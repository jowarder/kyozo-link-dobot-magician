# Changelog

The version number is in the `VERSION` file and shows in the window title.
V1.x is the first working release line, V2.x the demo-mode upgrades and the real arm's bring-up.

## V4.6 (2026-10-29): study 4 round, a cube's turn from its coloured top

- Follows V4.5 (git tag `v4.5`; frozen copy in the `Kyozo_Link_V4.5` folder and `Kyozo_Link_V4.5.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v4.6`, the `Kyozo_Link_V4.6` folder and
  `Kyozo_Link_V4.6.zip`. (Its app.log carries on here; the V4.5 copy has it up to 2026-10-28 13:06.) The study 4
  round's changes were set aside (git stash) while study 4 ran on V4.5, and put back for this freeze.
- **The lab's calibration of 2026-10-28** (`calibration.json`, `calibration.reference.npz`, `config.yaml`): the cube
  calibration study 4 ran with (1.59 mm), and the safety floor at z -31.5 mm.
- **Paper material** (`study/paper/`): three Word files of draft material for the paper (the development and the
  iterations, the algorithms and agents and their changes, the novelty and findings) and a comparison picture
  (in the folder copy and zip; pictures under `study/` stay out of git).
- **Study 4 round** (2026-10-28, Claude from `For_Claude\study_4`, the real Dobot's 12 runs on V4.5, with their raw
  folders' depth pictures; the narration `study/NARRATION_v4.md`, the ledger `study/CHANGES_v4.csv`, the ideas
  `study/IDEAS.md` rows 45-51). Study 4: 7 of 12 passed, swaps 1 of 5, 2 catastrophic, no alarms.
  - **A cube's turn from its coloured top** (`app/vision/depth_detector.py`): with only cubes on the table (the lab's
    setting), a cube's turn is read from its top face's own colour near its top's height, not the depth outline, which
    takes in the side faces the camera sees. S-08's blue cube, turned 45.6 degrees, read 1.0 and was gripped across its
    corners; on study 4's pictures, readings over 10 degrees off went from 22 cubes of 66 to 3. A test runs it on a crop
    of S-08's real picture (`tests/lab_frames/`).
  - **A cube let go of must be on the table** (`app/llm/tools.py`, `app/hardware/dobot.py`): on the Dobot, the next
    look checks for it, and a pick that follows a release looks first. Not seen anywhere, it may be in the fingers: the
    arm waits for a person (every move refused until Home). S-08's blue cube stayed wedged in the fingers, was carried
    to the green cube and put down on it.
  - **A swap keeps each cube's level** (`app/llm/arrange.py`): one standing on a cube is swapped onto that cube (S-09:
    blue on green, red refused at the table where blue stood).
  - Not changed: S-12's E-STOP above a tower near the base, until it is known what was seen (IDEAS row 48).

## V4.5 (2026-10-28): study 3 round, the fingers' 20 degree offset allowed for

- Follows V4.4 (git tag `v4.4`; frozen copy in the `Kyozo_Link_V4.4` folder and `Kyozo_Link_V4.4.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v4.5`, the `Kyozo_Link_V4.5` folder and
  `Kyozo_Link_V4.5.zip`. (The app was running at the V4.4 freeze, so its app.log carried on here; the V4.4 copy has
  it up to 2026-10-28 02:52, this one up to 13:06.) Study 4 ran on this version (the Dobot, S-01 to S-12): 7 of 12
  passed, 2 some parts, 3 failed, 2 catastrophic; swaps 1 of 5.
- **Study 3 round** (2026-10-28, Claude from `For_Claude\study_3`, the fingers angle check of 2026-10-28 and Rafi's
  lab note "cubes picked diagonally"; the narration `study/NARRATION_v3.md`, the ledger `study/CHANGES_v3.csv`, the
  ideas `study/IDEAS.md` rows 30-43). Study 3 on the Dobot: 12 of 20, no alarms, swaps 0 of 5.
  - **The diagonal pick: the fingers offset is allowed for** (`app/hardware/wrist.py`, `app/ui/main_window.py`,
    `app/ui/model_tab.py`): a steady fingers angle check is trusted up to 30 degrees of offset (was 15); over 15 it
    says the gripper is probably mounted turned on the wrist. The lab's check (+20.1 degrees) now loads trusted; in
    study 3 cubes came out of the fingers turned +10 degrees on average, the same way.
  - **Turns keep their angle** (`app/llm/tools.py`, `arrange.py`): a turn counts from how the cube lay when the
    request began, swap puts each cube down at its own angle, the check after a turn reads steadily and looks again
    after its correction (S-06, S-08, S-09: swapped, then the turn missed).
  - **A cube just put down is picked at that angle** when the readings wander but agree with it (S-07, S-10, S-12:
    the red cube refused for 16.5-18 degrees of spread); the steadiness check is unchanged.
  - **Drop** (`app/llm/arrange.py`, new tool `drop`; place_beside `drop_mm`): let go up to 100 mm above the table,
    moved first or beside another object; near the base, as high as the arm reaches there. A held cube asked for by
    id is said to be held (S-20 ended with the cube still in the fingers).
  - **The covered cube's colour** (`app/vision/depth_detector.py`, `app/llm/request_checks.py`): named from the
    colour groups without the top's; teal accepted for green or blue when neither is seen (S-14).
  - **Towers and swaps** (`app/llm/tools.py`, `arrange.py`, `agent.py`): "X on Y" with Y on X keeps the pair where
    the pile was (S-15); no saved places: the model is told not to ask for a tray; a refused swap says to swap again,
    and a reply that says "swapped" with no swap done goes back to the model (S-10). Each grip and release inside one
    call kept in the step's record. One cube taken off a pile and put somewhere = pick + place_beside, not
    take_apart (which moves every cube in it).
  - **The twin's touch check** (`app/hardware/sim_robot.py`): what the fingers touch is judged where they really
    point, as the grip already was; with a wrist fault set and allowed for, every grip had "touched" the cube. The
    study's twin runs (a perfect wrist) are unchanged.
  - Twin, Simple 20 chained with the real Qwen: with the lab's +20 degree fault and the correction 18 of 20, the same
    18 and the same calls as a perfect wrist (S-12: outside the twin camera's view; S-20: outside the workspace).

## V4.4 (2026-10-28): study 2 round, reviewer 2 fixes, the lab's 25 mm calibration

- Follows V4.3 (git tag `v4.3`; frozen copy in the `Kyozo_Link_V4.3` folder and `Kyozo_Link_V4.3.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v4.4`, the `Kyozo_Link_V4.4` folder and
  `Kyozo_Link_V4.4.zip`. Started without V4.3's app.log, which stays in the frozen copy. Frozen with the lab's
  settings of 2026-10-28: the 25 mm cube calibration (passed, typically 1.21 mm), reach 320 mm, gripper settle 1.5 s.
- **Study 2 round, extending V4.3** (2026-10-26/27, Claude from `For_Claude\study_2` and Rafi's lab notes; the plan
  `study/PLAN_V4.4_study2_round.txt`, the narration `study/NARRATION_v2.md`, the ledger `study/CHANGES_v2.csv`, the
  ideas `study/IDEAS.md` rows 18-29). Study 2: twin 19 of 20, Dobot 8 of 29; nine catastrophic runs, all on the Dobot.
  - **The arm stops for a person** (`app/hardware/dobot.py`, `dobot_link.py`, `interfaces.py`, `app/llm/agent.py`):
    after a connect (a power cycle) or a lost USB link the Dobot refuses every move until Home; an alarm it can't
    clear holds it too. A prompt stops at the first step that meets it ("the arm needs a person: press Home"); the
    controller's alarm bytes, pose, joints and queue are logged (S-08_Run1: reconnected without Home, the cubes were
    knocked off the table).
  - **The controller's own reach** (`app/hardware/dobot_arm.py`, new): every target is checked against the Dobot's
    arm (J2/J3, fitted to 323 real moves) before it is sent; picks and places near the base come down from lower
    (S-06_Run1: the approach needed J2 -6.1, alarm 0x12, every move after it refused until switched off and on).
  - **Touching cubes are two cubes** (`app/vision/depth_detector.py`): a flat top of two clear colours is split
    (S-10_Run2 to S-20: a green and a blue cube touching were one 31 x 54 mm "teal block" -- "no cube was seen").
  - **Cube size: the cubes measured** (`app/cube_size.py`, `app/vision/scene.py`, `app/llm/tools.py`): cubes that
    clearly measure the other size (20 / 25 mm) stop anything that grips one, and the app offers that size (Set /
    Keep); never changed by itself. **A Cubes list beside the prompt box**, the same setting as Settings > Cubes,
    locked while a prompt runs.
  - **The watcher** (approved by Dr. Curry, 2026-10-26; `watcher/window.py`): the plan's prompts wrap (the whole
    prompt shown); the cube size at the top; an arm that needs a person starts nothing ("Waiting for you"), Run by
    itself pauses; nothing is scored differently.
  - **Fewer wasted steps** (`app/llm/tools.py`, `arrange.py`): an id from an earlier look means the one cube of its
    colour now, and a swap finds the cube it put down by colour and place (six "Unknown object_id" in study 2); after
    move_object or swap, a put-down with nothing held is told the move is done (the twin's S-20).
  - **The twin's missed grips** (`app/llm/tools.py`, `app/hardware/sim_robot.py`): a grip that closed on nothing is
    looked at again and tried once more, as the Dobot's already was, and a finger on the cube's edge is said so (the
    realistic twin: "26 mm across, the fingers open 27.5" was read as "the gripper is too narrow").
  - **Picks see their cube whole** (`app/llm/tools.py`, `arrange.py`): before a pick's fresh pictures the arm is taken
    out from between the camera and that cube; a missed grip finds its cube again by colour if its shape is named
    another way; swap names each cube's id (the realistic twin, this round: a turn 11 mm off, a retry that lost a
    "green cylinder", the wrong cube turned after a swap).
  - **Tests**: `unittest.main()` moved to the end of six test files, so every class runs when a file is run alone.
- **Reviewer 2: the cube calibration and the watcher** (2026-10-27; two read-only reviews, each finding checked in the
  code; Dr. Curry approved all the fixes).
  - **Cube calibration** (`app/calibration/cube.py`, `app/ui/calibration_panel.py`, `cube_tour.py`):
    - a take-back the camera can't judge from above (the gripper over the spot) is looked at again with the arm out
      of the way, as the pick test does: "can't tell" counted as "taken", so a grip on nothing carried on and the
      cube left behind was paired with the next spot;
    - more than a fifth of the spots (and at least 2) missing by over 3 mm fails the run, however good the typical
      (the median alone passed 6 spots at 1 mm with 4 at 4-5 mm); "Save it anyway" says why;
    - a look back at the first spot over 1.5 mm off is reported, no longer added to the fit as a spot that "agrees
      with the first"; the slip shown is the worst look back kept, not the last; the check's take-back goes where the
      cube is seen and checks the wrist's turn, as every spot's does;
    - after a stop part way, where the cube is follows what the step last did ("still in the gripper" was said of a
      cube just let go of); a failed check drops its spots' turns too; old progress files start afresh (format 2);
      the walk-through's limits are the code's (2.0 mm in every mode, the slip check against the Dobot's 1.0-1.8 mm).
  - **The watcher** (`watcher/`):
    - **scoring**: a swap with one cube knocked off the table no longer scores 100 "Full"; the cube a "beside" or
      "between" target is measured from is named in it, so not held to the 10 mm rule (PREREG 4: S-12 failed when the
      lift nudged the tower base); a run that passed is a pass whatever failed after the arm was done; a 45-degree
      turn says the other way ends the same (the wrist's way is in picks.csv);
    - **counting**: a chained set's infrastructure failures and the watcher's own unscored runs are kept and not
      counted (PREREG 5.1; they were the robot's fails, in the unseen test's too); "Proceed to next task" is an
      intervention (PREREG 6); "I had to help" is no verdict on where the cubes ended (not a disagreement); "Some
      parts" runs count at the session's end;
    - **records**: the time limit is the task file's (the unseen test's 5 minutes, PREREG 3; Simple 20 keeps its 10);
      a chained twin run's start and difficulty are the scene it started from, not the plan's draw; Discard and run
      again in a chained set starts from the same scene; a run scored and never saved is kept (`__crashed`, not
      counted); every CSV has one line ending (Excel showed a blank row between each); the workbook's "#" is the same
      run on every sheet and its links open the run's report; the E-STOP notice no longer counts as a finished job.
- **The watcher's Run log shows each step whole** (2026-10-27, display only: nothing saved or scored changes): a
  step's result and a refusal's whole reason, no longer cut at 120 characters ("ERROR:" dropped, REFUSED kept);
  list_objects as one line of the cubes it saw (`3 cubes: red (230, 70, 26), ...`), not its raw answer; arguments as
  `place(x=145, y=-67, z=20)` and `swap(obj_1, obj_2)`. A test's steps still show by name only.
- **Reviewer 2, second round: the calibration** (2026-10-27, before a lab session; three read-only reviews, each
  finding checked in the code; no limit changed):
  - **Cube calibration** (`app/calibration/cube.py`): a run stopped before its spots were planned (the arm not homed,
    a first move refused, Pause while centring) carries on by taking the empty table and planning its spots afresh --
    every 'Manually gripped - continue' failed until 'Start over'; an arm that needs a person (an alarm that won't
    clear, its link lost, not homed) pauses the run with its spots left to do -- taken as "can't go there", every spot
    left was skipped in seconds and the run lost; a cube seen to have bounced or been knocked after it was let go
    leaves that spot out (carrying on's first choice had put it in the fit); a grip that closed on nothing is no
    longer taken as holding the cube if the run is stopped then.
  - **Fingers angle check** (`app/hardware/wrist.py`): each reading is folded within 45 degrees of the put-downs' own
    typical turn, not of what the wrist was told (with the fingers ~15 degrees off, the lab's 14.6-degree reading at
    -40 from below was taken as -75.4, and that one put-down made 15.6 degrees of backlash and 18.2 of scatter); up to
    2 put-downs far off the others' fit (over 6 degrees and 3 times the scatter) are left out and named; a fit refused
    is refused the same when loaded again (refused for backlash under -1 degree, it was saved at 0 and came back
    trusted). The lab's 2026-10-26 check, refitted: offset +23.7, gain 0.61, backlash -2.4, scatter 6.9 -- still
    refused: the wrist didn't follow below about 0 degrees (check it turns to -40 with the cube held).

## V4.3 (2026-10-26): Claude feed 1, 20 mm cubes, calibration fixes

- Follows V4.2 (git tag `v4.2`; frozen copy in the `Kyozo_Link_V4.2` folder and `Kyozo_Link_V4.2.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v4.3`, the `Kyozo_Link_V4.3` folder and
  `Kyozo_Link_V4.3.zip`. Started without V4.2's app.log, which stays in the frozen copy.
- **Updated from task data fed to Claude** (Rafi, 2026-10-25): the app is improved in numbered feeds, each one the
  task data (each run's folder: run.json, RUN_FULL_REPORT, run_report, trace, moves, picks, gripper, alarms,
  model_log, observer, start/end pictures) from the real Dobot and the twin.
  - Feed 1: started 2026-10-25. Study 1's package and the skipped-runs notes; round 1 of at least 4. Goals: complete
    every task, then cut the latency; another LLM can be picked, Qwen stays the default. The narration is
    `study/NARRATION_v1.md`, the change ledger `study/CHANGES_v1.csv`, the ideas `study/IDEAS.md` (rows 1-15).
- **Round 1: fewer model turns** (`app/llm/agent.py`, `trace.py`, `tools.py`, `ui/model_tab.py`). Study 1's Dobot runs
  took 128 s each, 69 s of it Qwen deciding; every run began with a turn that only called list_objects (156 s over 18
  runs) and ended with one that only wrote a summary (368 s).
  - **The app looks first**: list_objects runs before the model's first answer and is given to it as its own call and
    result (the Model tab: "App · turn N: the look before the model's first answer").
  - **Several steps in one answer**: allowed and asked for; a step that fails stops the rest of that answer ("NOT RUN",
    not counted as a refusal).
  - **`done()`**: a new tool after the last step. The app checks the goal (nothing held, the goal check) and writes the
    reply from the steps' results; "done()" written as text counts the same. Not done: sent back, as before.
  - **One answer at most 256 tokens** (was 512; the longest real answer in two 20-task chains was 129): one that ran on
    in the twin took 157 s (S-14). Cut off, it is told to send its tool calls only.
- **Round 1: refusals the model couldn't get past** (`request_checks.py`, `tools.py`, `arrange.py`): a refused
  build_tower says the exact call (bottom to top); the same refused step sent again is told not to send it again;
  "by the tower" with no tower says so; a put-down with nothing held names pick(object_id=...) of the object last
  moved; "nearer" and "farther" are directions ("40 mm nearer the robot" = back); place_beside or place_on naming the
  held object itself as where it goes is refused, with the others' ids (the twin's S-14 put the blue cube "to the left
  of the blue cube", and the five tasks after it failed from the table it left).
- **Round 1: the Dobot's time between moves** (`app/hardware/dobot.py`). Study 1's 223 move-to-move gaps had a median
  of 0.69 s (157 s over 18 runs): each move asked the Dobot 8 status questions, about 0.13 s each on the serial link.
  What a move's arrival check read (no alarm, arrived) now stands for 2 s while nothing moves, clears or stops the arm:
  the next move's leftover-alarm check and the move record's readings use it (6 requests fewer a move). The arrival
  check still runs after every move; after an E-STOP, Clear Alarms or homing the Dobot is asked again.
- **Round 1: one wrist move fewer per pick and place** (`tools.py`): the travel ends short of the wrist's angle on the
  approach side and the last move turns the rest, so the backlash is taken up as before without a turn-past move
  (study 1, S-11_Run1 moves 3 and 9).
- **Round 1: pick another LLM** (`app/llm/models.py`, `ui/model_combo.py`, `ui/main_window.py`). Every installed Ollama
  model that can call tools is in the Model list, Qwen first, with notes: its size on a laptop (over 6 GB: slow),
  "not tested in the study" for non-Qwen models, and laptop models to pull. A pick lasts for the sitting; config.yaml's
  Qwen stays the default.
- Round 1 results (the twin, real Qwen, all 20 hands-off): V4.2's chain 18 of 20, 4.20 model turns and 73 s of model
  time a run; V4.3's first chain 20 of 20, 3.35 turns, 59 s; the second (with the refusal fixes and the 256-token cap)
  13 of 13 up to S-14 at 32.5 s of model time a run, then S-14's fault (fixed after it) and the five failures it left;
  the third (all of round 1) 20 of 20, 3.25 turns, 6 refused steps. Every test suite passes (33; six tests changed
  for the app's own look and done(): the scripted models' turns move up one). Not yet run on the Dobot.
- **The watcher: up to 10 studies** (`watcher/results.py`, `window.py`, `overview.py`, `study/twin_test.py`; Dr. Curry
  agreed 2026-10-26, the watcher's freeze lifted for this change only). The Study box lists study 1 to study 10
  (study n: the app after n - 1 updates, v(n-1)), saved in `study_1` ... `study_10`; Claude's input, Delete results
  and `twin_test.py --round` take them too. The cross-study report shows studies 1-3 and on to the last one with
  anything saved; its paired comparison stays study 1 vs study 3, as the prereg has it. Nothing else changed: the
  folders, scoring and reports of studies 1-3 are as they were.
- **Cube size: 20 or 25 mm** (`app/cube_size.py`, `app/ui/main_window.py`, `watcher/tasks.py`, `window.py`,
  `report.py`, `study/twin_test.py`; 2026-10-26, for the new 20 mm cubes). Settings > Cubes picks the study's cube
  size, saved in config.yaml (`vision: known_sizes_mm: cube`, which the camera already went by). The watcher and
  `twin_test.py` now take it too: the twin's cubes are set out at it, the Dobot's are found and scored by it (the
  task files' own `cube_size_mm` is only the default). Every session and run records it, and each run's report and
  the results' Runs sheet show it ("Cubes (mm)"; runs from before say 25). It can't be changed while a prompt, a
  calibration or the watcher's session is running. Calibrate with the new cube after changing it.
- **The watcher's status strip** (`watcher/status_strip.py`, `window.py`; 2026-10-26). A coloured line at the top of
  the watcher says what it is doing now: grey Ready; amber Setting up (looking at the table, the countdown); blue
  Running, with the task (7 of 20 · S-07), the steps so far and "last activity N s ago" (a long model turn on the CPU
  isn't a freeze), its dot blinking; orange Waiting for you (set the table out, a verdict, Save, or Run by itself
  paused, and why); green All N tasks done, with passed and failed, where it was saved and how long it took; red
  Ended early after N of M, and why. Each task's time, the session's and about how long is left on the right; the
  window's title says it too ("Kyozo Watcher · running 7/20"), for the taskbar. Waiting for you flashes the taskbar;
  the session's end flashes it and gives a short sound. It only shows: nothing is scored or saved differently.
- **Cube calibration fixes** (`app/calibration/cube.py`, `app/ui/calibration_panel.py`; 2026-10-26, after the lab's
  spot-2 take-back came up empty and three runs paused):
  - **Gentle release:** let go, the open fingers rise the first 10 mm slowly (15 mm/s), so a finger still touching
    the cube doesn't drag it 1-2 mm or tip it. (The air gripper's own speed is the pump's: not changed.)
  - **Re-centred before the take-back from spot 3:** before the run's own fit (5 spots), the calibration in use says
    where the cube is, less its own error at the 2 or more spots so far (only if those agree within 1 mm); a move of
    1 mm or more across the fingers, the fingers go there. (From one spot its own error can't be told from a move:
    spot 2 is covered by the look again below.)
  - **Turn check from spot 2:** the cube's turn as it was let go is told against the spots before from the second
    spot on (the fourth before); each spot's turn reading is logged (`turn_seen_deg`).
  - **Well-seen spots (the Dobot's):** only where the camera sees the table no more than 35 degrees slanted, by the
    calibration in use (near the base and to the sides it saw a 25 mm cube as 23 x 29 mm) -- or, a camera that sees
    no spot that well, within 10 degrees of the best-seen one; the best-seen ones if that leaves too few.
  - **Look again before pausing:** a take-back that comes up without the cube opens the gripper, moves the arm out
    of the way, looks, and takes the cube once more where it is now (within 8 mm); a second miss pauses as before.
  - **The calibration's cube size from a list:** Cube 25 mm, Cube 20 mm, Size: measure, or Other (typed, for a
    caliper reading). Live, it starts at Settings > Cubes and follows it; any cube can calibrate, its size given.
  - Changing Settings > Cubes now says no new calibration is needed (the cube is only the calibration's marker).
  - A controller that stops answering during a take-back now pauses saying where the cube is and what to do
    ("switch the Dobot off ..."), as it does elsewhere.
- **A pick goes where the cube is now** (`app/llm/tools.py`, `app/vision/scene.py`; 2026-10-26). The fresh pictures
  a pick already takes to read the cube's turn now give its place too (`SceneBuilder.looks_near`): if their middle is
  1 mm or more from where the cube was listed (it slid since the last look), the fingers go there, and the run's
  record says so ("moved": from, to, mm). Under 1 mm, the camera's own wander, it goes as listed; its height as
  listed.

## V4.2 (2026-10-25): improved from Claude's runs, iteration 1

- Follows V4.1 (git tag `v4.1`; frozen copy in the `Kyozo_Link_V4.1` folder and `Kyozo_Link_V4.1.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v4.2`, the `Kyozo_Link_V4.2` folder and
  `Kyozo_Link_V4.2.zip`. Started without V4.1's logs (app.log, the Model tab's prompt logs), which stay in the frozen
  copy.
- Last: the twin chain (all 20, real Qwen, hands-off) 20 of 20 (2026-10-25, twin run 10); every test suite passes
  (33). Not yet run on the Dobot.
- **Updated from the results of Claude's runs** (Rafi, 2026-10-23): V4.1's watcher test is frozen; V4.2 improves the
  program in iterations, each one fed by the results (logs, reports) of Claude running the tasks.
  - Iteration 1: started 2026-10-23.
- **The results folder named after the Session menu** (Rafi, 2026-10-23; `watcher/results.py`). Each study keeps its
  `study_N` folder (the watcher's Study box), and inside it one folder per menu choice: `Test_Twin_with_unseen_tasks`,
  `Test_Real_Dobot_with_unseen_tasks`, `20_Tasks_for_Twin`, `20_Tasks_for_Dobot` (were `Twin_Test_Data`,
  `Dobot_Test_Data`, `Twin_Simple20_Data`, `Dobot_Simple20_Data`). Practice has the same four names in
  `Practice_Session\practice_study_N\` (no `practice_study_N_` in front any more). Inside each, nothing changed: the
  reports, `User_Saved_<folder>\` with each run's own .md and web page, `_raw_data`, `_sessions_log`.
  - **Everything Claude never reads in one folder,** `Private_never_for_Claude\`: `Test_Tasks\test.yaml` (was
    `Test_Tasks_private`), `Study_Overview\` and `Study_Overview_practice\` (were `Study_Overview_private`),
    `Recycle_Bin_test\` (was `Recycle_Bin\Test_private`). The old names still count as private.
  - **Claude's input per study, named like the results** (`watcher/handoff.py`): `For_Claude\study_N\` with
    `START_HERE.md`, `SUMMARY.md` (Twin vs Dobot first; `PREVIOUS_SUMMARY.md` from study 2), and one folder per kind
    of data named as in `study_N` (`20_Tasks_for_Twin\`, `20_Tasks_for_Dobot\`: `FULL_REPORT.md`,
    `full_report.json`, `runs\`), and `study_N.zip`; practice's in `For_Claude\Practice_Session\practice_study_N\`.
    Made from the 20 Tasks runs (and training, if any), by itself after each 20 Tasks session too; never the unseen
    test's. START_HERE says which Kyozo Link version made it.
  - What the earlier layouts saved moves to `_earlier_results\` (nothing deleted). RUNBOOK, ROUND_PROMPT and MEASURES
    follow the new names; PREREG's "Where the data goes" line still names the old ones.
- **A skipped task is saved too, with why** (Rafi, 2026-10-23): a 20 Tasks task that never started (the table not
  READY within 20 s, or Proceed to next task pressed before it started) is saved as a run of its own under the next
  free number (`S-07_Run1`), marked **SKIPPED**: not a pass or a fail, counted apart. Its record (`run.json`,
  `run_report.txt`, its own .md and web page) says why, who skipped it and after how long, what the camera saw (and a
  picture of the table, and the depth on the Dobot), the task before it, how that ended and where it left the cubes,
  and the session's set-out. And, to point Claude at the cause: where this task needed each cube (had every task
  before gone as asked) vs where it was, and how far off; the last task that actually ran, when the one before was
  skipped too; and a failed set-out's every step, with what came back (the refused ones always).
  `FULL_REPORT` gets a Skipped column in its totals and a "Skipped tasks" section; Claude's `SUMMARY.md` lists them
  with the same details (a skip after another task usually means that one left the cubes where this one can't start);
  the cross-study report leaves them out of its counts. The session's index line stays as before.
- **Claude's package also carries what was skipped before V4.2, and the engineer's notes** (`watcher/handoff.py`):
  skips that were only logged (each sitting's index: task, why, what the camera saw) are rebuilt into a "Skipped before
  V4.2" section of `SUMMARY.md`, each with the run saved last before it in that sitting, and into
  `skipped_before_v4.2.json`; the study's own reports in `study/reports/study_N/` are copied, as written, to its
  `notes\` (START_HERE: a cause in the watcher is fixed there, not Claude's to change). The study data isn't touched.
  `For_Claude\study_1` built 2026-10-23 from the baseline: 18 Dobot runs (S-01 to S-15), 5 twin runs (S-01 to S-05),
  28 logged skips, the two reports.
- **Part 1 of iteration 1: the table as it is, and how runs are judged** (Rafi, 2026-10-23/24; the plan in
  `study/PLAN_V4.2_free_start.md`). The watcher (the measuring instrument) only; the app's own improvements come next,
  from study 1's data.
  - **Nothing sorted, nothing waited for:** the Dobot's set-out is gone. Every task of a chained set (Simple 20, the
    unseen test) starts from the table as the task before left it, on the Dobot and in the twin (which starts from the
    set's layout once). No READY wait, no 20 s skip. 1 run per task, as before.
  - **A look before each task:** the arm parks out of the camera's way and its own position is checked; 3 pictures;
    if a cube is missing, the arm to a second position (the other side) and 3 more. A tower's hidden cubes are worked
    out from where they were last seen. The task then starts with the cubes there; parts needing a cube that can't be
    seen are recorded as impossible. Skipped only if none of its own cubes can be seen; no cube at all for 3 tasks in a
    row ends the session; a camera that fails twice: not run (infrastructure). The end look is retaken from the second
    position too when a cube is missing.
  - **Judging:** each run's outcome PASS (the strict pass, unchanged) / SOME PARTS / FAIL / SKIPPED, a CATASTROPHIC flag
    beside it (a cube knocked off or past the tray's edge + 20 mm, another cube moved > 30 mm, a tower brought down; the
    arm couldn't park, lost its homing or still holds a cube), the score formula unchanged. A cube only in the task's
    way may be moved out of it (ending on the table, unstacked, inside the tray). Each run records its start condition
    (clean, tower to take down, cube out of the tray, cubes close together, cube not seen) and its parts. The failure
    type follows the first wrong step: a cube sent the wrong way is "plan" (the app's object ids read from its own
    looks), a refusal while moving a cube aside "preparation". Turns were already scored from all 5 end pictures (each
    cube's median angle).
  - **Time:** a chained set's task has 10 minutes (simple.yaml 600 s; the unseen test's file, made with 300, gets at
    least 600 too); one answer from Qwen 400 s (config.yaml `llm: timeout_s`, and the app's default).
  - **Reports** (run report, run page, FULL_REPORT, workbook, session summary, Claude's SUMMARY.md): the outcome, the
    flag, the start condition; catastrophic runs listed first. ROUND_PROMPT says how a run is judged.
  - **Study 1 rescored:** `study/rescore_v42.py` writes RESCORED_V4.2.md / .json beside each data folder's reports
    (nothing else touched). Dobot: 13 PASS, 2 SOME PARTS (S-07, S-08), 3 FAIL; S-05 "plan" (was "limit_alarm") and
    catastrophic (blue left at x = 149). Twin: 4 PASS, S-05 the same.
  - **A second, independent review** of Part 1 found 8 bugs, fixed with a test each: a cube under a tower at the end
    counted as knocked off (CATASTROPHIC); a cube already outside the tray flagged in every later task; a cube under the
    cube a task moves wrongly allowed to move; V4.2's judging leaking into training runs (now chained sets only); by
    hand, the arm moved by itself every 1.5 s (now it only looks; by itself it moves only when nothing else holds the
    arm and E-STOP is off, and a long swing lifts 60 mm first, the wrist mirrored too); a task waiting for ever after
    Run by itself was ticked again; a tower of three's middle cube taken for missing; the empty-table count not reset
    when a task started. And: SOME PARTS only when the part's cube really moved (> 5 mm), the first move of a cube
    decides "plan", a skipped task's record keeps the scene, test prompts' parts not shown on screen.
- **Part 2 of iteration 1: the app** (2026-10-24; study 1's baseline and the twin chain behind each change):
  - **The twin reads like the Dobot:** a cube measured near 25 mm is 25 mm during a watcher session (a tower's top read
    28 mm, too wide for the gripper); a stacked cube's middle by its flat top, its turn too when the outline is pulled
    more than 5 degrees by the side faces (21.9 degrees read for a cube at 31.4; 8 of 8 app-built tower tops picked).
  - **Towers:** pick and place_on clear up to two cubes off the one wanted (the bottom of a tower of three); place_on
    onto a cube with another on it clears it first when the request names the target but not what's on it.
  - **Each cube its own direction** in a two-cube request (S-05: red sent forward, blue back).
  - **Turns checked** (the arm out of view, several pictures) and put right once if more than 6 degrees off (the
    Dobot's anticlockwise turns went 25-33 degrees too far).
  - **Bumped cubes:** before a pick is refused for an unsteady reading, 10 more pictures with the arm away; a neighbour
    too close for the open fingers moved aside first (if the request doesn't name it); a cube read too wide measured
    again (4+ pictures, two thirds fitting).
  - **Dropped cubes:** letting go mid-air = no longer held, the table looked at again; on a robot that can't feel a
    grip (the Dobot) each pick checked by the camera, a miss said and tried once more. That check first skips 3
    queued pictures (2026-10-25, found by the live-mode test): a picture from before the pick showed the cube still
    there, a grip that held read as missed, and the gripper opened -- on the real arm, the cube dropped from the look
    spot.
  - **Qwen:** an answer capped (512 tokens; S-15's ran for the whole 400 s), told once, then the prompt ends; new rules:
    do every part it safely can, look again after a failed step, stop after an alarm, never end holding a cube.
  - Two independent reviews (Part 1: 8 bugs; the app: 7 and more), every fix tested. **The full twin chain (all 20,
    real Qwen, hands-off): 10 PASS at Part 1 -> 15 PASS -> 20 PASS** (S-01 to S-15, then group D's fixes; 20 of 20 on 2026-10-25, twin run 10). Not yet on
    the Dobot.
  - **Group D** (2026-10-25): a tower is built where its bottom cube is unless the request names a place (S-17); the
    top of a tower of three (more than 62 mm up) turned by its flat top (S-18 to S-20); "take the blue cube off the
    tower" no longer read by the goal check as building one, which had the model put it back (S-18); a cube lifted off
    only to get at the one under it is put down by the next pick, and the refusal says where (S-19, which timed out
    holding it); place_free beside an object with a side ("right") refused, pointing to place_beside -- it took
    whichever side was free (S-19).
  - **A gap is measured between squared-up faces** (Rafi, 2026-10-25; S-16 scored 97): place_beside measured a gap
    from a turned cube's corner, the watcher between squared-up faces (centres a cube's size plus the gap apart), so a
    50 mm gap beside a cube turned 35 degrees came out about 60 by the watcher's measure. For a square object it now
    aims for the watcher's gap; never closer, corner to corner, than the smallest gap (5 mm), so turned cubes can't
    touch. Long objects are still measured as they lie.
  - **Two tower gaps** (twin run 9, 2026-10-25: 17 of 20, S-16 passing): S-17 -- Qwen picked the tower's bottom
    cube first, build_tower was refused ("already holding"), and it built the tower near the base instead. A held
    cube that is one of the tower's own is put back where it was picked up (if that spot is still free), then the
    tower built. S-18 -- "put it to the left of the tower": beside the tower's top cube was refused four times as not
    named (run 8 passed only by measuring from the held cube's old spot). "The tower" / "pile" / "stack" now names
    its cubes as where to put something (place_on, place_beside, place_between, move_above; picking one still needs
    it named), and a cube put beside a pile's top goes on the surface the pile stands on, not let go a cube up.
  - PREREG still describes the set-out and the READY check (§ the unseen test built on Simple 20) and V4.1's failure
    order: its wording to follow, with Dr. Curry.

## V4.1 (2026-10-23): the 20 tasks, by themselves

- Follows V4.0 (git tag `v4.0`; frozen copy in the `Kyozo_Link_V4.0` folder and `Kyozo_Link_V4.0.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v4.1`, the `Kyozo_Link_V4.1` folder and
  `Kyozo_Link_V4.1.zip`. Started without V4.0's logs (app.log, the Model tab's prompt logs), which stay in the frozen
  copy.
- The lab's first runs of the 20 tasks (2026-10-23) and why some were skipped: `study/reports/study_1/` (group D on the Dobot;
  all 20 in the twin).
- **Only cubes: nothing grey, black or white is an object.** With `vision: cubes_only` the study's red, green and
  blue cubes are all there is, so a colourless thing is the robot's own: at the lab (2026-10-22) the parked gripper,
  missed by the arm's mask, was "a grey block" in the way and every move from the parking spot was refused.
- **Simple 20: the watcher test with the cubes put down once** (Rafi, 2026-10-22; `study/tasks/simple.yaml`, not
  the study's training or test set -- train.yaml and PREREG are unchanged). Red, green and blue go down once (red
  left, green middle, blue right, 7 cm apart, ~23 cm out), then 20 tasks run by themselves, each from wherever the one
  before left the cubes, in Dr. Curry's 4 groups of 5: A moves only; B swaps, each with a turn (the only turns);
  C towers of two, each taken down so the next can be built; D a tower of three, and two cubes let drop from a height
  (their targets say `within_mm: 20` and ask no angle). Every distance and gap asked for is 40 mm or more.
  - **The cubes can go down anywhere, in any order** (on the Dobot): before the first task the arm sets them out
    where it starts itself (`watcher/setout.py`: list_objects, pick, place_at a place made for it; a cube on
    another's spot is put aside first). Not a task, not scored; every step logged (set_out.json, the index). If it
    can't, Run by itself pauses and says why, to put them there by hand.
  - **The Session menu lists the unseen test and Simple 20 only** (four choices; it opens on Simple 20). The training
    sessions are kept in the code, out of the menu. Every Simple 20 prompt has its own button: **▶ Run** before a
    session, **▶ Now** during one (in place of the current task if it hasn't started, else straight after it).
  - **Each group in a session of its own:** a "Run:" row with ▶ Run Group A, B, C, D and ▶ Run all 20 (the list's
    group chips are labelled "Show:", filters only; the tick / times / order controls are hidden for Simple 20). Put
    the cubes down anywhere before any group: the set-out lays them out where it starts -- for group D building its
    tower too (the bottom cube to its spot, the one above put on it with place_on).
  - The set-out ends with a look at the table when it built a tower: on the Dobot (2026-10-23) it left the arm
    hovering over the tower it had just built, hiding it from the watcher's camera, and group D's five tasks were all
    skipped as "not READY".
  - **The unseen test is built on Simple 20** (Dr. Curry, 2026-10-23; PREREG §3, §9 item 13). `study/make_test_tasks.py`
    (Make test tasks…) makes it as a chain like Simple 20: T-n has S-n's group and kind with its own cubes (always red,
    green, blue), directions, distances and gaps (40-60 mm), turns (20-40° either way), tower orders and drop heights;
    the chain is found on paper first (each task READY from where the ones before leave the cubes, none a Simple 20
    task), then each task the twin can do is done there by its tool recipe (one that isn't is drawn again, with the
    rest after it). A test session on it runs as Simple 20 does (by itself, set-out, Run Group A-D, 5 minutes,
    Proceed, the score), its prompts hidden. The menu's Simple 20 entries are now "20 Tasks for Twin / Dobot (by
    itself)".
  - **Picks go ahead with an unsteady angle reading up to 15°** (Rafi): after the second look, a cube whose turn the
    camera reads up to 15° apart is picked from the readings' average (was refused past ~8°); a pick that then bumps
    it and still holds it is scored as it ends (partly, or a fail). The set-out also looks again and tries a pick the
    tools sent back for an unsteady reading up to 3 times (it gave up at the first).
  - The set-out puts each cube down exactly on its spot with the place tool: through saved places, the Dobot's open
    fingers didn't fit a sized spot ("full") and an unsized one is the tip's height, not the table's (the lab).
  - **Looser calibration grades** (Rafi, 2026-10-22): the pick test passes with its worst spot within 3.0 mm (was
    1.5); the fingers angle check is trusted, and used for picks, up to 10° of scatter (was 1.5°), and a saved check is
    judged again by these limits when it is loaded. The lab's check that day (+13.1°, 88%, scatter 8.9°) is now used;
    its rotation pick test, uncorrected, missed by the same 13.1° on average.
  - **Every refused step is logged**: in the run log as it happens (REFUSED …), in run.json (`refused_steps`: tool,
    what was asked, why, when), in refused_steps.csv, and in the session's index.
  - **Partial credit (0-100) next to the strict pass / fail** (every watcher run, not only Simple 20;
    `watcher/tasks.py` `partial_credit`): each target earns 0-1 -- full within the pass rule (10 mm, 8°), falling
    evenly to 0 at three times it (a drop: full within its 20 mm, 0 at 50 mm); a tower half for its height, half for
    where it stands; the task the mean; 25 points off for each other cube moved, 50 for one knocked off the table.
    Bands: Full (90+), Partial (50-89), Fail (under 50). In the watcher's result line, the Session plan, run.json
    (`credit`), run_report.txt, the session's results.xlsx (Score, Band columns, mean by level) and FULL_REPORT.md,
    and SESSION_SUMMARY.md (mean by group). Refused steps, time and alarms are reported beside it, not in it.
  - **⏭ Proceed to next task**: ends the task now and goes on -- running, it is ended, scored and saved ("ended by
    you" if it didn't pass); not started yet, it is skipped and logged; finished, it is saved. No verdict is asked.
  - New session kinds "Simple 20 for Twin / Dobot (by itself)" (results in `Twin_Simple20_Data` /
    `Dobot_Simple20_Data`), with **▶ Run all 20**, **▶ Group A-D** and a **▶ Run** on each task's line.
  - **By itself, on the Dobot too:** READY from the camera, a 5 s countdown (E-STOP or unticking Run by itself stops
    it), scored by the watcher with no verdict asked, saved under the next number, then the next task. **Every run
    is saved** -- pass, fail, refused, error, E-STOP, the **5-minute time limit** ("timeout"), even one that couldn't
    be scored ("not scored"); nothing is re-run. A task the table can't start within 20 s is **skipped and logged**
    (the index, the plan, SESSION_SUMMARY). Each run's start is noted in the index the moment it starts, and a run an
    earlier sitting never finished (the app closed or crashed) is kept as `…__crashed` when the next session starts.
  - **Towers are scored:** the watcher's finder now sees cubes up to three high and says how high (`level`); a cube
    under a tower is taken to be there, under the one on top (`with_hidden`); a new target `tower: {cubes: [bottom,
    ..., top]}` passes when the top cube stands that many cubes up within 10 mm of the bottom one's start (the middle
    one is hidden from the camera: the report says so). A task can start from a tower (`start: {tower: [...]}`), and
    a cube asked to go somewhere on the table that ends on top of another fails. The twin sets out the chain's start
    (towers too) when a group or one task runs on its own; between chained runs the app keeps what it stacked on what.
  - `study/check_tasks.py` knows towers and checks a chained set by playing it through from its layout.
- **Watcher active** (the main window's prompt box, Rafi's request): with it on, every prompt you send is recorded
  as the watcher records a run -- the table looked at before and after (pictures, cube positions, how far each moved
  and turned), every step, move, refused step and alarm, the arm, camera, calibration and settings -- whether it is
  done, refused, fails, is stopped or reaches its 5 minutes. Afterwards the arm parks for the end look and you name
  the run (and may give a verdict). `Kyozo_Link_Results\Prompt_Runs` is laid out as a watcher results folder and
  written by the watcher's own report code, so a recorded prompt keeps everything a watcher run does: `_raw_data\<name>`
  (run.json, run_report.txt with the event timeline, time split and "what happened", PROMPT_REPORT.md, trace, model
  log, pictures and depth, moves / gripper / picks / alarms / refused_steps .csv, observer.json), its own page in
  `User_Saved_Prompt_Runs` (.md, and HTML with its pictures), FULL_REPORT.md / .html, full_report.json and
  results.xlsx across every recorded prompt, and a hash-chained index per sitting of the app (`_sessions_log`).
  Listed in `PROMPT_RUNS.md`. No pass or fail is worked out (the reports say NO TARGET): a typed prompt has no
  target. A red ● REC shows while it is on. Runs saved in the first layout (`Prompt_Runs\<name>`) are moved in.

## V4.0 (2026-10-22): beta test

- Follows V3.9 (git tag `v3.9`; frozen copy in the `Kyozo_Link_V3.9` folder and `Kyozo_Link_V3.9.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v4.0`, the `Kyozo_Link_V4.0` folder and
  `Kyozo_Link_V4.0.zip`.
- **Only cubes on the table: `vision: cubes_only: true`** (config.yaml; the lab, 2026-10-22). Depth noise rounded a cube's corners: the detector called it a cylinder, set its turn to 0 and took its middle from a circle, so a cube turned ~35 degrees was gripped square and missed; a side face read with the top made a 25 mm cube "23.7 x 27.5", a "block", and a finger caught its edge. With cubes_only a top is never taken as round (its own turn kept), a cube's middle is its flat top's (0.2-1 mm better in the twin), and a block, cylinder or ball whose narrow side is near the known cube size (up to 1.6 cube sizes long) is that cube, 25 x 25. Without it, nothing changes; a block measured near a known cube's size is now that cube either way. The demo is unaffected (known sizes are live only).
- **The watcher study needs no printed paper** (Dr. Curry agreed 2026-10-22). The cubes go anywhere on the grey
  sheet by hand, and every instruction is relative to the cubes:
  - **New training set** (`study/tasks/train.yaml`): 20 tasks in 4 levels, 5 each: one cube one step; one cube two
    steps or directions; two cubes; three cubes. The file gives an `area:` (x 170–290, y −110 to 110 mm) instead of
    `sheet: a4`, and each start is just the cubes.
  - **Scoring additions** (`watcher/tasks.py`): `beside` also takes `further` / `nearer` (along the robot's x);
    a `turned` target is measured from the cube's own start (not an absolute angle); a `row` can have a left-to-right
    `order` (and must then run left to right); the "Pass if" wording follows.
  - **READY from the camera** (`watcher/arrange.py` `check_start`, the watcher's setup text): it sees exactly the
    task's cubes, each in the area and the arm's reach, at least 3 cm apart (4 cm asked), and the task can be done
    from there; otherwise it says what to move. No outlines, spots or paper check. Every target is measured from
    where the camera saw the cubes start.
  - **The twin** puts the cubes at seeded random places under the same rules (set | task | repeat).
  - **The unseen test is made from the training set** (`study/make_test_tasks.py`): T-n has TR-n's level, cubes and
    steps, with values (colours, 20–60 mm, 15–60°, sides, gaps, order) and wording drawn from the secret seed. The
    hand-written list of shapes is gone: change the training tasks and the generator follows.
  - `study/check_tasks.py` checks paper-free sets: a task must be doable from at least 50 of 200 random starts.
  - RUNBOOK and PREREG (§2, §3, §4, §7, §8, §9) follow; the continuous calibration is not used in the study.
  - **Reviewer-2 fixes (2026-10-22 night):**
    - **The start that's scored is a fresh look of 5 pictures** taken at Start run (the READY check's was 1 picture,
      maybe seconds old); not started if a cube moved over 5 mm since READY, or the start no longer passes READY.
      The end look is 5 pictures too, looked at once more if it doesn't see the start's cubes (recorded:
      `end_relooked`, `end_unclear`). By hand, the run's record and its difficulty use the start as seen.
    - The request checks: a prompt naming two directions or sides allows either ("30 mm to the left, then 60 mm to
      the right" had its second leg refused); further / nearer sides ("nearer the robot than"); place_beside's own
      near / far; no direction check on a relative prompt ("left of the green cube", a row).
    - "Between" needs room for the fingers (15 mm each side); a two-leg move's first leg must be in reach; cubes end
      10 mm apart at least (a turned cube's corners); READY's advice says "towards the middle (too far to the
      robot's left)" instead of a left/right the person facing the robot would get backwards.
    - A turned result says "turned +44.0, wanted +45" (not "-46") for a 45° turn.
    - The test generator: gaps 20-40 mm and angles 15-40° (training's range; past 45° a wrong-way turn would score as
      right); "it" only after a step on that cube alone; no "Move the X so it is..." wording; each task drawn on its
      own; its twin check on starts of its own (not the twin test's); a training task in substance (or in all but
      its colours) is refused; the seed isn't written in the scratch file; `made:` records the twin check and commit.
    - A deleted or replaced test run's line goes in `Recycle_Bin\Test_private\deletions_log.txt`, not the top one.
    - Cube calibration: the typical error leaves out the looks back at the first spot (each had a twin in the fit,
      so it read low); the check after you take over allows for the gripper's offset (it was never trusted, so
      every take-over paused again); a run whose slip check couldn't be judged says so.
    - The Dobot: a read that isn't answered is asked once more (a move never is), and a position request with no
      answer says so instead of "'NoneType' object has no attribute 'params'".
  - **Hardware limits recorded:** the change ledger (`study/CHANGES_TEMPLATE.csv`) has a `hardware_limit` column (the limit a compensation targets: camera angle or position noise, the arm's repeatability or reach, the gripper's slop, the serial link, the table's slope, light, or none); `study/HARDWARE_TEMPLATE.csv` records the hardware the same way at the start of each study (Verify, Pick test, the still cube's angle spread, the touches' slope; unanswered moves and alarms per 100 moves). RUNBOOK, MEASURES (B7), PREREG §7 and the round prompt follow.
- **Continuous calibration** (Dr. Curry's "cruise control"): a new Calibration style, *Continuous (keeps itself
  calibrated)*. It keeps the calibration in use (the cube calibration's) right while the app works:
  - Every 10 s, while the arm is idle, the camera finds the A4 sheet's corners in its own coordinates and measures
    them through the calibration, against where they were when it started. It also matches the still background
    (not the sheet) with the picture taken then.
  - Nothing is done on one look: 4 of the last 6 must agree.
  - The camera moved (the background with the sheet, or the sheet's distance alone): the calibration is corrected
    by the turn and shift that put the corners back, at most 2 mm / 0.3° at a time. A correction is kept only if
    the next 3 looks find the sheet closer; otherwise it goes back to the last good calibration.
  - The sheet moved alone: it says so and corrects nothing. More than 10 mm / 3° in all from the start: it stops
    and asks for a calibration with the cube.
  - Corrections are saved in place with everything the cube calibration measured (the wrist, the gripper offset,
    the lens correction); the calibration it started from is kept in Earlier calibrations. Every look goes to
    `calibration_continuous_log.jsonl`. It carries on after the app is opened again, and a new calibration made
    any other way ends it.
  - It doesn't look during a watcher run (corrections only between runs), and each run's record and report has
    the calibration in use and what the continuous calibration has done.
  - The demo's twin works it out from where its camera really is (its sheet isn't in its pictures): press *Bump
    camera* to see it follow. Code: `app/calibration/continuous.py`, `app/ui/continuous_monitor.py`.
  - The camera's own depth calibration (its left and right images) can't be redone from the app: Orbbec offers no
    way to.
- **The angle check after a lost cube.** When a step after the cube calibration lost the cube (a take-back missed,
  a move refused), the Fingers angle check, Rotation pick test and Pick test ended at once and said why only at the
  foot of the column. Now they are greyed out (their tooltips say why), and **Cube back in the gripper -
  continue** appears. Grip the cube again on the Manual tab and press it, and they run again.
- **The Fingers angle check: Full (20) or Quick (10).** A choice beside the button. Full is every angle (−40° to
  +40°) from below and from above at 2 places, as before (about 7 minutes). Quick is the same at 1 place (about 3.5
  minutes): still enough to be trusted (at least 6 at 3 angles from both sides), with room for a missed look.
- **The Detection window has the camera's exposure.** You can choose automatic exposure or a fixed one, adjust the
  fixed value there, or use **Fix it where it is now**. Choosing **Coloured cubes only** while automatic exposure is on
  offers to fix it: automatic exposure washed a red cube out to pink on the black cloth, and the colour finder lost
  it. It is the same setting as Camera setup's, kept in the same place (config.yaml `camera: controls`), and it
  isn't changed while Camera setup is locked for the study.
- **6 touch points for the table, and each touch can be taken away.** The cube box has a touch point choice and
  **Go above it**, which takes the open gripper 20 mm above the point. The six points are 1 the middle, 2 stretched
  out, 3 left, 4 right, and 5 and 6 the sheet's near corners. You jog it down and press Fingertips on the table, and it
  then offers the next point. With all 6 the height is learnt over the whole sheet, with the reach and from side to
  side, with touches to spare. Each touch is listed with how far it is from the others' fit, with its own **Remove**
  button; Forget touches still clears them all. With 6 or more, one that is over 1 mm off while the others agree is
  marked "check this one". Two touches, one a little off, had given a 2.7 mm per 100 mm slope, and the calibration
  failed just over its limit.
- **A one-line verdict under the touch points**, once all 6 are touched: ✓ good (within 0.5 mm), ⚠ usable (for
  example "T4 is 1.4 mm off; redo it for best results", or a steep slope), or ✕ redo ("Redo T3: it is 4.2 mm off the
  others").
- **Taking the cube back during the cube calibration: aimed sooner, and slower at the end.** At the lab a finger came
  down on the cube at spot 3, knocked it along the fingers, and every spot after it was held 1.8 mm off-centre (the
  slip check caught it). A 25 mm cube in the Dobot's 27.5 mm fingers has only 1.25 mm each side.
  - The fingers go where the camera sees the cube from spot 4 on (the fit of 3 earlier spots, if it is good to
    1.5 mm), across the fingers only: only there can a finger land on the cube. Along them it is taken back where
    it was let go, as before (aimed there too, an arm that lost its reach was put right by gripping the cube that
    much off, and nothing showed it).
  - The last 15 mm down go at 20 mm/s, as picks do, so a finger that meets the cube's edge slides round it rather
    than knocking it.
  - The closing squeeze centres the cube across the fingers; along them its place is tracked (below).
- **The camera tracks where the cube sits in the fingers** (the cube calibration). The calibration took the cube to
  sit in the same place in the fingers at every spot, but the fingers centre it only across them, not along them.
  Knocked once, it was held 1-3 mm further along from then on: the spots after it disagreed with the ones before,
  and the run failed. Now:
  - Every take-back's place is kept. With the camera's look just before it, that says where the cube then sits
    along the fingers, and so where it lands at the next spot. A fit that follows this ("the cube tracked in the
    fingers") is tried beside the usual one. It is kept only if the place really changed (by 1 mm, or a grip was
    pushed) and it predicts the spots at least 20% better (and by 0.03 mm), so a run where nothing changed is
    solved as before. (The plain fit's rule for one more number, 0.15 mm, was made for the lab's 1.7 mm errors: in
    the twin it kept a fit 0.68 mm off the truth over the tracking's 0.19.)
  - A push the camera can't see (a finger landing on the cube as it comes down) spoils only that grip: where the
    cube sat there is measured afresh. Up to 1 grip in 6 (Precise: 4).
  - A calibration made with it keeps the whole offset of where the fingers hold the cube: across them, their
    middle (measured); along them, where the hand gripped it at the start (the grips before the first change).
    Every pick after holds things there.
  - In the twin, the cube knocked 2 mm along the fingers at spot 3 and 2 mm back at spot 6: tracked, 0.2 mm off.
    The twin can hold a cube off-centre along the fingers for this (`SimRobot.keeps_place_along_fingers`, off by
    default).
  - The result has a **Grip** line when the cube's place changed ("changed during the run (by up to 2.0 mm); the
    camera tracked it; 1 grip pushed as the fingers came down, measured afresh there"). The angle check and the
    pick test then go where each cube really was.
  - **The look back at the first spot still judges by where the cube was the first time**, as before. On the Dobot,
    along the fingers is straight out from the base, so a grip moved along them and an arm that lost its reach look
    the same: the tracking only says which is likelier in the message, and never lets a failed look back pass.
  - **After you take over** (gripped again by hand), the look back judges across the fingers by the strict 1.5 mm
    and the whole of it by the usual 3 mm. Your grip holds the cube elsewhere along them, and that alone had paused
    the run again ("the arm lost its place") at 1.5 mm.
  - The aiming and the look back go only by the spots seen whole and standing as tall as the others, as the final
    fit does. The look back records where the arm says it let go, as the spots do.
  - A pause for a knocked cube says what to do: grip it again where it stands, centred and about halfway down, and
    press 'Manually gripped - continue'; the spots so far are kept.
  - **The camera's steadiness is measured at spot 1:** it looks at the cube twice. More than 0.5 mm apart, the
    result says so (light, sun, a cold camera) and the run carries on.
  - **One line in app.log sums up each run** ("Cube calibration summary: ..."): spots tried, found and used; the
    looks back at the first spot (from the first time, and from where they should have landed); the fit; grips
    tracked and taken as pushed; passed or why not.
  - **What it can't see:** an arm that lost its reach (a skipped step after a knock). The next take-back grips the
    cube that much off along the fingers, so every later put-down lands where it was sent. Press Home before using
    a calibration made after a heavy knock, and Verify it.
- **The Fingers angle check writes each look to app.log** (the angle told and the angle the arm reports, the cube's
  turn as seen, how whole it was seen) and a summary (offset, gain, backlash, scatter). Its 6.6-7.6 degree scatter at
  the lab can then be traced to the camera's reading or to the wrist.
- **Found: why the Dobot didn't answer some moves (pydobot's checksum).** pydobot 1.3.2 works a message's checksum
  out with `% 255` where it must be `% 256` (marked "TODO verify this" in its code). For 2 of every 256 messages
  the checksum is then wrong, and the Dobot drops such a message without a word: a move whose bytes happen to sum
  so went unanswered every time it was sent, retries, Clear Alarms and all ("Couldn't go above touch point 6",
  22 times in five days at the lab). Found 2026-10-21 from the bytes now logged: the two moves unanswered that
  night were sent with checksums 0 and 1 where 255 and 0 were right. The app's own link (dobot_link.py) now sends
  every message with a right checksum.
- **On the real Dobot the arm gets out of the camera's way before a prompt looks**, even with no `robot: look_pose`
  set: it goes to where the cube calibration waits (the robot's left, about (110, 225), 11 cm above the table).
  Without one it stayed where it had just put a cube down, above it, and the next prompt's look didn't see the cube
  ("the blue cube is not visible"; the lab, 2026-10-22). A `look_pose` in config.yaml is still used first.

- **The step-by-step guide has the Fingers angle check.** Step 6 is now "Then, with the cube still held (in this
  order)": the Pick test, the **Fingers angle check** (Quick or Full: what it does, how long, that it needs the cube
  still held -- don't Finish first), the Rotation pick test, Add cubes, Finish and Verify. It also says to run
  Quick once more after the first calibration on a new setup (its spots stay near where the cube was gripped). Steps
  1-4 now say: 0.2 mm jog steps for the last millimetre of a touch, what Good/Usable/Redo mean (0.3-0.8 mm is
  normal; a slope is followed), centre the cube along the fingers, the slow last 15 mm and the aiming across the
  fingers, and the "knocked" and "did not acknowledge" messages. The paper guide: the 6 touch points, and a step 5
  with the same steps after the run.

- **A colour a letter off is still that colour.** "Pick up the bllue cube and put it right of the green cube" was
  refused as naming only the green one. Blue, green, yellow, purple, orange, black, white and brown are now
  recognised a letter off ("bllue", "gren", "yelow"); not pink, teal or grey, which "pick", "tell" and "tray"
  are a letter off, and never the app's own words (tray, block, back...).
- **A pick goes by the average of the camera's angle readings.** The real camera's reading of a still cube's turn
  wanders 8-10 degrees, and "pick up the blue cube" was refused ("kept changing, by up to 5 degrees over 8
  pictures"). Now the pick goes ahead when the readings' average is known to 1.25 degrees (none more than 8 off it):
  a 25 mm cube in the Dobot's 27.5 mm fingers fits about 6. Readings that really disagree are still refused.
- **The calibration's look during the run allows for the gripper's offset**, as its final fit does: the Dobot's
  fingers' middle is 7.2 mm off the tool point, and without it the turn from spot to spot read as the cube having
  moved (in the twin a 3 mm offset paused a run, "knocked", with nothing knocked).

- **No detection boxes on the live feed until the camera is calibrated.** Without a calibration the detector can't
  tell the table from what stands on it: it boxed the arm, the printed sheet's edges and the grey sheet itself ("white
  bar", "grey block"... dozens of them). The feed now says "Not calibrated yet: objects are shown once the camera
  is calibrated" instead. The demo, calibrated by the twin, is as before.

- **Touches that agree on a sloping plane are believed.** 6 touches within 0.6 mm of one plane, 7.0 mm per 100 mm
  out of level (the arm's own heights, more likely than the table), were refused as "too steep" (the limit was 6
  mm per 100 mm, for a touch pressed into the table or missed). With 4 or more touches that agree to 1.5 mm, up to
  12 mm per 100 mm is now usable (the put-downs follow the plane); 2 or 3 touches keep the 6 mm limit. Steeper, or
  agreeing on too steep a plane, the message says so (press Home) instead of "they disagree too much".

- **The cube calibration's aiming and its "knocked" pause wait for enough spots.** At the lab (2026-10-21) the run
  paused twice, "3.5 mm" and "3.4 mm from where it should have landed", when its own looks put the cube 1.1 and
  1.0 mm from there: the fits made from 3 spots (and a scale), and the tracking from 5 (one just gripped by hand),
  couldn't tell. Now the take-backs aim from 5 spots (as before 2026-10-20), a scale from 8, the tracking from 8,
  and a knock pauses the run only from 6. After a take-over, the look back judges across the fingers from 3 spots
  (it needs only the camera's turn).

- **A move the Dobot doesn't answer: its command queue started afresh.** The lab logged 22 in five days. The same
  move went unanswered again and again, the jog's too ("Couldn't go above touch point 3"), with no alarm, while
  status requests were answered. That fits a stopped or full command queue, and Clear Alarms, which restarts the
  queue, had put it right. Now the second retry stops, clears and restarts the queue, sets the speed again, and sends
  the move a last time. The error also says which it was: no reply at all, or a reply without a queue number.
  - **Since 2026-10-21 the restart is what Clear Alarms does** (stop, clear the queue, clear alarms, start), not
    stop and start alone. At the lab the move down to touch point 6 went unanswered three times (no alarm showing,
    everything else answered); stopping and starting hadn't helped, the button had. A test at the lab the same day
    (303 messages, 25 moves, 16 straight after a gripper command) answered every one in 0.12 s: it doesn't come from
    the link, nor from the gripper alone.
  - What was sent goes in the log with each unanswered move (its bytes), and any bytes the Dobot sends that nobody
    was waiting for (a reply too late) are logged, not silently dropped: the next time shows why.
  - Unanswered three times, it says what to do: Clear Alarms and try again; if it keeps happening, switch the Dobot
    off and on and Home.
- **Earlier calibrations can be deleted** (Earlier calibrations / reset...): **Delete the one chosen** or **Delete all
  earlier ones**. They go to the Windows Recycle Bin, so they can be put back; the one in use isn't touched.
- **The cube calibration's spots stay where the table was touched**, up to 4 cm past the touches. Every spot's height
  is then measured, not guessed. At the lab a spot at (150, 230), 120 mm past the touches and at the edge of the
  camera's view, landed crooked and the fingers came down on it. **The first spot is where the cube was gripped**, so
  the first put-down goes back onto the paper's centre.
- **The gripper's offset is measured afresh by every cube calibration**, never built on an earlier one. A shaky
  7-spot run's (-8.8, 3.7) mm had been carried into every calibration after it, and every put-down and pick landed
  off by it.
- **Camera setup shows only what's needed until "Show advanced"** (remembered). Shown: Height, Tilt, Cube size, Cube
  top read, Top points, Saturation, Warm-up; Exposure and Depth exposure; Find best exposure, Save reference, Lock for
  study, Start calibration. Hidden until then: Edge margin, Clipped pixels, Noise, Shake; Gain, White balance,
  Projector power, Anti-flicker; the Depth preset and Detection comparisons; Camera capabilities, Shake test, Mount
  mode. Hidden ones still apply, are saved and are recorded, and one out of target is still named in the verdict.
- **US Letter sheets.** `config.yaml` `study: paper: letter` (or `a4`): the lab's printers hold US Letter, and an
  A4 page printed on it measured 278 x 216 mm, so Find the paper refused it. The spots and the centre stay at the same
  robot positions, which fit on Letter with room (all 20 training tasks check fine on it). `python study/sheet.py`
  writes `study/Letter_sheet.pdf`; `--paper a4` writes the A4 one.
- **The depth sensor's own exposure** (Camera setup: "Depth (infrared) exposure", with its automatic box). Left
  automatic, it overexposed the white sheet on the dark mat: the sheet read 12 mm (up to 26 mm) above the mat, with
  depth on only 45% of it, and phantom white "objects" stood on it. Fixed at 1200 it reads flat (+1.6 mm) and whole.
  The lab's settings are now colour exposure 65, projector power 4, depth exposure 1200 (fixed).
- **Find best exposure ignores black, grey and white things.** A laptop, a mouse and the arm's black parts stood up
  from the table too. They were counted as cubes, so every exposure scored below zero and the darkest one was kept.
- **Find best exposure keeps room for the light to change** (2026-10-21). It kept the darkest exposure that scored:
  at the lab 24, the blue cube's top at 98 of 255 (and too dark, the camera's noise read as the strongest colour:
  it even scored an exposure that didn't see the cube). Now colour that dark isn't trusted, and of the exposures
  within 10% of the best it keeps the one with the cubes nearest mid brightness (170): 52 there. The lab's
  settings are now colour exposure 50, depth exposure 1200, projector power 4 (a sweep the same day: depth on all
  of the mat from 500 to 3000, noise 0.5 mm either way). Twenty looks at the still cube: its centre steady to 0.13 mm,
  its angle as read by Camera setup spread over 7.6 degrees -- the size of the Fingers angle check's scatter.
- **Camera setup's cube readings judge the coloured cubes only** (when any are seen). The gripper standing low in
  the picture was found as a black and a grey "cube" (a 3 x 17 mm top, 72 depth points), and as the weakest cube
  it turned Saturation, Cube top read and Top points red beside a blue cube that met them all. The cubes line says
  how many such black or grey things were left out; with nothing coloured seen, all are judged as before.
- **Camera setup no longer expects 3 cubes.** One cube of any colour is enough to calibrate, but with only one on
  the table it said "Only 1 of the 3 cubes seen" and stayed Not ready. Cubes on the table is now "not set" (any
  number) unless you set it, for when you want all of them checked.
- **What a step says is shown by its buttons** (in the cube and continuous boxes), as well as at the foot of the
  column. After a cube calibration, the next steps it lists start with the Fingers angle check.
- **"Paper not found" says why when the sheet measures bigger than A4:** tape over its edges or corners, or the
  arm or something white touching it.
- **RUNBOOK:** the simple way to lay the sheet. Rough is fine: tape it underneath, calibrate with the cube, then
  Find the paper. The spots follow it.

## V3.9 (2026-10-13): study design

- Follows V3.8 (git tag `v3.8`; frozen copy in the `Kyozo_Link_V3.8` folder and `Kyozo_Link_V3.8.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v3.9`, the `Kyozo_Link_V3.9` folder and
  `Kyozo_Link_V3.9.zip`.
- **Watcher: choose the runs.** The Session plan tab, before Start session, lists the set's tasks with tick boxes (a
  level at once, Tick all / Untick all), **Times each** (1-10), **In rounds / Back to back**, and **New / Same
  start**. Real sessions allow it too, but warn when a ticked task already has saved runs in that study. The unseen
  test's tasks are listed by id and level, with the prompts hidden, unless you turn on **Show test prompts**. That
  switch shows them with a red "don't share screenshots" warning, and it turns off again whenever the window closes. During a session, **Run this task again** and a
  right-click on the plan (again next / at the end) add a run of any task. **Double-click a task** in the plan to
  load it into a bar above the list (a test prompt is hidden unless Show test prompts is on), then **Run this task
  now**. With no session running, it starts a session of just that task, once. During a session, it adds the task as
  the next run (asked first in a real session). Either way it is scored and saved like any run. What was chosen is recorded in session.json
  (`plan_choice`), the session summary and the index (`added_run`).
- **Watcher: save under any number.** The Save dialog lists the task's saved runs and starts at the next free number.
  You can pick any number or your own tag. A number already saved replaces that run, after a warning, and a real run
  needs a reason.
- **Watcher: Run by itself (the twin only).** A switch next to Start run, shown in Demo mode only (never on the real
  Dobot). Each run starts when the table is READY, the twin scores it itself (Skip; note "ran by itself (no person
  watching)") and it is saved under the next free number, then the next run. It pauses for you on a run that can't be
  scored, a table not READY in 60 s, 2 infrastructure failures in a row, or E-STOP. Untick it to take over. The runs
  are marked `unattended` in run.json and `ran_by_itself` in the index, and the session summary counts them.
- **Cross-study report** (`watcher/overview.py`), in its own folder, `Kyozo_Link_Results\Study_Overview_private`
  (practice: `Practice_Session\Study_Overview_private`). It contains CROSS_STUDY_REPORT.md / .html,
  cross_study.json and cross_study.xlsx. Sections:
  - the main claim: the Dobot's unseen test, study 1 → 2 → 3, and task by task paired study 3 vs 1;
  - all four kinds per study;
  - the hardware gap (twin − Dobot);
  - results by level, failure types and every task across the studies;
  - bookkeeping: discarded/replaced runs and runs by itself.
  The measure is unassisted passes, without infrastructure repeats. It is remade after every Save, at every session's
  end and by Rebuild reports…, or with `python -m watcher.overview [--practice]`. It is private (it holds the test's
  results) and shows the test tasks by id and level only.
- **The test-set generator** (`study/make_test_tasks.py`; the watcher's **Test tasks… → Make test tasks…** runs it
  in a process of its own, the seed typed hidden twice and passed on its input). It makes 20 tasks from your secret
  seed, T-n mirroring TR-n's level and steps, with its own cubes, spots, distances (20–60 mm), sides, angles, gaps
  and wording.
  - Every task is on the A4 sheet: no stacking, every moved cube ends on the paper and within reach.
  - Every task can be done with today's tools by a known recipe. The optional twin check runs each recipe in the twin
    from both starts and redraws tasks that fail.
  - Every task passes `study/check_tasks.py`.
  - It writes `Test_Tasks_private\test.yaml` and `test_tasks.md / .html` to read. It prints and logs task ids only:
    the app's own logging is silenced while it runs.
  - It keeps an earlier set as `test_OLD_<date>.yaml`, retires a set in the old places (`test_RETIRED_<date>.yaml`),
    and refuses once a real test run is saved.
  - The watcher now reads only `Test_Tasks_private\test.yaml`. The old 16-task places are no longer read.
  - **Making them in the watcher:** the Session plan tab has a **Make test tasks…** button. While it works, a
    progress panel shows:
    - a bar and "N of 20 ready";
    - the task the twin is checking, by id and level only;
    - the time left;
    - **Stop**, which writes nothing.
    The list fills with the 20 tasks when they're done.
  - ROUND_PROMPT adds the generator and `Recycle_Bin\Test_private` to what the update session never reads.
- **Review fixes (2026-10-13), calibration:**
  - **The paper's pose is kept per calibration file** (`calibration.json` → `calibration_paper.json`), so the demo's
    twin sheet is never taken for the real one. The old shared `paper.json` is ignored: find the paper again.
  - **One thing moves the arm at a time** (`MainWindow.arm_busy`). A calibration step, a prompt, click-to-move, the
    Manual tab and the watcher's start each refuse while another moves the arm. E-STOP always works.
  - **Cube calibration:**
    - Paused or stopped as it finished solving, the robot keeps the gripper offset it had.
    - Enough distinct spots must remain once odd, hidden or off-centre ones are left out. Leaving one out no longer
      raises.
    - A paper run resumed after a restart stays a paper run.
    - "Save it anyway" survives a No.
    - Finish stays offered if the cube couldn't be put down.
    - The paper buttons are only enabled when they make sense, and "Put it back down" only goes straight down.
  - **Camera setup:**
    - Esc can't close it mid-action.
    - Exposure changes wait while a calibration uses the camera.
    - The main window can't close under a Camera setup action or a calibration step.
  - **Smaller fixes:**
    - "Remember this view" says when it fails.
    - The Earlier calibrations dialog refreshes the buttons.
    - Going back to an earlier calibration is checked first and written atomically.
- **Review fixes (2026-10-13), watcher:**
  - **Nothing of a test task is left on screen.** When a session ends, the judge box and the score line are cleared.
    With Show test prompts off, the task line, the judge box, where each cube ended and the run log's step details
    are hidden too (on the Dobot, turn it on to judge).
  - **Near-miss swaps are "execution" failures, not "plan".** A cube on the other's start spot, or on a spot the task
    names, no longer counts as "a zone the task never mentions".
  - **Deleting Recycle_Bin (or Recycle_Bin\Test_private) needs a reason** and is logged once it holds real runs.
    A replaced run's move is written to the index before the new run is saved.
  - **The test generator** never draws the template's example, so a finished set is no longer refused at the end.
    `study/twin_test.py --set test` silences the app's log lines.
  - **E-STOP from the main window pauses Run by itself.** A run with an E-STOP is never auto-judged. Ticking Run by
    itself restarts its 60 s table wait.
  - **Small fixes:**
    - A refused start (table height unknown) no longer leaves a plan that stops the tick boxes working.
    - No session starts while the test tasks are being made.
    - A level filter whose level isn't in the plan falls back to All levels.
    - The loaded bar says when its task isn't in the running session.
    - Ending a session in setup marks that run "Not run".
    - The finished summary doesn't count infrastructure repeats as failures.
- **Recycle_Bin in Kyozo_Link_Results.** Replaced and discarded runs move there whole (evidence, .md, web page), with
  `why.txt`, at the same path as their kind folder. A test run's go under `Recycle_Bin\Test_private` (private, like the
  other test folders). Real ones are logged in `deletions_log.txt`, and FULL_REPORT lists "Discarded and replaced
  runs". Delete results… still uses the Windows Recycle Bin for whole folders.

## V3.8 (2026-10-13)

- Follows V3.7 (git tag `v3.7`; frozen copy in the `Kyozo_Link_V3.7` folder and `Kyozo_Link_V3.7.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v3.8`, the `Kyozo_Link_V3.8` folder and
  `Kyozo_Link_V3.8.zip`.
- **The watcher** (`watcher/`, the Watcher toolbar button, its own window) for Dr. Curry's GECA 2027 study "Closing
  the Loop": runs the study's fixed tasks on the Dobot or in the twin with nobody typing, and saves every run as it
  happens: ghost outlines of each cube's place, the table check, the run, the observer's verdict before the score,
  its own cube finder and scorer, failure types (PREREG 5.2), motion, picks, alarms, model turns and time split.
  Save / Discard (with a run tag), a "Practice session" toggle, a session plan by difficulty level (test sessions
  hide the prompts), a walk-through. Results go to `Kyozo_Link_Results` (`study_1..3\{Twin,Dobot}_{Training,Test}_Data`).
- **Study design:** 3 studies, 2 updates; 20 training tasks in 5 levels (`study/tasks/train.yaml`); the test set is
  written privately and never seen by Claude; Claude's package (paired twin + Dobot training, never a test result).
  PREREG, RUNBOOK, ROUND_PROMPT and MEASURES rewritten; `study/twin_test.py`, `study/check_tasks.py`.
- **The A4 sheet** (`study/sheet.py` -> `study/A4_sheet.pdf`, geometry in `app/vision/paper.py`): taped to the cloth,
  centre (225, 0), 4 corner spots printed 25 mm and turned by the arm's angle there. Each run starts from a seeded,
  task-safe arrangement (`watcher/arrange.py`), the same in the twin and on the Dobot. Calibration tab: *Cube
  calibration with paper*; the watcher's *Find the paper* (paper.json). "Towards/away from the robot" is scored along
  the sheet's arrow (x), as the app moves; `check_tasks.py` refuses radial targets.
- **Reports:** per run run_report.txt, model_log.html/.txt, moves.csv / gripper.csv; per session FULL_REPORT.md/.html,
  full_report.json, results.xlsx and .csv files, remade after every run (*Rebuild reports…*).
- **Camera setup** window (live readings against targets, picture settings on the Gemini 335, depth preset and
  detection comparisons, Mount mode); gripper-angle and cube-calibration fixes (pass limit 2.0 mm, *Save it anyway*).
- **App:** a saved place is never an object ("on spot 3" = place_at); spots are markings, never obstacles; robots
  report moves, gripper, alarms, E-STOP, no_answer and status_lost to watchers; a fixed Qwen seed (`llm.seed`).

## V3.7 (2026-10-09)

- Follows V3.6 (git tag `v3.6`; frozen copy in the `Kyozo_Link_V3.6` folder and `Kyozo_Link_V3.6.zip` next to this
  one). Developed in the `Kyozo_Link` folder; frozen as git tag `v3.7`, the `Kyozo_Link_V3.7` folder and
  `Kyozo_Link_V3.7.zip`.
- **Depth preset** (Settings > Camera: *Default* or *High Accuracy*; `camera: depth_preset` in config.yaml, Default
  to start). Loaded before the camera streams, when it connects: the Gemini 335 only takes a preset while it isn't
  streaming, which is why the switch to High Accuracy at the start of a cube calibration always failed (it is gone).
  Changing it while the app runs stops the streams, loads it and starts them again (a few seconds; the feed keeps
  its last picture meanwhile); if the camera won't, it is closed and reopened with it; if that fails too, it goes
  back to the old preset and says so. Locked while a prompt, a calibration step or an arm move is running. Live
  mode now has a Settings button too (just the camera). Every calibration records the preset it was made with; a
  different one now is reported (log, status bar): switch back or recalibrate.
- **Fingers angle check** (Calibration tab, after a cube calibration, the cube still held): the cube is put down
  with the wrist at -40, -20, 0, +20 and +40° from its middle, at 2 places, coming to each angle once from below
  and once from above (20 put-downs). The camera sees which way the cube's sides lie (the fingers squeezed it square
  to them), which is where the wrist really was. Fitted: **offset** (a turn left over), **gain** (the wrist turns
  that many times what it is told), **backlash** (slack in its gears) and **scatter** (repeatability). Saved with
  the calibration (also kept by *Add 1 / 2 cubes*). Not used if implausible (gain outside 0.85-1.15, backlash over
  8°, offset over 15°), if it scatters over 1.5°, or if the calibration's fingers' angle changed since.
- **Every pick** (two-finger gripper): the wrist is told the angle that makes the fingers really point where the
  pick wants them (the check's model; without one, the fingers' angle from the calibration as before, and the log
  says so); it always comes to that angle from the same side (4° below it first: `wrist_approach`,
  `wrist_overshoot_deg`), so the backlash is the same every time; the last 15 mm down is slow (20 mm/s:
  `slow_last_mm`, `slow_speed_mm_s`; all under `robot: gripper:`). The object's turn is read from 4 pictures; if
  they disagree by over 3° it looks again, and if they still do the pick is refused, saying why.
- **Rotation pick test** (Calibration tab): the cube put down turned at random 6 times, found, picked as prompts
  pick, and let go again without turning; how far it turned in between is how far the fingers were off its sides.
  Average, worst, spread, misses, and the error by the side the wrist came from. *correction on / off* to compare.
- **Model tab:** a *Fingers and wrist* box above the prompts: the check's offset, gain, backlash, scatter, when, the
  cube size and depth preset, whether picks use it, the last rotation pick test, and a small plot of the put-downs.
  Each pick's record says how its angle was read and what the wrist was told.
- **Learn cube calibration (demo, Calibration tab, top of "With a cube"):** a walk-through of the whole cube
  calibration on the demo. Choose a **20 mm** cube (forgiving: it fits the 27.5 mm gripper turned up to ~31°) or
  **25 mm** (as at the lab: 1.25 mm of room each side, ~6°), **Like the lab** (the camera's noise; a gripper 3°
  turned, a wrist 5% short with 2° of slack) and the arm's speed. Start sets out one cube on an empty table.
  11 steps, each with what to do, why, the button (highlighted) and what a good result looks like: Home, touch the
  table stretched out, touch it beside the cube, wrist to middle, grip, calibrate, pick test, fingers angle check,
  rotation pick test off then on, finish. **Watch:** the demo does each step itself with the normal buttons ("Do
  this step", "Run to the end", "Repeat the last step"). **Practise:** you do them (Manual tab, Calibration tab)
  and the panel ticks each step when it is right, or says what isn't (a touch that didn't reach the table, the
  wrist not in its middle, with 25 mm the gripper too far off the cube's middle, a grip that closed on nothing...).
  **Exit** puts back the scene, the camera, the wrist, the speed and the calibration in use before.
- **Demo, Calibration tab:** opening it sets out the cube calibration's table, one cube of the size chosen in the
  walk-through (20 or 25 mm; choosing the other size swaps it). The scene that was there is remembered, and the
  Prompt tab puts it back, unless a calibration is under way (the table touched, the cube held, a step running, the
  walk-through). The Manual tab leaves the cube, since that is where the arm is jogged while calibrating.
- **Demo, Calibration tab picture:** the printed calibration marker (the black-and-white card) is no longer drawn on
  the twin's tool. The simulated camera still sees it, so the demo's automatic calibration with a marker works.
- **Demo:** the simulated arm can have a gripper mounted turned, a wrist that turns short and gears with slack
  (`SimRobot.fingers_turned_deg`, `wrist_gain`, `wrist_backlash_deg`); the simulated camera has the depth preset
  too. Tested with 3°, 5 % short and 2°: the check finds them within 0.5°, 0.01 and 0.5°, and the rotation pick
  test's average error drops from over 1° to under 0.6°.

## V3.6 (2026-10-08)

- Follows V3.5 (git tag `v3.5`; frozen copy in the `Kyozo_Link_V3.5` folder next to this one). Developed in the
  `Kyozo_Link` folder; frozen as git tag `v3.6`, the `Kyozo_Link_V3.6` folder and `Kyozo_Link_V3.6.zip`.
- The hardware launcher is now `Run Kyozo Link.bat` (was `Run Dobot Vision Task.bat`).
- **Calibrate with a cube** (Calibration tab, style "with a cube"): a third way, with no marker and no table step,
  measured where objects are picked. The marker sits ~150 mm above the fingertips, so a small tilt in its
  calibration was a sideways miss at the table (1 degree ~ 2.6 mm). At the lab: 0.62-0.76 mm typical (Fast).
  - **Before:** press Home; touch the table with the fingertips at 2-3 places (stretched out, to one side, beside
    the cube; *Fingertips on the table*, listed as T1, T2... and marked on the picture). The cube is let go 0.5 mm
    above the table wherever it is, by the height the touches give (the Dobot stands 2-3 mm higher stretched out).
    An **arm check** says if the arm wasn't homed, or the table reads very differently near and far or than at the
    last calibration (the lab: z -51.4 one day, 2.2 the next, not homed). *Wrist to middle*, then grip the cube.
  - **The run:** Precise 20 spots, Quick 10, Fast 6; the wrist stays in its middle; half speed. The cube is centred
    in the fingers (a squeeze in place), put down at each spot, found by the camera against the empty table, and
    taken back by the robot's own coordinates; if the camera saw it turn or move as it dropped, the wrist turns and
    the arm moves to match, and with no room for the fingers (a 25 mm cube in 27.5 mm) it waits above it and asks
    you. After each pick-up the camera checks the cube came up. Every 5 spots and at the end the cube goes back to
    the first spot seen whole: over 3 mm from the first time, the arm lost its place (press Home) and the spots
    since are done again.
  - **Take over:** *Pause - I'll take over* stops after the current move; the robot also pauses when it needs a
    hand. Grip the cube by hand wherever it is and press *Manually gripped - continue*: the camera and the arm are
    checked, then it carries on. Progress is saved after every spot (it survives closing the app); *Start over*
    throws it away.
  - **The solve:** the table's surface (thousands of depth points) gives the camera's tilt and height; the spots
    give the rest. Tried and kept only if each spot, predicted from the others, comes out better: a scale, the
    gripper's offset from the tool point (the robot then moves by it), the depth sensor's own picture, a correction
    over the table (Precise). A spot that disagrees is left out (two from 10 up). Also measured: the fingers' real
    angle (allowed for on every pick).
  - **After:** *Pick test* (3 new spots, picked from where the camera says); *Add 1 / 2 cubes* for the heights.
  - Every calibration is kept: *Earlier calibrations / reset...* goes back to one of the last 10, or clears it.
- **The Calibration tab** shows one style at a time (*Calibration style*), with a step-by-step guide; it no longer
  runs past the window at 150% scaling.
- **The lens's bend is taken out of the real camera's pictures** as they come in (`camera.undistort`, on by default).
- The real camera says how long it has been on: calibrating in its first 15 minutes asks first.
- **Verify is stricter:** Good under 1.5 mm typical (was 3), Usable under 3 (was 6), and says when the misses lean
  one way rather than scatter.
- **Prompts:** objects of a known size (`vision.known_sizes_mm`, cube: 25) are taken to be that size when measured
  near it (the camera read 25 mm cubes as 20-30 mm, and called one too wide); *turn_object* turns the object held
  and matches another's angle (*like_id*); a reply saying something was turned when nothing was is sent back; a
  *Try:* example lines up the red, green and blue cubes with a gap you type.
- A Dobot move that gets no answer is sent again; the demo's fingers square a cube up as real ones do.
- **Docs:** flowcharts S0-S4 in `docs/flowcharts` (S4: the AI agent in detail) as PDF, SVG, HTML and diagrams.net;
  a summary for supervisors in `docs/Kyozo_Link_summary.md`.
- Demo: a scene "One cube, for calibrating"; *Add 1 cube* / *Add 2 cubes* bring blue and green ones.

## V3.5 (2026-10-03): towers as asked, a camera that holds up to noise and never loses what it put down

- Follows V3.4 (git tag `v3.4`; frozen copy in the `Kyozo_Link_V3.4` folder next to this one). Frozen copy:
  `Kyozo_Link_V3.5` (folder and zip) next to this one; git tag `v3.5`.
- The open Model list has a heading row: Model, Good for, Speed, Planning (the dots alone didn't say which was which).
  It isn't a row of the list, so it can't be picked.
- **Towers with places asked for** are worked out by the app before anything is built (app/llm/tower_plan.py): "red
  at the bottom and purple at the third", "the green one at the third position from bottom", "yellow second from the
  top", "green in the middle", "blue on top"; "a tower" or "all the cubes" means every one. A build_tower call that
  doesn't match is refused with the order to send (the cubes not placed keep the AI's order), and one that can't be
  built ("purple sixth" with five cubes, two cubes asked for the same place) is said so. Before, "purple at the third"
  was read as "purple second", "green third" wasn't seen, and both towers were built wrong (3 and 4 of 5 cubes).
- **The depth detector holds up to a real camera's noise** (the demo's "Realistic" and "Poor" pictures): one cube was
  seen as two or three things ("a purple bar", "a purple cylinder", "a purple ball"), and the arm went for the pieces.
  Heights are smoothed (a median, which drops wild pixels) before the tops are found; a top is split only where its
  height really steps (not into fixed 6 mm levels, which cut a 21 mm cube in two); pieces of one colour at one level
  that touch, or have only a hole in the depth picture between them, are one object; and the round-or-not test looks
  at the top's corners, by its level. Measured on every demo scene, both robots: extra objects per 20 looks went from
  34-37 (Realistic) and 69-70 (Poor) to 0-2; all objects named exactly right went from 0-1 to 8-12 of 20 looks on
  Realistic (the rest: a cube named a cylinder or a block); Perfect stays 20 of 20. Under "Poor" shapes are still
  often wrong.
- **The xArm's demo camera is placed for the xArm, with the real camera's lens**: the Orbbec Gemini 335's field of
  view (55 degrees top to bottom, 86 across: its colour camera's, the narrower of its two), 560 mm up, to the right of
  its working area, some 60 degrees above the table (`demo_camera` and `demo_camera_fov_deg` in its profile). It sees
  all of the demo scenes' area: the Dobot's camera moved out for it saw 80%, and a cube lined up at y -230 went out of
  its picture. Measured: 15/15 looks exactly right on a Perfect picture, 11/15 on Realistic. The Dobot's bench camera
  stays as it was (38 degrees): with the wider lens from the same place each object was a third smaller in the
  picture, a 24 mm can measured 21.8 mm and the calibration found 7 of its 8 marker points.
- **Nothing is put where the camera can't see it**: free spots, rows and every put-down are checked against the
  camera's picture (the whole object, foot and top, clear of its edges), besides the arm's reach; a row also leaves
  room for the open fingers next to what stands near it. An object seen before and not now is listed under
  `not_seen_now`, with why (out of the camera's view there, or no longer seen where it was), and the AI says so
  instead of "there is no red cube"; one cut by the picture's edge is listed as only partly seen.
- **No "done" that isn't**: when the AI replies that it has finished and the app's own check says otherwise (a tower
  still standing, the tray not empty, a tower not as asked...), the AI is sent back once with what the check found
  ("Not done yet: still in a pile: ..."); a reply that says what couldn't be done, or asks you something, isn't.
  "Dismantle the tower" ended with "The tower is dismantled" and the tower still there.
- Tools that move named objects (pick, build_tower, turn_object, put_all_in, line_up, move_object, take_apart,
  place_between, swap) look at the table themselves when the request hasn't yet, and carry on, instead of refusing
  ("Call list_objects first" made the small model look, and then stop).
- The Prompt tab's conversation has a **Show refused steps** switch (hide the amber "Step refused" lines; the app's
  "Note:" lines under a reply always show) and a **Clear** button (the Log tab keeps everything).
- The status bar says when the demo's camera isn't perfect: "Camera: Connected (demo) · picture: Poor · bumped" (the
  setting isn't kept, so after a restart the cause of odd sightings was gone without a trace).
- **Towers on free table, and moved**: build_tower takes `where` (outside, center, left, right, near_base, far) as
  well as a saved place, and takes the objects off any pile they are in first, so "the tower should be outside of the
  tray" is one call (what is already right stays; a tower already built as asked is left alone). "Outside (of) the
  tray", "not in the tray" and "away from the tray" are refused for the tray itself. Before, "a tower with the cubes
  outside of the tray" was built IN the tray (the AI had no way to say free table), and moving it out was done by
  hand, one cube at a time.

## V3.4 (2026-10-03): more ways to ask, each step checked against the request, much faster answers

- Follows V3.3 (git tag `v3.3`; frozen copy in the `Kyozo_Link_V3.3` folder next to this one). Frozen copy:
  `Kyozo_Link_V3.4` (folder and zip) next to this one; git tag `v3.4`.
- **More ways to ask**, each one tool call that the app works out itself (positions, order, checks), on both robots:
  - in a row: "line up the cubes", "arrange them from smallest to largest, 3 cm apart" (line_up);
  - moved by a distance: "move the red cube 5 cm to the left", "push it a bit forward" (move_object; refused, with
    what is in the way, when the spot is taken);
  - taken apart and emptied: "take the tower apart", "empty the tray" (take_apart, empty_place), top first, onto
    free table nearby;
  - between and swap: "put the green cube between the red and the blue", "swap the red and blue cubes";
  - put back / undo: "put it back", "undo that" -- back where things were before the last request that moved
    anything, a pile rebuilt from the bottom ("undo" twice redoes it);
  - "slowly" / "carefully": the arm at 40% speed for that request only;
  - "do it again" / "now the blue one": the AI is told the previous request;
  - where things are, in words: list_objects says which object is leftmost, rightmost, nearest the robot,
    farthest, in the tray, on the X ("the cube on the left", "the one nearest the robot");
  - units: "5 cm", "2 inches" are turned into mm.
- **Each step checked against the words of the request** (found by the prompt test bench, first run 32/43 with the
  Quick model): an object or place the request doesn't name, when the one it names isn't there ("the yellow cube" with
  none on the table was swapped for the red one; "in the bin" became the tray), a row in another order than named, a
  move against the direction asked ("towards the robot" went away from it), "at" an angle for "by" one (and back), a
  tower without the place named ("in the tray"), putting something back into the place it was to be taken out of, and
  a turn nobody asked for are refused with the reason, and the AI corrects itself or tells you. With all the fixes
  the bench went from 32/43 to 41/43, and the last two pass with these checks.
- "Slowly" / "carefully" / "gently": the app slows the arm down itself (the AI forgot to). A reply that ends with
  something still in the gripper (other than for "pick up") is sent back once to put it down ("take the cube out of the
  tray" was picked and left held). Objects of a kind that differ in size are listed as "small" / "large" (a 20 mm cube
  was "medium" and left out of "large cubes in the large bin").
- "Empty the tray" / "put it back" look at the table themselves if the AI didn't; tools that take objects refuse before
  anything moves if the table wasn't looked at in this request; and an object that can't be put down is put back where
  it was, not left in the gripper (it was, and every next cube was refused). The reply check also covers "empty the
  tray", "take it apart" and "take it out of the tray".
- **Much faster answers** without a graphics card: what the gripper holds and the previous request now go with the
  request, not at the end of the instructions, so the instructions and tools (about 5,300 tokens) read the same every
  time and Ollama reuses its work on them. Measured on the Quick model, CPU only: about 4 s an answer instead of about
  2 minutes (which is also why answers timed out). And the model reads them once right after it is loaded (the label
  says "loading…" until then), so the first prompt is quick too.
- The time-out message no longer tells you to pick the Quick model when it is the one in use.
- **Prompt test bench** (`python tests/prompt_bench.py`): 43 typical requests of 12 kinds run through the real
  model in the demo world, each scored by what is on the table afterwards; a summary by kind, and the most tokens
  the model read in one turn. About 30-60 minutes; not part of the unit tests.
- **build_tower**: a whole tower in one call -- the bottom one to the place asked for ("in the tray"), each next one
  on top, each turned if asked ("at 45 degrees"). Built step by step, the small model left the base outside the
  tray, turned nothing, and said "a tower inside the tray, at 45 degrees". An order asked for is kept to.
- **Bridging**: a long object laid across several level objects ("the bar on top of all the cubes"): place_on
  takes several object_ids; it lies along their row, steady only if held up on both sides of its middle and no
  end out past them by more than a quarter of its length. The tray planner does it too when the floor is full.
  The demo's simulator lets something rest on supports on both sides of its middle.
- **The reply is checked against the table**: the goal check also looks at a tower's place ("in the tray") and
  at an angle asked for ("nothing was turned"), and a reply that says it was all done when the check says
  otherwise gets a Note under it.
- Everyday names: "pen in the tray" means the blue bar (a pen, pencil, stick or rod = a bar; a can, tube or bottle
  = a cylinder): the AI is told so, and asks which one if two fit. The Mixed objects scene's example "Pen next to
  the can" (there is no pen or can: the camera sees a blue bar and a grey cylinder) is now "Blue bar next to the
  grey cylinder".
- The model may read 8,192 tokens at once (Ollama's own 4,096 was outgrown by a prompt of a few steps: "request
  (4287 tokens) exceeds the available context size"), sent with the load and every request; `llm: num_ctx` in
  config.yaml overrides it (about 0.6 GB more memory). If it is ever outgrown, the message says so plainly.

## V3.3 (2026-10-03): turning "at" an angle and several objects at once, piles keep their names, honest replies

- Follows V3.2 (git tag `v3.2`; frozen copy in the `Kyozo_Link_V3.2` folder next to this one). Frozen copy:
  `Kyozo_Link_V3.3` (folder and zip) next to this one; git tag `v3.3`.
- Turning: "at 45 degrees" (where it ends up, angle_deg) as well as "by 45 degrees" (turn_deg), and several objects
  in one turn_object call, top of a pile first; one that can't be taken or has something on it is left, with the
  reason. "All the cubes should be at 45 degrees" made the model pack the tray instead.
- An object in a pile keeps its name: with a cube on it, the grey cylinder was renamed "grey cube" (and the cube on
  it "black cylinder"), and the robot picked the wrong thing.
- Objects are let go 3 mm above what they go on (was 1 mm): a height measured on a pile can be a few mm short, and a
  cube moved off one was pushed into the table.
- A free spot on the table is chosen where the open fingers can also let go (the xArm's came down on a cylinder
  beside the spot).
- The robot's reply is checked against the tools: when it gives a reason for failing that no tool gave ("too wide
  for the gripper"), the tool's own reason is shown under it; and the model is told to use the tool's words.

## V3.2 (2026-10-03): Kyozo Link -- the UFACTORY xArm 6 as a second robot, model picker, turning, three-level trays

- Follows V2.5 (git tag `v2.5`; frozen copy in the `Dobot_Vision_task_V2.5` folder next to this one). The work done as
  "V3.1 (in development)" is this release; there was no V3.1 release. Frozen copy: `Kyozo_Link_V3.2` (folder and zip)
  next to this one; git tag `v3.2`.
- The software is now called **Kyozo Link** (was Dobot Vision Task): the window titles, the start-up window and
  the log. (The folder, the .bat files and the git history keep their names.)
- A second robot: the **UFACTORY xArm 6** with the xArm Gripper. The toolbar's new **Robot** list switches between
  it and the Dobot Magician (the app restarts into it). Demo mode shows its 3D twin, live mode drives the real arm
  over the network (UFACTORY's `xarm-python-sdk`). See *The second robot* in the README.
  - The twin: UFACTORY's own model of this arm (xarm_ros2, BSD licence), the arm's 1305 meshes and the gripper's
    linkage, drawn with the app's own 3D view; the joint angles for a pose worked out exactly (the tool pointing
    down keeps the arm in one plane); six joint gauges.
  - The xArm drawn smooth, not edgy: its meshes reduced by quadric edge collapse (round links stay round; the
    first grid-based reduction left them lumpy) and lit pixel by pixel (Phong shading) from smoothed corner normals,
    so its links look round rather than faceted. (The 3D view's drawing can now light any mesh this way; the
    Dobot's stays as it was.)
  - Each robot keeps its own settings, calibration and saved places (`xarm6:` in `config.yaml`, `*_xarm6` files).
  - The gripper planning and collision checks use each gripper's own shape (the xArm's fingers are 32 mm wide; its
    knuckles stand out beside them) and wrist (the xArm's J6 turns the tool all the way round).
  - The xArm's demo scenes are set out 120 mm further from its base: nearer than 200 mm it would come down on itself.
  - Manual tab for the xArm: how far the gripper opens; live: gripper speed, collision sensitivity, Enable motors,
    Clear errors, Check errors, Reset after E-STOP. Speed capped at 250 mm/s.
- A window at start-up asks which robot and Demo or Live (the last choice already picked: Enter starts as before),
  and says what Start will do; nothing connects until then. Switching in the toolbar restarts without asking.
- A **Log** tab again, after Calibration, with Copy log and Clear: the same live log as the System check window's
  Show log (which stays), the same lines in both.
- The model is now chosen in the **Prompt tab**, just above the prompt box, and the status bar shows it on every tab
  ("LLM: qwen3:4b-instruct · ready · 3.2 GB"). In the toolbar it didn't fit a screen with larger text (150%): the list
  went into the toolbar's overflow strip and couldn't be changed. The demo's Simulated camera and Bump camera moved
  into the demo's Settings panel, so the toolbar is one row again.
- The Model list shows the Qwen models installed, each with what it is good for -- **Quick** (qwen3:4b-instruct),
  **Detailed planning** (qwen3:8b), **Deep reasoning** (qwen3:4b, the Thinking version) -- and dots for its speed and
  its planning.
- Picking a model loads it at once and frees the other, a label beside it says whether it is loading,
  ready (and how much memory it holds) or not loaded, the choice is remembered, and a thinking-only model gets a
  warning. The list is locked while a prompt runs. While the app is open the model stays loaded (30 minutes after
  each use, was Ollama's 5: the first prompt after a break waited for it to load again); closing the app unloads
  it. The default model is now qwen3:4b-instruct-2507 (qwen3:4b is now Qwen's Thinking version: too slow here).
- Switching the model in the toolbar now unloads the other one from Ollama. Both stayed in memory (8.5 GB), which
  a 16 GB PC without a graphics card can't hold: prompts timed out after 120 s. A timeout with two models loaded
  now says so and frees the other one.
- **Turning objects:** "turn the brown block 70 degrees" turns it where it stands (a new turn_object tool), and
  "put the white cube in the tray at 45 degrees" puts it down turned (turn_deg on the put-down tools). Any angle;
  the Dobot's wrist (+-90 degrees) gets there by the turn that looks the same (a block every 180, a cube every 90);
  round things (ball, cylinder) are left as they are, with the reason. Both robots, demo and real.
- **Trays take three levels** when the floor is full, on steady piles only: a third level only where every level
  below is at least as wide (a cube on a cube on a block). With two at most, a green cube was left out of a tray
  whose white and black cubes had flat tops free. The finger and reach checks still apply at that height.
- The demo has its own **Detection** settings (config.yaml `vision_demo:`; the real camera's stay under `vision:`),
  starting on *Any object*. "Coloured cubes only", chosen against the real camera's phantoms, also blinded the demo
  to its ball, can and pen ("there is no ball"); and a real pick area, in the real arm's coordinates, applied to the
  demo's table. The Detection window says which ones you're changing.
- A timeout's advice no longer says "try the smaller qwen3:4b" (that name is now the slow Thinking version): it
  names the model that was too slow and points to a Quick model in the Model list.
- The Prompt tab's conversation: each kind of line has its own colour and a small icon -- your prompt blue, "Asking
  the model..." dim, the robot's steps grey (looking, picking, placing each with its icon; a refused step amber),
  its reply green, errors red. The words are as they were.
- Before each new look at the table, the arm no longer swings all the way to its parking spot (the xArm's was high
  up, far to the side): it looks from where it is if it hides nothing the camera saw, or lifts or moves only part
  of the way until it doesn't. A five-cube tower: the xArm's arm travels 43% less; the Dobot's parking spot is near
  and its arm is usually over the cubes, so it still goes there more often. The first look still parks.
- Fixed for both robots: letting go beside an object, the fingers closed on the carried one were not checked on the
  way down (only the open ones at the bottom).

## V2.5 (2026-10-02): nothing goes through anything, real-camera detection and calibration, green cubes

- Follows V2.1 (git tag `v2.1`; frozen copy in the `Dobot_Vision_task_V2.1` folder next to this one). The work done as
  "V2.2 (in development)" is this release; there were no V2.2-V2.4 releases. Frozen copy: `Dobot_Vision_task_V2.5`.
- The Log tab is gone from the tab bar: the log now shows inside the **System check** window: **Show log** swaps the check results for the log (with **Copy log** and **Clear**), and **Back to checks** swaps them back. It still collects everything from the start, and `app.log` is written as before.
- Nothing goes through anything in the demo. The gripper (as drawn) and what it carries now stop where they meet an object, a tray or bin (walls and floor) or the table, in every scene, by hand or by prompt:
  - The fingers were drawn 15 mm lower than the app took them to be (since V1.8), so they sank into cubes and the table. The tool point is now the fingertips, as the gripper planning and calibration already assumed.
  - The gripper's collision shape is now its real shape, measured from the model the 3D view draws: fingers 14 mm thick (not 6), and the body above them, which stands out about 70 mm to one side. The planner uses the same shape, so it turns the gripper or refuses in words (e.g. next to a tower) rather than being stopped halfway.
  - A carried object is checked too (it used to pass through other objects, tray walls and the table), and so are tray and bin walls and floors (they weren't checked at all).
  - Balls and cylinders are checked as round, not as squares.
  - Something already touching the gripper can be backed away from, but not pushed further into (that used to allow any move).
  - Fingers that close on something they can't hold stop against it instead of closing through it.
  - The suction cup lets go of a stacked object just above the one below (it went 5 mm into it).
- Smaller cubes in the demo, easier to pick by hand: 20 mm (were 25), and 15 / 20 mm in the size-sorting scene (were 18 / 24). The fingers open 27.5 mm: a 25 mm cube left 1.25 mm either side, so lining up by hand meant being within about 2 mm; a 20 mm cube leaves 3.75 mm.
- Quick jog-step buttons (1, 5, 10 mm) beside the step box on the Manual tab.
- Found with the smaller cubes:
  - "Put it beside" spaced objects as if both were 25 mm wide (a 5 mm gap between 20 mm cubes came out 10 mm): it now uses their measured sizes.
  - The demo's suction cup hung every object 12 mm below the tip (right only for a 25 mm cube): now half the object's height.
  - The camera took the end of a block sticking out from under a smaller cube for an object of its own ("a brown ball"), and a cylinder's rim round a smaller cube on it for "a grey cube": both are now seen as the object underneath.
  - "What the camera sees" in the 3D view draws each box the size the camera measured (it was always 25 mm).
- An object taken by hand (Manual tab, Close Gripper) is now known to be held when a prompt runs. The prompt was told "holding nothing" (and the camera can't see what the gripper holds), so "pick the blue cube" opened the gripper, dropped the red cube on the blue one and came down on it.
- Starting low (left there by hand), the arm first rises straight up before going across: going home from round a cube pushed a finger into it.
- Bug check, demo and real:
  - E-STOP lets go of what the gripper held (demo and real) but the tools still thought it held it: the next prompt was told so. Now they're told it's let go.
  - Real arm: the reach check read the Dobot's own heights as if measured from the table (it is ~60 mm below the arm's zero), so most working heights looked out of reach and detours could be refused. It now measures from the calibrated table (no table height yet: no judging by the model).
  - "Put it beside": when the side asked for has no room for the fingers, the refusal names the sides that do (e.g. next to the tray's wall: "there is room on its left and behind"); something long is turned a quarter turn when that makes the fingers fit (a pen beside a can); and something round beside it is measured by its diameter (a 10 mm gap beside the can came out 15).
  - Step by step: the 3D preview of putting something in a tray or bin shows the free spot it goes to (it showed the middle), and "beside" now has a preview.
  - An object taken by hand keeps the id it was listed under.
  - The saved camera reference and calibration session files are closed after reading (a damaged one couldn't be set aside on Windows).
- "Make a tower in the tray" with both cubes already in it: the model called put_all_in (which lays things side by side), it found them already there, and the model said nothing needed doing. Now, for a tower, the app doesn't run put_all_in and tells the model how to build one; the model's rules say so too.
- A tower asked for in an order ("Tower: red, yellow, green, blue, purple"; "red at the bottom, then yellow..."; "purple on blue on red"; "from the top: ...") is built in that order. The model built red, blue, green, yellow, purple, and the app's check called it done: the app didn't read an order given as a list. Now it does, the check says when the order is wrong, and a pick of the wrong next object (or a place_on anywhere but the top) isn't done: the model is told which one is next and what it goes on.
- **Detection** window (toolbar, both modes; kept in config.yaml): find *any object* (depth) or *coloured cubes only* (colour), switched while running; leave out what is *lower than* / *smaller than* a size, or *not seen in* N pictures in a row (2 on the real camera by default); and a **pick area** (an X/Y rectangle in the arm's coordinates, outlined on the camera feed) outside which nothing is found. On the real camera's saved frames: "coloured cubes only" finds just the red cube; a pick area over the mat leaves out the cables and the box by the base.
- Calibration measures the camera's distance scale too. Every real calibration was 15-19 mm off: the camera's distances came out about 10% long (or its focal length that much short; the points can't tell which), and a turn and a shift alone can't fit that. With the scale (used only when it clearly fits better: 6+ points, 0.8-1.25, error at least 20% lower) the same four sessions re-solve to 6.7-8.7 mm, all with a scale of 0.89-0.91. The Calibration tab says what it found; the session records it. Objects are placed through the same calibration, so their positions are corrected too.
- A green cube in every demo scene (as on the lab table), and in the Try prompts: "Three cubes and a tray" (was two: a green cube added; All the cubes in the tray / Green cube on the red one / Red cube next to the green), Mixed objects (a green cube added; All the cubes in the tray / Ball in the tray / Green cube on the black one / Pen next to the can -- seven things don't all fit the tray), Tower building (Green on purple), Size sorting (Green cube in the small bin); Colour sorting had one. The tower scene's description gives the same order as its Try prompt (it said red, blue, green... -- the order the model once built instead).
- Filling a tray plans only spots the arm can reach, with the fingers turned in a way the wrist can turn there: the far side of the tray (past 300 mm) was planned and then refused, and a cube next to another was planned with the fingers closing along x, which the wrist couldn't do there -- they closed the other way, onto the neighbour.
- A cylinder seen at an angle was "a ball": its outline is some 15% wider than its top, and that was the limit; now 40% (a ball's is two or three times its crown).
- The reply check matches whole numbers: "17 mm", made up, passed because an app reply said "170".
- The demo has its own safety box (X -300 to 307, Y +-300, Z 0 to 300), not the real arm's from config.yaml: an X max of 268 set for the real arm put the demo's tray out of reach. (Changing it in the demo still lasts for that session only.)
- The log window stops listening once it is closed: a line logged after that (shutting down, or another window's test) raised an error.
- Manual tab: a jog stopped short by Z min (or Z max, or the edge of the workspace) says so, and how to go further. The arm just stopped, without a word, 39 mm above the table it had to reach for the table touch.
- The calibration's table touch sets Z min 1 mm above the table it touched. It added twice the calibration error (39 mm with a 19.5 mm calibration), and a 24 mm cube was "outside the robot's safe workspace": gripping it halfway down needs the fingertips lower than that. The tip measures the table itself, in the arm's own frame: the camera's error doesn't come into it.
- "Detect table height" (live) no longer sets Z min from a calibration whose heights weren't checked with the table-touch step: today's put the table at -179 mm (the tip touches it at about -35), so Z min was 145 mm below the table and no floor at all. It says so, and to do the table touch.
- Real arm, far too many things seen (some sixty, where one red cube stood). Checked on the camera's saved frames:
  - The table is fitted as a plane in each look, and heights are measured from it. Measured from one height (the tip's touch), a mat 1.5 degrees off level in the arm's frame (today's calibration) was 6 mm "up" in places, and dozens of bits of it were objects.
  - Nothing behind the arm is looked at (its base turns +-90 degrees: it can never reach there).
  - The arm is looked for where it is: the arm model's heights are from the table, the Dobot's from its own zero (35 mm above your table), so the arm was placed too low and parts of it -- the marker card, the gripper -- were objects. The gripper's body (70 mm to one side) is left out too.
  - Left: the red cube, and real clutter by the base (cables, the air tube, the box by the base).
- Real arm: the air pump ran on for good once the gripper had been closed. "Open" (and the E-STOP's release) only turns the air round; the pump is now switched off once the gripper has opened, as Dobot's own examples do. While the gripper holds something the pump still runs: the air is what holds it.
- Tower guard, second round (the model put the red cube, the bottom, on the purple one; the app then kept saying "next: the yellow cube" with the yellow already on it, and the model took it off and put it back for five minutes):
  - The bottom object of the tower is put down on the table or a place, not on another object.
  - The tower is read from wherever its bottom object is; what is under it or out of order on it comes off first, from the top.
  - A prompt whose steps keep being refused (more than 4 times) is ended, with the reason.
- A pile of three was seen as two: the camera only reported the object under the top one if its colour was most of what is below (the middle cube of three is half), and the tools took the top one as what the bottom one is "covered by". Now each colour holding 8 mm down the sides is an object, and "covered by" is the one right on it.
- Beside the base, the arm model judged even where the arm was as "out of reach", so every way round a tall pile was refused ("can't get from ... without going through something"): where the arm is now isn't judged any more.
- In a tray or bin, an object's height is measured from its floor (two 20 mm cubes in the tray were "24 mm", and stacking let go 4 mm up).
- 3D view: a cube standing in a tray or bin under another one wasn't drawn ("the blue cube is not visible"): the tray's floor, drawn by its middle's distance, was painted over it. The floor is now always drawn under what is in it, and the walls stand on the tray's edges as in the simulator (they were drawn 2 mm further in).
- Packed in a tray, a cube could not be picked out again: halfway down its side the fingers met the wall on one side and the next cube on the other. The gripper now holds it higher up (no less than 5 mm down its side) when that keeps the fingers above what is in the way.

## V2.1 (2026-09-29): Model tab, two-finger gripper, objects of any colour, tray planning

- Started from V2.0 (git tag `v2.0`). Saved as git tag `v2.1`, with a frozen copy in the
  `Dobot_Vision_task_V2.1` folder (and zip) next to this one.

### Model tab: everything the model decided, and what the app did with it (demo and live)
- New **Model** tab next to Prompt. One card per prompt, top to bottom, no clicks: how the app read the
  prompt (task, object, destination, the calls it expects), then every model turn in seven stages:
  1 Receive (tokens read, how long, estimated parts), 2 Understand, 3 Find objects (each word matched
  against what's on the table; a guess such as "blue box" read as the blue cube is flagged), 4 Options
  (which actions make sense now), 5 Choose (the action and the rule it follows), 6 Fill in (each value
  and where it came from, plus the app's checks), 7 Answer (the exact call, tokens written, time).
- Each stage is labelled with where it comes from: *measured* (Ollama's own figures), *app* (the app's
  reading, not the model's mind), *reasoning* (the model's own words, only with the switch below).
- Under each instruction, what the **app** did: where the target came from (camera, saved place, free
  spot), the reach checks, then every move with the joint angles before and after (J1-J4 gauges, the
  largest move, the closest any joint came to its limit along the way). Live mode reads the angles from
  the Dobot after each move; demo mode calculates them from the arm model. Joint angles are never
  chosen by the model.
- At the end: was the goal met (checked against the table), does the reply only use numbers the app gave,
  guesses, refusals and how the model recovered, loops, steps/time/tokens used.
- **Only problems** switch, Copy, Save (a standalone HTML page), Clear. Every prompt is also saved as
  JSON in `prompt_logs/` (git-ignored).
- **Settings → Prompts → Show the model's reasoning** (off by default): asks qwen3 to think out loud and
  shows it in stage 5. Much slower: about a minute per turn instead of a few seconds.
- Towers: after each place_on the app tells the model the pile, bottom to top, and which objects are not
  in it yet (the model had taken the cube it just stacked for the bottom, described the tower wrongly and
  stopped with a cube left out). The Model tab checks towers: every object in the pile, any "the yellow
  block should be the third" in its place, and a reply that gets the order wrong.
### Two-finger gripper (demo and live)
- `config.yaml` now says `gripper_type: gripper` (it said suction since V1.8, so the real robot was sent the
  suction-cup command). New `robot: gripper:` settings, to be measured on the robot: opening (27.5 mm, the
  Magician kit), safety margin, how far down the fingers reach, which way they close at r = 0.
- The camera measures each object's footprint from its top face: narrow side, long side and how it is
  turned (demo: within 0.3 mm and 1 degree). list_objects gives `footprint_mm`, and marks an object
  too wide for the fingers; the model is told not to try those.
- The top centre is now the middle of the top face's outline, not the average of its points: from an
  angled camera the average sat ~2.5 mm toward the camera, more than a 25 mm cube in a 27.5 mm opening
  allows (1.25 mm a side). Now 0.1-0.3 mm in the demo.
- A cube turned about 45 degrees is no longer thrown away by the colour detector's shape filter.
- Each pick: refused in words if the object is wider than the opening less the margin, too flat, or a
  neighbour is where a finger would come down; otherwise the fingers are turned to its narrow sides
  with the least wrist turn (a square one either way), close halfway down it (no deeper than the fingers
  reach, never down to the table), and it is carried without turning. Put down with its bottom 1 mm
  above the surface; a quarter or half turn only if the wrist can't hold its turn there.
- The pose's r is now treated as the Dobot defines it, J1 + J4 (the gripper's turn on the table): the
  demo's J4 gauges and 3D gripper follow it.
- Demo twin: objects can stand turned (scene files: `yaw_deg`), Shuffle turns them up to 45 degrees,
  and the virtual gripper holds an object only if the fingertips are down its sides and it fits between
  them. Size sorting's large cubes are now 24 mm (26 mm left 0.75 mm a side).
- Model tab: each pick's App block shows the measured size, which way the fingers turned, the room to
  spare (a tight fit is flagged) and how deep they closed, or why it couldn't be gripped.
- Fixed in review:
  - An object standing on another had its height measured from the table (a 12 mm block on a 25 mm cube
    came out as 37 mm): the fingers would have gone down past its bottom into the cube under it, and
    suction let go too high. Now measured from what it stands on, or not at all.
  - After putting something down at a place (no look after), its top was remembered at the fingertips'
    height, 12.5 mm too low: the next cube stacked on it would have been let go inside it.
  - A demo scene's places are now surfaces (the tray's or bin's floor, the table at the tower spot), and the
    tools let go with the object's bottom 1 mm above them. The old heights put a 25 mm cube held by its top
    9 mm into the tray floor (the demo hid it by dropping objects to rest). Places saved from the Manual tab
    are still the tool's own height, as taught.
  - Demo: when the gripper closes on nothing, the pick says so and lifts clear, instead of "Picked up".
  - Where no turn that looks the same fits the wrist at the drop-off, the object is turned as little as the
    wrist allows, instead of asking J4 to go past its limit (an alarm on the real arm).
  - Step-by-step preview shows where the fingertips really go for pick, place_on and place_at.
  - The finger-clearance check no longer counts the object underneath as a neighbour in the way.
  - Live: the first recorded move checks the Dobot's r = J1 + J4 (which the finger turning relies on) and
    logs an error if this robot does it differently.
### Finding objects of any colour, named by colour and shape (demo and live)
- New detector, `vision: detector: depth` (now the default in config.yaml; `color_blob` is still there):
  anything standing more than 5 mm up from the table, within the arm's reach, is an object, whatever
  it is made of. Works for white, black, grey, wood and any colour; not for clear glass or plastic
  (the depth camera sees through it), and very dark matte or mirror-shiny things can leave gaps.
- Each is named by its colour (white, grey, black, brown, red, orange, yellow, green, teal, blue,
  purple, pink) and its shape (cube, block, bar, cylinder, ball, disc, flat piece): "white cube",
  "grey cylinder", "orange ball", "blue bar". It can't tell a cup from a can: both are cylinders.
- How: every flat top starts an object; each takes in its own sides and curved surface, highest first,
  staying near its top; the outline, size, turn and height are measured as before. In the demo, every
  object is found once, by the right name, within 0.1-1 mm (a ball within 2 mm: its far side is hidden).
- Left out: the arm itself (and what it carries), a tray or bin round a saved place, and thin or hollow
  pieces (a bin's walls, cut up by the edge of the reach).
- A cube under another of a different colour, which the camera sees only by its sides, is found by the
  sides changing colour partway down, and listed as covered by the top one (the tools then move the top
  one aside to get it). Two touching objects of the same height, or a stack of one colour, look like one.
- New demo scene, Mixed objects: a white cube, a black cube, a wooden block, a grey cylinder, an orange
  ball and a blue bar, with a tray. The demo draws balls and cylinders.
- The model and the Model tab know the new names: "wooden" is brown, a "pen" or "stick" is a bar, a
  "block" or "box" can be a cube.
- The camera feeds' boxes and the System check use it too. An object named a little differently from
  one look to the next ("white" / "grey") keeps its id.
- Fixed on the way: an error while drawing the 3D view (or the camera view) closed the whole app without
  a word -- PyQt does that on an error in drawing. Now it is logged and the app keeps going.
### Each demo scene's own prompts after "Try:"
- The example buttons in the Prompt tab now come with the loaded scene (`prompts` in each scene file):
  a highlighted one that does the whole scene ("Sort the cubes by colour", "Build a rainbow tower"...),
  then two or three short ones, then What do you see? and Go home. Live mode keeps the general ones.
- New action, put_all_in(place, objects): several objects into one tray or bin in one go, planned together
  by the app (llm/packing.py) -- the biggest and longest first, each squared up to the tray (tried both
  ways), packed from one corner with room for the open fingers, short ones let go a few mm up so they can
  sit by a wall, and when the floor is full a second layer on flat tops (the lowest first; never on a ball,
  and a ball not on top). What doesn't fit is left where it is and said so. The model is told to use it for
  "everything / all / both / these in the tray"; Stop ends it between objects; the Model tab shows the plan
  and checks every object went in. Order: anything nearly as long as a side first, then what can only go on
  the floor (a ball), then the rest biggest first; something on top may overhang what it stands on by a
  quarter of its size, centred. The demo's Mixed objects table, all of it into the tray: 6 of 6 (bar, ball,
  block and cylinder on the floor, a cube on the block and one on the cylinder); one at a time it was "full"
  after 2.
- Seeing a packed tray: a cube took in the sides of the block under it ("a black block, 39 x 47 mm"), the
  block's visible ends were listed as objects of their own ("a brown bar"), and a taller neighbour within
  35 mm counted as on top of an object (picking the ball would have moved a cube aside first). Now a
  straight-sided object's surface stays within its top's outline, the ends of an object under a stack are
  joined to it (same colour, same height, a sliver beside the stack), and "on top" means its middle is over
  the other's measured top.
- Found checking every tool path with the gripper in the demo (fixed; the same code drives the real arm):
  - Moving between two places the arm went straight, and swept through what stood between: going home after a
    five-cube tower it came down through the tower top (the real arm would have knocked it over). The tools'
    moves now take a clear way: straight if nothing's in it; else across at a height clear of everything, then
    down; else a step aside first (near its base the arm can't reach high, so "up and over" isn't always
    there). Each way is checked in 5 mm steps -- the fingers, the gripper over them, what it carries --
    against everything on the table, along the path the arm really takes. If no way is clear, it says so.
    (The straight way is checked for obstacles only, as before, so moves that always worked still do.)
  - Letting go right beside something (a 5 mm gap) had a finger come down on it. The fingers are now turned out
    of the way when the object looks the same turned (a quarter turn for a square), or it's refused with the
    room needed.
  - put_all_in stopped holding an object when one couldn't be put in; it now puts that one down on a free spot
    and goes on.
  - "Put the blue cube down next to the blue cube" (moving a cube off a pile): now next to the one it was on.
- Manual tab:
  - Turn the gripper: R- / R+ by a step (15 degrees to start), within the wrist's range (said in words at
    its limit).
  - Pick here: the object under the gripper (within about 4 cm) picked up the way a prompt does it -- the
    camera finds it, the fingers are checked for fit, centred and turned to it, and close halfway down. By
    hand the fingers had about 1 mm to spare round a 25 mm cube, with 10 mm jog steps.
  - Close Gripper says what it holds, or (demo) why nothing: "the blue cube is 35 mm across the fingers",
    "the fingertips are above it"...
  - Open Gripper tells the robot tools: a prompt afterwards no longer thinks it's still holding it.
- Demo collisions: a move stops where a finger, the gripper above them or the suction tip would go into an
  object, and says so ("a finger touched the blue cube"); it used to pass straight through (the real arm
  would press on it or push it over). The prompts' own moves are planned clear of them.
- Demo: an object let go over another's edge now tips off and lands beside it, on the table (or the tray's
  floor). It used to "rest" on anything it overlapped even by 3 mm, hanging almost wholly in the air.
- A ball's size is now its outline circle's (part of it is out of sight: it measured 16 x 20 mm for 22).
  The demo world takes a ball or cylinder as the same width however it's turned (a turned ball "rested" on
  the objects next to it).
- The depth detector judges round or not by an object's flat top when it's big enough to tell (a block
  packed close to others in a tray was called a cylinder).
- Scene prompts: "Everything in the tray" (Mixed objects), "Both cubes in the tray" (Two cubes).
- Putting several things in a tray or bin: each used to go to its middle, down onto the one before (the
  real arm would drive it into it) -- the tray filled up as a wobbly tower. Now each goes to a free spot
  inside it, filled from one corner, clear of what's there (as turned rectangles) with room for the open
  fingers inside the walls; a full tray is said so. A place saved from the Manual tab (size unknown) is one
  spot: taken, and the app refuses rather than come down on what's there.
- Depth detector in trays: a tray's thin walls were taken in by the objects beside them, and two cubes in a
  tray with bits of wall between them were dropped as "the tray". Objects now grow only downhill from their
  tops, a tray is recognised by its ring of walls, and the demo's known tray walls are left out.
- Mixed objects: "Clear the table into the tray" is now "Ball and both cubes in the tray" (six things don't
  fit an 80 mm tray).
- E-STOP now also ends the prompt at once. It used to stop only the arm: the prompt stayed "running" until
  the model's next answer came back, and no scene could be loaded meanwhile. A Stop button beside "Asking
  the model..." does the same without an E-STOP (a move under way finishes; nothing after it is done). The
  model's late answer is not acted on.
- When the model says what it will do ("Let me first list the objects.") and stops there, the app tells it
  to go ahead (twice at most; never when it asked you something). "Sort the cubes by colour" ended at that
  sentence every time.
- The model is told that a short request without a verb is still something to do, and to do every part of it
  before replying ("Red cube in the tray, blue on top" was read as a description, and "done").
- Ollama client keeps each reply's figures (tokens, durations, stop reason) and the model's details
  (size, compression, memory limit). Dobot driver: `get_joints()`.

## V2.0 (2026-09-24): settings panel, new 3D view, demo scenes, shuffle, step-by-step mode

- Started from V1.8 (git tag `v1.8`). Saved as git tag `v2.0`, with a frozen copy in the
  `Dobot_Vision_task_V2.0` folder (and zip) next to this one.

### Settings panel and a new-look 3D view (demo mode)
- **Settings** button in the toolbar (demo mode) shows a panel docked beside the 3D view, like an
  inspector: folding sections (Scene, Look, Helpers, Extras), a switch per option, hover for what it
  does, All on / All off / Defaults. Changes show at once and are remembered in `config.yaml`
  (`display:`). All off = the V1.8 look, and the joint panel has its own switch.
- Look: soft shadows, rim light, shiny highlights, measuring mat (10 mm grid and ruler), studio
  background (glow and darkened corners). The Calibration tab's camera view gets the look too.
- Helpers: reach map (the ring the tip can reach at its current height, the no-go zone by the base in
  red), joint gauges (J1-J4 against the Dobot's published limits, orange near one, red past one, with
  arcs at the joints), height line, path preview and ghost target while the arm moves, camera cone
  (where the calibration puts the camera), gripper glow (green holding, amber closed on nothing),
  what the camera sees (outlines where the detector finds each object).
- Extras: labels, glowing tip trail, Top/Front/Side/3D view buttons, auto-rotate, Save image
  (to `screenshots/`). The old "Labels & trail" box on the view is now two options in Settings.
- The demo arm now takes the same route as the real one: across the front of the base it swings
  round instead of cutting through (shared in `app/hardware/motion.py`).
- The joint gauges show J2 and J3 the Dobot's way (rear arm from upright, forearm below level), as the
  real robot reports them; with the gauges off, the V1.8 panel (J3 as the elbow bend) is shown.

### More demo scenes, picked from Settings
- **Scene** section in the Settings panel: pick a scene and **Load**, or **Reset** to put everything
  back where it started. Refused while a prompt runs or the arm moves. The choice is remembered
  (`twin: scenario:` in config.yaml).
- Four scenes (`app/twin/scenarios/`): Two cubes and a tray (as before), Colour sorting (red, yellow,
  green, blue cubes; a warm bin and a cool bin), Tower building (five colours and a tower spot),
  Size sorting (two small 18 mm cubes, two large 26 mm cubes, a small bin and a large bin; 26 mm is
  about the most the Magician's gripper can hold).
- A scene brings its own named places (tray, bins, tower spot) for `place_at`; a pose saved with the
  same name on the Manual tab still wins. `app/poses_demo/tray.json` moved into the default scene.
- **Shuffle** (Scene section): the objects set out somewhere new, always within reach and the joint
  limits, apart (room for the fingers), clear of the bins and named places, in the camera's view and not
  under the arm. Bins stay put. Each layout has a number: type it in to get that layout again; Reset
  puts the scene back. Tested with qwen3:8b on shuffled colour and size sorting: all cubes sorted.
- **Step by step** (switch next to Send, and a Prompts section in Settings): before each robot move of a
  prompt the app says what it will do, shows the route and a ghost arm in the 3D view (amber), and waits:
  **Go**, **Go all** (the rest without asking) or **Stop**. Looking at the table doesn't ask; E-STOP while
  a step waits counts as Stop. "All on / All off" only switch the 3D view's options, never this.
- **Resizable panes:** a divider you can drag between the prompt and the 3D view, and between the view and
  the jog controls; the widths are remembered (`layout:` in config.yaml). The prompt's example buttons
  wrap onto a second line when narrow, so the window fits a laptop screen at 150% scaling (before, with
  Settings open, the right edge of the window was cut off).
- The demo detector also knows yellow and purple (demo only; see `DEMO_EXTRA_COLORS` in
  `app/vision/detector.py`). Bins are never picked up.
- The model is told each object's height (`height_mm` in list_objects, measured by the depth camera),
  so "the small cubes" / "the large one" work; the Prompt tab's log shows it too.
- A prompt may now take up to 20 robot steps (`llm: max_tool_calls` was 8): sorting four cubes
  needs about nine.
- **Fixed: stacking on a cube that had just been moved went to its old spot.** After a put-down the
  robot tools still had the table as it was at the last look, so "put blue on red" (red having just
  been moved to the tower spot) went to where red used to be. The tools now remember where they put
  each object, and it keeps its id at the next look (before, a move of more than 30 mm gave it a new
  one, which is why an older log shows "Unknown object_id" right after a move). Affects the real robot too.
- **Fixed: "build a tower using all these cubes" stopped after two.** The model tried to put the next
  cube on the bottom cube of the pile; the refusal now names the top of the pile and its id, and the
  model's instructions say to stack each next cube on the one put down last. Tested with qwen3:8b: all
  five cubes in one tower, twice in a row.

## V1.8 (2026-09-23): first version confirmed working on the real robot

Tested on a Dobot Magician (DT-MG-4R005-02E) with the two-finger gripper, an Orbbec Gemini 335
RGB-D camera, and Ollama running qwen3:8b. 127 automated tests pass (`python -m unittest discover -s tests`).

### What it does
- **Manual control:** jog X/Y/Z in chosen steps, gripper open/close, Home, saved poses,
  workspace bounds (safety box, reach limit, no-go zone next to the base), arm speed and gripper wait,
  Check/Clear Alarms, E-STOP and Reset E-STOP.
- **Camera:** live colour feed with the detected cubes outlined, click-to-move,
  3D positions from colour plus depth (top-face centre of each object).
- **Prompts (local language model, qwen3:8b via Ollama):** tools `list_objects`, `move_above`,
  `move_to`, `pick`, `place`, `place_at`, `place_on` (stack), `place_beside`
  (left/right/front/behind at a set gap), `place_free`, `open_gripper`, `close_gripper`, `home`.
  Picking a covered object moves the one on top aside first.
- **Calibration:**
  - A. automatic, with the printed ArUco marker on the tool (sweep, then a wrist turn to find
    and remove the marker's sideways offset);
  - B. by hand (click the tool in the picture at 8 to 12 spots);
  - then touch the table (sets the height correction and the safety floor), and verify
    (sends the tip to 5 spots and measures the real error);
  - every run is saved in `sessions/` and can be replayed;
  - "Has the camera moved?" check against a remembered view.
- **Demo mode:** PyBullet simulation with a simulated camera and a digital twin drawn from the
  Magician's real meshes (from jkaniuka/magician_ros2, MIT licence), so everything can be tried without hardware.
- **System check:** robot and its alarms, camera and depth, calibration, table height, safety bounds,
  language model and memory, all in one window.

### Fixed in this version
- **Arm stuck near the base / jogging did nothing after automatic calibration.** A straight move
  across the front of the base ran into a joint limit (alarm 0x22). The controller counted the move
  as done, so the app didn't notice. Now:
  - moves that would cut across the front of the base swing round it instead (joint move);
  - after every move the app checks the alarms and where the arm really is;
  - a spot the arm can't reach gets a clear message, and the alarm is cleared so the next move works;
  - a controller stuck in alarm is reported once, with the joint angles and "power-cycle, then Home";
  - Home clears an alarm left over from before, so it isn't reported as homing failing;
  - automatic calibration skips a spot it can't reach, and stops after two in a row.
- **"Put A on the right side of B" stacked A on top of B.** Added the `place_beside` tool, and
  the model's instructions now tell "beside" from "on top", with the robot's own left and right.
- Removed the marker card from the top of the twin's gripper.

### Known limits (to look at in V2)
- The arm's real reach near the base depends on height: about 183 mm out was already too close at
  78 mm up. The app now reports this clearly but doesn't plan around it.
- On the real robot, the gripper fingers open about 12 mm past a held cube's sides. A small
  `place_beside` gap along the jaw direction could knock the neighbour.
- The automatic calibration's sweep order can still send the arm the long way round.

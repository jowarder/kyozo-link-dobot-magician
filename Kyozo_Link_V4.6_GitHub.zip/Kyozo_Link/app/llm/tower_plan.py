"""The tower a request asks for, worked out by the app before anything is built: how many objects, and which one goes
where ("red at the bottom and purple at the third", "the green one at the third position from bottom", "blue on top",
"yellow in the middle"); the rest in the order the model chose. Read only as a full order of colours ("Tower: red,
yellow, green"), "purple at the third" was taken for "purple second", and "green third" wasn't seen at all -- the model
built both wrong, and the app let it.
"""
from __future__ import annotations

import re
from typing import Optional

from app.llm.trace import COLOUR_ALIASES, COLOURS, tower_order

ORDINALS = {"first": 1, "1st": 1, "second": 2, "2nd": 2, "third": 3, "3rd": 3, "fourth": 4, "4th": 4, "fifth": 5,
            "5th": 5, "sixth": 6, "6th": 6, "seventh": 7, "7th": 7, "eighth": 8, "8th": 8}
NUMBERS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8}
_COLOUR = r"\b(" + "|".join(COLOURS + tuple(COLOUR_ALIASES)) + r")\b"
_ORDINAL = r"\b(" + "|".join(ORDINALS) + r")\b|\b(?:position|level|place|number|no\.?)\s*(\d)\b"
_FROM_TOP = re.compile(r"^\W*(?:\w+\s+){0,2}?from\s+(?:the\s+)?top\b")
# an ordinal that names a place in the tower, not just the first in a list ("put red first, then blue" is an order)
MIDDLE_PLACES = re.compile(r"\b(?:second|2nd|third|3rd|fourth|4th|fifth|5th|sixth|6th|seventh|7th|eighth|8th|"
                           r"middle|(?:position|level)\s*\d)\b")


def _colour(word: str) -> str:
    return COLOUR_ALIASES.get(word, word)


def count_asked(prompt: str) -> Optional[int]:
    """"a tower of three cubes" -> 3; None when no number is given."""
    match = re.search(r"\b(two|three|four|five|six|seven|eight|\d)\s+(?:\w+\s+)?(?:cubes|blocks|boxes|objects|pieces)\b",
                      prompt.lower())
    if not match:
        return None
    word = match.group(1)
    return NUMBERS.get(word) or int(word)


def _place_of(text: str, n: int) -> Optional[int]:
    """The place (0 = bottom) the start of `text` gives: "at the bottom", "on top", "at the third (position) (from the
    bottom)", "second from the top", "in the middle", "position 3"; None if it gives none."""
    head = text[:60]
    ordinal = re.search(_ORDINAL, head)
    if ordinal:
        number = ORDINALS[ordinal.group(1)] if ordinal.group(1) else int(ordinal.group(2))
        if _FROM_TOP.search(head[ordinal.end():]):
            return n - number
        return number - 1
    if re.search(r"\bmiddle\b|\bcent(?:re|er)\b", head):
        return n // 2 if n % 2 else None
    if re.search(r"\btop\b(?!\s+of\b)", head):
        return n - 1
    if re.search(r"\bbottom\b|\bbase\b", head):
        return 0
    return None


def position_claims(prompt: str, labels: list[str], n: int) -> dict[str, Optional[int]]:
    """{label: place from the bottom (0 = bottom)} for each colour the request gives a place, by its colour: "red at the
    bottom", "the purple should be at the third", "put the green one at the third position from bottom", "the third
    one should be yellow". A place past the tower's top is kept (as is) for tower_plan to refuse."""
    p = prompt.lower()
    claims: dict[str, Optional[int]] = {}
    found = list(re.finditer(_COLOUR, p))
    by_colour = {_colour(l.split()[0]): l for l in labels}
    for i, match in enumerate(found):
        label = by_colour.get(_colour(match.group(1)))
        if label is None or label in claims:
            continue
        # what follows the colour, up to the next colour or the end of the sentence
        end = found[i + 1].start() if i + 1 < len(found) else len(p)
        stop = re.search(r"[.;!?]", p[match.end():end])
        after = p[match.end(): match.end() + stop.start()] if stop else p[match.end():end]
        place = _place_of(after, n)
        if place is None:
            # "the third (one) should be yellow": the place just before the colour
            before = p[max(0, match.start() - 40): match.start()]
            lead = re.search(r"(?:" + _ORDINAL + r")\s+(?:\w+\s+){0,4}$", before)
            if lead and not re.search(_COLOUR, lead.group(0)):
                place = _place_of(lead.group(0), n)
        if place is not None:
            claims[label] = place
    return claims


def tower_plan(prompt: str, labels: list[str], given: list[str]) -> tuple[Optional[list[str]], Optional[str]]:
    """(the tower asked for, bottom to top, as labels; None if the request leaves it all to the model), or (None, why it
    can't be built as asked). `labels`: what is on the table; `given`: the model's own order, kept for the objects the
    request doesn't place. "A tower" with no number, or "all the cubes", is every one (of the kind it names)."""
    if len(set(labels)) != len(labels):
        return None, None                          # two of a colour: places by colour can't tell them apart
    p = prompt.lower()
    candidates = labels
    if re.search(r"\b(?:cubes?|blocks?)\b", p):
        cubes = [l for l in labels if l.split()[-1] in ("cube", "block")]
        candidates = cubes or labels
    number = count_asked(p)
    n = number or len(candidates)
    if number is not None and number > len(candidates):
        return None, f"There are only {len(candidates)} to build with, not {number}."
    claims = position_claims(p, candidates, n)
    sequence = tower_order(prompt, candidates)
    # a list of colours ("Tower: red, yellow, green", "red, then blue", "blue on red") is the whole order; "blue on top
    # and red at the bottom" is two places in a tower of all of them
    listed = re.search(r",|\bthen\b|" + _COLOUR + r"(?:\s+\w+)?\s+on\s+(?:top\s+of\s+)?(?:the\s+)?" + _COLOUR, p)
    if sequence and (listed or set(claims) != set(sequence)):
        return sequence, None
    if not claims and number is None and len([g for g in given if g in candidates]) >= n:
        return None, None
    if not claims and number is not None:
        return None, None                          # "a tower of three cubes": which three is the model's choice
    slots: list[Optional[str]] = [None] * n
    for label, place in claims.items():
        if place is None or not 0 <= place < n:
            return None, (f"The {label} can't go there: the tower has {n} object{'s' if n != 1 else ''}, counted from "
                          "the bottom.")
        if slots[place] is not None:
            return None, f"The {slots[place]} and the {label} were both asked for the same place in the tower."
        slots[place] = label
    rest = [g for g in given if g in candidates and g not in claims]
    rest += [l for l in candidates if l not in claims and l not in rest]
    for i in range(n):
        if slots[i] is None:
            slots[i] = rest.pop(0)
    return [s for s in slots if s is not None], None

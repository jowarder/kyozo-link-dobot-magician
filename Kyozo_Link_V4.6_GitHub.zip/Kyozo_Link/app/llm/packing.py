"""Planning a tray or bin for several objects at once (the put_all_in tool): where each goes, turned how, in what
order -- before the arm moves.

Put down one at a time, each object went to the first free spot it fitted, turned as it happened to lie on the
table: an 80 mm tray was "full" after a cylinder and a block at 30 degrees. Planned together:

1. anything nearly as long as a side first (a 60 mm bar only fits lying along one, so while one is free), then what
   can only go on the floor (a ball), then the rest biggest first;
2. each squared up to the tray -- tried lying both ways -- and put in the lowest free row, from one corner, with
   room for the open fingers (inside the walls, clear of what's already in);
3. when the floor is full, on top of something with a flat top it fits on (the lowest first; never on a ball, and
   a ball not on top of anything: it would roll). Three levels at most, and a third only on a steady pile: every
   level below at least as wide as it (a cube on a cube on a block) -- with two at most, a green cube was left out
   of a tray whose white and black cubes had flat tops free;
4. a long object (a bar) that fits on no single top: laid across a row of level tops (a bar across three cubes),
   along the row, resting on supports on both sides of its middle, no end out past them by more than a quarter;
5. what doesn't fit is left where it is, and said so.

Positions are in mm from the place's middle, with the tray square to the robot's axes (the demo's trays are);
heights are the robot's z.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Optional

GAP_MM = 3.0               # between things side by side
OVERHANG = 0.25           # something on top may be wider than what it stands on by this share of its own size
                           # (a 25 mm cube centred on a 20 mm block: 2.5 mm over each side, and steady)
MAX_LAYERS = 3
STEADY_MM = 1.0            # a third level: no wider than every level below (to this much)
WALL_CLEAR_MM = 1.0        # fingertips this far above a wall's top open over it
MAX_DROP_MM = 8.0          # a short object may be let go this much above its floor, to get the fingertips above the
                           # walls (then it can go right by one: a 10 mm bar, gripped 5 mm down, would otherwise need
                           # 20 mm clear of the walls on each side for the fingers)
BRIDGE_LEVEL_MM = 2.5      # laid across several tops: these level (to this much)
BRIDGE_OVERHANG = 0.25     # ...and no end out past them by more than this share of its length
NOTHING_ON = {"ball"}      # nothing goes on top of these
NOT_ON_TOP = {"ball"}      # these don't go on top of anything


@dataclass
class Item:
    """An object to put in."""
    id: str
    label: str
    width: float            # its narrow side, seen from above
    length: float           # its long side
    height: float
    grip_depth: float       # how far below its top the fingertips hold it

    @property
    def shape(self) -> str:
        return self.label.split()[-1]


@dataclass
class Box:
    """Something in the tray: already there, or planned."""
    id: str
    label: str
    x: float
    y: float
    width: float
    length: float
    angle: float            # which way its long side points (degrees)
    top: float              # z of its top
    layer: int = 0
    covered: bool = False
    support_width: Optional[float] = None    # the narrowest of it and everything below it (the pile's), else its own
    support_length: Optional[float] = None

    def __post_init__(self) -> None:
        if self.support_width is None:
            self.support_width = self.width
        if self.support_length is None:
            self.support_length = self.length

    @property
    def shape(self) -> str:
        return self.label.split()[-1]


@dataclass
class Placement:
    id: str
    label: str
    x: float                # from the place's middle
    y: float
    angle: float            # its long side will point this way
    closing: float          # the fingers close along this (across its narrow side)
    surface: float          # z of what it will stand on
    on: Optional[str] = None
    drop: float = 0.0       # let go this much above it (a short object, fingertips above the walls)


@dataclass
class Plan:
    placements: list = field(default_factory=list)
    left_out: list = field(default_factory=list)     # [(label, why)]


@dataclass
class Fingers:
    reach: float            # from the middle to each finger's middle, open
    thickness: float        # each finger, along the way they close
    width: float            # each finger, across it


def rectangles_overlap(a_centre, a_size, b_centre, b_size, gap: float) -> bool:
    """Whether two rectangles seen from above -- (width, length, angle of the long side) round their centres -- come
    closer than `gap` (tested along each one's sides: if on any of them they don't meet, they don't)."""
    def corners(centre, size):
        width, length, angle = size
        c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
        hl, hw = length / 2.0 + gap / 2.0, width / 2.0 + gap / 2.0
        return [(centre[0] + i * hl * c - j * hw * s, centre[1] + i * hl * s + j * hw * c)
                for i, j in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    a, b = corners(a_centre, a_size), corners(b_centre, b_size)
    for size in (a_size, b_size):
        for turn in (size[2], size[2] + 90.0):
            ux, uy = math.cos(math.radians(turn)), math.sin(math.radians(turn))
            pa = [x * ux + y * uy for x, y in a]
            pb = [x * ux + y * uy for x, y in b]
            if max(pa) <= min(pb) or max(pb) <= min(pa):
                return False
    return True


def overlap_depth(a_centre, a_size, b_centre, b_size) -> float:
    """How far two rectangles seen from above (as in rectangles_overlap) are into each other: the least overlap
    along any of their sides (0 or less: apart)."""
    def corners(centre, size):
        width, length, angle = size
        c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
        hl, hw = length / 2.0, width / 2.0
        return [(centre[0] + i * hl * c - j * hw * s, centre[1] + i * hl * s + j * hw * c)
                for i, j in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    a, b = corners(a_centre, a_size), corners(b_centre, b_size)
    depth = math.inf
    for size in (a_size, b_size):
        for turn in (size[2], size[2] + 90.0):
            ux, uy = math.cos(math.radians(turn)), math.sin(math.radians(turn))
            pa = [x * ux + y * uy for x, y in a]
            pb = [x * ux + y * uy for x, y in b]
            depth = min(depth, min(max(pa), max(pb)) - max(min(pa), min(pb)))
    return depth


def _extent(width: float, length: float, angle: float) -> tuple[float, float]:
    """Half its size along the tray's x and y."""
    c, s = abs(math.cos(math.radians(angle))), abs(math.sin(math.radians(angle)))
    return (length * c + width * s) / 2.0, (length * s + width * c) / 2.0


def _extent_along(box: "Box", direction: float) -> float:
    """How wide a box is along `direction` (degrees), seen edge-on."""
    turn = math.radians(direction - box.angle)
    return abs(box.length * math.cos(turn)) + abs(box.width * math.sin(turn))


def plan_tray(items: list[Item], inner: tuple[float, float], wall_top: Optional[float], floor_z: float,
              existing: list[Box], fingers: Optional[Fingers], step: float = 2.0,
              reachable: Optional[Callable[[float, float, float], bool]] = None,
              can_close: Optional[Callable[[float, float, float], bool]] = None) -> Plan:
    """Where each item goes: see the module's description. `inner`: the tray's inside (width along x, depth along
    y); `wall_top`: z of its walls' top (None: no walls to mind); `existing`: what is in it already; `fingers`:
    None for a suction cup; `reachable(x, y, z)`: whether the arm can let go there (x, y in the tray's own frame,
    z the tool's height) -- a tray reaching past the arm's reach had its far side planned, and what went there was
    left out at the last moment ("outside the robot's safe workspace"). `can_close(x, y, closing)`: whether the wrist
    can turn the fingers to close along `closing` there (straight out from the base, closing along x needs J4 at
    90 degrees: the fingers then closed the other way, onto the cube planned next to it)."""
    can_reach = reachable or (lambda x, y, z: True)
    turns = can_close or (lambda x, y, closing: True)
    plan = Plan()
    boxes = [Box(**vars(b)) for b in existing]
    half_x, half_y = inner[0] / 2.0, inner[1] / 2.0

    def fingers_clear(x: float, y: float, closing: float, fingertips: float) -> bool:
        if fingers is None:
            return True
        ux, uy = math.cos(math.radians(closing)), math.sin(math.radians(closing))
        size = (fingers.thickness, fingers.width, closing + 90.0)       # long side across the closing direction
        for side in (-1.0, 1.0):
            fx, fy = x + side * fingers.reach * ux, y + side * fingers.reach * uy
            if wall_top is not None and fingertips < wall_top + WALL_CLEAR_MM:
                ex, ey = _extent(*size)
                if abs(fx) + ex > half_x or abs(fy) + ey > half_y:
                    return False                        # a finger would come down on a wall
            for box in boxes:
                if box.top > fingertips + 1.0 and rectangles_overlap((fx, fy), size, (box.x, box.y),
                                                                     (box.width, box.length, box.angle), 1.0):
                    return False
        return True

    def on_the_floor(item: Item) -> Optional[Placement]:
        candidates = []
        for angle in (0.0, 90.0):
            ex, ey = _extent(item.width, item.length, angle)
            room_x, room_y = half_x - ex - 1.0, half_y - ey - 1.0
            if room_x < 0 or room_y < 0:
                continue
            nx, ny = int(room_x // step), int(room_y // step)
            for i in range(-nx, nx + 1):
                for j in range(-ny, ny + 1):
                    candidates.append((j * step, i * step, angle))     # lowest row first, then from the left
        candidates.sort(key=lambda c: (c[0], c[1], c[2]))
        fingertips = floor_z + item.height + 1.0 - item.grip_depth
        drop = 0.0
        if wall_top is not None and fingertips < wall_top + WALL_CLEAR_MM <= fingertips + MAX_DROP_MM:
            drop = wall_top + WALL_CLEAR_MM - fingertips
            fingertips += drop
        for y, x, angle in candidates:
            if not can_reach(x, y, fingertips) or (fingers is not None and not turns(x, y, angle + 90.0)):
                continue
            size = (item.width, item.length, angle)
            if any(rectangles_overlap((x, y), size, (b.x, b.y), (b.width, b.length, b.angle), GAP_MM) for b in boxes):
                continue
            if not fingers_clear(x, y, angle + 90.0, fingertips):
                continue
            return Placement(item.id, item.label, x, y, angle, angle + 90.0, floor_z, drop=drop)
        return None

    def on_top(item: Item) -> Optional[Placement]:
        if item.shape in NOT_ON_TOP:
            return None
        def fits_on(b: Box) -> bool:
            if b.layer == 0:          # on the floor's: a little wider is steady
                return (item.width - b.width <= max(2.0, OVERHANG * item.width)
                        and item.length - b.length <= max(2.0, OVERHANG * item.length))
            # higher: no wider than any level below, so the pile stays steady
            return (item.width <= b.support_width + STEADY_MM and item.length <= b.support_length + STEADY_MM)

        bases = sorted((b for b in boxes if not b.covered and b.shape not in NOTHING_ON and b.layer < MAX_LAYERS - 1
                        and fits_on(b)),
                       key=lambda b: b.top)
        for base in bases:
            fingertips = base.top + item.height + 1.0 - item.grip_depth
            if not can_reach(base.x, base.y, fingertips) or (fingers is not None
                                                             and not turns(base.x, base.y, base.angle + 90.0)):
                continue
            if not fingers_clear(base.x, base.y, base.angle + 90.0, fingertips):
                continue
            return Placement(item.id, item.label, base.x, base.y, base.angle, base.angle + 90.0, base.top, base.label)
        return None

    def across(item: Item) -> Optional[tuple]:
        """(Placement, the tops it rests on) laying a long item across a row of level tops, or None."""
        if item.shape in NOT_ON_TOP or item.length < 2.0 * item.width:
            return None
        tops = [b for b in boxes if not b.covered and b.shape not in NOTHING_ON and b.layer < MAX_LAYERS - 1]
        best = None
        for i, a in enumerate(tops):
            for b in tops[i + 1:]:
                if abs(a.top - b.top) > BRIDGE_LEVEL_MM or math.hypot(b.x - a.x, b.y - a.y) < 1.0:
                    continue
                line = math.degrees(math.atan2(b.y - a.y, b.x - a.x))
                ux, uy = math.cos(math.radians(line)), math.sin(math.radians(line))
                cx, cy = (a.x + b.x) / 2.0, (a.y + b.y) / 2.0
                row, spans = [], []
                for t in tops:
                    along = (t.x - cx) * ux + (t.y - cy) * uy
                    side = -(t.x - cx) * uy + (t.y - cy) * ux
                    if abs(t.top - a.top) > BRIDGE_LEVEL_MM:
                        continue
                    if abs(side) > _extent_along(t, line + 90.0) / 2.0 + item.width / 2.0 - 2.0:
                        continue
                    half = _extent_along(t, line) / 2.0
                    row.append(t)
                    spans.append((along - half, along + half))
                low, high = min(s[0] for s in spans), max(s[1] for s in spans)
                middle = (low + high) / 2.0
                left = any(s[0] < middle - 1.0 and s[1] > middle - item.length / 2 + 1.0 for s in spans)
                right = any(s[1] > middle + 1.0 and s[0] < middle + item.length / 2 - 1.0 for s in spans)
                overhang = max(low - (middle - item.length / 2), (middle + item.length / 2) - high)
                if not (left and right) or overhang > BRIDGE_OVERHANG * item.length:
                    continue
                x, y = cx + ux * middle, cy + uy * middle
                surface = max(t.top for t in row)
                fingertips = surface + item.height + 1.0 - item.grip_depth
                if not can_reach(x, y, fingertips) or (fingers is not None and not turns(x, y, line + 90.0)):
                    continue
                if not fingers_clear(x, y, line + 90.0, fingertips):
                    continue
                key = (surface, -len(row))
                if best is None or key < best[0]:
                    names = ", ".join(t.label for t in row)
                    best = (key, Placement(item.id, item.label, x, y, line % 180.0, line + 90.0, surface, names), row)
        return (best[1], best[2]) if best else None

    def order(item: Item) -> tuple:
        # 1. anything nearly as long as a side, while a side is free; 2. what can only go on the floor (a ball: it
        # can't go on top of anything) -- planned last, the ball found the floor full and was left out, while a
        # cube planned before it could have gone on top of another; 3. the rest, biggest first
        long_one = item.length >= 0.6 * max(inner)
        return (not long_one, item.shape not in NOT_ON_TOP, -item.length, -item.width * item.length)

    for item in sorted(items, key=order):
        spot = on_the_floor(item) or on_top(item)
        if spot is None:
            bridge = across(item)
            if bridge is not None:
                spot, row = bridge
                for t in row:
                    t.covered = True
                boxes.append(Box(item.id, item.label, spot.x, spot.y, item.width, item.length, spot.angle,
                                 spot.surface + item.height, layer=max(t.layer for t in row) + 1))
                plan.placements.append(spot)
                continue
        if spot is None:
            why = ("no room left on its floor, and it can't go on top of anything there" if item.shape not in NOT_ON_TOP
                   else f"no room left on its floor (a {item.shape} can't go on top of something: it would roll)")
            plan.left_out.append((item.label, why))
            continue
        base = next((b for b in boxes if spot.on is not None and b.label == spot.on and b.x == spot.x
                     and b.y == spot.y and not b.covered), None)
        if base is not None:
            base.covered = True
        boxes.append(Box(item.id, item.label, spot.x, spot.y, item.width, item.length, spot.angle,
                         spot.surface + item.height, layer=(base.layer + 1) if base is not None else 0,
                         support_width=min(item.width, base.support_width) if base is not None else None,
                         support_length=min(item.length, base.support_length) if base is not None else None))
        plan.placements.append(spot)
    return plan

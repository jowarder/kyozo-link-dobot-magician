"""The app's own checks of each step the model takes, against the words of the request. A step that plainly does
something else than asked is not done, and the model is told why and what to do instead. Found by the prompt test
bench (tests/prompt_bench.py), where the small model:

- "Put the yellow cube in the tray" (there is none): put the red cube in;
- "Put the red cube in the bin" (there is none): put it in the tray;
- "Line up red, green and purple from left to right": lined them up purple, green, red;
- "Move the red cube 1 inch towards the robot": moved it away from the robot;
- "Turn the brown block 45 degrees": turned it TO 45 degrees, not BY 45.

Lenient on purpose: only what the request plainly says is checked ("all", "them", "the rest"... and no check of
colours at all).
"""
from __future__ import annotations

import re
from typing import Optional

from app.llm.trace import COLOUR_ALIASES, COLOURS, OBJECT_KINDS, SIZES

PLACE_WORDS = ("tray", "bin", "box", "basket", "bowl", "container", "plate", "cup", "bucket", "crate", "drawer")
# "all the cubes", "the rest", "them": more than the colours named may be meant
MANY = re.compile(r"\b(?:all|every|everything|each|rest|others?|remaining|them|both|these|those|cubes|blocks|"
                  r"objects|things)\b")
SLOW = re.compile(r"\b(?:slow|slowly|slower|careful|carefully|gentle|gently)\b")
TOWER_WORDS = re.compile(r"\b(?:tower|pile|stack)\b")    # "the tower": the cubes in it, though not named by colour
OBJECT_ARGS = ("object_id", "object_ids", "object_id_a", "object_id_b")
CHECKED_TOOLS = {"pick", "move_object", "turn_object", "swap", "line_up", "place_on", "place_beside",
                 "place_between", "move_above"}
PLACE_TOOLS = {"place_at", "put_all_in", "empty_place", "build_tower"}
TURN_TOOLS = {"turn_object", "build_tower", "place", "place_at", "place_on", "place_free", "place_beside"}
DIRECTIONS = {"left": "left", "right": "right", "forward": "away", "front": "away", "away": "away",
              "further": "away", "back": "towards", "behind": "towards", "backward": "towards",
              "backwards": "towards", "towards_base": "towards", "closer": "towards", "towards": "towards",
              "toward": "towards", "towards_the_robot": "towards", "toward_the_robot": "towards",
              "nearer": "towards", "farther": "away"}
DIRECTION_WORDS = {"left": "left", "right": "right", "away": "forward (away from the robot)",
                   "towards": "back (towards the robot)"}


def colour_of(label: str) -> str:
    word = label.split()[0] if label else ""
    return COLOUR_ALIASES.get(word, word)


# words a letter off a colour's name that mean something else ("move it back" isn't black)
NOT_TYPOS = {"back", "lack", "slack", "while", "write", "whit", "greet", "greed", "preen", "brow", "grown", "crown",
             "drown", "blown", "brawn", "blur", "glue", "clue", "flue", "range", "grange", "fellow", "mellow", "bellow",
             "hello", "yell"}
# colours a typo may stand for: not pink, teal or grey -- "pick", "tell", "tray" are a letter off them
TYPO_COLOURS = ("blue", "green", "yellow", "purple", "orange", "black", "white", "brown")


def _one_off(word: str, name: str) -> bool:
    """A letter added, left out or changed: "bllue", "gren", "greem" for green."""
    if abs(len(word) - len(name)) > 1 or word == name:
        return False
    if len(word) == len(name):
        return sum(a != b for a, b in zip(word, name)) == 1
    short, long_ = sorted((word, name), key=len)
    return any(long_[:i] + long_[i + 1:] == short for i in range(len(long_)))


def _colour_word(word: str) -> Optional[str]:
    """The colour a word names: as written, an alias, or a typo of one (a word of 4 letters or more, a letter off a
    colour's name: the lab, 2026-10-21, "pick up the bllue cube" was refused as naming only the green one)."""
    word = COLOUR_ALIASES.get(word, word)
    if word in COLOURS:
        return word
    if len(word) < 4 or word in NOT_TYPOS or word in DIRECTIONS or word in OBJECT_KINDS or word in SIZES             or word in PLACE_WORDS:
        return None                      # (the app's own words: "tray" is a letter off "gray")
    near = [c for c in TYPO_COLOURS if _one_off(word, c)]
    return COLOUR_ALIASES.get(near[0], near[0]) if len(near) == 1 else None


def named_colours(prompt: str) -> list[str]:
    """The colours a request names, in its order ("dark" = black, "wooden" = brown; "bllue" = blue)."""
    named = []
    for match in re.finditer(r"[a-z]+", prompt.lower()):
        word = _colour_word(match.group(0))
        if word is not None and word not in named:
            named.append(word)
    return named


def wants_slow(prompt: str) -> bool:
    return bool(SLOW.search(prompt.lower()))


def angle_asked(prompt: str) -> Optional[tuple[str, float]]:
    """("by", 45) for "turn it 45 degrees" / "rotate it by 45°"; ("at", 45) for "at 45 degrees" / "to 45 degrees"; None
    if no angle is named."""
    p = prompt.lower()
    match = re.search(r"(\b\w+\s+)?(-?\d+(?:\.\d+)?)\s*(?:°|deg\b|degrees?\b)", p)
    if not match:
        return None
    before = (match.group(1) or "").strip()
    value = float(match.group(2))
    if before in ("at", "to", "set", "an", "of"):
        return "at", value
    if before == "by" or re.search(r"\b(?:turn|rotate|spin|twist)\w*\b", p[:match.start()]):
        return "by", value
    return "at", value


def direction_asked(prompt: str) -> Optional[str]:
    """Which way a "move it 5 cm ..." request says: left, right, away or towards (the robot); None if it doesn't."""
    p = prompt.lower()
    if re.search(r"\b(?:towards?|closer to|nearer to|in to)\s+(?:the\s+)?(?:robot|base|arm)\b|\bcloser\b|\bnearer\b", p):
        return "towards"
    if re.search(r"\baway\b|\bfurther\b|\bfarther\b|\bforwards?\b", p):
        return "away"
    if re.search(r"\bback(?:wards?)?\b", p):
        return "towards"
    if re.search(r"\bleft\b", p):
        return "left"
    if re.search(r"\bright\b", p):
        return "right"
    return None


def directions_asked(prompt: str) -> list[str]:
    """Every way a request says to move ("30 mm to the left, then 60 mm to the right": left and right), in
    direction_asked's order; [] if it says none."""
    p = prompt.lower()
    found = {"towards": bool(re.search(r"\b(?:towards?|closer to|nearer to|in to)\s+(?:the\s+)?(?:robot|base|arm)\b|"
                                       r"\bcloser\b|\bnearer\b|\bback(?:wards?)?\b", p)),
             "away": bool(re.search(r"\baway\b|\bfurther\b|\bfarther\b|\bforwards?\b", p)),
             "left": bool(re.search(r"\bleft\b", p)), "right": bool(re.search(r"\bright\b", p))}
    return [d for d, named in found.items() if named]


def check_step(name: str, arguments: dict, prompt: str, executor, task: str) -> Optional[str]:
    """"ERROR: not done. ..." for a step that plainly isn't what the request asks for; None to go ahead."""
    for check in (_missing_place, _wrong_object, _wrong_place, _place_left_out, _unasked_tower_place,
                  _back_into_place, _wrong_row_order,
                  _wrong_direction, _wrong_side, _wrong_turn, _unasked_turn):
        refusal = check(name, arguments or {}, prompt, executor, task)
        if refusal:
            return refusal
    return None


def _scene(executor) -> list:
    return list(getattr(executor, "_last_scene", []) or [])


def _ids(arguments: dict) -> list[str]:
    ids = []
    for key in OBJECT_ARGS:
        value = arguments.get(key)
        if isinstance(value, list):
            ids += [str(v) for v in value]
        elif value:
            ids.append(str(value))
    return ids


def _wrong_object(name, arguments, prompt, executor, task) -> Optional[str]:
    """An object of a colour the request doesn't name, when it names colours: "the yellow cube" with no yellow one
    on the table is said so, not swapped for the red one."""
    if name not in CHECKED_TOOLS or task == "build a tower" or MANY.search(prompt.lower()):
        return None
    named = named_colours(prompt)
    if not named:
        return None
    scene = _scene(executor)
    by_id = {o.id: o for o in scene}
    on_table = {colour_of(o.label) for o in scene}
    # the camera's "teal" is a hue between green and blue (a green cube's shaded sides under a warm lamp): it stands
    # for a green or blue the user named when none of that colour is seen (study 3, S-14: "the green cube" with the
    # green cube read as teal, under the blue one, was refused -- "there is no green one")
    stands_for = {c for c in ("green", "blue") if c in named and c not in on_table and "teal" in on_table}
    on_table |= stands_for
    holding = getattr(executor, "holding", None)
    for oid in _ids(arguments):
        obj = by_id.get(oid)
        if obj is None or colour_of(obj.label) in named or (colour_of(obj.label) == "teal" and stands_for):
            continue
        # picking what is on top of a named one, to get at it, is fine
        covered_by = getattr(executor, "_covered_by", None)
        if name == "pick" and covered_by is not None and any(
                colour_of(o.label) in named and covered_by(o) is obj for o in scene if o is not obj):
            continue
        # "the tower" names the cubes in it (S-18 in the twin, 2026-10-25: "put it to the left of the tower" --
        # place_beside the tower's top, the red cube, was refused four times as not named) -- as where to put
        # something only: picking or moving one of them still needs it named
        pile_of = getattr(executor, "_pile_of", None)
        if (name in ("place_on", "place_beside", "place_between", "move_above") and TOWER_WORDS.search(prompt.lower())
                and pile_of is not None and len(pile_of(obj)) >= 2):
            continue
        if (name in ("place_on", "place_beside", "place_between", "move_above") and TOWER_WORDS.search(prompt.lower())
                and pile_of is not None and not any(len(pile_of(o)) >= 2 for o in scene)):
            # "put it to the left of the tower" with no tower on the table (V4.3: S-18 in the twin, 2026-10-25, after
            # S-17 built none): beside the green cube, refused five times the same, then it ended holding the cube
            put_down = (f" Put the {holding} down where it was (put_back) or out of the way (place_free), then tell"
                        if holding else " Tell")
            return (f"ERROR: not done. The user asked to put it by the tower, and there is no tower (no cube on another) "
                    f"on the table now (seen: {', '.join(sorted(o.label for o in scene)) or 'nothing'}). Don't use the "
                    f"{obj.label} instead.{put_down} the user there is no tower.")
        if holding and colour_of(holding) in named and name in ("place_on", "place_beside", "place_between"):
            missing = [c for c in named if c not in on_table and c != colour_of(holding)]
        else:
            missing = [c for c in named if c not in on_table]
        if missing:
            what = " or ".join(missing)
            return (f"ERROR: not done. The user asked for {_a(what)} {what} object, and there is no {what} one on the "
                    f"table (seen: {', '.join(sorted(o.label for o in scene)) or 'nothing'}). Don't use the "
                    f"{obj.label} instead: tell the user there is no {what} one, and do nothing else.")
        if holding and colour_of(holding) == colour_of(obj.label):
            return (f"ERROR: not done. You are holding the {obj.label}, which the user didn't name: it was only in the "
                    f"way. Put it down out of the way with place_free(where='outside'), then go on with the "
                    f"{', '.join(named)} one(s) (pick does that by itself too).")
        return (f"ERROR: not done. The user named only the {', '.join(named)} one(s); the {obj.label} wasn't asked "
                "for. Use the object(s) the user named.")
    return None


def _a(word: str) -> str:
    return "an" if word[:1] in "aeiou" else "a"


def _wrong_place(name, arguments, prompt, executor, task) -> Optional[str]:
    """A place the request doesn't name, when it names one that doesn't exist: "in the bin" with only a tray is
    said so, not done in the tray."""
    if name not in PLACE_TOOLS:
        return None
    given = str(arguments.get("place_name") or "").strip().lower()
    if not given:
        return None
    p = prompt.lower()
    places = executor._saved_places() if hasattr(executor, "_saved_places") else {}
    if re.search(r"\b" + re.escape(given) + r"\b", p) or any(re.search(r"\b" + re.escape(w) + r"\b", p)
                                                              for w in given.split() if w not in ("the", "a")):
        return None
    asked = [w for w in PLACE_WORDS if re.search(rf"\b{w}e?s?\b", p)]
    known = [w for w in asked if any(w in name_.split() for name_ in places)]
    missing = [w for w in asked if w not in known]
    if not missing:
        return None
    what = " or ".join(missing)
    return (f"ERROR: not done. The user asked for the {what}, and there is no place called that (places: "
            f"{', '.join(sorted(places)) or 'none'}). Don't use the {given} instead: tell the user there is no {what}, "
            "and ask where it should go.")


def _missing_place(name, arguments, prompt, executor, task) -> Optional[str]:
    """Nothing is picked for "put the red cube in the bin" when there is no bin: refused only at the place step, the
    cube was already in the gripper, and the model put it down somewhere else. ("box" is left out: it can be a cube.)"""
    if name not in ("pick", "put_all_in", "build_tower", "move_above"):
        return None
    p = prompt.lower()
    places = executor._saved_places() if hasattr(executor, "_saved_places") else {}
    if any(re.search(r"\b" + re.escape(place) + r"\b", p) for place in places):
        return None
    missing = [w for w in PLACE_WORDS if w != "box" and re.search(rf"\b{w}e?s?\b", p)
               and not any(w in place.split() for place in places)]
    if not missing:
        return None
    what = " or ".join(missing)
    return (f"ERROR: not done. The user asked for the {what}, and there is no place called that (places: "
            f"{', '.join(sorted(places)) or 'none'}). Pick nothing: tell the user there is no {what}, and ask where it "
            "should go.")


WHERE_WORDS = ("left", "right", "near", "nearer", "far", "further", "farther", "base", "outside", "middle", "centre",
               "center", "corner", "edge", "side", "spot", "table", "away", "next", "beside", "front", "behind")


def _unasked_tower_place(name, arguments, prompt, executor, task) -> Optional[str]:
    """build_tower told where to go when the request doesn't say where: "Build a tower with the green cube at the
    bottom, then the red cube, then the blue cube on top" was built near the base, away from where the green cube stood
    (the twin, S-17, 2026-10-24). Not said where, the bottom one stays where it is."""
    if name != "build_tower" or not (arguments.get("where") or arguments.get("place_name")):
        return None
    p = prompt.lower()
    places = executor._saved_places() if hasattr(executor, "_saved_places") else {}
    if (any(re.search(rf"\b{w}\b", p) for w in WHERE_WORDS + PLACE_WORDS)
            or any(re.search(r"\b" + re.escape(place) + r"\b", p) for place in places)):
        return None
    return ("ERROR: not done. The user didn't say where the tower goes, so it needs no place: call build_tower again "
            "without where or place_name -- the bottom one stays where it is." + _tower_call_hint(arguments, prompt,
                                                                                                 executor))


def _tower_call_hint(arguments: dict, prompt: str, executor) -> str:
    """The build_tower call to make, as the app plans the tower from the request (V4.3: S-17 in the twin, 2026-10-25:
    refused for an unasked place, with the order wrong too, Qwen read the refusal as "a place is needed" and gave up)."""
    from app.llm.tower_plan import tower_plan
    scene = _scene(executor)
    labels = {o.id: o.label for o in scene}
    given = [labels.get(i, i) for i in arguments.get("object_ids") or []]
    try:
        planned, impossible = tower_plan(prompt, [o.label for o in scene], given)
    except Exception:  # noqa: BLE001 - a hint is never worth failing a check over
        return ""
    if impossible or not planned:
        return ""
    ids = {o.label: o.id for o in scene}
    return (" Bottom to top it is: " + ", ".join(planned) + ", so call: build_tower(object_ids=["
            + ", ".join(ids.get(label, label) for label in planned) + "]).")


def _named_places(prompt: str, executor, words: str) -> list[str]:
    """The saved places the request names after `words` ("in the tray": words = in|into|inside)."""
    p = prompt.lower()
    places = executor._saved_places() if hasattr(executor, "_saved_places") else {}
    return [name for name in places
            if re.search(rf"\b(?:{words})\s+(?:the\s+|a\s+)?" + re.escape(name) + r"\b", p)]


def _place_left_out(name, arguments, prompt, executor, task) -> Optional[str]:
    """build_tower without the place the request names ("a tower of the three cubes in the tray": built where the
    green cube stood)."""
    if name != "build_tower" or arguments.get("place_name"):
        return None
    named = _named_places(prompt, executor, "in|into|inside|on|at")
    if not named:
        return None
    return (f"ERROR: not done. The user asked for the tower in the {named[0]}: call build_tower again with "
            f"place_name='{named[0]}'.")


OUT_OF = r"out of|from|outside(?:\s+of)?|not in|away from"


def _back_into_place(name, arguments, prompt, executor, task) -> Optional[str]:
    """Put back into the place the request says to take it out of ("Take the cube out of the tray": picked, then
    place_at the tray)."""
    if name not in PLACE_TOOLS:
        return None
    given = str(arguments.get("place_name") or "").strip().lower()
    if given and given in _named_places(prompt, executor, OUT_OF):
        if name == "build_tower":
            # "a tower with the cubes outside of the tray": built IN the tray
            return (f"ERROR: not done. The user asked for it OUTSIDE the {given}. Call build_tower again with "
                    "where='outside' instead of place_name.")
        return (f"ERROR: not done. The user asked to take it OUT of the {given}: don't put it back in. Put it down "
                "beside it with place_free('next_to', its id).")
    return None


def _wrong_row_order(name, arguments, prompt, executor, task) -> Optional[str]:
    """line_up with the colours in another order than named ("red, green and purple from left to right")."""
    if name != "line_up" or "small" in str(arguments.get("order") or "") or "larg" in str(arguments.get("order") or ""):
        return None
    named = named_colours(prompt)
    if len(named) < 2:
        return None
    p = prompt.lower()
    if re.search(r"right to (?:the )?left|far(?:thest)? to near|back to front", p):
        named = list(reversed(named))
    scene = _scene(executor)
    by_id = {o.id: o for o in scene}
    given = [colour_of(by_id[i].label) for i in _ids(arguments) if i in by_id]
    in_order = [c for c in given if c in named]
    if in_order == [c for c in named if c in in_order]:
        return None
    ids = {colour_of(o.label): o.id for o in scene}
    return ("ERROR: not done. The row asked for is, in order: " + ", ".join(named) + ". Call line_up with "
            "object_ids in that order (the first one goes leftmost): [" + ", ".join(ids.get(c, c) for c in named)
            + "].")


CLAUSE_SPLIT = re.compile(r",|;|\band\b|\bthen\b")


def directions_by_colour(prompt: str) -> dict[str, list[str]]:
    """Each named colour's own way to move, where the request gives each cube its own ("the red cube 40 mm nearer the
    robot and the blue cube 40 mm further": red towards, blue away) -- a part of the request naming one colour and
    a direction. {} where it doesn't say so part by part. (S-05, twin and Dobot: the check took both directions as
    asked for both cubes, so red sent forward passed, out of reach, and blue went back, out of the area.)"""
    out: dict[str, list[str]] = {}
    last = None
    for part in CLAUSE_SPLIT.split(prompt.lower()):
        colours, ways = named_colours(part), directions_asked(part)
        if len(colours) > 1:
            last = None                            # (two colours in one part: whose way it is isn't clear)
            continue
        if colours:
            last = colours[0]
        if last is not None and ways:              # ("... 20 mm right and 30 mm forward": both the red cube's)
            out.setdefault(last, [])
            out[last] += [w for w in ways if w not in out[last]]
    return out if len(out) > 1 else {}


def _wrong_direction(name, arguments, prompt, executor, task) -> Optional[str]:
    if name != "move_object":
        return None
    if RELATIVE_WORDS.search(prompt.lower()):      # ("left of the green cube", "a row from left to right": where it
        return None                                # goes is relative, not a move by -- any move may get it there)
    asked = directions_asked(prompt)               # (a move in two legs names both: either is what was asked)
    own = directions_by_colour(prompt)
    if own:                                        # (each cube its own way: this cube's)
        obj = next((o for o in _scene(executor) if str(getattr(o, "id", "")) in _ids(arguments)), None)
        colour = colour_of(obj.label) if obj is not None else None
        asked = own.get(colour, asked)
    given = DIRECTIONS.get(str(arguments.get("direction") or "").lower().replace(" ", "_"))
    if not asked or given is None or given in asked:
        return None
    return (f"ERROR: not done. The user asked to move it {' or '.join(DIRECTION_WORDS[a] for a in asked)}, and "
            f"direction '{arguments.get('direction')}' is {DIRECTION_WORDS[given]}. Use direction "
            + " or ".join(f"'{DIRECTION_WORDS[a].split()[0]}'" for a in asked) + ".")


SIDE_GIVEN = {"further": "front", "away": "front", "forward": "front", "far": "front", "nearer": "behind",
              "closer": "behind", "back": "behind", "near": "behind"}     # (place_beside's own words for them too)
RELATIVE_WORDS = re.compile(r"\b(?:of the|than the|between|line|row|swap|exchange)\b")


def sides_asked(prompt: str) -> list[str]:
    """The sides a "put it to the left of the red cube" request names, as place_beside says them: left, right (the
    robot's), front ("further from the robot than") and behind ("nearer the robot than"); [] if none."""
    p = prompt.lower()
    found = {"left": r"\bleft\b", "right": r"\bright\b",
             "front": r"\b(?:further|farther)\s+(?:away\s+)?from\s+(?:the\s+)?(?:robot|base|arm)\s+than\b|"
                      r"\bin front of\b",
             "behind": r"\b(?:nearer|closer)\s+(?:to\s+)?(?:the\s+)?(?:robot|base|arm)\s+than\b|\bbehind\b"}
    return [side for side, words in found.items() if re.search(words, p)]


def _wrong_side(name, arguments, prompt, executor, task) -> Optional[str]:
    """place_beside on another side than the one asked for. (The lab, 2026-10-11: "on the right side of the green
    cube, 30 mm gap" -- the right was too near the base, the tool said there was room on the left, and the cube went
    on the left.)"""
    if name != "place_beside":
        return None
    asked = sides_asked(prompt)                    # (several named: each step's own is one of them)
    given = str(arguments.get("side") or "").strip().lower()
    if not asked or not given or SIDE_GIVEN.get(given, given) in asked:
        return None
    if len(asked) > 1:
        return (f"ERROR: not done. The user asked for the {' and '.join(asked)} sides, and side '{given}' is none of "
                f"them. Use the side asked for this cube; if it can't be done, don't put it anywhere else: tell the "
                "user why.")
    asked = asked[0]
    return (f"ERROR: not done. The user asked for it on the {asked}, and side '{given}' isn't what they asked. "
            f"Use side='{asked}'; if the {asked} can't be done, don't put it anywhere else: tell the user why.")


TURN_WORDS = re.compile(r"\b(?:turn\w*|rotat\w*|spin\w*|twist\w*|angle\w*|straight\w*|align\w*|square\w*|"
                        r"parallel|orient\w*)\b")


def _unasked_turn(name, arguments, prompt, executor, task) -> Optional[str]:
    """A turn nobody asked for ("take the cube out of the tray" came with angle_deg=0: the cube was set straight)."""
    if name not in TURN_TOOLS or (arguments.get("turn_deg") is None and arguments.get("angle_deg") is None):
        return None
    if angle_asked(prompt) is not None or TURN_WORDS.search(prompt.lower()):
        return None
    return ("ERROR: not done. The user didn't ask for any turn: call it again without turn_deg and angle_deg.")


def _wrong_turn(name, arguments, prompt, executor, task) -> Optional[str]:
    """angle_deg for "turn it 45 degrees" (BY 45), or turn_deg for "at 45 degrees" (where it ends up)."""
    if name not in TURN_TOOLS:
        return None
    asked = angle_asked(prompt)
    if asked is None:
        return None
    kind, value = asked
    if kind == "by" and arguments.get("angle_deg") is not None and arguments.get("turn_deg") is None:
        return (f"ERROR: not done. The user asked to turn it BY {value:g} degrees (from where it is now): use "
                f"turn_deg={value:g}, not angle_deg.")
    if kind == "at" and arguments.get("turn_deg") is not None and arguments.get("angle_deg") is None:
        return (f"ERROR: not done. The user asked for it to end up AT {value:g} degrees: use angle_deg={value:g}, "
                "not turn_deg.")
    return None

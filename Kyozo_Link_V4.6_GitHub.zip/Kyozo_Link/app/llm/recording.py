"""Records what the robot tools make the arm do, for the Model tab: every move and gripper action, with where
the arm went, which route it took, how long it took, and each joint's angle before and after.

Joint angles come from the robot itself in live mode (it reports them after every move), and from the app's
model of the arm in demo mode. Only the demo can also look along the path for the point where a joint came
closest to its limit: the real controller does that check itself and just stops (alarm 0x22) if it has to.
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from app.hardware import motion
from app.hardware.interfaces import Pose
from app import robots

JOINTS = ("J1", "J2", "J3", "J4")   # the Dobot's; the robot this run drives: robots.active().joint_names
logger = logging.getLogger(__name__)


def _pose_tuple(pose: Optional[Pose]) -> Optional[list]:
    return None if pose is None else [round(pose.x, 1), round(pose.y, 1), round(pose.z, 1), round(pose.r, 1)]


def calculated_joints(pose: Pose) -> dict:
    robot = robots.active()
    joints = robot.joints(robot.geometry(pose.x, pose.y, pose.z, pose.r), pose.r)
    return {name: round(joints[name], 1) for name in robot.joint_names}


def limit_margin(joints: dict) -> tuple[str, float]:
    """(joint, degrees to its nearest limit) for the joint closest to a limit."""
    best = ("J1", 1e9)
    limits = robots.active().joint_limits_deg
    for name in [n for n in limits if n in joints]:
        low, high = limits[name]
        margin = min(joints[name] - low, high - joints[name])
        if margin < best[1]:
            best = (name, round(margin, 1))
    return best


class MoveRecorder:
    """Stands in for the robot inside the tools: passes every call through, and writes down the moves."""

    def __init__(self, robot):
        self._robot = robot
        self.moves: Optional[list] = None      # a list while a tool call is being recorded, else None

    def __getattr__(self, name):              # everything else (bounds, clamp_pose, held_object...) as is
        return getattr(self._robot, name)

    @property
    def joint_source(self) -> str:
        return f"reported by the {robots.active().short_name}" if hasattr(self._robot, "get_joints") else "calculated from the arm model"

    def _joints_now(self, pose: Optional[Pose]) -> Optional[dict]:
        reader = getattr(self._robot, "get_joints", None)
        try:
            if reader is not None:
                values = reader()
                return ({name: round(float(v), 1) for name, v in zip(robots.active().joint_names, values)}
                        if values else None)
            return calculated_joints(pose) if pose is not None else None
        except Exception:  # noqa: BLE001 - a missing reading must never stop the robot
            return None

    def _pose(self) -> Optional[Pose]:
        try:
            return self._robot.get_pose()
        except Exception:  # noqa: BLE001
            return None

    def _record(self, kind: str, action, target: Optional[Pose] = None, speed: Optional[float] = None):
        if self.moves is None:
            return action()
        before = self._pose()
        joints_before = self._joints_now(before)
        entry = {"kind": kind, "target": _pose_tuple(target), "from": _pose_tuple(before), "joints_before": joints_before,
                 "at": round(time.time(), 3)}
        if kind == "move":                        # the speed asked for: a slow approach's, or the arm's set speed
            setting = speed if speed is not None else getattr(self._robot, "max_speed", None)
            if setting is not None and type(self._robot).__name__ == "DobotRobot":
                setting = min(max(float(setting), 5.0), 500.0)     # (what the Dobot really gets: see _apply_speed)
            entry["speed_mm_s"] = round(float(setting), 1) if setting is not None else None
            entry["speed_from"] = "asked for this move" if speed is not None else "the arm's set speed"
        if kind == "move" and before is not None and target is not None:
            entry["route"] = "swings round the base" if motion.passes_near_base(before, target) else "straight"
            if not hasattr(self._robot, "get_joints"):     # demo: find the tightest point along the way
                tightest = ("J1", 1e9)
                for point in motion.path_points(before, target, 24):
                    joint, margin = limit_margin(calculated_joints(point))
                    if margin < tightest[1]:
                        tightest = (joint, margin)
                entry["tightest_on_path"] = list(tightest)
        started = time.monotonic()
        try:
            result = action()
        except Exception as exc:
            entry["error"] = str(exc)
            raise
        finally:
            entry["seconds"] = round(time.monotonic() - started, 2)
            after = self._pose()
            entry["to"] = _pose_tuple(after)
            entry["joints_after"] = self._joints_now(after)
            self._check_r(after, entry["joints_after"])
            self.moves.append(entry)
        return result

    def _check_r(self, pose: Optional[Pose], joints: Optional[dict]) -> None:
        """Live: the gripper's turning takes the Dobot's r to be J1 + J4 (see hardware/gripper.py). Checked against
        what the controller reports, once: if it isn't, the fingers would be lined up wrong on every pick."""
        if pose is None or not joints or not hasattr(self._robot, "get_joints") or getattr(self, "_r_checked", False):
            return
        self._r_checked = True
        gap = (pose.r - joints["J1"] - joints["J4"] + 180.0) % 360.0 - 180.0
        if abs(gap) > 2.0:
            logger.error("The Dobot reports r = %.1f with J1 = %.1f and J4 = %.1f: r is not J1 + J4 on this robot, "
                         "so the gripper would be turned wrong. Tell the developer (hardware/gripper.py).",
                         pose.r, joints["J1"], joints["J4"])
        else:
            logger.info("Checked on the Dobot: r = J1 + J4 (r %.1f, J1 %.1f, J4 %.1f)", pose.r, joints["J1"], joints["J4"])

    def move_to(self, pose: Pose, speed: Optional[float] = None):
        return self._record("move", lambda: self._robot.move_to(pose, speed) if speed is not None
                            else self._robot.move_to(pose), target=pose, speed=speed)

    def open_gripper(self):
        return self._record("open gripper", self._robot.open_gripper)

    def close_gripper(self):
        return self._record("close gripper", self._robot.close_gripper)

    def home(self):
        return self._record("home", self._robot.home)

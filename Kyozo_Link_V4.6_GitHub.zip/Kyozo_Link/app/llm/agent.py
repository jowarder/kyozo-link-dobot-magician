"""Prompt -> tool-call loop: sends the user prompt + tool schema to the LLM via Ollama,
dispatches tool calls, and repeats until the model finishes or the step cap is hit.
"""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

from app.hardware.interfaces import RobotStopped
from app.llm.ollama_client import OllamaClient
from app.llm.request_checks import check_step, wants_slow
from app.llm.tools import TOOL_SCHEMAS, ToolExecutor
from app.llm.tower_plan import tower_plan
from app.llm.trace import tower_order
from app.llm.trace import PromptTrace

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You control a robot arm with a camera above the workbench.
Use the provided tools to complete the user's request.
Rules:
- Every request is something to DO, even a short one without a verb: "red cube in the tray" = put the red
  cube in the tray; "yellow on purple" = put the yellow cube on the purple cube. Do every part of it
  ("X in the tray, Y on top" is two moves) before you reply, and never say something is done unless the
  tool results show it.
- The app looks at the table for you before your first answer: the result of list_objects comes with the request.
  Call list_objects again only after a step failed, or when the table may have changed. Never invent coordinates.
- FEW ANSWERS: each answer takes a long time on this PC. When you know every step from what is listed, call them ALL
  in ONE answer, in order, and done() last ("swap A and B, then turn A 30 degrees" = swap, turn_object, done in one
  answer). If a step fails, the steps after it in that answer are not run: you get the results and decide again.
- done(): call it after your last step, in the same answer, when those steps complete the WHOLE request. The app
  then tells the user what was done: write no reply. If any part can't be done, don't call done: reply in plain text.
- Only use object ids that list_objects returned. Match the object the user named by its colour and kind
  (labels are "colour kind": cube, block, bar, cylinder, ball, disc, flat piece; "wooden" = brown; a "box" or
  "block" can be a cube). People use everyday names: a pen, pencil, stick or rod = a bar; a can, tube or bottle
  = a cylinder; a sphere = a ball; a coin = a disc. "Pen in the tray" with a blue bar listed = the blue bar. If
  two objects fit the name, ask which one; if none matches, say so and do not move.
- To go near an object use move_above(object_id); to pick it up use pick(object_id).
- "it" means the object you are holding (see State, with the request); if you hold nothing, it means the
  last object you moved. If you hold something, do not pick another object.
- To put it down use place_at(place_name) with a name from saved_places: a tray or bin, or a spot or
  zone marked on the table ("spot 3"), or place_on(object_id) to stack it on an object.
- A SAVED PLACE is never an object: "put A on spot 3" / "move A to spot 3" / "A in zone a" (any name
  listed in saved_places) = pick(A), then place_at("spot 3"). Look the name up in saved_places, exactly
  as written there; only if it isn't listed, say so.
- "put A on B" / "put A on top of B" / "stack A on B" (B an object): the object being MOVED is A (the one
  named first). Do pick(A), then place_on(B). Never swap them. Example: "put the red block on the blue
  block" = pick(red cube), then place_on(blue cube).
- BESIDE is not ON TOP: "put A on the right/left side of B", "to the right of B", "next to B",
  "beside B", "N mm from B", "in front of / behind B" = pick(A), then place_beside(B, side, gap_mm).
  Example: "put the red cube on the right side of the blue cube, 10 mm apart" = pick(red cube),
  then place_beside(blue cube, "right", 10). Left/right/front/behind are the robot's own directions.
- "put A in/at the tray" = pick(A), then place_at("tray"). If A is already held, just place_at.
- SEVERAL objects into one tray or bin ("everything", "all the cubes", "both", "these", "A, B and C in the
  tray") = ONE call: put_all_in(place_name, [every one of their ids]). It plans and does it all, and says
  what didn't fit: tell the user that. Don't pick and place them one by one. put_all_in puts them SIDE BY
  SIDE: it never builds a tower (see TOWER).
- SIZE: each object's height_mm (from list_objects) is its own size. "small"/"smaller" = lower height_mm,
  "large"/"big"/"bigger" = higher height_mm. Compare the numbers; the label only gives the colour.
  When sizes differ, "where" says "small" or "large" for each: use it ("small cubes in the small bin").
  footprint_mm is [narrow side, long side] seen from above ("wide", "long", "flat" compare these).
- An object listed with gripper: "too wide ..." cannot be picked up: do not call pick on it; tell the user
  why (its width and the gripper's opening, as given). The tool turns the gripper and chooses how to hold
  it by itself.
- A TOWER / STACK / PILE of several objects = ONE call: build_tower([their ids, BOTTOM FIRST]), with
  place_name if the user said where ("in the tray"), and angle_deg / turn_deg if they asked for an angle.
  Never put_all_in for a tower. "Build a tower" (no number) and "using all the cubes" = every cube listed.
  "A is the third block" counts from the BOTTOM. Decide the whole order before the call. Describe the tower
  in the order the tool gives, bottom to top. A tower outside the tray / on the table: where="outside" (or
  left, right, near_base, far), never place_name="tray". To move or rebuild a tower, call build_tower again:
  it takes the pile apart first. (To add one object to an existing pile: pick it, then place_on its top.)
- TURN / ROTATE is not moving: "turn the brown block 70 degrees" = turn_object([its id], turn_deg=70) (BY 70;
  anticlockwise seen from above, "clockwise" = negative). "the cubes should be AT 45 degrees" / "set them to 45
  degrees" = turn_object([every cube's id], angle_deg=45) -- ONE call for all of them, never put_all_in. To
  put something down turned ("put it in the tray at 45 degrees", "take the cubes out and put them at 45
  degrees") add turn_deg (by) or angle_deg (at) to that place tool. Only when the user asks for a turn.
  "the same angle as B", "turn A like B", "make A's angle similar to B" = turn_object([A's id], like_id=B's id).
  turn_object also turns the object you are holding (it puts it back, turned, where it was picked up).
- To put it on an empty part of the table ("outside the tray", "close to the robot base",
  "on the left", "to the side", "away") use place_free(where): near_base, far, left, right,
  center, or next_to with object_id. Never make up x/y numbers for this.
- An object listed with covered_by has something on top of it: just pick(it) as usual, the tool
  moves the top object aside itself. An object under "hidden" cannot be seen: pick(the object on
  top of it, see "under"), place_free(...), list_objects again, then pick the one the user asked for.
- A ROW / LINE ("line up the cubes", "arrange them by size", "in a row, 3 cm apart") = ONE call:
  line_up([ids], order=given/smallest_first/largest_first, gap_mm). Not place_free one by one.
- MOVE BY a distance ("move the red cube 5 cm left", "push it a bit forward") = move_object(id, direction,
  distance_mm): left, right, forward (away from the robot: further), back (towards the robot: nearer, closer).
  "40 mm nearer the robot" = direction back. "a bit" = 20 mm.
- LET IT DROP / FALL ("lift it 40 mm ... and let it drop") = ONE call: drop(id, height_mm, and direction and
  distance_mm if it is to move first). It picks it up first if it isn't held. Don't use move_to for it.
  Dropped BESIDE another object ("50 mm above the table to the right of B, with a 50 mm gap, and let it drop") =
  drop(id, height_mm=50, beside_id=B, side, gap_mm). Not move_object first: drop moves it.
- Units: tools take mm. 1 cm = 10 mm, 1 inch = 25.4 mm ("5 cm" = 50, "2 inches" = 51).
- ONE cube taken off a pile and put somewhere ("take A off the tower and put it to the left of the tower", "take
  the tower apart: put A to the left of B") = pick(A), then place_beside(B, "left", gap) (B = the cube it stood
  on). Not take_apart: that moves EVERY cube in the pile. Never pick the bottom one of a pile for this.
- "take the tower/pile apart", "unstack" (no place said for one cube) = take_apart(any id in it). "empty the
  tray", "take everything out of the tray" = empty_place("tray"). "between A and B" = pick(it),
  place_between(A, B). "swap A and B" = swap(A, B). "put it back", "undo that", "put everything back" =
  put_back (it knows where things were).
- "take A out of the tray/bin" = pick(A), then place_free("next_to", A's id): never leave it in the gripper.
- "slowly", "carefully", "gently": the app slows the arm down itself; just do the task.
- If the user names an object or place that is not listed (no yellow cube, no bin), say so and do nothing:
  never use another one instead.
- "do it again", "same again", "now the blue one": repeat the previous request (given with the request), changed as asked.
- An object's "where" (from list_objects) says leftmost / rightmost / nearest the robot / farthest / in the
  tray / on the X: use it for "the one on the left", "the nearest cube", "the cube in the tray".
- An object under "not_seen_now" (from list_objects) was seen before and isn't now (out of the camera's view, or
  moved by hand): say that, in those words; don't say it isn't there. It can't be picked.
- If a tool returns an ERROR, do not retry with made-up values; report it to the user, giving the reason the
  ERROR gives, in its words. Never give another reason of your own (e.g. "too wide") that no tool result said.
- If no tool can do exactly what was asked, say so; do not do something else instead.
- A request with several parts ("move the red cube ... and the blue cube ...", "swap them, then turn one"): if one
  part can't be done, still do every other part that doesn't depend on it -- but not a part that only makes sense
  after the one that failed (the next level of a tower whose lower one failed). Do as much as can be done SAFELY.
- After a pick, place or move that failed, call list_objects before anything else: the table may have changed.
  Never act on an object whose place you don't know now.
- Stop at once, doing nothing more, after an alarm, E-STOP or "Stopped by you". Otherwise never end holding an
  object: put it down (place_free) before your reply.
When finished without done(), reply with plain text summarizing what you did (no further tool call): which parts
were done and which weren't, and why (the tool's own reason). Only state what the tool results say, with their
numbers: never claim a distance or position they don't give."""


STOPPED = "Stopped by you. Nothing further was done."
GO_AHEAD = "Go ahead: call the tool now. Don't say what you will do, do it."
# it ended with the cube still in the gripper: "Take the cube out of the tray" -> pick, and "The red cube was taken from
# the tray"
# ...but one that says it couldn't is not pushed on into more moves
GIVES_UP = re.compile(r"\b(?:could not|couldn't|cannot|can't|unable|not able|failed|stopped|alarm|e-stop)\b",
                      re.IGNORECASE)
# "The tower is dismantled", with the tower still standing (it looked, and then just replied): sent back once, with
# what the app's own check found
TOO_LONG = ("Your answer ran on too long and was cut off. Answer with tool calls only, no explanation: the next step "
            "(or steps), or done() if the request is done.")
TOO_LONG_STOP = "Stopped: the model's answers ran on too long twice (cut off at the answer limit)."
NOT_DONE = ("Not done yet, as the app checked it: {detail}. Do it now with the tools, then reply. If it can't be "
            "done, say why.")
ADMITS = re.compile(r"\b(?:not|couldn't|could not|cannot|can't|unable|failed|left out|stopped|only)\b", re.IGNORECASE)
STILL_HOLDING = ("You are still holding the {held}. Put it down where the user asked (\"out of the tray\" = "
                 "place_free next_to, beside the tray), then reply.")
MAX_REFUSALS = 4   # steps refused by the guards (see Agent._guard) before the prompt is ended
# asked for a tower, the model called put_all_in (it lays things side by side): not done, and told how
NOT_A_TOWER = ("ERROR: not done. The user asked for a TOWER (one pile), and put_all_in only puts objects side "
               "by side. Build it with ONE call: build_tower([the ids, bottom first], place_name if they said where, "
               "angle_deg if they asked for an angle).")
MAX_NUDGES = 2
# "I turned it to a 45-degree angle" -- when the turn had failed and nothing else turned it: sent back once
CLAIMS_TURN = re.compile(r"\b(?:turned|rotated|twisted)\b|\b\d+\s*(?:°|-?\s*degrees?)\b", re.IGNORECASE)
TURN_DONE = re.compile(r"\bTurned (?!0 of)|\bTurned by\b|\bSet at\b|\bturned [+-]?\d")
NOT_TURNED = ("Your reply says something was turned, but no tool turned anything in this request{why}. Either turn "
              "it now with turn_object (it can turn what you hold too), or tell the user it was NOT turned, and why.")
# "The red and blue cubes were swapped" -- when the swap had been refused and nothing swapped them (study 3, S-10)
CLAIMS_SWAP = re.compile(r"\b(?:swapped|switched places|exchanged)\b", re.IGNORECASE)
SWAP_DONE = re.compile(r"^Swapped the ")
NOT_SWAPPED = ("Your reply says they were swapped, but no swap was done in this request{why}. Either swap them now "
               "(list_objects, then swap with the ids it gives), or tell the user they were NOT swapped, and why.")
# V4.3: fewer model turns. On the laptop's CPU each answer took 5-25 s (study 1, Dobot: 47-177 s of Qwen a run, in
# 3-6 turns). The app looks first (list_objects, the turn every prompt began with), the model may give every step in
# one answer, and done() after the last step ends the prompt without a turn for the summary.
DONE = "done"
NOT_RUN = ("NOT RUN: an earlier step in this answer failed, so this one wasn't done. Decide again from the results "
           "above.")
# a step that didn't do what it was called for: refused, not run, or "Turned 0 of 1" (the turn left undone)
_FAILED = re.compile(r"^(?:ERROR|NOT RUN)|^\w+ 0 of \d+\b")
NOT_DONE_YET = "NOT DONE YET, as the app checked it: {detail}. Do it now with the tools, then done()."
SUMMARY_SKIPS = {"list_objects", "set_speed", DONE}
SAYS_DONE = re.compile(r"^\s*[`*\"']*done(?:\(\s*\))?[`*\"'.!]*\s*$", re.IGNORECASE)
# the same step sent again after it was refused (S-18 in the twin, 2026-10-25: one place_beside five times, 236 s)
REPEATED = (" You sent exactly this step before and it was refused the same way: don't send it again. Do something "
            "else, or, if the request can't be done, put down what you hold (put_back or place_free) and tell the user "
            "why.")


def step_failed(result) -> bool:
    return bool(_FAILED.search(str(result or "")))


def app_summary(steps: list) -> str:
    """The reply when the model ends with done(): what each step that did something said, in order."""
    said = [str(s.result).strip() for s in steps if s.tool_name not in SUMMARY_SKIPS and not step_failed(s.result)]
    return " ".join(said) if said else "Done: nothing needed moving."


_ANNOUNCES = re.compile(r"\b(let me|let's|i will|i'll|i am going to|i'm going to|first,? i|next,? i|now,? i)\b",
                        re.IGNORECASE)


def announces_action(text: str) -> bool:
    """A reply that says what it is about to do ("Let me first list the objects") rather than a finished answer. Not
    one that asks you something ("Which cube do you mean? I'll move it then"): that is for you to answer."""
    return bool(_ANNOUNCES.search(text or "")) and "?" not in (text or "")


def claims_turn_not_done(reply: str, steps: list) -> bool:
    """The reply says something was turned, nothing in this request's steps turned anything, and the reply doesn't
    own up to it ("couldn't turn it")."""
    if not CLAIMS_TURN.search(reply or "") or ADMITS.search(reply or ""):
        return False
    return not any(TURN_DONE.search(step.result or "") for step in steps
                   if not str(step.result or "").startswith("ERROR"))


def claims_swap_not_done(reply: str, steps: list) -> bool:
    """The reply says something was swapped, no step in this request swapped anything, and the reply doesn't own up
    to it."""
    if not CLAIMS_SWAP.search(reply or "") or ADMITS.search(reply or ""):
        return False
    return not any(SWAP_DONE.search(str(step.result or "")) for step in steps)


# Steps that only look: step-by-step mode doesn't stop to ask about these.
NO_APPROVAL_NEEDED = {"list_objects", "set_speed", DONE}


@dataclass
class AgentStep:
    tool_name: str
    arguments: dict
    result: str


@dataclass
class AgentRun:
    steps: list = field(default_factory=list)
    final_message: str = ""
    trace: dict = field(default_factory=dict)   # everything the Model tab shows (see trace.py)


class Agent:
    def __init__(self, client: OllamaClient, executor: ToolExecutor, model: str,
                 max_tool_calls: int = 8, temperature: float = 0.2, look_first: bool = True):
        self.client = client
        self.executor = executor
        self.model = model
        self.look_first = look_first     # the app calls list_objects before the model's first answer (V4.3)
        self._refused_before: set = set()
        self.max_tool_calls = max_tool_calls
        self.temperature = temperature
        # for the Model tab: the mode, scene and so on at the time of a prompt (set by the main window)
        self.describe_setup: Optional[Callable[[], dict]] = None
        self._stop = threading.Event()   # the running prompt's: each run has its own (see cancel)
        self.in_tool = False             # a tool is running (the arm may be moving), perhaps for an ended prompt
        self.previous_prompt = ""        # the last prompt's words, for "do it again" / "same with the blue one"

    def cancel(self) -> None:
        """End the running prompt: nothing more is done once the model's pending answer comes back, and no further
        tool is run (a move under way finishes, unless E-STOP stops it). The run's own event is set, so a new prompt
        started meanwhile isn't affected."""
        self._stop.set()

    def run(self, user_prompt: str, on_step: Optional[Callable[[AgentStep], None]] = None,
            approve: Optional[Callable[[str, dict], str]] = None,
            on_trace: Optional[Callable[[dict], None]] = None) -> AgentRun:
        """Runs the tool-calling loop. `on_step(AgentStep)` is called after each tool
        executes, so the UI can log progress live. `approve(tool name, arguments)`, if given (step-by-step
        mode), is asked before each step that moves the robot and answers "go" (this step), "all" (this and
        every step after it) or "stop" (end the task here, nothing more is done). `on_trace(record)` gets the
        Model tab's record of the prompt after every turn (a copy, safe to keep)."""
        begin_run = getattr(self.executor, "begin_run", None)
        if begin_run is not None:
            begin_run()
        # Each prompt starts fresh, so tell the model what the gripper holds: "put it
        # down" / "put it on the tray" only make sense if it knows what "it" is.
        # It goes with the request, not at the end of the instructions: the instructions and the tools then read the
        # same every time and Ollama reuses its work on them. Changed every prompt, the ~5,600 tokens were read again
        # from scratch -- some 2-3 minutes on a PC without a graphics card, and answers timed out.
        status = getattr(self.executor, "status_text", None)
        context = f"State: {status()}." if status else ""
        if self.previous_prompt:
            context += f'\nThe previous request was: "{self.previous_prompt}".'
        self.previous_prompt = user_prompt.strip()[:200]
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": (context.strip() + "\n\nRequest: " if context.strip() else "") + user_prompt},
        ]
        run = AgentRun()
        trace = self._new_trace(user_prompt, SYSTEM_PROMPT + ("\n\n" + context.strip() if context.strip() else ""))
        stop = self._stop = threading.Event()       # cancel() sets this one: this run's
        if hasattr(self.executor, "should_stop"):
            self.executor.should_stop = stop.is_set   # (a long tool call, put_all_in, ends between objects)
            self.executor.request = user_prompt       # (the tools: what the user asked -- place_on clears a cube in
                                                      # the way only when the request doesn't name it)

        def report() -> None:
            run.trace = trace.data
            if on_trace is not None:
                on_trace(trace.snapshot())

        def finish(final_message: str) -> AgentRun:
            self.executor.request = ""             # (a tool called outside a prompt isn't judged by this one)
            end_run = getattr(self.executor, "end_run", None)
            if end_run is not None:
                end_run()                   # a speed set for this prompt (set_speed) goes back
            run.final_message = final_message
            trace.finish(final_message, self.executor)
            report()
            return run

        if wants_slow(user_prompt) and hasattr(self.executor, "_tool_set_speed"):
            # "Carefully stack the blue cube on the green cube": the model went at full speed
            try:
                result = self.executor.execute("set_speed", {"speed": "slow"})
            except Exception as exc:  # noqa: BLE001 - not slowing down is no reason not to do the task
                result = f"ERROR: {exc}"
            step = AgentStep(tool_name="set_speed", arguments={"speed": "slow", "by": "the app"}, result=result)
            run.steps.append(step)
            if on_step:
                on_step(step)
        nudges = 0
        refusals = 0
        too_long = 0
        self._refused_before = set()        # (name and arguments of each step refused in this prompt)
        if self.look_first and hasattr(self.executor, "_tool_list_objects"):
            # the look every prompt began with, done by the app: one model turn fewer (5-11 s on the laptop). It goes
            # in as the model's own call and its result, so the model reads it as if it had asked.
            message = {"role": "assistant", "content": "",
                       "tool_calls": [{"function": {"name": "list_objects", "arguments": {}}}]}
            turn = trace.model_turn(message, {}, 0.0, getattr(self.executor, "holding", None),
                                    status() if status else "")
            turn["by"] = "the app"
            messages.append(message)
            outcome = self._run_call("list_objects", {}, turn, 0, run, on_step, trace, None)
            if outcome.get("finish") is not None:
                return finish(outcome["finish"])
            messages.append({"role": "tool", "content": outcome["result"]})
            report()
        for _ in range(self.max_tool_calls):
            asked = time.monotonic()
            message = self.client.chat(self.model, messages, tools=TOOL_SCHEMAS,
                                        temperature=self.temperature)
            turn = trace.model_turn(message, dict(getattr(self.client, "last_stats", None) or {}),
                                    time.monotonic() - asked, getattr(self.executor, "holding", None),
                                    status() if status else "")
            report()
            if stop.is_set():
                return finish(STOPPED)
            tool_calls = message.get("tool_calls") or []
            if not tool_calls and (getattr(self.client, "last_stats", None) or {}).get("stop_reason") == "length":
                # cut off at the answer limit (it ran on and on): told once, then the prompt ends -- a failed turn, not
                # a 400 s wait counted as the PC's fault (V4.2)
                too_long += 1
                if too_long > 1:
                    cut = (message.get("content") or "").strip()
                    return finish(f"{cut} [cut off at the answer limit]" if cut else TOO_LONG_STOP)
                turn["nudged"] = TOO_LONG
                messages.append({"role": "user", "content": TOO_LONG})
                continue
            if not tool_calls:
                messages.append(message)
                if SAYS_DONE.match(message.get("content") or ""):
                    # "done()" written as the answer, not called (Qwen, every prompt of the V4.3 twin chain): the same
                    # as the call -- the app checks, and the user is told what was done, not "done()"
                    unmet = self._not_done_yet(trace, nudges)
                    if unmet is None:
                        return finish(app_summary(run.steps))
                    nudges += 1
                    turn["nudged"] = unmet
                    messages.append({"role": "user", "content": unmet})
                    continue
                if nudges < MAX_NUDGES and announces_action(message.get("content", "")):
                    # "Let me first list the objects." -- and nothing called: the model stopped at saying what it
                    # would do. Taken as its answer, "Sort the cubes by colour" ended there, every time.
                    nudges += 1
                    turn["nudged"] = GO_AHEAD
                    messages.append({"role": "user", "content": GO_AHEAD})
                    continue
                held = getattr(self.executor, "holding", None)
                if (nudges < MAX_NUDGES and held and isinstance(held, str)
                        and trace.data.get("understood", {}).get("task") != "pick up"
                        and not GIVES_UP.search(message.get("content", "") or "")):
                    nudges += 1
                    turn["nudged"] = STILL_HOLDING.format(held=held)
                    messages.append({"role": "user", "content": turn["nudged"]})
                    continue
                reply = message.get("content", "") or ""
                if nudges < MAX_NUDGES and claims_turn_not_done(reply, run.steps):
                    nudges += 1
                    failed = [s.result for s in run.steps if s.tool_name == "turn_object" and s.result.startswith("ERROR")]
                    turn["nudged"] = NOT_TURNED.format(why=f" (turn_object said: {failed[-1]})" if failed else "")
                    messages.append({"role": "user", "content": turn["nudged"]})
                    continue
                if nudges < MAX_NUDGES and claims_swap_not_done(reply, run.steps):
                    nudges += 1
                    failed = [s.result for s in run.steps if s.tool_name == "swap" and step_failed(s.result)]
                    turn["nudged"] = NOT_SWAPPED.format(why=f" (swap said: {failed[-1]})" if failed else "")
                    messages.append({"role": "user", "content": turn["nudged"]})
                    continue
                goal = trace.goal_now(self.executor) if nudges < MAX_NUDGES else {}
                # (a question is for you to answer: "Which cube do you mean?" isn't pushed on)
                if goal.get("status") == "not met" and not ADMITS.search(reply) and "?" not in reply:
                    nudges += 1
                    turn["nudged"] = NOT_DONE.format(detail=goal.get("detail", "it isn't done"))
                    messages.append({"role": "user", "content": turn["nudged"]})
                    continue
                return finish(message.get("content", ""))

            messages.append(message)
            failed_here = False
            for index, call in enumerate(tool_calls):
                name = call["function"]["name"]
                raw_args = call["function"].get("arguments", {})
                try:
                    arguments = raw_args if isinstance(raw_args, dict) else json.loads(raw_args)
                except (TypeError, ValueError):
                    arguments = None
                if stop.is_set():
                    return finish(STOPPED)
                if failed_here:
                    # a step after one that failed, in the same answer: it was planned for a table that isn't there
                    trace.app_result(turn, index, NOT_RUN, None, self._joint_source(), stopped="not run")
                    messages.append({"role": "tool", "content": NOT_RUN})
                    continue
                if not isinstance(arguments, dict):
                    result = f"ERROR: the arguments of {name} weren't readable JSON: {str(raw_args)[:120]}"
                    step = AgentStep(tool_name=name, arguments={}, result=result)
                    run.steps.append(step)
                    if on_step:
                        on_step(step)
                    trace.app_result(turn, index, result, None, self._joint_source())
                    messages.append({"role": "tool", "content": result})
                    failed_here = True
                    continue
                if name == DONE:
                    unmet = self._not_done_yet(trace, nudges)
                    if unmet is None:
                        trace.app_result(turn, index, "Finished: the app tells the user.", None, self._joint_source())
                        return finish(app_summary(run.steps))
                    nudges += 1
                    turn["nudged"] = unmet
                    trace.app_result(turn, index, unmet, None, self._joint_source())
                    messages.append({"role": "tool", "content": unmet})
                    break
                outcome = self._run_call(name, arguments, turn, index, run, on_step, trace, approve)
                if outcome.get("finish") is not None:
                    return finish(outcome["finish"])
                if outcome.get("approve_all"):
                    approve = None
                if outcome.get("refused"):
                    refusals += 1
                    if refusals > MAX_REFUSALS:
                        # it went round in circles: picked the same cube off the tower and put it back, for minutes
                        return finish("Stopped: the model kept trying steps that don't build what was asked for "
                                      f"(refused {refusals} times). Nothing further was done; see the Model tab.")
                messages.append({"role": "tool", "content": outcome["result"]})
                failed_here = step_failed(outcome["result"])
        return finish(f"Stopped after reaching the {self.max_tool_calls}-step limit.")

    def _not_done_yet(self, trace, nudges: int) -> Optional[str]:
        """done() called: what is still to do, for the model (the checks a reply gets), or None to finish."""
        if nudges >= MAX_NUDGES:
            return None
        held = getattr(self.executor, "holding", None)
        if held and isinstance(held, str) and trace.data.get("understood", {}).get("task") != "pick up":
            return STILL_HOLDING.format(held=held).replace("then reply", "then done()")
        goal = trace.goal_now(self.executor)
        if goal.get("status") == "not met":
            return NOT_DONE_YET.format(detail=goal.get("detail", "it isn't done"))
        return None

    def _run_call(self, name: str, arguments: dict, turn: dict, index: int, run: AgentRun, on_step, trace,
                  approve) -> dict:
        """One step: asked about (step-by-step mode), checked by the guards, done. Returns {"result"}, with "refused"
        (a guard said no), "approve_all" (Go for all) or "finish" (the prompt ends here, with this reply)."""
        def record(result: str, details: Optional[dict] = None, stopped: str = "") -> None:
            step = AgentStep(tool_name=name, arguments=arguments, result=result)
            run.steps.append(step)
            if on_step:
                on_step(step)
            trace.app_result(turn, index, result, details, self._joint_source(), stopped=stopped)

        out: dict = {}
        if approve is not None and name not in NO_APPROVAL_NEEDED:
            decision = approve(name, arguments)
            if decision == "all":
                out["approve_all"] = True
            elif decision != "go":
                record("ERROR: stopped by you before this step (step-by-step mode).", stopped="by you")
                return {"finish": "Stopped by you before this step. Nothing further was done."}
        key = name + json.dumps(arguments, sort_keys=True, default=str)
        refusal = self._guard(name, arguments, trace)
        if refusal:
            if key in self._refused_before:
                refusal += REPEATED
            self._refused_before.add(key)
            record(refusal)
            return {**out, "result": refusal, "refused": True}
        held_up = self._needs_person()
        if held_up:
            record(f"ERROR: {held_up}", stopped="needs a person")
            return {"finish": f"Stopped before {name}: the arm needs a person. {held_up}"}
        try:
            self.in_tool = True             # (a new prompt waits for this: one thread drives the arm)
            result = self.executor.execute(name, arguments)
        except RobotStopped as exc:
            # Not something for the model to work around: whoever pressed E-STOP wants it to stop,
            # and must not have the run carry on the moment they reset it.
            record(f"ERROR: {exc}", getattr(self.executor, "last_record", None), stopped="E-STOP")
            return {"finish": "Stopped: the robot was E-stopped. Nothing further was done."}
        except Exception as exc:  # noqa: BLE001 - surface tool errors back to the model
            result = f"ERROR: {exc}"
            logger.exception("Tool %s failed", name)
        finally:
            self.in_tool = False
        held_up = self._needs_person()
        if held_up:
            # nor this: the arm lost its homing, its link or is stuck in alarm -- the model trying again (study 2,
            # S-08_Run1: swap, then pick, over and over, while the arm went 64 degrees round from where it was sent)
            # can only make it worse
            record(result, getattr(self.executor, "last_record", None), stopped="needs a person")
            return {"finish": f"Stopped: the arm needs a person. {held_up} Nothing further was done."}
        record(result, getattr(self.executor, "last_record", None))
        return {**out, "result": result}

    def _needs_person(self) -> Optional[str]:
        """Why the arm can't go on until a person acts (the Dobot's needs_person), or None."""
        try:
            why = getattr(getattr(self.executor, "robot", None), "needs_person", None)
        except Exception:  # noqa: BLE001 - asking must never break a prompt
            return None
        return why if isinstance(why, str) and why else None     # (the twin has none; a test's stand-in, no text)

    def _guard(self, name: str, arguments: dict, trace) -> Optional[str]:
        """A step that plainly doesn't build what was asked for, not done: why, and what to do instead (for the
        model), or None to go ahead."""
        task = trace.data.get("understood", {}).get("task", "")
        refusal = check_step(name, arguments, trace.data.get("prompt", ""), self.executor, task)
        if refusal:
            return refusal
        if task != "build a tower":
            return None
        if name == "put_all_in":
            # "make a tower in the tray": put_all_in found both cubes already in it, and the model said nothing
            # needed doing
            return NOT_A_TOWER
        if name == "build_tower":
            return self._tower_call_guard(arguments, trace)
        return self._tower_order_guard(name, arguments, trace)

    def _tower_call_guard(self, arguments: dict, trace) -> Optional[str]:
        """build_tower other than asked for -- in another order ("red at the bottom, then yellow..."), with a cube in
        another place ("purple at the third" was built second), or not with all of them ("a tower", "all the
        cubes": blue was left out): not done, and the model given the ids in the order the app worked out (the
        objects the request doesn't place, in the model's own order). One that can't be built as asked is said so."""
        scene = list(getattr(self.executor, "_last_scene", []) or [])
        labels = {o.id: o.label for o in scene}
        given = [labels.get(i, i) for i in arguments.get("object_ids") or []]
        planned, impossible = tower_plan(trace.data.get("prompt", ""), [o.label for o in scene], given)
        if impossible:
            return f"ERROR: not done. {impossible} Tell the user, and build nothing."
        if not planned or given == planned:
            return None
        ids = {o.label: o.id for o in scene}
        return ("ERROR: not done. The tower asked for is, bottom to top: " + ", ".join(planned) + ". Call build_tower "
                "with object_ids in that order: [" + ", ".join(ids.get(label, label) for label in planned) + "].")

    def _tower_order_guard(self, name: str, arguments: dict, trace) -> Optional[str]:
        """For a tower asked for in a given order ("Tower: red, yellow, green, blue, purple" was built red, blue,
        green, yellow, purple): only the next object is picked, and put on the top of the tower so far; the bottom
        one goes on the table or a place, not on another object; and what is in the wrong place on (or under) the
        bottom one comes off first, from the top. Otherwise not done, and the model told the next step."""
        if name not in ("pick", "place_on"):
            return None
        scene = list(getattr(self.executor, "_last_scene", []) or [])
        piles = self.executor.piles() if hasattr(self.executor, "piles") else []
        holding = getattr(self.executor, "holding", None)
        seen = [o.label for o in scene]
        out_of_sight = {label for p in piles for label in p} | ({holding} if holding else set())
        order = tower_order(trace.data.get("prompt", ""), seen + sorted(out_of_sight - set(seen)))
        if not order:
            return None
        asked = f"The tower asked for is, bottom to top: {', '.join(order)}."
        ids = {o.label: o.id for o in scene}
        named = next((o.label for o in scene if o.id == arguments.get("object_id")), None)
        base = order[0]
        if holding == base:
            if name == "place_on":
                # it put the red cube (the bottom) on the purple one, and the tower grew on the purple cube
                return (f"ERROR: not done. {asked} The {base} is its bottom: put it down with place_at (the place "
                        "asked for) or place_free, not on another object.")
            return None
        pile = next((p for p in piles if base in p), [base])
        under, above = pile[:pile.index(base)], pile[pile.index(base):]
        good = 0
        while good < min(len(above), len(order)) and above[good] == order[good]:
            good += 1
        if under or good < len(above):
            # something under the bottom one, or out of order on it: off it comes, from the top
            top = pile[-1]
            if name == "pick" and named == top:
                return None
            wrong = (f"the {base} (the bottom) is standing on the {', '.join(under)}" if under
                     else f"the {', '.join(above[good:])} {'is' if len(above) - good == 1 else 'are'} on it out of order")
            return (f"ERROR: not done. {asked} Now {wrong}. First take it off, from the top: pick the {top} "
                    f"({ids.get(top, '?')}) and put it down with place_free; then carry on.")
        if good >= len(order):
            return None
        following = order[good]
        if name == "pick" and (named == following or (good == 1 and named == base)):
            return None
        if name == "place_on" and named == above[-1] and holding == following:
            return None
        so_far = ", ".join(above) if len(above) > 1 else f"just the {base} so far"
        put_down = (f" First put the {holding} down away from the tower (place_free), as it isn't next."
                    if holding and holding != following else "")
        return (f"ERROR: not done. {asked} It is now: {so_far}.{put_down} Next: pick the {following} "
                f"({ids.get(following, '?')}), then place_on the {above[-1]} ({ids.get(above[-1], '?')}).")

    def _new_trace(self, user_prompt: str, system_prompt: str) -> PromptTrace:
        setup = {}
        if self.describe_setup is not None:
            try:
                setup = self.describe_setup()
            except Exception:  # noqa: BLE001 - a description is never worth failing a prompt over
                setup = {}
        info_of = getattr(self.client, "model_info", None)
        info = info_of(self.model) if info_of is not None else {}
        return PromptTrace(user_prompt, self.model, self.temperature, bool(getattr(self.client, "think", False)),
                           self.max_tool_calls, setup=setup, model_info=info, system_prompt=system_prompt,
                           tools=TOOL_SCHEMAS)

    def _joint_source(self) -> str:
        robot = getattr(self.executor, "robot", None)
        return getattr(robot, "joint_source", "calculated from the arm model")

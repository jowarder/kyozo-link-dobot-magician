"""The models Ollama has installed, as the Prompt tab's Model list shows them: what each is good for (Quick, Detailed
planning, Deep reasoning) and how fast it is and how carefully it plans, as dots.

What matters for this app is whether a model answers directly or always thinks first: the "Thinking" versions (e.g.
qwen3:4b since Qwen3-4B-Thinking-2507) write a long chain of reasoning before every answer, which on a PC without a
graphics card takes minutes per step. The dots are a guide, from what the models are known for and what was measured
on this PC (qwen3:4b-instruct: seconds a step; qwen3:8b: about twice as long a token; qwen3:4b Thinking: minutes).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

RECOMMENDED = "qwen3:4b-instruct-2507-q4_K_M"
QUICK, DETAILED, DEEP = "Quick", "Detailed planning", "Deep reasoning"
# (V4.3) any installed model that can call the tools is listed, not only Qwen. The default stays RECOMMENDED (config.yaml
# llm: model, the study's); one picked in the list is for this sitting only. On this laptop (16 GB, no graphics card,
# the camera and the app beside it) a model up to about this size runs; a bigger one is listed with a warning.
LAPTOP_MAX_GB = 6.0
# small models that call tools and run on a laptop's CPU, to try (`ollama pull <name>`): for the Model list's tooltip
FOR_A_LAPTOP = ("qwen3:4b-instruct-2507-q4_K_M", "qwen2.5:3b", "llama3.2:3b", "qwen3:1.7b", "granite3.3:2b",
                "phi4-mini")


@dataclass
class ModelInfo:
    name: str
    size_gb: float
    tools: bool = True              # can call the robot's tools (a vision-only model like llava can't)
    thinking_only: bool = False     # always thinks before answering (can't be switched off)

    @property
    def listed(self) -> bool:
        """Shown in the Model list: every model that can call the robot's tools (a vision-only one like llava can't)."""
        return self.tools

    @property
    def tested(self) -> bool:
        """The app is tested with the Qwen models; with another, it may plan worse (its own way with the tools)."""
        return self.name.startswith("qwen")

    @property
    def too_big(self) -> bool:
        """Bigger than this laptop runs well (see LAPTOP_MAX_GB): slow, and the app and camera short of memory."""
        return self.size_gb > LAPTOP_MAX_GB

    @property
    def role(self) -> str:
        if self.thinking_only:
            return DEEP
        if "instruct" in self.name or self.size_gb < 4.0:
            return QUICK
        return DETAILED

    @property
    def speed(self) -> int:
        """1-3 dots: how quickly it gets through a step on this PC."""
        return 3 if self.role == QUICK and not self.too_big else 1

    @property
    def planning(self) -> int:
        """1-3 dots: how carefully it plans a task of several steps."""
        return {QUICK: 1, DETAILED: 2, DEEP: 3}[self.role]

    @property
    def short_name(self) -> str:
        """Without Ollama's version and packing tags: qwen3:4b-instruct-2507-q4_K_M -> qwen3:4b-instruct."""
        return re.sub(r"-q\d\w*$", "", re.sub(r"-\d{4}(?=-|$)", "", self.name))


def list_order(info: ModelInfo) -> tuple:
    """The Model list's order: Quick first, then Detailed planning, then Deep reasoning; in each, the tested (Qwen)
    ones first, smaller before bigger."""
    return ({QUICK: 0, DETAILED: 1, DEEP: 2}[info.role], not info.tested, info.size_gb)


def notes(info: ModelInfo) -> list[str]:
    """What to know before picking it, for its row's tooltip."""
    out = []
    if info.name == RECOMMENDED:
        out.append("the study's model (the default)")
    elif not info.tested:
        out.append("not tested with this app: it may plan worse, and runs with it don't count for the study")
    if info.too_big:
        out.append(f"{info.size_gb:.1f} GB is big for this laptop (up to about {LAPTOP_MAX_GB:.0f} GB runs well)")
    if info.thinking_only:
        out.append("always thinks first: minutes a step on this PC")
    return out


def choose(models: list[ModelInfo], wanted: str) -> str:
    """The model to start with: the one asked for if it is listed, else the recommended one, else the first quick
    one, else the first listed (else `wanted` as it is: Ollama says it is missing)."""
    listed = [m for m in models if m.listed]
    names = [m.name for m in listed]
    if wanted in names:
        return wanted
    if RECOMMENDED in names:
        return RECOMMENDED
    quick = [m.name for m in listed if m.role == QUICK]
    return (quick or names or [wanted])[0]

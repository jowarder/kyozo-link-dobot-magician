"""Thin HTTP client for a local Ollama server."""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Optional

import requests

logger = logging.getLogger(__name__)


THINKING_TIMEOUT_S = 300.0   # an answer's time limit with the model's reasoning on
MAX_ANSWER_TOKENS = 256      # one answer at most this long: a turn writes ~20-60 tokens (129 at most in two 20-task
                             # chains; a few steps in one answer ~40 each). An answer that ran on and on (S-15 in the
                             # twin, V4.2) took the whole 400 s; at 512 one still cost 157 s (V4.3 chain 1, S-14), at
                             # 256 about 70 s, and it is told once to answer with its tool calls
MAX_THINKING_TOKENS = 4096   # ... with the model's reasoning on (its reasoning counts too)
PREPARE_TIMEOUT_S = 600.0    # reading the instructions once after loading: about 2 minutes on a CPU, more on a slow one


class OllamaClient:
    def __init__(self, endpoint: str = "http://localhost:11434", timeout_s: float = 120.0,
                 keep_alive: Optional[str] = None, num_ctx: Optional[int] = None, seed: Optional[int] = None):
        """keep_alive: how long Ollama keeps the model in memory after a request ("30s", "5m", "0" to
        unload at once). None leaves it to Ollama's own default, 5 minutes. An 8B model holds about 6 GB.
        num_ctx: how many tokens the model may read at once (the instructions, the robot's tools and the conversation
        so far), sent with every request and the load -- else Ollama reloads the model when it changes. None: Ollama's
        own default, 4096, which a prompt of a few steps outgrew (the tools alone are about 2,600).
        seed: the model's random seed, sent with every answer (llm: seed in config.yaml), so the same request in the
        same state gets the same answer -- the study keeps it fixed. None: Ollama picks one each time."""
        self.endpoint = endpoint.rstrip("/")
        self.timeout_s = timeout_s
        self.keep_alive = keep_alive
        self.num_ctx = num_ctx
        self.seed = seed
        self.think = False              # the model's reasoning ("Show the model's reasoning" in Settings): slower
        self.last_stats: dict = {}      # Ollama's figures for the last answer: tokens, timings, why it stopped
        self._model_info: dict = {}

    def list_models(self) -> list[str]:
        resp = requests.get(f"{self.endpoint}/api/tags", timeout=self.timeout_s)
        resp.raise_for_status()
        return [m["name"] for m in resp.json().get("models", [])]

    def installed_models(self) -> list:
        """Every installed model (models.ModelInfo): its size, whether it can call tools, whether it always thinks
        first. Raises if Ollama can't be reached."""
        from app.llm.models import ModelInfo
        resp = requests.get(f"{self.endpoint}/api/tags", timeout=10.0)
        resp.raise_for_status()
        out = []
        for model in resp.json().get("models", []):
            name = model["name"]
            try:
                shown = requests.post(f"{self.endpoint}/api/show", json={"model": name}, timeout=10.0).json()
            except (requests.RequestException, ValueError):
                shown = {}
            capabilities = shown.get("capabilities") or ["tools"]
            finetune = str((shown.get("model_info") or {}).get("general.finetune") or "")
            out.append(ModelInfo(name=name, size_gb=model.get("size", 0) / 1e9, tools="tools" in capabilities,
                                 thinking_only=finetune.lower() == "thinking"))
        return out

    def load(self, model: str) -> float:
        """Have Ollama load `model` into memory now (so the first prompt doesn't wait for it), kept for keep_alive.
        Returns how long it took, in seconds. Raises if it couldn't."""
        started = time.monotonic()
        payload: dict[str, Any] = {"model": model}
        if self.keep_alive is not None:
            payload["keep_alive"] = self.keep_alive
        if self.num_ctx:
            payload["options"] = {"num_ctx": int(self.num_ctx)}
        resp = requests.post(f"{self.endpoint}/api/generate", json=payload, timeout=300.0)
        resp.raise_for_status()
        logger.info("Loaded %s into Ollama in %.1f s", model, time.monotonic() - started)
        return time.monotonic() - started

    def prepare(self, model: str, system_prompt: str, tools: Optional[list[dict]] = None) -> float:
        """Have the model read the instructions and the tools once now, answering a single token, so the first prompt
        doesn't: Ollama keeps what it read and reuses it while the next request starts the same way. On a PC without
        a graphics card that first read takes about 2 minutes (the first prompt timed out). Returns the seconds it
        took. Raises if it couldn't."""
        started = time.monotonic()
        payload: dict[str, Any] = {
            "model": model, "stream": False, "think": bool(self.think),
            "messages": [{"role": "system", "content": system_prompt}, {"role": "user", "content": "Ready?"}],
            "options": {"num_predict": 1, **({"num_ctx": int(self.num_ctx)} if self.num_ctx else {})},
        }
        if tools:
            payload["tools"] = tools
        if self.keep_alive is not None:
            payload["keep_alive"] = self.keep_alive
        resp = requests.post(f"{self.endpoint}/api/chat", json=payload, timeout=PREPARE_TIMEOUT_S)
        resp.raise_for_status()
        logger.info("%s read the instructions in %.1f s", model, time.monotonic() - started)
        return time.monotonic() - started

    def chat(self, model: str, messages: list[dict], tools: Optional[list[dict]] = None,
              temperature: float = 0.2) -> dict:
        """Sends a chat request with optional tool schemas. Returns the raw response message."""
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": False,
            # qwen3 "thinks" at length by default. That is what pushed requests past the
            # timeout on a CPU-only laptop (~16 tok/s), and tool selection doesn't need it. On only when asked
            # (to see its reasoning in the Model tab).
            "think": bool(self.think),
            "options": {"temperature": temperature, **({"num_ctx": int(self.num_ctx)} if self.num_ctx else {}),
                        "num_predict": MAX_THINKING_TOKENS if self.think else MAX_ANSWER_TOKENS,
                        **({"seed": int(self.seed)} if self.seed is not None else {})},
        }
        if tools:
            payload["tools"] = tools
        if self.keep_alive is not None:
            payload["keep_alive"] = self.keep_alive
        # thinking out loud first ("Show the model's reasoning"), an answer took over 2 minutes -- more with the model
        # still loading -- and the prompt failed on the timeout
        timeout = max(self.timeout_s, THINKING_TIMEOUT_S) if self.think else self.timeout_s
        try:
            resp = requests.post(f"{self.endpoint}/api/chat", json=payload, timeout=timeout)
            resp.raise_for_status()
        except requests.ConnectionError as exc:
            logger.error("Ollama connection failed: %s", exc)
            raise ConnectionError(
                f"Could not reach Ollama at {self.endpoint}. Is `ollama serve` running?"
            ) from exc
        except requests.Timeout as exc:
            logger.error("Ollama request timed out after %ss", timeout)
            others = [m for m in self.loaded_models() if m["name"] != model]
            if others:
                # both models in memory at once (switched in the toolbar, the old one still loaded): on a PC without a
                # graphics card they didn't fit in the RAM together, Windows swapped, and answers took minutes
                for other in others:
                    self.unload(other["name"])
                raise TimeoutError(
                    f"Ollama did not answer within {timeout:.0f}s. It had another model in memory as well ("
                    + ", ".join(f"{m['name']}, {m['size_gb']:.1f} GB" for m in others)
                    + "): together they didn't fit in the RAM. That one is unloaded now -- send the prompt again."
                ) from exc
            # (it said "try the smaller qwen3:4b": that name is now Qwen's Thinking version, the slowest of all here)
            if "instruct" in model:
                # (it told you to pick a Quick model while the Quick one was the one in use)
                raise TimeoutError(
                    f"Ollama did not answer within {timeout:.0f}s. The PC seems busy: close other programs and send "
                    "the prompt again."
                ) from exc
            raise TimeoutError(
                f"Ollama did not answer within {timeout:.0f}s: {model} is too slow on this PC. Pick a Quick model "
                "in the Model list (e.g. qwen3:4b-instruct), or close other programs to free up memory."
            ) from exc
        except requests.RequestException as exc:
            logger.error("Ollama request failed: %s", exc)
            detail = ""
            if exc.response is not None:
                detail = f" ({exc.response.status_code}: {exc.response.text[:200]})"
                if "context" in exc.response.text and ("exceed" in exc.response.text or "too long" in exc.response.text):
                    # the conversation (instructions, tools, every step so far) outgrew what the model may read
                    raise RuntimeError(
                        f"The conversation got too long for the model ({self.num_ctx or 4096} tokens). Try a shorter "
                        "request, or raise num_ctx under llm: in config.yaml (more memory).") from exc
            raise RuntimeError(f"Ollama returned an error{detail}") from exc
        data = resp.json()
        ns = 1e9                        # Ollama reports durations in nanoseconds
        self.last_stats = {
            "tokens_read": data.get("prompt_eval_count"), "tokens_written": data.get("eval_count"),
            "read_s": (data.get("prompt_eval_duration") or 0) / ns, "write_s": (data.get("eval_duration") or 0) / ns,
            "load_s": (data.get("load_duration") or 0) / ns, "total_s": (data.get("total_duration") or 0) / ns,
            "stop_reason": data.get("done_reason"),
        }
        return data["message"]

    def model_info(self, model: str) -> dict:
        """Size, compression and memory limit of a model (asked once, then remembered); {} if unknown."""
        if model in self._model_info:
            return self._model_info[model]
        info: dict = {}
        try:
            resp = requests.post(f"{self.endpoint}/api/show", json={"model": model}, timeout=5.0)
            resp.raise_for_status()
            data = resp.json()
            details = data.get("details", {})
            info = {"parameters": details.get("parameter_size"), "compression": details.get("quantization_level"),
                    "family": details.get("family")}
            for key, value in (data.get("model_info") or {}).items():
                if key.endswith(".context_length"):
                    info["model_memory_limit"] = value     # what the model supports; Ollama may use less
            for line in str(data.get("parameters", "")).splitlines():
                if line.split()[:1] == ["num_ctx"]:
                    info["memory_limit"] = int(line.split()[1])
        except (requests.RequestException, ValueError, TypeError, IndexError):
            info = {}
        self._model_info[model] = info
        return info

    def loaded_models(self) -> list[dict]:
        """Models Ollama has in memory right now: [{name, size_gb, on_gpu_gb}]. Empty if none or unreachable."""
        try:
            resp = requests.get(f"{self.endpoint}/api/ps", timeout=3.0)
            resp.raise_for_status()
            return [{"name": m.get("name", "?"), "size_gb": m.get("size", 0) / 1e9, "on_gpu_gb": m.get("size_vram", 0) / 1e9}
                    for m in resp.json().get("models", [])]
        except (requests.RequestException, ValueError):
            return []

    def unload(self, model: str) -> bool:
        """Have Ollama let go of `model` (free its memory now, not when its keep-alive runs out). False if it couldn't."""
        try:
            resp = requests.post(f"{self.endpoint}/api/generate", json={"model": model, "keep_alive": 0}, timeout=30.0)
            resp.raise_for_status()
            logger.info("Unloaded %s from Ollama", model)
            return True
        except requests.RequestException as exc:
            logger.warning("Could not unload %s from Ollama: %s", model, exc)
            return False

    def unload_others(self, keep: str) -> list[str]:
        """Unload every model Ollama has in memory except `keep`: two at once don't fit in a 16 GB PC's RAM without a
        graphics card. Returns the ones unloaded."""
        return [m["name"] for m in self.loaded_models() if m["name"] != keep and self.unload(m["name"])]

    def try_start_local_server(self, wait_s: float = 20.0) -> bool:
        """If Ollama is installed on this machine but not running, start it.

        Only for a local endpoint (never tries to start anything for a remote lab
        machine). Returns True once the server answers."""
        if self.is_reachable():
            return True
        host = self.endpoint.split("//", 1)[-1].split(":")[0]
        if host not in ("localhost", "127.0.0.1"):
            return False
        exe = shutil.which("ollama")
        if exe is None:
            candidate = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Ollama" / "ollama.exe"
            exe = str(candidate) if candidate.exists() else None
        if exe is None:
            return False
        logger.info("Ollama is not running; starting `ollama serve`")
        subprocess.Popen([exe, "serve"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.monotonic() + wait_s
        while time.monotonic() < deadline:
            time.sleep(1.0)
            if self.is_reachable():
                return True
        return False

    def is_reachable(self) -> bool:
        try:
            requests.get(f"{self.endpoint}/api/tags", timeout=3.0)
            return True
        except requests.RequestException:
            return False

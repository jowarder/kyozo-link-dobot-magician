"""Tool schema exposed to the LLM, and Python dispatchers that execute them.

The LLM never sees the camera image -- it only sees this tool schema and the
text results below. Vision (detector + locator) measures where things are;
the LLM only decides which tools to call and in what order.
"""
from __future__ import annotations

import json
import logging
import math
import re
import statistics
from dataclasses import replace
from pathlib import Path
from typing import Callable, Optional

from app import robots
from app.calibration.guidance import MIN_X_MM
from app.cube_size import describe as describe_cube, size_mismatch
from app.hardware import dobot_arm
from app.hardware.gripper import (SQUARE_MM, GripperSpec, across, grip_depth,
                                  plan_grip, tool_parts, turn_for_place)
from app.hardware.interfaces import Robot, Pose
from app.hardware.motion import path_points
from app.hardware.wrist import WristCorrected, approach_from_side, slow_move, steady_mean
from app.llm.arrange import ARRANGE_SCHEMAS, ArrangeTools
from app.llm.packing import Box, Fingers, Item, plan_tray, rectangles_overlap
from app.llm.recording import MoveRecorder
from app.vision.scene import SceneBuilder, SceneObject

logger = logging.getLogger(__name__)

PICK_APPROACH_HEIGHT_MM = 50.0
PLACE_APPROACH_HEIGHT_MM = 50.0
MIN_APPROACH_MM = 20.0        # near the base, where the arm can't reach 50 mm up, it comes down from as low as this

# An object is "covered" if another is nearly above it: close sideways and clearly higher. A camera
# looking from the side can still see a sliver of the covered one, which would otherwise be picked
# as if it were free -- with the arm coming down through the object on top.
COVER_DISTANCE_MM = 35.0
BUILDING_WORDS = re.compile(r"\b(?:tower|pile|stack|stacks|heap)\b")   # (place_on: building, not clearing)
CUBE_TURNED_MAX_MM = 25.0 * math.sqrt(2) + 6.0   # a 25 mm cube's outline turned 45 degrees, and a camera's slack
WIDTH_LOOKS = 6            # ... read too wide once: this many fresh pictures before refusing it (their median)
TURN_NEAR_MM = 30.0        # ... the cube looked for this near where it was put
TURN_CHECK_DEG = 6.0       # turn_object: a turn this far off what was asked, looked at afterwards, is put right once
ANGLE_RETRY_LOOKS = 10     # a pick about to be refused for an unsteady reading: this many pictures, the arm away
MISSED_GRIP = "The grip missed"   # a pick checked: the cube still on the table where it was
MISSED_NEAR_MM = 30.0              # ...looked for again: one of its colour this near where it was is it, whatever its shape word
MOVED_MIN_MM = 1.0         # a pick's fresh pictures put the cube at least this far from where it was listed: the
                           # fingers go where they see it (V4.3: a cube that slid a few mm since the last look was
                           # gripped on its edge; under this, the camera's own wander)
MISS_NEAR_MM = 12.0        # ... seen this near where it was (x, y and height)
QUEUED_PICTURES = 3        # ... after skipping this many queued pictures (taken before the pick)
# a cube let go of and then not seen anywhere on the table (study 4, S-08: gripped across its corners, it stayed wedged
# in the open fingers, was carried to the next cube and put down on top of it)
LET_GO_UNSEEN = ("The {label} wasn't seen anywhere on the table after the gripper let go of it at ({x:.0f}, {y:.0f}): "
                 "it may be stuck in the gripper's fingers. The arm waits for a person: take it out of the gripper and "
                 "put it on the table, then press Home with the area clear.")
CLEAR_LEVELS = 2          # pick / place_on move this many objects off the one wanted (a tower of three)
COVER_HEIGHT_MM = 15.0

CLEARANCE_MM = 55.0             # a free spot is at least this far from any object
SAVED_PLACE_CLEARANCE_MM = 80.0  # ...and from a saved place such as the tray
DEFAULT_OBJECT_HEIGHT_MM = 25.0
# The camera gives each object's top-centre, not its size: the test cubes are 25 mm, so that is the
# width assumed when putting one beside another.
OBJECT_WIDTH_MM = 25.0
MIN_BESIDE_GAP_MM = 5.0          # closer than this, the calibration's few-mm error could make them touch
# place_beside's sides, in the robot's own frame (looking out from its base): +x is away from it.
BESIDE_DIRECTIONS = {"left": (0.0, 1.0), "right": (0.0, -1.0), "front": (1.0, 0.0), "behind": (-1.0, 0.0)}
_UNKNOWN = object()   # a robot that can't tell whether it is holding something (the real one)


PLACE_GAP_MM = 4.0            # between things put down side by side in a tray or bin
HOME_X_MM, HOME_Z_MM = 200.0, 50.0   # the arm's home position (as the demo's; the real homing ends near it)
TRAVEL_NEAR_MM = 45.0         # something this near the way from one point to another is passed over, not through
TRAVEL_CLEARANCE_MM = 25.0    # ...with the tip (or what it carries) this far above its top
WALL_BLOCK_MM = 8.0           # a tray's or bin's walls, taken this thick outward from its inside (they are 4)
LOW_TOOL_MM = 40.0            # the tool this near the table (fingers perhaps round something) rises before going across
LIFT_OUT_MM = 5.0             # ...straight up, this much above the fingers' depth: clear of anything between them
BRIDGE_LEVEL_MM = 2.5        # laid across several objects: their tops this level, or it would tip
BRIDGE_OVERHANG = 0.25       # ...and no end out past them by more than this share of its length
FREE_TABLE_WORDS = ("near", "base", "far", "left", "right", "center", "centre", "middle", "table", "free", "outside",
                    "away", "next_to", "anywhere")
ANY_FREE_SPOT = ("outside", "table", "free", "anywhere", "away")   # (where) any free spot: not a particular one
SIZE_STEP_MM = 4.0            # objects of a kind this much different in height are "small" and "large" (list_objects)
RELEASE_GAP_MM = 3.0          # let go with the object's bottom this far above what it goes on: a height measured on a
                              # pile can be a few mm short (a 20 mm cube on a cylinder: "18 mm"), and with 1 mm the cube
                              # was pushed into the table; a 3 mm drop does no harm
IN_VIEW_MARGIN_PX = 20.0     # an object is in the camera's view when it is this far inside the picture's edges, whole
VIEW_MARGIN_PX = 14.0        # the arm this near (in the picture) to something on the table counts as hiding it
VIEW_OBJECT_MARGIN_MM = 12.0  # ...round each object, as seen from above
VIEW_LIFTS_MM = (60.0, 120.0)  # to clear the camera's view, first try just lifting the arm this much
VIEW_TOWARD_PARK = (0.3, 0.55, 0.8)  # ...then this far of the way to the parking spot
ANGLE_LOOKS = 4               # before a pick, the object's turn is read from this many pictures...
ANGLE_AGREE_DEG = 3.0         # ...and they must agree this well, the furthest off one in four left out (else it
                              # looks again, once, and judges all of them together; then the pick is refused)...
ANGLE_MEAN_DEG = 1.25         # ...or their average be known this well (its standard error), none further off than
ANGLE_SPREAD_MAX_DEG = 8.0    # this: the real camera's reading of a still cube wanders 8-10 degrees (the lab,
                              # 2026-10-21), and a pick was refused at "5 degrees over 8 pictures" -- but the average of
                              # them is good to ~1 degree, and a 25 mm cube in 27.5 mm fingers fits ~6
ANGLE_SPREAD_LIMIT_DEG = 15.0  # ...and after the second look, picked from their average up to this far apart; refused
                              # only beyond it (Rafi, 2026-10-22: a set-out was refused at 8 degrees -- a pick that
                              # bumps the cube and still holds it is scored as such, partly or as a fail)
BACK_WHERE_MM = 15.0          # place_on: a cube set aside off the held one, further than this from where it stood, goes
                              # back there first (see _back_where_it_stood)
DROP_MAX_MM = 100.0           # a drop lets go at most this far above where the object lands
PUT_DOWN_NEAR_MM = 6.0        # a cube the arm put down itself, still this near where it let go, and its unsteady
PUT_DOWN_AGREE_DEG = 10.0     # readings' average this near the turn it was let go at: picked at that turn (see
                              # _as_put_down)
WRIST_OVERSHOOT_DEG = 4.0     # the wrist comes to a pick's angle from this far below (its gears' slack taken up alike)
SLOW_LAST_MM = 15.0           # the last this-many mm down to an object being picked...
SLOW_SPEED_MM_S = 20.0        # ...at this speed
NEAR_START_MM = 25.0          # route points this near where the arm is now aren't judged by the arm model's reach


def _steps(room: float, step: float = 2.0) -> list[float]:
    """-room .. room in `step`s, through 0."""
    n = int(room // step)
    return [k * step for k in range(-n, n + 1)]


def _mean_error(angles: list, mean: float, period: float, dropped: int) -> float:
    """How well the average of these angle readings is known (its standard error, degrees), the `dropped` furthest
    off left out as steady_mean leaves them."""
    off = sorted(abs((a - mean + period / 2.0) % period - period / 2.0) for a in angles)
    kept = off[:len(off) - dropped] if dropped else off
    if len(kept) < 2:
        return float("inf")
    return math.sqrt(sum(d * d for d in kept) / (len(kept) - 1)) / math.sqrt(len(kept))


def _footprint(obj) -> Optional[tuple[float, float, float]]:
    """An object's measured footprint, or None (not every detector gives an outline)."""
    return getattr(obj, "footprint", None)


ROUND_SHAPES = ("ball", "cylinder", "disc")
# whole moves (picked up and put down where asked, in one step): a put-down straight after one is said to be done
WHOLE_MOVES = ("move_object", "swap")
# the tools that touch no cube: still done while the cubes measure another size than the one set (cube_mismatch)
CUBE_SIZE_FREE_TOOLS = ("list_objects", "home", "open_gripper", "close_gripper", "set_speed", "move_to", "move_above")


def _width_along(obj, footprint: tuple[float, float, float], direction: float) -> float:
    """How wide it is along `direction` (degrees). Something round (by its name) is its diameter whichever way:
    its outline's rectangle comes at any angle, and measured corner to corner, a 24 mm can was 33 mm wide."""
    if obj is not None and str(getattr(obj, "label", "")).split()[-1:] and obj.label.split()[-1] in ROUND_SHAPES:
        return (footprint[0] + footprint[1]) / 2.0
    return across(*footprint, direction)


def _width_squared(obj, footprint: tuple[float, float, float], direction: float) -> float:
    """How wide it is along `direction` as if squared up: a square object (a cube) its own side, however it is turned
    -- a gap is measured between squared-up faces, as the watcher scores it (S-16 in the twin, 2026-10-25: a 50 mm
    gap from a turned cube's corner was 10.6 mm short of that; Rafi chose the watcher's). Anything else as it lies."""
    if footprint[1] - footprint[0] <= SQUARE_MM:
        return (footprint[0] + footprint[1]) / 2.0
    return _width_along(obj, footprint, direction)


TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "list_objects",
            "description": "Returns the objects the camera sees, with id, label, position and size (footprint_mm: narrow side and long side seen from above; height_mm). An object marked gripper: too wide can't be picked up. An object marked covered_by has another object on top of it (pick still works: the one on top is moved aside first); objects listed under hidden are under a visible one and cannot be picked until that one is moved.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "pick",
            "description": "Picks up the object with the given id: moves above it, descends, grips, and lifts. If another object is on top of it, the tool first moves that one aside by itself.",
            "parameters": {
                "type": "object",
                "properties": {"object_id": {"type": "string", "description": "id from list_objects"}},
                "required": ["object_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "place",
            "description": "Places the held object at an explicit x, y, z (mm, robot frame). Only for coordinates the user typed; to put it on free table space use place_free.",
            "parameters": {
                "type": "object",
                "properties": {
                    "x": {"type": "number"}, "y": {"type": "number"}, "z": {"type": "number"},
                    "turn_deg": {"type": "number", "description": "Only when the user asks for a turn: turn the object by this many degrees as it is put down (positive = anticlockwise seen from above, e.g. 70). Omit otherwise."}, "angle_deg": {"type": "number", "description": "Only when the user asks for an angle the object should END UP at (\"at 45 degrees\"): its final angle on the table, degrees anticlockwise from the robot's x axis. Omit otherwise."},
                },
                "required": ["x", "y", "z"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "place_at",
            "description": "Puts the currently held object down at a saved place by name: a tray or bin, or a spot or zone marked on the table (e.g. 'tray', 'spot 3'). Names are listed in list_objects under saved_places.",
            "parameters": {
                "type": "object",
                "properties": {"place_name": {"type": "string"}, "turn_deg": {"type": "number", "description": "Only when the user asks for a turn: turn the object by this many degrees as it is put down (positive = anticlockwise seen from above, e.g. 70). Omit otherwise."}, "angle_deg": {"type": "number", "description": "Only when the user asks for an angle the object should END UP at (\"at 45 degrees\"): its final angle on the table, degrees anticlockwise from the robot's x axis. Omit otherwise."}},
                "required": ["place_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "put_all_in",
            "description": "Puts several objects into one tray or bin in one go: the tool plans where each goes (the "
                           "biggest first, turned to fit, up to three levels on steady flat tops when the floor is full) and does "
                           "all the picking and placing itself. Use it for 'put everything / all the cubes / these in the "
                           "tray', with every object's id. It says what didn't fit.",
            "parameters": {
                "type": "object",
                "properties": {
                    "place_name": {"type": "string", "description": "a tray or bin from saved_places"},
                    "object_ids": {"type": "array", "items": {"type": "string"}, "description": "ids from list_objects"},
                },
                "required": ["place_name", "object_ids"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "place_free",
            "description": "Puts the held object down on a free, reachable spot of the table that the tool chooses itself "
                           "(never invent coordinates). where: 'near_base' (as close to the robot base as the arm can reach), "
                           "'far' (far from the base), 'left', 'right', 'center', or 'next_to' together with object_id. "
                           "To put it at a particular side of an object or a particular distance from it, use place_beside.",
            "parameters": {
                "type": "object",
                "properties": {
                    "where": {"type": "string", "description": "near_base, far, left, right, center or next_to"},
                    "object_id": {"type": "string", "description": "only for next_to: the object to put it beside"},
                    "turn_deg": {"type": "number", "description": "Only when the user asks for a turn: turn the object by this many degrees as it is put down (positive = anticlockwise seen from above, e.g. 70). Omit otherwise."}, "angle_deg": {"type": "number", "description": "Only when the user asks for an angle the object should END UP at (\"at 45 degrees\"): its final angle on the table, degrees anticlockwise from the robot's x axis. Omit otherwise."},
                },
                "required": ["where"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "place_on",
            "description": "Stacks the currently held object ON TOP of another object identified by id. Only for "
                           "'on top of' / 'stack on'; to put it beside an object use place_beside. To lay a long "
                           "object ACROSS several objects of the same height ('the bar on top of all the cubes', 'lay the "
                           "pen across the cubes'), give them all in object_ids instead: it is laid along their row, "
                           "resting on them.",
            "parameters": {
                "type": "object",
                "properties": {"object_id": {"type": "string"},
                               "object_ids": {"type": "array", "items": {"type": "string"},
                                              "description": "several objects to lay it across (instead of object_id)"}, "turn_deg": {"type": "number", "description": "Only when the user asks for a turn: turn the object by this many degrees as it is put down (positive = anticlockwise seen from above, e.g. 70). Omit otherwise."}, "angle_deg": {"type": "number", "description": "Only when the user asks for an angle the object should END UP at (\"at 45 degrees\"): its final angle on the table, degrees anticlockwise from the robot's x axis. Omit otherwise."}},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "place_beside",
            "description": "Puts the held object down on the table BESIDE another object, on the given side, with the "
                           "given gap between them (edge to edge, mm). Use for 'to the right of the blue cube', 'next to "
                           "X, 10 mm apart', 'beside X'. side is the robot's own: 'left' or 'right' (looking out from "
                           "its base), 'front' (farther from the base) or 'behind' (nearer the base).",
            "parameters": {
                "type": "object",
                "properties": {
                    "object_id": {"type": "string", "description": "id from list_objects: the object to put it beside"},
                    "side": {"type": "string", "description": "left, right, front or behind"},
                    "gap_mm": {"type": "number", "description": "the gap between the two objects, mm (default 10)"},
                    "drop_mm": {"type": "number", "description": "Only for 'let it drop' from a height: let go with its bottom this far above the surface, mm (it falls). Omit otherwise."},
                    "turn_deg": {"type": "number", "description": "Only when the user asks for a turn: turn the object by this many degrees as it is put down (positive = anticlockwise seen from above, e.g. 70). Omit otherwise."}, "angle_deg": {"type": "number", "description": "Only when the user asks for an angle the object should END UP at (\"at 45 degrees\"): its final angle on the table, degrees anticlockwise from the robot's x axis. Omit otherwise."},
                },
                "required": ["object_id", "side"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "build_tower",
            "description": "Builds a TOWER (one pile) of the given objects in one go: object_ids BOTTOM FIRST. The "
                           "bottom one goes to place_name if given (e.g. 'tray'), or to free table with where (e.g. "
                           "outside the tray), else it stays where it is; then each next one on top of the one before. "
                           "Objects already in a pile are taken off it first, so it also moves or rebuilds a tower. "
                           "angle_deg / turn_deg turn every one, if the user asked. It says what it built, bottom to "
                           "top, or where it stopped and why.",
            "parameters": {
                "type": "object",
                "properties": {"object_ids": {"type": "array", "items": {"type": "string"},
                                              "description": "ids from list_objects, bottom first"},
                               "place_name": {"type": "string", "description": "where the tower goes (a saved place), "
                                                                               "only if the user said"},
                               "where": {"type": "string", "description": "on free table instead: center, left, right, "
                                                                          "near_base, far, or outside (any free spot)"},
                               "angle_deg": {"type": "number", "description": "every object ends up at this angle, "
                                                                              "only if asked"},
                               "turn_deg": {"type": "number", "description": "every object turned by this much, "
                                                                             "only if asked"}},
                "required": ["object_ids"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "turn_object",
            "description": "Turns objects on the table where they stand: picks each up, turns it, puts it back on the "
                           "same spot. turn_deg turns BY that much ('turn the brown block 70 degrees'); angle_deg sets the "
                           "angle it ends up AT ('all the cubes at 45 degrees'); like_id turns it to the same angle as "
                           "another object ('make the red cube's angle like the green cube's'). Give every object's id in "
                           "object_ids (one call for several). The object being held can be turned too: it is put back, "
                           "turned, where it was picked up. A round object (ball, cylinder, can) looks the same at any "
                           "turn: it is left as it is. One with something on top of it can't be turned until that is "
                           "moved: the tool says.",
            "parameters": {
                "type": "object",
                "properties": {"object_ids": {"type": "array", "items": {"type": "string"},
                                              "description": "ids from list_objects"},
                               "turn_deg": {"type": "number", "description": "turn by, degrees (e.g. 70 or -45)"},
                               "angle_deg": {"type": "number", "description": "end up at, degrees from the robot's x axis"},
                               "like_id": {"type": "string",
                                           "description": "end up at the same angle as this object (id from "
                                                          "list_objects)"}},
                "required": ["object_ids"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "move_above",
            "description": "Moves the arm to hover above the object with the given id (use this for 'go close to / over the X'). Does not grip.",
            "parameters": {
                "type": "object",
                "properties": {"object_id": {"type": "string", "description": "id from list_objects"}},
                "required": ["object_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "move_to",
            "description": "Moves the arm to an explicit x, y, z position (mm, robot frame) without gripping. Only use coordinates that came from list_objects or that the user typed; never invent them.",
            "parameters": {
                "type": "object",
                "properties": {
                    "x": {"type": "number"}, "y": {"type": "number"}, "z": {"type": "number"},
                },
                "required": ["x", "y", "z"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "home",
            "description": "Moves the arm to its home position.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "open_gripper",
            "description": "Opens the gripper / releases suction.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "close_gripper",
            "description": "Closes the gripper / activates suction.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
]
TOOL_SCHEMAS += ARRANGE_SCHEMAS      # line_up, move_object, take_apart, empty_place, place_between, swap, put_back...
# (V4.3) ends the prompt in the answer with its last step: the summary turn it saves took 6-25 s on the laptop (and
# 73 s once). The agent handles it: the app checks the goal as for a reply, and tells the user what was done.
TOOL_SCHEMAS.append({
    "type": "function",
    "function": {
        "name": "done",
        "description": "Call last, in the same answer as your final step(s), when those steps complete the whole "
                       "request. The app then checks it and tells the user what was done, so write no reply. If a "
                       "step fails, the steps after it (and done) are not run: you get the results to decide again.",
        "parameters": {"type": "object", "properties": {}},
    },
})


class ToolExecutor(ArrangeTools):
    """Dispatches LLM tool calls to the robot + scene. Raises ValueError on unknown/bad calls."""

    def __init__(self, robot: Robot, scene_builder: SceneBuilder,
                 calibration_ready: Callable[[], bool] = lambda: True,
                 poses_dir: Optional[Path] = None, look_pose: Optional[Pose] = None,
                 table_z_provider: Callable[[], Optional[float]] = lambda: None,
                 places_provider: Optional[Callable[[], dict]] = None,
                 gripper: Optional[GripperSpec] = None,
                 place_areas_provider: Optional[Callable[[], dict]] = None):
        """`table_z_provider` gives the table's height in the robot frame (None if not known); it is
        needed to put something down on free table space. `places_provider` gives named drop-off
        places that come with the demo scene (name -> (x, y, z) mm: a tray, bins, a tower spot). `gripper`: the end
        effector (default a suction cup, which takes an object by its top); with two fingers each pick checks the
        object fits between them, turns them to its narrow sides and closes partway down it."""
        self.places_provider = places_provider
        # the inside of each tray or bin {name: (width, depth, wall top z)}, so several things go in side by side;
        # the demo world's own, if the places are its (a place saved from the Manual tab has no known size)
        if place_areas_provider is None:
            place_areas_provider = getattr(getattr(places_provider, "__self__", None), "place_areas", None)
        self.place_areas_provider = place_areas_provider
        self.should_stop: Callable[[], bool] = lambda: False   # Stop pressed: a long tool call ends between objects
        self.gripper = gripper or GripperSpec(kind="suction")
        self._wanted_turn: Optional[float] = None   # a turn the user asked for (turn_deg), while one tool call puts it down
        self._grip_r = 0.0          # the end effector's turn while holding (r = J1 + J4): kept, so the object doesn't turn
        self._grip_depth = 0.0      # how far below the held object's top the fingertips are (0 for suction)
        self._held_square = True    # a square object looks the same turned a quarter turn
        self.table_z_provider = table_z_provider
        self._under: dict[str, str] = {}          # what we know we stacked: lower object -> object on top of it
        self._heights: dict[str, float] = {}      # each object's height, learned while it sat on the table
        self._held_height = DEFAULT_OBJECT_HEIGHT_MM
        self._just_placed: list[tuple[float, float]] = []   # put down since the last look, so not in the scene yet
        self._let_go: Optional[tuple[str, float, float]] = None   # the last object let go of, and where, until a look
                                                                  # sees it on the table (_check_let_go)
        # every pose the tools send is in ideal terms; the wrist correction (the fingers angle check's model, once
        # set: see hardware/wrist.py) turns it into what the robot is told, then the moves are written down
        self.wrist = WristCorrected(robot, self.gripper)
        self.gripper.told_wrist = self.wrist.told_wrist      # (the planner judges the wrist's limits as it is told)
        self.robot = MoveRecorder(self.wrist)   # passes everything through; writes down the moves for the Model tab
        self.wrist_overshoot_deg = WRIST_OVERSHOOT_DEG
        self.slow_last_mm = SLOW_LAST_MM
        self.slow_speed = SLOW_SPEED_MM_S
        self.angle_looks = ANGLE_LOOKS
        self.check_picks = True    # a robot that can't feel a grip: each pick checked by the camera
        self.turn_checks = 1       # turns looked at afterwards and put right (once); 0: not checked
        self.look_pose = look_pose  # where the arm waits so it isn't between the camera and the table
        # what the last tool call did, for the Model tab: its moves, the safety checks, where the target came from
        self.last_record: dict = {"moves": [], "checks": [], "target_from": None}
        self.scene_builder = scene_builder
        self.calibration_ready = calibration_ready
        self.poses_dir = poses_dir
        self._last_scene: list[SceneObject] = []
        self._ids_seen: dict[str, str] = {}   # every id listed since the table was set out: its label then
        self._listed = False
        self.holding: Optional[str] = None  # label of the object in the gripper, if any
        self._held_obj: Optional[SceneObject] = None   # ...and how it was listed (its id), to update once put down
        self.last_moved: Optional[str] = None  # so "put it in the tray" still works right after a placement
        self._this_prompt_start: Optional[dict] = None   # where everything was at this prompt's first look...
        self._last_prompt_start: Optional[dict] = None   # ...and at the last prompt's that moved something (put_back)
        self._moved_in_prompt = False
        # each object's turn at this prompt's first look, and the ones put down since: "swap them, then turn the red
        # cube 45 degrees" turns it from where it was asked, not from how the swap left it (study 3, S-06, S-08)
        self._prompt_angles: dict[str, float] = {}
        self._placed_in_prompt: set[str] = set()
        # the turn each object was put down at (id -> x, y, turn), until it is picked again: a cube the arm has just
        # put down isn't refused for an unsteady reading that agrees with it (study 3, S-07, S-10: the swap's own cube)
        self._placed_angles: dict[str, tuple[float, float, float]] = {}
        # what was moved aside to get at the object under it (its id -> where it stood, its turn, what was under it):
        # "put the green cube on the blue cube" with the blue one on the green -- the blue cube goes back where it
        # stood before the green goes on it (study 3, S-15: the tower ended where blue had been set aside, 51 mm off)
        self._set_aside: dict[str, tuple[float, float, Optional[float], str]] = {}
        self._speed_at_start: Optional[float] = None     # set_speed: the speed to go back to at the end of the prompt
        # what a step put down, and where: (label, x, y, the step) -- this step's, and the one before's
        self._released_now: Optional[tuple] = None
        self._released_before: Optional[tuple] = None
        self._tool_now = ""
        # the cubes on the table measure another size than the one set: (measured, set, the size they are), or None;
        # nothing moves meanwhile (_require_listed). `cube_size_kept`: (set, measured as) the user said to keep anyway
        self.cube_mismatch: Optional[tuple[float, float, float]] = None
        self.cube_size_kept: Optional[tuple[float, float]] = None

    def status_text(self) -> str:
        holding = f"Currently holding: {self.holding}" if self.holding else "Currently holding: nothing"
        if self.last_moved:
            holding += f". Last object you moved: {self.last_moved}"
        try:
            places = self._saved_places()
        except Exception:  # noqa: BLE001 - the state line must never break a prompt
            places = None
        if places == {}:
            # (the instructions' many tray examples: "put the green cube on the blue cube" called place_at('tray'),
            # with no tray on the table -- study 3, S-15; S-17 build_tower(where="outside the tray"))
            holding += ". Saved places: none -- there is no tray or bin now: don't use place_at or place_name"
        return holding

    def _saved_places(self) -> dict[str, Pose]:
        """Named drop targets: the demo scene's own places (its tray or bins), then poses saved from the
        Manual tab (e.g. 'tray'), which win if a name is used twice."""
        places: dict[str, Pose] = {}
        provider = getattr(self, "places_provider", None)   # (a test may build this without __init__)
        if provider is not None:
            for name, (x, y, z) in provider().items():
                places[str(name).lower()] = Pose(x=float(x), y=float(y), z=float(z))
        if self.poses_dir is not None and self.poses_dir.exists():
            for path in sorted(self.poses_dir.glob("*.json")):
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    data.pop("area_mm", None)                  # a flat zone's size: see _saved_place_areas
                    data.pop("marking", None)                  # a printed spot: see _markings
                    places[path.stem.lower()] = Pose(**data)
                except (OSError, ValueError, TypeError) as exc:   # one damaged file must not break every prompt
                    logger.warning("Ignoring the saved place %s: %s", path.name, exc)
        return places

    def _saved_place_areas(self) -> dict[str, tuple[float, float, float]]:
        """The size of each saved place that has one ("area_mm": [width, depth] in its file): a flat zone on the table
        (the study's zone A and B, marked only in the software), where several things go side by side as in a tray.
        No walls: (width, depth, 0)."""
        areas: dict[str, tuple[float, float, float]] = {}
        if self.poses_dir is None or not self.poses_dir.exists():
            return areas
        for path in sorted(self.poses_dir.glob("*.json")):
            try:
                area = json.loads(path.read_text(encoding="utf-8")).get("area_mm")
                if area:
                    areas[path.stem.lower()] = (float(area[0]), float(area[1]), 0.0)
            except (OSError, ValueError, TypeError, IndexError):
                continue                                      # (the place itself is reported by _saved_places)
        return areas

    def _markings(self) -> set[str]:
        """The saved places that are only marked on the table -- the study's printed spots ("marking": true in their
        file, or given by markings_provider) -- not things: nothing has to keep clear of them, and their outline
        never blocks a cube put down beside or near them. They are still places to put things (place_at)."""
        names: set[str] = set()
        provider = getattr(self, "markings_provider", None)
        if provider is not None:
            names |= {str(n).lower() for n in provider()}
        poses_dir = getattr(self, "poses_dir", None)
        if poses_dir is not None and poses_dir.exists():
            for path in poses_dir.glob("*.json"):
                try:
                    if json.loads(path.read_text(encoding="utf-8")).get("marking"):
                        names.add(path.stem.lower())
                except (OSError, ValueError, AttributeError):
                    continue
        return names

    def _obstacle_places(self) -> dict[str, Pose]:
        """The saved places things keep clear of (a tray, a bin): every one but the markings."""
        markings = self._markings()
        return {name: place for name, place in self._saved_places().items() if name not in markings}

    def _place_areas(self) -> dict[str, tuple[float, float, float]]:
        """The inside of every place with a known size {name: (width, depth, wall top z)}: the demo scene's trays and
        bins, then saved places with a size (which win if a name is used twice). Without one a place is one spot."""
        provider = getattr(self, "place_areas_provider", None)
        areas = dict(provider() or {}) if provider is not None else {}
        if getattr(self, "poses_dir", None) is not None:
            areas.update(self._saved_place_areas())
        return areas

    def _scene_place_names(self) -> set[str]:
        """The places given by the surface things are put down on, rather than by the tool's height as taught: the
        demo scene's own (not overridden by a saved pose of the same name), and saved places with a size -- a flat
        zone, whose z is the table's (see _saved_place_areas)."""
        provider = getattr(self, "places_provider", None)
        names = {str(name).lower() for name in provider()} if provider is not None else set()
        if self.poses_dir is not None and self.poses_dir.exists():
            names -= {path.stem.lower() for path in self.poses_dir.glob("*.json")}
            names |= set(self._saved_place_areas())
        return names

    def _let_go_at(self, name: str, place: Pose) -> float:
        """Where the tool lets go at a place: a scene place gives the surface, so the held object's bottom goes
        1 mm above it (wherever the tool holds it); a saved pose is the tool's own height, as taught -- never
        lower, on a real arm."""
        return self._release_z(place.z) if name in self._scene_place_names() else place.z

    def planned_target(self, name: str, args: dict) -> Optional[Pose]:
        """Where the tool tip is headed for this call, if that's known without doing it (step-by-step mode shows
        it in the 3D view before you say Go); None for steps whose spot is worked out as they run."""
        try:
            if name in ("pick", "move_above"):
                obj = self._find_object(args["object_id"])
                x, y, z = obj.xyz_robot
                if name == "move_above":
                    return Pose(x=x, y=y, z=z + PICK_APPROACH_HEIGHT_MM)
                return Pose(x=x, y=y, z=z - grip_depth(self.gripper, self._heights.get(obj.label)))
            if name == "place_on":
                x, y, z = self._find_object(args["object_id"]).xyz_robot
                return Pose(x=x, y=y, z=self._release_z(z))
            if name == "place_at":
                place_name = str(args["place_name"]).strip().lower()
                place = self._saved_places().get(place_name)
                if place is None:
                    return None
                z = self._let_go_at(place_name, place)
                if self.holding:
                    # the free spot the object will go to, as place_at works it out (the place's middle was shown)
                    scene_place = place_name in self._scene_place_names()
                    x, y = self._spot_at_place(place_name, place, place.z if scene_place else None)
                    return Pose(x=x, y=y, z=z)
                return Pose(x=place.x, y=place.y, z=z)
            if name == "place_beside" and self.holding:
                anchor = self._find_object(args["object_id"])
                surface = anchor.xyz_robot[2] - self._heights.get(anchor.label, DEFAULT_OBJECT_HEIGHT_MM)
                z = self._release_z(surface)
                side = str(args.get("side", "")).strip().lower()
                side = {"back": "behind", "near": "behind", "far": "front", "forward": "front"}.get(side, side)
                spot, _ = self._beside_spot(anchor, side, float(args.get("gap_mm", 10.0)), z)
                return None if spot is None else Pose(x=spot[0], y=spot[1], z=z)
            if name in ("place", "move_to"):
                return Pose(x=float(args["x"]), y=float(args["y"]), z=float(args["z"]))
        except (KeyError, ValueError, TypeError):
            return None
        return None

    def forget_scene(self, keep_piles: bool = False) -> None:
        """A new scene was set out on the table: nothing held, nothing known about what is where. `keep_piles`: the
        table is the same one, carried on from (the watcher's Simple 20, each task starting where the last left the
        cubes): what we stacked on what, and the objects' heights, are still known -- a cube under a tower can't be
        seen, and is only known from having been stacked on (the memory still lapses by itself once the pile changes)."""
        if not keep_piles:
            self._under.clear()
            self._heights.clear()
        self._just_placed.clear()
        self._let_go = None
        self._last_scene = []
        self._ids_seen.clear()
        self._listed = False
        self._held_height = DEFAULT_OBJECT_HEIGHT_MM
        self.holding = None
        self._held_obj = None
        self.last_moved = None
        self._grip_r, self._grip_depth, self._held_square = 0.0, 0.0, True
        self._this_prompt_start = self._last_prompt_start = None
        self._prompt_angles, self._placed_in_prompt = {}, set()
        self._placed_angles.clear()
        self._set_aside.clear()

    def let_go_by_hand(self) -> None:
        """The gripper was opened from the Manual tab: whatever it held is no longer held (the next prompt looks at
        the table again anyway, and finds it where it fell)."""
        if self.holding:
            self.last_moved = self.holding
        self.holding = None
        self._held_obj = None
        self._grip_r, self._grip_depth, self._held_square = 0.0, 0.0, True

    def took_by_hand(self, info: Optional[dict]) -> None:
        """The gripper was closed from the Manual tab and holds something (the demo can tell what: `info`, see
        SimRobot.held_info). The next prompt was told "holding nothing": the model moved the cube around unawares,
        and picking something else opened the gripper and dropped it on what it was about to pick."""
        if not info:
            return
        width, depth, height = info["size"]
        round_ = info.get("shape") in ("ball", "cylinder")
        footprint = (min(width, depth), max(width, depth),
                     0.0 if round_ else info["yaw"] + (90.0 if depth > width else 0.0))
        self.holding = info["label"]
        seen = [o for o in self._last_scene if o.label == info["label"]]     # the id it was last listed under, if any
        known = min(seen, key=lambda o: math.dist(o.xyz_robot[:2], info["xyz"][:2]), default=None)
        self._held_obj = SceneObject(id=known.id if known is not None else "in_hand", label=info["label"],
                                     xyz_robot=tuple(info["xyz"]), confidence=1.0, footprint=footprint)
        self._heights[info["label"]] = height
        self._held_height = height
        self._grip_r = info["r"] if self.gripper.fingers else 0.0
        self._grip_depth = info["grip_depth"] if self.gripper.fingers else 0.0
        self._held_square = round_ or abs(width - depth) <= SQUARE_MM
        self.last_moved = info["label"]

    def begin_run(self) -> None:
        """Called at the start of each user prompt: the model must look at the table
        again before it is allowed to move to a position. The last prompt's start is kept for put_back ("undo that"),
        if it moved anything."""
        self._listed = False
        if self._moved_in_prompt and self._this_prompt_start is not None:
            self._last_prompt_start = self._this_prompt_start
        self._this_prompt_start = None
        self._moved_in_prompt = False
        self._prompt_angles, self._placed_in_prompt = {}, set()
        self._set_aside = {}

    def end_run(self) -> None:
        """Called when a prompt ends, however it ends: a speed set for it (set_speed) goes back."""
        self._restore_speed()

    def _require_listed(self) -> None:
        if not self._listed:
            raise ValueError(
                "Call list_objects first. Do not guess coordinates: only move to positions "
                "that come from list_objects."
            )

    def _refuse_wrong_cube_size(self, name: str) -> None:
        """Nothing that grips or puts down a cube while the cubes measure another size than the one set -- except putting
        down one already held: found out while it was held (the size is judged from a few looks; the first pick can
        come before), it is put down, not left hanging in the gripper. Its next pick is refused."""
        if self.cube_mismatch is None or name in CUBE_SIZE_FREE_TOOLS:
            return
        if self.holding and name.startswith("place"):
            return
        measured, setting, other = self.cube_mismatch
        raise ValueError(
            f"Not moving: the cubes on the table measure about {measured:.0f} mm across, but the cube size is set to "
            f"{describe_cube(setting)}; they look like the {describe_cube(other)} cubes. Gripped and stacked as "
            f"{describe_cube(setting)} cubes they would slip or topple. Tell the user to set the cube size (beside the "
            f"prompt box, or Settings > Cubes), then ask again.")

    def _check_cube_size(self) -> None:
        """After a look: do the cubes on the table measure the size set? (cube_mismatch; the window offers to change it)"""
        measured = getattr(self.scene_builder, "measured_cube_mm", lambda: None)()
        setting = (getattr(self.scene_builder, "known_sizes", None) or {}).get("cube")
        numbers = all(isinstance(v, (int, float)) for v in (measured, setting))
        other = size_mismatch(measured, setting) if numbers else None
        self.cube_mismatch = (None if other is None or self.cube_size_kept == (setting, other)
                              else (float(measured), float(setting), float(other)))

    def _view_spot(self, here: Pose) -> Pose:
        """Where the camera's picture is taken from: where the arm is, if it hides nothing the camera saw last time;
        else the nearest of a few spots that clear the view (straight up, then part of the way to the parking spot);
        else the parking spot itself (look_pose). Before the first look, with nothing known yet, the parking spot."""
        look = self.look_pose
        candidates = [here]
        top = (getattr(self.robot, "bounds", None) or {}).get("z", [None, here.z + max(VIEW_LIFTS_MM)])[1]
        for lift in VIEW_LIFTS_MM:
            candidates.append(Pose(here.x, here.y, min(here.z + lift, top), here.r))
        for t in VIEW_TOWARD_PARK:
            candidates.append(Pose(here.x + (look.x - here.x) * t, here.y + (look.y - here.y) * t,
                                   max(here.z, here.z + (look.z - here.z) * t), here.r))
        for spot in candidates:
            if spot is not here and not (self._within_bounds(spot) and self._can_reach(spot)):
                continue
            hides = self._hides_objects(spot)
            if hides is None:
                return look          # can't tell (nothing seen yet, no camera model): the safe parking spot
            if not hides:
                return spot
        return look

    def _in_view(self, x: float, y: float, z: float, radius_mm: float = OBJECT_WIDTH_MM / 2.0) -> Optional[bool]:
        """Whether the camera sees something `radius_mm` round at (x, y, z), whole and clear of the picture's edges;
        None if it can't be told (no camera model). The arm can reach further than the camera sees: a row of cubes was
        lined up out to y -230, the red one went out of the picture, and was "not there"."""
        try:
            import numpy as np
            intrinsics = self.scene_builder.camera.get_intrinsics()
            to_camera = np.linalg.inv(np.asarray(self.scene_builder.t_cam_to_robot, float))
        except Exception:  # noqa: BLE001 - no camera model: can't judge
            return None
        if intrinsics is None:
            return None
        cx, cy, depth = (to_camera @ np.array([x, y, z, 1.0]))[:3]
        if depth <= 1.0:
            return False
        u = intrinsics.fx * cx / depth + intrinsics.cx
        v = intrinsics.fy * cy / depth + intrinsics.cy
        edge = IN_VIEW_MARGIN_PX + intrinsics.fx * radius_mm / depth
        return bool(edge <= u <= intrinsics.width - edge and edge <= v <= intrinsics.height - edge)

    def _hides_objects(self, pose: Pose, only: Optional[list] = None) -> Optional[bool]:
        """Whether the arm at `pose` would come between the camera and something it saw on the table (or something
        put down since; `only`: just these objects): the arm's links, as round bars, and each object, projected into
        the camera's picture. None if it can't be told: nothing seen yet, or no camera model."""
        if not self._listed or not self._last_scene:
            return None
        try:
            import numpy as np
            intrinsics = self.scene_builder.camera.get_intrinsics()
            to_camera = np.linalg.inv(np.asarray(self.scene_builder.t_cam_to_robot, float))
        except Exception:  # noqa: BLE001 - no camera model: can't judge
            return None
        table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
        table_z = float(table_z) if table_z is not None else 0.0
        robot = robots.active()
        g = robot.geometry(pose.x, pose.y, pose.z, pose.r, table_z=table_z)
        chain = [(0.0, 0.0, table_z), (0.0, 0.0, g.shoulder[2]), g.shoulder, g.elbow, g.wrist, g.tool_corner, g.tcp]
        bar, tool = robot.arm_clearance_mm, robot.gripper_body_mm / 2.0
        points, radii = [], []
        for k, (a, b) in enumerate(zip(chain, chain[1:])):
            steps = max(1, int(math.dist(a, b) / 15.0))
            for i in range(steps + 1):
                t = i / steps
                points.append([a[j] + (b[j] - a[j]) * t for j in range(3)])
                radii.append(tool if k == len(chain) - 2 else bar)

        def project(xyz: np.ndarray, radius: np.ndarray):
            camera = np.c_[xyz, np.ones(len(xyz))] @ to_camera.T
            depth = camera[:, 2]
            ahead = depth > 1.0
            safe = np.where(ahead, depth, 1.0)
            u = intrinsics.fx * camera[:, 0] / safe + intrinsics.cx
            v = intrinsics.fy * camera[:, 1] / safe + intrinsics.cy
            return np.c_[u, v], intrinsics.fx * radius / safe, ahead

        arm_px, arm_r, arm_ok = project(np.asarray(points), np.asarray(radii))
        things, sizes = [], []
        for o in (self._last_scene if only is None else only):
            footprint = _footprint(o) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
            things.append(list(o.xyz_robot))
            sizes.append(max(footprint[:2]) / 2.0 + VIEW_OBJECT_MARGIN_MM)
        for x, y in (self._just_placed if only is None else ()):
            things.append([x, y, table_z + OBJECT_WIDTH_MM / 2.0])
            sizes.append(OBJECT_WIDTH_MM / 2.0 + VIEW_OBJECT_MARGIN_MM)
        thing_px, thing_r, thing_ok = project(np.asarray(things), np.asarray(sizes))
        gap = np.linalg.norm(arm_px[:, None, :] - thing_px[None, :, :], axis=2)
        near = gap < arm_r[:, None] + thing_r[None, :] + VIEW_MARGIN_PX
        return bool((near & arm_ok[:, None] & thing_ok[None, :]).any())

    def _within_bounds(self, pose: Pose) -> bool:
        """Whether `pose` is inside the safe workspace (bounds + reach), as _require_reachable judges it."""
        clamp = getattr(self.robot, "clamp_pose", None)
        if clamp is None:
            return True
        safe = clamp(pose)
        return math.dist((safe.x, safe.y, safe.z), (pose.x, pose.y, pose.z)) <= 3.0

    def _require_reachable(self, pose: Pose, what: str) -> None:
        """Refuse, rather than let the robot silently clamp to somewhere else, when a
        target is outside the safe workspace (bounds + reach limit)."""
        clamp = getattr(self.robot, "clamp_pose", None)
        if clamp is None:
            return
        safe = clamp(pose)
        off = ((safe.x - pose.x) ** 2 + (safe.y - pose.y) ** 2 + (safe.z - pose.z) ** 2) ** 0.5
        wrist_ok = self.gripper.wrist_fits(pose.r, pose.x, pose.y, margin=0.0)
        self.last_record.setdefault("checks", []).append(
            {"what": what, "at": [round(pose.x), round(pose.y), round(pose.z)], "ok": off <= 3.0 and wrist_ok})
        if not wrist_ok:
            raise ValueError(f"{what}: the wrist can't turn to r {pose.r:.0f}° at ({pose.x:.0f}, {pose.y:.0f}) mm "
                             f"({self.gripper.wrist_name} {self.gripper.wrist_turn(pose.r, pose.x, pose.y):+.0f}°, past "
                             "its limit). Not moving. Tell the user.")
        if off > 3.0:
            raise ValueError(
                f"{what} at ({pose.x:.0f}, {pose.y:.0f}, {pose.z:.0f}) mm is outside the robot's "
                f"safe workspace (nearest allowed point is ({safe.x:.0f}, {safe.y:.0f}, {safe.z:.0f})). "
                "Not moving. Tell the user the object is out of reach."
            )

    def _nothing_held(self, note: str = "") -> ValueError:
        """A put-down with nothing in the gripper, said with the calls to make instead: told only "pick an object up
        first", Qwen wrote 512 tokens about it (157 s) before picking (V4.3 twin chain 1, S-14, after take_apart)."""
        seen = [o for o in self._last_scene if o.label == self.last_moved] if self.last_moved else []
        just = getattr(self, "_released_before", None)
        if just is not None and just[0] == self.last_moved and just[3] in WHOLE_MOVES:
            # the step before was a whole move, put down where it was asked to go: picked up again to be put down a
            # second time, it was undone -- study 2, S-20 in the twin: moved 40 mm nearer as asked, then carried off
            # to a saved place, a fail
            label, x, y, step = just
            hint = (f" The {label} was put down by the last step ({step}), at ({x:.0f}, {y:.0f}) mm: that move is "
                    f"done. If that is where the task wants it, don't pick it up again: go on with the rest of the "
                    f"task, or finish." + (f" To move it on from there: pick(object_id=\"{seen[0].id}\") first."
                                           if len(seen) == 1 else ""))
        elif len(seen) == 1:
            hint = (f" The last object moved was the {self.last_moved}: if that is the one, call "
                    f"pick(object_id=\"{seen[0].id}\") and then this step again, both in one answer.")
        elif self.last_moved:
            hint = (f" The last object moved was the {self.last_moved}: if that is the one, call list_objects, pick it "
                    "up, then put it down.")
        else:
            hint = " Call pick for the object to move, then this step again, both in one answer."
        return ValueError("Nothing is being held, so there is nothing to put down." + hint + note)

    def _not_the_held(self, obj: SceneObject, tool: str, role: str) -> None:
        """`obj` named as where the held object goes is the held object itself: refused, with the others to choose
        from. (V4.3 twin chain 2, S-14: place_beside(object_id = the blue cube) with the blue cube in the gripper put
        it "to the left of the blue cube", where the blue cube had been -- 56 mm from where it was asked for.)"""
        held = self._held_obj
        if not self.holding or not (obj.id == getattr(held, "id", None) or (held is None and obj.label == self.holding)):
            return
        others = ", ".join(f"the {o.label} ({o.id})" for o in self._last_scene
                           if o.id != obj.id and o.label != self.holding)
        raise ValueError(f"{obj.id} is the {self.holding} itself, which is in the gripper: object_id in {tool} is the "
                         f"object to put it {role}. Call {tool} again with one of the others"
                         + (f": {others}." if others else "."))

    def _find_object(self, object_id: str) -> SceneObject:
        for obj in self._last_scene:
            if obj.id == object_id:
                return obj
        # an id from an earlier look: the camera gives a cube a new id once it has been moved further than tracking
        # follows (or was hidden a moment). Its colour is clear: the one cube of that colour seen now is it. Study 2,
        # S-06_Run2, S-08_Run2, S-09_Run2, S-11_Run2: "Unknown object_id" six times, the cube in plain view
        label = self._ids_seen.get(str(object_id))
        if label:
            colour = label.split()[0]
            same = [o for o in self._last_scene if o.label.split()[0] == colour and o.label != self.holding]
            if len(same) == 1:
                self._note_target(f"{object_id} was the {label} in an earlier look: now {same[0].id}")
                return same[0]
        held = self._held_obj
        if self.holding and held is not None and str(object_id) == held.id:
            # (not "unknown, call list_objects": that never lists what is held, and the model asked again and again
            # until the run ended with the cube in the gripper -- study 3, S-20)
            raise ValueError(f"{object_id} is the {self.holding} you are holding: list_objects lists only what is on "
                             "the table. Put it down with a place tool (place_free, place_beside, place_on, place_at), "
                             "or drop to let it fall.")
        raise ValueError(f"Unknown object_id: {object_id}. Call list_objects first.")

    def execute(self, name: str, arguments: dict) -> str:
        handler: Callable[[dict], str] | None = getattr(self, f"_tool_{name}", None)
        if handler is None:
            raise ValueError(f"Unknown tool: {name}")
        self._refuse_wrong_cube_size(name)
        self._released_before, self._released_now, self._tool_now = self._released_now, None, name
        self.last_record = {"moves": [], "checks": [], "target_from": None}
        self.robot.moves = self.last_record["moves"]
        arguments = dict(arguments)
        note = ""
        if name.startswith("place") and (arguments.get("turn_deg") is not None or arguments.get("angle_deg") is not None):
            turn, angle = arguments.pop("turn_deg", None), arguments.pop("angle_deg", None)
            note = self._want_turn(float(angle if angle is not None else turn), absolute=angle is not None)
        try:
            result = handler(arguments)
            return (result.rstrip(".") + "." + note) if note and isinstance(result, str) else result
        finally:
            self._wanted_turn = None
            self.robot.moves = None
            try:
                pose = self.robot.get_pose()
                self.last_record["arm_after"] = [round(pose.x, 1), round(pose.y, 1), round(pose.z, 1)]
            except Exception:  # noqa: BLE001 - the record is a nice-to-have, never a reason to fail
                pass
            self.last_record["holding_after"] = self.holding

    def _note_target(self, text: str) -> None:
        """Where the step's target came from, in words (the first one said wins: the step's own target)."""
        if self.last_record.get("target_from") is None:
            self.last_record["target_from"] = text

    def _grip_unfelt(self) -> bool:
        """A robot that can't feel what its fingers hold (the Dobot): the camera checks for it."""
        return self.check_picks and getattr(self.robot, "held_object", _UNKNOWN) is _UNKNOWN

    def _check_let_go(self) -> None:
        """The object last let go of is somewhere on the table in the look just taken (its colour, anywhere: a cube that
        slid or fell is no worry here). Not seen at all, it may still be in the fingers -- the arm then waits for a
        person (the Dobot's needs_person, cleared by Home) and the step is refused. Study 4, S-08: the blue cube,
        gripped across its corners, stayed wedged in the open fingers; the swap went on to the green cube, and the
        turn after it put the blue one down on the green."""
        let_go, self._let_go = self._let_go, None
        if let_go is None or not self._grip_unfelt():
            return
        label, x, y = let_go
        colour = label.split()[0]
        if self.holding == label or any(o.label.split()[0] == colour for o in self._last_scene):
            return
        why = LET_GO_UNSEEN.format(label=label, x=x, y=y)
        hold = getattr(self.robot, "hold_for_person", None)
        if hold is not None:
            hold(why)
        raise ValueError(why)

    def _tool_list_objects(self, args: dict) -> str:
        if not self.calibration_ready():
            # Uncalibrated, positions are raw camera coordinates, not robot coordinates.
            # Acting on them sent the real arm to unreachable points and tripped alarms.
            raise ValueError(
                "The camera is not calibrated, so object positions can't be used to move "
                "the robot. Tell the user to calibrate first (Calibration tab)."
            )
        if self.look_pose is not None:
            self._require_reachable(self.look_pose, "Look position")
            here = self.robot.get_pose()
            # Out of the camera's way, but no further than needed: it went all the way to the parking spot before
            # every look, a long swing between every two cubes (the xArm's high up and far to the side).
            spot = self._view_spot(here)
            if math.dist((here.x, here.y, here.z), (spot.x, spot.y, spot.z)) > 20.0:
                look = self.look_pose
                if spot is look:
                    self._note_target(f"the parking spot out of the camera's view ({look.x:.0f}, {look.y:.0f}, "
                                      f"{look.z:.0f})")
                    spot = Pose(x=look.x, y=look.y, z=look.z, r=self._carry_turn(look.x, look.y))
                else:
                    self._note_target(f"just out of the camera's view of the objects ({spot.x:.0f}, {spot.y:.0f}, "
                                      f"{spot.z:.0f})")
                self._travel(spot)
        if getattr(self, "_checking_pick", False) or getattr(self, "_picking_again", False):
            # a camera queues pictures: one from before the pick shows the cube still there -- a grip that held read
            # as missed, and the gripper opened (on the real arm, the cube dropped from the look spot). Skipped, as
            # the calibration does (app.calibration.auto.FLUSH_FRAMES; the live-mode test's camera, 3 behind)
            camera = getattr(self.scene_builder, "camera", None)
            for _ in range(QUEUED_PICTURES if camera is not None else 0):
                try:
                    camera.get_frame()
                except Exception:  # noqa: BLE001 - a picture missed is one skipped fewer
                    break
        before = list(self._last_scene)
        self._last_scene = self.scene_builder.get_scene()
        self._ids_seen.update({o.id: o.label for o in self._last_scene})
        self._listed = True
        self._check_let_go()
        self._check_cube_size()
        self._just_placed.clear()
        self._learn_heights()
        self._note_start_of_prompt()
        places_words = self._where_words()
        objects = []
        for o in self._last_scene:
            entry = {"id": o.id, "label": o.label, "xyz_mm": tuple(round(v) for v in o.xyz_robot),
                     "confidence": round(o.confidence, 2)}
            footprint = _footprint(o)
            if footprint is not None:
                # its top face seen from above: narrow side, long side (mm)
                entry["footprint_mm"] = [round(footprint[0]), round(footprint[1])]
                if self.gripper.fingers and footprint[0] > self.gripper.widest_mm:
                    entry["gripper"] = (f"too wide: {footprint[0]:.0f} mm across its narrowest side, the gripper "
                                        f"opens {self.gripper.opening_mm:.1f} mm")
            if o.label in self._heights:
                # its own size (top minus what it stands on), as measured while it stood on the table: the
                # detector names things by colour only, so this is how "the small one" can be told apart
                entry["height_mm"] = round(self._heights[o.label])
            cover = self._covered_by(o)
            if cover is not None:
                entry["covered_by"] = cover.label
            if places_words.get(o.id):
                entry["where"] = places_words[o.id]
            objects.append(entry)
        result = {
            "holding": self.holding,
            "objects": objects,
            "saved_places": sorted(self._saved_places()),
        }
        gone = self._out_of_view(before)
        if gone:
            result["not_seen_now"] = gone
            result["not_seen_note"] = ("Seen before (or put down) and not seen now: out of the camera's view, or moved by "
                                       "hand. They can't be picked. If the user asks for one, say so in these words; "
                                       "don't say it isn't there.")
        hidden = self._hidden_objects()
        if hidden:
            result["hidden"] = hidden
        if self.cube_mismatch is not None:
            measured, setting, other = self.cube_mismatch
            result["cube_size_warning"] = (f"The cubes measure about {measured:.0f} mm, but the cube size is set to "
                                           f"{describe_cube(setting)}: nothing can be moved until the user sets it. "
                                           f"Tell the user, in these words.")
        if hidden:
            result["note"] = ("A hidden object can't be seen or picked up. To get it, pick the object on top of it "
                              "(named under 'under') and put it on a free spot with place_free, then list_objects again.")
        return str(result)

    def _out_of_view(self, before: list) -> list[dict]:
        """What was in the last look (or put down since) and is not in this one: [{"label", "last_at_mm", "why"}] --
        out of the camera's view where it was last, or no longer seen there (moved by hand, or taken away). ("I cannot
        fulfill the request because there is no red cube", said of a red cube the app itself had put out of the
        camera's sight.)"""
        seen = {o.label for o in self._last_scene}
        gone = []
        for o in before:
            if o.label in seen or o.label == self.holding:
                continue
            x, y, z = o.xyz_robot
            if any(n.label.split()[0] == o.label.split()[0] and math.dist(n.xyz_robot[:2], (x, y)) <= 30.0
                   for n in self._last_scene):
                continue                  # the same one, named another shape this time (a noisy picture)
            out = self._in_view(x, y, z) is False
            gone.append({"label": o.label, "last_at_mm": (round(x), round(y)),
                         "why": "out of the camera's view there" if out else "no longer seen where it was"})
        return gone

    def _where_words(self) -> dict[str, str]:
        """Each object's place in words, for "the one on the left" / "the nearest cube" / "the one in the tray":
        {id: "leftmost, nearest the robot, in the tray"}. Left / right as the robot sees it (left = +y)."""
        seen = [o for o in self._last_scene if o.label != self.holding]
        words: dict[str, list[str]] = {o.id: [] for o in seen}
        places = self._saved_places()
        for o in seen:
            fp = _footprint(o)
            if self._in_view(*o.xyz_robot, radius_mm=(max(fp[:2]) / 2.0) if fp else OBJECT_WIDTH_MM / 2.0) is False:
                words[o.id].append("at the edge of the camera's view (only partly seen: its size may be wrong)")
        loose = []
        for o in seen:
            inside = [name for name in places if self._in_place_quietly(o, name)]
            below = self._below(o)
            if below is not None:
                words[o.id].append(f"on the {below.label}")
            words[o.id] += [f"in the {name}" for name in inside]
            if not inside and below is None:
                loose.append(o)
        if len(loose) >= 2:
            for test, word in ((max, "leftmost"), (min, "rightmost")):
                words[test(loose, key=lambda o: o.xyz_robot[1]).id].append(word)
            for test, word in ((min, "nearest the robot"), (max, "farthest from the robot")):
                words[test(loose, key=lambda o: math.hypot(*o.xyz_robot[:2])).id].append(word)
        # small or large among its own kind, when sizes differ: "the small cubes in the small bin" left a 20 mm cube
        # out as "medium size", the same size as the 20 mm cube it called large
        kinds: dict[str, list] = {}
        for o in seen:
            if o.label in self._heights:
                kinds.setdefault(o.label.split()[-1], []).append(o)
        for group in kinds.values():
            sizes = sorted(self._heights[o.label] for o in group)
            if len(group) < 2 or sizes[-1] - sizes[0] < SIZE_STEP_MM:
                continue
            _, cut = max((b - a, (a + b) / 2.0) for a, b in zip(sizes, sizes[1:]))
            for o in group:
                words[o.id].append("small" if self._heights[o.label] < cut else "large")
        return {oid: ", ".join(w) for oid, w in words.items() if w}

    def _in_place_quietly(self, obj, name: str) -> bool:
        try:
            return self._inside_place(obj, name)
        except ValueError:
            return False

    # ---- what is on top of what ----------------------------------------------------------------
    def _covered_by(self, obj: SceneObject) -> Optional[SceneObject]:
        """The object sitting (nearly) right on `obj`, if any: of those above it, the lowest. (The first one found
        was taken: in a pile of three, the bottom one was "covered by" the top one, the middle one left out.)"""
        above = [other for other in self._last_scene if self._sits_above(other, obj)]
        return min(above, key=lambda other: other.xyz_robot[2], default=None)

    def _sits_above(self, other: SceneObject, obj: SceneObject) -> bool:
        """Whether `other` is above `obj`, over it (on it, or higher up the same pile)."""
        if other is obj or other.label == self.holding or obj.label == self.holding:
            return False          # what the gripper carries hovers over things without being "on" them
        if other.xyz_robot[2] - obj.xyz_robot[2] < COVER_HEIGHT_MM:
            return False
        footprint = _footprint(obj)
        dx, dy = other.xyz_robot[0] - obj.xyz_robot[0], other.xyz_robot[1] - obj.xyz_robot[1]
        if footprint is None:
            return math.hypot(dx, dy) < COVER_DISTANCE_MM
        # on it: its middle over this one's top (as measured). Within 35 mm alone, a taller neighbour packed
        # beside it in a tray "covered" it, and picking it would first have moved that neighbour aside
        width, length, angle = footprint
        c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
        return abs(dx * c + dy * s) <= length / 2.0 + 3.0 and abs(-dx * s + dy * c) <= width / 2.0 + 3.0

    def _top_of_pile(self, obj: SceneObject) -> SceneObject:
        """The highest object in the pile `obj` is part of."""
        for _ in range(len(self._last_scene)):
            above = self._covered_by(obj)
            if above is None:
                break
            obj = above
        return obj

    def _below(self, obj: SceneObject) -> Optional[SceneObject]:
        """The object `obj` sits on, if any."""
        return next((o for o in self._last_scene if o is not obj and self._covered_by(o) is obj), None)

    def _pile_of(self, obj: SceneObject) -> list[str]:
        """The pile `obj` is part of, bottom to top (labels), including a lower object the camera can no longer
        see but that we remember stacking on."""
        bottom = obj
        for _ in range(len(self._last_scene)):
            under = self._below(bottom)
            if under is None:
                break
            bottom = under
        pile = [bottom]
        for _ in range(len(self._last_scene)):
            above = self._covered_by(pile[-1])
            if above is None or above in pile:
                break
            pile.append(above)
        labels = [o.label for o in pile]
        seen = {o.label for o in self._last_scene}
        for _ in range(len(self._under)):
            hidden = next((lower for lower, upper in self._under.items()
                           if upper == labels[0] and lower not in seen and lower not in labels), None)
            if hidden is None:
                break
            labels.insert(0, hidden)
        return labels

    def piles(self) -> list[list[str]]:
        """Every pile of two or more objects, as last seen or placed, bottom to top (labels)."""
        found, counted = [], set()
        for o in self._last_scene:
            if o.label in counted or o.label == self.holding:
                continue
            pile = self._pile_of(o)
            counted.update(pile)
            if len(pile) > 1:
                found.append(pile)
        return found

    def _hidden_objects(self) -> list[dict]:
        """Objects we stacked something on and can no longer see: [{'label', 'under'}]. The memory is only
        kept while the object on top is still in view; otherwise things have been moved and it is stale."""
        seen = {o.label for o in self._last_scene}
        hidden = []
        for lower, upper in list(self._under.items()):
            if upper not in seen or lower in seen:
                self._under.pop(lower, None)          # the pile was changed: forget what we remembered of it
            else:
                hidden.append({"label": lower, "under": upper})
        return hidden

    def _learn_heights(self) -> None:
        """An object shows its own height: its top minus what it stands on -- the table, or the top of the object
        it sits on. One sitting on something the camera can't see (we stacked it there) is left as it was: measured
        from the table it came out as the whole pile's height (a 12 mm block on a 25 mm cube: "37 mm"), and the
        fingers went down past its bottom into the cube under it."""
        table_z = self.table_z_provider()
        if table_z is None:
            return
        stacked_on_something = set(self._under.values())
        for o in self._last_scene:
            if self._covered_by(o) is not None:
                continue
            below = self._below(o)
            if below is not None:
                height = o.xyz_robot[2] - below.xyz_robot[2]
            elif o.label in stacked_on_something:
                continue
            else:
                # on the table, or on a tray's or bin's floor (from the table, two 20 mm cubes in the tray were
                # "24 mm", and one put on the other was let go 4 mm up)
                height = o.xyz_robot[2] - self._floor_under(o.xyz_robot[0], o.xyz_robot[1], table_z)
            if 8.0 <= height <= 45.0:
                self._heights[o.label] = round(height, 1)

    def _floor_under(self, x: float, y: float, table_z: float) -> float:
        """What something standing at (x, y) stands on: the floor of a tray or bin it is inside (a scene place of
        known size), else the table."""
        areas = self._place_areas()
        if areas:
            places = self._saved_places()
            for name, (inner_x, inner_y, _) in areas.items():
                place = places.get(name)
                if place is not None and abs(x - place.x) <= inner_x / 2 and abs(y - place.y) <= inner_y / 2:
                    return place.z
        return table_z

    def _tool_pick(self, args: dict) -> str:
        put_aside = ""
        if self.holding and self._held_only_in_the_way():
            # (S-19 in the twin, 2026-10-24: it picked the blue cube off the red one to get at red, then couldn't put
            # it anywhere -- blue wasn't asked for -- nor pick red, "already holding"; stuck till the time ran out,
            # still holding it.) What it holds was only in the way: put down on a free spot first.
            held = self.holding
            put = self._tool_place_free({"where": "outside"})
            self._tool_list_objects({})
            put_aside = f"The {held} (not asked for, only in the way) was put down first ({put.rstrip('.')}). "
        if self.holding:
            # pick() opens the gripper first, which would drop whatever is held.
            raise ValueError(f"Already holding the {self.holding}. Put it down first "
                             "(place_at a saved place, or place_on an object).")
        self._look_first()
        obj = self._find_object(args["object_id"])
        moved_aside = ""
        cover = self._covered_by(obj)
        if cover is not None:
            # Going straight down would come down through the object on top (a collision on a real arm),
            # so that one is moved out of the way first, here, rather than left to the model to remember.
            obj, moved_aside = self._clear_the_way(obj, cover)
        moved_aside = put_aside + moved_aside
        try:
            return moved_aside + self._pick_up(obj)
        except ValueError as exc:
            if MISSED_GRIP in str(exc) and not getattr(self, "_picking_again", False):
                return moved_aside + self._pick_again(obj, str(exc))
            room = self._make_room(obj, str(exc))
            if room is None:
                raise
            obj, made = room
            return moved_aside + made + self._pick_up(obj)

    def _make_room(self, obj: SceneObject, why: str) -> Optional[tuple[SceneObject, str]]:
        """A pick refused because the open gripper would hit a neighbour (a bumped cube against another): that one
        moved aside to a free spot first -- if the request doesn't name it (the "allowed preparation" rule: only a cube
        in the way, never one of the task's own) -- and `obj` as seen after. None: no room to make (refused as before)."""
        import re as _re
        from app.llm.request_checks import colour_of, named_colours
        found = _re.search(r"would hit the (.+?) beside it", why)
        request = str(getattr(self, "request", "") or "")
        if found is None or self.holding or getattr(self, "_making_room", False) or not request:
            return None
        neighbour = min((o for o in self._last_scene if o.label == found.group(1) and o.id != obj.id),
                        key=lambda o: math.dist(o.xyz_robot[:2], obj.xyz_robot[:2]), default=None)
        if neighbour is None or colour_of(neighbour.label) in set(named_colours(request)):
            return None
        if self._covered_by(neighbour) is not None:
            return None
        self._making_room = True
        try:
            self._pick_up(neighbour)
            put = self._tool_place_free({"where": "outside"})
            self._tool_list_objects({})
        except ValueError:
            return None
        finally:
            self._making_room = False
        again = min((o for o in self._last_scene if o.label == obj.label),
                    key=lambda o: math.dist(o.xyz_robot[:2], obj.xyz_robot[:2]), default=None)
        if again is None:
            return None
        return again, (f"The {neighbour.label} was too close for the open gripper, so it was moved aside first "
                       f"({put.rstrip('.')}). ")

    def _pick_again(self, obj: SceneObject, why: str) -> str:
        """The grip missed (the cube still on the table where it was): looked at again and picked once more."""
        self._picking_again = True
        try:
            self._tool_list_objects({})
            # by its name, or else by its colour near where it was: the camera may name its shape another way from one
            # look to the next (the realistic twin, this round's E3: "green cylinder", then "green cube" -- "can't be
            # seen now"; the lab, 2026-10-22: "blue cylinder" and back)
            colour = obj.label.split()[0]
            same = [o for o in self._last_scene if o.label == obj.label] or [
                o for o in self._last_scene if o.label.split()[0] == colour
                and math.dist(o.xyz_robot[:2], obj.xyz_robot[:2]) <= MISSED_NEAR_MM]
            again = min(same, key=lambda o: math.dist(o.xyz_robot[:2], obj.xyz_robot[:2]), default=None)
            if again is None:
                raise ValueError(f"{why} Looked again: the {obj.label} can't be seen now. Tell the user.")
            try:
                return f"The first grip missed the {obj.label}; looked again and picked it once more. " + \
                    self._pick_up(again)
            except ValueError as exc:
                raise ValueError(f"{exc} (the second try)") from None
        finally:
            self._picking_again = False

    def _clear_the_way(self, obj: SceneObject, cover: SceneObject, depth: int = 0) -> tuple[SceneObject, str]:
        """Puts `cover` (which is on top of `obj`) down on the nearest free spot, looks again, and
        returns `obj` as it is seen now, plus a sentence saying what was done. If `cover` has another on it, that one
        is moved aside first (the bottom of a tower of three: V4.2 -- it was refused as "too high to take apart", so
        no task could start from a tower of three); higher than that is refused."""
        said_above = ""
        above = self._covered_by(cover)
        if above is not None:
            if depth >= CLEAR_LEVELS - 1:
                raise ValueError(f"The {obj.label} is under the {cover.label}, which is itself under more than one "
                                 "other object. Tell the user the pile is too high to take apart.")
            cover, said_above = self._clear_the_way(cover, above, depth + 1)
        if self.table_z_provider() is None:
            raise ValueError(f"The {obj.label} has the {cover.label} on top of it, and the table height isn't known "
                             "yet, so the arm can't move the top one aside. Tell the user to do the calibration's "
                             "table-height step, or to move the top object by hand.")
        self._pick_up(cover)
        held = _footprint(self._held_obj) if self._held_obj is not None else None
        self._set_aside[cover.id] = (float(cover.xyz_robot[0]), float(cover.xyz_robot[1]),
                                     float(held[2]) if held is not None else None, obj.id)
        moved = self._tool_place_free({"where": "next_to", "object_id": obj.id})
        self._tool_list_objects({})                 # the arm holds nothing now: look again
        same = [o for o in self._last_scene if o.label == obj.label]     # (there may be two of a colour: take the nearest)
        again = min(same, key=lambda o: math.dist(o.xyz_robot[:2], obj.xyz_robot[:2]), default=None)
        if again is None:
            raise ValueError(f"After moving the {cover.label} aside I can no longer see the {obj.label}. Tell the user.")
        if self._covered_by(again) is not None:
            raise ValueError(f"The {obj.label} still has something on top of it after moving the {cover.label}. Tell the user.")
        return again, (said_above + f"The {cover.label} was on top of the {obj.label}, so it was moved aside first. "
                       f"({moved}) ")

    def _clear_view_of(self, obj: SceneObject) -> None:
        """The arm out from between the camera and `obj` before the pick's fresh pictures of it (its turn, where it is
        now), as list_objects takes it out of the way of all of them. This round's E3 (the realistic twin, S-07): the
        swap had just put the red cube down at (228, -68), the gripper still over it -- on the camera's line to the blue
        cube at (178, 1); the part of the blue cube left in view put it at (187, 8), and the turn came down 11 mm off,
        onto it."""
        if self.look_pose is None or self.holding:
            return
        here = self.robot.get_pose()
        if not self._hides_objects(here, only=[obj]):
            return                                   # (clear, or it can't be told: as before)
        spot = self._view_spot(here)
        if spot is self.look_pose:
            spot = Pose(x=spot.x, y=spot.y, z=spot.z, r=self._carry_turn(spot.x, spot.y))
        self.last_record["view_cleared"] = {"object": obj.label, "from": [round(here.x), round(here.y), round(here.z)],
                                            "to": [round(spot.x), round(spot.y), round(spot.z)]}
        self._travel(spot)

    def _steady_angle(self, obj: SceneObject) -> SceneObject:
        """The object as listed, its turn read again from several pictures (their average): they must agree within
        ANGLE_AGREE_DEG, one reading in four -- the furthest off -- left out (a square looks the same every quarter
        turn). If they don't, it looks again and judges all the readings together; if they still don't, the pick is
        refused, saying why. Something round has no turn to read. Listed without an outline (the colour finder gives
        none), its turn comes from these pictures; where the camera can't see it now (the arm in the way), as
        listed."""
        footprint = _footprint(obj)
        label = str(getattr(obj, "label", ""))
        if not self.gripper.fingers or self.angle_looks < 2 or label.split()[-1:] and label.split()[-1] in ROUND_SHAPES:
            return obj
        reader = getattr(self.scene_builder, "footprints_near", None)
        if reader is None:
            return obj
        seer = getattr(self.scene_builder, "looks_near", None)     # (the same pictures, with where it was seen)
        self._clear_view_of(obj)
        prints: list = []
        places: list = []
        spread = 0.0
        for attempt in range(2):
            if callable(seer):
                both = seer(obj.xyz_robot[0], obj.xyz_robot[1], self.angle_looks)
                new = [footprint for footprint, _ in both]
                places += [xyz for _, xyz in both]
            else:
                new = reader(obj.xyz_robot[0], obj.xyz_robot[1], self.angle_looks)
            prints += new
            if len(prints) < 2:
                if attempt == 0:
                    return obj                   # (the camera can't see it now: as listed)
                break                            # (unsteady the first time, and now too few looks to say: refused)
            if footprint is not None:
                width, length = footprint[0], footprint[1]
            else:                                # (no outline listed: its size as these pictures measure it)
                width = float(statistics.median(p[0] for p in prints))
                length = float(statistics.median(p[1] for p in prints))
            period = 90.0 if length - width <= SQUARE_MM else 180.0
            mean, spread, dropped = steady_mean([p[2] for p in prints], period)
            if spread <= ANGLE_AGREE_DEG or (spread <= ANGLE_SPREAD_MAX_DEG
                                             and _mean_error([p[2] for p in prints], mean, period,
                                                             dropped) <= ANGLE_MEAN_DEG) or (
                    attempt > 0 and len(new) >= 2 and spread <= ANGLE_SPREAD_LIMIT_DEG):   # (a 2nd look seen)
                self.last_record["angle"] = {"object": obj.label, "looks": len(prints), "left_out": dropped,
                                             "spread_deg": round(spread, 1), "again": attempt > 0,
                                             "from_looks": footprint is None}
                return self._where_seen_now(
                    replace(obj, footprint=(round(width, 1), round(length, 1), round(mean % 180.0, 1))), places)
        again = self._angle_from_afar(obj, footprint)
        if again is not None:                    # (the arm out of the way, many more pictures: they agree now)
            return again
        known = self._as_put_down(obj, [p[2] for p in prints], period, width, length) if len(prints) >= 2 else None
        if known is not None:                    # (the arm put it down itself, and the pictures agree with that)
            return known
        self.last_record["angle"] = {"object": obj.label, "looks": len(prints), "spread_deg": round(spread, 1),
                                     "refused": True}
        raise ValueError(f"Can't pick up the {obj.label}: the camera's reading of which way it is turned kept changing "
                         f"(by up to {spread:.0f}° over {len(prints)} pictures, the worst left out), so the fingers "
                         "could land on it. Call list_objects to look again, or tell the user.")

    def _as_put_down(self, obj: SceneObject, angles: list, period: float, width: float,
                     length: float) -> Optional[SceneObject]:
        """The object at the turn the arm put it down at, if it did so itself (and hasn't picked it since), it still
        stands within PUT_DOWN_NEAR_MM of there, and the unsteady pictures' average agrees with that turn within
        PUT_DOWN_AGREE_DEG -- else None (refused as before). The swap's own cube, just set aside, was refused at 16.5
        and 17.2 degrees of spread and the swap left half done (study 3, S-07, S-10): its turn was known."""
        placed = self._placed_angles.get(obj.id)
        if placed is None or math.dist(placed[:2], obj.xyz_robot[:2]) > PUT_DOWN_NEAR_MM or not angles:
            return None
        mean, spread, _ = steady_mean(angles, period)
        off = (mean - placed[2] + period / 2.0) % period - period / 2.0
        if abs(off) > PUT_DOWN_AGREE_DEG:
            return None
        self.last_record["angle"] = {"object": obj.label, "looks": len(angles), "spread_deg": round(spread, 1),
                                     "again": True, "as_put_down": True, "seen_off_deg": round(off, 1)}
        logger.info("The %s's turn readings spread %.1f°: picked at the turn it was put down at (%.1f°; their average "
                    "%.1f° from it)", obj.label, spread, placed[2], off)
        return replace(obj, footprint=(round(width, 1), round(length, 1), round(placed[2] % 180.0, 1)))

    def _where_seen_now(self, obj: SceneObject, places: list) -> SceneObject:
        """The object where the pick's fresh pictures see it (the middle of their places), if that is MOVED_MIN_MM or
        more from where it was listed -- it slid since the last look; else as listed. Its height stays as listed."""
        if len(places) < 2:
            return obj
        x = float(statistics.median(p[0] for p in places))
        y = float(statistics.median(p[1] for p in places))
        moved = math.dist((x, y), obj.xyz_robot[:2])
        if moved < MOVED_MIN_MM:
            return obj
        logger.info("The %s is seen %.1f mm from where it was listed (%.1f, %.1f): picked where it is now (%.1f, %.1f)",
                    obj.label, moved, obj.xyz_robot[0], obj.xyz_robot[1], x, y)
        self.last_record["moved"] = {"object": obj.label, "mm": round(moved, 1),
                                     "from": [round(v, 1) for v in obj.xyz_robot[:2]], "to": [round(x, 1), round(y, 1)]}
        return replace(obj, xyz_robot=(x, y, obj.xyz_robot[2]))

    def _angle_from_afar(self, obj: SceneObject, footprint) -> Optional[SceneObject]:
        """Before a pick is refused for an unsteady reading (V4.2; the Dobot's S-06, S-08: 16-17 degrees, the arm or
        a neighbour partly hiding a bumped cube): the arm out of the camera's view (list_objects), ANGLE_RETRY_LOOKS
        fresh pictures, judged as before -- agreeing, or their average known well enough, up to the second look's
        limit. The object, its turn read so, or None (refused as before: the fingers fit only within ~6 degrees)."""
        reader = getattr(self.scene_builder, "footprints_near", None)
        if reader is None or getattr(self, "_angle_retry", False) or self.holding:
            return None
        self._angle_retry = True
        try:
            self._tool_list_objects({})
            near = min((o for o in self._last_scene if o.label == obj.label
                        and math.dist(o.xyz_robot[:2], obj.xyz_robot[:2]) <= TURN_NEAR_MM),
                       key=lambda o: math.dist(o.xyz_robot[:2], obj.xyz_robot[:2]), default=None)
            if near is None:
                return None
            prints = reader(near.xyz_robot[0], near.xyz_robot[1], ANGLE_RETRY_LOOKS)
            if len(prints) < 3:
                return None
            width = footprint[0] if footprint is not None else float(statistics.median(q[0] for q in prints))
            length = footprint[1] if footprint is not None else float(statistics.median(q[1] for q in prints))
            period = 90.0 if length - width <= SQUARE_MM else 180.0
            angles = [q[2] for q in prints]
            mean, spread, dropped = steady_mean(angles, period)
            if not (spread <= ANGLE_AGREE_DEG or (spread <= ANGLE_SPREAD_LIMIT_DEG
                                                  and _mean_error(angles, mean, period, dropped) <= ANGLE_MEAN_DEG)):
                return None
            self.last_record["angle"] = {"object": obj.label, "looks": len(prints), "left_out": dropped,
                                         "spread_deg": round(spread, 1), "again": True, "from_afar": True}
            return replace(near, footprint=(round(width, 1), round(length, 1), round(mean % 180.0, 1)))
        finally:
            self._angle_retry = False

    def _pick_up(self, obj: SceneObject) -> str:
        if self._let_go is not None and self._grip_unfelt():
            self._tool_list_objects({})     # (what was let go of is on the table, not still in the fingers)
            obj = next((o for o in self._last_scene if o.id == obj.id), obj)
        x, y, z = obj.xyz_robot
        self._note_target(f"camera: top of the {obj.label} ({obj.id}) at ({x:.0f}, {y:.0f}, {z:.0f})")
        r, grip_z = 0.0, z
        if self.gripper.fingers:
            obj = self._steady_angle(obj)
            x, y = obj.xyz_robot[:2]                # (where its fresh pictures see it, if it slid since the last look)
            try:
                try:
                    plan = plan_grip(self.gripper, x, y, z, self._heights.get(obj.label), _footprint(obj),
                                     blocked=lambda direction, depth: self._finger_hits(obj, direction, depth))
                except ValueError:
                    wider = self._measured_again(obj)    # (a cube read too wide once: its width from fresh pictures)
                    if wider is None:
                        raise
                    obj = wider
                    plan = plan_grip(self.gripper, x, y, z, self._heights.get(obj.label), _footprint(obj),
                                     blocked=lambda direction, depth: self._finger_hits(obj, direction, depth))
            except ValueError as exc:
                self.last_record["grip"] = {"object": obj.label, "footprint": _footprint(obj), "refused": str(exc)}
                raise ValueError(f"Can't pick up the {obj.label}: {exc}") from None
            r, grip_z = plan.r, z - plan.depth_mm
            self.last_record["grip"] = {"object": obj.label, "footprint": _footprint(obj), "r": plan.r, "j4": plan.j4,
                                        "across_mm": plan.across_mm, "spare_mm": plan.spare_mm,
                                        "depth_mm": plan.depth_mm, "note": plan.note,
                                        "wrist": self._wrist_note(x, y, r)}
            # every grip of a call, in order ("grip" is only the last: a swap's first grips were lost from the
            # records -- study 3, S-06, picks.csv's swap row had the first pick's place with the last pick's r)
            self.last_record.setdefault("grips", []).append(
                {"object": obj.label, "xy": [round(x, 1), round(y, 1)], "seen_deg": (_footprint(obj) or (0, 0, None))[2],
                 "r": plan.r, "j4": plan.j4})
        above_z = self._approach_or_refuse(x, y, z, f"The {obj.label}")
        self._require_reachable(Pose(x=x, y=y, z=above_z, r=r), obj.label)
        self._require_reachable(Pose(x=x, y=y, z=grip_z, r=r), obj.label)
        self.robot.open_gripper()
        above = Pose(x=x, y=y, z=above_z, r=r)
        turned = self._travel_turned(above)   # the fingers turn on the way
        self._down_to_grip(above, grip_z, turned)
        self.robot.close_gripper()
        if getattr(self.robot, "held_object", _UNKNOWN) is None:
            # the demo knows whether the gripper really took hold (the real one has no sensor for it). Missed, it is
            # looked at again and picked once more, as on the Dobot (pick's MISSED_GRIP): E3 of the study 2 round,
            # S-01 with the realistic camera -- a reading 2 mm off put a finger on the cube's edge, and the model,
            # told only that it closed on nothing, said the gripper was too narrow and gave up
            problem = getattr(self.robot, "last_grip_problem", "") or "nothing between the fingers"
            self.robot.open_gripper()
            self.robot.move_to(Pose(x=x, y=y, z=above_z, r=r))
            raise ValueError(f"{MISSED_GRIP}: the gripper closed on nothing ({problem}), so the {obj.label} was not "
                             "picked up. Call list_objects to look again, then pick it.")
        self.robot.move_to(Pose(x=x, y=y, z=above_z, r=r))
        self.holding = obj.label
        self._held_obj = obj
        self._placed_angles.pop(obj.id, None)
        self._held_height = self._heights.get(obj.label, DEFAULT_OBJECT_HEIGHT_MM)
        self._grip_r, self._grip_depth = r, z - grip_z
        self._held_square = _footprint(obj) is None or _footprint(obj)[1] - _footprint(obj)[0] <= SQUARE_MM
        if (self.check_picks and getattr(self.robot, "held_object", _UNKNOWN) is _UNKNOWN
                and not getattr(self, "_checking_pick", False)):
            self._checking_pick = True
            try:
                self._tool_list_objects({})          # (the arm, with what it holds, out of the camera's view)
            finally:
                self._checking_pick = False
            if any(o.label == obj.label and math.dist(o.xyz_robot[:2], (x, y)) <= MISS_NEAR_MM
                   and abs(o.xyz_robot[2] - z) <= MISS_NEAR_MM for o in self._last_scene):
                self.robot.open_gripper()
                self.holding, self._held_obj = None, None
                self._grip_r, self._grip_depth, self._held_square = 0.0, 0.0, True
                raise ValueError(f"{MISSED_GRIP}: the {obj.label} is still on the table where it was. Call list_objects "
                                 "to look again, then pick it.")
        # lifting it takes it off whatever it was on, and uncovers whatever was under it
        self._under.pop(obj.label, None)
        for lower, upper in list(self._under.items()):
            if upper == obj.label:
                del self._under[lower]
        return f"Picked up {obj.label} ({obj.id})"

    def _measured_again(self, obj: SceneObject) -> Optional[SceneObject]:
        """A cube read too wide for the fingers, but no wider than a cube's own outline turned 45 degrees (25 mm reads
        up to ~35 across: the Dobot's S-09, 2026-10-23, "36 mm across its narrowest side"): its width taken again from
        several fresh pictures (the median). The object with that width if it now fits the fingers, else None (refused
        as before -- never assumed to fit)."""
        footprint = _footprint(obj)
        label = str(getattr(obj, "label", ""))
        reader = getattr(self.scene_builder, "footprints_near", None)
        if footprint is None or reader is None or not label.endswith("cube"):
            return None
        if not self.gripper.widest_mm < footprint[0] <= CUBE_TURNED_MAX_MM:
            return None
        prints = reader(obj.xyz_robot[0], obj.xyz_robot[1], max(self.angle_looks, WIDTH_LOOKS))
        fits = [p for p in prints if min(p[0], p[1]) <= self.gripper.widest_mm]
        if len(prints) < 4 or 3 * len(fits) < 2 * len(prints):
            return None                            # (at least 4 pictures, two thirds of them saying it fits)
        width = statistics.median(min(p[0], p[1]) for p in prints)
        length = statistics.median(max(p[0], p[1]) for p in prints)
        if width > self.gripper.widest_mm:
            return None
        return replace(obj, footprint=(round(width, 1), round(length, 1), footprint[2]))

    def _travel_turned(self, above: Pose) -> bool:
        """Travel to `above`, with fingers ending the way there short of its angle, then turned up to it: the wrist
        comes to its angle from one side as approach_from_side has it (the gears' slack taken up alike), one move
        fewer than travelling to the angle and then turning past it and back (V4.3: about 2 s a pick or a place on
        the Dobot, study 1). True if it came to the angle so; False: the travel went straight to it."""
        pre = self.wrist.pre_turn(self.wrist_overshoot_deg) if self.gripper.fingers else 0.0
        before = above.r + self.wrist.side * pre
        if pre > 0.0 and self.gripper.wrist_fits(before, above.x, above.y):
            self._travel(Pose(x=above.x, y=above.y, z=above.z, r=before))
            self.robot.move_to(above)
            return True
        self._travel(above)
        return False

    def _down_to_grip(self, above: Pose, grip_z: float, turned: bool = False) -> None:
        """From above the object down to the grip: with fingers, the wrist first brought to its angle from one side
        (the gears' slack always taken up the same way, so the fingers' angle repeats) and the last SLOW_LAST_MM
        slowly (the fingers don't knock a light cube aside)."""
        x, y, r = above.x, above.y, above.r
        if not self.gripper.fingers:
            self.robot.move_to(Pose(x=x, y=y, z=grip_z, r=r))
            return
        if not turned:
            approach_from_side(self.robot, above, self.gripper, self.wrist.pre_turn(self.wrist_overshoot_deg),
                               self.wrist.side)
        slow_from = grip_z + self.slow_last_mm
        if self.slow_last_mm <= 0.0 or slow_from >= above.z:
            self.robot.move_to(Pose(x=x, y=y, z=grip_z, r=r))
            return
        self.robot.move_to(Pose(x=x, y=y, z=slow_from, r=r))
        slow_move(self.robot, Pose(x=x, y=y, z=grip_z, r=r), self.slow_speed)

    def _wrist_note(self, x: float, y: float, r: float) -> str:
        """For the Model tab: what the wrist was told for the grip's r, and why."""
        model = self.wrist.model
        approach = (f"the wrist came to it from {self.wrist.pre_turn(self.wrist_overshoot_deg):.0f}° "
                    f"{'below' if self.wrist.side < 0 else 'above'}"
                    if self.wrist_overshoot_deg > 0 else "the wrist straight to it")
        slow = f", the last {self.slow_last_mm:.0f} mm at {self.slow_speed:.0f} mm/s" if self.slow_last_mm > 0 else ""
        if model is None:
            return f"no fingers angle check yet: told r {r:.1f}° as planned; {approach}{slow}"
        if not self.wrist.active:
            return f"the fingers angle check isn't trusted ({'; '.join(model.problems)}): told r {r:.1f}° as planned; {approach}{slow}"
        told = self.wrist.told_r(r, x, y)
        return (f"told r {told:.1f}° for {r:.1f}° ({told - r:+.1f}°: offset {model.offset_deg:+.1f}°, gain "
                f"{model.gain:.3f}, backlash {model.backlash_deg:.1f}°); {approach}{slow}")

    def _finger_hits(self, obj: SceneObject, direction_deg: float, depth: Optional[float] = None) -> Optional[str]:
        """What the open gripper would come down on, closing along `direction_deg` round `obj`, if anything: see
        _finger_hits_at. Something whose top is below where the fingertips stop (what `obj` stands on) is out of
        their way."""
        try:
            fingertips = obj.xyz_robot[2] - (grip_depth(self.gripper, self._heights.get(obj.label)) if depth is None
                                             else depth)
        except ValueError:          # too flat: plan_grip says so
            return None
        return self._finger_hits_at(obj.xyz_robot[0], obj.xyz_robot[1], fingertips, direction_deg, skip=obj)

    def _finger_hits_at(self, x: float, y: float, fingertips: float, direction_deg: float,
                        skip: Optional[SceneObject] = None) -> Optional[str]:
        """What the open gripper would hit, round (x, y) with the fingertips down at `fingertips` and closing along
        `direction_deg`, if anything: the fingers, and the gripper's body above them -- it stands out 70 mm to one
        side, and came down on a tower next to the cube being picked. (What it carries is not included.) Holding
        something, the fingers closed on it too, as they come down: the xArm's open fingers (86 mm apart) straddled
        the cube beside the spot, and the closed ones, on the way down, came down on it."""
        r = direction_deg - self.gripper.jaw_axis_deg
        parts = tool_parts(self.gripper, x, y, fingertips, r)
        if self.holding and self.gripper.fingers:
            held_fp = (_footprint(self._held_obj) if self._held_obj is not None else None) or (OBJECT_WIDTH_MM,)
            parts += tool_parts(self.gripper, x, y, fingertips, r, opening=min(held_fp[:2]))
        for other in self._last_scene:
            # (by id: the steadiness check hands back a copy of the object, its turn read again)
            if other is skip or (skip is not None and other.id == skip.id) or other.label == self.holding:
                continue
            size = _footprint(other) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
            for part in parts:
                if part.low < other.xyz_robot[2] - 1.0 and rectangles_overlap(part.centre, part.size,
                                                                              other.xyz_robot[:2], size, 0.0):
                    return other.label
        for what, centre, size, top in self._tray_blocks():
            for part in parts:
                if part.low < top - 1.0 and rectangles_overlap(part.centre, part.size, centre, size, 0.0):
                    return what
        return None

    def _tray_blocks(self) -> list[tuple[str, tuple, tuple, float]]:
        """The demo's trays and bins as blocks seen from above: their floors and walls, (in words, centre, (width,
        length, angle of the long side), top). The tool (and what it carries) went through them: only their
        insides were minded, when putting things in. None for places of unknown size (the real arm's saved ones)."""
        areas = self._place_areas()
        if not areas:
            return []
        places = self._obstacle_places()                  # (a printed spot has no floor or walls to hit)
        blocks = []
        wall = WALL_BLOCK_MM
        for name, (inner_x, inner_y, top) in areas.items():
            place = places.get(name)
            if place is None:
                continue
            x, y = place.x, place.y
            blocks.append((name, (x, y), (inner_y, inner_x, 0.0), place.z))   # the floor, up to its surface
            blocks += [(f"{name}'s wall", (x, y + side * (inner_y + wall) / 2.0), (wall, inner_x + 2 * wall, 0.0), top)
                       for side in (-1.0, 1.0)]
            blocks += [(f"{name}'s wall", (x + side * (inner_x + wall) / 2.0, y), (wall, inner_y + 2 * wall, 90.0), top)
                       for side in (-1.0, 1.0)]
        return blocks

    def _spot_at_place(self, name: str, place: Pose, surface_z: Optional[float]) -> tuple[float, float]:
        """Where at a place the held object goes: a free spot, clear of what is already there and with room for the
        open fingers. Always the place's own middle used to be the answer, so the second object went down onto the
        first (the real arm would drive it into it) and a tray filled up as a wobbly tower. A tray or bin (size
        known) takes things side by side, from one corner; a place without a known size is one spot.
        Raises, in words, when there's no room."""
        held = self._held_obj
        held_fp = _footprint(held) if held is not None else None
        width, length, angle = held_fp if held_fp else (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
        release = self._release_z(surface_z) if surface_z is not None else place.z

        def held_at(x: float, y: float) -> tuple:
            # as it will lie there: turned by any turn on the way (see _carry_turn)
            turned = self._carry_turn(x, y) - self._grip_r if self.gripper.fingers else 0.0
            return (x, y), (width, length, angle + turned)
        areas = self._place_areas()
        area = areas.get(name)
        opening = (self.gripper.opening_mm / 2.0 + self.gripper.shape.finger_thickness_mm
                   if self.gripper.fingers else 0.0)

        def blocked(x: float, y: float) -> Optional[str]:
            centre, footprint = held_at(x, y)
            for other in self._last_scene:
                if other.label == self.holding:
                    continue
                # as rectangles, turned as they are: as circles, two cubes 20 mm apart one way and 22 the other
                # counted as clear -- and overlapped
                other_fp = _footprint(other) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
                if rectangles_overlap(centre, footprint, other.xyz_robot[:2], other_fp, PLACE_GAP_MM):
                    return f"the {other.label}"
            if self.gripper.fingers:
                # clear with the fingers turned any way that lets it go looking the same (as _clear_turn does)
                reason = None
                for r in self._release_turns(x, y):
                    direction = self.gripper.closing_direction(r)
                    hit = self._finger_hits_at(x, y, release, direction)
                    if hit:
                        reason = reason or f"the {hit} (in the fingers' way)"
                        continue
                    if area is not None and release < area[2] + 2.0:
                        # the fingertips go down inside the walls: both fingers must be inside them too
                        ux, uy = math.cos(math.radians(direction)), math.sin(math.radians(direction))
                        if any(abs(x - place.x + side * opening * ux) > area[0] / 2.0
                               or abs(y - place.y + side * opening * uy) > area[1] / 2.0 for side in (-1.0, 1.0)):
                            reason = reason or f"the {name}'s wall (in the fingers' way)"
                            continue
                    return None
                return reason
            return None

        if area is None:
            blocker = blocked(place.x, place.y)
            if blocker:
                raise ValueError(f"{blocker[0].upper()}{blocker[1:]} is already at the '{name}' spot, so there's no "
                                 f"room there for the {self.holding}. Put it somewhere else, or tell the user.")
            return place.x, place.y
        _, (w_now, l_now, a_now) = held_at(place.x, place.y)
        turn = math.radians(a_now)            # its extent along the tray's sides (the tray square to the table)
        half_x = (l_now * abs(math.cos(turn)) + w_now * abs(math.sin(turn))) / 2.0
        half_y = (l_now * abs(math.sin(turn)) + w_now * abs(math.cos(turn))) / 2.0
        room_x, room_y = area[0] / 2.0 - half_x - 1.0, area[1] / 2.0 - half_y - 1.0
        if room_x < 0 or room_y < 0:
            raise ValueError(f"The {self.holding} is too big for the '{name}'. Tell the user.")
        # filled from one corner, row by row, like packing a box: the first thing in the middle left no room beside
        # it for the next one's fingers (an 80 mm tray took one 25 mm cube; this way it takes four)
        spots = [(dx, dy) for dx in _steps(room_x) for dy in _steps(room_y)]
        for dx, dy in spots:
            if blocked(place.x + dx, place.y + dy) is None:
                return place.x + dx, place.y + dy
        inside = sorted({o.label for o in self._last_scene if o.label != self.holding
                         and abs(o.xyz_robot[0] - place.x) <= area[0] / 2 and abs(o.xyz_robot[1] - place.y) <= area[1] / 2})
        raise ValueError(f"The '{name}' is full: there's no room left in it for the {self.holding}"
                         + (f" (it holds the {', the '.join(inside)})" if inside else "") + ". Tell the user.")

    def _clear_turn(self, x: float, y: float, z: float) -> float:
        """The end effector's turn to let go at (x, y, z) with the open fingers clear of what's next to it: as carried,
        or turned by what leaves it looking the same (a quarter turn for a square, half for a long one). A 5 mm gap
        beside a cube had a finger come down on it. Raises, with the room needed, when no turn is clear."""
        carried = self._carry_turn(x, y)
        if not self.gripper.fingers:
            return carried
        hit = None
        for r in self._release_turns(x, y):
            hit = self._finger_hits_at(x, y, z, self.gripper.closing_direction(r))
            if hit is None:
                return r
        if hit is None:
            return carried
        width = (_footprint(self._held_obj) or (OBJECT_WIDTH_MM,))[0] if self._held_obj is not None else OBJECT_WIDTH_MM
        room = (self.gripper.opening_mm - width) / 2.0 + self.gripper.shape.finger_thickness_mm + 1.0
        raise ValueError(f"The open gripper would hit the {hit} when letting go of the {self.holding} there: they need "
                         f"about {room:.0f} mm of room beside it. Leave a bigger gap, or put it somewhere else.")

    def _release_turns(self, x: float, y: float, extra: float = 0.0) -> list[float]:
        """The end effector's turns that put the held object down at (x, y) looking as carried (a quarter turn apart for
        a square one, half for a long one) and that the wrist can reach there: nearest the carried turn first."""
        carried = self._carry_turn(x, y) + extra        # (extra: turned by that much more, on purpose)
        period = 90.0 if self._held_square else 180.0
        turns = sorted({round(carried + k * period, 3) for k in range(-3, 4)}, key=lambda r: abs(r - carried))
        return [r for r in turns if self.gripper.wrist_fits(r, x, y)]

    def _travel(self, target: Pose) -> None:
        """Go to `target` by a way that doesn't go through anything on the table. Straight from one point to another
        the arm, or what it carries, swept through what stood between: going home after a five-cube tower it ran
        down through the tower (a real arm would have knocked it over). And "up, across, down" isn't always there:
        near its base the arm can't reach high. So: the straight way if it's clear; else across at a height clear of
        everything, then down; else a step aside first (at this height), then on. Raises, in words, when no way is
        clear. Starting low (left there by hand, say), it first rises straight up out of whatever may be between or
        beside the fingers: the camera can't see what is right by the gripper, and going home from round a cube
        pushed a finger into it."""
        here = self.robot.get_pose()
        table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
        rise = (self.gripper.finger_depth_mm if self.gripper.fingers else 0.0) + LIFT_OUT_MM
        if (table_z is not None and math.hypot(target.x - here.x, target.y - here.y) > 5.0
                and here.z - table_z < LOW_TOOL_MM and target.z > here.z - 1.0):
            up = Pose(here.x, here.y, max(here.z + rise, min(target.z, here.z + LOW_TOOL_MM)), here.r)
            if self._can_reach(up):
                self.robot.move_to(up)
                here = up
        route = self._route(here, target)
        if route is None:
            raise ValueError(f"Can't get from ({here.x:.0f}, {here.y:.0f}, {here.z:.0f}) to ({target.x:.0f}, "
                             f"{target.y:.0f}, {target.z:.0f}) without going through something on the table. "
                             "Tell the user.")
        for waypoint in route:
            self.robot.move_to(waypoint)

    def _route(self, here: Pose, target: Pose) -> Optional[list[Pose]]:
        """The first clear way from here to target, as the poses to move to (the last one is target)."""
        # the straight way, as every move went before: checked for things in the way only. (The arm model's reach is
        # a guide, not the real controller's limits: judged by it, moves that always worked on the real arm could be
        # refused. It only chooses between detours.)
        if self._path_clear([here, target], check_reach=False):
            return [target]
        safe = self._clear_height(here, target)
        candidates = []
        for height in sorted({max(safe, here.z, target.z), max(safe, target.z)}, reverse=True):
            candidates.append([Pose(here.x, here.y, height, here.r), Pose(target.x, target.y, height, target.r), target])
        for step in (40.0, 60.0):
            for k in range(12):
                a = math.radians(30.0 * k)
                aside = Pose(here.x + step * math.cos(a), here.y + step * math.sin(a), here.z, here.r)
                candidates.append([aside, target])
                candidates.append([aside, Pose(aside.x, aside.y, target.z, target.r), target])
        candidates.sort(key=lambda way: sum(math.dist((a.x, a.y, a.z), (b.x, b.y, b.z))
                                            for a, b in zip([here] + way, way)))
        for way in candidates:
            if self._path_clear([here] + way):
                return [p for p in way if math.dist((p.x, p.y, p.z), (here.x, here.y, here.z)) > 0.5]
        return None

    def _path_clear(self, points: list[Pose], check_reach: bool = True) -> bool:
        """Whether the tool gets through these points, leg by leg (by the route the arm really takes: straight, or
        the swing round its base), within reach and without touching anything on the table. Reach isn't judged right
        by where the arm is now: it is there, whatever the arm model says (a rough guide near the base) -- judged by
        it, every way out from beside the base was "out of reach", and a cube couldn't be put down anywhere."""
        start = (points[0].x, points[0].y, points[0].z)
        for a, b in zip(points, points[1:]):
            length = math.dist((a.x, a.y, a.z), (b.x, b.y, b.z))
            if length < 0.5:
                continue
            steps = max(2, int(length / 5.0))
            for p in path_points(a, b, steps):
                judged = check_reach and math.dist((p.x, p.y, p.z), start) > NEAR_START_MM
                if (judged and not self._can_reach(p)) or self._tool_hits(p) is not None:
                    return False
        return True

    def _tool_hits(self, pose: Pose) -> Optional[str]:
        """What the tool (fingers, the gripper over them, or the suction tip) and what it carries would be in at `pose`,
        taking everything on the table as standing from the table up to its top."""
        # the whole tool (fingers fully open: never narrower than they are), as the demo checks it
        parts = [(part.centre, part.size, part.low) for part in tool_parts(self.gripper, pose.x, pose.y, pose.z, pose.r)]
        if self.holding:
            held = _footprint(self._held_obj) if self._held_obj is not None else None
            width, length, angle = held or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
            turned = pose.r - self._grip_r if self.gripper.fingers else 0.0
            parts.append(((pose.x, pose.y), (width, length, angle + turned),
                          pose.z - (self._held_height - self._grip_depth)))
        table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
        if table_z is not None and min(bottom for _, _, bottom in parts) < table_z - 1.0:
            return "table"
        for other in self._last_scene:
            if other.label == self.holding:
                continue
            size = _footprint(other) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
            for centre, footprint, bottom in parts:
                if bottom < other.xyz_robot[2] - 1.0 and rectangles_overlap(centre, footprint, other.xyz_robot[:2],
                                                                             size, 0.0):
                    return other.label
        for what, centre_b, size_b, top in self._tray_blocks():
            for centre, footprint, bottom in parts:
                if bottom < top - 1.0 and rectangles_overlap(centre, footprint, centre_b, size_b, 0.0):
                    return what
        return None

    def _clear_height(self, a: Pose, b: Pose) -> float:
        """How high the tip must be to pass over everything near the way from a to b (with what it carries)."""
        dx, dy = b.x - a.x, b.y - a.y
        length_sq = dx * dx + dy * dy or 1.0
        tops = []
        for o in self._last_scene:
            if o.label == self.holding:
                continue
            t = max(0.0, min(1.0, ((o.xyz_robot[0] - a.x) * dx + (o.xyz_robot[1] - a.y) * dy) / length_sq))
            if math.hypot(a.x + t * dx - o.xyz_robot[0], a.y + t * dy - o.xyz_robot[1]) <= TRAVEL_NEAR_MM:
                tops.append(o.xyz_robot[2])
        for _, centre, size, top in self._tray_blocks():
            reach = max(size[:2]) / 2.0 + TRAVEL_NEAR_MM
            t = max(0.0, min(1.0, ((centre[0] - a.x) * dx + (centre[1] - a.y) * dy) / length_sq))
            if math.hypot(a.x + t * dx - centre[0], a.y + t * dy - centre[1]) <= reach:
                tops.append(top)
        if not tops:
            return -1e9
        hanging = (self._held_height - self._grip_depth) if self.holding else 0.0
        return max(tops) + TRAVEL_CLEARANCE_MM + hanging

    def _controller_problem(self, pose: Pose, planning: bool) -> Optional[str]:
        """Why the Dobot's controller would refuse `pose` -- `planning`: why a plan shouldn't use it, a few degrees
        spare -- by its own arm (app/hardware/dobot_arm.py), or None: fine, not the Dobot, or the table unknown. The
        twin's poses are judged as the lab's would be: its table (z 0) at the lab table's height in the controller's
        frame, so the twin turns down what the real arm can't do."""
        if robots.active().key != "dobot_magician":
            return None
        if getattr(self.robot, "controller_z", None) is True:          # (the real Dobot: its own z)
            z = pose.z
        else:
            table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
            if table_z is None:
                return None
            z = pose.z - table_z + dobot_arm.LAB_TABLE_Z_MM
        return dobot_arm.reach_problem(pose.x, pose.y, z, planning=planning)

    def _approach_z(self, x: float, y: float, z: float, height: float = PICK_APPROACH_HEIGHT_MM) -> Optional[float]:
        """Where to come down from onto (x, y, z): `height` above it -- or lower, where the arm can't reach that high
        (near its base). Study 2, S-06_Run1: 50 mm above a cube 160 mm from the base needed the rear arm 6 degrees
        past upright; the controller refused it with alarm 0x12 and took no move after it until switched off and on.
        None if not even MIN_APPROACH_MM above can be reached. With a few degrees spare (dobot_arm.PLANNED) if any
        height has them; else (near the base, onto a tower two high) within what the controller takes (REFUSED: the
        lab's arm went to J2 -1.9 and was refused at -6), as the driver itself judges every move."""
        for planning in (True, False):
            up = height
            while up >= MIN_APPROACH_MM - 1e-6:
                problem = self._controller_problem(Pose(x, y, z + up), planning=planning)
                if problem is None:
                    if up < height or not planning:
                        self.last_record.setdefault("approach", []).append(
                            {"at": [round(x), round(y)], "above_mm": round(up, 1), "wanted_mm": height,
                             "why": "near the base the arm can't reach higher"
                                    + ("" if planning else " (no degrees spare)")})
                    return z + up
                up -= 2.0
        return None

    def _approach_or_refuse(self, x: float, y: float, z: float, what: str,
                            height: float = PICK_APPROACH_HEIGHT_MM) -> float:
        above = self._approach_z(x, y, z, height)
        if above is None:
            problem = self._controller_problem(Pose(x, y, z + MIN_APPROACH_MM), planning=False)
            raise ValueError(f"{what} at ({x:.0f}, {y:.0f}) mm is too close to the robot's base for the arm to come "
                             f"down onto ({problem}). Not moving. Tell the user it is out of reach there.")
        return above

    def _can_reach(self, pose: Pose) -> bool:
        if not self.gripper.wrist_fits(pose.r, pose.x, pose.y, margin=0.0):
            return False            # (a step aside keeps the wrist's turn: further round, J4 can pass its limit)
        if self._controller_problem(pose, planning=False) is not None:
            return False            # (the controller's own arm: it would refuse it, and may then refuse everything)
        clamp = getattr(self.robot, "clamp_pose", None)
        if clamp is not None:
            safe = clamp(pose)
            if math.dist((safe.x, safe.y, safe.z), (pose.x, pose.y, pose.z)) > 3.0:   # as _require_reachable
                return False
        # the arm model measures heights from the table (the base stands on it): the real Dobot from its own zero,
        # with the table some 60 mm below it -- taken as is, most of the real arm's working heights were "out of
        # reach", and a detour round something could be refused. Table height unknown: no model to judge by.
        table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
        if table_z is None:
            return True
        return robots.active().within_limits(pose.x, pose.y, pose.z - table_z, pose.r)

    def _carry_turn(self, x: float, y: float) -> float:
        """The end effector's turn to take the held object to (x, y): as it was picked up -- or turned by what the
        user asked for (turn_deg) -- unless the wrist can't reach that there (then a half turn, or a quarter for a
        square object: it looks the same)."""
        if not self.gripper.fingers or not self.holding:
            return 0.0
        wanted = getattr(self, "_wanted_turn", None)
        start = self._grip_r + (wanted or 0.0)
        return turn_for_place(self.gripper, start, x, y, self._held_square)

    def _want_turn(self, degrees: float, absolute: bool = False) -> str:
        """Put the held object down turned by `degrees` -- or, `absolute`, turned to end up at `degrees` on the table
        (the user asked for it: the place tools' turn_deg / angle_deg). Returns a note for the result: what was done,
        or why it wasn't turned (round; the suction cup holds by the top)."""
        self._wanted_turn = None
        if not self.holding or not self.gripper.fingers:
            return " (Not turned: the suction cup can't turn what it holds.)" if self.holding else ""
        shape = self._held_obj.label.split()[-1] if self._held_obj is not None else ""
        if shape in ROUND_SHAPES:
            return f" (The {self.holding} looks the same at any turn, so it wasn't turned.)"
        if not absolute:
            self._wanted_turn = degrees
            return f" Turned by {degrees:+.0f}° as asked."
        footprint = _footprint(self._held_obj) if self._held_obj is not None else None
        if footprint is None:
            return f" (Not turned to {degrees:.0f}°: how it lies now isn't known.)"
        # it looks the same a quarter turn on (square) or a half turn (long): the smallest turn that ends there
        period = 90.0 if self._held_square else 180.0
        self._wanted_turn = (degrees - footprint[2] + period / 2.0) % period - period / 2.0
        return f" Set at {degrees:.0f}° as asked (turned {self._wanted_turn:+.0f}°)."

    def _put_back_for_tower(self, ids: list) -> str:
        """Holding one of the tower's own objects (S-17 in the twin, 2026-10-25: it picked the green cube, the
        bottom, then build_tower was refused, "already holding", and it put green down near the base and built the
        tower there, 60 mm from where it was): put back where it was picked up, if that spot is still free, so the
        tower is built as if it had never been picked. A sentence saying so, or "" (then refused as before)."""
        held = self._held_obj
        if held is None or held.id not in ids or self.table_z_provider() is None:
            return ""
        x, y, top = held.xyz_robot
        if any(o.label != self.holding and math.hypot(o.xyz_robot[0] - x, o.xyz_robot[1] - y) < OBJECT_WIDTH_MM
               for o in self._last_scene):
            return ""
        label = self.holding
        self._note_target(f"put back where it was picked up, for the tower: ({x:.0f}, {y:.0f})")
        self._tool_place({"x": x, "y": y, "z": self._release_z(top - self._held_height)})
        self._tool_list_objects({})
        return f"The {label} was put back where it was picked up first (the tower starts from there). "

    def _tool_build_tower(self, args: dict) -> str:
        """A whole tower in one call: the bottom one to the place asked for (or left where it is), each next one on
        the one before, each turned if asked. Built step by step by the model, the small one lost track: it left the
        base outside the tray, turned nothing, and said "a tower inside the tray, at 45 degrees"."""
        ids = list(args.get("object_ids") or [])
        if len(ids) < 2:
            raise ValueError("A tower needs at least two objects: give their ids in object_ids, bottom first.")
        put_back = self._put_back_for_tower(ids) if self.holding else ""
        if self.holding:
            raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        if put_back:
            return put_back + self._tool_build_tower(args)
        self._look_first()
        place = str(args.get("place_name") or "").strip().lower() or None
        where = str(args.get("where") or "").strip().lower().replace(" ", "_") or None
        if place is not None and place not in self._saved_places() and any(w in place for w in FREE_TABLE_WORDS):
            # the model put place_free's words here ("near_base") -- "a tower outside the tray" was refused, and it
            # then built it IN the tray
            place, where = None, where or place
        if place is not None and where is not None:
            raise ValueError("Give place_name (a saved place) or where (free table), not both.")
        absolute = args.get("angle_deg") is not None
        degrees = args.get("angle_deg") if absolute else args.get("turn_deg")
        objects = [self._find_object(i) for i in ids]
        labels = [o.label for o in objects]
        built: list[str] = []
        anywhere = where is not None and any(w in where for w in ANY_FREE_SPOT)

        def base_is_right(base) -> bool:
            if place is not None:
                return self._inside_place(base, place)
            if where is not None:      # "outside the tray": anywhere off the places; "left": moved there
                return anywhere and not any(self._in_place_quietly(base, name) for name in self._saved_places())
            return True
        pile = self._pile_of(objects[0])
        if pile == labels and degrees is None and base_is_right(objects[0]):
            return "The tower is already built as asked, bottom to top: " + ", ".join(labels) + ". Nothing was moved."
        # what is already right stays: the bottom of the tower asked for, in its place, with the next ones on it
        keep = 0
        if pile[:1] == labels[:1] and base_is_right(objects[0]) and degrees is None:
            while keep < min(len(pile), len(labels)) and pile[keep] == labels[keep]:
                keep += 1
        cleared = self._clear_piles(objects, keep)
        objects = [self._find_object(i) for i in ids]

        def turned_down(do) -> str:
            note = self._want_turn(float(degrees), absolute) if degrees is not None else ""
            try:
                do()
            finally:
                self._wanted_turn = None
            return note

        try:
            base = objects[0]
            if keep == 0 and place is not None and not self._inside_place(base, place):
                self._tool_pick({"object_id": base.id})
                turned_down(lambda: self._tool_place_at({"place_name": place}))
            elif keep == 0 and where is not None and not base_is_right(base):
                spot = "center" if anywhere else where
                self._tool_pick({"object_id": base.id})
                turned_down(lambda: self._tool_place_free({"where": spot}))
            elif degrees is not None:
                self._tool_turn_object({"object_ids": [base.id], **({"angle_deg": degrees} if absolute
                                                                     else {"turn_deg": degrees})})
            built += labels[:max(keep, 1)]
            below = objects[max(keep, 1) - 1]
            for obj in objects[max(keep, 1):]:
                self._tool_pick({"object_id": obj.id})
                turned_down(lambda below=below: self._tool_place_on({"object_id": below.id}))
                built.append(obj.label)
                below = obj
        except ValueError as exc:
            done = (", bottom to top: " + ", ".join(built)) if built else ""
            raise ValueError(f"Built {len(built)} of {len(objects)}{done}; stopped at the "
                             f"{objects[len(built)].label}: {exc}") from None
        at = f" in the {place}" if place else (" on free table" if where else "")
        how = ""
        if degrees is not None:
            how = f", each at {float(degrees):.0f}°" if absolute else f", each turned by {float(degrees):+.0f}°"
        first = f"Took {cleared} off a pile first. " if cleared else ""
        return first + f"Built a tower of {len(built)}{at}{how}, bottom to top: " + ", ".join(built) + "."

    def _clear_piles(self, objects: list, keep: int) -> int:
        """Takes off, top first, onto free table nearby, whatever is on the tower's objects -- and those of them in a
        pile -- except the first `keep` of the tower already right in place. ("The tower should be outside of the
        tray": the model took it apart by hand, one cube at a time.) Returns how many were moved."""
        moved = 0
        wanted = [o.label for o in objects]
        done: set[str] = set()
        for obj in objects:
            pile = self._pile_of(obj)
            if len(pile) < 2 or pile[0] in done:
                continue
            done.add(pile[0])
            stays = keep if pile[:keep] == wanted[:keep] and keep else 1
            seen = [label for label in pile if any(o.label == label for o in self._last_scene)]
            bottom = next(o for o in self._last_scene if o.label == seen[0])
            for label in reversed(seen[stays:]):
                top = next((o for o in self._last_scene if o.label == label), None)
                if top is not None:
                    self._moved_to_free_spot_near(top, bottom.xyz_robot[0], bottom.xyz_robot[1])
                    moved += 1
        return moved

    def _inside_place(self, obj, name: str) -> bool:
        """Whether `obj` stands in the place `name` already (inside a tray's walls, or on the spot)."""
        places = self._saved_places()
        if name not in places:
            raise ValueError(f"No saved place called '{name}'. Available: {sorted(places) or 'none'}.")
        place = places[name]
        areas = self._place_areas()
        x, y = obj.xyz_robot[0], obj.xyz_robot[1]
        if name in areas:
            inner_x, inner_y, _ = areas[name]
            return abs(x - place.x) <= inner_x / 2.0 and abs(y - place.y) <= inner_y / 2.0
        return math.hypot(x - place.x, y - place.y) <= 15.0

    def _tool_turn_object(self, args: dict) -> str:
        """Turn objects where they stand: each picked up and put back on the same spot, turned by turn_deg or to end
        up at angle_deg. Several in one call ("all the cubes at 45 degrees": it packed the tray instead, with nothing
        to turn them all); the top of a pile first, and one with something on it is left with the reason."""
        self._look_first()
        ids = list(args.get("object_ids") or ([args["object_id"]] if args.get("object_id") else []))
        if not ids:
            raise ValueError("Which objects? Give their ids from list_objects in object_ids.")
        if args.get("turn_deg") is None and args.get("angle_deg") is None and not args.get("like_id"):
            raise ValueError("How far? Give turn_deg (turn by), angle_deg (end up at), in degrees, or like_id (the "
                             "same angle as that object).")
        like = None
        if args.get("like_id"):
            like = self._find_object(args["like_id"])
            footprint = _footprint(like)
            if footprint is None:
                raise ValueError(f"How the {like.label} lies isn't known (the camera gave no outline), so nothing "
                                 "can be turned to match it.")
            absolute, degrees = True, float(footprint[2])
        else:
            absolute = args.get("angle_deg") is not None
            degrees = float(args["angle_deg"] if absolute else args["turn_deg"])
        done, left = [], []
        if self.holding:
            # turn what is held: put back where it was picked up, turned ("pick the red cube and make its angle like
            # the green cube's": it was held, the tool refused, and the model said it had turned it anyway)
            held = self._held_obj
            if held is None or held.id not in ids:
                raise ValueError(f"Already holding the {self.holding}. Put it down first, then turn.")
            x, y, top = held.xyz_robot
            before, square = _footprint(held), self._held_square
            note = self._want_turn_asked(self._turn_from_start(held.id, degrees, absolute), degrees, absolute)
            turn = self._wanted_turn
            try:
                self._tool_place({"x": x, "y": y, "z": self._release_z(top - self._held_height), "top_z": top})
            finally:
                self._wanted_turn = None
            note = note.rstrip(".") + self._check_turn(held.label, x, y, before, turn, square)
            done.append(f"the {held.label}{note.rstrip('.')} (put back where it was picked up)")
            ids = [i for i in ids if i != held.id]
        targets = sorted((self._find_object(i) for i in ids), key=lambda o: -o.xyz_robot[2])   # the top of a pile first
        for target in targets:
            if target.label.split()[-1] in ROUND_SHAPES:
                left.append(f"the {target.label} (round: it looks the same at any turn)")
                continue
            cover = self._covered_by(target)
            if cover is not None:
                left.append(f"the {target.label} (the {cover.label} is on top of it: move that first)")
                continue
            x, y, top = target.xyz_robot
            asked = self._turn_from_start(target.id, degrees, absolute)
            try:
                self._tool_pick({"object_id": target.id})
            except ValueError as exc:            # this one can't be taken (a neighbour too close): on to the rest
                left.append(f"the {target.label} ({str(exc).rstrip('.')})")
                continue
            bottom = top - self._held_height
            before = _footprint(self._held_obj) if self._held_obj is not None else None
            square = self._held_square
            note = self._want_turn_asked(asked, degrees, absolute)
            turn = self._wanted_turn
            try:
                self._tool_place({"x": x, "y": y, "z": self._release_z(bottom), "top_z": top})
            finally:
                self._wanted_turn = None
            note = note.rstrip(".") + self._check_turn(target.label, x, y, before, turn, square)
            done.append(f"the {target.label}{note.rstrip('.')}")
        asked = len(targets) + (1 if done and "put back where it was picked up" in done[0] else 0)
        text = (f"Turned {len(done)} of {asked}" + (f" to match the {like.label}" if like is not None else "")
                + (": " + "; ".join(done) if done else "") + ".")
        if left:
            text += " Left as they are: " + "; ".join(left) + "."
        return text

    def _turn_from_start(self, object_id: str, degrees: float, absolute: bool) -> tuple[float, bool]:
        """(degrees, absolute) for _want_turn: "turn it by N" for an object already put down in this prompt (a swap
        first) means N from its turn when the user asked -- each carry left a cube a few degrees off, and turned from
        where the swap left it, the red cube ended 35 degrees off a 45-degree turn (study 3, S-06; S-08 the same)."""
        start = self._prompt_angles.get(object_id)
        if absolute or start is None or object_id not in self._placed_in_prompt:
            return degrees, absolute
        return start + degrees, True

    def _want_turn_asked(self, asked: tuple[float, bool], degrees: float, absolute: bool) -> str:
        """_want_turn for `asked` (see _turn_from_start), said as the user asked it."""
        note = self._want_turn(*asked)
        if asked == (degrees, absolute) or self._wanted_turn is None:
            return note
        return (f" Turned by {degrees:+.0f}° from how it lay when asked ({self._wanted_turn:+.0f}° from how it was "
                "picked up: moving it earlier had turned it a little).")

    def _check_turn(self, label: str, x: float, y: float, before, turn: Optional[float], square: bool) -> str:
        """A turn looked at afterwards (V4.2): the arm out of the camera's view first (it stood right over the cube),
        the cube's angle read again from several pictures and compared with where `turn` should have left it from
        `before` (its footprint when picked up; `square`: it looks the same a quarter turn on); more than
        TURN_CHECK_DEG off -> picked up and put right once, by how far off the re-pick's own steady reading says. On the
        Dobot, turns anticlockwise went 25-33 degrees too far (S-06 +45 -> +78, S-07 +30 -> +55, 2026-10-23) and
        nothing noticed. Returns what it found, for the result."""
        if (turn is None or before is None or not self.gripper.fingers or self.turn_checks < 1
                or getattr(self, "_checking_turn", False)):
            return ""
        period = 90.0 if square else 180.0

        def wrap(a: float) -> float:
            return (a + period / 2.0) % period - period / 2.0
        reader = getattr(self.scene_builder, "footprints_near", None)
        if reader is None:
            return ""
        self._tool_list_objects({})                # (the arm out of the camera's view)
        now = min((o for o in self._last_scene if o.label == label
                   and math.dist(o.xyz_robot[:2], (x, y)) <= TURN_NEAR_MM),
                  key=lambda o: math.dist(o.xyz_robot[:2], (x, y)), default=None)
        if now is None:
            return " (the turn couldn't be checked: it isn't seen where it was put)"
        angle = self._turn_read_near(reader, now.xyz_robot[0], now.xyz_robot[1], period)
        if angle is None:
            return " (the turn couldn't be checked: the camera's readings of it didn't agree)"
        off = wrap(wrap(angle - before[2]) - turn)
        if abs(off) <= TURN_CHECK_DEG:
            return f"; checked: it turned {turn + off:+.0f}° (asked {turn:+.0f}°)"
        self._checking_turn = True
        try:
            self._tool_pick({"object_id": now.id})
            held = _footprint(self._held_obj) if self._held_obj is not None else None
            if held is not None:                   # (the re-pick's own steady reading: how far off it really is)
                off = wrap(wrap(held[2] - before[2]) - turn)
            if abs(off) <= TURN_CHECK_DEG:
                self._wanted_turn = None
                nx, ny, ntop = now.xyz_robot
                self._tool_place({"x": nx, "y": ny, "z": self._release_z(ntop - self._held_height), "top_z": ntop})
                return f"; checked: it turned {turn + off:+.0f}° (asked {turn:+.0f}°)"
            self._wanted_turn = -off
            nx, ny, ntop = now.xyz_robot
            self._tool_place({"x": nx, "y": ny, "z": self._release_z(ntop - self._held_height), "top_z": ntop})
            # looked at once more, only to say how it ended (not put right again: once is the limit)
            self._tool_list_objects({})
            last = self._turn_read_near(reader, nx, ny, period)
            if last is not None:
                return (f"; checked: it turned {turn + off:+.0f}° (asked {turn:+.0f}°), so it was turned {-off:+.0f}° "
                        f"more; now {wrap(wrap(last - before[2]) - turn):+.0f}° off what was asked")
        except ValueError as exc:
            said = f"; checked: it turned {turn + off:+.0f}° (asked {turn:+.0f}°); putting it right failed ({exc})"
            if self.holding:                       # (never left in the gripper: put back as it was, else beside)
                self._wanted_turn = None
                try:
                    nx, ny, ntop = now.xyz_robot
                    self._tool_place({"x": nx, "y": ny, "z": self._release_z(ntop - self._held_height),
                                      "top_z": ntop})
                except ValueError:
                    try:
                        self._tool_place_free({"where": "next_to", "object_id": now.id})
                    except ValueError:
                        pass
                said += f"; now holding: {self.holding}" if self.holding else "; it was put back"
            return said
        finally:
            self._wanted_turn = None
            self._checking_turn = False
        return f"; checked: it turned {turn + off:+.0f}° (asked {turn:+.0f}°), so it was turned {-off:+.0f}° more"

    def _turn_read_near(self, reader, x: float, y: float, period: float) -> Optional[float]:
        """The turn of what stands at (x, y), from several pictures, judged as a pick judges them: agreeing well, or
        their average known well enough; if not, a second lot of pictures and all of them together up to the second
        look's limit. None if they still don't agree. (One lot only, a turn's check gave up in 5 of the Dobot's 6
        turns in study 3 -- "the camera's readings of it didn't agree" -- and a turn 35 degrees off went unnoticed.)"""
        angles: list = []
        for attempt in range(2):
            prints = reader(x, y, max(self.angle_looks, 6))
            if len(prints) < (3 if attempt == 0 else 2):
                return None
            angles += [q[2] for q in prints]
            angle, spread, dropped = steady_mean(angles, period)
            if spread <= ANGLE_AGREE_DEG or (spread <= ANGLE_SPREAD_MAX_DEG
                                             and _mean_error(angles, angle, period, dropped) <= ANGLE_MEAN_DEG) or (
                    attempt > 0 and spread <= ANGLE_SPREAD_LIMIT_DEG):
                return angle
        return None

    def _release_z(self, surface_z: float) -> float:
        """Where the tip goes to let go on a surface at `surface_z`: the object's bottom RELEASE_GAP_MM above it. The
        suction tip is on the object's top; the fingertips are `_grip_depth` below it."""
        return surface_z + self._held_height + RELEASE_GAP_MM - self._grip_depth

    def _tool_place(self, args: dict) -> str:
        if not self.holding:
            # Otherwise the arm drives to the target, "releases" nothing, and reports success.
            raise self._nothing_held()
        self._require_listed()
        x, y, z = args["x"], args["y"], args["z"]
        r = args["r"] if args.get("r") is not None else self._clear_turn(x, y, z)
        if self.gripper.fingers:
            self.last_record["release"] = {"r": round(r, 1), "turned": round(r - self._grip_r, 1)}
            self.last_record.setdefault("releases", []).append(
                {"object": self.holding, "xy": [round(x, 1), round(y, 1)], "r": round(r, 1),
                 "turned": round(r - self._grip_r, 1)})
        top = args.get("top_z", z + self._grip_depth)
        if self._in_view(x, y, top) is False or self._in_view(x, y, top - self._held_height) is False:
            raise ValueError(f"Not putting the {self.holding} down at ({x:.0f}, {y:.0f}) mm: the camera can't see there "
                             "(the arm reaches further than the camera sees), so it couldn't be found again. Tell the "
                             "user, or choose a spot nearer the middle of the table.")
        above_z = self._approach_or_refuse(x, y, z, "The place", PLACE_APPROACH_HEIGHT_MM)
        self._require_reachable(Pose(x=x, y=y, z=above_z, r=r), "Place target")
        self._require_reachable(Pose(x=x, y=y, z=z, r=r), "Place target")
        above = Pose(x=x, y=y, z=above_z, r=r)
        # to its angle from the same side as a pick (the gears' slack taken up alike): put down at an angle, or into a
        # tight slot, it lands where it was meant to, not off by the slack
        if not self._travel_turned(above) and self.gripper.fingers:
            approach_from_side(self.robot, above, self.gripper, self.wrist.pre_turn(self.wrist_overshoot_deg),
                               self.wrist.side)
        self.robot.move_to(Pose(x=x, y=y, z=z, r=r))
        self.robot.open_gripper()
        self.robot.move_to(Pose(x=x, y=y, z=above_z, r=r))
        # where its top is now: the tip was on it (suction) or _grip_depth below it (fingers). Remembered as the
        # fingertip height, the next place_on before a look let go 12.5 mm too low -- into the cube below.
        top_z = args.get("top_z", z + self._grip_depth)
        self._turned_while_held = r - self._grip_r
        self._grip_r, self._grip_depth, self._held_square = 0.0, 0.0, True
        released, self.holding = self.holding, None
        self.last_moved = released or self.last_moved
        if released:
            self._released_now = (released, x, y, getattr(self, "_tool_now", ""))
            self._let_go = (released, float(x), float(y))
        self._moved_in_prompt = True
        self._just_placed.append((x, y))
        self._remember_moved(x, y, top_z)
        return f"Placed {released or 'object'} at ({x:.0f}, {y:.0f}, {z:.0f}) mm"

    def _remember_moved(self, x: float, y: float, top_z: float) -> None:
        """Where the object just put down is now (its top, like list_objects gives), under the same id. Until
        the next look the table is only known from the last one, and that still showed it where it was picked
        up: "put the blue cube on the red cube" then aimed at the empty spot the red cube had left."""
        moved, self._held_obj = self._held_obj, None
        if moved is None:
            return
        footprint = _footprint(moved)
        turned = getattr(self, "_turned_while_held", 0.0)
        if footprint is not None and turned:
            footprint = (footprint[0], footprint[1], round((footprint[2] + turned) % 180.0, 1))
        now = SceneObject(moved.id, moved.label, (float(x), float(y), float(top_z)), moved.confidence, footprint)
        self._placed_in_prompt.add(moved.id)
        if footprint is not None:
            self._placed_angles[moved.id] = (float(x), float(y), float(footprint[2]))
        self._last_scene = [o for o in self._last_scene if o.id != moved.id] + [now]
        note_moved = getattr(self.scene_builder, "note_moved", None)
        if note_moved is not None:
            note_moved(moved.id, now.xyz_robot)

    def _tool_place_at(self, args: dict) -> str:
        name = str(args["place_name"]).strip().lower()
        places = self._saved_places()
        if name not in places:
            raise ValueError(f"No saved place called '{name}'. Available: {sorted(places) or 'none'}.")
        target = places[name]
        if not self.holding:
            return self._tool_place({"x": target.x, "y": target.y, "z": target.z})   # (says there's nothing held)
        z = self._let_go_at(name, target)
        scene_place = name in self._scene_place_names()
        x, y = self._spot_at_place(name, target, target.z if scene_place else None)
        spot = "" if (x, y) == (target.x, target.y) else f", at a free spot in it ({x:.0f}, {y:.0f})"
        if scene_place:
            self._note_target(f"the scene's place '{name}': its surface at ({target.x:.0f}, {target.y:.0f}, "
                              f"{target.z:.0f}){spot}, let go {z - target.z:.0f} mm above it")
        else:
            self._note_target(f"saved place '{name}' at ({target.x:.0f}, {target.y:.0f}, {target.z:.0f})")
        return self._tool_place({"x": x, "y": y, "z": z})

    def _tool_put_all_in(self, args: dict) -> str:
        """Several objects into one tray or bin, planned together (see packing.py), then picked and put down one after
        another. What can't be picked, or doesn't fit, is left where it is and said so."""
        name = str(args.get("place_name", "")).strip().lower()
        places = self._saved_places()
        if name not in places:
            raise ValueError(f"No saved place called '{name}'. Available: {sorted(places) or 'none'}.")
        if self.holding:
            raise ValueError(f"Already holding the {self.holding}: put it down first.")
        self._look_first()
        areas = self._place_areas()
        if name not in areas:
            raise ValueError(f"The size of the '{name}' isn't known, so they can't be planned into it together: "
                             "put them in one at a time with pick and place_at.")
        place, (inner_w, inner_d, wall_top) = places[name], areas[name]
        ids = list(dict.fromkeys(str(i) for i in (args.get("object_ids") or [])))
        if not ids:
            raise ValueError("Which objects? Give their ids from list_objects.")
        objects = [self._find_object(i) for i in ids]
        in_it = lambda o: abs(o.xyz_robot[0] - place.x) <= inner_w / 2 and abs(o.xyz_robot[1] - place.y) <= inner_d / 2  # noqa: E731
        already = [o for o in objects if in_it(o)]
        items, left_out = [], [(o.label, "already in it") for o in already]
        for o in objects:
            if o in already:
                continue
            width, length, _ = _footprint(o) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
            height = self._heights.get(o.label, DEFAULT_OBJECT_HEIGHT_MM)
            if self.gripper.fingers and width > self.gripper.widest_mm:
                left_out.append((o.label, f"{width:.0f} mm wide: too wide for the gripper"))
                continue
            try:
                depth = grip_depth(self.gripper, self._heights.get(o.label))
            except ValueError:
                left_out.append((o.label, "too flat for the fingers"))
                continue
            items.append(Item(o.id, o.label, width, length, height, depth))
        existing = []
        for o in self._last_scene:
            if o in objects and o not in already or not in_it(o):
                continue
            width, length, angle = _footprint(o) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
            existing.append(Box(o.id, o.label, o.xyz_robot[0] - place.x, o.xyz_robot[1] - place.y, width, length,
                                angle, o.xyz_robot[2], layer=1 if self._below(o) is not None else 0,
                                covered=self._covered_by(o) is not None))
        shape = self.gripper.shape
        fingers = (Fingers(self.gripper.opening_mm / 2.0 + shape.finger_thickness_mm / 2.0, shape.finger_thickness_mm,
                           shape.finger_width_mm) if self.gripper.fingers else None)
        def reachable(x: float, y: float, z: float) -> bool:
            # as _tool_place will judge it: there, and the approach above it
            return all(self._within_bounds(Pose(place.x + x, place.y + y, height))
                       for height in (z, z + PLACE_APPROACH_HEIGHT_MM))
        def can_close(x: float, y: float, closing: float) -> bool:
            # a turn r that closes the fingers along `closing` (or half round; any whole turn more) that the wrist has
            return any(self.gripper.wrist_fits(closing + k - self.gripper.jaw_axis_deg + turn, place.x + x, place.y + y)
                       for k in (0.0, 180.0) for turn in (-360.0, 0.0, 360.0))
        plan = plan_tray(items, (inner_w, inner_d), wall_top, place.z, existing, fingers, reachable=reachable,
                         can_close=can_close)
        left_out += plan.left_out
        self._note_target(f"planned together into the '{name}': " + "; ".join(
            f"the {p.label} {'on the ' + p.on if p.on else 'on its floor'} at ({place.x + p.x:.0f}, {place.y + p.y:.0f})"
            for p in plan.placements))
        self.last_record["packing"] = {"place": name, "planned": [
            {"object": p.label, "at": [round(place.x + p.x), round(place.y + p.y)], "on": p.on, "turned_to": p.angle}
            for p in plan.placements], "left_out": [list(item) for item in left_out]}
        done, stopped = [], False
        for p in plan.placements:
            if self.should_stop():
                stopped = True
                break
            try:
                self._tool_pick({"object_id": p.id})
            except ValueError as exc:
                left_out.append((p.label, str(exc)))
                continue
            x, y = place.x + p.x, place.y + p.y
            try:
                self._tool_place({"x": x, "y": y, "z": self._release_z(p.surface) + p.drop,
                                  "top_z": p.surface + self._held_height, "r": self._release_turn(p.closing, x, y)})
            except ValueError as exc:
                # not left stuck holding it: put down on a free spot, and on with the rest
                left_out.append((p.label, str(exc)))
                self._tool_place_free({"where": "center"})
                continue
            done.append(f"the {p.label} " + (f"on the {p.on}" if p.on else "on its floor"))
        self.last_record["packing"]["done"] = len(done)
        self.last_record["packing"]["stopped"] = stopped
        text = f"Put {len(done)} of {len(ids)} in the {name}"
        text += (": " + ", ".join(done) + ".") if done else "."
        if left_out:
            text += " Left where they are: " + "; ".join(f"the {label} ({why})" for label, why in left_out) + "."
        if stopped:
            text += " Stopped by you before the rest."
        return text

    def _release_turn(self, closing: float, x: float, y: float) -> float:
        """The end effector's turn that has the fingers close along `closing` at (x, y) -- so the held object lies the
        way the plan says (they hold it across its narrow side) -- within the wrist's reach there."""
        now = self.gripper.closing_direction(self._grip_r)
        delta = (closing - now + 90.0) % 180.0 - 90.0             # the fingers look the same turned half round
        for r in sorted((self._grip_r + delta + k * 180.0 for k in (-1, 0, 1)), key=lambda r: abs(r - self._grip_r)):
            if self.gripper.wrist_fits(r, x, y):
                return r
        return self._carry_turn(x, y)

    def _tool_place_on(self, args: dict) -> str:
        ids = list(args.get("object_ids") or [])
        if len(ids) > 1:
            return self._place_across([self._find_object(i) for i in ids])
        if not ids and not args.get("object_id"):
            raise ValueError("On what? Give object_id (or object_ids to lay it across several).")
        target = self._find_object(ids[0] if ids else args["object_id"])
        self._not_the_held(target, "place_on", "on")
        cover = self._covered_by(target)
        cleared = ""
        if cover is None and self.holding and self._back_where_it_stood(target):
            target, cleared = self._put_back_then_place_on(target)
        if cover is not None and self.holding and self._in_the_way(target):
            # (V4.2: "put the blue cube on the green cube" with a red one left on green by an earlier task -- the model
            # gave up and ended still holding blue. The request doesn't name red, so it is only in the way.)
            target, cleared = self._clear_then_place_on(target)
            cover = self._covered_by(target)
        if cover is not None:
            # Say where it CAN go: told only "nothing can be put on it", the model gave up on a tower half-built
            # and put the rest of the cubes down anywhere.
            top = self._top_of_pile(cover)
            still = f" You are still holding the {self.holding}." if self.holding else ""
            raise ValueError(f"The {target.label} has the {cover.label} on top of it, so nothing can be put on it "
                             f"directly. The top of that pile is the {top.label} ({top.id}): to add to the pile "
                             f"(e.g. building a tower), call place_on with object_id {top.id}.{still}")
        held = self.holding
        held_id = self._held_obj.id if self._held_obj is not None else None
        x, y, z = target.xyz_robot
        # the object's bottom just above the lower one's top. The suction cup used to let go 20 mm above it, which with
        # a 25 mm cube pressed it 5 mm into the one below (a soft cup gives a little; the demo's doesn't)
        release = self._release_z(z)
        self._note_target(f"top of the {target.label} ({target.id}) at ({x:.0f}, {y:.0f}, {z:.0f}) + {release - z:.0f} mm")
        result = self._tool_place({"x": x, "y": y, "z": release, "top_z": z + self._held_height})
        if held:
            self._under[target.label] = held   # remembered, in case it is later hidden from the camera
        return cleared + result + self._pile_report(held_id)

    def _held_only_in_the_way(self) -> bool:
        """What is held is a cube the request doesn't name (it names colours, and not this one's): only in the way."""
        from app.llm.request_checks import MANY, colour_of, named_colours
        request = str(getattr(self, "request", "") or "")
        if not request or MANY.search(request.lower()) or BUILDING_WORDS.search(request.lower()):
            return False
        named = set(named_colours(request))
        return bool(named) and colour_of(self.holding) not in named

    def _in_the_way(self, target: SceneObject) -> bool:
        """Whether everything on `target` is only in the way: the request names `target` itself, names none of the
        objects on it, and isn't about building a pile ("green, then red, then blue", "a tower of all these cubes":
        what is on it is part of what's being built -- then place_on its top, as said)."""
        from app.llm.request_checks import MANY, named_colours
        request = str(getattr(self, "request", "") or "")
        if not request or BUILDING_WORDS.search(request.lower()) or MANY.search(request.lower()):
            return False
        from app.llm.request_checks import colour_of
        named = set(named_colours(request))
        above = [o for o in self._last_scene if self._sits_above(o, target)]
        return (bool(above) and colour_of(target.label) in named
                and not any(colour_of(o.label) in named for o in above))

    def _back_where_it_stood(self, target: SceneObject) -> bool:
        """`target` was set aside (by _clear_the_way) off the very object now held, which was under it: turning the
        pair over, it goes back where it stood first, so the pile ends where it was."""
        aside = self._set_aside.get(target.id)
        held = self._held_obj
        return (aside is not None and held is not None and aside[3] == held.id
                and math.dist(aside[:2], target.xyz_robot[:2]) > BACK_WHERE_MM)

    def _put_back_then_place_on(self, target: SceneObject) -> tuple[SceneObject, str]:
        """The held object put down out of the way, `target` carried back to where it stood (at its turn then), the
        held one picked up again: then it goes on `target` where the pile was. Returns `target` as seen now and what
        was done."""
        held = self.holding
        x0, y0, angle0, _ = self._set_aside.pop(target.id)
        wanted, self._wanted_turn = self._wanted_turn, None     # (no turn for the moves on the way: only the last)
        done: list[str] = []
        try:
            self._just_placed.append((x0, y0))                    # (not there: that is where the other goes back)
            put = self._tool_place_free({"where": "next_to", "object_id": target.id})
            done.append(f"the {held} was put down ({put.rstrip('.')})")
            self._tool_list_objects({})
            target = self._seen_again(target, *target.xyz_robot[:2])
            self._carry(target, lambda: self._put_down_at(x0, y0, angle=angle0))
            done.append(f"the {target.label} put back where it stood, ({x0:.0f}, {y0:.0f})")
            self._tool_list_objects({})
            again = min((o for o in self._last_scene if o.label == held),
                        key=lambda o: math.dist(o.xyz_robot[:2], (x0, y0)), default=None)
            if again is None:
                raise ValueError(f"the {held} can't be seen any more")
            self._tool_pick({"object_id": again.id})
            done.append(f"the {held} picked up again")
        except ValueError as exc:
            now = f" Now holding the {self.holding}." if self.holding else " Nothing is held now."
            raise ValueError(f"Putting the {target.label} back for the {held}: " + "; ".join(done or ["nothing done"])
                             + f"; then: {str(exc).rstrip('.')}.{now} Tell the user.") from None
        self._wanted_turn = wanted
        target = self._seen_again(target, x0, y0)
        return target, (f"The {target.label} had been moved aside off the {held}, so it went back where it stood "
                        "first: " + "; ".join(done) + ". ")

    def _clear_then_place_on(self, target: SceneObject) -> tuple[SceneObject, str]:
        """The held object put down beside, what's on `target` moved aside (as pick does), the held one picked up again:
        then it can go on `target`. Returns `target` as seen now and what was done."""
        held = self.holding
        above = [o for o in self._last_scene if self._sits_above(o, target)]
        if len(above) > CLEAR_LEVELS:              # (said before anything is put down)
            raise ValueError(f"The {target.label} has {len(above)} objects on it: too many to take off. You are still "
                             f"holding the {held}.")
        wanted, self._wanted_turn = self._wanted_turn, None     # (no turn for the moves on the way: only the last)
        done: list[str] = []
        try:
            put = self._tool_place_free({"where": "next_to", "object_id": target.id})
            done.append(f"the {held} was put down ({put.rstrip('.')})")
            self._tool_list_objects({})
            target = min((o for o in self._last_scene if o.label == target.label),
                         key=lambda o: math.dist(o.xyz_robot[:2], target.xyz_robot[:2]), default=target)
            cover = self._covered_by(target)
            if cover is not None:
                target, said = self._clear_the_way(target, cover)
                done.append(said.strip().rstrip("."))
            again = min((o for o in self._last_scene if o.label == held),
                        key=lambda o: math.dist(o.xyz_robot[:2], target.xyz_robot[:2]), default=None)
            if again is None:
                raise ValueError(f"the {held} can't be seen any more")
            self._tool_pick({"object_id": again.id})
            done.append(f"the {held} picked up again")
            self._tool_list_objects({})
        except ValueError as exc:
            now = f" Now holding the {self.holding}." if self.holding else " Nothing is held now."
            raise ValueError(f"Clearing the {target.label} for the {held}: " + "; ".join(done or ["nothing done"])
                             + f"; then: {str(exc).rstrip('.')}.{now} Tell the user.") from None
        self._wanted_turn = wanted
        target = min((o for o in self._last_scene if o.label == target.label),
                     key=lambda o: math.dist(o.xyz_robot[:2], target.xyz_robot[:2]), default=target)
        return target, (f"The {target.label} had something on it that the request doesn't name: "
                        + "; ".join(done) + ". ")

    def _place_across(self, supports: list) -> str:
        """Lay the held object across `supports` (a bar on top of a row of cubes): along their row, its middle over
        the row's middle, resting on their level tops. Only when it is steady: the tops level, something under it on
        both sides of its middle, and no end out past the supports by more than a quarter of its length. Before
        this a long thing could only go on one object, and "the bar on top of all the cubes" was refused."""
        if not self.holding:
            raise self._nothing_held()
        self._require_listed()
        for s in supports:
            cover = self._covered_by(s)
            if cover is not None:
                raise ValueError(f"The {s.label} has the {cover.label} on top of it: it can't hold anything else up.")
        tops = [s.xyz_robot[2] for s in supports]
        if max(tops) - min(tops) > BRIDGE_LEVEL_MM:
            raise ValueError("Their tops aren't level (" + ", ".join(f"the {s.label} {s.xyz_robot[2]:.0f} mm"
                                                                     for s in supports)
                             + "): it would tip. Tell the user.")
        held_fp = (_footprint(self._held_obj) if self._held_obj is not None else None) or (OBJECT_WIDTH_MM, 60.0, 0.0)
        width, length = held_fp[0], held_fp[1]
        # the row: the line through the supports' middles (the way they are spread out)
        xs = [s.xyz_robot[0] for s in supports]
        ys = [s.xyz_robot[1] for s in supports]
        cx, cy = sum(xs) / len(xs), sum(ys) / len(ys)
        sxx = sum((x - cx) ** 2 for x in xs)
        syy = sum((y - cy) ** 2 for y in ys)
        sxy = sum((x - cx) * (y - cy) for x, y in zip(xs, ys))
        line = math.degrees(0.5 * math.atan2(2.0 * sxy, sxx - syy))
        ux, uy = math.cos(math.radians(line)), math.sin(math.radians(line))
        spans = []
        for s in supports:
            fp = _footprint(s) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
            along = (s.xyz_robot[0] - cx) * ux + (s.xyz_robot[1] - cy) * uy
            side = -(s.xyz_robot[0] - cx) * uy + (s.xyz_robot[1] - cy) * ux
            half = _width_along(s, fp, line) / 2.0
            if abs(side) > _width_along(s, fp, line + 90.0) / 2.0 + width / 2.0 - 2.0:
                raise ValueError(f"They aren't in a row: the {s.label} is {abs(side):.0f} mm off the line through "
                                 "them, so it wouldn't hold it up. Tell the user.")
            spans.append((along - half, along + half, s))
        low, high = min(a for a, _, _ in spans), max(b for _, b, _ in spans)
        middle = (low + high) / 2.0
        if not (any(b > middle - length / 2 + 1.0 and a < middle - 1.0 for a, b, _ in spans)
                and any(a < middle + length / 2 - 1.0 and b > middle + 1.0 for a, b, _ in spans)):
            raise ValueError(f"The {self.holding} ({length:.0f} mm) is too short to reach across them (they span "
                             f"{high - low:.0f} mm): it would fall between. Tell the user.")
        overhang = max(low - (middle - length / 2), (middle + length / 2) - high)
        if overhang > BRIDGE_OVERHANG * length:
            raise ValueError(f"The {self.holding} would stick out {overhang:.0f} mm past them at an end (more than a "
                             f"quarter of its {length:.0f} mm): it might tip. Tell the user.")
        x, y = cx + ux * middle, cy + uy * middle
        top = max(tops)
        # its long side along the row (a long object looks the same half a turn on)
        note = self._want_turn(line, absolute=True) if self.gripper.fingers else ""
        held = self.holding
        names = ", ".join(f"the {s.label}" for s in supports[:-1]) + f" and the {supports[-1].label}"
        self._note_target(f"across {names}: their row's middle ({x:.0f}, {y:.0f}), on their tops at {top:.0f} mm")
        try:
            self._tool_place({"x": x, "y": y, "z": self._release_z(top), "top_z": top + self._held_height})
        finally:
            self._wanted_turn = None
        return f"Laid the {held} across {names}, at ({x:.0f}, {y:.0f}) mm, along their row ({line % 180:.0f}°)."

    def _pile_report(self, placed_id: Optional[str]) -> str:
        """The pile just added to, bottom to top, and what else is on the table. Told only "Placed red cube at
        (172, -2, 45)", the model took the cube it had just stacked for the bottom of the tower, described the
        tower wrongly and stopped with a cube left out."""
        placed = next((o for o in self._last_scene if o.id == placed_id), None)
        if placed is None:
            return ""
        pile = self._pile_of(placed)
        others = [f"{o.label} ({o.id})" for o in self._last_scene
                  if o.label not in pile and o.label != self.holding]
        text = (f". The pile is now, bottom to top: {', '.join(pile)} ({len(pile)} objects; the top is the "
                f"{placed.label}, {placed.id}).")
        text += (" Not in this pile: " + ", ".join(others) + ". To add one to this pile: pick it, then "
                 f"place_on with object_id {placed.id}." if others
                 else " Every object on the table is in this pile.")
        return text

    def _beside_spot(self, anchor: SceneObject, side: str, gap: float, z: float):
        """((x, y, r, turned a quarter turn?), None) to put the held object `gap` mm to the `side` of `anchor`, letting
        go at height z with the open gripper clear of everything; or (None, why not). As carried (or turned so it
        looks the same) first; failing that a quarter turn, for something long: a pen put beside a can with the
        fingers closing towards the can had no room for them, lying the other way it has."""
        dx, dy = BESIDE_DIRECTIONS[side]
        direction = math.degrees(math.atan2(dy, dx))
        anchor_fp = _footprint(anchor) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
        held_fp = ((_footprint(self._held_obj) if self._held_obj is not None else None)
                   or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0))
        turned = (self._carry_turn(*anchor.xyz_robot[:2]) - self._grip_r) if self.gripper.fingers else 0.0
        why = "no room"
        for extra in ((0.0,) if self._held_square or not self.gripper.fingers else (0.0, 90.0)):
            held_now = (held_fp[0], held_fp[1], held_fp[2] + turned + extra)
            # edge to edge: half of each one's width along the way, as measured (it was taken as 25 mm for both:
            # with 20 mm cubes a 5 mm gap came out 10)
            # -- squared up for cubes, but never closer corner to corner than the smallest gap (two cubes turned 45
            # degrees, corner to corner, are 10 mm wider than squared up: a 5 mm gap would have them overlap)
            centres = max(_width_squared(anchor, anchor_fp, direction) / 2 + gap
                          + _width_squared(self._held_obj, held_now, direction) / 2,
                          _width_along(anchor, anchor_fp, direction) / 2 + min(gap, MIN_BESIDE_GAP_MM)
                          + _width_along(self._held_obj, held_now, direction) / 2)
            x, y = anchor.xyz_robot[0] + dx * centres, anchor.xyz_robot[1] + dy * centres
            taken = None
            for other in self._last_scene:
                if other is anchor or other.label == self.holding:
                    continue
                other_fp = _footprint(other) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)
                if rectangles_overlap((x, y), held_now, other.xyz_robot[:2], other_fp, 3.0):
                    taken = other.label
                    break
            if taken:
                why = f"that spot ({x:.0f}, {y:.0f}) is taken by the {taken}"
                continue
            above_z = self._approach_z(x, y, z, PLACE_APPROACH_HEIGHT_MM)
            if not self._can_reach(Pose(x, y, z)) or above_z is None or not self._can_reach(Pose(x, y, above_z)):
                why = f"({x:.0f}, {y:.0f}) is out of reach"
                continue
            if not self.gripper.fingers:
                return (x, y, 0.0, False), None
            for r in self._release_turns(x, y, extra):
                hit = self._finger_hits_at(x, y, z, self.gripper.closing_direction(r))
                if hit is None:
                    return (x, y, r, extra != 0.0), None
                why = f"the open gripper would hit the {hit} there"
        return None, why

    def _tool_place_beside(self, args: dict) -> str:
        """Beside `object_id`, on `side`, `gap_mm` apart edge to edge, on the same surface it stands on."""
        if not self.holding:
            raise self._nothing_held(" (object_id in place_beside is the object to put it beside, not the one to "
                                     "move.)")
        self._require_listed()
        anchor = self._find_object(args["object_id"])
        self._not_the_held(anchor, "place_beside", "beside")
        side = str(args.get("side", "")).strip().lower()
        side = {"back": "behind", "near": "behind", "far": "front", "forward": "front"}.get(side, side)
        if side not in BESIDE_DIRECTIONS:
            raise ValueError(f"Unknown side '{side}': use left, right, front or behind (the robot's own directions).")
        gap = float(args.get("gap_mm", 10.0))
        if gap < MIN_BESIDE_GAP_MM:
            raise ValueError(f"A gap of {gap:.0f} mm is too small to do reliably: the calibration can be a few mm off, "
                             f"so the objects could touch or knock. Use at least {MIN_BESIDE_GAP_MM:.0f} mm.")
        if self._covered_by(anchor) is not None:
            raise ValueError(f"The {anchor.label} has something on top of it; put things beside the top one instead.")
        # the same surface the anchor stands on: its top minus its own height, then the held object on that -- and
        # for the top of a pile, the surface the pile stands on ("left of the tower": beside its top, it was let go
        # in mid-air, a cube up)
        pile = self._pile_of(anchor)
        below = pile[:pile.index(anchor.label) + 1] if anchor.label in pile else [anchor.label]
        surface = anchor.xyz_robot[2] - sum(self._heights.get(label, DEFAULT_OBJECT_HEIGHT_MM) for label in below)
        z = self._release_z(surface)
        # ("lift it 50 mm above the table to the right of the green cube, and let it drop": let go that high up)
        drop = min(max(float(args.get("drop_mm") or 0.0), 0.0), DROP_MAX_MM)
        spot, why = self._beside_spot(anchor, side, gap, z + drop)
        if spot is None:
            fits = [other for other in BESIDE_DIRECTIONS if other != side
                    and self._beside_spot(anchor, other, gap, z)[0] is not None]
            # (the side the user named isn't swapped for another: the robot put a cube on the left when asked for
            # the right, because this said "use side=left")
            hint = (f" There is room on its {' and '.join(fits)}. If the user named this side, don't put it elsewhere: "
                    "tell the user why and ask; if the side was your own choice, use another."
                    if fits else " Leave a bigger gap, or put it somewhere else.")
            raise ValueError(f"Can't put the {self.holding} to the {side} of the {anchor.label}: {why}.{hint}")
        x, y, r, quarter = spot
        for name, place in self._obstacle_places().items():      # (a printed spot is no obstacle)
            if math.hypot(place.x - x, place.y - y) < CLEARANCE_MM:
                raise ValueError(f"That spot ({x:.0f}, {y:.0f}) is on the '{name}'. Tell the user.")
        held = self.holding
        self._note_target(f"{gap:.0f} mm to the {side} of the {anchor.label} ({anchor.id}): worked out as ({x:.0f}, {y:.0f})"
                          + (", turned a quarter turn so the fingers fit" if quarter else ""))
        held_id = self._held_obj.id if self._held_obj is not None else None
        if drop:
            self._tool_place({"x": x, "y": y, "z": z + drop, "r": r, "top_z": surface + self._held_height})
            self._placed_angles.pop(held_id, None)            # (it may turn as it lands: its turn isn't known now)
            held += f" (let go {drop:.0f} mm up, so it dropped)"
        else:
            self._tool_place({"x": x, "y": y, "z": z, "r": r})
        if quarter:
            held += " (turned a quarter turn, so the fingers fit)"
        return (f"Put the {held} down to the {side} of the {anchor.label} (the robot's {side}), {gap:.0f} mm apart "
                f"edge to edge, at ({x:.0f}, {y:.0f}) mm; the {anchor.label} is at "
                f"({anchor.xyz_robot[0]:.0f}, {anchor.xyz_robot[1]:.0f}) mm")

    def _tool_place_free(self, args: dict) -> str:
        if not self.holding:
            raise self._nothing_held()
        side = next((s for s in ("left", "right", "front", "behind") if s in str(args.get("where", "")).lower()), None)
        if args.get("object_id") and side:
            # (S-19 in the twin, 2026-10-25: place_free(where=right, object_id=green) for "to the right of the green
            # cube with a 50 mm gap" put it next to green on whichever side was free -- its left)
            raise ValueError(f"place_free next to an object takes whichever side is free, not its {side}. For the "
                             f"{side} side of it use place_beside(object_id, side='{side}', gap_mm=the gap asked for, "
                             "else 10). Nothing was done.")
        self._require_listed()
        table_z = self.table_z_provider()
        if table_z is None:
            raise ValueError("The table height isn't known yet, so I can't put it down on the table. Tell the user to do "
                             "the calibration's table-height step, or use place_at with a saved place.")
        where = str(args.get("where", "center")).lower()
        anchor = self._find_object(args["object_id"]) if args.get("object_id") else None
        x, y, description = self._choose_free_spot(where, anchor)
        z = self._release_z(table_z)     # the object's bottom just above the table
        held = self.holding
        self._note_target(f"free table spot, {description}: worked out as ({x:.0f}, {y:.0f})")
        self._tool_place({"x": x, "y": y, "z": z})
        return f"Put the {held} down {description}, at ({x:.0f}, {y:.0f}) mm"

    def _choose_free_spot(self, where: str, anchor: Optional[SceneObject]) -> tuple[float, float, str]:
        """A spot on the table that is reachable, clear of every object (seen or remembered) and of the
        saved places, chosen by `where`. Returns (x, y, plain-words description)."""
        bounds = getattr(self.robot, "bounds", None) or {"x": [-300.0, 307.0], "y": [-300.0, 300.0]}
        reach = float(getattr(self.robot, "max_reach_mm", 300.0)) * 0.95 - 5.0
        r_min = robots.active().min_radius_mm + 10.0   # nearer the base the arm can't reach down to the table
        occupied = [(o.xyz_robot[0], o.xyz_robot[1], CLEARANCE_MM) for o in self._last_scene]
        occupied += [(p.x, p.y, SAVED_PLACE_CLEARANCE_MM) for p in self._obstacle_places().values()]
        occupied += [(x, y, CLEARANCE_MM) for x, y in self._just_placed]
        candidates = []
        for x in range(int(max(bounds["x"][0], MIN_X_MM)), int(bounds["x"][1]) + 1, 10):
            for y in range(int(bounds["y"][0]), int(bounds["y"][1]) + 1, 10):
                radius = math.hypot(x, y)
                if radius < r_min or radius > reach:
                    continue
                if any(math.hypot(x - ox, y - oy) < clearance for ox, oy, clearance in occupied):
                    continue
                candidates.append((x, y, radius))
        # and where the camera will see it (the arm reaches further than the camera sees)
        table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
        floor = table_z or 0.0
        candidates = [c for c in candidates if self._in_view(c[0], c[1], floor) is not False
                      and self._in_view(c[0], c[1], floor + OBJECT_WIDTH_MM) is not False]   # its foot and its top
        if not candidates:
            raise ValueError("There is no free spot on the table that the arm can reach and the camera can see. Tell "
                             "the user the table is too crowded.")

        if anchor is not None or "next" in where or "beside" in where:
            if anchor is None:
                raise ValueError("next_to needs an object_id: which object should it go beside?")
            ax, ay = anchor.xyz_robot[0], anchor.xyz_robot[1]
            # (next to itself: "take it out of the tray" -- "next to the red cube" read as if there were two)
            beside = "beside where it was" if anchor.label == self.holding else f"next to the {anchor.label}"
            order, words = (lambda c: math.hypot(c[0] - ax, c[1] - ay)), lambda c: beside
        elif "base" in where or "near" in where or "close" in where:
            order = lambda c: (round(c[2] / 10), abs(c[1]))  # noqa: E731
            words = lambda c: f"close to the robot base ({c[2]:.0f} mm from it, the nearest the arm can reach)"  # noqa: E731
        elif "far" in where or "away" in where:
            order = lambda c: (-round(c[2] / 10), abs(c[1]))  # noqa: E731
            words = lambda c: f"far from the robot base ({c[2]:.0f} mm from it)"  # noqa: E731
        elif "left" in where:
            order = lambda c: -(c[1] - 0.2 * abs(c[0] - 200.0))  # noqa: E731
            words = lambda c: "on the left side (the robot's left, looking away from its base)"  # noqa: E731
        elif "right" in where:
            order = lambda c: c[1] + 0.2 * abs(c[0] - 200.0)  # noqa: E731
            words = lambda c: "on the right side (the robot's right, looking away from its base)"  # noqa: E731
        else:
            order = lambda c: math.hypot(c[0] - 200.0, c[1])  # noqa: E731
            words = lambda c: "in the middle of the table"  # noqa: E731
        # the best spot where the open fingers can also let go (clear of what's beside it): chosen by distance alone,
        # the xArm's wide-open fingers came down on a cylinder in the tray next to the spot, and the move was refused
        ranked = sorted(candidates, key=order)
        table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
        for best in ranked[:200]:
            if table_z is None or self._fingers_can_let_go(best[0], best[1], self._release_z(table_z)):
                return best[0], best[1], words(best)
        best = ranked[0]
        return best[0], best[1], words(best)

    def _fingers_can_let_go(self, x: float, y: float, z: float) -> bool:
        """Whether the held object can be let go at (x, y, z) with the open fingers clear, turned some way that leaves
        it looking as carried (as _clear_turn would choose)."""
        if not self.gripper.fingers or not self.holding:
            return True
        return any(self._finger_hits_at(x, y, z, self.gripper.closing_direction(r)) is None
                   for r in self._release_turns(x, y))

    def _tool_move_to(self, args: dict) -> str:
        self._require_listed()
        target = Pose(x=args["x"], y=args["y"], z=args["z"], r=self._carry_turn(args["x"], args["y"]))
        self._note_target(f"coordinates written by the model ({target.x:.0f}, {target.y:.0f}, {target.z:.0f})")
        self._require_reachable(target, "Target")
        self._travel(target)
        return f"Moved to ({args['x']:.0f}, {args['y']:.0f}, {args['z']:.0f}) mm"

    def _tool_move_above(self, args: dict) -> str:
        obj = self._find_object(args["object_id"])
        x, y, z = obj.xyz_robot
        target = Pose(x=x, y=y, z=self._approach_or_refuse(x, y, z, f"The {obj.label}"), r=self._carry_turn(x, y))
        self._note_target(f"camera: top of the {obj.label} ({obj.id}) + {target.z - z:.0f} mm")
        self._require_reachable(target, obj.label)
        self._travel(target)
        return f"Moved above {obj.label} ({obj.id})"

    def _tool_home(self, args: dict) -> str:
        # to the home position clear of anything tall first (the homing move itself is the controller's, not ours:
        # from there it doesn't sweep past a pile)
        self._travel(Pose(x=HOME_X_MM, y=0.0, z=HOME_Z_MM, r=0.0))
        self.robot.home()
        return "Moved home"

    def _tool_open_gripper(self, args: dict) -> str:
        self.robot.open_gripper()
        if self.holding:                             # (let go: it fell, or was set down -- where, unknown till looked)
            dropped = self.holding
            self.let_go_by_hand()
            self._listed = False
            return (f"Gripper opened: let go of the {dropped}. Where it is now isn't known until the table is looked "
                    "at again: call list_objects before picking it.")
        return "Gripper opened"

    def _tool_close_gripper(self, args: dict) -> str:
        self.robot.close_gripper()
        return "Gripper closed"

"""More ways to move things, each one call for the model (the app does the positions, order and checks):

- line_up: objects in a row, in an order (as given, smallest first, largest first), a gap apart;
- move_object: an object moved by a distance in a direction ("5 cm to the left");
- take_apart / empty_place: a pile taken down, a tray emptied, top first, onto free table nearby;
- place_between / swap: the held object between two others; two objects swapped;
- put_back: objects back where they were when the last prompt began ("put it back", "undo that");
- set_speed: "slowly" / "carefully" for the rest of the prompt.

Distances may be given with units ("5 cm", "2 inches"): `to_mm` turns them into mm.
"""
from __future__ import annotations

import math
import re
from typing import Callable, Optional

from app.llm.packing import rectangles_overlap
from app.vision.scene import SceneObject

UNIT_MM = {"mm": 1.0, "millimetre": 1.0, "millimeter": 1.0, "cm": 10.0, "centimetre": 10.0, "centimeter": 10.0,
           "in": 25.4, "inch": 25.4, "inches": 25.4, '"': 25.4, "m": 1000.0}
DIRECTIONS = {"left": (0.0, 1.0), "right": (0.0, -1.0), "forward": (1.0, 0.0), "front": (1.0, 0.0),
              "away": None, "back": (-1.0, 0.0), "behind": (-1.0, 0.0), "backward": (-1.0, 0.0),
              "towards_base": None, "closer": None,
              "nearer": (-1.0, 0.0), "farther": None}      # (V4.3: the request's own words, as back and further)
SPOT_GAP_MM = 3.0           # a spot is free when nothing else is this near its footprint
MOVED_MM = 10.0             # put_back: further than this from where it was counts as moved
SEEN_AGAIN_MM = 30.0        # swap: the cube it just put down, seen within this of where (if its id changed)
STANDS_ON_MM = 12.0         # swap: an object seen under another, its top at least this much lower, is what it stands on
SLOW_SHARE = 0.4            # set_speed slow: this share of the arm's set speed
FINGER_ROOM_MM = 26.0       # line_up: this much free table round each spot, for the open fingers
ROW_GAP_MM = 20.0           # line_up's default gap, edge to edge
DROP_HEIGHT_MM = 40.0       # drop: the object's bottom this far above the table when let go, unless asked


def _direction(word: str, x: float, y: float) -> tuple[float, float]:
    """The unit step for a direction word, at an object at (x, y): left/right/forward/back are the robot's own;
    away/further and closer/towards the base are along the line from the robot's base."""
    radius = math.hypot(x, y) or 1.0
    if word in ("away", "forward_away", "further", "farther"):
        return x / radius, y / radius
    if word in ("towards_base", "closer", "towards_the_robot", "toward_the_robot"):
        return -x / radius, -y / radius
    if word in DIRECTIONS and DIRECTIONS[word] is not None:
        return DIRECTIONS[word]
    raise ValueError(f"Which way is '{word}'? Use left, right, forward or back (the robot's own directions).")


def to_mm(value, default: Optional[float] = None) -> float:
    """A distance in mm from a number (mm) or text with a unit: "5 cm" -> 50, "2 inches" -> 50.8, "30" -> 30."""
    if value is None or value == "":
        if default is None:
            raise ValueError("How far? Give a distance, e.g. 50 (mm) or '5 cm'.")
        return float(default)
    if isinstance(value, (int, float)):
        return float(value)
    match = re.match(r"\s*(-?\d+(?:\.\d+)?)\s*([a-zA-Z\"]*)", str(value))
    if not match:
        raise ValueError(f"'{value}' is not a distance: give e.g. 50 (mm) or '5 cm'.")
    number, unit = float(match.group(1)), match.group(2).lower()
    return number * UNIT_MM.get(unit or "mm", 1.0)


ARRANGE_SCHEMAS = [
    {"type": "function", "function": {
        "name": "line_up",
        "description": "Puts objects in a ROW on free table, in an order (given = as in object_ids), a gap apart.",
        "parameters": {"type": "object", "properties": {
            "object_ids": {"type": "array", "items": {"type": "string"}},
            "order": {"type": "string", "description": "given, smallest_first or largest_first"},
            "gap_mm": {"type": "number", "description": "edge to edge, mm (default 20)"},
            "along": {"type": "string", "description": "left_to_right or near_to_far"},
            "where": {"type": "string", "description": "center, left, right, near_base or far"}},
            "required": ["object_ids"]}}},
    {"type": "function", "function": {
        "name": "move_object",
        "description": "Moves an object BY a distance in a direction, and puts it down on the table there (nothing "
                       "is held after).",
        "parameters": {"type": "object", "properties": {
            "object_id": {"type": "string"},
            "direction": {"type": "string",
                          "description": "left, right, forward (away from the robot: further, farther) or back "
                                         "(towards the robot: nearer, closer). \"40 mm nearer the robot\" = back."},
            "distance_mm": {"type": "number"}},
            "required": ["object_id", "direction", "distance_mm"]}}},
    {"type": "function", "function": {
        "name": "take_apart",
        "description": "Takes a pile or tower apart: every object above the bottom one, top first, onto free table "
                       "next to it. object_id: any object in the pile.",
        "parameters": {"type": "object", "properties": {"object_id": {"type": "string"}},
                       "required": ["object_id"]}}},
    {"type": "function", "function": {
        "name": "empty_place",
        "description": "Takes everything out of a tray or bin, top first, onto free table next to it.",
        "parameters": {"type": "object", "properties": {"place_name": {"type": "string"}},
                       "required": ["place_name"]}}},
    {"type": "function", "function": {
        "name": "place_between",
        "description": "Puts the HELD object down in the middle between two objects. Pick it first.",
        "parameters": {"type": "object", "properties": {
            "object_id_a": {"type": "string"}, "object_id_b": {"type": "string"}},
            "required": ["object_id_a", "object_id_b"]}}},
    {"type": "function", "function": {
        "name": "drop",
        "description": "LET AN OBJECT DROP: held (or picked first), lifted height_mm above the table, moved distance_mm "
                       "in direction first if asked, then let go so it falls. \"lift it 40 mm, move it 40 mm nearer "
                       "the robot and let it drop\" = drop(id, height_mm=40, direction=back, distance_mm=40). "
                       "Beside another: \"lift it 50 mm above the table to the right of B with a 50 mm gap and let it "
                       "drop\" = drop(id, height_mm=50, beside_id=B, side=right, gap_mm=50).",
        "parameters": {"type": "object", "properties": {
            "object_id": {"type": "string", "description": "id from list_objects, or the id of the object held"},
            "height_mm": {"type": "number", "description": "its bottom above the table when let go (default 40)"},
            "direction": {"type": "string", "description": "left, right, forward (further) or back (nearer the robot)"},
            "distance_mm": {"type": "number", "description": "how far to move it first (default 0: let go where it "
                                                             "was)"},
            "beside_id": {"type": "string", "description": "let it drop beside this object instead (with side, gap_mm)"},
            "side": {"type": "string", "description": "with beside_id: left, right, front or behind"},
            "gap_mm": {"type": "number", "description": "with beside_id: the gap between them, edge to edge"}},
            "required": ["object_id"]}}},
    {"type": "function", "function": {
        "name": "swap",
        "description": "Swaps two objects' places.",
        "parameters": {"type": "object", "properties": {
            "object_id_a": {"type": "string"}, "object_id_b": {"type": "string"}},
            "required": ["object_id_a", "object_id_b"]}}},
    {"type": "function", "function": {
        "name": "put_back",
        "description": "Puts objects back where they were before the last request (default: all it moved).",
        "parameters": {"type": "object", "properties": {
            "object_ids": {"type": "array", "items": {"type": "string"}}},
            "required": []}}},
    {"type": "function", "function": {
        "name": "set_speed",
        "description": "How fast the arm moves for the rest of this request ('slowly' is already done by the app).",
        "parameters": {"type": "object", "properties": {"speed": {"type": "string", "description": "slow or normal"}},
                       "required": ["speed"]}}},
]


class ArrangeTools:
    """The tools above, for ToolExecutor (they use its pick, place and checks)."""

    # ---- what the tools need: where things are, free spots, putting down ------------------------------------------
    def _surface_at(self, x: float, y: float) -> float:
        table_z = self.table_z_provider() if getattr(self, "table_z_provider", None) is not None else None
        if table_z is None:
            raise ValueError("The table height isn't known yet, so nothing can be put down on the table. Tell the "
                             "user to do the calibration's table-height step.")
        return self._floor_under(x, y, table_z)

    def _footprint_of(self, obj) -> tuple[float, float, float]:
        from app.llm.tools import OBJECT_WIDTH_MM, _footprint
        return (_footprint(obj) if obj is not None else None) or (OBJECT_WIDTH_MM, OBJECT_WIDTH_MM, 0.0)

    def _spot_taken(self, x: float, y: float, footprint, ignore: set, gap: float = SPOT_GAP_MM) -> Optional[str]:
        """What is in the way of putting something of `footprint` at (x, y) on the table, if anything: another
        object, or a tray (outside its walls only: inside it, put_all_in plans)."""
        for other in self._last_scene:
            if other.id in ignore or other.label == self.holding:
                continue
            if rectangles_overlap((x, y), footprint, other.xyz_robot[:2], self._footprint_of(other), gap):
                return f"the {other.label}"
        areas = self._place_areas()
        places = self._obstacle_places() if hasattr(self, "_obstacle_places") else self._saved_places()
        for name, (inner_x, inner_y, _) in areas.items():     # (a printed spot is no obstacle: not in places)
            place = places.get(name)
            if place is not None and rectangles_overlap((x, y), footprint, (place.x, place.y),
                                                        (inner_y + 16.0, inner_x + 16.0, 0.0), SPOT_GAP_MM):
                return f"the {name}"
        return None

    def _top_under(self, x: float, y: float, footprint, ignore: set) -> Optional[SceneObject]:
        """The highest object under a footprint at (x, y), if any."""
        under = [o for o in self._last_scene if o.id not in ignore and o.label != self.holding
                 and rectangles_overlap((x, y), footprint, o.xyz_robot[:2], self._footprint_of(o), -2.0)]
        return max(under, key=lambda o: o.xyz_robot[2], default=None)

    def _put_down_at(self, x: float, y: float, angle: Optional[float] = None,
                     surface: Optional[float] = None) -> str:
        """The held object down at (x, y) on `surface` (default: the table or tray floor there), at `angle` if given
        (else as carried)."""
        surface = self._surface_at(x, y) if surface is None else surface
        note = self._want_turn(float(angle), absolute=True) if angle is not None else ""
        try:
            return self._tool_place({"x": x, "y": y, "z": self._release_z(surface),
                                     "top_z": surface + self._held_height}) + note
        finally:
            self._wanted_turn = None

    def _free_spot_near(self, x: float, y: float) -> tuple[float, float]:
        anchor = SceneObject(id="_spot", label="spot", xyz_robot=(x, y, 0.0), confidence=1.0)
        fx, fy, _ = self._choose_free_spot("next_to", anchor)
        return fx, fy

    def _moved_to_free_spot_near(self, obj, x: float, y: float) -> str:
        spot = {}

        def down() -> None:
            spot["xy"] = self._free_spot_near(x, y)
            self._put_down_at(*spot["xy"])
        self._carry(obj, down)
        return f"the {obj.label} to ({spot['xy'][0]:.0f}, {spot['xy'][1]:.0f})"

    def _carry(self, obj, put_down: Callable[[], object]):
        """pick(obj), then `put_down()`; if that fails, the object goes back where it was rather than staying in the
        gripper. "Empty the tray" without a look first: the white cube was picked, couldn't be put down ("call
        list_objects first"), and every next one was refused ("already holding the white cube")."""
        x, y, top = obj.xyz_robot
        self._tool_pick({"object_id": obj.id})
        try:
            return put_down()
        except ValueError as exc:
            back = ""
            if self.holding:
                try:
                    self._put_down_at(x, y, surface=top - self._held_height)
                    back = f" The {obj.label} was put back where it was."
                except ValueError:
                    back = f" The {obj.label} is still held."
            raise ValueError(str(exc).rstrip(".") + "." + back) from None

    def _look_first(self) -> None:
        """A tool looks at the table itself, if this request hasn't yet, and then works with the objects as seen now
        (the ids stay with their objects from look to look). Refused instead ("Call list_objects first"), the small
        model looked, then replied "the tower is dismantled" without doing it."""
        if not self._listed:
            self._tool_list_objects({})

    # ---- line_up -------------------------------------------------------------------------------------------------
    def _tool_line_up(self, args: dict) -> str:
        """In a row: the slots worked out first (the whole row on free, reachable table, clear of every object),
        then each object put in its slot, in order."""
        self._look_first()
        objs = [self._find_object(i) for i in args.get("object_ids") or []]
        if len(objs) < 2:
            raise ValueError("A row needs at least two objects: give their ids in object_ids.")
        if self.holding:
            raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        order = str(args.get("order") or "given").lower()
        size = lambda o: (self._heights.get(o.label, o.xyz_robot[2]),                      # noqa: E731
                          self._footprint_of(o)[0] * self._footprint_of(o)[1])
        if "small" in order:
            objs.sort(key=size)
        elif "larg" in order or "big" in order:
            objs.sort(key=size, reverse=True)
        gap = to_mm(args.get("gap_mm"), ROW_GAP_MM)
        along = str(args.get("along") or "left_to_right").lower()
        ux, uy = (1.0, 0.0) if ("far" in along or "front" in along) else (0.0, -1.0)   # robot's left -> right
        direction = math.degrees(math.atan2(uy, ux))
        from app.llm.tools import _width_along
        widths = [_width_along(o, self._footprint_of(o), direction) for o in objs]
        total = sum(widths) + gap * (len(objs) - 1)
        offsets, at = [], -total / 2.0
        for w in widths:
            offsets.append(at + w / 2.0)
            at += w + gap
        everything = {o.id for o in self._last_scene}
        where = str(args.get("where") or "center").lower()
        xs = [o.xyz_robot[0] for o in self._last_scene] or [200.0]
        ys = [o.xyz_robot[1] for o in self._last_scene] or [0.0]
        middle = (sum(xs) / len(xs), sum(ys) / len(ys))
        rank = {"left": lambda c: -c[1], "right": lambda c: c[1], "near_base": lambda c: math.hypot(*c),
                "far": lambda c: -math.hypot(*c)}.get(where.replace(" ", "_"),
                                                     lambda c: math.hypot(c[0] - middle[0], c[1] - middle[1]))
        bounds = getattr(self.robot, "bounds", None) or {"x": [100.0, 300.0], "y": [-300.0, 300.0]}
        centres = [(float(x), float(y)) for x in range(int(bounds["x"][0]), int(bounds["x"][1]) + 1, 10)
                   for y in range(int(bounds["y"][0]), int(bounds["y"][1]) + 1, 10)]
        centres.sort(key=rank)
        from app import robots
        from app.calibration.guidance import MIN_X_MM
        from app.hardware.interfaces import Pose
        r_min = robots.active().min_radius_mm + 10.0     # nearer the base the arm can't reach down to the table
        chosen = None
        for cx, cy in centres:
            slots = [(cx + ux * off, cy + uy * off) for off in offsets]
            ok = True
            for (sx, sy), o in zip(slots, objs):
                fp = self._footprint_of(o)
                if sx < MIN_X_MM or math.hypot(sx, sy) < r_min:
                    ok = False
                    break
                # clear of everything where it stands now, the row's own too (they are moved one by one), with room
                # for the open fingers (kept to the row's own gap: the camera's view leaves less table to choose from)
                if self._spot_taken(sx, sy, fp, {o.id}, max(SPOT_GAP_MM, FINGER_ROOM_MM)) is not None:
                    ok = False
                    break
                z = self._surface_at(sx, sy) + self._heights.get(o.label, 20.0) + 3.0
                if not (self._can_reach(Pose(sx, sy, z)) and self._can_reach(Pose(sx, sy, z + 40.0))):
                    ok = False
                    break
                if self._in_view(sx, sy, z) is False:      # where the camera will see it again
                    ok = False
                    break
            if ok:
                chosen = slots
                break
        if chosen is None:
            raise ValueError(f"There's no free stretch of table for a row {total:.0f} mm long that the arm can reach "
                             "and the camera can see. Tell the user (fewer objects, or a smaller gap).")
        done = []
        for (sx, sy), o in zip(chosen, objs):
            try:
                self._carry(o, lambda sx=sx, sy=sy: self._put_down_at(sx, sy))
            except ValueError as exc:
                raise ValueError(f"Lined up {len(done)} of {len(objs)}" + (f" ({', '.join(done)})" if done else "")
                                 + f"; stopped at the {o.label}: {exc}") from None
            done.append(o.label)
        words = "left to right" if uy else "near to far"
        return (f"Lined up {len(done)} in a row, {words}: " + ", ".join(done)
                + f", {gap:.0f} mm apart, from ({chosen[0][0]:.0f}, {chosen[0][1]:.0f}) to "
                  f"({chosen[-1][0]:.0f}, {chosen[-1][1]:.0f}) mm.")

    # ---- move_object ---------------------------------------------------------------------------------------------
    def _tool_move_object(self, args: dict) -> str:
        self._look_first()
        obj = self._find_object(args["object_id"])
        if self.holding and self.holding != obj.label:
            raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        distance = to_mm(args.get("distance_mm"), 20.0)
        word = str(args.get("direction") or "").lower().replace(" ", "_")
        x, y = obj.xyz_robot[0], obj.xyz_robot[1]
        dx, dy = _direction(word, x, y)
        tx, ty = x + dx * distance, y + dy * distance
        taken = self._spot_taken(tx, ty, self._footprint_of(obj), {obj.id})
        if taken:
            raise ValueError(f"({tx:.0f}, {ty:.0f}) is taken by {taken}: the {obj.label} can't go {distance:.0f} mm "
                             f"{word.replace('_', ' ')}. Tell the user.")
        if self.holding:
            self._put_down_at(tx, ty)
        else:
            self._carry(obj, lambda: self._put_down_at(tx, ty))
        return (f"Moved the {obj.label} {distance:.0f} mm {word.replace('_', ' ')}, to ({tx:.0f}, {ty:.0f}) mm, and put "
                f"it down there: nothing is held now.")

    # ---- drop -----------------------------------------------------------------------------------------------------
    def _tool_drop(self, args: dict) -> str:
        """Let the object fall from a height: picked first unless held, moved if asked, let go height_mm up. There was
        no tool for it: "lift it 40 mm, move it 40 mm nearer the robot, and let it drop" picked the cube, then asked
        for it by its id (refused: what is held isn't listed) until the run ended with it in the gripper (study 3,
        S-20)."""
        from app.llm.tools import DROP_MAX_MM
        self._look_first()
        held = self._held_obj
        if self.holding and held is not None and str(args["object_id"]) in (held.id, held.label):
            obj = held
        else:
            obj = self._find_object(args["object_id"])
            if self.holding and self.holding != obj.label:
                raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        height = min(max(to_mm(args.get("height_mm"), DROP_HEIGHT_MM), 0.0), DROP_MAX_MM)
        if args.get("beside_id"):                      # (beside another: place_beside lets go drop_mm up)
            if not self.holding:
                self._tool_pick({"object_id": obj.id})
            beside = {"object_id": args["beside_id"], "drop_mm": height}
            beside.update({k: args[k] for k in ("side", "gap_mm") if args.get(k) is not None})
            return self._tool_place_beside(beside)
        distance = to_mm(args.get("distance_mm"), 0.0)
        word = str(args.get("direction") or "").lower().replace(" ", "_")
        x, y = obj.xyz_robot[0], obj.xyz_robot[1]
        dx, dy = _direction(word, x, y) if distance else (0.0, 0.0)
        tx, ty = x + dx * distance, y + dy * distance
        taken = self._spot_taken(tx, ty, self._footprint_of(obj), {obj.id})
        if taken:
            raise ValueError(f"({tx:.0f}, {ty:.0f}) is taken by {taken}: the {obj.label} would land on it. Tell the "
                             "user.")
        if not self.holding:
            self._tool_pick({"object_id": obj.id})
        surface = self._surface_at(tx, ty)
        # near the base the arm can't come down from as high (the rear arm would lean back past upright): let go as
        # high as it can there, not refuse a spot a put-down reaches (this round's twin, S-20: 40 mm up at 152 mm out)
        asked = height
        while height > 0.0 and self._approach_z(tx, ty, self._release_z(surface) + height) is None:
            height = max(0.0, height - 5.0)
        # (the release height plus the drop: _release_z lets go its own small gap up)
        self._tool_place({"x": tx, "y": ty, "z": self._release_z(surface) + height,
                          "top_z": surface + self._held_height})
        self._placed_angles.pop(obj.id, None)          # (it may turn as it lands: its turn isn't known now)
        moved = f", {distance:.0f} mm {word.replace('_', ' ')} of where it was," if distance else ""
        lower = (f" (as high as the arm reaches there, near its base: {asked:.0f} mm was asked)" if height < asked
                 else "")
        return (f"Dropped the {obj.label} from {height:.0f} mm above the table{lower}{moved} at ({tx:.0f}, {ty:.0f}) "
                "mm: nothing is held now. It may have bounced; list_objects shows where it landed.")

    # ---- take_apart / empty_place --------------------------------------------------------------------------------
    def _tool_take_apart(self, args: dict) -> str:
        self._look_first()
        obj = self._find_object(args["object_id"])
        if self.holding:
            raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        pile = self._pile_of(obj)                     # labels, bottom to top
        if len(pile) < 2:
            return f"The {obj.label} isn't in a pile: there is nothing to take apart."
        seen = [label for label in pile if any(o.label == label for o in self._last_scene)]
        base = next(o for o in self._last_scene if o.label == seen[0])     # (one we stacked on may be hidden)
        moved = []
        for label in reversed(seen[1:]):
            top = next((o for o in self._last_scene if o.label == label), None)
            if top is None:
                continue
            try:
                moved.append(self._moved_to_free_spot_near(top, base.xyz_robot[0], base.xyz_robot[1]))
            except ValueError as exc:
                raise ValueError(f"Took {len(moved)} of {len(seen) - 1} off the pile" + (": " + "; ".join(moved) if moved
                                 else "") + f"; stopped at the {label}: {exc}") from None
        return "Took the pile apart, top first: " + "; ".join(moved) + f". The {base.label} stays where it is."

    def _tool_empty_place(self, args: dict) -> str:
        name = str(args.get("place_name") or "").strip().lower()
        places = self._saved_places()
        if name not in places:
            raise ValueError(f"No saved place called '{name}'. Available: {sorted(places) or 'none'}.")
        if self.holding:
            raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        self._look_first()
        inside = sorted((o for o in self._last_scene if self._inside_place(o, name)), key=lambda o: -o.xyz_robot[2])
        if not inside:
            return f"The {name} is already empty."
        place, moved, left = places[name], [], []
        for o in inside:
            try:
                moved.append(self._moved_to_free_spot_near(o, place.x, place.y))
            except ValueError as exc:
                left.append(f"the {o.label} ({str(exc).rstrip('.')})")
        text = f"Took {len(moved)} of {len(inside)} out of the {name}" + (": " + "; ".join(moved) if moved else "") + "."
        return text + (" Left in it: " + "; ".join(left) + "." if left else "")

    # ---- place_between / swap ------------------------------------------------------------------------------------
    def _tool_place_between(self, args: dict) -> str:
        if not self.holding:
            raise ValueError("Nothing is being held: pick the object to put between them first.")
        self._look_first()
        a, b = self._find_object(args["object_id_a"]), self._find_object(args["object_id_b"])
        from app.llm.tools import _width_along
        direction = math.degrees(math.atan2(b.xyz_robot[1] - a.xyz_robot[1], b.xyz_robot[0] - a.xyz_robot[0]))
        gap = (math.dist(a.xyz_robot[:2], b.xyz_robot[:2]) - _width_along(a, self._footprint_of(a), direction) / 2
               - _width_along(b, self._footprint_of(b), direction) / 2)
        held = self._footprint_of(self._held_obj)
        need = min(_width_along(self._held_obj, held, direction), _width_along(self._held_obj, held, direction + 90))
        if gap < need + 2 * SPOT_GAP_MM:
            raise ValueError(f"There's only {gap:.0f} mm between the {a.label} and the {b.label}, and the {self.holding} "
                             f"needs about {need + 2 * SPOT_GAP_MM:.0f}. Tell the user (move them apart first).")
        x, y = (a.xyz_robot[0] + b.xyz_robot[0]) / 2.0, (a.xyz_robot[1] + b.xyz_robot[1]) / 2.0
        mine = self._held_obj.id if self._held_obj is not None else ""
        taken = self._spot_taken(x, y, held, {a.id, b.id, mine})
        if taken:
            raise ValueError(f"The middle between the {a.label} and the {b.label} is taken by {taken}. Tell the user.")
        held_label = self.holding
        self._put_down_at(x, y)
        return f"Put the {held_label} between the {a.label} and the {b.label}, at ({x:.0f}, {y:.0f}) mm."

    def _tool_swap(self, args: dict) -> str:
        self._look_first()
        a, b = self._find_object(args["object_id_a"]), self._find_object(args["object_id_b"])
        if self.holding:
            raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        for o in (a, b):
            cover = self._covered_by(o)
            if cover is not None:
                raise ValueError(f"The {o.label} has the {cover.label} on top of it: move that first, then swap.")
        (ax, ay, _), (bx, by, _) = a.xyz_robot, b.xyz_robot
        # each takes the other's place at its level: one standing on a cube is swapped onto that cube (study 4, S-09:
        # "swap the blue and red cubes" with blue on green -- red was put down on the table where blue stood, the
        # fingers would have hit the green cube, and the swap was refused half done)
        on_a, on_b = self._stands_on(a), self._stands_on(b)
        if {getattr(on_a, "id", None), getattr(on_b, "id", None)} & {a.id, b.id}:
            on_a = on_b = None                                 # (one on the other: as before)
        tx, ty = self._free_spot_near(ax, ay)                  # out of the way for a moment
        first: dict = {}

        def aside():
            # (a's turn as its first pick read it: picked again from the side, it is put down at that, not at the
            # second reading -- each carry turned a cube a few degrees more, study 3, S-06 39 -> 55 -> 64)
            held = getattr(self._held_obj, "footprint", None)
            first["angle"] = float(held[2]) if held is not None else None
            return self._put_down_at(tx, ty)
        try:
            self._carry(a, aside)
        except ValueError as exc:
            # (refused before anything moved, the model went on with only "call list_objects": it picked and turned
            # the cube, never swapped them, and said they were swapped -- study 3, S-10)
            if self.holding:
                raise
            why = str(exc).split(" Call list_objects")[0].rstrip(".")     # (its own advice replaced by this one)
            raise ValueError(f"Not swapped, nothing moved: {why}. Call list_objects, then swap "
                             "again with the ids it gives.") from None
        b_moved = False
        try:
            self._carry(b, lambda: self._put_down_in_place_of(ax, ay, on_a))
            b_moved = True
            a = self._seen_again(a, tx, ty)
            self._carry(a, lambda: self._put_down_in_place_of(bx, by, on_b, angle=first.get("angle")))
        except ValueError as exc:
            where = f"The {a.label} is at ({tx:.0f}, {ty:.0f}) for now" + (
                f", the {b.label} at ({ax:.0f}, {ay:.0f}), where the {a.label} was" if b_moved else "")
            raise ValueError(f"Not swapped: {str(exc).rstrip('.')}. {where}: tell the user.") from None
        # each with its id: this round's E3 (the realistic twin, S-09), "then turn the red cube" after the swap turned
        # obj_32, the green one
        on = lambda under: f" on the {under.label}" if under is not None else ""  # noqa: E731
        return f"Swapped the {a.label} and the {b.label}: the {a.label} ({a.id}) is now at ({bx:.0f}, {by:.0f}){on(on_b)}, " \
               f"the {b.label} ({b.id}) at ({ax:.0f}, {ay:.0f}){on(on_a)} mm."

    def _stands_on(self, obj) -> Optional[SceneObject]:
        """The object `obj` stands on (seen under it, its top at least half a cube lower), or None: the table."""
        under = self._top_under(obj.xyz_robot[0], obj.xyz_robot[1], self._footprint_of(obj), {obj.id})
        if under is None or under.xyz_robot[2] > obj.xyz_robot[2] - STANDS_ON_MM:
            return None
        return under

    def _put_down_in_place_of(self, x: float, y: float, under: Optional[SceneObject],
                              angle: Optional[float] = None) -> str:
        """The held object down where another stood: on the table at (x, y), or on `under` (what that one stood on),
        squared on it."""
        if under is None:
            return self._put_down_at(x, y, angle=angle)
        held = self.holding
        ux, uy, top = under.xyz_robot
        result = self._put_down_at(ux, uy, angle=angle, surface=top)
        self._under[under.label] = held      # (remembered, as place_on does: it may be hidden from the camera later)
        return result

    def _seen_again(self, obj, x: float, y: float):
        """`obj`, just put down at (x, y), in the latest look: by its id, or else the one of its colour seen nearest
        there. A look between (a pick's second look at an unsteady cube) gives it a new id: study 2, S-06_Run2,
        S-08_Run2, S-09_Run2, a swap stopped half done -- "Unknown object_id" for the cube it had just put down."""
        try:
            return self._find_object(obj.id)
        except ValueError:
            colour = obj.label.split()[0]
            near = [o for o in self._last_scene if o.label.split()[0] == colour
                    and math.dist(o.xyz_robot[:2], (x, y)) <= SEEN_AGAIN_MM]
            if not near:
                raise ValueError(f"The {obj.label} isn't seen where it was put down, at ({x:.0f}, {y:.0f})") from None
            return min(near, key=lambda o: math.dist(o.xyz_robot[:2], (x, y)))

    # ---- put_back ------------------------------------------------------------------------------------------------
    def _note_start_of_prompt(self) -> None:
        """Called at each prompt's first look: where everything was then (for the NEXT prompt's put_back)."""
        if getattr(self, "_this_prompt_start", None) is None:
            self._this_prompt_start = {o.id: (o.label, tuple(o.xyz_robot)) for o in self._last_scene}
            self._prompt_angles = {o.id: float(o.footprint[2]) for o in self._last_scene
                                   if getattr(o, "footprint", None) is not None}

    def _tool_put_back(self, args: dict) -> str:
        before = getattr(self, "_last_prompt_start", None)
        if not before:
            return "There's nothing to put back: no earlier prompt has been seen. Tell the user."
        if self.holding:
            raise ValueError(f"Already holding the {self.holding}. Put it down first.")
        self._look_first()
        wanted = set(args.get("object_ids") or [])
        now = {o.id: o for o in self._last_scene}
        todo = []
        for oid, (label, xyz) in before.items():
            o = now.get(oid) or next((v for v in now.values() if v.label == label), None)
            if o is None or (wanted and o.id not in wanted):
                continue
            if math.dist(o.xyz_robot[:2], xyz[:2]) > MOVED_MM or abs(o.xyz_robot[2] - xyz[2]) > MOVED_MM:
                todo.append((o, xyz))
        if not todo:
            return "Everything is where it was when the last prompt began: nothing to put back."
        todo.sort(key=lambda item: item[1][2])          # lowest spot first: a pile is rebuilt from the bottom
        done, left = [], []
        for _ in range(len(todo)):                       # a spot freed by one put back lets another go back
            for item in list(todo):
                o, (x, y, z) = item
                current = next((v for v in self._last_scene if v.id == o.id), o)
                if self._covered_by(current) is not None:
                    continue                             # what is on it now goes back first
                below = self._top_under(x, y, self._footprint_of(current), {current.id})
                surface = None
                if below is not None:
                    if abs(below.xyz_robot[2] + self._heights.get(current.label, 20.0) - z) > 8.0:
                        continue                         # something else stands there now
                    surface = below.xyz_robot[2]         # it stood on this one
                try:
                    self._carry(current, lambda x=x, y=y, surface=surface: self._put_down_at(x, y, surface=surface))
                    done.append(f"the {current.label} to ({x:.0f}, {y:.0f})"
                                + (f", on the {below.label}" if below is not None else ""))
                except ValueError as exc:
                    left.append(f"the {current.label} ({str(exc).rstrip('.')})")
                todo.remove(item)
        left += [f"the {o.label} (its spot is taken)" for o, _ in todo]
        text = (f"Done: put back {len(done)} where they were before the last request" + (": " + "; ".join(done)
                if done else "") + ".")
        return text + (" Not put back: " + "; ".join(left) + "." if left else "")

    # ---- set_speed -----------------------------------------------------------------------------------------------
    def _tool_set_speed(self, args: dict) -> str:
        word = str(args.get("speed") or "normal").lower()
        normal = getattr(self, "_speed_at_start", None) or getattr(self.robot, "max_speed", None)
        if normal is None:
            return "The arm's speed can't be changed here."
        self._speed_at_start = normal
        speed = normal * SLOW_SHARE if any(w in word for w in ("slow", "careful", "gentle")) else normal
        setter = getattr(self.robot, "set_speed", None)
        if setter is not None:
            try:
                setter(speed)
            except RuntimeError as exc:
                raise ValueError(f"The arm's speed could not be changed: {exc}") from None
        return f"The arm moves at {speed:.0f} mm/s for the rest of this prompt" + (
            " (slowly)." if speed < normal else ".")

    def _restore_speed(self) -> None:
        normal = getattr(self, "_speed_at_start", None)
        setter = getattr(self.robot, "set_speed", None)
        if normal is not None and setter is not None:
            try:
                setter(normal)
            except Exception:  # noqa: BLE001 - a speed not restored is no reason to fail the prompt's end
                pass
        self._speed_at_start = None

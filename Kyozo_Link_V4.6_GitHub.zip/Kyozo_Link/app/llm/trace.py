"""The record behind the Model tab: for one prompt, every model turn and what the app did with it.

Three kinds of information, and the tab says which is which:
  * measured   -- Ollama's own figures (tokens, timings, why it stopped) and the model's exact answer;
  * app        -- worked out by the app: how the prompt reads, which objects the words match, which actions
                  were possible, the checks on each answer, the end checks. Rules of thumb, shown as such;
  * reasoning  -- the model's own explanation, only when "Show the model's reasoning" is on.
Nothing here guesses at what goes on inside the model.
"""
from __future__ import annotations

import ast
import copy
import json
import math
import re
import time
from typing import Optional

from app.llm.recording import limit_margin

# the rule in the model's instructions that each action follows (see SYSTEM_PROMPT in agent.py)
RULES = {
    "list_objects": "the app looks first (V4.3); again only after a failed step or a change",
    "pick": "to move an object, start with pick(object)",
    "place_at": "\"put A in/at the tray\" = pick(A), then place_at(\"tray\")",
    "put_all_in": "several objects into one tray or bin: one put_all_in(place, all their ids); it plans where each goes",
    "place_on": "\"put A on B\" = pick(A), then place_on(B); a tower: place_on(the one put down last)",
    "place_beside": "beside is not on top: pick(A), then place_beside(B, side, gap_mm)",
    "place_free": "an empty part of the table: place_free(where), never made-up numbers",
    "place": "put it down at a position",
    "move_above": "to go near an object: move_above(object)",
    "move_to": "never invent coordinates: only for positions the user gives",
    "home": "go to the home position",
    "open_gripper": "open the gripper",
    "close_gripper": "close the gripper",
    "done": "after the last step, in the same answer, when they finish the whole request (V4.3)",
}
PLACE_TOOLS = {"place_at", "place_on", "place_beside", "place_free", "place"}
NEEDS_EMPTY_GRIPPER = {"pick", "put_all_in"}
LOOK_ONLY = {"list_objects"}
COLOURS = ("red", "blue", "green", "yellow", "purple", "orange", "grey", "gray", "white", "black", "brown", "pink",
           "teal")
COLOUR_ALIASES = {"gray": "grey", "wooden": "brown", "wood": "brown", "dark": "black"}
SIZES = ("small", "smaller", "large", "larger", "big", "bigger", "little", "tall", "short")
OBJECT_KINDS = {"cube": "cube", "cubes": "cube", "block": "cube", "blocks": "cube", "box": "box", "boxes": "box",
                "bin": "box", "tray": "box", "container": "box", "object": "any", "one": "any", "it": "held",
                "thing": "any", "ball": "ball", "balls": "ball", "sphere": "ball", "cylinder": "cylinder",
                "can": "cylinder", "tube": "cylinder", "bar": "bar", "stick": "bar", "pen": "bar", "pencil": "bar", "rod": "bar", "bottle": "cylinder",
                "disc": "disc", "disk": "disc", "coin": "disc", "piece": "flat"}
_NOUN = r"(?:(?:the|a|an)\s+)?((?:(?:%s|%s|colou?red|\w+-colou?red)\s+)*(?:%s))" % (
    "|".join(COLOURS + tuple(COLOUR_ALIASES)), "|".join(SIZES), "|".join(sorted(OBJECT_KINDS, key=len, reverse=True)))
_DESTINATIONS = [("beside", r"\b(?:beside|next to|to the (?:left|right) of|on the (?:left|right) side of|"
                            r"in front of|behind|\d+\s*mm from)\b"),
                 ("on top", r"\b(?:on top of|onto|on)\b"),
                 ("into", r"\b(?:into|inside|in|at)\b")]


# requests one tool does, by their words: (pattern, the task in words, the tool)
_ONE_CALL_TASKS = [
    # "lift it 40 mm, move it 40 mm nearer the robot, and let it drop" (before "move by": it moves it too)
    (r"\blet (?:it|them|the \w+(?: \w+)?) (?:drop|fall)\b|\bdrop (?:it|the \w+(?: \w+)?) from\b", "drop an object",
     "drop"),
    # "move the red cube 5 cm to the left" (not "to the left OF the blue cube": that is beside)
    (r"\b(?:move|push|shift|slide|nudge)\b(?=.*(?:\d\s*(?:mm|cm|millimet\w*|centimet\w*|inch\w*|in)\b|\ba (?:bit|little)\b))"
     r".*\b(?:left|right|forward|back|backwards|closer|towards|away)\b(?!\s+(?:of|from)\b)",
     "move by a distance", "move_object"),
    (r"\bundo\b|\b(?:put|move)\b.*\bback\b", "put things back", "put_back"),
    (r"\b(?:do|try) (?:it|that) again\b|\bsame again\b", "repeat the previous request", "…"),
    (r"\b(?:take|pull|break)\b.*\bapart\b|\bunstack\b|\bdismantle\b", "take a pile apart", "take_apart"),
    (r"\bempty (?:the|this|that)\b|\b(?:everything|all|them)\b.*\bout of\b", "empty a place", "empty_place"),
    (r"\bout of\b", "take out of a place", "pick, place_free"),
    (r"\bswap\b|\bswitch places\b|\bexchange\b", "swap two objects", "swap"),
    (r"\bbetween\b", "put between two objects", "place_between"),
    (r"\bline (?:up|them up)\b|\bin a (?:row|line)\b|\barrange\b(?!.*\b(?:in|into)\s+(?:the\s+)?\w*\s*(?:tray|bins?)\b)",
     "arrange in a row", "line_up"),
]


def _now() -> str:
    return time.strftime("%H:%M:%S")


def _carried_out(call: dict) -> bool:
    """The app did the step: not refused, and not stopped (by you, E-STOP, or not run after a failed step)."""
    app = call.get("app") or {}
    return bool(app) and not app.get("refused") and not app.get("stopped")


def _estimate_tokens(text: str) -> int:
    return max(1, round(len(text) / 4))        # about four characters a token: an estimate, shown as one


def _parse(result: str) -> Optional[dict]:
    try:
        value = ast.literal_eval(result)
        return value if isinstance(value, dict) else None
    except (ValueError, SyntaxError):
        return None


# ---- the app's reading of the prompt ------------------------------------------------------------------------------
def understand(prompt: str) -> dict:
    """What the request looks like: the kind of task, the object to move and where to. A rule of thumb, shown as
    the app's reading (the model reads the prompt its own way)."""
    p = " " + prompt.lower().strip() + " "
    reading = {"task": "other", "object": None, "destination": None, "expected": [], "notes": []}
    if re.search(r"what do you see|look at|list|which objects|what is on", p):
        reading.update(task="look at the table", expected=["list_objects"])
        return reading
    if re.search(r"\bhome\b", p):
        reading.update(task="go home", expected=["home"])
        return reading
    for pattern, task, tool in _ONE_CALL_TASKS:
        if re.search(pattern, p):
            # (before the tower: "take the tower apart" is no tower to build)
            reading.update(task=task, expected=["list_objects", tool])
            return reading
    if re.search(r"\boff (?:the |a |that )?(?:top of (?:the )?)?(?:tower|pile|stack)\b", p):
        # "take the blue cube off the tower and put it to the left": a cube taken off, no tower to build (S-18 in the
        # twin, 2026-10-24: read as one, the goal check said "not done: blue left out" and the model put it back)
        reading.update(task="take off a pile", expected=["list_objects", "pick", "place_…"])
    elif re.search(r"\btower\b|\bstack (?:all|them|every)", p):
        reading.update(task="build a tower", expected=["list_objects", "pick", "place_at or place_on", "…"])
    elif re.search(r"\bsort\b|\bbins?\b", p) and re.search(r"\ball\b|\bcubes\b|colours|colors|sizes", p):
        reading.update(task="sort several objects into places", expected=["list_objects", "pick", "place_at", "…"])
    destination_kind, split_at = None, None
    for kind, pattern in _DESTINATIONS:
        match = re.search(pattern, p)
        if match and (split_at is None or match.start() < split_at):
            destination_kind, split_at = kind, match.start()
    head = p[:split_at] if split_at is not None else p
    tail = p[split_at:] if split_at is not None else ""
    obj = re.search(_NOUN, head)
    if obj:
        reading["object"] = obj.group(1).strip()
    if tail:
        dest = re.search(_NOUN, tail)
        reading["destination"] = dest.group(1).strip() if dest else tail.strip()
    if reading["task"] == "other":
        if destination_kind == "beside":
            reading.update(task="put beside another object", expected=["list_objects", "pick", "place_beside"])
        elif destination_kind == "on top" and reading["destination"] and OBJECT_KINDS.get(
                reading["destination"].split()[-1]) in ("cube", "any"):
            reading.update(task="stack on another object", expected=["list_objects", "pick", "place_on"])
        elif destination_kind == "into" and reading["destination"] and re.search(
                r"\b(?:everything|all|both|these|every|each)\b|,|\band\b", head):
            reading.update(task="put several into a place", expected=["list_objects", "put_all_in"])
        elif destination_kind in ("into", "on top") and reading["destination"]:
            reading.update(task="put into a place", expected=["list_objects", "pick", "place_at"])
        elif re.search(r"\b(?:pick|grab|lift|hold)\b", p):
            reading.update(task="pick up", expected=["list_objects", "pick"])
    if destination_kind == "into" and re.search(r"\b(?:pick|take|get)\b", p) and reading["destination"]:
        reading["notes"].append(f"\"{tail.strip()}\" could say where the object is now, or where it should go")
    return reading


# ---- matching the prompt's words to what's on the table -------------------------------------------------------------------
def _words(phrase: str) -> list[str]:
    return [w for w in re.split(r"[\s-]+", phrase.lower()) if w and w not in ("the", "a", "an", "colored", "coloured")]


def match_phrase(phrase: str, objects: list[dict], places: list[str], role: str) -> dict:
    """Each candidate on the table for `phrase`, judged by name, colour and kind. `role`: "object" (the thing
    to move) or "destination"."""
    words = [COLOUR_ALIASES.get(w, w) for w in _words(phrase)]
    colours = [w for w in words if w in COLOURS]
    kind_word = next((w for w in reversed(words) if w in OBJECT_KINDS), None)
    kind = OBJECT_KINDS.get(kind_word) if kind_word else None
    rows = []
    candidates = [(o["label"], o.get("id"), "object") for o in objects] + [(name, None, "place") for name in places]
    for label, oid, what in candidates:
        label_words = _words(label)
        label_kind = next((OBJECT_KINDS[w] for w in reversed(label_words) if w in OBJECT_KINDS), "cube")
        label_colours = [w for w in label_words if w in COLOURS]
        exact = " ".join(w for w in words if w not in SIZES) == " ".join(label_words)
        colour = "—" if not colours else ("✓" if all(c in label_colours for c in colours) else "✗")
        if kind in (None, "any", "held") or kind == label_kind:
            kind_fit = "✓"
        elif kind == "box" and label_kind == "cube":
            kind_fit = f"{kind_word} ≠ cube"
        else:
            kind_fit = "✗"
        right_role = (what == "object") == (role == "object")
        if exact and right_role:
            verdict = "exact"
        elif colour != "✗" and kind_fit != "✗" and right_role and (colours or kind not in (None, "any")):
            verdict = "partial"
        else:
            verdict = "no"
        rows.append({"candidate": label + (f" ({oid})" if oid else ""), "name": "✓" if exact else "✗",
                     "colour": colour, "kind": kind_fit, "role": what, "verdict": verdict})
    order = {"exact": 0, "partial": 1, "no": 2}
    rows.sort(key=lambda r: order[r["verdict"]])
    best = rows[0] if rows and rows[0]["verdict"] != "no" else None
    return {"phrase": phrase, "rows": rows, "best": best["candidate"] if best else None,
            "guess": bool(best and best["verdict"] == "partial")}


def options(holding: Optional[str]) -> dict:
    """Which of the actions were possible at that moment (the app refuses the rest)."""
    closed = PLACE_TOOLS if not holding else NEEDS_EMPTY_GRIPPER
    why = "nothing is held" if not holding else f"already holding the {holding}"
    all_tools = list(RULES)
    open_tools = [t for t in all_tools if t not in closed]
    return {"open": open_tools, "closed": sorted(closed), "why_closed": why, "total": len(all_tools)}


# ---- one prompt ------------------------------------------------------------------------------------------------------------
class PromptTrace:
    """Built up by the agent as the prompt runs; `data` is plain lists and dicts, ready to show or save."""

    def __init__(self, prompt: str, model: str, temperature: float, reasoning: bool, max_steps: int,
                 setup: Optional[dict] = None, model_info: Optional[dict] = None,
                 system_prompt: str = "", tools: Optional[list] = None):
        self.data = {
            "prompt": prompt, "started": time.strftime("%Y-%m-%d %H:%M:%S"), "model": model,
            "temperature": temperature, "reasoning": reasoning, "max_steps": max_steps,
            "setup": dict(setup or {}), "model_info": dict(model_info or {}),
            "understood": understand(prompt), "turns": [], "finished": False,
        }
        self._started = time.monotonic()
        self._fixed_tokens = {"instructions": _estimate_tokens(system_prompt),
                              "actions": _estimate_tokens(json.dumps(tools or [])),
                              "prompt": _estimate_tokens(prompt)}
        self._results: list[tuple[int, str]] = []      # (turn number, what the app replied), in order
        self._objects: list[dict] = []
        self._places: list[str] = []
        self._previous_read = 0

    # -- a model turn ---------------------------------------------------------------------------------------------------
    def model_turn(self, message: dict, stats: dict, seconds: float, holding: Optional[str], state_text: str) -> dict:
        number = len(self.data["turns"]) + 1
        stats = dict(stats or {})
        read = stats.get("tokens_read")
        earlier = sum(_estimate_tokens(r) + 12 for _, r in self._results)
        receive = {
            "tokens_read": read, "new": (read - self._previous_read) if read and self._previous_read else None,
            "parts_estimated": {**self._fixed_tokens, "state": _estimate_tokens(state_text), "earlier turns": earlier},
            "memory_limit": self.data["model_info"].get("memory_limit"),
        }
        if read:
            self._previous_read = read
        calls = []
        for call in message.get("tool_calls") or []:
            name = call["function"]["name"]
            raw = call["function"].get("arguments", {})
            args = raw if isinstance(raw, dict) else _safe_json(raw)
            calls.append(self._analyse_call(number, name, args, raw, holding))
        turn = {
            "number": number, "time": _now(), "decided_s": round(seconds, 2), "stats": stats, "receive": receive,
            "reasoning": (message.get("thinking") or "").strip() or None,
            "reply": None if calls else (message.get("content") or "").strip(),
            "raw": message.get("tool_calls") or message.get("content"),
            "calls": calls, "progress": self._progress(),
        }
        if not calls:
            turn["options"] = "another action, or stop and reply"
        self.data["turns"].append(turn)
        return turn

    def _analyse_call(self, turn_no: int, name: str, args, raw, holding: Optional[str]) -> dict:
        from app.llm.tools import TOOL_SCHEMAS    # (here, not at the top: tools.py imports this module's neighbours)
        schema = next((s["function"] for s in TOOL_SCHEMAS if s["function"]["name"] == name), None)
        understood = self.data["understood"]
        matches = []
        if self._objects or self._places:
            if understood.get("object") and name in ("pick", "move_above"):
                matches.append(match_phrase(understood["object"], self._objects, self._places, "object"))
            if understood.get("destination") and name in PLACE_TOOLS:
                matches.append(match_phrase(understood["destination"], self._objects, self._places, "destination"))
        fills = []
        for key, value in (args.items() if isinstance(args, dict) else []):
            fills.append({"field": key, "value": value, "from": self._where_from(key, value)})
        seen_ids = {o.get("id") for o in self._objects}
        checks = [
            ("well-formed answer", isinstance(args, dict), "arguments are a JSON object"),
            ("action exists", schema is not None, name),
            ("required fields", schema is not None and all(k in (args or {}) for k in
                                                          schema.get("parameters", {}).get("required", [])),
             ", ".join(schema.get("parameters", {}).get("required", [])) if schema else "—"),
            ("field types", schema is not None and _types_ok(schema, args or {}), "as the action expects"),
        ]
        if isinstance(args, dict) and "object_id" in args:
            checks.append(("object was seen", args["object_id"] in seen_ids,
                           f"{args['object_id']} " + ("was listed" if args["object_id"] in seen_ids else "was never listed")))
        if name in NEEDS_EMPTY_GRIPPER:
            checks.append(("gripper free", not holding, "holding nothing" if not holding else f"holding the {holding}"))
        if name in PLACE_TOOLS:
            checks.append(("holding something", bool(holding), f"holding the {holding}" if holding else "holding nothing"))
        invented = name in ("move_to", "place") and not re.search(r"\d", self.data["prompt"])
        checks.append(("no made-up coordinates", not invented,
                       "coordinates written by the model" if invented else "ids and names only"))
        checks.append(("follows a rule", name in RULES, RULES.get(name, "no rule for this")))
        return {
            "name": name, "args": args, "raw_args": raw, "rule": RULES.get(name),
            "fits_task": _fits(understood, name), "matches": matches, "fills": fills,
            "options": options(holding),
            "holding_before": holding,
            "checks": [{"check": c, "ok": bool(ok), "detail": d} for c, ok, d in checks],
            "app": None,
        }

    def _where_from(self, key: str, value) -> str:
        if key == "object_id":
            for number, result in reversed(self._results):
                if f"'{value}'" in result or f"({value})" in result:
                    return f"the app's reply in turn {number}"
            return "not in any reply: invented?"
        if key == "place_name":
            return "the saved places" if str(value).lower() in self._places else "not a saved place"
        if key in ("x", "y", "z"):
            return "written by the model"
        return "the model"

    def _progress(self) -> list[str]:
        done = []
        for turn in self.data["turns"]:
            for call in turn["calls"]:
                if _carried_out(call):
                    done.append(call["name"])
        return done

    # -- what the app did with it -------------------------------------------------------------------------------------------
    def app_result(self, turn: dict, index: int, result: str, record: Optional[dict], joint_source: str,
                   stopped: str = "") -> None:
        call = turn["calls"][index]
        refused = result.startswith("ERROR")
        record = copy.deepcopy(record or {})
        moves = record.get("moves", [])
        largest = None
        closest = None
        for move in moves:
            before, after = move.get("joints_before"), move.get("joints_after")
            if before and after:
                for joint in before:
                    change = after[joint] - before[joint]
                    if abs(change) >= 0.5 and (largest is None or abs(change) > abs(largest[1])):
                        largest = (joint, round(change, 1))
                for joints in (before, after):
                    joint, margin = limit_margin(joints)
                    if closest is None or margin < closest[1]:
                        closest = (joint, margin, joints[joint])
            if move.get("tightest_on_path") and (closest is None or move["tightest_on_path"][1] < closest[1]):
                closest = (move["tightest_on_path"][0], move["tightest_on_path"][1], None)
        call["app"] = {
            "result": result, "refused": refused, "reason": result.removeprefix("ERROR:").strip() if refused else "",
            "stopped": stopped, "target_from": record.get("target_from"), "safety": record.get("checks", []),
            "moves": moves, "joint_source": joint_source,
            "largest_joint_move": list(largest) if largest else None,
            "closest_to_limit": list(closest) if closest else None,
            "arm_after": record.get("arm_after"), "holding_after": record.get("holding_after"),
            "grip": record.get("grip"), "release": record.get("release"), "packing": record.get("packing"),
            "angle": record.get("angle"),
            "seconds": round(sum(m.get("seconds", 0.0) for m in moves), 2),
        }
        self._results.append((turn["number"], result))
        if call["name"] == "list_objects":
            listed = _parse(result)
            if listed:
                self._objects = listed.get("objects", [])
                self._places = [str(p).lower() for p in listed.get("saved_places", [])]
        call["checks"].append({"check": "accepted by the app", "ok": not refused,
                               "detail": "carried out" if not refused else call["app"]["reason"][:160]})

    # -- the end -------------------------------------------------------------------------------------------------------------------
    def finish(self, final_message: str, executor=None) -> None:
        turns = self.data["turns"]
        calls = [c for t in turns for c in t["calls"]]
        refusals = [c for c in calls if c.get("app") and c["app"]["refused"]]
        recoveries = []
        for i, call in enumerate(calls):
            if call.get("app") and call["app"]["refused"]:
                following = calls[i + 1] if i + 1 < len(calls) else None
                if following is None:
                    what = "gave up and replied"
                elif following["name"] == "list_objects":
                    what = "looked at the table again"
                elif following["name"] == call["name"] and following["args"] != call["args"]:
                    hinted = re.findall(r"obj_\d+", call["app"]["reason"])
                    what = ("followed the hint" if hinted and str((following["args"] or {}).get("object_id")) in hinted
                            else "tried again with different values")
                elif following["name"] == call["name"]:
                    what = "tried exactly the same again"
                else:
                    what = f"did something else: {following['name']}"
                recoveries.append({"refused": f"{call['name']} {_short(call['args'])}", "then": what})
        loops = []
        for a, b in zip(calls, calls[1:]):
            if a["name"] == b["name"] and a["args"] == b["args"] and a["name"] not in LOOK_ONLY:
                loops.append(f"{a['name']} {_short(a['args'])}")
        guesses = [m for c in calls for m in c["matches"] if m["guess"]]
        model_s = sum(t["decided_s"] for t in turns)
        robot_s = sum((c.get("app") or {}).get("seconds", 0.0) for c in calls)
        self.data.update({
            "finished": True, "final_message": final_message, "took_s": round(time.monotonic() - self._started, 1),
            "end": {
                "goal": self._goal_check(calls, executor),
                "reply": self._reply_check(final_message, executor),
                "guesses": list(dict.fromkeys(f"\"{g['phrase']}\" read as the {g['best']}" for g in guesses)),
                "ambiguities": list(self.data["understood"].get("notes", [])),
                "refusals": len(refusals), "recoveries": recoveries, "loops": loops,
                "budget": {"steps": len(calls), "limit": self.data["max_steps"], "model_s": round(model_s, 1),
                           "robot_s": round(robot_s, 1),
                           "tokens_read": sum(t["stats"].get("tokens_read") or 0 for t in turns),
                           "tokens_written": sum(t["stats"].get("tokens_written") or 0 for t in turns)},
                "joints": self._joint_summary(calls),
            },
        })

    def goal_now(self, executor) -> dict:
        """The goal check as things stand, before the run ends (the model says it is done: is it?)."""
        try:
            return self._goal_check([c for t in self.data["turns"] for c in t["calls"]], executor)
        except Exception:  # noqa: BLE001 - a check that can't be made is no reason to stop a prompt
            return {"status": "not checked"}

    def _goal_check(self, calls: list, executor) -> dict:
        goal = self._task_goal(calls, executor)
        turned = self._angle_check(calls)
        if turned and goal.get("status") != "not met":
            return {"status": "not met", "detail": (goal.get("detail", "") + "; " if goal.get("status") == "met"
                                                     else "") + turned}
        if turned:
            goal = dict(goal, detail=goal.get("detail", "") + "; " + turned)
        return goal

    def _angle_check(self, calls: list) -> str:
        """"" if no angle was asked for, or something was turned; else what is missing ("at 45 degrees" was asked,
        and nothing was turned: the model said "the tower is oriented at 45 degrees" all the same)."""
        asked = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:°|deg|degree|degrees)\b", self.data.get("prompt", "").lower())
        if not asked:
            return ""
        done = [c for c in calls if _carried_out(c)]
        turning = [c for c in done if c["name"] == "turn_object"
                   or any(k in (c.get("args") or {}) for k in ("angle_deg", "turn_deg"))]
        return "" if turning else f"{asked.group(1)}° was asked for, and nothing was turned"

    def _task_goal(self, calls: list, executor) -> dict:
        task = self.data["understood"]["task"]
        done = [c for c in calls if _carried_out(c)]
        scene = {o.label: o.xyz_robot for o in getattr(executor, "_last_scene", [])} if executor is not None else {}
        picked = [c for c in done if c["name"] == "pick"]
        moved_label = None
        if picked:
            moved_label = (picked[-1]["app"]["result"].split("Picked up ", 1)[-1].split(" (", 1)[0]).strip()
        if task == "put into a place":
            place = next((c for c in reversed(done) if c["name"] == "place_at"), None)
            if not place or not moved_label or moved_label not in scene:
                return {"status": "not met", "detail": "nothing was put in a place"}
            name = str(place["args"].get("place_name", "")).lower()
            spot = executor._saved_places().get(name) if hasattr(executor, "_saved_places") else None
            where = scene[moved_label]
            if spot is not None and math.hypot(where[0] - spot.x, where[1] - spot.y) <= 45.0:
                return {"status": "met", "detail": f"the {moved_label} is at the {name} ({where[0]:.0f}, {where[1]:.0f})"}
            return {"status": "not met", "detail": f"the {moved_label} is at ({where[0]:.0f}, {where[1]:.0f}), not the {name}"}
        if task == "stack on another object":
            stack = next((c for c in reversed(done) if c["name"] == "place_on"), None)
            if not stack or not moved_label:
                return {"status": "not met", "detail": "nothing was stacked"}
            below = next((o["label"] for o in self._objects if o.get("id") == stack["args"].get("object_id")), None)
            if below in scene and moved_label in scene:
                top, base = scene[moved_label], scene[below]
                if math.hypot(top[0] - base[0], top[1] - base[1]) <= 15.0 and top[2] > base[2] + 10.0:
                    return {"status": "met", "detail": f"the {moved_label} is on the {below}"}
                return {"status": "not met", "detail": f"the {moved_label} is not on top of the {below}"}
        if task == "build a tower":
            return self._tower_check(executor)
        if task == "empty a place":
            return self._emptied_check(executor)
        if task == "take out of a place":
            # "Take the cube out of the tray": picked, and left in the gripper ("The red cube was taken from the tray")
            if not moved_label:
                return {"status": "not met", "detail": "nothing was taken out"}
            if getattr(executor, "holding", None) == moved_label:
                return {"status": "not met", "detail": f"the {moved_label} is still held, not put down"}
            inside = getattr(executor, "_inside_place", None)
            obj = next((o for o in getattr(executor, "_last_scene", []) if o.label == moved_label), None)
            places = executor._saved_places() if hasattr(executor, "_saved_places") else {}
            still = [name for name in places if obj is not None and inside is not None and inside(obj, name)]
            if still:
                return {"status": "not met", "detail": f"the {moved_label} is still in the {still[0]}"}
            return {"status": "met", "detail": f"the {moved_label} is out, on the table"}
        if task == "take a pile apart":
            piles = executor.piles() if hasattr(executor, "piles") else []
            if piles:
                return {"status": "not met", "detail": "still in a pile: " + "; ".join(", ".join(p) for p in piles)}
            return {"status": "met", "detail": "nothing is in a pile"}
        packed = [c for c in done if c["name"] == "put_all_in" and c["app"].get("packing")]
        if packed:
            packing = packed[-1]["app"]["packing"]
            left = [f"the {label} ({why})" for label, why in packing.get("left_out", [])]
            detail = f"{packing.get('done', 0)} put in the {packing.get('place')}"
            if packing.get("stopped"):
                return {"status": "not met", "detail": detail + "; stopped before the rest"}
            return ({"status": "met", "detail": detail} if not left
                    else {"status": "not met", "detail": detail + "; left out: " + ", ".join(left)})
        if task in ("look at the table", "go home"):
            return {"status": "met" if done else "not met", "detail": "done" if done else "nothing was done"}
        return {"status": "not checked", "detail": "no automatic check for this kind of request"}

    def _emptied_check(self, executor) -> dict:
        """"Empty the tray": nothing left in the place the prompt names. (The model replied "I have completed the
        task of emptying the tray" with all three cubes still in it.)"""
        places = executor._saved_places() if hasattr(executor, "_saved_places") else {}
        prompt = self.data["prompt"].lower()
        named = [name for name in places if re.search(r"\b" + re.escape(name) + r"\b", prompt)]
        inside = getattr(executor, "_inside_place", None)
        if not named or inside is None:
            return {"status": "not checked", "detail": "no place of that name to check"}
        left = [f"the {o.label} (in the {name})" for name in named for o in getattr(executor, "_last_scene", [])
                if o.label != getattr(executor, "holding", None) and inside(o, name)]
        if left:
            return {"status": "not met", "detail": "still there: " + ", ".join(left)}
        return {"status": "met", "detail": "the " + " and the ".join(named) + " " + ("is" if len(named) == 1 else "are")
                + " empty"}

    def _tower_check(self, executor) -> dict:
        """The tallest pile against the prompt: every object in it (unless the prompt gives a number), and any
        "the yellow block should be the third" in its place, counted from the bottom."""
        piles = executor.piles() if hasattr(executor, "piles") else []
        on_table = [o.label for o in getattr(executor, "_last_scene", [])]
        if not piles:
            return {"status": "not met", "detail": "no pile was built"}
        pile = max(piles, key=len)
        problems = []
        # the tower the app works out from the request (as the check before build_tower does)
        from app.llm.tower_plan import tower_plan
        everything = on_table + [label for p in piles for label in p if label not in on_table]
        planned, impossible = tower_plan(self.data["prompt"], everything, pile)
        if impossible:
            problems.append(impossible.rstrip("."))
        elif planned is not None:
            left_out = [label for label in planned if label not in pile]
            if left_out:
                problems.append("left out: " + ", ".join(left_out))
            placed = position_claims_of(self.data["prompt"], everything, len(planned))
            for label, place in placed.items():
                if label in pile and place is not None and pile.index(label) != place:
                    problems.append(f"the {label} should be {_place_words(place, len(planned))}, "
                                    f"it is {_place_words(pile.index(label), len(pile))}")
            if pile != planned and not placed:
                problems.append("asked for, bottom to top: " + ", ".join(planned))
        # "a tower inside the tray": its bottom one in the place (the model left it outside, and said "inside")
        prompt = self.data["prompt"].lower()
        places = executor._saved_places() if hasattr(executor, "_saved_places") else {}
        inside = getattr(executor, "_inside_place", None)
        bottom = next((o for o in getattr(executor, "_last_scene", []) if o.label == pile[0]), None)
        for name in places:
            if re.search(r"\b(?:in|into|inside)\s+(?:the\s+)?" + re.escape(name) + r"\b", prompt) and bottom is not None:
                try:
                    if inside is not None and not inside(bottom, name):
                        problems.append(f"the tower is not in the {name}")
                except ValueError:
                    pass
        detail = f"{len(pile)} of {len(on_table)} in the tower (bottom to top: {', '.join(pile)})"
        return {"status": "not met" if problems else "met",
                "detail": detail + ("; " + "; ".join(problems) if problems else "")}

    def _reply_check(self, final_message: str, executor=None) -> dict:
        said = self._results
        supported_text = " ".join(r for _, r in said) + " " + self.data["prompt"]
        numbers = re.findall(r"-?\d+(?:\.\d+)?", final_message or "")
        # a whole number, not part of another: "17 mm" made up passed as given, because an app reply said "170"
        given = set(re.findall(r"-?\d+(?:\.\d+)?", supported_text))
        unsupported = [n for n in numbers if n not in given and n.lstrip("-") not in given]
        wrong = []
        piles = executor.piles() if executor is not None and hasattr(executor, "piles") else []
        if piles and self.data["understood"]["task"] in ("build a tower", "stack on another object"):
            pile = max(piles, key=len)
            for label, place in _order_claims(final_message or "", pile, []):
                if label in pile and pile.index(label) != place:
                    wrong.append(f"says the {label} is {_place_words(place, len(pile))}, "
                                 f"it is {_place_words(pile.index(label), len(pile))}")
        problems = (["numbers no app reply gave: " + ", ".join(unsupported)] if unsupported else []) + wrong
        return {"ok": not problems,
                "detail": "; ".join(problems) if problems else "every number it gives comes from an app reply"}

    def _joint_summary(self, calls: list) -> dict:
        moves = [m for c in calls for m in ((c.get("app") or {}).get("moves") or []) if m["kind"] == "move"]
        closest = None
        for c in calls:
            near = (c.get("app") or {}).get("closest_to_limit")
            if near and (closest is None or near[1] < closest[1]):
                closest = near
        return {"moves": len(moves), "closest": closest}

    def snapshot(self) -> dict:
        return copy.deepcopy(self.data)


_ORDINALS = {"first": 0, "1st": 0, "second": 1, "2nd": 1, "third": 2, "3rd": 2, "fourth": 3, "4th": 3,
             "fifth": 4, "5th": 4, "bottom": 0}
_ORDER_CLAIM = re.compile(r"\b(" + "|".join(COLOURS) + r")\s+(?:cube|block|box|one)\b[^.,;]*?"
                          r"\b(first|1st|second|2nd|third|3rd|fourth|4th|fifth|5th|bottom|top)\b(?!\s+of\b)")


def _order_claims(text: str, pile: list[str], on_table: list[str]) -> list[tuple[str, int]]:
    """'the red cube is at the bottom', 'the yellow block should be the third block': [(label, index from the
    bottom)], the label found by its colour. "on top of" is where something was put, not a place in the tower,
    so it doesn't count."""
    claims = []
    for colour, word in _ORDER_CLAIM.findall(text.lower()):
        label = next((l for l in list(pile) + list(on_table) if colour in l.lower().split()), f"{colour} cube")
        claims.append((label, len(pile) - 1 if word == "top" else _ORDINALS[word]))
    return claims


def tower_order(prompt: str, labels: list[str]) -> list[str]:
    """The order a tower request asks for, bottom to top, as the labels of the objects on the table: the colours it
    names, in the order it names them ("Tower: red, yellow, green, blue, purple"; "red at the bottom, then
    yellow..."), one said to be "on top" last and one "at the bottom" first, all of it reversed for "from the top"
    or "A on B" (B is below). `labels`: one per object (two red cubes: "red cube" twice). [] if it names fewer than
    two, or a colour fits no object or more than one."""
    p = prompt.lower()
    if re.search(r"\b(?:second|2nd|third|3rd|fourth|4th|fifth|5th|sixth|6th|seventh|7th|eighth|8th|middle|"
                 r"(?:position|level)\s*\d)\b", p):
        # "red at the bottom and purple at the third" is not the order red, purple (purple second): places, for
        # tower_plan.position_claims
        return []
    named = []
    for match in re.finditer(r"[a-z]+", p):
        word = COLOUR_ALIASES.get(match.group(0), match.group(0))
        if word in COLOURS and word not in named:
            named.append(word)
    if len(named) < 2:
        return []
    colour_words = "|".join(COLOURS + tuple(COLOUR_ALIASES))
    if (re.search(r"top to (?:the )?bottom|from the top|top down", p)
            or re.search(rf"\b(?:{colour_words})\b(?:\s+\w+)?\s+on\s+(?:top\s+of\s+)?(?:the\s+)?(?:{colour_words})\b", p)):
        named.reverse()
    else:
        for colour in list(named):
            if re.search(rf"\b{colour}\b[^,.;]{{0,20}}\b(?:on|at) (?:the )?top\b", p):
                named.remove(colour)
                named.append(colour)
            elif re.search(rf"\b{colour}\b[^,.;]{{0,20}}\b(?:on|at) the bottom\b", p):
                named.remove(colour)
                named.insert(0, colour)
    order = []
    for colour in named:
        fits = [label for label in labels if COLOUR_ALIASES.get(label.split()[0], label.split()[0]) == colour]
        if len(fits) != 1:
            return []
        order.append(fits[0])
    return order


def position_claims_of(prompt: str, labels: list[str], n: int) -> dict:
    from app.llm.tower_plan import position_claims
    return position_claims(prompt, labels, n)


def _place_words(index: int, height: int) -> str:
    return ("at the bottom" if index == 0 else "on top" if index == height - 1
            else f"block {index + 1} from the bottom")


def _short(args) -> str:
    return json.dumps(args, ensure_ascii=False) if not isinstance(args, str) else args


def _safe_json(raw):
    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return raw


def _types_ok(schema: dict, args: dict) -> bool:
    properties = schema.get("parameters", {}).get("properties", {})
    for key, value in args.items():
        expected = properties.get(key, {}).get("type")
        if expected == "number" and not isinstance(value, (int, float)):
            return False
        if expected == "string" and not isinstance(value, str):
            return False
    return True


def _fits(understood: dict, name: str) -> Optional[str]:
    expected = " ".join(understood.get("expected", []))
    if not expected:
        return None
    return "fits the task" if name in expected or "…" in expected else "not what the task seemed to need"

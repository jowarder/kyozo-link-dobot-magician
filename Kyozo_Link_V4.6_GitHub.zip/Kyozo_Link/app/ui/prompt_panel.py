"""Prompt-driven control tab: text input, live action log, and Agent execution."""
from __future__ import annotations

import ast
import html
import re
import inspect
import logging
import threading
import time
from typing import Callable, Optional

from PyQt6.QtCore import QTimer, pyqtSignal
from PyQt6.QtWidgets import (QFrame, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QProgressBar,
                             QPushButton, QTextEdit)

from app.llm.agent import Agent, AgentStep, AgentRun
from app.ui.display_settings import DisplaySettings
from app.ui.flow_layout import FlowLayout, flow_policy
from app.ui.log_icons import icon
from app.ui.settings_panel import ToggleSwitch
from app.ui.worker import CallableWorker

logger = logging.getLogger(__name__)


def describe_plan(name: str, args: dict, labels: dict[str, str], target=None) -> str:
    """A step that is about to happen, as a plain sentence (step-by-step mode asks about it)."""
    def who(oid):
        return labels.get(oid, oid)
    where = f" at ({target.x:.0f}, {target.y:.0f}, {target.z:.0f}) mm" if target is not None else ""
    obj = who(args.get("object_id", ""))
    texts = {
        "pick": f"Pick up the {obj}{where}",
        "move_above": f"Move above the {obj}{where}",
        "place_on": f"Put it down on top of the {obj}{where}",
        "place_at": f"Put it down at the saved place \"{args.get('place_name', '')}\"{where}",
        "place_beside": f"Put it down to the {args.get('side', '')} of the {obj}, {args.get('gap_mm', '')} mm apart",
        "place_free": f"Put it down on free table ({args.get('where', '')})",
        "place": f"Put it down{where}",
        "move_to": f"Move the tip{where}",
        "open_gripper": "Open the gripper",
        "close_gripper": "Close the gripper",
        "home": "Go home",
    }
    return texts.get(name, f"{name} {args}")


# Each kind of line in the log: (its colour, its icon). Your prompt blue, waiting dim, the robot's steps grey (each
# with its own icon), its reply green, errors red: they were all one colour, and hard to tell apart.
LINE_STYLES = {
    "you": ("#6cb6ff", "you"),
    "wait": ("#7f93a3", "wait"),
    "look": ("#b3c4d1", "look"),
    "pick": ("#b3c4d1", "pick"),
    "place": ("#b3c4d1", "place"),
    "move": ("#b3c4d1", "move"),
    "step": ("#b3c4d1", "info"),
    "refused": ("#e0a030", "refused"),
    "note": ("#e0a030", "refused"),       # the app's own check under a reply: like a refused step, never hidden
    "robot": ("#6bdc8b", "robot"),
    "stopped": ("#ffb86b", "stopped"),
    "error": ("#ff7b7b", "error"),
}
STEP_KINDS = {"list_objects": "look", "pick": "pick", "move_above": "move", "move_to": "move", "home": "move",
              "place": "place", "place_at": "place", "place_on": "place", "place_beside": "place",
              "place_free": "place", "put_all_in": "place"}


REASON_WORDS = ("because", "too ", "cannot", "can't", "unable", "since", "due to", "not possible")


def reply_reason_mismatch(reply: str, steps: list) -> str:
    """The tool's own reason, if the robot's reply gives a reason for failing that isn't it ("" if it's fine). The
    model once answered "the black cube is too wide for the gripper" when the tool had said the cube touched the
    table: its reply is shown with the tool's words beside it."""
    errors = [s.result.removeprefix("ERROR:").strip() for s in steps if s.result.startswith("ERROR")]
    text = reply.lower()
    if not errors or not any(word in text for word in REASON_WORDS):
        return ""
    reason = errors[-1]
    words = {w.strip(".,:;()'\"").lower() for w in reason.split()}
    words = {w for w in words if len(w) >= 5 and w not in {"would", "there", "their", "where", "which", "before",
                                                             "tell", "user"}}
    shared = sum(1 for w in words if w in text)
    return reason if shared < 2 else ""


ADMITS = ("couldn't", "could not", "cannot", "can't", "not ", "only ", "left out", "failed", "unable", "stopped")


def goal_mismatch(reply: str, trace: dict) -> str:
    """What the app's own check found missing ("the tower is not in the tray; 45° was asked for, and nothing was
    turned"), when the reply says it was all done ("" otherwise). The model once replied "a tower inside the tray,
    oriented at 45 degrees" for a tower beside the tray with nothing turned."""
    goal = ((trace or {}).get("end") or {}).get("goal") or {}
    if goal.get("status") != "not met":
        return ""
    text = (reply or "").lower()
    if any(word in text for word in ADMITS):
        return ""              # it says itself that not everything was done
    return str(goal.get("detail") or "")


def step_kind(step: AgentStep) -> str:
    """The kind of log line a step makes (its colour and icon): refused, or by the tool it used."""
    if step.result.startswith("ERROR"):
        return "refused"
    return STEP_KINDS.get(step.tool_name, "step")


def describe_step(step: AgentStep, labels: dict[str, str]) -> str:
    """One tool call as a plain sentence. `labels` maps object ids (obj_1) to names
    (red cube) and is updated whenever the model looks at the table."""
    name, args, result = step.tool_name, step.arguments, step.result
    who = lambda oid: labels.get(oid, oid)  # noqa: E731

    if result.startswith("ERROR"):
        reason = html.escape(result.removeprefix("ERROR:").strip())
        return f"<span style='color:#e0a030'>Step refused ({name}): {reason}</span>"
    if name == "list_objects":
        try:
            data = ast.literal_eval(result)
        except (ValueError, SyntaxError):
            return f"<i>Looked at the table.</i> {html.escape(result)}"
        labels.clear()
        labels.update({o["id"]: o["label"] for o in data["objects"]})
        seen = ", ".join(f"{o['label']}" + (f" ({o['height_mm']} mm)" if "height_mm" in o else "")
                         + f" at x={o['xyz_mm'][0]}, y={o['xyz_mm'][1]}"
                         + (f" (under the {o['covered_by']})" if o.get("covered_by") else "")
                         for o in data["objects"]) or "nothing"
        for h in data.get("hidden", []):
            seen += f", {h['label']} (hidden under the {h['under']})"
        holding = data["holding"] or "nothing"
        places = ", ".join(data["saved_places"]) or "none"
        return (f"<i>Looked at the table:</i> sees {seen}. "
                f"Holding: {holding}. Saved places: {places}.")
    if name == "move_above":
        return f"<i>Moved above the {who(args.get('object_id', ''))}.</i>"
    if name == "pick":
        if "moved aside" in result:      # say what else was moved, so the table changing isn't a surprise
            return f"<i>{html.escape(result)}</i>"
        return f"<i>Picked up the {who(args.get('object_id', ''))}.</i>"
    if name == "place_on":
        return f"<i>Put it down on top of the {who(args.get('object_id', ''))}.</i>"
    if name in ("place_free", "place_beside"):
        return f"<i>{html.escape(result)}.</i>"
    if name == "place_at":
        return f"<i>Put it down at the saved place '{html.escape(str(args.get('place_name', '')))}'.</i>"
    return f"<i>{html.escape(result)}</i>"


class BusyRow(QWidget):
    """A moving bar with a message beside it, shown while the model is working, so it is clear the
    app hasn't frozen. The bar just animates (there is no way to know how long the model will take);
    the seconds counter shows it is still going."""

    def __init__(self, text: str, parent=None):
        super().__init__(parent)
        self._text = text
        self._started = 0.0
        layout = QHBoxLayout(self)
        layout.setContentsMargins(2, 0, 2, 0)
        self.bar = QProgressBar()
        self.bar.setRange(0, 0)          # 0..0 makes it an endless, animated bar
        self.bar.setTextVisible(False)
        self.bar.setFixedSize(130, 10)
        self.label = QLabel(text)
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setToolTip("End this prompt now: nothing more is done (a move under way finishes; "
                                 "E-STOP stops that too)")
        layout.addWidget(self.bar)
        layout.addWidget(self.label)
        layout.addStretch()
        layout.addWidget(self.stop_btn)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self.hide()

    def start(self) -> None:
        self._started = time.monotonic()
        self._tick()
        self.show()
        self._timer.start(500)

    def stop(self) -> None:
        self._timer.stop()
        self.hide()

    def _tick(self) -> None:
        self.label.setText(f"{self._text}  ({int(time.monotonic() - self._started)} s)")


class PromptPanel(QWidget):
    step_completed = pyqtSignal(object)  # AgentStep, emitted from the worker thread
    approval_needed = pyqtSignal(str, dict)   # step-by-step: (tool, arguments), from the worker thread
    plan_preview = pyqtSignal(object)          # where the next step takes the tip (a Pose), or None: for the 3D view
    trace_updated = pyqtSignal(object)         # the Model tab's record of the prompt, after every turn (a dict)
    busy_changed = pyqtSignal(bool)            # a prompt started (True) or ended (False): the model can't change meanwhile
    recorded = pyqtSignal(object, str)         # Watcher active: a prompt's record is written ((its folder, prompt))

    # live mode (and a scene without its own): the demo scenes bring theirs ("prompts" in each scene file)
    LINE_UP = "Line up the red, green and blue cubes in a row, 30 mm apart"
    EXAMPLES = ["Pick the red cube and put it in the tray",
                "Put the blue cube on the red cube",
                LINE_UP,
                "What do you see?",
                "Go home"]
    ALWAYS = ["What do you see?", "Go home"]      # after a scene's own
    # filled in for you to change (the gap, the order) and send, rather than sent straight away
    EDIT_FIRST = {LINE_UP}

    def __init__(self, agent: Agent, parent=None, settings: Optional[DisplaySettings] = None):
        super().__init__(parent)
        self.agent = agent
        self.settings = settings or DisplaySettings()
        self._worker: CallableWorker | None = None
        # why the arm is someone else's right now (a calibration step, Camera setup...), or None: asked before sending
        # (the window sets it)
        self.arm_busy: Optional[Callable[[], Optional[str]]] = None
        self._labels: dict[str, str] = {}
        self._answer: Optional[str] = None           # step-by-step: what you said about the step asked about
        self._answered = threading.Event()
        self.step_completed.connect(self._on_step)
        self.approval_needed.connect(self._show_approval)
        # Watcher active: each prompt recorded as a watcher run (watcher/prompt_record.py; the window sets it)
        self.recorder = None
        self._recording = None                       # the prompt being recorded now (a PromptRun)
        self.recorded.connect(self._name_recorded)

        layout = QVBoxLayout(self)
        layout.addLayout(self._build_log_tools())
        self._lines: list[tuple[str, str]] = []       # (the line, its kind): the log redrawn from these when filtered
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Type what you want the robot to do, or click an example below.\n\n"
                                    "Each step the model takes shows up here as it happens.")
        layout.addWidget(self.log)

        # the examples wrap onto a second line when the panel is narrow, rather than keeping it wide
        examples = QWidget()
        examples.setSizePolicy(flow_policy())
        self._examples_row = FlowLayout(examples)
        self._examples_row.addWidget(QLabel("Try:"))
        self._chips: list[QPushButton] = []
        self.set_examples(self.EXAMPLES, featured=False)
        layout.addWidget(examples)

        self.busy = BusyRow("Asking the model... can take up to a minute to process")
        self.busy.stop_btn.clicked.connect(lambda: self.cancel("Stopped by you"))
        self._abandoned: list = []       # prompts ended by Stop / E-STOP whose thread is still waiting on the model
        layout.addWidget(self.busy)
        layout.addWidget(self._build_approval_bar())

        # the language model, chosen right where the prompts are typed (the window fills it in: see MainWindow)
        self.model_row = QHBoxLayout()
        layout.addLayout(self.model_row)

        input_row = QHBoxLayout()
        self.prompt_input = QLineEdit()
        self.prompt_input.setPlaceholderText("e.g. pick the red cube and place it in the tray")
        self.prompt_input.returnPressed.connect(self._send)
        self.send_btn = QPushButton("Send")
        self.send_btn.clicked.connect(self._send)
        self.step_switch = ToggleSwitch()
        self.step_switch.setChecked(self.settings["step_by_step"])
        self.step_switch.setToolTip("Step by step: approve each robot move before it happens (also in Settings)")
        self.step_switch.toggled.connect(lambda on: self.settings.set("step_by_step", on))
        self.settings.changed.connect(lambda: self.step_switch.setChecked(self.settings["step_by_step"]))
        step_label = QLabel("Step by step")
        step_label.setToolTip(self.step_switch.toolTip())
        self.watch_switch = ToggleSwitch()
        self.watch_switch.setChecked(False)
        self.watch_switch.setToolTip("Watcher active: every prompt you send is recorded as the watcher records a run -- "
                                     "the table looked at before and after (pictures, where each cube is), every step, "
                                     "move and alarm, the arm, camera and settings -- whether it is done, refused, "
                                     "fails or is stopped. Each prompt gets 5 minutes; afterwards the arm parks out of "
                                     "the camera's way and you name the run. Saved in Kyozo_Link_Results\\Prompt_Runs")
        self.watch_switch.toggled.connect(self._watch_toggled)
        watch_label = QLabel("Watcher active")
        watch_label.setToolTip(self.watch_switch.toolTip())
        self.rec_label = QLabel("● REC")
        self.rec_label.setStyleSheet("color: #ff5c5c; font-weight: bold;")
        self.rec_label.setToolTip(self.watch_switch.toolTip())
        self.rec_label.hide()
        input_row.addWidget(self.prompt_input)
        input_row.addWidget(self.rec_label)
        input_row.addWidget(self.watch_switch)
        input_row.addWidget(watch_label)
        input_row.addWidget(self.step_switch)
        input_row.addWidget(step_label)
        input_row.addWidget(self.send_btn)
        layout.addLayout(input_row)
        self._time_limit = QTimer(self)                  # Watcher active: a prompt's 5 minutes
        self._time_limit.setSingleShot(True)
        self._time_limit.timeout.connect(self._time_up)

    def set_examples(self, prompts: list[str], featured: bool = True) -> None:
        """The buttons after "Try:". A demo scene's own prompts (the first, highlighted, does the whole scene),
        then "What do you see?" and "Go home"."""
        for chip in self._chips:
            self._examples_row.removeWidget(chip)
            chip.deleteLater()
        self._chips = []
        shown = list(prompts) + [t for t in (self.ALWAYS if featured else []) if t not in prompts]
        for i, text in enumerate(shown):
            chip = QPushButton(text)
            if text in self.EDIT_FIRST:
                chip.setToolTip("Click to fill it in: change the gap (or the order of the colours), then press Send")
                chip.clicked.connect(lambda _checked=False, t=text: self._fill_text(t))
            else:
                chip.setToolTip("Click to send this" + (": it does the whole scene" if featured and i == 0 else ""))
                chip.clicked.connect(lambda _checked=False, t=text: self._send_text(t))
            if featured and i == 0:
                chip.setProperty("featured", True)
            self._examples_row.addWidget(chip)
            self._chips.append(chip)
        self._examples_row.invalidate()

    def example_prompts(self) -> list[str]:
        return [chip.text() for chip in self._chips]

    def is_busy(self) -> bool:
        """True while a prompt is being worked on (the model may be driving the arm)."""
        return self._worker is not None

    def _build_log_tools(self) -> QHBoxLayout:
        """Over the conversation: show or hide the refused steps (the app's checks sending a step back to the model,
        which then usually does it right), and clear it all."""
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addStretch(1)
        self.refused_switch = ToggleSwitch()
        self.refused_switch.setChecked(True)
        self.refused_switch.setToolTip("Show the steps the app sent back to the model (amber lines). Hidden, the "
                                       "conversation shows only what was done; the notes under a reply stay.")
        self.refused_switch.toggled.connect(self._redraw_log)
        refused_label = QLabel("Show refused steps")
        refused_label.setToolTip(self.refused_switch.toolTip())
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setToolTip("Clear the conversation shown here (the Log tab keeps everything)")
        self.clear_btn.clicked.connect(self.clear_log)
        row.addWidget(self.refused_switch)
        row.addWidget(refused_label)
        row.addSpacing(12)
        row.addWidget(self.clear_btn)
        return row

    def _append_log(self, text: str, kind: str = "step") -> None:
        """One line of the conversation, in its kind's colour, with its icon in front (LINE_STYLES)."""
        self._lines.append((text, kind))
        if self._shown(kind):
            self._write_line(text, kind)

    def _shown(self, kind: str) -> bool:
        return kind != "refused" or self.refused_switch.isChecked()

    def _write_line(self, text: str, kind: str) -> None:
        colour, name = LINE_STYLES.get(kind, LINE_STYLES["step"])
        self.log.append(f'{icon(self.log.document(), name, colour)}&nbsp; <span style="color:{colour};">{text}</span>')

    def _redraw_log(self) -> None:
        """The conversation again, with the refused steps shown or left out."""
        self.log.clear()
        for text, kind in self._lines:
            if self._shown(kind):
                self._write_line(text, kind)
        self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())

    def clear_log(self) -> None:
        self._lines.clear()
        self.log.clear()

    def _fill_text(self, text: str) -> None:
        """Into the box, not sent: the first number (the gap) selected, to type over."""
        self.prompt_input.setText(text)
        self.prompt_input.setFocus()
        number = re.search(r"\d+", text)
        if number:
            self.prompt_input.setSelection(number.start(), number.end() - number.start())

    def _send_text(self, text: str) -> None:
        self.prompt_input.setText(text)
        self._send()

    def _send(self) -> None:
        prompt = self.prompt_input.text().strip()
        if not prompt or self._worker is not None:
            return
        busy = self.arm_busy() if self.arm_busy is not None else None
        if busy:                       # (the prompt stays typed in, to send when the arm is free)
            self._append_log(f"<i>Not sent: {html.escape(busy)}.</i>", "wait")
            return
        if self._abandoned and (getattr(self.agent, "in_tool", False) or self._recording is not None):
            # an ended prompt's last move is still finishing (or, Watcher active, the arm parking for its last look):
            # two prompts must never drive the arm at once
            self._append_log("<i>The last move is still finishing: send it again in a moment.</i>", "wait")
            return
        self._append_log(f"<b>You:</b> {html.escape(prompt)}", "you")
        self._append_log("<i>Asking the model... (can take up to a minute to process)</i>", "wait")
        self.prompt_input.clear()
        self.send_btn.setEnabled(False)
        self.busy.start()
        self.busy_changed.emit(True)

        step_by_step = self.settings["step_by_step"]
        if step_by_step:
            self._append_log("<i>Step by step: each robot move waits for your Go.</i>", "wait")
        watching = self.watching()
        if watching:
            from watcher.prompt_record import TIME_LIMIT_S
            self._append_log(f"<i>Watcher active: this prompt is recorded (the table looked at first; "
                             f"{TIME_LIMIT_S / 60:.0f} minutes at most).</i>", "wait")
            self._time_limit.start(int(TIME_LIMIT_S * 1000))
        worker = self._worker = CallableWorker(self._run_agent, prompt, step_by_step, watching)
        # (a prompt ended with Stop / E-STOP is no longer the current one: whatever it says when it ends is not shown)
        worker.finished_ok.connect(lambda run, w=worker: self._on_run_finished(run) if w is self._worker
                                   else self._forget(w))
        worker.failed.connect(lambda message, w=worker: self._on_run_failed(message) if w is self._worker
                              else self._forget(w))
        worker.start()

    def _run_agent(self, prompt: str, step_by_step: bool = False, watching: bool = False) -> AgentRun:
        extra = {"approve": self._ask} if step_by_step else {}   # (only then: nothing else changes without it)
        if "on_trace" in inspect.signature(self.agent.run).parameters:   # (a stand-in agent in a test may not)
            extra["on_trace"] = self.trace_updated.emit
        record = None
        if watching:                             # (the table looked at before the model is asked)
            try:
                record = self._recording = self.recorder.begin(prompt)
            except Exception:  # noqa: BLE001 - the prompt still runs; it just isn't recorded
                logger.exception("Couldn't start recording the prompt")

        def on_step(step):
            if record is not None:
                self.recorder.step(record, step)
            self.step_completed.emit(step)
        run, error = None, None
        try:
            run = self.agent.run(prompt, on_step=on_step, **extra)
            return run
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            if record is not None:             # done, refused, failed, stopped or out of time: all recorded
                try:
                    folder = self.recorder.finish(record, run, error)
                    self.recorded.emit(folder, prompt)
                except Exception:  # noqa: BLE001
                    logger.exception("Couldn't finish recording the prompt")
                finally:
                    if self._recording is record:
                        self._recording = None

    # ---- Watcher active ------------------------------------------------------------------------------
    def watching(self) -> bool:
        return self.watch_switch.isChecked() and self.recorder is not None

    def _watch_toggled(self, on: bool) -> None:
        if on and self.recorder is None:
            self.watch_switch.setChecked(False)
            self._append_log("<i>Watcher active isn't available here (no recorder).</i>", "wait")
            return
        self.rec_label.setVisible(on)
        self._append_log("<i>Watcher active: each prompt from now on is recorded (Kyozo_Link_Results\\Prompt_Runs).</i>"
                         if on else "<i>Watcher active off: prompts are no longer recorded.</i>", "wait")

    def _time_up(self) -> None:
        """Watcher active: the prompt has had its 5 minutes -- ended (as Stop ends it) and recorded as it stands."""
        record = self._recording
        if self._worker is None:
            return
        if record is not None:
            record.timed_out = True
        self.cancel("Time limit (5 minutes)")

    def _name_recorded(self, folder, prompt: str) -> None:
        """A recorded prompt has ended: you name it (and may give a verdict); closed without, it is saved under the
        name suggested."""
        if folder is None or self.recorder is None:
            return
        rec = {}
        try:
            import json
            rec = json.loads((folder / "run.json").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            pass
        from app.ui.prompt_name_dialog import PromptNameDialog
        suggested = self.recorder.suggested_name(prompt)
        dialog = PromptNameDialog(self, prompt, rec.get("outcome", "?"), suggested)
        dialog.exec()
        name, verdict, note = dialog.answer() if dialog.result() else (suggested, "", "")
        try:
            final = self.recorder.save(folder, name, verdict, note)
            self._append_log(f"<i>Recorded and saved as {html.escape(final.name)} (Prompt_Runs).</i>", "wait")
        except Exception as exc:  # noqa: BLE001
            logger.exception("Couldn't save the recorded prompt")
            self._append_log(f"<b>Error:</b> the recorded prompt couldn't be saved ({html.escape(str(exc))}); it is "
                             f"still in Prompt_Runs\\_pending.", "error")

    # ---- step-by-step mode ---------------------------------------------------------------------------
    def _build_approval_bar(self) -> QFrame:
        self.approval_bar = QFrame()
        self.approval_bar.setObjectName("approvalBar")
        self.approval_bar.setStyleSheet("QFrame#approvalBar { background: #1c3a44; border: 1px solid #4bb8ad; "
                                        "border-radius: 6px; }")
        row = QHBoxLayout(self.approval_bar)
        row.setContentsMargins(10, 6, 6, 6)
        self.approval_label = QLabel()
        self.approval_label.setWordWrap(True)
        row.addWidget(self.approval_label, stretch=1)
        self.go_btn = QPushButton("Go")
        self.go_btn.setToolTip("Do this step, then ask again before the next one")
        self.go_all_btn = QPushButton("Go all")
        self.go_all_btn.setToolTip("Do this step and all the rest of this task without asking")
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setToolTip("End the task here: the arm stays where it is, nothing more is done")
        for button, answer in ((self.go_btn, "go"), (self.go_all_btn, "all"), (self.stop_btn, "stop")):
            button.clicked.connect(lambda _=False, a=answer: self.answer(a))
            row.addWidget(button)
        self.approval_bar.hide()
        return self.approval_bar

    def _ask(self, name: str, args: dict) -> str:
        """On the worker thread: show the step and wait for Go / Go all / Stop (or E-STOP)."""
        self._answered.clear()
        self._answer = None
        self.approval_needed.emit(name, dict(args))
        self._answered.wait()
        return self._answer or "stop"

    def _show_approval(self, name: str, args: dict) -> None:
        planned = getattr(self.agent.executor, "planned_target", None)
        target = planned(name, args) if planned is not None else None
        self.approval_label.setText("<b>Next step:</b> " + html.escape(describe_plan(name, args, self._labels, target)))
        self.plan_preview.emit(target)
        self.approval_bar.show()
        self.go_btn.setFocus()
        self.busy.stop()

    def answer(self, what: str) -> None:
        """Go / Go all / Stop for the step being asked about (E-STOP uses it too, with "stop")."""
        self.approval_bar.hide()
        self.plan_preview.emit(None)
        if what != "stop" and self._worker is not None:
            self.busy.start()
        self._answer = what
        self._answered.set()

    def waiting_for_you(self) -> bool:
        return not self.approval_bar.isHidden()

    def _on_step(self, step: AgentStep) -> None:
        logger.info("tool call %s(%s) -> %s", step.tool_name, step.arguments, step.result)  # raw, for the Log tab
        self._append_log(describe_step(step, self._labels), step_kind(step))

    def cancel(self, why: str) -> None:
        """End the running prompt now (Stop, or E-STOP): the panel is free again at once -- Send, scene changes --
        while the run, told to stop, winds down by itself once the model's pending answer comes back."""
        worker = self._worker
        if worker is None:
            return
        self._time_limit.stop()
        if self._recording is not None and not self._recording.timed_out:
            self._recording.stopped_why = why            # (Stop, E-STOP: the record says which)
        cancel = getattr(self.agent, "cancel", None)
        if cancel is not None:
            cancel()
        if self.waiting_for_you():
            self.answer("stop")
        self._abandoned.append(worker)          # (kept until its thread ends: Qt mustn't delete a running thread)
        self._worker = None
        self.approval_bar.hide()
        self.plan_preview.emit(None)
        self._append_log(f"{why}: the prompt was ended. Nothing further is done.", "stopped")
        self.busy.stop()
        self.send_btn.setEnabled(True)
        self.busy_changed.emit(False)

    def _forget(self, worker) -> None:
        if worker in self._abandoned:
            self._abandoned.remove(worker)

    def _on_run_finished(self, run: AgentRun) -> None:
        self._time_limit.stop()
        self.approval_bar.hide()
        self.plan_preview.emit(None)
        self._append_log(f"<b>Robot:</b> {run.final_message}", "robot")
        mismatch = reply_reason_mismatch(run.final_message or "", getattr(run, "steps", []) or [])
        if mismatch:
            self._append_log(f"<b>Note:</b> the tool's own reason was different: {html.escape(mismatch)}", "note")
        missing = goal_mismatch(run.final_message or "", getattr(run, "trace", None) or {})
        if missing:
            self._append_log(f"<b>Note:</b> not everything asked for was done, as the app checked it: "
                             f"{html.escape(missing)}", "note")
        self.busy.stop()
        self.send_btn.setEnabled(True)
        self._worker = None
        self.busy_changed.emit(False)

    def _on_run_failed(self, message: str) -> None:
        self._time_limit.stop()
        self.approval_bar.hide()
        self.plan_preview.emit(None)
        self._append_log(f"<b>Error:</b> {html.escape(str(message))}", "error")
        self.busy.stop()
        self.send_btn.setEnabled(True)
        self._worker = None
        self.busy_changed.emit(False)

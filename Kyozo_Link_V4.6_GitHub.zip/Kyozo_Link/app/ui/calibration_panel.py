"""Calibration tab: automatic (marker), by hand, or with a cube; then the table-height step, then verification.

Both ways end the same: a camera->robot transform, made to agree about heights by touching the
tip to the table (step 5), and checked by sending the tip somewhere and seeing where the camera
says it is. Every run is saved as a session folder, so a problem at the lab can be debugged at
home. Clicking the camera picture here never moves the robot.
"""
from __future__ import annotations

import logging
import math
import threading
import time
from pathlib import Path
from typing import Callable, Optional

import numpy as np
from PyQt6.QtCore import Qt, QUrl, pyqtSignal
from PyQt6.QtGui import QColor, QDesktopServices
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QGroupBox, QHBoxLayout, QLabel, QListWidget,
                             QListWidgetItem, QMessageBox, QPushButton, QSizePolicy, QSpinBox, QVBoxLayout, QWidget)

from app.calibration.auto import MIN_FOUND, REACH_FRACTION, AutoOutcome, run_auto_calibration
from app.calibration.cube import (CAMERA_WARM_S, GRIP_ABOVE_TABLE_MM, MODES, ODD_OFF_MM, SAVE_ANYWAY_MAX_MM,
                                  TOUCH_POINTS, TOUCH_SAME_MM, WORST_MM, CubeOutcome,
                                  HeightsOutcome, middle_turn,
                                  CubeProgress, PickTestOutcome, TableHeights, arm_check, camera_warm, load_progress,
                                  progress_path, put_cube_down, run_cube_calibration, run_cube_stacks, run_pick_test,
                                  save_progress, with_touch)
from app.calibration.guidance import min_radius_mm
from app.calibration.boardless import MIN_POINTS, RECOMMENDED_POINTS, BoardlessCalibrator, SolveResult
from app.calibration.guidance import advice, build_cells
from app.calibration.marker import MARKER_SIZES_MM, make_marker_sheet
from app.calibration.session import SampleRecord, SessionRecorder
from app.calibration.storage import (calibration_history, clear_calibration, load_calibration, restore_calibration,
                                     save_calibration)
from app.calibration.table_touch import TableTouchRefused, apply_table_touch
from app.calibration.verify import GOOD_MM, USABLE_MM, VerifyResult, away_poses, choose_targets, run_verification
from app.calibration.wrist_check import TURNS_DEG as FINGERS_TURNS
from app.calibration.wrist_check import FingersCheckOutcome, RotationTestOutcome, run_fingers_check, run_rotation_test
from app.hardware.interfaces import Camera, Intrinsics, Pose, Robot
from app.hardware.wrist import WristModel
from app.ui.coverage_map import CoverageMap
from app.ui.flow_layout import FlowLayout
from app.ui.guide_text import GuideText
from app.ui.scroll import scrollable
from app.ui.video_widget import VideoWidget
from app.ui.worker import CallableWorker
from app.vision.locator import foreground_depth
from app.vision.table import TablePlane, measure_table

logger = logging.getLogger(__name__)

_TONES = {"warn": "#ffd166", "good": "#7fe0b0", "bad": "#ff8a8a"}
# the pick test passes (green) with its worst spot this close and every pick held: 1.5 mm until 2026-10-22, when Rafi
# chose 3.0 mm (the lab's pick tests that day: 2.45 mm typical, 2.51 worst, 3 of 3 held)
PICK_TEST_GOOD_MM = 3.0

# Section C's guide: what to do, what the robot does, how to read the result, and what to do if it fails.
PAPER_GUIDE = """
<p><b>Cube calibration with paper</b> is the cube calibration (same steps, same checks), with the study's printed A4
sheet placed at the same time. Print <i>study/Letter_sheet.pdf</i> (US Letter) or <i>study/A4_sheet.pdf</i>, as
config.yaml's study: paper says, at 100% (its ruler must measure 10 cm).</p>
<h4>Step 1 &middot; Touch the table</h4>
<p>As in the cube calibration: at the <b>6 touch points</b> (choose one, <b>Go above it</b>), jog the open gripper
down until the fingertips <b>just touch the table</b> (0.2 mm steps for the last millimetre) and press <b>Fingertips
on the table</b>. The line under the touches should say Good or Usable.</p>
<h4>Step 2 &middot; Grip the cube at the paper's centre</h4>
<ol>
<li>Press <b>Go to the paper's centre</b>: the open gripper goes 20 mm above where the sheet's centre belongs
(225, 0), the wrist in its middle, the fingers pointing straight out from the robot.</li>
<li>Put the cube on the table right under it. Jog the open gripper down round it until it rests on the cube's top,
and <b>close</b> it. Don't move the arm sideways or turn the wrist from here on.</li>
</ol>
<h4>Step 3 &middot; Line the paper up under the held cube</h4>
<ol>
<li>Press <b>Lift for the paper</b>: the held cube goes 5 mm straight up.</li>
<li>Slide the paper under it: the <b>centre outline right below the cube</b>, its sides <b>parallel to the cube's
faces</b>, the arrow towards the robot. Look from above, then from the side.</li>
<li><b>Tape the four corners</b> to the cloth. Keep the paper's edges clear: the camera finds the sheet by them.</li>
<li>Press <b>Put it back down</b>: the cube goes back to exactly where it was, resting on the paper's centre
outline. (The calibration measures how the cube is held from there: it must rest on the paper, not hang above it.)</li>
</ol>
<h4>Step 4 &middot; Start</h4>
<p>Choose Precise, Quick or Fast and press <b>Calibrate with a cube and paper</b>. It runs exactly as the cube
calibration. When it passes, the camera <b>finds the paper</b> and saves where it really is, next to the calibration:
the four corner spots follow it. If the paper is more than 8 mm or 3&deg; from where it belongs, it says so: the
calibration is kept, but place the paper again and press the watcher's <b>Find the paper</b>.</p>
<h4>Step 5 &middot; Then, with the cube still held</h4>
<p>As in the cube calibration (choose <i>With a cube</i> above to read its guide): <b>Pick test</b>, then the
<b>Fingers angle check</b> (Quick or Full: the wrist's real angles, used by every pick that turns it), then
<b>Finish</b> and <b>Verify calibration</b>.</p>
"""

CUBE_GUIDE = """
<h4>Before you start</h4>
<ul>
<li><b>One cube</b> that fits the open gripper: square, matte (not shiny), 15&ndash;30 mm; 20 mm is ideal.
For the optional height check, 1 or 2 more of the same size.</li>
<li><b>Camera</b> clamped firmly (any wobble spoils the result), aimed at the middle of the working area, and
switched on <b>at least 15 minutes</b> before: its distances drift while it warms up.</li>
<li><b>Table</b> clear except the cube, placed in the middle of the working area (about 22 cm in front of the
robot's base). No direct sunlight. Take the calibration marker off the tool.</li>
<li>Press <b>System check</b> in the toolbar: nothing should be red.</li>
</ul>

<h4>Step 1 &middot; Touch the table (at the 6 touch points)</h4>
<p>On the Manual tab, open the gripper and jog down until the fingertips <b>just touch the table</b>: for the last
millimetre type <b>0.2</b> in the Step (mm) box (with 1 mm steps a touch can be up to 1 mm off), and don't press. Then press <b>Fingertips on the table</b> (above):
the table's height there is recorded and the arm rises exactly 1 mm.</p>
<p><b>The 6 touch points</b> (above the touch buttons): choose one, press <b>Go above it</b> (the open gripper goes 20
mm above it), jog straight down until the fingertips just touch, and press <b>Fingertips on the table</b>; it then offers
the next. All 6 (the middle, stretched out, left, right and the sheet's near corners) give the table's height over the
whole sheet, with touches to spare; the calibration's spots stay where it was touched (and 4 cm round).
With 4 or more, each touch shows how far it is from the others' fit: one more than 1 mm off is marked; take just that one
away with its <b>Remove</b> button and touch there again. The line under the touches says whether they will do:
<b>Good</b> (within 0.5 mm of one plane), <b>Usable</b>, or <b>Redo</b>. 0.3&ndash;0.8 mm is normal for a real table.
The table may slope a few mm from near to far (the Dobot's own heights, as often as the table): the calibration
follows it.</p>
<p>Or by hand: do it <b>first with the arm stretched out</b> (about 27 cm from the robot's middle, where the far spots go),
<b>then beside the cube</b>. Stretched out, the Dobot stands 2-3 mm higher or lower than near; from the two
touches the robot lets the cube go just above the table everywhere, so it doesn't drop and turn. A third touch
off to one side also allows for a table that slopes sideways. A new touch within 4 cm of an earlier one replaces
it; <b>Forget touches</b> starts again (do that after pressing Home, or if the table was moved).</p>
<ul>
<li><b>Dobot</b>: its fingers reach only 15 mm, less than a 20 mm cube is tall, so touch the table
<b>beside</b> the cube.</li>
<li><b>xArm</b>: its fingers are longer than the cube, so do this <b>round</b> the cube.</li>
</ul>

<h4>Step 2 &middot; Grip the cube (close the gripper <i>on</i> it)</h4>
<ul>
<li><b>Dobot</b>: jog up about 3 cm, move over the cube, and lower the <b>open</b> gripper so the cube goes
<b>between the two fingers</b>, until the gripper rests on the cube's top (it goes no lower). Then close the
gripper: the fingers squeeze the cube.</li>
<li><b>xArm</b>: after step 1 the fingertips are 1 mm above the table with the cube between them: close the
gripper so the fingers squeeze the cube.</li>
</ul>
<p><b>Don't lift it.</b> Leave the cube held in the gripper and still resting on the table, and go to step 3: the
robot lifts it itself. A gripper closed with nothing between the fingers carries nothing, and the calibration
finds no cube.</p>
<p>Grip it <b>once</b>, by two flat faces (not the corners), with the <b>wrist in its middle</b>: before you lower
the gripper round the cube, press <b>Wrist to middle</b> (the gripper then points along the arm). The cube doesn't
need to be centred across the fingers (the robot squeezes it again in place), but <b>centre it along them</b>:
nothing does that, and where you grip it there is where every pick will hold things. The wrist stays in its middle
for the whole run.</p>

<h4>Step 3 &middot; Start</h4>
<p>Choose <b>Precise</b> (20 spots, about 10 minutes, the most accurate), <b>Quick</b> (10 spots, about 5) or
<b>Fast</b> (6 spots, about 3: a first try, or a check after a small bump; one spot can be missed). If you measured
the cube with calipers, type its size; otherwise leave <i>size: measure</i>. Press <b>Calibrate with a cube</b>.
The question that follows shows how high the fingertips are above the table: a few mm (about 5 on the Dobot, 1 on
the xArm). If it says the table wasn't touched, or shows much more, cancel and redo step 1.</p>

<h4>Step 4 &middot; While it runs (keep a hand near E-STOP)</h4>
<ol>
<li>It centres the cube: opens and closes the gripper in place (the wrist stays in its middle).</li>
<li>It looks at the empty table from its two waiting places, the cube held out of the way.</li>
<li>At each spot: puts the cube down (the wrist in its middle), moves away, waits 0.6 s, the camera takes 20
pictures, and the robot takes the cube back, the last 15 mm down slowly (closing the fingers centres it again).
From 5 spots on, the fingers come down where the camera sees the cube, across them (the Dobot's fingers open only
2.5 mm wider than a 25 mm cube). If the camera saw the cube turn as it was let go, the wrist turns the same few
degrees to take it back. Where the cube sits along the fingers is tracked by the camera, so a knock there doesn't
spoil the result.</li>
<li>Every 5 spots, and at the end, it puts the cube back at the first spot and looks again: the slip check. Up
to 1.5 mm that look counts as one more spot; up to 3 mm it is only reported (not a spot: it disagrees with the
first). Over 3 mm the arm has lost its place: the run pauses, and the spots since the last good check are done
again after. After you took over, 1.5 mm across the fingers is enough to pause.</li>
</ol>
<p>It goes at half speed (the Dobot's motors skip a step less easily), and saves its progress after every spot.</p>

<h4>If something goes wrong part-way: take over</h4>
<p>Press <b>Pause &ndash; I'll take over</b> at any time (the gripper hit the cube, say): the robot stops after the
current move and waits. It also pauses by itself when it needs a hand: no room for the fingers round a turned
cube (it waits above it), the camera sees the cube knocked more than 3 mm, the gripper came up without the cube,
a move was refused, or the arm lost its place.</p>
<ol>
<li>On the Manual tab, jog the arm up, over the cube (wherever it is now), turn the wrist to match the cube if it
is turned, lower the open gripper round it and close it, the cube resting on the table. After an alarm, or if the
arm knocked into something: Clear Alarms and press <b>Home</b> first.</li>
<li>Press <b>Manually gripped &ndash; continue</b>. If a spot was measured just before it stopped, you are asked
whether to use it (yes, unless the cube was knocked before the camera looked). The robot checks the camera hasn't
moved and the arm hasn't lost its place (the cube back at the first spot), then carries on.</li>
</ol>
<p>Progress survives closing the app. <b>Start over</b> throws it away (the calibration in use doesn't change).</p>
<p>Don't walk in front of the camera or touch the table: every look is compared with the empty table.
<b>Stop</b> finishes the current move and puts the cube down; <b>E-STOP</b> stops at once.</p>

<h4>Step 5 &middot; Read the result</h4>
<ul>
<li><b>Typical error</b> (each spot predicted from the others): under 0.5 mm is excellent; up to 2.0 mm passes.
<b>Worst</b>: under about 3 mm. One or two spots over it are left out or reported; more than a fifth of the spots
(and at least 2) over 3 mm fails the run, however good the typical.</li>
<li><b>Slip check</b> (the worst look back at the first spot): under 1.5 mm is as good as the Dobot puts a cube
back (1.0 to 1.8 mm apart at the lab); the table flat to under 0.5 mm.</li>
<li><b>Left out</b>: none, or one or two spots, is normal.</li>
<li><b>Arrows on the picture</b> show each spot's miss, 15 times larger. Pointing every way: noise, good. All one
way: something moved, so check the camera clamp and run it again. Larger towards the picture's edges: the lens.</li>
</ul>
<p>A result that passes is saved and used at once, and the safety floor is set from the table.</p>

<h4>Step 6 &middot; Then, with the cube still held (in this order)</h4>
<p>These need the calibration that just passed and the cube still in the gripper: don't press Finish first. If the
cube was lost on the way (a take-back missed), grip it again on the Manual tab and press <b>Cube back in the gripper
&ndash; continue</b>.</p>
<ol>
<li><b>Pick test</b> (about 2 minutes): the cube at 3 new spots, found by the camera and picked from where the
camera says. Worst under 3 mm and 3 of 3 held passes (under 1 mm is very good): this is the accuracy to report.</li>
<li><b>Fingers angle check</b> (recommended; <b>Quick (10)</b> about 3.5 minutes, <b>Full (20)</b> about 7): the
cube is put down with the wrist turned to set angles, -40&deg; to +40&deg;, coming from below and from above, and
the camera reads how it really turned. From that it measures the wrist's offset, gain and backlash, and every pick
that turns the wrist (a cube lying turned) is corrected by them from then on. Quick is enough to be trusted; Full
is the more accurate. The result says whether it is trusted, and why not if it isn't.</li>
<li><b>Rotation pick test</b> (optional): picks of turned cubes, with the angle check's correction on or off (the
switch beside it), to show what it changes.</li>
<li><b>Add 1 cube / Add 2 cubes</b> (optional): first put them on the table, at least 15 cm apart and away from the
robot. Towers 2 or 3 high are built and each level is checked; the result is kept only if the heights get better.</li>
<li><b>Finish</b> puts the cube back on the table. Then press <b>Verify calibration</b> (below) as an independent
check: under 1.5 mm is Good.</li>
</ol>
<p>The first calibration on a new setup (no calibration before it) keeps its spots near where the cube was gripped:
the app can't yet tell where the camera sees. Run it once more (Quick) after it passes: then the spots spread over
all of the area the camera sees and the table was touched.</p>

<h4>If it doesn't work</h4>
<ul>
<li><i>Arm check</i> (after touching the table): the Dobot wasn't homed, or the table reads very differently
near and far, or than last time. Press Home, forget the touches and touch again.</li>
<li><i>&ldquo;below the table height&rdquo;</i>: the touch was pressed too hard. Redo step 1.</li>
<li><i>Found at too few spots</i>: the camera must see the whole working area; nothing else on the table or
moving in view.</li>
<li><i>Landed crooked</i>: something under the cube, or the table isn't flat there. One or two are fine.</li>
<li><i>Seen ... mm from where it was the first time</i>: the cube moved in the fingers, the arm lost its place,
or the camera moved. Press <b>Home</b> (the Dobot's motors skip if the arm knocks into something), check the
camera clamp is tight, touch the table again (step 1, both places), and run it again.</li>
<li><i>The table touches disagree</i>: one touch pressed into the table or missed it. Remove that one (or Forget
touches) and redo step 1. <i>Agree, but on a plane too far out of level</i>: press Home and touch again.</li>
<li><i>The robot did not acknowledge the move</i>: press Clear Alarms (Manual tab) and try again; if it keeps
happening, switch the Dobot off and on and press Home.</li>
<li><i>Spots disagree</i>: let the camera warm up, tighten the clamp, use Precise (with 20 spots, one or two
odd ones are left out, and it can also correct the lens's bending).</li>
</ul>
<p>A calibration that came out worse than the one before? <b>Earlier calibrations / reset</b> (below) goes back to
any of the last 10, or clears it.</p>
<p class="muted">Calibrate again whenever the camera is moved or bumped. Every run is kept in the sessions folder
(button below). The xArm has its own calibration: the same steps with the xArm chosen at start-up.</p>
"""


def _wrapping_row(*widgets) -> QWidget:
    """Buttons side by side, onto the next line when the column is narrow (at 150% scaling, rows side by side made
    the column wider than the window gave it, and cut its right side off)."""
    row = QWidget()
    row.setObjectName("cubeRow")
    row.setStyleSheet("#cubeRow { background: transparent; }")   # (the group box's colour shows through)
    flow = FlowLayout(row)
    for widget in widgets:
        flow.addWidget(widget)
    return row


class CalibrationPanel(QWidget):
    """Has its own camera feed. Clicks here only ever record calibration samples;
    click-to-move lives on the Manual tab's separate feed, so a calibration click
    can never also move the robot."""

    progress = pyqtSignal(str)   # status text from a worker thread

    def __init__(self, robot: Robot, camera: Camera, calibration_path: Path,
                 on_calibrated: Callable[[np.ndarray, float], None], note: str = "",
                 on_reset_builtin: Optional[Callable[[], None]] = None, feed_widget=None,
                 on_table_touched: Optional[Callable[[float], None]] = None,
                 sessions_dir: Optional[Path] = None, context: Optional[dict] = None,
                 get_transform: Optional[Callable[[], np.ndarray]] = None,
                 on_check_camera: Optional[Callable[[Callable], None]] = None,
                 on_remember_view: Optional[Callable[[Callable], None]] = None, gripper=None,
                 place_cubes: Optional[Callable[[int], str]] = None,
                 on_cleared: Optional[Callable[[], None]] = None,
                 on_wrist: Optional[Callable[[], None]] = None, wrist_settings: Optional[dict] = None,
                 on_camera_setup: Optional[Callable[[], None]] = None,
                 arm_busy: Optional[Callable[[], Optional[str]]] = None, continuous=None,
                 cube_size_mm: Optional[float] = None, parent=None):
        """`note` is shown above the instructions; `on_reset_builtin` (demo mode) adds a button that
        drops a practised calibration and restores the simulator's exact one; `feed_widget` replaces
        the plain camera feed (anything with a `pixel_clicked(u, v)` signal); `get_transform` returns
        the calibration currently in use (for verifying one that was loaded rather than just made). `gripper`: the
        end effector (GripperSpec), for the cube calibration; `place_cubes(n)` (demo mode) puts n more cubes on the
        table for its height step, returning what it did. `on_wrist()`: the fingers angle check or the rotation pick
        test saved a result with the calibration (the app reads it again); `wrist_settings`: how picks come to their
        angle (side, overshoot_deg, slow_last_mm, slow_speed), for the rotation pick test. `arm_busy()`: why the arm is
        someone else's right now (a prompt, a click-to-move, the Manual tab, the watcher's session, Camera setup), or
        None -- every step that moves the arm asks it first. `continuous`: the continuous calibration
        (ui/continuous_monitor.py), offered as a style of its own; None: not offered."""
        super().__init__(parent)
        self.arm_busy = arm_busy
        self.continuous = continuous
        self.robot = robot
        self.camera = camera
        self.video_widget = feed_widget if feed_widget is not None else VideoWidget(camera, zoomable=True)
        # a picture to click points on (a camera's); the demo's 3D model has none: no calibrating by hand then
        self._clickable = hasattr(self.video_widget, "pixel_clicked")
        self.calibration_path = calibration_path
        self.on_calibrated = on_calibrated
        self.on_cleared = on_cleared
        self.on_wrist = on_wrist
        self.wrist_settings = dict(wrist_settings or {})
        self._cube_size_start = cube_size_mm      # the cube size picked at first: Settings > Cubes' (live), or measure
        self._wrist_model: Optional[WristModel] = None    # the fingers angle check made with this calibration
        # what the cube steps did, newest result each ("touch", "middle", "cube", "pick_test", "fingers",
        # "rotation_off", "rotation_on", "finish"): read by the demo's walk-through (cube_tour.py) to follow along
        self.done_steps: dict = {}
        self.on_table_touched = on_table_touched
        self.get_transform = get_transform
        self.on_check_camera = on_check_camera
        self.on_remember_view = on_remember_view
        self.markers_dir = calibration_path.parent / "markers"
        self.calibrator = BoardlessCalibrator(intrinsics=camera.get_intrinsics())
        self.recorder = (SessionRecorder(sessions_dir, camera.get_intrinsics(), context or {})
                         if sessions_dir is not None else None)
        self._transform: Optional[np.ndarray] = None   # the latest solve, before/after the height step
        self._armed = False
        self._last_result: Optional[SolveResult] = None
        self._worker: Optional[CallableWorker] = None
        self._cancel = threading.Event()
        self._verify_marks: list[dict] = []
        self.gripper = gripper
        self.place_cubes = place_cubes
        self._cube_phase1: Optional[CubeOutcome] = None   # phase 1 done: pick test and the height step may follow
        self._unsaved_cube: Optional[CubeOutcome] = None  # failed only over its limit: 'Save it anyway' may keep it
        self._touches: list = []                         # where the fingertips touched the table: (x, y, z) each
        self._touched_at: Optional[float] = None          # time.monotonic() of the first of them
        self._pause = threading.Event()                   # "Pause - I'll take over"
        self._cube_running = False
        self._progress_file = progress_path(calibration_path)
        self._progress: Optional[CubeProgress] = load_progress(self._progress_file)   # a run to carry on
        self._paper_run = False                           # the run under way is "Cube calibration with paper"

        outer = QHBoxLayout(self)
        outer.addWidget(self.video_widget, stretch=2)
        controls = QWidget()   # the right-hand column; scrolls when the window is short
        layout = QVBoxLayout(controls)
        outer.addWidget(scrollable(controls), stretch=1)
        if note:
            note_label = QLabel(note)
            note_label.setWordWrap(True)
            note_label.setStyleSheet("background: #16303a; color: #9fe3d6; padding: 8px; border-radius: 4px;")
            layout.addWidget(note_label)
        if on_camera_setup is not None:
            # step 0: the camera placed and its picture set, so the calibration can pass (camera_setup_dialog.py)
            self.camera_setup_btn = QPushButton("Camera setup (step 0)...")
            self.camera_setup_btn.setToolTip("Before calibrating: the camera's height and tilt, the cubes' size, depth "
                                             "and colours in the picture, against their targets; the exposure and "
                                             "other picture settings; a reference to check each session against")
            self.camera_setup_btn.clicked.connect(on_camera_setup)
            layout.addWidget(self.camera_setup_btn)
        # one way of calibrating shown at a time (all three, one under the other, made a long column to scroll)
        style_row = QHBoxLayout()
        style_row.addWidget(QLabel("Calibration style:"))
        self.style_box = QComboBox()
        for text, key in (("With a cube (the most accurate)", "cube"), ("Cube calibration with paper", "paper"),
                          ("Continuous (keeps itself calibrated)", "continuous"),
                          ("Automatic (marker on the tool)", "auto"), ("By hand (click points)", "hand")):
            if (key != "hand" or self._clickable) and (key != "continuous" or continuous is not None):
                self.style_box.addItem(text, key)
        self.style_box.setToolTip("Which way to calibrate: only that one's steps are shown. Verifying, the camera "
                                  "check and earlier calibrations are below, whichever is chosen.")
        self.style_box.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.style_box.setMinimumContentsLength(12)
        style_row.addWidget(self.style_box, stretch=1)
        layout.addLayout(style_row)
        self.overview = QLabel("")
        self.overview.setWordWrap(True)
        layout.addWidget(self.overview)

        # ---- A. automatic ----------------------------------------------------------------------------
        auto_box = self.auto_box = QGroupBox("Automatic (marker on the tool)")
        auto_layout = QVBoxLayout(auto_box)
        auto_text = QLabel("Print the sheet at 100% size, stick the marker on a stiff card on top of the tool, "
                           "facing the camera. Jog the tip to the middle of the workspace, safely above the table "
                           "(60 to 100 mm): the arm sweeps from there and never goes lower. Keep the area clear.")
        auto_text.setWordWrap(True)
        auto_layout.addWidget(auto_text)
        self.marker_size = QComboBox()
        for size in MARKER_SIZES_MM:
            self.marker_size.addItem(f"{size:.0f} mm", size)
        self.sheet_btn = QPushButton("Save marker print sheet")
        self.sheet_btn.clicked.connect(self._save_sheet)
        auto_layout.addWidget(_wrapping_row(QLabel("Marker size:"), self.marker_size, self.sheet_btn))
        self.auto_btn = QPushButton("Start automatic calibration")
        self.auto_btn.clicked.connect(self._start_auto)
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setEnabled(False)
        self.stop_btn.setToolTip("Stops after the current move. The E-STOP button stops immediately.")
        self.stop_btn.clicked.connect(self._stop)
        auto_layout.addWidget(_wrapping_row(self.auto_btn, self.stop_btn))
        layout.addWidget(auto_box)

        # ---- B. by hand -------------------------------------------------------------------------------
        hand_box = self.hand_box = QGroupBox("By hand")
        hand = QVBoxLayout(hand_box)
        instructions = QLabel(
            "1. Jog the gripper tip to a point on the workbench (Manual tab).\n"
            "2. Come back here, click 'Arm next click', then click the middle of the tool's body in the picture "
            "-- not its very end (a thin tip can read the table behind it). Click the same part of the tool every time.\n"
            f"3. Repeat: {MIN_POINTS} points is the minimum, {RECOMMENDED_POINTS} to 12 is the sweet spot. "
            "Spread them sideways over the amber areas of the map; the height doesn't matter much.\n"
            "4. Solve. Check the error, and remove any point marked as suspicious."
        )
        instructions.setWordWrap(True)
        hand.addWidget(instructions)
        self.status_label = QLabel(f"Samples: 0 / {MIN_POINTS} minimum")
        hand.addWidget(self.status_label)
        self.coverage_map = CoverageMap()
        hand.addWidget(self.coverage_map)
        self.advice_label = QLabel("")
        self.advice_label.setWordWrap(True)
        self.advice_label.setStyleSheet("color: #ffd166;")
        hand.addWidget(self.advice_label)
        self.sample_list = QListWidget()
        self.sample_list.setMinimumHeight(110)
        self.sample_list.currentRowChanged.connect(lambda _row: self._apply_marks())   # show it in the picture
        hand.addWidget(self.sample_list)
        self.arm_btn = QPushButton("Arm next click")
        self.arm_btn.clicked.connect(self._arm)
        self.reset_btn = QPushButton("Reset")
        self.reset_btn.clicked.connect(self._reset)
        self.solve_btn = QPushButton("Solve")
        self.solve_btn.clicked.connect(self._solve)
        hand.addWidget(_wrapping_row(self.arm_btn, self.reset_btn, self.solve_btn))
        self.remove_selected_btn = QPushButton("Remove selected point")
        self.remove_selected_btn.clicked.connect(self._remove_selected)
        self.remove_worst_btn = QPushButton("Remove worst point")
        self.remove_worst_btn.setToolTip("Drops the point that disagrees most with the others "
                                         "(after Solve), then solve again.")
        self.remove_worst_btn.clicked.connect(self._remove_worst)
        hand.addWidget(_wrapping_row(self.remove_selected_btn, self.remove_worst_btn))
        layout.addWidget(hand_box)

        # ---- C. with a cube ----------------------------------------------------------------------------------
        cube_box = self.cube_box = QGroupBox("With a cube (no marker; the most accurate)")
        cube_layout = QVBoxLayout(cube_box)
        cube_intro = QLabel("Measured where objects are picked, with the real gripper and the depth camera. "
                            "Needs one cube and about 10 minutes.")
        cube_intro.setWordWrap(True)
        cube_layout.addWidget(cube_intro)
        self.guide_btn = QPushButton("Hide the step-by-step guide")
        self.guide_btn.setCheckable(True)
        self.guide_btn.setChecked(True)
        self.cube_guide = GuideText(CUBE_GUIDE)
        self.guide_btn.toggled.connect(self._show_guide)
        touch_row = QWidget()
        touch_row.setObjectName("cubeRow")
        touch_row.setStyleSheet("#cubeRow { background: transparent; }")   # (the group box's colour shows through)
        touch_flow = FlowLayout(touch_row)
        # the 4 places to touch (cube.TOUCH_POINTS): the open gripper taken 20 mm above one, then jog it down
        self.touch_point_box = QComboBox()
        for n, (name, x, y) in enumerate(TOUCH_POINTS, start=1):
            self.touch_point_box.addItem(f"Touch point {n}: {name}", n - 1)
        self.touch_point_box.setToolTip("Where to touch the table: all 6 (the middle, stretched out, left, right, near "
                                        "left, near right) give its height over the whole sheet, with touches to "
                                        "spare. The calibration's spots stay where it was touched.")
        self.touch_point_btn = QPushButton("Go above it")
        self.touch_point_btn.setToolTip("The open gripper goes 20 mm above the touch point chosen, the wrist in its "
                                        "middle. Then jog it straight down until the fingertips just touch, and press "
                                        "'Fingertips on the table'.")
        self.touch_point_btn.clicked.connect(self._go_touch_point)
        touch_flow.addWidget(self.touch_point_box)
        touch_flow.addWidget(self.touch_point_btn)
        self.touch_btn = QPushButton("Fingertips on the table")
        self.touch_btn.setToolTip("Press with the fingertips just touching the table: records its height there and "
                                  f"raises the arm {GRIP_ABOVE_TABLE_MM:.0f} mm. Touch it with the arm stretched "
                                  "out first, then beside the cube.")
        self.touch_btn.clicked.connect(self._touch_table)
        self.touch_label = QLabel("Table: not touched yet")     # (its own line: it grows with every touch)
        self.touch_label.setWordWrap(True)
        self.touch_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.forget_touches_btn = QPushButton("Forget touches")
        self.forget_touches_btn.setToolTip("Forgets where the table was touched (after Home, or if the table moved).")
        self.forget_touches_btn.clicked.connect(self._forget_touches)
        touch_flow.addWidget(self.touch_btn)
        touch_flow.addWidget(self.forget_touches_btn)
        self.paper_btn = QPushButton("Go to the paper's centre")
        self.paper_btn.setToolTip("The open gripper goes 20 mm above where the A4 sheet's centre belongs (225, 0), the "
                                  "wrist in its middle: put the cube under it and grip it there.")
        self.paper_btn.clicked.connect(self._go_paper_centre)
        self.paper_btn.setVisible(False)
        touch_flow.addWidget(self.paper_btn)
        self.lift_paper_btn = QPushButton("Lift for the paper")
        self.lift_paper_btn.setToolTip("With the cube gripped at the paper's centre: lifts it 5 mm straight up, so the "
                                       "paper can be slid under it, lined up with the cube and taped.")
        self.lift_paper_btn.clicked.connect(self._lift_for_paper)
        self.lift_paper_btn.setVisible(False)
        touch_flow.addWidget(self.lift_paper_btn)
        self.down_paper_btn = QPushButton("Put it back down")
        self.down_paper_btn.setToolTip("Puts the held cube back exactly where it was lifted from: resting on the paper.")
        self.down_paper_btn.clicked.connect(self._down_onto_paper)
        self.down_paper_btn.setVisible(False)
        touch_flow.addWidget(self.down_paper_btn)
        self._paper_lift = None                  # (x, y, z, r) the held cube was lifted from, until it's put back
        self.middle_btn = QPushButton("Wrist to middle")
        self.middle_btn.setToolTip("Turns the wrist to the middle of its range (the gripper along the arm). Press it "
                                   "with the gripper lifted clear of the cube, before you lower it round the cube.")
        self.middle_btn.clicked.connect(self._wrist_to_middle)
        touch_flow.addWidget(self.middle_btn)
        cube_layout.addWidget(touch_row)
        cube_layout.addWidget(self.touch_label)
        # every touch, numbered as on the camera picture (T1, T2...): how many there are, and where
        self.touches_list = QLabel("")
        self.touches_list.setWordWrap(True)
        self.touches_list.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.touches_list.setVisible(False)
        cube_layout.addWidget(self.touches_list)
        # once all 6 touch points are touched: whether they'll do, in one line (TableHeights.verdict)
        self.touch_verdict = QLabel("")
        self.touch_verdict.setWordWrap(True)
        self.touch_verdict.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.touch_verdict.setVisible(False)
        cube_layout.addWidget(self.touch_verdict)
        # one button per touch, to take just that one away (a touch pressed into the table, say)
        self.touch_remove_row = QWidget()
        self.touch_remove_row.setObjectName("cubeRow")
        self.touch_remove_row.setStyleSheet("#cubeRow { background: transparent; }")
        self.touch_remove_flow = FlowLayout(self.touch_remove_row)
        self.touch_remove_btns: list = []
        self.touch_remove_row.setVisible(False)
        cube_layout.addWidget(self.touch_remove_row)
        options_row = QWidget()
        options_row.setObjectName("cubeRow")
        options_row.setStyleSheet("#cubeRow { background: transparent; }")   # (the group box's colour shows through)
        options_flow = FlowLayout(options_row)
        self.cube_mode = QComboBox()
        self.cube_mode.addItem(f"Precise ({MODES['precise'].spots} spots, ~10 min)", "precise")
        self.cube_mode.addItem(f"Quick ({MODES['quick'].spots} spots, ~5 min)", "quick")
        self.cube_mode.addItem(f"Fast ({MODES['fast'].spots} spots, ~3 min)", "fast")
        self.cube_spots = QSpinBox()
        self.cube_spots.setRange(6, 30)
        self.cube_spots.setSuffix(" spots")
        self.cube_spots.setValue(MODES["precise"].spots)
        self.cube_mode.currentIndexChanged.connect(
            lambda _i: self.cube_spots.setValue(MODES[self.cube_mode.currentData()].spots))
        self.cube_size = QDoubleSpinBox()
        self.cube_size.setRange(0.0, 60.0)
        self.cube_size.setDecimals(1)
        self.cube_size.setSingleStep(0.1)
        self.cube_size.setSuffix(" mm")
        self.cube_size.setSpecialValueText("size: measure")
        self.cube_size.setToolTip("The cube's size, if you measured it (calipers); left at 'measure', the camera "
                                  "measures it. Only used while calibrating (the stacks' heights).")
        # the size picked (V4.3: the study's 25 and 20 mm cubes), or the camera's measure; Other: typed (calipers)
        self.cube_size_choice = QComboBox()
        for words, value in (("Cube 25 mm", 25.0), ("Cube 20 mm", 20.0), ("Size: measure", 0.0),
                             ("Other size (type it)", None)):
            self.cube_size_choice.addItem(words, value)
        self.cube_size_choice.setToolTip("The size of the cube you calibrate with (it needn't be the study's: the "
                                         "study's is Settings > Cubes). Measure: the camera measures it. Other: type "
                                         "what you measured with calipers.")
        self.cube_size_choice.currentIndexChanged.connect(lambda _i: self._cube_size_chosen())
        options_flow.addWidget(self.cube_mode)
        options_flow.addWidget(self.cube_spots)
        options_flow.addWidget(self.cube_size_choice)
        options_flow.addWidget(self.cube_size)
        self.set_cube_size(self._cube_size_start)
        cube_layout.addWidget(options_row)
        self.cube_btn = QPushButton("Calibrate with a cube")
        self.cube_btn.clicked.connect(self._start_cube)
        self.cube_stop_btn = QPushButton("Stop")
        self.cube_stop_btn.setToolTip("Stops after the current move, and puts the cube down. E-STOP stops at once.")
        self.cube_stop_btn.clicked.connect(self._stop)
        self.cube_pause_btn = QPushButton("Pause - I'll take over")
        self.cube_pause_btn.setToolTip("Stops after the current move and waits, the cube left where it is: jog the arm "
                                       "and grip the cube by hand, then press 'Manually gripped - continue'.")
        self.cube_pause_btn.clicked.connect(self._pause_cube)
        cube_layout.addWidget(_wrapping_row(self.cube_btn, self.cube_pause_btn, self.cube_stop_btn))
        resume_row = QWidget()
        resume_row.setObjectName("cubeRow")
        resume_row.setStyleSheet("#cubeRow { background: transparent; }")
        resume_flow = FlowLayout(resume_row)
        self.continue_btn = QPushButton("Manually gripped - continue")
        self.continue_btn.setToolTip("With the gripper closed on the cube, the cube resting on the table: carries on "
                                     "with the run that stopped, from where it was.")
        self.continue_btn.clicked.connect(self._continue_cube)
        self.start_over_btn = QPushButton("Start over")
        self.start_over_btn.setToolTip("Throws away the spots measured so far (the calibration in use doesn't "
                                       "change).")
        self.start_over_btn.clicked.connect(self._start_over)
        self.progress_label = QLabel("")
        self.progress_label.setWordWrap(True)
        self.progress_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        resume_flow.addWidget(self.continue_btn)
        resume_flow.addWidget(self.start_over_btn)
        cube_layout.addWidget(resume_row)
        cube_layout.addWidget(self.progress_label)
        next_row = QWidget()
        next_row.setObjectName("cubeRow")
        next_row.setStyleSheet("#cubeRow { background: transparent; }")   # (the group box's colour shows through)
        next_flow = FlowLayout(next_row)
        self.pick_test_btn = QPushButton("Pick test")
        self.pick_test_btn.setToolTip("Puts the cube at 3 spots the calibration never saw, finds it with the camera "
                                      "and picks it up from where the camera says it is.")
        self.pick_test_btn.clicked.connect(self._pick_test)
        self.add_one_btn = QPushButton("Add 1 cube")
        self.add_one_btn.setToolTip("Put one more cube on the table first. The two are stacked at 5 spots, for the "
                                    "heights.")
        self.add_one_btn.clicked.connect(lambda: self._add_cubes(1))
        self.add_two_btn = QPushButton("Add 2 cubes")
        self.add_two_btn.setToolTip("Put two more cubes on the table first, at least 15 cm apart. Towers of three "
                                    "are built at 4 spots, for the heights and the camera's distance scale.")
        self.add_two_btn.clicked.connect(lambda: self._add_cubes(2))
        self.save_anyway_btn = QPushButton("Save it anyway")
        self.save_anyway_btn.setToolTip("Keep the calibration just made though its spots disagree by more than the "
                                        "limit (it asks first; saved marked as over the limit)")
        self.save_anyway_btn.clicked.connect(self._save_cube_anyway)
        self.save_anyway_btn.setVisible(False)
        cube_layout.addWidget(self.save_anyway_btn)
        self.finish_cube_btn = QPushButton("Finish")
        self.finish_cube_btn.setToolTip("Keep the calibration just made; the cube is put back on the table.")
        self.finish_cube_btn.clicked.connect(self._finish_cube)
        self.fingers_btn = QPushButton("Fingers angle check")
        self.fingers_btn.setToolTip("Measures how the wrist really turns: puts the cube down with the wrist turned "
                                    "-40 to +40°, at 2 places, coming to each angle from below and from above (20 "
                                    "put-downs). Offset, gain, backlash and scatter are saved with the calibration, "
                                    "and every pick then uses them.")
        self.fingers_btn.clicked.connect(self._fingers_check)
        # how many put-downs: every angle from both sides at 2 places, or at 1 (half the time; 6 is the least trusted)
        self.fingers_size = QComboBox()
        self.fingers_size.addItem("Full (20)", 2)
        self.fingers_size.addItem("Quick (10)", 1)
        self.fingers_size.setToolTip("Full: 2 places x 5 angles x from below and above (20 put-downs, about 7 min). "
                                     "Quick: 1 place (10 put-downs, about 3.5 min); enough to be trusted, with room "
                                     "for a look or two the camera misses.")
        self.rotation_btn = QPushButton("Rotation pick test")
        self.rotation_btn.setToolTip("Puts the cube down turned at random 6 times, picks it the way prompts do, and "
                                     "measures how far the fingers were off its sides. Run it with the correction "
                                     "off, then on, to compare.")
        self.rotation_btn.clicked.connect(self._rotation_test)
        self.rotation_corrected = QCheckBox("correction on")
        self.rotation_corrected.setChecked(True)
        self.rotation_corrected.setToolTip("On: picks as prompts do them now (the fingers angle check's correction, "
                                           "the wrist coming to its angle from one side, the last 15 mm slowly). "
                                           "Off: as before, to compare.")
        # a step after the calibration lost the cube (the take-back missed, a move refused) and it was gripped again
        # on the Manual tab: the real gripper has no sensor, so this is how the panel learns it holds the cube again
        self.regrip_btn = QPushButton("Cube back in the gripper - continue")
        self.regrip_btn.setToolTip("After a step lost the cube: grip it again on the Manual tab (square, in the "
                                   "fingers' middle, resting on the table), then press this. The pick test, the fingers "
                                   "angle check and the rotation pick test can then run again.")
        self.regrip_btn.clicked.connect(self._cube_regripped)
        for button in (self.regrip_btn, self.pick_test_btn, self.fingers_btn, self.fingers_size, self.rotation_btn,
                       self.rotation_corrected, self.add_one_btn, self.add_two_btn, self.finish_cube_btn):
            next_flow.addWidget(button)
        cube_layout.addWidget(next_row)
        # what the last step said, here by its buttons (the full text is also at the foot of the column, far below)
        self.cube_said = QLabel("")
        self.cube_said.setWordWrap(True)
        self.cube_said.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.cube_said.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.cube_said.setVisible(False)
        cube_layout.addWidget(self.cube_said)
        cube_layout.addWidget(self.guide_btn)
        cube_layout.addWidget(self.cube_guide)
        layout.addWidget(cube_box)

        # ---- D. continuous: the calibration in use kept right by itself (calibration/continuous.py) -----------------
        continuous_box = self.continuous_box = QGroupBox("Continuous (keeps itself calibrated)")
        continuous_layout = QVBoxLayout(continuous_box)
        continuous_text = QLabel(
            "Keeps the calibration in use right by itself: every 10 s, while the arm is idle, the camera looks at the "
            "A4 sheet's corners and the still background. If the camera has moved a little (a bump, vibration, "
            "warming up), it corrects the calibration in small steps, keeps a correction only if the sheet then "
            "measures closer, and otherwise goes back to the last good one. The sheet moved instead: it says so and "
            "corrects nothing. More than 10 mm or 3° in all: it stops and asks for a calibration with the cube.\n\n"
            "1. Calibrate with the cube (and do the fingers angle check), Finish.\n"
            "2. Park the arm out of the sheet's way, and press the watcher's Find the paper.\n"
            "3. Press Start. That's all: it runs by itself from then on, also after the app is opened again. During "
            "a watcher run it doesn't look; corrections only happen between runs, and each run records them.")
        continuous_text.setWordWrap(True)
        continuous_layout.addWidget(continuous_text)
        self.continuous_start_btn = QPushButton("Start")
        self.continuous_start_btn.setToolTip("Remembers how the sheet and the background look now, through the "
                                             "calibration in use, and from then on keeps that calibration right.")
        self.continuous_stop_btn = QPushButton("Stop")
        self.continuous_stop_btn.setToolTip("No more looks or corrections; the calibration in use stays as it is.")
        self.continuous_look_btn = QPushButton("Look now")
        self.continuous_look_btn.setToolTip("One look straight away (it also looks every 10 s by itself).")
        self.continuous_log_btn = QPushButton("Show the log")
        self.continuous_log_btn.setToolTip("Every look and what it decided, one line each (a text file).")
        continuous_layout.addWidget(_wrapping_row(self.continuous_start_btn, self.continuous_stop_btn,
                                                  self.continuous_look_btn, self.continuous_log_btn))
        self.continuous_status = QLabel("Off.")
        self.continuous_status.setWordWrap(True)
        self.continuous_status.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.continuous_status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        continuous_layout.addWidget(self.continuous_status)
        self.continuous_said = QLabel("")
        self.continuous_said.setWordWrap(True)
        self.continuous_said.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.continuous_said.setVisible(False)
        continuous_layout.addWidget(self.continuous_said)
        continuous_box.setVisible(False)
        if continuous is not None:
            self.continuous_start_btn.clicked.connect(continuous.start)
            self.continuous_stop_btn.clicked.connect(lambda: continuous.stop())
            self.continuous_look_btn.clicked.connect(continuous.check_now)
            self.continuous_log_btn.clicked.connect(self._show_continuous_log)
            continuous.status.connect(self._continuous_said)
            self._continuous_said(*continuous.text)
        layout.addWidget(continuous_box)

        # ---- finishing --------------------------------------------------------------------------------------
        finish_box = QGroupBox("Finish, then check")
        finish = QVBoxLayout(finish_box)
        finish_text = self.finish_text = QLabel("5. Lower the tip until it just touches the table, then press the button. Without "
                             "this, every height the camera reports is too low by however far above the tip "
                             "the marker or your click was, and the arm would be sent into the table. It also "
                             "sets the safety floor.")
        finish_text.setWordWrap(True)
        finish.addWidget(finish_text)
        self.table_btn = QPushButton("5. Set table height (tip touching the table)")
        self.table_btn.clicked.connect(self._set_table_height)
        finish.addWidget(self.table_btn)
        self.verify_btn = QPushButton("Verify calibration (moves the arm)")
        self.verify_btn.setToolTip("Sends the tip to a few spots and finds it in the camera picture: "
                                   "the gap is the calibration's real error.")
        self.verify_btn.clicked.connect(self._verify)
        finish.addWidget(self.verify_btn)
        layout.addWidget(finish_box)

        # ---- camera position ------------------------------------------------------------------------------------
        camera_box = QGroupBox("Has the camera moved?")
        camera_row = QVBoxLayout(camera_box)
        self.check_camera_btn = QPushButton("Check camera position")
        self.check_camera_btn.clicked.connect(lambda: self.on_check_camera and self.on_check_camera(self._say))
        self.remember_btn = QPushButton("Remember this view as calibrated")
        self.remember_btn.setToolTip("Only when you know the calibration is good right now.")
        self.remember_btn.clicked.connect(lambda: self.on_remember_view and self.on_remember_view(self._say))
        camera_row.addWidget(_wrapping_row(self.check_camera_btn, self.remember_btn))
        camera_box.setVisible(on_check_camera is not None)
        layout.addWidget(camera_box)

        self.result_label = QLabel("")
        self.result_label.setWordWrap(True)
        # never wider than the panel: a long word (a folder's path) made it so, and cut off every line's end
        self.result_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.result_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.result_label)
        self.history_btn = QPushButton("Earlier calibrations / reset...")
        self.history_btn.setToolTip("Go back to one of the last 10 calibrations, or clear the one in use.")
        self.history_btn.clicked.connect(self._earlier_calibrations)
        layout.addWidget(self.history_btn)
        if self.recorder is not None:
            self.sessions_btn = QPushButton("Open the saved sessions folder")
            self.sessions_btn.clicked.connect(lambda: self._open_folder(self.recorder.root))
            layout.addWidget(self.sessions_btn)
        if on_reset_builtin is not None:
            builtin_btn = QPushButton("Use the built-in exact calibration")
            builtin_btn.clicked.connect(lambda: self._use_builtin(on_reset_builtin))
            layout.addWidget(builtin_btn)
        layout.addStretch()

        if self._progress is not None and getattr(self._progress, "paper", False):
            # (a paper run to carry on after a restart: it carries on as one, and finds the paper when it passes)
            self._paper_run = True
            if self.style_box.findData("paper") >= 0:
                self.style_box.setCurrentIndex(self.style_box.findData("paper"))
        self.style_box.currentIndexChanged.connect(lambda _i: self._show_style())
        self._show_style()
        self.progress.connect(lambda text: self._say(text))
        if self._clickable:
            self.video_widget.pixel_clicked.connect(self._on_pixel_clicked)
        self._refresh_samples()

    STYLE_TEXT = {
        "cube": "A cube in the gripper is put down at 6-20 spots and found by the camera each time: no marker, and "
                "the table's height comes from touching it. Follow the guide below.",
        "paper": "The cube calibration, with the cube gripped at the A4 sheet's centre and the sheet lined up under "
                 "the held cube; afterwards the camera finds where the sheet really is. Follow the guide below.",
        "continuous": "Not a calibration of its own: the one in use (made with the cube) kept right by itself, by "
                      "the A4 sheet's corners and the still background, while the app works.",
        "auto": "A printed marker on the tool is found by the camera as the arm moves it round; then step 5 (the "
                "table's height) below.",
        "hand": "Move the tip to a spot, click it in the picture, repeat; solve; then step 5 (the table's height) below.",
    }

    def _show_style(self) -> None:
        """Only the chosen way of calibrating; step 5 (touch the table) is the marker's and the clicks' own (the cube
        touches the table itself)."""
        style = self.style_box.currentData()
        if style not in self.STYLE_TEXT:          # (nothing chosen: a style this panel hasn't, e.g. by hand in demo)
            return
        for key, box in (("cube", self.cube_box), ("auto", self.auto_box), ("hand", self.hand_box),
                         ("continuous", self.continuous_box)):
            box.setVisible(key == style or (key == "cube" and style == "paper"))
        paper = style == "paper"
        self.cube_box.setTitle("Cube calibration with paper" if paper else "With a cube (no marker; the most accurate)")
        self.cube_guide.setHtml(PAPER_GUIDE if paper else CUBE_GUIDE)
        self.cube_btn.setText("Calibrate with a cube and paper" if paper else "Calibrate with a cube")
        for button in (self.paper_btn, self.lift_paper_btn, self.down_paper_btn):
            button.setVisible(paper)
        self.finish_text.setVisible(style in ("auto", "hand"))
        self.table_btn.setVisible(style in ("auto", "hand"))
        self.overview.setText(self.STYLE_TEXT[style] + (" The picture: wheel zooms, drag pans, R resets; clicking it "
                                                         "never moves the robot." if self._clickable else
                                                         " The 3D view: drag turns it, wheel zooms, R resets."))

    # ---- the continuous calibration -----------------------------------------------------------------------------
    def _continuous_said(self, text: str, tone: str = "") -> None:
        colour = _TONES.get(tone, "")
        self.continuous_status.setStyleSheet(f"color: {colour};" if colour else "")
        self.continuous_status.setText(text or "Off.")
        on = self.continuous is not None and self.continuous.on
        self.continuous_start_btn.setEnabled(not on)
        self.continuous_stop_btn.setEnabled(on)
        self.continuous_look_btn.setEnabled(on)

    def _show_continuous_log(self) -> None:
        from app.calibration.continuous import log_file
        path = log_file(self.calibration_path)
        if not path.exists():
            self._say("No log yet: it starts with the first look.", "warn")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    # ---- small helpers -------------------------------------------------------------------------------------------
    def _say(self, text: str, tone: str = "") -> None:
        colour = _TONES.get(tone, "")
        self.result_label.setStyleSheet(f"color: {colour};" if colour else "")
        # a path may break after its slashes (a zero-width space there), instead of running off the edge
        shown = text.replace("\\", "\\\u200b").replace("/", "/\u200b")
        self.result_label.setText(shown)
        # and by the buttons of the box in view (the foot of the column is often scrolled out of sight)
        for box, said in ((getattr(self, "cube_box", None), getattr(self, "cube_said", None)),
                          (getattr(self, "continuous_box", None), getattr(self, "continuous_said", None))):
            if box is None or said is None:
                continue
            said.setStyleSheet(f"color: {colour};" if colour else "")
            said.setText(shown)
            said.setVisible(box.isVisibleTo(self) and bool(text))

    def _open_folder(self, folder: Path) -> None:
        folder.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))

    def _set_marks(self, marks: list[dict]) -> None:
        """Set the verification marks (an empty list clears them); the clicked points stay."""
        self._verify_marks = list(marks)
        self._apply_marks()

    def _sample_marks(self) -> list[dict]:
        """Where each calibration point was clicked, as small numbered dots; the one selected in
        the list is picked out with a ring, so a mis-click is easy to see."""
        selected = self.sample_list.currentRow()
        marks = [{"u": u, "v": v, "kind": "sample", "label": str(i + 1)}
                 for i, (u, v, _depth) in enumerate(self.calibrator.samples_pixel) if i != selected]
        if 0 <= selected < len(self.calibrator.samples_pixel):
            u, v, _depth = self.calibrator.samples_pixel[selected]
            marks.append({"u": u, "v": v, "kind": "selected", "label": f"#{selected + 1}"})
        return marks

    def _apply_marks(self) -> None:
        if hasattr(self.video_widget, "set_marks"):
            self.video_widget.set_marks(self._sample_marks() + self._touch_marks() + self._verify_marks)

    def _touch_marks(self) -> list[dict]:
        """Where the table was touched, on the camera picture (T1, T2...), as the calibration in use puts it there
        (a rough one puts them roughly)."""
        transform = self._current_transform()
        if not self._touches or transform is None:
            return []
        try:
            k = self.camera.get_intrinsics()
            to_camera = np.linalg.inv(np.asarray(transform, float))
        except Exception:  # noqa: BLE001 - no picture marks is no reason to stop
            return []
        marks = []
        for i, (x, y, z) in enumerate(self._touches):
            q = to_camera @ np.array([x, y, z, 1.0])
            if q[2] > 1.0:
                u, v = k.fx * q[0] / q[2] + k.cx, k.fy * q[1] / q[2] + k.cy
                if 0 <= u < k.width and 0 <= v < k.height:
                    marks.append({"u": u, "v": v, "kind": "touch", "label": f"T{i + 1}"})
        return marks

    def _show_touches(self) -> None:
        """The list under the touch buttons, and the marks on the picture."""
        # with touches to spare, the one that is off (pressed into the table, or not quite on it), to take away with its
        # button: told only with 6 or more (TableHeights.odd_one); with 4 or 5, only that they disagree
        heights = TableHeights(self._touches) if len(self._touches) >= 4 else None
        odd = heights.odd_one() if heights is not None else None
        lines = []
        for i, (x, y, z) in enumerate(self._touches):
            line = (f"T{i + 1}: x {x:.0f}, y {y:.0f} mm ({math.hypot(x, y) / 10:.0f} cm from the robot's middle), "
                    f"table z = {z:.1f} mm")
            if i == odd:
                others = TableHeights(self._touches[:i] + self._touches[i + 1:])
                line += (f"  <- check this one: {z - others.at(x, y):+.1f} mm off the others, which agree without "
                         "it")
            lines.append(line)
        if heights is not None and odd is None and heights.spread_mm() > ODD_OFF_MM / 2:
            lines.append(f"The touches disagree by up to {heights.spread_mm():.1f} mm: one may be off. "
                         + ("Touch all 6 points: then the odd one is marked." if len(self._touches) < 6 else
                            "No single one stands out: if in doubt, Forget touches and touch them again."))
        if len(self._touches) == 1:
            lines.append("One touch so far: touch the table once more, at the other end of the reach (stretched "
                         "out, or beside the cube).")
        missing = [f"{n}" for n, (name, x, y) in enumerate(TOUCH_POINTS, start=1)
                   if not any(math.hypot(x - tx, y - ty) < TOUCH_SAME_MM for tx, ty, _ in self._touches)]
        if self._touches and missing:
            lines.append(f"Touch points not touched yet: {', '.join(missing)} (of {len(TOUCH_POINTS)}).")
        self.touches_list.setText("\n".join(lines))
        self.touches_list.setVisible(bool(lines))
        if self._touches and not missing:
            level, words = TableHeights(self._touches).verdict()
            mark, tone = {"good": ("✓", "good"), "usable": ("⚠", "warn"), "redo": ("✕", "bad")}[level]
            self.touch_verdict.setText(f"{mark}  {words}")
            self.touch_verdict.setStyleSheet(f"color: {_TONES[tone]}; border-top: 1px solid #2b4250; "
                                             "padding-top: 6px; margin-top: 2px;")
        self.touch_verdict.setVisible(bool(self._touches) and not missing)
        for button in self.touch_remove_btns:
            self.touch_remove_flow.removeWidget(button)
            button.deleteLater()
        self.touch_remove_btns = []
        for i in range(len(self._touches)):
            button = QPushButton(f"Remove T{i + 1}")
            button.setToolTip(f"Takes away touch T{i + 1} only (the others are kept); then touch there again.")
            button.clicked.connect(lambda _c=False, n=i: self._remove_touch(n))
            self.touch_remove_flow.addWidget(button)
            self.touch_remove_btns.append(button)
        self.touch_remove_row.setVisible(bool(self._touches))
        self._apply_marks()

    def _remove_touch(self, index: int) -> None:
        """One touch taken away (the others kept)."""
        if self._worker is not None or self._cube_phase1 is not None or not 0 <= index < len(self._touches):
            return
        x, y, z = self._touches.pop(index)
        if not self._touches:
            self._touched_at = None
        self.touch_label.setText(f"Table: {TableHeights(self._touches).describe()}" if self._touches else
                                 "Table: not touched yet")
        self._show_touches()
        self._refresh_buttons()
        logger.info("Calibration: table touch T%d (x %.0f, y %.0f, z %.1f) taken away", index + 1, x, y, z)
        self._say(f"Touch T{index + 1} (z = {z:.1f} mm) taken away; {len(self._touches)} kept. Touch there again if "
                  "you like.", "good")

    def _go_touch_point(self) -> None:
        """The open gripper 20 mm above the touch point chosen, the wrist in its middle: up first, across, then down
        (the table's height from the touches so far; none yet: the safety floor's)."""
        if self._worker is not None or self._cube_phase1 is not None or self._arm_refused():
            return
        index = int(self.touch_point_box.currentData() or 0)
        name, x, y = TOUCH_POINTS[index]
        table = TableHeights(self._touches).at(x, y) if self._touches else float(self._bounds()["z"][0])
        z, r = table + 20.0, middle_turn(x, y)

        def go():
            self.robot.open_gripper()
            here = self.robot.get_pose()
            up = max(here.z, z + 40.0)
            self.robot.move_to(Pose(here.x, here.y, up, here.r))
            self.robot.move_to(Pose(x, y, up, r))
            self.robot.move_to(Pose(x, y, z, r))
            return z
        self._say(f"Going above touch point {index + 1} ({name})...")
        self._start_worker(go, lambda _z: self._say(
            f"The open gripper is about 20 mm above touch point {index + 1} ({name}: x {x:.0f}, y {y:.0f}). On the "
            "Manual tab, jog it straight down, the smallest step for the last few mm, until the fingertips just touch "
            "the table; then press 'Fingertips on the table'.", "good"),
            lambda message: self._say(f"Couldn't go above touch point {index + 1}: {message}", "bad"))

    def _current_transform(self) -> Optional[np.ndarray]:
        """The calibration in use: the app's, if it says so, else the latest solve here. None if there is none (the
        app stands in the identity until it is calibrated: no camera point is anywhere near the robot by it)."""
        transform = self.get_transform() if self.get_transform is not None else self._transform
        if transform is None or np.allclose(np.asarray(transform, float), np.eye(4)):
            return None
        return transform

    def _bounds(self) -> dict:
        bounds = getattr(self.robot, "bounds", None)
        return bounds if bounds else {"x": [100.0, 320.0], "y": [-250.0, 250.0], "z": [-100.0, 150.0]}

    def _reach(self) -> float:
        return float(getattr(self.robot, "max_reach_mm", 300.0))

    def _refresh_buttons(self) -> None:
        idle = self._worker is None
        n = self.calibrator.num_samples()
        self.arm_btn.setEnabled(idle)
        self.reset_btn.setEnabled(idle)
        self.solve_btn.setEnabled(idle and n >= MIN_POINTS)
        self.remove_selected_btn.setEnabled(idle)
        self.remove_worst_btn.setEnabled(idle and self._last_result is not None and n > MIN_POINTS)
        self.table_btn.setEnabled(idle and self._transform is not None)
        self.verify_btn.setEnabled(idle and self._current_transform() is not None)
        self.auto_btn.setEnabled(idle)
        self.sheet_btn.setEnabled(idle)
        self.stop_btn.setEnabled(not idle)
        self.cube_btn.setEnabled(idle and self._cube_phase1 is None)
        self.touch_btn.setEnabled(idle and self._cube_phase1 is None)
        self.forget_touches_btn.setEnabled(idle and self._cube_phase1 is None and bool(self._touches))
        self.touch_point_btn.setEnabled(idle and self._cube_phase1 is None)
        for button in self.touch_remove_btns:
            button.setEnabled(idle and self._cube_phase1 is None)
        self.middle_btn.setEnabled(idle and self._cube_phase1 is None)
        # (the paper's steps as the touches: not while a finished run still holds the cube at its waiting place --
        # going to the paper's centre opens the gripper first)
        self.paper_btn.setEnabled(idle and self._cube_phase1 is None)
        self.lift_paper_btn.setEnabled(idle and self._cube_phase1 is None and self._paper_lift is None)
        self.down_paper_btn.setEnabled(idle and self._cube_phase1 is None and self._paper_lift is not None)
        if hasattr(self, "camera_setup_btn"):      # (it changes the camera: not under a running step)
            self.camera_setup_btn.setEnabled(idle)
        self.cube_stop_btn.setEnabled(not idle)
        self.cube_pause_btn.setEnabled(not idle and self._cube_running)
        carry_on = self._progress is not None and self._cube_phase1 is None
        for widget in (self.continue_btn, self.start_over_btn, self.progress_label):
            widget.setVisible(carry_on)
        self.continue_btn.setEnabled(idle)
        self.start_over_btn.setEnabled(idle)
        if carry_on:
            self.progress_label.setText(f"A run to carry on: {self._progress.describe()}."
                                        + (f" Stopped because {self._progress.why}." if self._progress.why else ""))
        self.history_btn.setEnabled(idle and self._cube_phase1 is None)
        unsaved = getattr(self, "_unsaved_cube", None)
        self.save_anyway_btn.setVisible(unsaved is not None)
        self.save_anyway_btn.setEnabled(idle)
        if unsaved is not None:
            self.save_anyway_btn.setText(f"Save it anyway ({unsaved.typical_mm:.2f} mm)")
        self.style_box.setEnabled(idle and self._cube_phase1 is None and self._progress is None)
        waiting = idle and self._cube_phase1 is not None
        fingers = self.gripper is None or getattr(self.gripper, "fingers", True)
        for button in (self.pick_test_btn, self.add_one_btn, self.add_two_btn, self.finish_cube_btn):
            button.setVisible(waiting)
        for button in (self.fingers_btn, self.fingers_size, self.rotation_btn, self.rotation_corrected):
            button.setVisible(waiting and fingers)
        # the steps that start from the cube held need it held: after one lost it, they wait for it gripped again
        lost = waiting and not self._cube_phase1.holding
        self.regrip_btn.setVisible(lost)
        for button, what in ((self.pick_test_btn, "The pick test"), (self.fingers_btn, "The fingers angle check"),
                             (self.rotation_btn, "The rotation pick test")):
            button.setEnabled(not lost)
            tip = button.toolTip().split("\n\nNot now:")[0]
            button.setToolTip(tip + (f"\n\nNot now: {what.lower()} starts from the cube held, and the last step lost "
                                     "it. Grip it again on the Manual tab, then press 'Cube back in the gripper - "
                                     "continue'." if lost else ""))

    def _start_worker(self, work: Callable, done: Callable, failed: Callable, *args) -> None:
        self._cancel.clear()
        worker = CallableWorker(work, *args)
        self._worker = worker

        def finish(handler):
            def wrapper(value):
                self._worker = None
                self._refresh_buttons()
                handler(value)
            return wrapper
        worker.finished_ok.connect(finish(done))
        worker.failed.connect(finish(failed))
        self._refresh_buttons()
        worker.start()

    def shutdown(self) -> None:
        """Called when the window closes: ask a running calibration to stop, and wait for it. (The window doesn't close
        under a running step: it asks, stops it and closes once it has -- Stop finishes the move and puts the cube down,
        longer than this waits. Only if you close it anyway is anything still running here.)"""
        self._cancel.set()
        if self._worker is not None:
            self._worker.wait(10000)

    def _arm_refused(self) -> bool:
        """The app's check before a step moves the arm: True (and why, said) if something else has it now."""
        why = self.arm_busy() if self.arm_busy is not None else None
        if why:
            self._say(f"Not now: {why}.", "bad")
            return True
        return False

    def _stop(self) -> None:
        self._cancel.set()
        self._say("Stopping after the current move... (E-STOP stops immediately.)", "warn")

    # ---- the print sheet -------------------------------------------------------------------------------------------
    def _save_sheet(self) -> None:
        try:
            path = make_marker_sheet(self.markers_dir / "dobot_marker_A4.png")
        except Exception as exc:  # noqa: BLE001
            self._say(f"Could not write the marker sheet: {exc}", "bad")
            return
        self._open_folder(path.parent)
        self._say(f"Saved {path}. Print it at 100% / actual size (not 'fit to page') and check the 100 mm bar "
                  "with a ruler. Use the 30 mm marker if the camera is within about 0.5 m of the arm, "
                  "otherwise the 40 mm one.")

    # ---- by-hand samples ---------------------------------------------------------------------------------------------
    def _use_builtin(self, restore: Callable[[], None]) -> None:
        restore()
        self._reset()
        self._say("Restored the simulator's built-in exact calibration.")

    def _arm(self) -> None:
        self._armed = True
        self.status_label.setText("Click the middle of the tool's body in the camera view now...")

    def _reset(self) -> None:
        self.calibrator.reset()
        self._last_result = None
        if self.recorder is not None:
            self.recorder.clear()
        self._forget_solve()
        self._set_marks([])
        self._update_status()
        self._say("")

    def _remove_selected(self) -> None:
        row = self.sample_list.currentRow()
        if row < 0:
            self._say("Select a point in the list first.")
            return
        self._remove(row)

    def _remove_worst(self) -> None:
        if self._last_result is None:
            return
        self._remove(self._last_result.worst_index)

    def _remove(self, index: int) -> None:
        self.calibrator.remove_sample(index)
        if self.recorder is not None and index < len(self.recorder.samples):
            self.recorder.remove(index)
        self._last_result = None  # the old result no longer matches the points
        self._forget_solve()
        self._update_status()
        self._say(f"Removed point #{index + 1}. Press Solve to see the new result.")

    def _refresh_samples(self) -> None:
        """Rebuild the list, the coverage map and the advice from the current points."""
        result = self._last_result
        kept_row = self.sample_list.currentRow()
        self.sample_list.clear()
        for i, (robot_xyz, (u, v, depth)) in enumerate(zip(self.calibrator.samples_robot,
                                                            self.calibrator.samples_pixel)):
            text = (f"#{i + 1}  robot=({robot_xyz[0]:.0f},{robot_xyz[1]:.0f},{robot_xyz[2]:.0f})  "
                    f"px=({u:.0f},{v:.0f})  depth={depth:.0f}mm")
            suspect = False
            if result is not None and i < len(result.residuals_mm):
                text += f"  |  fit {result.residuals_mm[i]:.1f} mm"
                if result.measurable:
                    text += f", left out {result.loo_errors_mm[i]:.1f} mm"
                suspect = i in result.suspects
                if suspect:
                    text += "  <-- check this one"
            item = QListWidgetItem(text)
            if suspect:
                item.setForeground(QColor("#ff8a8a"))
            self.sample_list.addItem(item)
        cells = build_cells(self._bounds(), self._reach())
        points_xy = [(p[0], p[1]) for p in self.calibrator.samples_robot]
        suspects = result.suspects if result is not None else []
        self.coverage_map.set_state(cells, points_xy, suspects)
        self.advice_label.setText(advice(self.calibrator.num_samples(), cells, points_xy, suspects))
        if 0 <= kept_row < self.sample_list.count():
            self.sample_list.setCurrentRow(kept_row)   # the list was rebuilt; keep the same point selected
        self._apply_marks()
        self._refresh_buttons()

    def _on_pixel_clicked(self, u: int, v: int) -> None:
        if not self._armed or self._worker is not None:
            return
        self._armed = False
        frame = self.camera.get_frame()
        if frame.depth is None:
            self._say("No depth at this frame; try again.")
            return
        depth_mm = foreground_depth(frame.depth, u, v)
        if depth_mm <= 0:
            self._say("No valid depth at that pixel; click elsewhere.")
            return
        pose = self.robot.get_pose()
        self.calibrator.add_sample((pose.x, pose.y, pose.z), (u, v), depth_mm)
        if self.recorder is not None:
            self.recorder.add(SampleRecord((pose.x, pose.y, pose.z), (u, v), depth_mm, "manual",
                                           rgb=frame.rgb.copy(), depth=frame.depth.copy()))
        self._last_result = None  # a new point makes the last solve stale
        self._forget_solve()
        self._set_marks([])
        self._update_status()

    def _update_status(self) -> None:
        n = self.calibrator.num_samples()
        self.status_label.setText(f"Samples: {n} (minimum {MIN_POINTS}, recommended {RECOMMENDED_POINTS}+)")
        self._refresh_samples()

    def _forget_solve(self) -> None:
        """The points changed, so the last solve (and its height step) no longer applies."""
        self._transform = None
        self._refresh_buttons()

    @staticmethod
    def _scale_note(result) -> str:
        """A line on the camera's distance scale, when the calibration measured one (see calibration/solver.py)."""
        scale = getattr(result, "scale", 1.0)
        if abs(scale - 1.0) < 1e-6 or result.unscaled_error_mm is None:
            return ""
        return (f"\nThe camera's distances came out {abs(1.0 / scale - 1.0) * 100:.0f}% "
                f"{'long' if scale < 1.0 else 'short'}; that is allowed for (without it the error was "
                f"{result.unscaled_error_mm:.1f} mm).")

    def _quality(self, honest: float) -> str:
        return "good" if honest < 6.0 else ("usable" if honest < 10.0 else "poor - retake or add points")

    def _solve(self) -> None:
        try:
            result = self.calibrator.solve_detailed()
        except Exception as exc:
            self._say(f"Solve failed: {exc}")
            return
        self._last_result = result
        self._transform = result.transform
        honest = result.honest_error_mm
        # This is what gets saved and used for the safety margin: the honest number, not the flattering fit.
        save_calibration(
            self.calibration_path, result.transform, self.camera.get_intrinsics(),
            method="boardless", reprojection_error_mm=honest, num_samples=self.calibrator.num_samples(),
            extras=self._camera_extras(),
        )
        n = self.calibrator.num_samples()
        if result.measurable:
            text = (f"Solved. Typical error placing a point: {honest:.1f} mm ({self._quality(honest)}).\n"
                    "That is measured by predicting each point from all the others, so it includes "
                    "click noise -- the calibration itself is likely better than this.\n"
                    f"(The fit's own error, {result.fit_error_mm:.1f} mm, flatters it: ignore that one.)")
        else:
            text = (f"Solved with {n} points, but the real error can't be measured: nothing is left "
                    f"over to check against. Assuming at least {honest:.0f} mm; in simulation 3 points "
                    "was ~6 mm typically and ~18 mm in the worst 10% of runs. Add points to see a real number.")
        text += self._scale_note(result)
        if result.suspects:
            listed = ", ".join(f"#{i + 1}" for i in result.suspects)
            text += f"\nPoint {listed} disagrees with the rest and may be a mis-click -- try 'Remove worst point'."
        text += ("\n\nNOT FINISHED: step 5. Until you set the table height, heights are too low by the distance "
                 "from the tip to where you clicked, and the arm would be sent into the table.")
        if self.recorder is not None:
            self.recorder.set_result(method="boardless", honest_error_mm=honest, fit_error_mm=result.fit_error_mm,
                                     loo_errors_mm=result.loo_errors_mm, suspects=result.suspects,
                                     transform=result.transform, scale=result.scale,
                                     unscaled_error_mm=result.unscaled_error_mm)
            self.recorder.save()
        self._say(text, "warn")
        self._refresh_samples()
        self.on_calibrated(result.transform, honest)

    # ---- automatic calibration ----------------------------------------------------------------------------------------
    def _start_auto(self) -> None:
        if self._worker is not None or self._arm_refused():
            return
        try:
            start = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001
            self._say(f"Can't read the robot's position: {exc}", "bad")
            return
        radius = math.hypot(start.x, start.y)
        if not (min_radius_mm() <= radius <= REACH_FRACTION * self._reach()):
            self._say(f"The tip is {radius:.0f} mm out from the robot's base. Jog it to the middle of the workspace "
                      f"first, between {min_radius_mm():.0f} and {REACH_FRACTION * self._reach():.0f} mm out (the arm "
                      "can't reach down to the table nearer the base than that), 60 to 100 mm above the table.",
                      "bad")
            return
        reply = QMessageBox.question(
            self, "Start automatic calibration?",
            f"The arm will move to about a dozen positions across the workspace, starting from where it is now "
            f"(tip at z = {start.z:.0f} mm), never lower than that, and turn its wrist at one spot.\n\n"
            "Is the tip safely above the table (60 to 100 mm) and the area clear? E-STOP always works.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        self._set_marks([])
        marker_mm = float(self.marker_size.currentData())
        self._say("Starting...")
        self._start_worker(self._run_auto, self._auto_done, self._auto_failed, marker_mm)

    def _run_auto(self, marker_mm: float) -> AutoOutcome:
        return run_auto_calibration(self.robot, self.camera, self._bounds(), self._reach(), marker_mm,
                                    on_progress=self.progress.emit, cancel=self._cancel.is_set)

    def _auto_failed(self, message: str) -> None:
        self._say(f"The automatic calibration stopped: {message}", "bad")

    def _auto_done(self, outcome: AutoOutcome) -> None:
        if outcome.cancelled:
            self._say("Stopped. Nothing was changed.", "warn")
            return
        if len(outcome.sightings) < MIN_FOUND or outcome.solve is None:
            self._say(f"The marker was found at only {len(outcome.sightings)} of {outcome.poses_tried} positions "
                      f"(at least {MIN_FOUND} are needed). Check that it is printed at full size, flat, facing the "
                      "camera, well lit, and that the marker size chosen here matches the one you stuck on. "
                      "Nothing was changed.", "bad")
            return
        self.calibrator.reset()
        if self.recorder is not None:
            self.recorder.clear()
        for s in outcome.sightings:
            self.calibrator.add_sample(s.robot_xyz, s.centre_uv, s.depth_mm)
            if self.recorder is not None:
                self.recorder.add(SampleRecord(s.robot_xyz, s.centre_uv, s.depth_mm, "marker",
                                               rgb=None if s.rgb is None else s.rgb.copy(),
                                               depth=None if s.depth is None else s.depth.copy()))
        self._last_result = outcome.solve
        self._transform = outcome.transform
        honest = outcome.solve.honest_error_mm
        save_calibration(self.calibration_path, outcome.transform, self.camera.get_intrinsics(),
                         method="marker", reprojection_error_mm=honest, num_samples=len(outcome.sightings),
                         extras=self._camera_extras())
        text = (f"Automatic calibration done: the marker was found at {len(outcome.sightings)} of "
                f"{outcome.poses_tried} positions. Typical error {honest:.1f} mm ({self._quality(honest)}).")
        if outcome.wrist is not None:
            w = outcome.wrist
            text += (f"\nThe marker turned out to be {w.distance_mm:.1f} mm off the tool's axis "
                     f"({w.offset_xy_mm[0]:+.1f}, {w.offset_xy_mm[1]:+.1f}); that was taken out.")
        else:
            text += (f"\nCould not find how far off-centre the marker is ({outcome.wrist_note}). "
                     "If it is stuck exactly over the tool it doesn't matter; otherwise positions can be off "
                     "sideways by that much.")
        text += self._scale_note(outcome.solve)
        if outcome.solve.suspects:
            text += "\nSome sightings disagree with the rest: " + ", ".join(f"#{i + 1}" for i in outcome.solve.suspects) + "."
        text += "\n\nNOT FINISHED: step 5. Lower the tip until it touches the table and press the button."
        if self.recorder is not None:
            w = outcome.wrist
            self.recorder.set_result(method="marker", honest_error_mm=honest, fit_error_mm=outcome.solve.fit_error_mm,
                                     loo_errors_mm=outcome.solve.loo_errors_mm, suspects=outcome.solve.suspects,
                                     transform=outcome.transform, scale=outcome.solve.scale,
                                     unscaled_error_mm=outcome.solve.unscaled_error_mm)
            self.recorder.set_auto({"poses_tried": outcome.poses_tried, "sightings": len(outcome.sightings),
                                    "wrist_offset_mm": None if w is None else list(w.offset_xy_mm),
                                    "wrist_direction": None if w is None else w.direction,
                                    "wrist_residual_mm": None if w is None else w.residual_mm,
                                    "wrist_note": outcome.wrist_note})
            self.recorder.save()
        self._say(text, "warn")
        self._refresh_samples()
        self.on_calibrated(outcome.transform, honest)

    # ---- calibration with a cube ------------------------------------------------------------------------------------
    def _show_guide(self, shown: bool) -> None:
        self.cube_guide.setVisible(shown)
        self.guide_btn.setText("Hide the step-by-step guide" if shown else "Show the step-by-step guide")

    def _wrist_to_middle(self) -> None:
        if self._worker is not None or self._arm_refused():
            return
        try:
            pose = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001
            self._say(f"Can't read the robot's position: {exc}", "bad")
            return
        target = Pose(pose.x, pose.y, pose.z, middle_turn(pose.x, pose.y))
        self._start_worker(lambda: self.robot.move_to(target),
                           lambda _r: (self.done_steps.__setitem__("middle", target),
                                       self._say("The wrist is in its middle (the gripper along the arm). Now lower "
                                                 "the open gripper round the cube and close it.", "good")),
                           lambda message: self._say(f"The wrist couldn't turn: {message}", "bad"))

    def _touch_table(self) -> None:
        if self._worker is not None or self._arm_refused():
            return
        try:
            pose = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001
            self._say(f"Can't read the robot's position: {exc}", "bad")
            return
        if not self._touches:
            self._touched_at = time.monotonic()
        self._touches = with_touch(self._touches, (pose.x, pose.y, pose.z))
        heights = TableHeights(self._touches)
        last = load_calibration(self.calibration_path)
        last_z = (last.extras or {}).get("table_z") if last is not None else None
        warnings = arm_check(self._touches, last_z, getattr(self.robot, "homed", True) is not False)
        self.touch_label.setText(f"Table: {heights.describe()}")
        self._show_touches()
        missing = [n for n, (_name, x, y) in enumerate(TOUCH_POINTS)
                   if not any(math.hypot(x - tx, y - ty) < TOUCH_SAME_MM for tx, ty, _ in self._touches)]
        if missing:                                          # the next touch point not touched yet, offered
            self.touch_point_box.setCurrentIndex(missing[0])
        reach = math.hypot(pose.x, pose.y)
        if heights.too_steep:
            nxt, tone = (heights.verdict()[1] if heights.agreed else
                         "These touches disagree too much: one pressed into the table or missed it. Press 'Forget "
                         "touches' and touch it again."), "bad"
        elif len(self._touches) == 1:
            nxt, tone = ("Better: touch it once more, with the arm stretched out about 27 cm (or beside the cube, if "
                         "this one was stretched out); then grip the cube (step 2)." if reach < 240.0 else
                         "Now touch it beside the cube too, then grip the cube (step 2)."), "good"
        elif missing:
            nxt, tone = (f"Next: {self.touch_point_box.currentText().lower()} ('Go above it', then touch). "
                         f"All {len(TOUCH_POINTS)} give the table's height over the whole sheet, with touches to "
                         "spare."), "good"
        else:
            nxt, tone = ("Close the gripper on the cube (step 2), then press 'Calibrate with a cube'. (Grip it "
                         "beside the last touch: the arm is now 1 mm above the table there.)"), "good"
        if warnings and tone != "bad":
            nxt, tone = "Arm check: " + "; ".join(warnings) + ".", "warn"
        up = Pose(pose.x, pose.y, pose.z + GRIP_ABOVE_TABLE_MM, pose.r)
        self._refresh_buttons()
        self.done_steps["touch"] = (pose.x, pose.y, pose.z)
        self._start_worker(lambda: self.robot.move_to(up),
                           lambda _r: self._say(f"Table height recorded here: z = {pose.z:.1f} mm, at "
                                                f"{reach:.0f} mm from the robot's middle (table: {heights.describe()}). "
                                                f"The fingertips are now {GRIP_ABOVE_TABLE_MM:.0f} mm above it. "
                                                + nxt, tone),
                           lambda message: self._say(f"Table height recorded (z = {pose.z:.1f} mm), but the arm "
                                                     f"couldn't rise: {message}", "warn"))

    def _forget_touches(self) -> None:
        self._touches, self._touched_at = [], None
        self.touch_label.setText("Table: not touched yet")
        self._show_touches()
        self._refresh_buttons()
        self._say("The table touches are forgotten. Touch it again: stretched out, then beside the cube.", "good")

    def _camera_extras(self) -> dict:
        """What the camera was like when a calibration was made, saved with it: whether the pictures were straightened
        for the lens, and the depth preset (Settings > Camera). Either changing later makes the calibration a bit off."""
        extras = {"undistorted": getattr(self.camera, "_undistorter", None) is not None}
        preset = getattr(self.camera, "depth_preset", None)
        if preset:
            extras["depth_preset"] = preset
        return extras

    def _start_cube(self, confirm: bool = True) -> None:
        """`confirm` False: start without the questions (the demo's walk-through shows them in its own panel)."""
        if self._worker is not None or self._arm_refused():
            return
        if self._progress is not None and not confirm:
            self._discard_progress()
        if self._progress is not None:
            reply = QMessageBox.question(
                self, "Start a new cube calibration?",
                f"A cube calibration is part-way through ({self._progress.describe()}). Start a new one? The spots "
                "measured so far are thrown away.\n\n(To carry on with it instead: answer No, grip the cube and "
                "press 'Manually gripped - continue'.)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if reply != QMessageBox.StandardButton.Yes:
                return
            self._discard_progress()
        try:
            start = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001
            self._say(f"Can't read the robot's position: {exc}", "bad")
            return
        mode = self.cube_mode.currentData()
        if not self._touches:
            table = (f"You haven't pressed 'Fingertips on the table': the table is taken as {GRIP_ABOVE_TABLE_MM:.0f} "
                     f"mm below the fingertips (z = {start.z - GRIP_ABOVE_TABLE_MM:.1f} mm), the same everywhere.")
        else:
            heights = TableHeights(self._touches)
            here = heights.at(start.x, start.y)
            table = (f"The fingertips are {start.z - here:.1f} mm above the table (table: {heights.describe()}).")
            if len(self._touches) == 1:
                table += (" Touched at one place only: stretched out, the cube may be let go a few mm high. Better: "
                          "answer No and touch it with the arm stretched out too.")
        warm = camera_warm(self.camera)
        warning = ("\n\nThe camera was switched on only "
                   f"{warm / 60:.0f} minutes ago: its distances drift for the first {CAMERA_WARM_S / 60:.0f}. "
                   "Calibrating now is less accurate." if warm is not None and warm < CAMERA_WARM_S else "")
        if getattr(self.robot, "homed", True) is False:
            warning += ("\n\nThe Dobot hasn't been homed since the app connected to it. If it was switched off and "
                        "on since, its coordinates can be centimetres out: answer No, press Home (Manual tab), touch "
                        "the table again and grip the cube.")
        homed_at = getattr(self.robot, "homed_at", None)
        if homed_at is not None and self._touched_at is not None and homed_at > self._touched_at:
            warning += ("\n\nThe arm was homed after the table was touched: better forget the touches and touch it "
                        "again.")
        self._paper_run = self.style_box.currentData() == "paper"
        if self._paper_run and self._paper_lift is not None:
            # (the calibration measures how the cube is held from where the fingertips are now: lifted, every spot
            # would let it go from that height)
            self._say("The cube is still lifted for the paper: press 'Put it back down' first. The cube must rest on "
                      "the paper when the calibration starts.", "bad")
            return
        if self._paper_run:
            from app.vision.paper import DESIGNED_CENTRE
            away = math.hypot(start.x - DESIGNED_CENTRE[0], start.y - DESIGNED_CENTRE[1])
            if away > 15.0:
                warning += (f"\n\nThe gripper is {away:.0f} mm from the paper's centre ({DESIGNED_CENTRE[0]:.0f}, "
                            f"{DESIGNED_CENTRE[1]:.0f}): with paper, grip the cube on the centre outline (press "
                            "'Go to the paper's centre' first).")
        off_middle = (start.r - middle_turn(start.x, start.y) + 180.0) % 360.0 - 180.0
        if abs(off_middle) > 15.0:
            warning += (f"\n\nThe wrist is turned {off_middle:+.0f} degrees from its middle. Better: answer No, open "
                        "the gripper, lift it clear, press 'Wrist to middle', and grip the cube again.")
        reply = QMessageBox.StandardButton.Yes if not confirm else QMessageBox.question(
            self, "Calibrate with a cube?",
            f"The gripper must be closed on a cube that rests on the table (now at x = {start.x:.0f}, "
            f"y = {start.y:.0f}, z = {start.z:.1f} mm). {table}\n\n"
            f"The arm will put the cube at {self.cube_spots.value()} spots across the table, the wrist in its middle, "
            "and centre the cube in the gripper each time; the camera looks at it each time (about "
            f"{dict(precise=12, quick=7, fast=4)[mode]} minutes). Is the table clear "
            f"but for the cube? E-STOP always works.{warning}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        self._unsaved_cube = None             # (a new run: the last one's over-the-limit result is no longer offered)
        self._set_marks([])
        self._say("Starting...")
        self._pause.clear()
        self._cube_running = True
        self._start_worker(self._run_cube, self._cube_done, self._cube_failed)

    def _run_cube(self) -> CubeOutcome:
        return run_cube_calibration(self.robot, self.camera, self._bounds(), self._reach(), self.gripper,
                                    old_transform=self._current_transform(), mode=self.cube_mode.currentData(),
                                    spots=self.cube_spots.value(), table_touches=list(self._touches) or None,
                                    cube_size_mm=self.cube_size.value() or None, on_progress=self.progress.emit,
                                    cancel=self._cancel.is_set, on_save=self._save_progress, pause=self._pause.is_set)

    def _save_progress(self, progress: CubeProgress) -> None:
        """(the worker's thread) After every spot: kept on disk, so a run survives the app being closed -- whether it
        is a paper run too."""
        progress.paper = bool(self._paper_run)
        save_progress(self._progress_file, progress)
        self._progress = progress

    def _discard_progress(self) -> None:
        self._progress = None
        self._progress_file.unlink(missing_ok=True)

    def _pause_cube(self) -> None:
        self._pause.set()
        self._say("Pausing after the current move... (E-STOP stops at once.)", "warn")

    def _take_over_text(self, why: str) -> str:
        progress = self._progress
        return (f"Paused: {why}.\n\nTake over: on the Manual tab, jog the arm up and over the cube (wherever it is "
                "now), turn the wrist to match it if it is turned, lower the open gripper round it and close it, the "
                "cube resting on the table. Then press 'Manually gripped - continue'. "
                + (f"Kept so far: {progress.describe()}. " if progress is not None else "")
                + "Or press 'Start over'.")

    def _continue_cube(self) -> None:
        if self._worker is not None or self._progress is None or self._arm_refused():
            return
        try:
            start = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001
            self._say(f"Can't read the robot's position: {exc}", "bad")
            return
        progress = self._progress
        text = (f"Carry on with the cube calibration ({progress.describe()})?\n\nThe gripper must be closed on the "
                f"cube, the cube resting on the table (the gripper is now at x = {start.x:.0f}, y = {start.y:.0f}, "
                f"z = {start.z:.1f} mm). The robot squeezes it once in place, checks the camera hasn't moved and puts "
                "the cube back at the first spot to check the arm hasn't lost its place, then carries on.")
        pending = progress.pending or {}
        use_last = True
        if pending.get("measured") and pending.get("pair"):
            box = QMessageBox(self)
            box.setWindowTitle("Carry on?")
            box.setText(text + f"\n\nSpot {pending['index'] + 1} was measured just before it stopped (the robot was "
                        "going back for the cube). Use that measurement? Yes, unless the cube was knocked before the "
                        "camera looked at it.")
            use = box.addButton(f"Carry on, use spot {pending['index'] + 1}", QMessageBox.ButtonRole.AcceptRole)
            drop = box.addButton("Carry on without it", QMessageBox.ButtonRole.AcceptRole)
            box.addButton(QMessageBox.StandardButton.Cancel)
            box.exec()
            if box.clickedButton() not in (use, drop):
                return
            use_last = box.clickedButton() is use
        elif QMessageBox.question(self, "Carry on?", text, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                  QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        self._set_marks([])
        self._say("Carrying on...")
        # (a paper run carries on as one, also after a restart: the paper is found when it passes)
        self._paper_run = bool(getattr(progress, "paper", False))
        self._pause.clear()
        self._cube_running = True
        self._start_worker(lambda: self._resume_cube(progress, use_last), self._cube_done,
                           self._cube_failed)

    def _resume_cube(self, progress: CubeProgress, use_last: bool) -> CubeOutcome:
        return run_cube_calibration(self.robot, self.camera, self._bounds(), self._reach(), self.gripper,
                                    resume=progress, use_last=use_last, on_progress=self.progress.emit,
                                    cancel=self._cancel.is_set, on_save=self._save_progress, pause=self._pause.is_set)

    def _start_over(self) -> None:
        if self._worker is not None or self._progress is None:
            return
        if QMessageBox.question(
                self, "Start over?",
                f"Throw away the cube calibration part-way through ({self._progress.describe()})? The calibration in "
                "use doesn't change.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        self._discard_progress()
        forget = bool(self._touches) and QMessageBox.question(
            self, "The table touches too?",
            "Forget the table touches too? (Yes after Home, or if the table or the robot moved.)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes
        if forget:
            self._forget_touches()
        self._refresh_buttons()
        self._say("Thrown away. To start again: " + ("touch the table (stretched out, then by the cube), "
                                                     if forget or not self._touches else "")
                  + "grip the cube with the wrist in its middle and press 'Calibrate with a cube'.", "good")

    # ---- earlier calibrations ---------------------------------------------------------------------------------------
    @staticmethod
    def _calibration_text(calib, when: Optional[float]) -> str:
        made = time.strftime("%d %b %H:%M", time.localtime(when)) if when else "?"
        return (f"{made}: {calib.method}, {calib.reprojection_error_mm:.2f} mm, {calib.num_samples} points")

    def _earlier_calibrations(self) -> None:
        if self._worker is not None:
            return
        history = calibration_history(self.calibration_path)
        current = load_calibration(self.calibration_path)
        dialog = QDialog(self)
        dialog.setWindowTitle("Calibrations")
        dialog.setMinimumWidth(520)
        column = QVBoxLayout(dialog)
        when = self.calibration_path.stat().st_mtime if current is not None else None
        column.addWidget(QLabel("In use: " + (self._calibration_text(current, when) if current is not None
                                              else "none (picking by camera is off)")))
        column.addWidget(QLabel("Earlier ones, newest first:" if history else "No earlier ones kept yet."))
        choices = QListWidget()
        for _path, calib, made in history:
            choices.addItem(self._calibration_text(calib, made))
        if history:
            choices.setCurrentRow(0)
        column.addWidget(choices)
        row = QHBoxLayout()
        use_btn = QPushButton("Use the one chosen")
        use_btn.setEnabled(bool(history))
        clear_btn = QPushButton("Clear calibration")
        clear_btn.setToolTip("No calibration in use: picking by camera stops until you calibrate (the one in use is "
                             "kept in this list, to go back to).")
        clear_btn.setEnabled(current is not None)
        close_btn = QPushButton("Close")
        for button in (use_btn, clear_btn, close_btn):
            row.addWidget(button)
        column.addLayout(row)
        # the earlier ones themselves, taken away (to the Windows Recycle Bin: they can be put back from there)
        tidy = QHBoxLayout()
        delete_btn = QPushButton("Delete the one chosen")
        delete_btn.setToolTip("Takes the earlier calibration chosen out of this list (to the Windows Recycle Bin). The "
                              "one in use isn't touched.")
        delete_all_btn = QPushButton("Delete all earlier ones")
        delete_all_btn.setToolTip("Takes every earlier calibration out of this list (to the Windows Recycle Bin). The "
                                  "one in use isn't touched.")
        for button in (delete_btn, delete_all_btn):
            button.setEnabled(bool(history))
            tidy.addWidget(button)
        tidy.addStretch()
        column.addLayout(tidy)

        def show_list() -> None:
            choices.clear()
            for _path, calib, made in history:
                choices.addItem(self._calibration_text(calib, made))
            if history:
                choices.setCurrentRow(0)
            for button in (use_btn, delete_btn, delete_all_btn):
                button.setEnabled(bool(history))

        def delete(indices: list) -> None:
            from watcher.results import to_recycle_bin
            gone = 0
            for index in sorted(indices, reverse=True):
                try:
                    to_recycle_bin(history[index][0])
                except OSError as exc:
                    QMessageBox.warning(dialog, "Calibrations", f"Couldn't delete {history[index][0].name}: {exc}")
                    break
                logger.info("Calibration: the earlier calibration %s sent to the Recycle Bin", history[index][0].name)
                del history[index]
                gone += 1
            show_list()
            if gone:
                self._say(f"{gone} earlier calibration{'s' if gone != 1 else ''} deleted (to the Windows Recycle Bin).",
                          "good")

        def delete_chosen() -> None:
            index = choices.currentRow()
            if index < 0:
                return
            if QMessageBox.question(dialog, "Delete this calibration?",
                                    f"Delete the earlier calibration {choices.item(index).text()}? It goes to the "
                                    "Windows Recycle Bin.",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                    QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
                delete([index])

        def delete_all() -> None:
            if QMessageBox.question(dialog, "Delete all earlier calibrations?",
                                    f"Delete all {len(history)} earlier calibrations? They go to the Windows Recycle "
                                    "Bin. The one in use (if any) stays.",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                    QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
                delete(list(range(len(history))))
        delete_btn.clicked.connect(delete_chosen)
        delete_all_btn.clicked.connect(delete_all)

        def use() -> None:
            index = choices.currentRow()
            if index < 0:
                return
            calib = restore_calibration(self.calibration_path, history[index][0])
            dialog.accept()
            if calib is None:
                self._say("That calibration couldn't be read.", "bad")
                return
            self._transform = calib.transform_matrix()
            self.on_calibrated(calib.transform_matrix(), calib.reprojection_error_mm)
            self._refresh_buttons()
            self._say(f"Now in use: the calibration from {self._calibration_text(calib, history[index][2])}. (The "
                      "one replaced is in the list, to go back to.)", "good")

        def clear() -> None:
            if QMessageBox.question(dialog, "Clear the calibration?",
                                    "No calibration in use: picking by camera stops until you calibrate again. (The "
                                    "one in use is kept in the list, to go back to.)",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                    QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
                return
            clear_calibration(self.calibration_path)
            dialog.accept()
            self._transform = None
            if self.on_cleared is not None:
                self.on_cleared()
            self._refresh_buttons()
            self._say("The calibration is cleared. Calibrate again (or go back to an earlier one).", "warn")
        use_btn.clicked.connect(use)
        clear_btn.clicked.connect(clear)
        close_btn.clicked.connect(dialog.reject)
        dialog.exec()

    def _cube_failed(self, message: str) -> None:
        self.done_steps["cube"] = message
        self._cube_phase1 = None
        self._cube_running = False
        self._progress = load_progress(self._progress_file)
        self._refresh_buttons()
        self._say(f"The cube calibration stopped: {message}. Nothing was changed."
                  + (" The spots measured so far are kept: once the robot is ready (E-STOP released, alarms "
                     "cleared), grip the cube and press 'Manually gripped - continue', or 'Start over'."
                     if self._progress is not None else ""), "bad")

    def set_cube_size(self, size_mm: Optional[float]) -> None:
        """The cube size picked: 25 or 20 mm, another (typed, shown in the box), or None/0 for the camera's measure."""
        size = float(size_mm or 0.0)
        index = self.cube_size_choice.findData(size)
        if index < 0:
            self.cube_size.setValue(size)
            index = self.cube_size_choice.count() - 1          # (Other: the box shows it)
        self.cube_size_choice.setCurrentIndex(index)
        self._cube_size_chosen()

    def _cube_size_chosen(self) -> None:
        """A size picked: its value in the box behind it (what the calibration reads); the box shown for Other only."""
        value = self.cube_size_choice.currentData()
        other = value is None
        if not other:
            self.cube_size.setValue(float(value))
        elif not self.cube_size.value():
            self.cube_size.setValue(25.0)
        self.cube_size.setVisible(other)

    @staticmethod
    def _cube_size_text(outcome: CubeOutcome) -> str:
        if outcome.cube_mm is None:
            return ""
        narrow, long_, height = outcome.cube_mm
        text = f"Cube measured: {narrow:.1f} x {long_:.1f} mm, {height:.1f} mm tall (camera)"
        if outcome.gripper_mm is not None:
            text += f"; {outcome.gripper_mm[0]:.1f} x {outcome.gripper_mm[1]:.1f} mm (gripper)"
        return text + "."

    def _cube_report(self, outcome: CubeOutcome) -> str:
        fit = outcome.fit
        found = [entry for entry in outcome.spot_log if entry.get("found")]
        again = " and again at the first" if any(entry.get("spot") == "first again" for entry in found) else ""
        spots = [entry for entry in found if entry.get("spot") != "first again"]
        lines = [f"Calibrated with the cube ({outcome.mode}): found at {len(spots)} of "
                 f"{outcome.spots_tried} spots{again}, {len(outcome.used)} used. Each spot predicted from the others: "
                 f"typical {outcome.typical_mm:.2f} mm, worst {outcome.worst_mm:.2f} mm."
                 + (f" (The calibration before was {float(np.median(outcome.before_mm)):.1f} mm off at the same "
                    "spots.)" if outcome.before_mm else "")]
        if fit.tracked and fit.along is not None:
            pushed = len(fit.broken or [])
            lines.append(f"Grip: the cube's place in the fingers changed during the run (by up to "
                         f"{float(np.ptp(fit.along)):.1f} mm); the camera tracked it"
                         + (f"; {pushed} grip{'s' if pushed != 1 else ''} pushed as the fingers came down, "
                            "measured afresh there" if pushed else "") + ".")
        lines.append(f"Used: {fit.name}." + ("" if len(outcome.tried) < 2 else " Also tried: " + "; ".join(
            f"{f.name} {f.typical_mm:.2f} mm" for f in outcome.tried if f is not fit) + "."))
        plane = outcome.plane
        table = (f"Table: z = {outcome.table_z:.1f} mm ({outcome.table_from}); its surface fitted to {plane.points} "
                 f"depth points ({plane.rms_mm:.2f} mm from flat, typically).")
        if outcome.up_check_deg is not None and outcome.up_check_deg > 0.3:
            table += (f" Its 'up' and the cube spots' disagree by {outcome.up_check_deg:.1f} degrees: is the robot "
                      "level with the table?")
        lines.append(table)
        checks = []
        slip = outcome.slip_worst_mm if outcome.slip_worst_mm is not None else outcome.slip_mm
        if slip is not None:
            checks.append(f"slip check {slip:.2f} mm" + (" (the worst of the looks back)"
                                                       if outcome.slip_worst_mm is not None
                                                       and outcome.slip_mm is not None
                                                       and abs(outcome.slip_worst_mm - outcome.slip_mm) > 0.005
                                                       else ""))
        if outcome.tool_offset_mm is not None:
            dx, dy = outcome.tool_offset_mm
            without, with_d = outcome.tool_offset_gain
            if outcome.offset_used:
                tx, ty = outcome.total_offset
                checks.append(f"the gripper's middle is ({tx:+.1f}, {ty:+.1f}) mm from the robot's tool point: the "
                              "robot now moves by it, so the gripper's middle goes where it is sent")
            else:
                checks.append(f"the gripper's middle is about ({dx:+.1f}, {dy:+.1f}) mm from the robot's tool point "
                              "(not used: allowing for it didn't predict the spots better)")
        if outcome.sides_mm is not None:
            checks.append(f"the cube's sides agree with its top to {math.hypot(*outcome.sides_mm):.1f} mm")
        if outcome.fingers is not None:
            offset, scatter, n = outcome.fingers
            if outcome.jaw_axis_deg is None:
                checks.append(f"the fingers' angle couldn't be told ({n} spots scatter by {scatter:.1f} degrees): "
                              "not changed")
            elif abs(offset) >= 1.0:
                checks.append(f"the fingers point {offset:+.1f} degrees from where the app thought (from {n} spots, "
                              f"scattering {scatter:.1f}): allowed for from now on, every pick turns to match")
            else:
                checks.append(f"the fingers point where the app thinks ({offset:+.1f} degrees, from {n} spots)")
        if self.cube_size.value() and outcome.height_bias_mm is not None:
            checks.append(f"cube tops' height {outcome.height_bias_mm:+.1f} mm against the size you gave")
        if checks:
            lines.append("Checks: " + "; ".join(checks) + ".")
        lines.append(self._cube_size_text(outcome))
        if outcome.pattern:
            lines.append(f"The misses left: {outcome.pattern}. Arrows on the picture: each spot's miss, 15x larger.")
        if outcome.skipped:
            lines.append("Left out: " + "; ".join(outcome.skipped) + ".")
        notes = [n for n in outcome.notes if not n.startswith("the cube's place along the fingers changed")]
        if notes:                          # (that one is the Grip line above)
            lines.append("Note: " + "; ".join(notes) + ".")
        return "\n".join(line for line in lines if line)

    def _cube_done(self, outcome: CubeOutcome) -> None:
        self.done_steps["cube"] = outcome
        self._cube_running = False
        if outcome.keep_progress:
            self._progress = load_progress(self._progress_file) or self._progress
        else:
            self._discard_progress()
        self._refresh_buttons()
        if outcome.paused:
            self._say(self._take_over_text(outcome.reason), "warn")
            return
        if outcome.cancelled:
            where = ("Stopped with the cube still in the gripper (it couldn't be put down)" if outcome.holding else
                     "Stopped; the cube was put down")
            self._say(f"{where}. Nothing was changed. The spots measured so far are kept: to carry on, grip the cube "
                      "and press 'Manually gripped - continue'; or 'Start over'.", "warn")
            return
        if not outcome.passed:
            folder = self._record_failed_cube(outcome)
            text = f"Not calibrated: {outcome.reason} Nothing was changed."
            if outcome.fit is not None:
                text += "\n\n" + self._cube_report(outcome)
            if outcome.skipped and outcome.fit is None:
                text += "\nLeft out: " + "; ".join(outcome.skipped) + "."
            if folder is not None:
                text += (f"\nThe run's record (every spot, the first pictures) is saved as {folder.name} in the "
                         "sessions folder (button below).")
            if self._may_save_anyway(outcome):
                self._unsaved_cube = outcome
                text += (f"\n\nIt is over the limit only by its typical error ({outcome.typical_mm:.2f} mm): you can "
                         "still keep it with 'Save it anyway' (below), marked as over the limit.")
            self._refresh_buttons()
            self._say(text, "bad")
            return
        typical = outcome.typical_mm
        extras = self._cube_extras(outcome)
        paper_note, look_for_paper = "", False
        if self._paper_run:
            if self.place_cubes is not None:                   # (the demo: nothing to look at)
                pose, paper_note = self._twin_paper()
                extras["paper"] = pose.__dict__
            else:                                              # (after saving, in a worker: a few pictures)
                look_for_paper, paper_note = True, "\nPaper: the camera is looking for it..."
        save_calibration(self.calibration_path, outcome.transform, self.camera.get_intrinsics(),
                         method=(f"cube with paper ({outcome.mode})" if self._paper_run
                                 else f"cube ({outcome.mode})"), reprojection_error_mm=typical,
                         num_samples=len(outcome.used), extras=extras)
        self._transform = outcome.transform
        self._last_result = None
        self._cube_phase1 = outcome
        self._wrist_model = None              # a new calibration: its fingers angle check is still to do
        if self.recorder is not None:
            self.recorder.clear()
            for pair in outcome.used:
                s = pair.sighting
                self.recorder.add(SampleRecord(pair.robot_xyz(outcome.table_z, outcome.cube_h), s.pixel, s.depth_mm,
                                               "cube"))
            self.recorder.set_result(method="cube", honest_error_mm=typical, loo_errors_mm=outcome.fit.errors_mm,
                                     suspects=[], transform=outcome.transform, scale=outcome.fit.scale,
                                     fit=outcome.fit.name, tried={f.name: f.typical_mm for f in outcome.tried})
            self.recorder.set_auto({"method": "cube", "mode": outcome.mode, "spots_tried": outcome.spots_tried,
                                    "found": len(outcome.pairs), "used": len(outcome.used),
                                    "cube_mm": outcome.cube_mm, "cube_h": outcome.cube_h,
                                    "gripper_mm": outcome.gripper_mm, "z_offset_mm": 0.0,
                                    "table_z": outcome.table_z, "table_from": outcome.table_from,
                                    "before_mm": outcome.before_mm, "slip_mm": outcome.slip_mm,
                                    "slip_worst_mm": outcome.slip_worst_mm,
                                    "tool_offset_mm": outcome.tool_offset_mm, "up_check_deg": outcome.up_check_deg,
                                    "skipped": outcome.skipped, "pattern": outcome.pattern,
                                    "turns": [p.r for p in outcome.used], "extras": extras})
            self.recorder.save()
        self.on_calibrated(outcome.transform, typical)
        if self.on_table_touched is not None and outcome.table_z is not None:
            self.on_table_touched(outcome.table_z)
        self._set_marks(outcome.arrows())
        self._refresh_buttons()
        report = self._cube_report(outcome)
        fingers = self.gripper is None or getattr(self.gripper, "fingers", True)
        after = ("\nSaved; the safety floor is set from the table. Next, the cube still held: "
                 + ("'Fingers angle check' (the wrist's real angles, used by every pick), then 'Rotation pick test'; "
                    if fingers else "")
                 + "optionally 'Pick test', or 'Add 1 cube' / 'Add 2 cubes' (put them on the table first, at least 15 "
                   "cm apart) for the heights; then 'Finish'.")
        self._say(report + paper_note + after, "good")
        if look_for_paper:
            from app.vision.paper import find_paper_with
            transform = outcome.transform
            self._start_worker(lambda: find_paper_with(self.camera, transform),
                               lambda found: self._paper_looked(found, "", report, after),
                               lambda message: self._paper_looked(None, message, report, after))

    def _go_paper_centre(self) -> None:
        """The open gripper 20 mm above where the A4 sheet's centre belongs, the wrist in its middle: up first, across,
        then down (the table's height from the touches; none yet: the safety floor's). Not while a finished run
        still holds the cube (the gripper opens first)."""
        if self._worker is not None or self._cube_phase1 is not None or self._arm_refused():
            return
        from app.hardware.interfaces import Pose
        from app.vision.paper import DESIGNED_CENTRE
        x, y = DESIGNED_CENTRE
        if self._touches:
            table = TableHeights(self._touches).at(x, y)        # (the tool's height with the fingertips on it)
        else:
            table = float(self._bounds()["z"][0])
        z, r = table + 20.0, middle_turn(x, y)

        def go():
            self.robot.open_gripper()
            here = self.robot.get_pose()
            up = max(here.z, z + 40.0)
            self.robot.move_to(Pose(here.x, here.y, up, here.r))
            self.robot.move_to(Pose(x, y, up, r))
            self.robot.move_to(Pose(x, y, z, r))
            return z
        self._say("Going to the paper's centre...")
        self._paper_lift = None
        self._start_worker(go, lambda z_: self._say(
            f"The open gripper is 20 mm above the paper's centre ({x:.0f}, {y:.0f}), the wrist in its middle. Put the "
            "cube right under it, lower the gripper round it and close it. Then press 'Lift for the paper'.", "good"),
            lambda message: self._say(f"Couldn't go to the paper's centre: {message}", "bad"))

    PAPER_LIFT_MM = 5.0

    def _lift_for_paper(self) -> None:
        """The held cube 5 mm straight up (same x, y and wrist), its place remembered, so the paper can be slid under
        it and lined up with it."""
        if self._worker is not None or self._cube_phase1 is not None or self._arm_refused():
            return
        from app.hardware.interfaces import Pose
        try:
            here = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001
            self._say(f"Can't read the robot's position: {exc}", "bad")
            return
        if self._paper_lift is None:
            self._paper_lift = (here.x, here.y, here.z, here.r)
        x, y, z, r = self._paper_lift
        up = z + self.PAPER_LIFT_MM

        def lift():
            self.robot.move_to(Pose(x, y, up, r))
            return up

        def failed(message: str) -> None:
            # (where it stopped isn't known -- an E-STOP part-way: 'Put it back down' mustn't go by the old place)
            self._paper_lift = None
            self._refresh_buttons()
            self._say(f"Couldn't lift the cube: {message}. Put it down by hand (Manual tab) if it is up, then grip it "
                      "again.", "bad")
        self._say("Lifting the cube for the paper...")
        self._start_worker(lift, lambda _: self._say(
            f"The cube is {self.PAPER_LIFT_MM:.0f} mm up. Slide the paper under it: the centre outline right below the "
            "cube, its sides parallel to the cube's faces, the arrow towards the robot. Tape the four corners, then "
            "press 'Put it back down'.", "good"), failed)

    def _down_onto_paper(self) -> None:
        """The held cube back exactly where it was lifted from: resting on the paper's centre outline. Straight down
        only: if the arm has been moved since (jogged, an E-STOP), it is refused and the lift forgotten."""
        if self._worker is not None or self._arm_refused():
            return
        if self._paper_lift is None:
            self._say("The cube wasn't lifted for the paper: nothing to put back.", "warn")
            return
        from app.hardware.interfaces import Pose
        x, y, z, r = self._paper_lift
        try:
            here = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001
            self._say(f"Can't read the robot's position: {exc}", "bad")
            return
        turned = abs((here.r - r + 180.0) % 360.0 - 180.0)
        if math.hypot(here.x - x, here.y - y) > 1.0 or turned > 1.0 or here.z < z - 0.5:
            self._paper_lift = None
            self._refresh_buttons()
            self._say(f"The arm has moved since the cube was lifted (it is at x = {here.x:.0f}, y = {here.y:.0f}, "
                      f"z = {here.z:.1f} mm, not straight above where it was lifted from), so it isn't put back by "
                      "itself. Put the cube on the paper's centre outline by hand (Manual tab) and grip it there.",
                      "bad")
            return

        def down():
            self.robot.move_to(Pose(x, y, z, r))
            return z

        def done(_):
            self._paper_lift = None
            self._say("The cube rests on the paper's centre outline again. Choose Precise, Quick or Fast and press "
                      "'Calibrate with a cube and paper'.", "good")
        self._say("Putting the cube back down...")
        self._start_worker(down, done, lambda message: self._say(f"Couldn't put the cube back down: {message}", "bad"))

    def _twin_paper(self) -> tuple:
        """After the demo's "Cube calibration with paper" passed: its sheet lies exactly where designed (the twin's is
        drawn, not in its pictures), saved next to the calibration. (pose, a line for the report)."""
        from app.vision.paper import PaperPose, paper_path, save_paper
        pose = PaperPose(found="twin", when=time.strftime("%Y-%m-%d %H:%M:%S"))
        save_paper(paper_path(self.calibration_path), pose)
        return pose, "\nPaper: the twin's sheet lies exactly where designed (saved)."

    def _paper_looked(self, found, error: str, report: str, after: str) -> None:
        """After "Cube calibration with paper" passed and was saved, the camera looked for the sheet (in a worker:
        the arm is away). Found: its pose is saved next to the calibration, and with it. Either way, said."""
        from app.vision.paper import paper_path, save_paper
        if found is None:                  # (the calibration stands without it)
            line = f"\nPaper: couldn't look for it ({error}); press the watcher's Find the paper."
        elif found.pose is None:
            line = f"\nPaper: not found ({found.reason}); press the watcher's Find the paper."
        else:
            save_paper(paper_path(self.calibration_path), found.pose)
            self._save_with_calibration({"paper": found.pose.__dict__})
            line = (f"\nPaper found ({found.size_mm[0]:.0f} x {found.size_mm[1]:.0f} mm): {found.pose.describe()} "
                    "(saved).")
            if not found.pose.well_placed():
                line += (" That is far from where the spots were designed: place the paper again at the paper's "
                         "centre (step 2), then press the watcher's Find the paper.")
        self._say(report + line + after, "good")

    def _cube_extras(self, outcome: CubeOutcome) -> dict:
        extras = {"tool_offset_mm": outcome.tool_offset_mm,
                  "tool_centre_mm": [round(v, 2) for v in outcome.total_offset],
                  "table_z": round(float(outcome.table_z), 2),
                  **self._camera_extras()}
        if outcome.jaw_axis_deg is not None:
            extras["jaw_axis_deg"] = outcome.jaw_axis_deg
        if outcome.correction is not None:
            extras["xy_correction"] = outcome.correction.as_dict()
        return extras

    @staticmethod
    def _may_save_anyway(outcome: CubeOutcome) -> bool:
        """Failed only because its spots typically disagree by more than the mode's limit (everything else went
        through), and not by more than SAVE_ANYWAY_MAX_MM."""
        return (outcome.over_limit and outcome.transform is not None and outcome.typical_mm is not None
                and outcome.typical_mm <= SAVE_ANYWAY_MAX_MM)

    def _save_cube_anyway(self) -> None:
        """Keep a calibration that came out over its limit, the user knowing: saved as any other, marked over the
        limit (method and extras), and the app says so whenever it loads it."""
        outcome = self._unsaved_cube
        if outcome is None or self._worker is not None:
            return
        typical, limit = outcome.typical_mm, outcome.pass_mm or 2.0
        worst = outcome.worst_mm or 0.0
        why = (f"This calibration's spots typically disagree by {typical:.2f} mm; the limit is {limit:.1f} mm."
               if typical > limit else
               f"Several of this calibration's spots miss by more than {WORST_MM:.0f} mm (up to {worst:.1f}), though "
               f"typically only {typical:.2f} mm: part of the run disagrees with the rest.")
        if QMessageBox.question(
                self, "Save a calibration over the limit?",
                f"{why}\n\n"
                "A 25 mm cube in the 27.5 mm gripper has about 1.25 mm to spare on each side, so picks may now and then "
                "put a finger on the cube.\n\nIt is saved marked as over the limit, and the app says so each time it "
                "loads it. The pick test and the fingers angle check need a calibration that passed, run straight "
                "after it. Save it?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        extras = {**self._cube_extras(outcome), "over_limit": True, "pass_mm": limit,
                  "saved_anyway": time.strftime("%Y-%m-%d %H:%M:%S")}
        save_calibration(self.calibration_path, outcome.transform, self.camera.get_intrinsics(),
                         method=f"cube ({outcome.mode}, over the limit)", reprojection_error_mm=typical,
                         num_samples=len(outcome.used), extras=extras)
        logger.warning("Cube calibration saved over its limit, by the user: %.2f mm typical (limit %.1f mm)",
                       typical, limit)
        self._unsaved_cube = None
        self._transform = outcome.transform
        self._last_result = None
        self._wrist_model = None
        self.on_calibrated(outcome.transform, typical)
        if self.on_table_touched is not None and outcome.table_z is not None:
            self.on_table_touched(outcome.table_z)
        self._refresh_buttons()
        self._say(f"Saved, over the limit: {typical:.2f} mm typically (the limit is {limit:.1f}). Check a few picks "
                  "before relying on it; calibrate again when you can.", "warn")

    def _record_failed_cube(self, outcome: CubeOutcome):
        """A failed run kept as a session too: what each spot measured and the first depth pictures, to see why."""
        if self.recorder is None:
            return None
        self.recorder.clear()
        for xy, look in outcome.pictures:
            rgb = look.rgb if look.rgb is not None else np.zeros((*look.depth.shape, 3), np.uint8)
            self.recorder.add(SampleRecord((float(xy[0]), float(xy[1]), float(outcome.table_z or 0.0)), (0.0, 0.0),
                                           0.0, "cube (failed run)", rgb=rgb, depth=look.depth))
        self.recorder.set_result(method="cube (failed)", reason=outcome.reason)
        self.recorder.set_auto({"method": "cube", "mode": outcome.mode, "spots_tried": outcome.spots_tried,
                                "spots": outcome.spot_log, "skipped": outcome.skipped, "table_z": outcome.table_z,
                                "table_from": outcome.table_from,
                                "pictures": "frame_01 is the empty table; then the first spots"})
        return self.recorder.save()

    def _pick_test(self) -> None:
        phase1 = self._cube_phase1
        if phase1 is None or self._worker is not None or self._arm_refused():
            return
        self._say("Pick test...")
        self._start_worker(lambda: run_pick_test(
            self.robot, self.camera, phase1, self._bounds(), self._reach(), self.gripper,
            on_progress=self.progress.emit, cancel=self._cancel.is_set), self._pick_test_done,
            lambda message: self._say(f"The pick test stopped: {message}", "bad"))

    def _pick_test_done(self, outcome: PickTestOutcome) -> None:
        self.done_steps["pick_test"] = outcome
        if outcome.cancelled:
            self._say("Pick test stopped.", "warn")
            return
        if not outcome.placed_mm:
            self._say(f"Pick test: {outcome.reason or 'nothing measured.'}", "bad")
            return
        typical, worst = outcome.typical_mm, max(outcome.placed_mm)
        tone = "good" if worst <= PICK_TEST_GOOD_MM and outcome.held == outcome.rounds else "warn"
        self._say(f"Pick test, at {len(outcome.placed_mm)} spots the calibration never saw: the camera put the cube "
                  f"within {typical:.2f} mm typically (worst {worst:.2f}) of where the robot left it; picked up "
                  f"from where the camera said: {outcome.held} of {outcome.rounds} held."
                  + (f" ({outcome.hidden} spot{'s' if outcome.hidden > 1 else ''} the camera didn't see whole "
                     "skipped.)" if outcome.hidden else "")
                  + (f"\n{outcome.reason}" if outcome.reason else ""), tone)

    # ---- the fingers angle check and the rotation pick test (calibration/wrist_check.py) -------------------------------
    def _fingers_check(self) -> None:
        phase1 = self._cube_phase1
        if phase1 is None or self._worker is not None or self._arm_refused():
            return
        places = int(self.fingers_size.currentData() or 2)
        self._say(f"Fingers angle check: {places * len(FINGERS_TURNS) * 2} put-downs, the wrist turned -40 to "
                  "+40°...")
        self._start_worker(lambda: run_fingers_check(
            self.robot, self.camera, phase1, self._bounds(), self._reach(), self.gripper, spots=places,
            on_progress=self.progress.emit, cancel=self._cancel.is_set), self._fingers_done,
            lambda message: self._say(f"The fingers angle check stopped: {message}", "bad"))

    def _fingers_done(self, outcome: FingersCheckOutcome) -> None:
        self.done_steps["fingers"] = outcome
        if outcome.cancelled:
            self._say("Fingers angle check stopped. Nothing was saved.", "warn")
            return
        if outcome.model is None:
            self._say(f"Fingers angle check: {outcome.reason or 'nothing measured.'}", "bad")
            return
        model = outcome.model
        self._wrist_model = model
        saved = self._save_with_calibration(self._wrist_extras())
        text = "Fingers angle check: " + model.describe() + "."
        if outcome.skipped:
            text += f"\nLeft out ({len(outcome.skipped)}): " + "; ".join(outcome.skipped[:3]) + (
                "..." if len(outcome.skipped) > 3 else "")
        if outcome.reason:
            text += f"\n{outcome.reason}"
        if not saved:
            text += "\nNot saved: no calibration file to save it with."
        elif model.trusted:
            text += "\nSaved with the calibration: every pick now uses it. Try 'Rotation pick test'."
        else:
            text += ("\nSaved, but picks don't use it (they use the fingers' angle from the calibration only). Check "
                     "the gripper is tight on the wrist and the cube square, then run it again.")
        self._say(text, "good" if model.trusted and saved else "warn")
        if saved and self.on_wrist is not None:
            self.on_wrist()

    def _rotation_test(self) -> None:
        phase1 = self._cube_phase1
        if phase1 is None or self._worker is not None or self._arm_refused():
            return
        corrected = self.rotation_corrected.isChecked()
        model = self._wrist_model
        if model is None:
            calib = load_calibration(self.calibration_path)
            model = WristModel.from_dict((calib.extras or {}).get("wrist_model")) if calib is not None else None
        settings = self.wrist_settings
        self._say(f"Rotation pick test ({'correction on' if corrected else 'correction off'})...")
        self._start_worker(lambda: run_rotation_test(
            self.robot, self.camera, phase1, self._bounds(), self._reach(), self.gripper, model=model,
            corrected=corrected, side=int(settings.get("side", -1)),
            overshoot_deg=float(settings.get("overshoot_deg", 4.0)),
            slow_last_mm=float(settings.get("slow_last_mm", 15.0)), slow_speed=float(settings.get("slow_speed", 20.0)),
            on_progress=self.progress.emit, cancel=self._cancel.is_set),
            lambda outcome: self._rotation_done(outcome, model),
            lambda message: self._say(f"The rotation pick test stopped: {message}", "bad"))

    def _rotation_done(self, outcome: RotationTestOutcome, model: Optional[WristModel]) -> None:
        self.done_steps["rotation_on" if outcome.corrected else "rotation_off"] = outcome
        if outcome.cancelled:
            self._say("Rotation pick test stopped.", "warn")
            return
        text = outcome.describe()
        if outcome.corrected and (model is None or not model.trusted):
            text += ("\n(No trusted fingers angle check: only the same-side approach and the slow finish were "
                     "used.)")
        if outcome.errors_deg:
            self._save_with_calibration({"rotation_test": {
                "corrected": outcome.corrected, "rounds": outcome.rounds, "held": outcome.held,
                "missed": outcome.missed, "mean_deg": round(outcome.mean_deg, 2), "worst_deg": round(outcome.worst_deg, 2),
                "spread_deg": None if outcome.spread_deg is None else round(outcome.spread_deg, 2),
                "by_side": {("below" if k < 0 else "above"): round(v, 2) for k, v in outcome.by_side().items()},
                "measured_at": time.strftime("%Y-%m-%d %H:%M")}})
            if self.on_wrist is not None:
                self.on_wrist()
        tone = "good" if outcome.errors_deg and outcome.worst_deg <= 3.0 and not outcome.missed else "warn"
        self._say(text, tone if outcome.errors_deg else "bad")

    def _wrist_extras(self) -> dict:
        return {"wrist_model": self._wrist_model.to_dict()} if self._wrist_model is not None else {}

    def _save_with_calibration(self, more: dict) -> bool:
        """Add `more` to the saved calibration's extras (the calibration itself unchanged). False if there is none."""
        calib = load_calibration(self.calibration_path)
        if calib is None or not more:
            return False
        extras = dict(calib.extras or {})
        extras.update(more)
        save_calibration(self.calibration_path, calib.transform_matrix(), Intrinsics(**calib.intrinsics),
                         method=calib.method, reprojection_error_mm=calib.reprojection_error_mm,
                         num_samples=calib.num_samples, extras=extras, archive=False)
        return True

    def _add_cubes(self, extra: int) -> None:
        phase1 = self._cube_phase1
        if phase1 is None or self._worker is not None or self._arm_refused():
            return
        if self.place_cubes is not None:
            placed = self.place_cubes(extra)
            if placed:
                self._say(placed)
        self._start_worker(self._run_heights, self._heights_done, self._heights_failed,
                           phase1, extra)

    def _run_heights(self, phase1: CubeOutcome, extra: int) -> HeightsOutcome:
        return run_cube_stacks(self.robot, self.camera, phase1, self._bounds(), self._reach(), self.gripper,
                               extra=extra, on_progress=self.progress.emit, cancel=self._cancel.is_set)

    def _heights_failed(self, message: str) -> None:
        # (still holding the cube: phase 1 stays, so Finish can put it down)
        holding = self._cube_phase1 is not None and self._cube_phase1.holding
        if not holding:
            self._cube_phase1 = None
        self._refresh_buttons()
        self._say(f"The stacking stopped: {message}. The table calibration made before is kept."
                  + (" Press Finish to put the cube down." if holding else ""), "bad")

    def _heights_done(self, outcome: HeightsOutcome) -> None:
        phase1 = self._cube_phase1
        self._cube_phase1 = None
        self._refresh_buttons()
        if outcome.cancelled:
            self._say("Stopped. The table calibration made before is kept.", "warn")
            return
        levels = ", ".join(f"{level} high {bias:+.2f} mm" for level, bias in sorted(outcome.level_bias_mm.items()))
        seen = (f"{len(outcome.stacks)} levels measured on {outcome.tried} tower{'s' if outcome.tried != 1 else ''}"
                + (f" ({outcome.hidden} hidden from the camera, not used)" if outcome.hidden else ""))
        if outcome.kept and outcome.transform is not None:
            extras = {"tool_offset_mm": phase1.tool_offset_mm,
                      "tool_centre_mm": [round(v, 2) for v in phase1.total_offset],
                      "table_z": round(float(phase1.table_z), 2),
                      **self._camera_extras()}
            if phase1.jaw_axis_deg is not None:
                extras["jaw_axis_deg"] = phase1.jaw_axis_deg
            extras.update(self._wrist_extras())
            save_calibration(self.calibration_path, outcome.transform, self.camera.get_intrinsics(),
                             method=f"cube+stacks ({outcome.extra + 1} cubes)",
                             reprojection_error_mm=outcome.table_typical_mm,
                             num_samples=len(phase1.used) + len(outcome.stacks), extras=extras)
            self._transform = outcome.transform
            self.on_calibrated(outcome.transform, outcome.table_typical_mm)
            text = (f"Heights added: {seen}. Up high now {float(np.median(outcome.stack_after_mm)):.2f} mm off "
                    f"(was {float(np.median(outcome.stack_before_mm)):.2f}); on the table "
                    f"{outcome.table_typical_mm:.2f} mm. Heights by the table calibration were: {levels}. Saved."
                    + ("\n(The correction over the table is dropped: it belonged to the table calibration.)"
                       if phase1.correction is not None else ""))
            if outcome.reason:
                text += f"\n{outcome.reason}"
            self._say(text, "good")
            return
        if outcome.stacks:
            self._say(f"{seen}; heights by the table calibration: {levels}. The table calibration is kept: "
                      f"{outcome.reason or 'the stacks added nothing.'}", "warn" if outcome.reason.startswith("the "
                                                                                                    "tower") else "good")
            return
        self._say(f"The table calibration is kept: {outcome.reason or 'no stack was measured.'}", "warn")

    def _cube_regripped(self) -> None:
        """A step lost the cube (the take-back missed, a move refused) and it was gripped again by hand: the real
        gripper has no sensor, so the user says so. The steps that start from the cube held can run again."""
        phase1 = self._cube_phase1
        if phase1 is None or phase1.holding or self._worker is not None:
            return
        if QMessageBox.question(
                self, "Cube back in the gripper?",
                "Is the cube gripped as in step 2: the open gripper lowered round it until it rests on the cube's top, "
                "then closed, by two flat faces, square to the fingers, the cube resting on the table?\n\n"
                "(Gripped higher or lower than that, the next put-downs let it go from the wrong height.)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        phase1.holding, phase1.cube_at = True, None
        logger.info("Calibration: the cube was gripped again by hand; the steps after the calibration may go on")
        self._refresh_buttons()
        self._say("The cube is held again: press Fingers angle check (or Pick test, Rotation pick test, Finish).",
                  "good")

    def _finish_cube(self) -> None:
        """The cube put back on the table; phase 1 is forgotten once it is (if that fails, Finish is there again)."""
        phase1 = self._cube_phase1
        if phase1 is None or self._worker is not None or self._arm_refused():
            return

        def done(_result) -> None:
            self._cube_phase1 = None
            self._refresh_buttons()
            self.done_steps["finish"] = True
            self._say("Done. The calibration with the cube is in use.", "good")
        self._say("Putting the cube back on the table...")
        self._start_worker(lambda: put_cube_down(self.robot, phase1, self._bounds(), self._reach()), done,
                           lambda message: self._say(f"Couldn't put the cube down: {message}. The calibration is "
                                                     "kept; once the robot is ready (E-STOP released, alarms cleared) "
                                                     "press Finish again.", "bad"))

    # ---- step 5: the table height ------------------------------------------------------------------------------------
    def _set_table_height(self) -> None:
        if self._transform is None or self._worker is not None:
            return
        self._say("Measuring the table...")
        self._start_worker(self._measure_for_touch, self._table_measured, self._table_failed, self._transform)

    def _measure_for_touch(self, transform: np.ndarray):
        return transform, self.robot.get_pose().z, measure_table(self.camera, transform)

    def _table_failed(self, message: str) -> None:
        self._say(f"Could not measure the table: {message}", "bad")

    def _table_measured(self, result) -> None:
        transform, z_touch, plane = result
        if self._transform is None or not np.array_equal(transform, self._transform):
            self._say("The calibration changed while measuring; press the button again.", "warn")
            return
        self._apply_table_touch(z_touch, plane)

    def _apply_table_touch(self, z_touch: float, plane: Optional[TablePlane]) -> None:
        if plane is None:
            self._say("The camera didn't find the table. Make sure it is in view and mostly clear "
                      "(the arm itself may stay), then try again.", "bad")
            return
        try:
            corrected, correction = apply_table_touch(self._transform, z_touch, plane.z_mm)
        except TableTouchRefused as exc:
            self._say(f"Not applied: {exc}. Lower the tip until it touches the table and try again, "
                      "or check for a mis-clicked point.", "bad")
            return
        self._transform = corrected
        honest = self._last_result.honest_error_mm if self._last_result is not None else 10.0
        method = ("marker" if self.recorder is not None and self.recorder.samples
                  and self.recorder.samples[0].source == "marker" else "boardless") + "+table"
        save_calibration(self.calibration_path, corrected, self.camera.get_intrinsics(), method=method,
                         reprojection_error_mm=honest, num_samples=self.calibrator.num_samples(),
                         extras=self._camera_extras())
        if self.recorder is not None:
            self.recorder.set_table_touch(z_touch=z_touch, camera_table_z=plane.z_mm, correction_mm=correction,
                                          tilt_deg=plane.tilt_deg)
            self.recorder.save()
        self.on_calibrated(corrected, honest)
        if self.on_table_touched is not None:
            self.on_table_touched(z_touch)
        self._refresh_buttons()
        self._say(f"Done. Table height is z = {z_touch:.0f} mm. Every height was raised by {correction:.0f} mm "
                  "(the distance from the tip to where the marker or your click was), and the safety floor was "
                  "set just above the table. Press 'Verify calibration' to check the result.", "good")

    # ---- verification -------------------------------------------------------------------------------------------------------
    def _verify(self) -> None:
        transform = self._current_transform()
        if transform is None or self._worker is not None or self._arm_refused():
            return
        reply = QMessageBox.question(
            self, "Verify the calibration?",
            "The arm will move to five spots above the table (tip about 45 mm up) and to two places out of the "
            "way, and the camera will look for the tool tip at each. Keep the area clear. E-STOP always works.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        self._set_marks([])
        self._say("Starting the check...")
        self._start_worker(self._run_verify, self._verify_done, self._verify_failed, transform)

    def _run_verify(self, transform: np.ndarray) -> VerifyResult:
        plane = measure_table(self.camera, transform)
        bounds = self._bounds()
        table_z = plane.z_mm if plane is not None else bounds["z"][0]
        return run_verification(self.robot, self.camera, transform,
                                choose_targets(bounds, self._reach(), table_z),
                                away_poses(bounds, self._reach(), table_z),
                                on_progress=self.progress.emit, cancel=self._cancel.is_set)

    def _verify_failed(self, message: str) -> None:
        self._say(f"The check stopped: {message}", "bad")

    def _verify_done(self, result: VerifyResult) -> None:
        marks = []
        for index, point in enumerate(result.points, start=1):
            marks.append({"u": point.predicted_px[0], "v": point.predicted_px[1], "kind": "expected",
                          "label": str(index)})
            if point.found_px is not None:
                marks.append({"u": point.found_px[0], "v": point.found_px[1], "kind": "found"})
        self._set_marks(marks)
        lines = []
        for index, point in enumerate(result.points, start=1):
            lines.append(f"spot {index}: " + (f"{point.error_mm:.1f} mm off" if point.error_mm is not None
                                             else point.note))
        typical = result.typical_mm
        head = ("No result." if typical is None else
                f"Typical error {typical:.1f} mm, worst {result.worst_mm:.1f} mm.")
        tone = "bad" if typical is None or typical >= USABLE_MM else ("warn" if typical >= GOOD_MM else "good")
        lean = f"\n{result.lean_text}" if result.lean_text else ""
        self._say(f"{head} {result.verdict}{lean}\n" + "; ".join(lines) +
                  "\nGreen rings: where the calibration says the tip is. Red crosses: where the camera found it.", tone)
        if self.recorder is not None:
            self.recorder.set_verification(result.as_dict())
            self.recorder.save()

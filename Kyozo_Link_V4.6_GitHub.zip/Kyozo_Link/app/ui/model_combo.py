"""The Prompt tab's Model list. Opened, each model is a row: its name, what it is good for (Quick, Detailed planning,
Deep reasoning), and dots for its speed and its planning, under a heading row (Model, Good for, Speed, Planning).
Closed: "name · role"."""
from __future__ import annotations

from PyQt6.QtCore import QRect, QSize, Qt
from PyQt6.QtGui import QColor, QPainter
from PyQt6.QtWidgets import (QComboBox, QStyle, QStyledItemDelegate, QStyleOptionComboBox, QStyleOptionViewItem,
                             QStylePainter, QWidget)

from app.ui.theme import ACCENT, BORDER, MUTED, TEXT

ROLE, SPEED, PLANNING, SHORT, SLOW_WARNING = (Qt.ItemDataRole.UserRole + n for n in range(1, 6))
DOT_ON_SPEED = QColor("#6bdc8b")
DOT_ON_SPEED_WARN = QColor("#f5a742")
DOT_ON_PLAN = QColor(ACCENT)
DOT_OFF = QColor(80, 100, 115)
COLUMNS = (0.0, 0.42, 0.74, 0.87)      # where name, role, speed and planning start, across the row
HEADINGS = ("Model", "Good for", "Speed", "Planning")
HEADING_HEIGHT = 24


def column_lefts(left: int, width: int) -> list[int]:
    """Where each column starts in a row (or the heading) from `left`, `width` wide: the same for both, so they line up."""
    return [left + int(width * c) for c in COLUMNS]


class ModelRowDelegate(QStyledItemDelegate):
    def sizeHint(self, option, index) -> QSize:
        size = super().sizeHint(option, index)
        return QSize(max(size.width(), 430), max(size.height(), 26))

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index) -> None:
        plain = QStyleOptionViewItem(option)
        self.initStyleOption(plain, index)
        plain.text = ""
        style = option.widget.style() if option.widget is not None else None
        if style is not None:
            style.drawControl(QStyle.ControlElement.CE_ItemViewItem, plain, painter, option.widget)
        if index.data(ROLE) is None:          # (before Ollama answers: the plain names)
            painter.setPen(QColor(TEXT))
            painter.drawText(option.rect.adjusted(10, 0, 0, 0), Qt.AlignmentFlag.AlignVCenter, str(index.data() or ""))
            return
        rect = option.rect.adjusted(10, 0, -10, 0)
        x = column_lefts(rect.left(), rect.width()) + [rect.right()]
        painter.save()
        painter.setPen(QColor(TEXT))
        painter.drawText(QRect(x[0], rect.top(), x[1] - x[0] - 6, rect.height()), Qt.AlignmentFlag.AlignVCenter,
                         str(index.data(SHORT)))
        font = painter.font()
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(QRect(x[1], rect.top(), x[2] - x[1] - 6, rect.height()), Qt.AlignmentFlag.AlignVCenter,
                         str(index.data(ROLE)))
        speed_on = DOT_ON_SPEED_WARN if index.data(SLOW_WARNING) else DOT_ON_SPEED
        self._dots(painter, x[2], rect.center().y(), int(index.data(SPEED)), speed_on)
        self._dots(painter, x[3], rect.center().y(), int(index.data(PLANNING)), DOT_ON_PLAN)
        painter.restore()

    @staticmethod
    def _dots(painter: QPainter, left: int, middle: int, on: int, colour: QColor) -> None:
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        for i in range(3):
            painter.setBrush(colour if i < on else DOT_OFF)
            painter.drawEllipse(left + i * 11, middle - 3, 7, 7)


class ModelListHeading(QWidget):
    """The heading row above the open list: what the columns are (the dots alone didn't say which was speed). In the
    list view's top margin, so it is never a row: it can't be picked, and the rows keep their numbers."""

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setPen(QColor(BORDER))
        painter.drawLine(0, self.height() - 1, self.width(), self.height() - 1)
        font = painter.font()
        font.setPointSizeF(max(font.pointSizeF() - 1.0, 7.0))
        painter.setFont(font)
        painter.setPen(QColor(MUTED))
        rect = self.rect().adjusted(10, 0, -10, -1)
        x = column_lefts(rect.left(), rect.width()) + [rect.right()]
        for i, heading in enumerate(HEADINGS):
            painter.drawText(QRect(x[i], rect.top(), x[i + 1] - x[i] - 6, rect.height()),
                             Qt.AlignmentFlag.AlignVCenter, heading)


class ModelCombo(QComboBox):
    """Items: text the model's name, data its full name; with set_model_rows, its role and dots too."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setItemDelegate(ModelRowDelegate(self))
        self.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.setMinimumContentsLength(26)
        self.heading = ModelListHeading(self.view())
        self.heading.hide()

    def set_model_rows(self, models: list) -> None:
        """One row per models.ModelInfo."""
        self.clear()
        for info in models:
            self.addItem(info.short_name, info.name)
            row = self.count() - 1
            self.setItemData(row, info.role, ROLE)
            self.setItemData(row, info.speed, SPEED)
            self.setItemData(row, info.planning, PLANNING)
            self.setItemData(row, info.short_name, SHORT)
            from app.llm.models import notes
            said = "".join(f"; {n}" for n in notes(info))
            self.setItemData(row, f"{info.name} ({info.size_gb:.1f} GB): {info.role.lower()}; speed {info.speed} of 3, "
                                  f"planning {info.planning} of 3{said}", Qt.ItemDataRole.ToolTipRole)
            self.setItemData(row, info.thinking_only or info.too_big, SLOW_WARNING)

    def closed_text(self) -> str:
        role = self.currentData(ROLE)
        short = self.currentData(SHORT) or self.currentText()
        return f"{short} · {role}" if role else str(short)

    def showPopup(self) -> None:
        view = self.view()
        view.setMinimumWidth(max(440, self.width()))   # the rows' columns, wider than the closed box
        # the heading goes in the view's top margin, which the popup's height counts in (no row is cut off); none
        # before Ollama has said what the models are good for
        headed = any(self.itemData(i, ROLE) is not None for i in range(self.count()))
        view.setViewportMargins(0, HEADING_HEIGHT if headed else 0, 0, 0)
        super().showPopup()
        if headed:
            port = view.viewport().geometry()
            self.heading.setGeometry(port.left(), port.top() - HEADING_HEIGHT, port.width(), HEADING_HEIGHT)
            self.heading.show()
            self.heading.raise_()
        else:
            self.heading.hide()

    def paintEvent(self, event) -> None:
        painter = QStylePainter(self)
        option = QStyleOptionComboBox()
        self.initStyleOption(option)
        option.currentText = self.closed_text()
        painter.drawComplexControl(QStyle.ComplexControl.CC_ComboBox, option)
        painter.drawControl(QStyle.ControlElement.CE_ComboBoxLabel, option)



"""The "System check" window: runs the checklist and shows it. The app's log is here too, not in the tab bar:
"Show log" swaps the report for the log in this same window, and "Back to checks" swaps it back."""
from __future__ import annotations

import html
from typing import Callable

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QTextBrowser, QVBoxLayout

from app.system_check import FAIL, INFO, OK, WARN, CheckContext, CheckResult, as_text, run_checks, summary
from app.ui.log_panel import LogPanel
from app.ui.worker import CallableWorker

_COLOURS = {OK: "#7fe0b0", WARN: "#ffd166", FAIL: "#ff8a8a", INFO: "#8fa8ba"}
_LABELS = {OK: "OK", WARN: "WARNING", FAIL: "PROBLEM", INFO: "info"}
TITLE = "System check"
LOG_TITLE = "System check: log"


class SystemCheckDialog(QDialog):
    progress = pyqtSignal(str)

    def __init__(self, make_context: Callable[[], CheckContext], parent=None, log_panel: LogPanel | None = None):
        super().__init__(parent)
        self.setWindowTitle(TITLE)
        self.resize(720, 560)
        self._make_context = make_context
        self._worker: CallableWorker | None = None
        self._results: list[CheckResult] = []
        self._log = log_panel
        self._headline_text = "Running the checks..."

        layout = QVBoxLayout(self)
        self.headline = QLabel(self._headline_text)
        self.headline.setStyleSheet("font-size: 13pt; font-weight: bold;")
        layout.addWidget(self.headline)
        self.report = QTextBrowser()
        self.pages = QStackedWidget()          # the report, or the log: one at a time, in this window
        self.pages.addWidget(self.report)
        if log_panel is not None:
            self.pages.addWidget(log_panel)
        layout.addWidget(self.pages, stretch=1)

        buttons = QHBoxLayout()
        self.run_btn = QPushButton("Run again")
        self.run_btn.clicked.connect(self.run)
        self.copy_btn = QPushButton("Copy report")
        self.copy_btn.clicked.connect(self._copy)
        buttons.addWidget(self.run_btn)
        buttons.addWidget(self.copy_btn)
        self.log_btn = self.clear_btn = None
        if log_panel is not None:
            self.log_btn = QPushButton("Show log")
            self.log_btn.setToolTip("Everything the app has logged since it started (also saved in app.log)")
            self.log_btn.clicked.connect(lambda: self.show_checks() if self.showing_log() else self.show_log())
            self.clear_btn = QPushButton("Clear")
            self.clear_btn.setToolTip("Empty this view of the log (app.log keeps it all)")
            self.clear_btn.clicked.connect(log_panel.clear)
            self.clear_btn.hide()
            buttons.addWidget(self.log_btn)
            buttons.addWidget(self.clear_btn)
        buttons.addStretch()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        buttons.addWidget(close_btn)
        layout.addLayout(buttons)
        self.progress.connect(self._set_headline)

    def showing_log(self) -> bool:
        return self._log is not None and self.pages.currentWidget() is self._log

    def show_log(self) -> None:
        if self._log is None:
            return
        self.pages.setCurrentWidget(self._log)
        self.setWindowTitle(LOG_TITLE)
        self.headline.setText("Everything the app has logged since it started")
        self.copy_btn.setText("Copy log")
        self.copy_btn.setEnabled(True)
        self.log_btn.setText("Back to checks")
        self.clear_btn.show()
        self._log.scroll_to_end()

    def show_checks(self) -> None:
        self.pages.setCurrentWidget(self.report)
        self.setWindowTitle(TITLE)
        self.headline.setText(self._headline_text)
        self.copy_btn.setText("Copy report")
        self.copy_btn.setEnabled(self._worker is None)
        if self.log_btn is not None:
            self.log_btn.setText("Show log")
            self.clear_btn.hide()

    def _set_headline(self, text: str) -> None:
        self._headline_text = text
        if not self.showing_log():         # checks running while the log is up: kept for "Back to checks"
            self.headline.setText(text)

    def _copy(self) -> None:
        QGuiApplication.clipboard().setText(self._log.text() if self.showing_log() else as_text(self._results))

    def run(self) -> None:
        """Runs the checks, showing them (not the log): also what opening the window does."""
        self.show_checks()
        if self._worker is not None:
            return
        self.run_btn.setEnabled(False)
        self.copy_btn.setEnabled(False)
        self._set_headline("Running the checks...")
        context = self._make_context()   # gathered on the UI thread; the checks then run off it
        self._worker = CallableWorker(run_checks, context, self.progress.emit)
        self._worker.finished_ok.connect(self._done)
        self._worker.failed.connect(lambda message: self._done([CheckResult("system check", FAIL, message)]))
        self._worker.start()

    def _done(self, results: list[CheckResult]) -> None:
        self._worker = None
        self._results = results
        self.run_btn.setEnabled(True)
        if not self.showing_log():
            self.copy_btn.setEnabled(True)
        self._set_headline(summary(results))
        rows = []
        for r in results:
            fix = f"<div style='margin-left:76px;color:#b7c9d6'>&rarr; {html.escape(r.fix)}</div>" if r.fix else ""
            rows.append(f"<p style='margin:6px 0'><b style='color:{_COLOURS[r.status]}'>{_LABELS[r.status]:<8}</b> "
                        f"<b>{html.escape(r.area)}</b>: {html.escape(r.message)}{fix}</p>")
        self.report.setHtml("".join(rows))

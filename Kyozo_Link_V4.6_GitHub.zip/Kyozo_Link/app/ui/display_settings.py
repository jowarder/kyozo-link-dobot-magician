"""What the 3D view shows: each effect can be switched on or off in the Settings window.

One shared object for the whole app; views read it when they draw and redraw when it changes. The
choices are remembered in config.yaml under `display:` (in demo and live mode alike: they are about
how things look, not about the robot).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable, Optional

from PyQt6.QtCore import QObject, pyqtSignal

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Option:
    key: str
    group: str
    label: str
    tip: str
    default: bool


LOOK, HELPERS, EXTRAS, PROMPTS = "Look", "Helpers", "Extras", "Prompts"

OPTIONS: tuple[Option, ...] = (
    Option("soft_shadows", LOOK, "Soft shadows",
           "Soft shadows of the arm and objects on the table, following the arm as it moves. "
           "Off: the simple flat shadows from V1.8.", True),
    Option("rim_light", LOOK, "Rim light",
           "A thin light edge along the arm's outline, so the dark arm stands out from the background.", True),
    Option("highlights", LOOK, "Shiny highlights",
           "Small bright highlights on the curved parts, so they read as metal and plastic, not flat colour.", True),
    Option("measuring_mat", LOOK, "Measuring mat",
           "A cutting-mat table with a 10 mm grid and a ruler along two edges. Off: the plain V1.8 grid.", True),
    Option("studio_background", LOOK, "Studio background",
           "A soft glow behind the robot and darker corners.", True),

    Option("reach_map", HELPERS, "Reach map",
           "The ring on the table where the tip can reach at its current height (it moves out as the tip "
           "goes up), with the no-go zone next to the base in red. Off: the two dashed arcs.", True),
    Option("joint_gauges", HELPERS, "Joint angle gauges",
           "In the joint panel: J1-J4 as gauges, turning orange near a joint limit and red past one; and arcs "
           "at the joints in the 3D view. Limits are the Dobot's published ranges. Off: plain numbers.", True),
    Option("height_line", HELPERS, "Height line",
           "A line from the tip straight down to the table, with the height in mm.", True),
    Option("path_preview", HELPERS, "Path preview",
           "While the arm moves: the route it takes (straight, or swinging round the base) and where it will stop.",
           True),
    Option("ghost_target", HELPERS, "Ghost target",
           "While the arm moves: a see-through arm where it is going.", True),
    Option("camera_cone", HELPERS, "Camera cone",
           "The camera where the calibration says it is, and the part of the table it sees. If it points "
           "somewhere odd, the calibration is off.", False),
    Option("gripper_glow", HELPERS, "Gripper status glow",
           "The gripper glows green when it is holding something, amber when closed on nothing.", True),
    Option("camera_detections", HELPERS, "What the camera sees",
           "Outlines where the camera finds each object (updated about once a second), next to where it "
           "really is. Uses the camera and the detector, so it costs a little.", False),

    Option("joint_panel", EXTRAS, "Joint and gripper panel",
           "The panel in the top right: the joint angles, and whether the gripper is closed and what it holds.",
           True),
    Option("labels", EXTRAS, "Name labels", "The names of the objects and the TCP.", True),
    Option("tip_trail", EXTRAS, "Glowing tip trail", "Where the tip has been, fading out.", True),
    Option("view_buttons", EXTRAS, "View buttons", "Top / Front / Side / 3D buttons in the corner of the view.",
           True),
    Option("auto_rotate", EXTRAS, "Auto-rotate", "Slowly turns the view round the robot, for showing it off. "
           "Drag the view to stop it.", False),
    Option("screenshot_button", EXTRAS, "Save-image button",
           "A button in the view that saves it as a picture in the screenshots folder.", True),

    Option("show_reasoning", PROMPTS, "Show the model's reasoning",
           "The model explains each decision before making it, and the Model tab shows that explanation. "
           "Makes every prompt noticeably slower (the model writes a paragraph before each step).", False),
    Option("step_by_step", PROMPTS, "Step by step",
           "Before each robot move of a prompt, the app shows it (and where the tip is headed, in the 3D view) and "
           "waits for you: Go does that step, Go all runs the rest, Stop ends the task there. Looking at the table "
           "doesn't ask. E-STOP still works at any moment. Also next to the Send button.", False),
)
# One line under each option in the Settings window (the longer `tip` is its tooltip).
SUMMARIES = {
    "soft_shadows": "Shadows on the table that follow the arm",
    "rim_light": "A light edge that lifts the dark arm off the background",
    "highlights": "Shine on the curved parts",
    "measuring_mat": "A 10 mm grid and rulers on the table",
    "studio_background": "A soft glow behind the robot, darker corners",
    "reach_map": "Where the tip can reach at its height",
    "joint_gauges": "Joint limits in colour, arcs at the joints",
    "height_line": "The tip's height above the table, in mm",
    "path_preview": "The route the arm is about to take",
    "ghost_target": "A see-through arm where it's heading",
    "camera_cone": "Where the calibration puts the camera",
    "gripper_glow": "Green when holding, amber when empty",
    "camera_detections": "Outlines of what the camera finds",
    "joint_panel": "Joint angles and gripper state, top right",
    "labels": "Object names and the TCP marker",
    "tip_trail": "Where the tip has been",
    "view_buttons": "Top, Front, Side and 3D buttons",
    "auto_rotate": "Slowly turns the view round the robot",
    "screenshot_button": "Save the view as a picture",
    "step_by_step": "Approve each robot move before it happens",
    "show_reasoning": "Its why, in the Model tab (slower)",
}
DEFAULTS = {option.key: option.default for option in OPTIONS}
GROUPS = (LOOK, HELPERS, EXTRAS, PROMPTS)
VIEW_GROUPS = (LOOK, HELPERS, EXTRAS)   # what "All on / All off" switch: the 3D view, never how prompts run


class DisplaySettings(QObject):
    changed = pyqtSignal()

    def __init__(self, saved: Optional[dict] = None, save: Optional[Callable[[dict], None]] = None, parent=None):
        """`saved`: what config.yaml had (unknown keys ignored, missing ones get the default).
        `save`: called with all the values whenever one changes."""
        super().__init__(parent)
        self._values = dict(DEFAULTS)
        for key, value in (saved or {}).items():
            if key in self._values:
                self._values[key] = bool(value)
        self._save = save

    def __getitem__(self, key: str) -> bool:
        return self._values[key]

    def as_dict(self) -> dict:
        return dict(self._values)

    def set(self, key: str, value: bool) -> None:
        self.update({key: value})

    def update(self, values: dict) -> None:
        changed = {k: bool(v) for k, v in values.items() if k in self._values and self._values[k] != bool(v)}
        if not changed:
            return
        self._values.update(changed)
        if self._save is not None:
            try:
                self._save(self.as_dict())
            except Exception as exc:  # noqa: BLE001 - not being able to remember a look is not worth an error box
                logger.warning("Could not save the display settings: %s", exc)
        self.changed.emit()

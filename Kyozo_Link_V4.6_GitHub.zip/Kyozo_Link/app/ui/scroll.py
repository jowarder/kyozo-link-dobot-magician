"""Let a side panel scroll instead of forcing the whole window to be tall enough for it."""
from __future__ import annotations

from PyQt6.QtCore import QEvent, QObject, Qt
from PyQt6.QtWidgets import QFrame, QScrollArea, QWidget


class _KeepWidth(QObject):
    """Keeps a scroll area at least as wide as its panel needs as the panel changes (a longer message, a button's new
    words): set only once, a panel that grew later was cut off on the right with no way to reach it."""

    def __init__(self, area: QScrollArea):
        super().__init__(area)
        self.area = area

    def eventFilter(self, obj, event):  # noqa: N802 (Qt)
        if event.type() == QEvent.Type.LayoutRequest:
            _fit(self.area)
        return False


def _fit(area: QScrollArea) -> None:
    panel = area.widget()
    if panel is not None:
        area.setMinimumWidth(panel.minimumSizeHint().width() + area.verticalScrollBar().sizeHint().width() + 4)


def scrollable(panel: QWidget) -> QScrollArea:
    """Wrap `panel` so that on a short window it keeps its natural size and gets a scroll bar,
    rather than being squashed until its text is cut off (or pushing the window off the screen).
    Only vertical scrolling: the panel always fits the width it is given."""
    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(QFrame.Shape.NoFrame)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    area.setWidget(panel)
    # never narrower than the panel needs, or its right edge is cut off with no way to reach it -- now and later
    _fit(area)
    panel.installEventFilter(_KeepWidth(area))
    return area

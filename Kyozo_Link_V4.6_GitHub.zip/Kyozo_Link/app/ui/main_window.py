"""Main application window: assembles hardware/sim backends, vision, LLM agent, and UI tabs."""
from __future__ import annotations

import logging
import math
import random
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable, Optional

import numpy as np
import yaml
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QToolBar, QPushButton, QComboBox, QLabel, QWidget,
    QHBoxLayout, QMessageBox, QSplitter, QVBoxLayout,
)

from app import APP_NAME, __version__
from app.calibration.storage import load_calibration
from app.fileutil import atomic_write_text
from app.hardware.camera import DEPTH_PRESETS, OrbbecCamera
from app.memory import ALARM_APP_MB, NORMAL_APP_MB, app_memory_mb, system_memory_gb
from app.hardware.dobot import DobotRobot
from app.hardware.gripper import GripperSpec
from app.hardware.interfaces import Camera, Pose, Robot
from app.hardware.sim_camera import SimCamera
from app.hardware.sim_robot import SimRobot
from app.hardware.unavailable import UnavailableCamera, UnavailableRobot
from app.hardware.wrist import WristModel
from app.cube_size import CONFIG_PATH as CUBE_SIZE_PATH, CUBE_SIZES_MM, cube_mm, describe as describe_cube
from app.llm.agent import SYSTEM_PROMPT, Agent
from app.llm.models import choose as choose_model
from app.llm.models import list_order as model_list_order
from app.llm.models import notes as model_notes
from app.llm.models import FOR_A_LAPTOP as MODELS_FOR_A_LAPTOP
from app.llm.ollama_client import OllamaClient
from app.llm.tools import TOOL_SCHEMAS, ToolExecutor
from app.twin.shuffle import shuffle_layout, shuffle_turns
from app.twin.world import TwinWorld, demo_workspace_bounds, list_scenarios
from app.hardware.sim_faults import PRESETS
from app.system_check import CheckContext
from app.ui.calibration_panel import CalibrationPanel
from app.ui.continuous_monitor import ContinuousCalibration
from app.ui.cube_tour import CubeTour
from app.ui.drift_monitor import DriftMonitor
from app.ui.display_settings import DisplaySettings
from app.ui.settings_panel import SettingsPanel
from app.ui.system_check_dialog import SystemCheckDialog
from app.vision.drift import reference_path
from app.ui.jog_panel import JogPanel
from app.ui.log_panel import LogPanel, LogTab
from app.ui.model_combo import ModelCombo
from app.ui.model_tab import ModelTab
from app.ui.prompt_panel import PromptPanel
from app.ui.scroll import scrollable
from app.ui.twin_view import TwinView
from app.ui.video_widget import VideoWidget
from app.ui.worker import CallableWorker
from app import robots
from app.hardware.xarm import XArmRobot
from app.vision.depth_detector import DepthObjectDetector
from app.vision.detection_settings import DETECTOR_FOR, FIND_ANY, FIND_CUBES, DetectionSettings, SwitchingDetector
from app.vision.detector import build_detector, with_demo_colors
from app.vision.locator import camera_point_to_robot, foreground_depth, locate_detection, pixel_to_camera_point
from app.vision.scene import SceneBuilder
from app.vision.table import measure_table, suggest_floor

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
CLICK_TO_MOVE_APPROACH_HEIGHT_MM = 30.0
DEFAULT_SCENE = "two_blocks_and_tray"   # the demo scene when config.yaml names none (or one that isn't there)
TOUCHED_FLOOR_MM = 1.0  # Z min this far above a table the tip touched (the grip keeps the fingertips 2 mm above it)
PICK_HERE_MM = 40.0     # "Pick here" takes the object within this of the gripper, seen from above
MODEL_CONTEXT_TOKENS = 8192   # what the model may read at once: Ollama's own 4096 was outgrown by a prompt of a few steps
                              # (the instructions and tools are about 2,600 tokens, each look at the table a few hundred);
                              # about 0.6 GB more memory (config.yaml llm: num_ctx overrides it)
KEEP_MODEL_LOADED = "30m"   # Ollama keeps the model this long after each use while the app is open (its own default,
                            # 5 minutes, made the first prompt after a break wait 30-60 s to load it again);
                            # closing the app unloads it (config.yaml llm: keep_alive overrides this)
DEMO_TABLE_Z_MM = 0.0   # the demo's table is a fixed prop at z = 0 (see scene_painter.py); a real
                        # calibration's z_min in config.yaml is measured in the real arm's own frame
                        # and has no relationship to that, so it must not be used as the demo's floor


def default_robot_settings(key: str) -> dict:
    """A robot's settings in config.yaml before any are saved (the Dobot's are under robot:, as they always were)."""
    if key == "xarm6":
        profile = robots.profile(key)
        return {"ip": "", "workspace_bounds": {axis: list(v) for axis, v in profile.demo_bounds.items()},
                "max_speed": 100.0, "gripper_type": "gripper", "gripper": {}, "max_reach_mm": profile.max_reach_mm,
                "collision_sensitivity": 3, "gripper_speed": 2000}
    return {}


class MainWindow(QMainWindow):
    def __init__(self, config: dict):
        super().__init__()
        self.config = config
        # Where its settings are saved, fixed now: a save that waits a moment (a divider dragged, a Detection setting
        # changed) went, in the tests, to the real config.yaml once the test had put PROJECT_ROOT back.
        self._config_file = PROJECT_ROOT / "config.yaml"
        # Which robot this run drives (the toolbar's Robot list; changing it restarts the app). Its settings are
        # config.yaml's section for it (robot: for the Dobot, xarm6: for the xArm); config["robot"] is made that
        # section here, so everything that reads the robot's settings reads that robot's.
        self.robot_profile = robots.set_active(robots.robot_key(config))
        self._robot_section = self.robot_profile.config_section
        if self._robot_section != "robot":
            config["robot"] = config.setdefault(self._robot_section, default_robot_settings(self.robot_profile.key))
        self.setWindowTitle(f"{APP_NAME} V{__version__} — {self.robot_profile.name}")
        self.resize(1100, 650)

        self.robot: Robot
        self.camera: Camera
        self._twin_world: TwinWorld | None = None
        self._click_worker: CallableWorker | None = None
        self._llm_status_worker: CallableWorker | None = None
        self._reconnect_worker: CallableWorker | None = None
        self._floor_worker: CallableWorker | None = None
        self._preset_worker: CallableWorker | None = None
        self._camera_setup_busy: Optional[str] = None     # what Camera setup is doing that holds the app, if anything
        self._watcher_active = False
        self._preset_combos: list[QComboBox] = []     # Settings > Camera, one per Settings panel, kept in step
        self._cube_combos: list[QComboBox] = []       # Settings > Cubes, the same
        self._table_z_mm: Optional[float] = None
        self._table_z_tried_at = -1e9
        self.robot_status = "Unknown"
        self.robot_connected = False
        self.camera_status = "Unknown"
        self.camera_connected = False

        # What the 3D view shows (the Settings window); remembered in config.yaml under display:
        self.display_settings = DisplaySettings(config.get("display"), save=self._save_display_settings)
        self._settings_panels: list[SettingsPanel] = []   # one beside each 3D view (demo); shown together

        # Created before backends so their connect() log lines show up in the log too. Shown in the Log tab and inside
        # the System check window ("Show log").
        self.log_panel = LogPanel()
        self.log_panel.attach_to_root_logger()

        self._build_backends()

        # what counts as an object: any object (by depth) or coloured cubes, and what is left out against phantoms
        # (the Detection window). Both detectors are made; the settings say which one looks. The demo has its own
        # settings (config.yaml vision_demo:; the real camera's are under vision:): "coloured cubes only", chosen
        # against the real camera's phantoms, also blinded the demo to its ball, can and pen; and a real pick area,
        # in the real arm's coordinates, has nothing to do with the demo's table.
        self._vision_section = "vision" if config.get("mode") == "live" else "vision_demo"
        if self._vision_section == "vision":
            self.detection_settings = DetectionSettings.from_config(config["vision"])
        else:
            self.detection_settings = DetectionSettings.from_config(
                config.get("vision_demo") or {"detector": DETECTOR_FOR[FIND_ANY]})
        if config.get("mode") == "live" and "steady_looks" not in config["vision"]:
            self.detection_settings.steady_looks = 2     # a real depth camera's noise comes and goes: seen twice
        depth_detector = DepthObjectDetector(
            get_transform=lambda: self.scene_builder.t_cam_to_robot, table_z_provider=self._table_z,
            arm_provider=self._arm_geometry,
            places_provider=lambda: {name: (p.x, p.y, p.z) for name, p in self.tool_executor._saved_places().items()}
            if getattr(self, "tool_executor", None) is not None else {},
            place_areas_provider=lambda: self.tool_executor._place_areas()   # trays, bins and sized saved places
            if getattr(self, "tool_executor", None) is not None else {},
            settings=self.detection_settings)
        # the demo scenes also use yellow and purple cubes (demo only: see DEMO_EXTRA_COLORS)
        colours = dict(config["vision"], detector="color_blob")
        colour_detector = build_detector(with_demo_colors(colours) if self._twin_world is not None else colours)
        self.detector = SwitchingDetector(self.detection_settings, depth_detector, colour_detector,
                                          get_transform=lambda: self.scene_builder.t_cam_to_robot)
        self._detection_save = QTimer(self)
        self._detection_save.setSingleShot(True)
        self._detection_save.timeout.connect(self._save_detection_settings)
        self.detection_settings.changed.append(self._on_detection_settings_changed)
        t_cam_to_robot = self._load_or_identity_transform()
        # what the objects are known to measure (config.yaml, vision: known_sizes_mm, e.g. cube: 25.0). Live only:
        # the demo's cubes are its own size
        known = {} if self._twin_world is not None else dict(config["vision"].get("known_sizes_mm") or {})
        # (vision: cubes_only: only cubes on the table -- a cube read round for a moment is still the cube)
        cubes_only = self._twin_world is None and bool(config["vision"].get("cubes_only", False))
        self.scene_builder = SceneBuilder(self.camera, self.detector, t_cam_to_robot, known_sizes=known,
                                          cubes_only=cubes_only)
        self.scene_builder.correction = self._saved_correction(t_cam_to_robot)
        # Its own tracker for the 3D view's "What the camera sees", so looking never renumbers the objects
        # a prompt is working with (and the two never run into each other from different threads).
        self._twin_scene = SceneBuilder(self.camera, self.detector, t_cam_to_robot, known_sizes=known,
                                        cubes_only=cubes_only)

        # 400 s for an answer (V4.2, Rafi; config.yaml llm: timeout_s): a turn takes 20-30 s, the slowest seen 92 s; a
        # shorter wait made the watcher count a slow answer as an infrastructure failure the twin would have finished,
        # a longer one would let one stuck request outlast a task's 10 minutes
        self.ollama_client = OllamaClient(endpoint=config["llm"]["endpoint"],
                                          timeout_s=float(config["llm"].get("timeout_s", 400.0)),
                                          keep_alive=config["llm"].get("keep_alive", KEEP_MODEL_LOADED),
                                          num_ctx=config["llm"].get("num_ctx", MODEL_CONTEXT_TOKENS),
                                          seed=config["llm"].get("seed"))
        self._apply_reasoning_setting()
        self.display_settings.changed.connect(self._apply_reasoning_setting)
        live = config.get("mode") == "live"
        self.tool_executor = ToolExecutor(
            self.robot, self.scene_builder, calibration_ready=lambda: (not live) or self._calibrated,
            poses_dir=self._poses_dir(), look_pose=self._look_pose(), table_z_provider=self._table_z,
            places_provider=(self._twin_world.places if self._twin_world is not None else None),
            place_areas_provider=(self._twin_world.place_areas if self._twin_world is not None else None),
            gripper=GripperSpec.from_config(config["robot"], self.robot_profile.gripper_defaults()))
        self.robot_profile.open_gap_mm = self.tool_executor.gripper.opening_mm   # drawn as wide open as it opens
        self._apply_jaw()                       # (the calibration loaded above may have measured the fingers' angle)
        settings = self._wrist_settings()       # how picks come to their angle (config.yaml, robot: gripper:)
        self.tool_executor.wrist.side = settings["side"]
        self.tool_executor.wrist_overshoot_deg = settings["overshoot_deg"]
        self.tool_executor.slow_last_mm = settings["slow_last_mm"]
        self.tool_executor.slow_speed = settings["slow_speed"]
        self._apply_wrist()                     # ...and the wrist's real turn (the fingers angle check)
        self.agent = Agent(
            client=self.ollama_client, executor=self.tool_executor,
            model=config["llm"]["model"], max_tool_calls=config["llm"]["max_tool_calls"],
            temperature=config["llm"]["temperature"],
        )

        self._drift_say: Optional[Callable] = None   # where to report the next camera-position check
        self.drift = DriftMonitor(self.camera, lambda: self.scene_builder.t_cam_to_robot,
                                  None if self._twin_world is not None else reference_path(self._calibration_path()))
        self.drift.report_ready.connect(self._on_drift_report)
        # the calibration in use kept right while the app works (the Calibration tab's "Continuous" style)
        self.continuous = ContinuousCalibration(
            self.camera, self._calibration_path(), get_transform=lambda: self.scene_builder.t_cam_to_robot,
            apply_transform=self._apply_continuous, can_check=self._continuous_held, corners=self._sheet_corners,
            has_calibration=lambda: self._calibrated, parent=self)

        self._build_ui()
        self._start_drift_watch()
        QTimer.singleShot(8000, self.continuous.resume)     # (on again if it was on when the app closed)
        self._refresh_llm_status()
        self._fill_model_list()        # what Ollama has installed, then the chosen model loaded
        self._llm_status_timer = QTimer(self)
        self._llm_status_timer.timeout.connect(self._refresh_llm_status)
        self._llm_status_timer.start(15000)  # re-check every 15s in case Ollama starts/stops later
        self._memory_warned = False
        self._memory_timer = QTimer(self)
        self._memory_timer.timeout.connect(self._log_memory)
        self._memory_timer.start(60000)
        QTimer.singleShot(5000, self._log_memory)

    # ---- backend construction -------------------------------------------------
    def _build_backends(self) -> None:
        mode = self.config.get("mode", "demo")
        if mode == "demo":
            # The demo's own safety box, not the real arm's from config.yaml (only in memory: config.yaml keeps the
            # real arm's). A live Z min (e.g. -58.6, that arm's own frame) let the demo's tip be jogged through the
            # demo's table, at z = 0; a live X max of 268 put the demo's tray out of reach.
            self.config["robot"]["workspace_bounds"] = (
                demo_workspace_bounds() if self.robot_profile.key == "dobot_magician"
                else {axis: list(v) for axis, v in self.robot_profile.demo_bounds.items()})
            bounds = self.config["robot"]["workspace_bounds"]
            self._twin_world = TwinWorld(gui=False)  # the 3D view is drawn inside the app instead
            client = self._twin_world.start()
            scene = self.config.get("twin", {}).get("scenario", DEFAULT_SCENE)
            if scene not in {s["name"] for s in list_scenarios()}:
                logger.warning("No demo scene called %r; using %r", scene, DEFAULT_SCENE)
                scene = DEFAULT_SCENE
            self._twin_world.load_scenario(scene)
            self.robot = SimRobot(client, bounds,
                                   max_speed=self.config["robot"].get("max_speed", self.robot_profile.default_max_speed),
                                   max_reach_mm=self.config["robot"].get("max_reach_mm", self.robot_profile.max_reach_mm),
                                   world=self._twin_world, marker_offset_mm=(9.0, -6.0),
                                   gripper=GripperSpec.from_config(self.config["robot"],
                                                                   self.robot_profile.gripper_defaults()))
            self.camera = SimCamera(client, width=self.config["camera"]["width"],
                                     height=self.config["camera"]["height"])
            self.camera.wanted_preset = self._configured_preset()
            self.camera.outline_bodies = self.robot.body_ids
        elif mode == "live" and self.robot_profile.key == "xarm6":
            settings = self.config["robot"]
            try:
                self.robot = XArmRobot(
                    ip=str(settings.get("ip") or ""), workspace_bounds=settings["workspace_bounds"],
                    max_speed=settings.get("max_speed", 100.0),
                    max_reach_mm=settings.get("max_reach_mm", self.robot_profile.max_reach_mm),
                    collision_sensitivity=settings.get("collision_sensitivity", 3),
                    gripper_speed=settings.get("gripper_speed", 2000),
                    min_radius_mm=self.robot_profile.min_radius_mm,
                    opening_mm=GripperSpec.from_config(settings, self.robot_profile.gripper_defaults()).opening_mm)
            except Exception as exc:  # noqa: BLE001 - e.g. no IP address yet, or the SDK not installed
                logger.error("Robot construction failed: %s", exc)
                self.robot = UnavailableRobot(str(exc))
            self._build_live_camera()
        elif mode == "live":
            try:
                self.robot = DobotRobot(
                    port=self.config["robot"]["port"],
                    workspace_bounds=self.config["robot"]["workspace_bounds"],
                    max_speed=self.config["robot"].get("max_speed", 100),
                    gripper_type=self.config["robot"].get("gripper_type", "suction"),
                    max_reach_mm=self.config["robot"].get("max_reach_mm", 300),
                    legacy_wait=self.config["robot"].get("legacy_move_wait", False),
                    gripper_settle_s=self.config["robot"].get("gripper_settle_s", 0.8),
                )
            except Exception as exc:  # noqa: BLE001 - e.g. pydobot not installed
                logger.error("Robot construction failed: %s", exc)
                self.robot = UnavailableRobot(str(exc))
            self._build_live_camera()
        else:
            raise ValueError(f"Unsupported mode: {mode}. Use 'demo' or 'live'.")

        try:
            self.robot.connect()
            self._mark_robot_connected(mode)
        except Exception as exc:  # noqa: BLE001 - surface via status bar instead of crashing
            self.robot_connected = False
            self.robot_status = f"Disconnected: {exc}"
            logger.error("Robot connect failed: %s", exc)

        try:
            self.camera.connect()
            self.camera_connected = True
            self.camera_status = f"Connected ({mode})"
            # the picture settings chosen in Camera setup (exposure, white balance...), kept in config.yaml
            saved = self.config["camera"].get(self._controls_key()) or {}
            if saved and hasattr(self.camera, "apply_controls"):
                self.camera.apply_controls(dict(saved))
        except Exception as exc:  # noqa: BLE001 - surface via status bar instead of crashing
            self.camera_connected = False
            self.camera_status = f"Disconnected: {exc}"
            logger.error("Camera connect failed: %s", exc)

    def _build_live_camera(self) -> None:
        try:
            self.camera = OrbbecCamera(
                serial=self.config["camera"].get("serial", ""),
                width=self.config["camera"]["width"], height=self.config["camera"]["height"],
                fps=self.config["camera"]["fps"],
                min_distance_mm=self.config["camera"].get("min_distance_mm", 300),
                undistort=bool(self.config["camera"].get("undistort", True)),
                depth_preset=self._configured_preset(),
            )
        except Exception as exc:  # noqa: BLE001 - e.g. pyorbbecsdk not installed
            logger.error("Camera construction failed: %s", exc)
            self.camera = UnavailableCamera(str(exc))

    def _controls_key(self) -> str:
        """Where the Camera setup's picture settings are kept in config.yaml's camera section: the real camera's and
        the demo's apart (a demo exposure is no use to the lab's camera)."""
        return "controls_demo" if self._twin_world is not None else "controls"

    def _lock_key(self) -> str:
        """Camera setup's "Lock for study" in config.yaml's camera section: the demo's apart from the lab camera's
        (locking while practising mustn't lock the lab's camera)."""
        return "setup_locked_demo" if self._twin_world is not None else "setup_locked"

    def _setup_locked(self) -> bool:
        return bool(self.config["camera"].get(self._lock_key(), False))

    def _camera_setup_dir(self) -> Path:
        return PROJECT_ROOT / ("camera_setup_demo" if self._twin_world is not None else "camera_setup")

    def _log_setup_change(self, what: str) -> None:
        from app.ui.camera_setup_dialog import log_change
        try:
            controls = self.camera.controls() if hasattr(self.camera, "controls") else {}
            settings = {n: c.value for n, c in controls.items()}
        except Exception:  # noqa: BLE001
            settings = {}
        log_change(self._camera_setup_dir(), what, settings)

    def _ask_past_lock(self, what: str) -> bool:
        """Locked for the study: changing `what` asks first, and is logged."""
        if not self._setup_locked():
            return True
        if QMessageBox.question(self, "Locked for study", f"The camera setup is locked for the study. Change the "
                                f"{what} anyway? (It is logged.)") != QMessageBox.StandardButton.Yes:
            return False
        self._log_setup_change(f"{what} changed while locked (from the main window)")
        return True

    def _preset_key(self) -> str:
        """Where the depth preset is kept in config.yaml's camera section: the demo's apart from the lab camera's
        (practising High Accuracy on the demo mustn't leave the real camera on it)."""
        return "depth_preset_demo" if self._twin_world is not None else "depth_preset"

    def _configured_preset(self) -> str:
        """The depth preset chosen in Settings > Camera (config.yaml camera: depth_preset; the demo's: depth_preset_demo)."""
        name = self.config["camera"].get(self._preset_key(), DEPTH_PRESETS[0])
        return name if name in DEPTH_PRESETS else DEPTH_PRESETS[0]

    def _mark_robot_connected(self, mode: str) -> None:
        self.robot_connected = True
        port = getattr(self.robot, "port", None) if isinstance(self.robot, DobotRobot) else None
        if isinstance(self.robot, XArmRobot):
            self.robot_status = f"Connected ({mode}, xArm at {self.robot.ip})"
            return
        self.robot_status = f"Connected ({mode}, {port})" if port else f"Connected ({mode})"
        if isinstance(self.robot, DobotRobot) and not self.robot.homed:
            # (every move is refused until then: DobotRobot.needs_person)
            self.statusBar().showMessage("Dobot connected: press Home on the Manual tab, with the area clear, "
                                         "before anything moves.", 20000)
        if port and port != self.config["robot"].get("port"):
            self._save_config_value(("robot", "port"), port)
            logger.info("Saved detected robot port %s to config.yaml", port)

    def _save_config_value(self, path: tuple[str, ...], value) -> None:
        config_path = self._config_file
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        target = raw
        for key in path[:-1]:
            target = target.setdefault(key, {})          # (made if it isn't there yet)
        target[path[-1]] = value
        atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
        node = self.config
        for key in path[:-1]:
            node = node.setdefault(key, {})
        node[path[-1]] = value

    def _reconnect_robot(self) -> None:
        if not isinstance(self.robot, (DobotRobot, XArmRobot)):
            self.statusBar().showMessage("Reconnect only applies to a real robot (live mode)", 4000)
            return
        if self._reconnect_worker is not None:
            return
        self.robot_status = "Scanning serial ports..." if isinstance(self.robot, DobotRobot) else "Connecting..."
        self.robot_connected = False
        self._update_robot_status_label()

        def work() -> None:
            self.robot.disconnect()
            self.robot.connect()

        self._reconnect_worker = CallableWorker(work)
        self._reconnect_worker.finished_ok.connect(self._on_reconnect_done)
        self._reconnect_worker.failed.connect(self._on_reconnect_failed)
        self._reconnect_worker.start()

    def _on_reconnect_done(self, _result) -> None:
        self._mark_robot_connected(self.config.get("mode", "live"))
        self._update_robot_status_label()
        self._reconnect_worker = None

    def _on_reconnect_failed(self, message: str) -> None:
        self.robot_connected = False
        self.robot_status = f"Disconnected: {message}"
        logger.error("Robot reconnect failed: %s", message)
        self._update_robot_status_label()
        self._reconnect_worker = None

    def _look_pose(self) -> Pose | None:
        """Where the arm parks before the camera looks at the table. Optional on the real
        robot (set robot.look_pose: [x, y, z] in config.yaml once you know a safe spot that
        keeps the arm out of the camera's view); the simulator has a built-in one."""
        configured = self.config.get("robot", {}).get("look_pose")
        if configured:
            return Pose(x=configured[0], y=configured[1], z=configured[2])
        if self.config.get("mode", "demo") == "demo":
            return Pose(*self.robot_profile.demo_look_pose)
        if robots.robot_key(self.config) == "dobot_magician":
            # none set: where the cube calibration waits while the camera looks (out of its view, and reached at every
            # calibration). Without one the arm stayed where it put a cube down, above it, and the next prompt's look
            # didn't see it ("no longer seen where it was" -- the lab, 2026-10-22)
            from app.calibration.cube import AWAY_UP_MM, away_poses_for
            bounds = self.config["robot"]["workspace_bounds"]
            reach = float(self.config["robot"].get("max_reach_mm", self.robot_profile.max_reach_mm))
            spot = away_poses_for(bounds, reach, float(bounds["z"][0]) + AWAY_UP_MM)[1]
            logger.info("Parking spot for the camera's looks (robot.look_pose not set): (%.0f, %.0f, %.0f), where the "
                        "cube calibration waits", spot.x, spot.y, spot.z)
            return Pose(x=spot.x, y=spot.y, z=spot.z)
        return None

    def _poses_dir(self) -> Path:
        # Saved poses double as named drop targets ("tray"). Demo positions are in the
        # simulator's frame, so keep them apart from the real robot's.
        # Each robot keeps its own (the xArm's in poses..._xarm6): their frames have nothing to do with each other.
        suffix = self.robot_profile.file_suffix
        if self.config.get("mode", "demo") == "demo":
            return PROJECT_ROOT / "app" / f"poses_demo{suffix}"
        return PROJECT_ROOT / (self.config["paths"]["poses_dir"] + suffix)

    def _calibration_path(self) -> Path:
        # Demo and live must never share a calibration file: the simulator's camera is
        # unrelated to the real one, and calibrating in demo would overwrite the real one.
        # Nor two robots: each has its own (calibration_xarm6.json for the xArm).
        suffix = self.robot_profile.file_suffix
        if self.config.get("mode", "demo") == "demo":
            return PROJECT_ROOT / f"calibration_demo{suffix}.json"
        name = Path(self.config["calibration"]["file"])
        return PROJECT_ROOT / name.with_name(name.stem + suffix + name.suffix)

    def _saved_correction(self, t_cam_to_robot: np.ndarray):
        """The correction over the table saved with this calibration (a cube calibration's), if any. Also sets the
        robot to move by the gripper's offset that calibration measured (none for any other)."""
        calib = load_calibration(self._calibration_path())
        matches = calib is not None and np.allclose(calib.transform_matrix(), t_cam_to_robot)
        centre = (calib.extras or {}).get("tool_centre_mm") if matches else None
        # the fingers' real angle, as that calibration measured it (none: config.yaml's)
        jaw = (calib.extras or {}).get("jaw_axis_deg") if matches else None
        self._calibrated_jaw = float(jaw) if jaw is not None else None
        self._apply_jaw()
        # how the wrist really turns (the fingers angle check), and the last rotation pick test, if made with it
        self._calibrated_wrist = WristModel.from_dict((calib.extras or {}).get("wrist_model")) if matches else None
        self._rotation_test = (calib.extras or {}).get("rotation_test") if matches else None
        self._apply_wrist()
        if hasattr(self.robot, "tool_centre_mm"):
            self.robot.tool_centre_mm = tuple(float(v) for v in centre) if centre else (0.0, 0.0)
            if centre and any(centre):
                logger.info("The robot moves by the gripper's offset (%.1f, %.1f) mm", *self.robot.tool_centre_mm)
        return calib.correction() if matches else None

    def _apply_jaw(self) -> None:
        """The gripper's jaw angle: the calibration's measurement if it has one, else config.yaml's. (The executor's
        gripper is the one object every part of the app plans picks with.)"""
        executor = getattr(self, "tool_executor", None)
        if executor is None or not executor.gripper.fingers:
            return
        if getattr(self, "_config_jaw", None) is None:
            self._config_jaw = float(executor.gripper.jaw_axis_deg)
        measured = getattr(self, "_calibrated_jaw", None)
        executor.gripper.jaw_axis_deg = measured if measured is not None else self._config_jaw
        if measured is not None and abs(measured - self._config_jaw) >= 0.05:
            logger.info("The fingers' angle: %.1f degrees (measured by the calibration; config.yaml says %.1f)",
                        measured, self._config_jaw)

    def _wrist_settings(self) -> dict:
        """How a pick brings the wrist to its angle (config.yaml, robot: gripper:): from which side ("below" or
        "above"), from how far, and the last mm down slowly at what speed."""
        own = (self.config["robot"].get("gripper") or {})
        side = str(own.get("wrist_approach", "below")).lower()
        return {"side": 1 if side == "above" else -1,
                "overshoot_deg": float(own.get("wrist_overshoot_deg", 4.0)),
                "slow_last_mm": float(own.get("slow_last_mm", 15.0)),
                "slow_speed": float(own.get("slow_speed_mm_s", 20.0))}

    def _apply_wrist(self) -> None:
        """Picks corrected by the fingers angle check saved with the calibration, if there is one, it was made with the
        fingers' angle in use now, and it passed its checks; else as planned (and the log says so)."""
        executor = getattr(self, "tool_executor", None)
        if executor is None or not executor.gripper.fingers:
            return
        model = getattr(self, "_calibrated_wrist", None)
        jaw = executor.gripper.jaw_axis_deg
        if model is not None and model.jaw_axis_deg is not None and abs(model.jaw_axis_deg - jaw) > 0.3:
            logger.warning("The fingers angle check was made with the fingers taken at %.1f° and they are taken at "
                           "%.1f° now: it isn't used. Run it again (Calibration tab, after a cube calibration).",
                           model.jaw_axis_deg, jaw)
            model = None
        executor.wrist.model = model
        said = model.describe() if model is not None else None
        if said != getattr(self, "_wrist_said", ""):          # (said once, not at every calibration reload)
            self._wrist_said = said
            if model is None:
                (logger.info if self._twin_world is not None else logger.warning)(
                    "No fingers angle check with this calibration: picks use only the fingers' angle (%.1f°). For the "
                    "wrist's offset, gain and backlash, run it after a cube calibration.", jaw)
            elif not model.trusted:
                logger.warning("The fingers angle check isn't used for picks: %s", "; ".join(model.problems))
            else:
                (logger.warning if model.mount_note else logger.info)("Picks use the fingers angle check: %s",
                                                                       model.describe())
        if getattr(self, "model_tab", None) is not None:
            self.model_tab.set_wrist(getattr(self, "_calibrated_wrist", None), getattr(self, "_rotation_test", None),
                                     used=executor.wrist.active)

    def _reload_wrist(self) -> None:
        """The Calibration tab saved a fingers angle check or a rotation pick test with the calibration."""
        self._saved_correction(self.scene_builder.t_cam_to_robot)

    def _load_or_identity_transform(self) -> np.ndarray:
        calib_path = self._calibration_path()
        calib = load_calibration(calib_path)
        self._calibrated = calib is not None
        self._calibration_error_mm = calib.reprojection_error_mm if calib is not None else None
        if calib is not None:
            logger.info("Loaded calibration from %s (error=%.2f mm)", calib_path, calib.reprojection_error_mm)
            if (calib.extras or {}).get("over_limit"):
                logger.warning("This calibration was saved over its limit (%.2f mm typically; the limit is %.1f mm, "
                               "saved anyway on %s): picks may now and then put a finger on a cube. Calibrate again "
                               "when you can.", calib.reprojection_error_mm, float(calib.extras.get("pass_mm", 2.0)),
                               calib.extras.get("saved_anyway", "?"))
            made_straight = (calib.extras or {}).get("undistorted")
            straight_now = getattr(self.camera, "_undistorter", None) is not None
            if made_straight is not None and bool(made_straight) != straight_now:
                logger.warning("The calibration was made with the lens straightening %s, and it is %s now: "
                               "recalibrate.", "on" if made_straight else "off", "on" if straight_now else "off")
            mismatch = self._preset_mismatch(calib)
            if mismatch:
                logger.warning(mismatch)
            return calib.transform_matrix()
        if isinstance(self.camera, SimCamera):
            logger.info("Demo mode: using the simulator's exact camera->robot transform "
                        "(recalibrate in the Calibration tab to practise the workflow).")
            self._calibrated = True
            self._calibration_error_mm = 0.0
            return self.camera.camera_to_robot_transform()
        logger.warning("No calibration found at %s; using identity transform until calibrated.", calib_path)
        return np.eye(4)

    # ---- UI construction --------------------------------------------------
    def _build_ui(self) -> None:
        toolbar = QToolBar("Main")
        self.addToolBar(toolbar)

        estop_btn = QPushButton("E-STOP")
        estop_btn.setStyleSheet(
            "background-color: #c0392b; color: white; font-weight: bold; padding: 6px 16px;"
        )
        estop_btn.clicked.connect(self._on_estop)
        toolbar.addWidget(estop_btn)

        reconnect_btn = QPushButton("Reconnect Robot")
        reconnect_btn.setToolTip("Re-scan serial ports for a Dobot (use after swapping robots or replugging)")
        reconnect_btn.clicked.connect(self._reconnect_robot)
        toolbar.addWidget(reconnect_btn)

        toolbar.addSeparator()
        toolbar.addWidget(QLabel(" Robot: "))
        self.robot_selector = QComboBox()
        for key, name in robots.ROBOT_NAMES.items():
            self.robot_selector.addItem(name, key)
        self.robot_selector.setCurrentIndex(self.robot_selector.findData(self.robot_profile.key))
        self.robot_selector.setToolTip("Which robot to drive: its 3D twin in demo mode, the real one in live mode. "
                                       "Each keeps its own settings, calibration and saved places.")
        self.robot_selector.currentIndexChanged.connect(self._on_robot_changed)
        toolbar.addWidget(self.robot_selector)
        toolbar.addWidget(QLabel(" Mode: "))
        self.mode_selector = QComboBox()
        self.mode_selector.addItems(["demo", "live"])
        self.mode_selector.setCurrentText(self.config.get("mode", "demo"))
        self.mode_selector.currentTextChanged.connect(self._on_mode_changed)
        toolbar.addWidget(self.mode_selector)

        toolbar.addSeparator()
        check_btn = QPushButton("System check")
        check_btn.setToolTip("Checks the robot, camera, calibration and table, and says what to fix")
        check_btn.clicked.connect(self._open_system_check)
        toolbar.addWidget(check_btn)
        detection_btn = QPushButton("Detection")
        detection_btn.setToolTip("What the camera counts as an object: any object or coloured cubes only, what to leave "
                                 "out against phantom objects, and the pick area")
        detection_btn.clicked.connect(self._open_detection)
        toolbar.addWidget(detection_btn)
        # Demo: the 3D view, the demo scene and the camera. Live: the camera only (beside its feed, Manual tab).
        self.settings_btn = QPushButton("Settings")
        self.settings_btn.setCheckable(True)
        self.settings_btn.setToolTip(
            "Show or hide the settings panel beside the 3D view: the demo scene, the camera, shadows, lighting, "
            "reach map, joint gauges and more" if self._twin_world is not None else
            "Show or hide the settings panel beside the camera feed (Manual tab): the camera's depth preset")
        self.settings_btn.toggled.connect(self._show_settings_panels)
        toolbar.addWidget(self.settings_btn)
        watcher_btn = QPushButton("Watcher")
        watcher_btn.setToolTip("The study's watcher: runs the fixed tasks with nobody typing, scores each run with the "
                               "camera and saves everything (practice or real test)")
        watcher_btn.clicked.connect(self._open_watcher)
        toolbar.addWidget(watcher_btn)

        # The model is chosen in the Prompt tab (_build_prompt_tab), where the prompts are typed; the demo's camera
        # tools are in its Settings panel (_camera_box). In the toolbar they made it too wide for a screen with larger
        # text: Qt moved the Model list into the toolbar's overflow strip, which closed as the list opened.
        # Filled from Ollama (the Qwen models installed, each with what it is good for) once it answers; until then
        # the two in config.yaml. Picking one loads it and frees the other; locked while a prompt runs.
        self.model_selector = ModelCombo()
        for name in dict.fromkeys([self.config["llm"]["model"], self.config["llm"].get("fallback_model")]):
            if name:
                self.model_selector.addItem(name, name)
        self.model_selector.setToolTip("The language model that turns your prompts into robot actions. Picking one "
                                       "loads it into memory and frees the one before.")
        self.model_selector.activated.connect(self._on_model_picked)
        self.model_state_label = QLabel("not loaded")
        self.model_state_label.setStyleSheet("color: #8fa8ba;")
        self._model_state = ("not loaded", "#8fa8ba")
        self._llm_status = "checking..."
        self.prompt_busy = False
        self._quality_combos: list[QComboBox] = []     # the demo's simulated-camera tools, one set per Settings panel
        self._bump_buttons: list[QPushButton] = []

        self.video_widget = VideoWidget(self.camera, detector=self.detector, outline_provider=self._pick_area_outline,
                                        detections_when=lambda: bool(self._calibrated))

        self.tabs = QTabWidget()
        self._manual_tab_index = self.tabs.addTab(self._build_manual_tab(), "Manual")
        self._prompt_tab_index = self.tabs.addTab(self._build_prompt_tab(), "Prompt")
        # everything the model decided and what the app did with it, prompt by prompt (saved in prompt_logs/)
        self.model_tab = ModelTab(PROJECT_ROOT / "prompt_logs")
        self.prompt_panel.trace_updated.connect(self.model_tab.update_trace)
        self._apply_wrist()                       # (the Model tab shows the fingers angle check)
        self.tabs.addTab(self.model_tab, "Model")
        self.agent.describe_setup = self._describe_setup
        self.calibration_tab = self._build_calibration_tab()
        self.tabs.addTab(self.calibration_tab, "Calibration")
        # step-by-step: every 3D view shows the move waiting for Go -- the Calibration tab's too (wired before it was
        # built, it never showed one)
        for view in self.tabs.findChildren(TwinView):
            self.prompt_panel.plan_preview.connect(view.show_plan)
        if self._twin_world is not None:   # demo: the Calibration tab opens on its one-cube table (see below)
            self.tabs.currentChanged.connect(self._on_tab_changed)
            if getattr(self, "cube_tour", None) is not None:
                self.cube_tour.size_box.currentIndexChanged.connect(lambda _i: self._calibration_cube_resized())
        self.log_tab = LogTab(self.log_panel)       # the same log as the System check window's "Show log"
        self.tabs.addTab(self.log_tab, "Log")
        self.setCentralWidget(self.tabs)

        self.robot_status_label = QLabel()
        self.camera_status_label = QLabel()
        self.llm_status_label = QLabel()
        self.drift_label = QLabel()
        status_bar = self.statusBar()
        status_bar.addPermanentWidget(self.drift_label)
        status_bar.addPermanentWidget(self.robot_status_label)
        status_bar.addPermanentWidget(self.camera_status_label)
        status_bar.addPermanentWidget(self.llm_status_label)
        for label in (self.drift_label, self.robot_status_label, self.camera_status_label, self.llm_status_label):
            label.setMinimumWidth(40)      # (a long status clips here, rather than making the window wider than the screen)
        self._update_robot_status_label()
        self._update_camera_status_label()
        self.llm_status_label.setText("LLM: checking...")

    def _build_prompt_tab(self) -> QWidget:
        """The conversation, with the same view of the workspace as the Manual tab beside it:
        the simulated 3D view in demo mode, the real camera feed in live mode. Clicking it
        moves the arm, exactly as on the Manual tab -- except while a prompt is running."""
        self.prompt_panel = PromptPanel(self.agent, settings=self.display_settings)
        self.prompt_panel.busy_changed.connect(self._on_prompt_busy)
        self.prompt_panel.arm_busy = lambda: self.arm_busy("prompt")
        from watcher.prompt_record import PromptRecorder     # (Watcher active: each prompt recorded as a run)
        self.prompt_panel.recorder = PromptRecorder(self._watcher_context)
        model_row = self.prompt_panel.model_row
        model_row.addWidget(QLabel("Model:"))
        model_row.addWidget(self.model_selector)
        model_row.addWidget(self.model_state_label)
        model_row.addStretch()
        # the cube size right where the prompts are typed (study 2: 20 or 25 mm cubes): Settings > Cubes' own, in step
        model_row.addWidget(QLabel("Cubes:"))
        model_row.addWidget(self._cube_size_combo())
        self._show_scene_prompts()
        splitter = self._splitter("prompt", default=(45, 55))
        splitter.addWidget(self.prompt_panel)

        twin_view = self._make_twin_view()
        if twin_view is not None:
            twin_view.table_clicked.connect(self._on_table_clicked)
            splitter.addWidget(self._with_settings_panel(twin_view))
        else:
            # its own feed widget (one widget can't sit in two tabs); shows what the detector sees
            self.prompt_video = VideoWidget(self.camera, detector=self.detector,
                                            outline_provider=self._pick_area_outline,
                                            detections_when=lambda: bool(self._calibrated))
            self.prompt_video.pixel_clicked.connect(self._on_click_to_move)
            feed = QWidget()
            feed_column = QVBoxLayout(feed)
            feed_column.addWidget(self.prompt_video, stretch=1)
            hint = QLabel("Click the feed to move the arm above that spot "
                          "(ignored while a prompt is running). E-STOP always works.")
            hint.setWordWrap(True)
            hint.setStyleSheet("color: #9fb4c4;")
            feed_column.addWidget(hint)
            splitter.addWidget(feed)
        return self._restore_split(splitter)

    def _make_twin_view(self) -> QWidget | None:
        """The 3D view of the simulated workspace (demo mode only); each tab gets its own."""
        if self._twin_world is None:
            return None
        view = TwinView(self._twin_world, self.robot, settings=self.display_settings,
                        camera_view=lambda: (self.scene_builder.t_cam_to_robot, self.camera.get_intrinsics()),
                        detections_source=self._twin_detections, screenshots_dir=PROJECT_ROOT / "screenshots")
        return view

    def _build_manual_tab(self) -> QWidget:
        splitter = self._splitter("manual", default=(67, 33))
        # Demo mode: just the 3D view -- there is no real camera to look at, and clicking the
        # table in it moves the arm. Live mode: the real camera feed, where clicks move the arm.
        twin_view = self._make_twin_view()
        if twin_view is not None:
            twin_view.table_clicked.connect(self._on_table_clicked)
            splitter.addWidget(self._with_settings_panel(twin_view))
        else:
            splitter.addWidget(self._with_settings_panel(self.video_widget))
        self.jog_panel = JogPanel(
            self.robot, self._poses_dir(),
            self.config["robot"]["workspace_bounds"], self._on_bounds_changed,
            on_detect_floor=self._detect_floor, on_setting_changed=self._on_robot_setting_changed,
            on_pick_here=self._pick_here, on_gripper_opened=self.tool_executor.let_go_by_hand,
            on_gripper_closed=self._closed_by_hand, arm_busy=lambda: self.arm_busy("manual"),
        )
        self._jog_column = scrollable(self.jog_panel)
        splitter.addWidget(self._jog_column)
        self.video_widget.pixel_clicked.connect(self._on_click_to_move)
        return self._restore_split(splitter)

    # ---- the draggable dividers between the panes -----------------------------------------------------
    def _splitter(self, name: str, default: tuple[int, int]) -> QSplitter:
        """Two panes side by side with a divider you can drag; the widths are remembered (config.yaml, layout:)."""
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setObjectName(name)
        splitter.setChildrenCollapsible(False)   # dragged all the way, a pane stops at its smallest, not vanishes
        splitter.setHandleWidth(7)
        splitter.setProperty("default_split", default)
        save = QTimer(splitter)                  # saved once the dragging has stopped, not on every pixel
        save.setSingleShot(True)
        save.setInterval(500)
        save.timeout.connect(lambda: self._save_split(splitter))
        splitter.splitterMoved.connect(lambda *_: save.start())
        return splitter

    def _restore_split(self, splitter: QSplitter) -> QSplitter:
        saved = (self.config.get("layout") or {}).get(splitter.objectName())
        parts = saved if isinstance(saved, list) and len(saved) == splitter.count() else splitter.property("default_split")
        for index, part in enumerate(parts):
            splitter.setStretchFactor(index, int(part))
        total = sum(parts) or 1
        width = max(1000, self.width())
        splitter.setSizes([int(width * p / total) for p in parts])
        return splitter

    def _save_split(self, splitter: QSplitter) -> None:
        sizes = splitter.sizes()
        hidden = any(splitter.widget(i).isHidden() for i in range(splitter.count()))
        if len(sizes) != 2 or min(sizes) <= 0 or hidden:   # a pane hidden (the jog controls while Settings is open)
            return
        parts = [round(100 * s / sum(sizes)) for s in sizes]
        self.config.setdefault("layout", {})[splitter.objectName()] = parts
        try:
            config_path = self._config_file
            raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            raw.setdefault("layout", {})[splitter.objectName()] = parts
            atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            logger.warning("Could not remember the pane widths: %s", exc)

    def _on_bounds_changed(self, bounds: dict) -> None:
        self.config["robot"]["workspace_bounds"] = bounds
        if self.config.get("mode", "demo") == "demo":
            # Those bounds are the real robot's safety limits; don't let sim tinkering rewrite them.
            if bounds["z"][0] < DEMO_TABLE_Z_MM:
                # Also reached from the bounds editor's "Apply & Save", not just at startup -- the
                # demo's table is fixed at z = 0 no matter what a typed-in Z min says.
                bounds["z"][0] = DEMO_TABLE_Z_MM   # same dict as self.robot.bounds: fixes both at once
                self.statusBar().showMessage(
                    f"Demo mode: Z min raised to {DEMO_TABLE_Z_MM:.0f} mm (the demo table is fixed "
                    "there) and applied for this session only", 6000)
            else:
                self.statusBar().showMessage("Demo mode: bounds applied for this session only", 4000)
            return
        config_path = self._config_file
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        raw.setdefault(self._robot_section, {})["workspace_bounds"] = bounds
        atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
        logger.info("Workspace bounds updated: %s", bounds)
        self.statusBar().showMessage("Workspace bounds saved to config.yaml", 4000)

    # ---- Settings window ---------------------------------------------------------------
    def _with_settings_panel(self, view: QWidget) -> QWidget:
        """The 3D view (live: the camera feed) with the settings panel docked on its right (hidden until the Settings
        button)."""
        camera = ("Camera", self._depth_preset_box())
        cubes = ("Cubes", self._cube_size_box())
        if self._twin_world is None:
            panel = SettingsPanel(self.display_settings, extra_sections=[camera, cubes], view_options=False)
        else:
            panel = SettingsPanel(self.display_settings, scenes=list_scenarios(),
                                  current_scene=lambda: self._twin_world.scenario.get("name"),
                                  on_load_scene=self.load_scene, on_shuffle=self.shuffle_scene,
                                  extra_sections=[("Simulated camera", self._camera_box()), camera, cubes])
        panel.setVisible(self.settings_btn.isChecked())
        panel.close_requested.connect(lambda: self.settings_btn.setChecked(False))
        self._settings_panels.append(panel)
        holder = QWidget()
        row = QHBoxLayout(holder)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)
        row.addWidget(view, stretch=1)
        row.addWidget(panel)
        return holder

    # ---- Settings > Cubes: the study's cube size ------------------------------------------------------------------
    def _cube_size_box(self) -> QWidget:
        """The study's cubes: 25 or 20 mm (app/cube_size.py). One setting for the app (what its camera takes a cube to
        measure), the twin's study cubes and the watcher (finding and scoring), saved in config.yaml (vision:
        known_sizes_mm: cube). Locked while a prompt, a calibration or a watcher session is under way."""
        box = QWidget()
        column = QVBoxLayout(box)
        column.setContentsMargins(8, 6, 8, 8)
        row = QHBoxLayout()
        row.addWidget(QLabel("Cube size:"))
        row.addWidget(self._cube_size_combo(), stretch=1)
        column.addLayout(row)
        return box

    def _cube_size_combo(self) -> QComboBox:
        """One cube size list (Settings > Cubes, beside the prompt box): all kept in step, the one setting."""
        combo = QComboBox()
        for size in CUBE_SIZES_MM:
            combo.addItem(describe_cube(size), size)
        now = cube_mm(self.config)
        if combo.findData(now) < 0:                 # (another size typed into config.yaml: offered as it is)
            combo.addItem(describe_cube(now), now)
        combo.setCurrentIndex(combo.findData(now))
        combo.setToolTip("The size of the study's cubes (all the same). The app's camera takes a cube measured near "
                         "it to be that size; the watcher sets the twin's cubes out at it, finds and scores the "
                         "Dobot's by it; every session and run records it. Change it between studies, not during one.")
        combo.activated.connect(lambda _i, c=combo: self._on_cube_size(float(c.currentData())))
        self._cube_combos.append(combo)
        return combo

    def _show_cube_size(self, size: float) -> None:
        for combo in self._cube_combos:
            if combo.findData(size) < 0:
                combo.addItem(describe_cube(size), size)
            combo.setCurrentIndex(combo.findData(size))

    def _cube_size_refused(self) -> Optional[str]:
        """Why the cube size can't be changed now (something is using it), or None."""
        if self.prompt_panel.is_busy():
            return "a prompt is running: wait for it to finish (or press Stop)"
        panel = getattr(self, "calibration_tab", None)
        if getattr(panel, "_worker", None) is not None or getattr(panel, "_cube_phase1", None) is not None:
            return "a calibration is under way: finish it first"
        if getattr(self, "_watcher_active", False):
            return "the watcher's session is open: end it first"
        return None

    def _on_cube_size(self, size: float) -> None:
        current = cube_mm(self.config)
        if size == current:
            return
        refused = self._cube_size_refused()
        if refused:
            self._show_cube_size(current)
            self.statusBar().showMessage(f"Cube size not changed: {refused}.", 6000)
            return
        self._save_config_value(CUBE_SIZE_PATH, size)
        self._apply_cube_size()
        self._show_cube_size(size)
        panel = getattr(self, "calibration_tab", None)
        if self._twin_world is None and hasattr(panel, "set_cube_size"):
            panel.set_cube_size(size)               # (the Calibration tab's cube to start with; pick it there too)
        logger.info("Cube size set to %s (config.yaml vision: known_sizes_mm: cube)", describe_cube(size))
        # (a calibration made with any cube, its size given, holds for the other: the cube is only its marker)
        self.statusBar().showMessage(f"Cube size {describe_cube(size)} saved: the camera, the twin's study cubes and "
                                     "the watcher go by it. No need to calibrate again: check a pick or two with "
                                     "the new cubes.", 10000)

    def _apply_cube_size(self) -> None:
        """The scene builders take the size now (live; the demo's own scenes keep their cubes' sizes)."""
        executor = getattr(self, "tool_executor", None)
        if executor is not None:
            executor.cube_mismatch = None           # (looked at again at the next prompt's first look)
        if self._twin_world is not None:
            return
        for builder in (getattr(self, "scene_builder", None), getattr(self, "_twin_scene", None)):
            if builder is not None:
                builder.known_sizes = {**builder.known_sizes, "cube": cube_mm(self.config)}

    def _offer_cube_size(self) -> None:
        """A prompt found the cubes on the table measuring another size than the one set (nothing moved): offer to set
        it. Never changed by itself -- the user may know better (a cube read badly in one picture)."""
        mismatch = getattr(self.tool_executor, "cube_mismatch", None)
        if mismatch is None or self.prompt_panel.is_busy():
            return
        measured, setting, other = mismatch
        logger.warning("The cubes measure about %.1f mm; the cube size is set to %s", measured, describe_cube(setting))
        box = QMessageBox(QMessageBox.Icon.Warning, "Cube size",
                          f"The cubes on the table measure about {measured:.0f} mm, but the cube size is set to "
                          f"{describe_cube(setting)}.", parent=self)
        box.setInformativeText(f"Set it to {describe_cube(other)}? Nothing is moved until the size matches the cubes, "
                               f"or you say to keep {describe_cube(setting)}.")
        change = box.addButton(f"Set {describe_cube(other)}", QMessageBox.ButtonRole.AcceptRole)
        keep = box.addButton(f"Keep {describe_cube(setting)}", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(change)
        box.exec()
        if box.clickedButton() is change:
            self._on_cube_size(other)
        elif box.clickedButton() is keep:
            self.tool_executor.cube_size_kept = (setting, other)
            self.tool_executor.cube_mismatch = None
            logger.info("Cube size kept at %s (the cubes measured about %.1f mm)", describe_cube(setting), measured)

    # ---- Settings > Camera: the depth preset ----------------------------------------------------------------------
    def _depth_preset_box(self) -> QWidget:
        """The depth sensor's preset: Default, or High Accuracy (fewer depth points, but surer ones). Saved in
        config.yaml and loaded before the camera streams; changing it restarts the streams (a few seconds), so it is
        locked while anything is using the camera or the arm. One per Settings panel, all kept in step."""
        box = QWidget()
        column = QVBoxLayout(box)
        column.setContentsMargins(8, 6, 8, 8)
        row = QHBoxLayout()
        row.addWidget(QLabel("Depth preset:"))
        combo = QComboBox()
        combo.addItems(list(DEPTH_PRESETS))
        combo.setCurrentText(self._current_preset())
        combo.setToolTip("How the depth sensor trades coverage for certainty. Default: depth almost everywhere. "
                         "High Accuracy: only the points it is sure of (more gaps, e.g. at cube edges). A "
                         "calibration belongs to the preset it was made with.")
        combo.activated.connect(lambda _i, c=combo: self._on_depth_preset(c.currentText()))
        row.addWidget(combo, stretch=1)
        column.addLayout(row)
        self._preset_combos.append(combo)
        return box

    def _current_preset(self) -> str:
        return (getattr(self.camera, "depth_preset", None) or getattr(self.camera, "wanted_preset", None)
                or self._configured_preset())

    def _show_preset(self, name: str, enabled: bool = True) -> None:
        for combo in self._preset_combos:
            combo.setCurrentText(name)
            combo.setEnabled(enabled)

    def _preset_switching(self) -> bool:
        return self._preset_worker is not None     # (cleared once its result is handled)

    def _preset_change_refused(self) -> Optional[str]:
        """Why the depth preset can't be changed right now (the camera is being used, or the arm moves), or None."""
        if self._camera_setup_busy:
            return f"{self._camera_setup_busy}: wait for it to finish."
        if self._preset_switching():
            return "The depth preset is already being changed."
        if self.prompt_panel.is_busy():
            return "A prompt is running: wait for it to finish (or press Stop), then try again."
        if getattr(self.calibration_tab, "_worker", None) is not None:
            return "A calibration step is running: wait for it to finish, then try again."
        if getattr(self.robot, "motion", None) is not None or any(
                w is not None and w.isRunning() for w in (self._click_worker, self._floor_worker)):
            return "The arm is moving: try again when it has stopped."
        return None

    def _preset_mismatch(self, calib=None) -> Optional[str]:
        """A warning if the saved calibration was made with another depth preset than the camera has now."""
        calib = calib if calib is not None else load_calibration(self._calibration_path())
        made_with = (calib.extras or {}).get("depth_preset") if calib is not None else None
        now = getattr(self.camera, "depth_preset", None)
        if made_with and now and made_with != now:
            return (f"The calibration was made with the {made_with} depth preset and the camera is on {now} now: "
                    "switch back (Settings > Camera) or recalibrate.")
        return None

    def _on_depth_preset(self, name: str, asked: bool = False) -> None:
        """`asked`: Camera setup has already asked past its lock (and logs the change itself)."""
        current = self._current_preset()
        if name == current:
            return
        refused = self._preset_change_refused()
        if refused:
            self._show_preset(current, enabled=not self._preset_switching())
            self.statusBar().showMessage(f"Depth preset not changed: {refused}", 6000)
            return
        if not asked and not self._ask_past_lock(f"depth preset (to {name})"):
            self._show_preset(current)
            return
        switch = getattr(self.camera, "switch_depth_preset", None)
        if not self.camera_connected or switch is None:
            if hasattr(self.camera, "wanted_preset"):
                self.camera.wanted_preset = name
            self._save_config_value(("camera", self._preset_key()), name)
            self._show_preset(name)
            self.statusBar().showMessage(f"Depth preset {name} saved: it is loaded when the camera connects.", 6000)
            return
        self._show_preset(name, enabled=False)
        self.statusBar().showMessage(f"Changing the depth preset to {name} (the camera restarts its streams)...")
        self._preset_worker = CallableWorker(switch, name)
        self._preset_worker.finished_ok.connect(self._preset_switched)
        self._preset_worker.failed.connect(self._preset_failed)
        self._preset_worker.start()

    def _preset_switched(self, message: str) -> None:
        self._preset_worker = None
        now = self._current_preset()
        self._save_config_value(("camera", self._preset_key()), getattr(self.camera, "wanted_preset", now))
        self._show_preset(now)
        mismatch = self._preset_mismatch()
        logger.info(message)
        if mismatch:
            logger.warning(mismatch)
        self.statusBar().showMessage(message + (f" {mismatch}" if mismatch else ""), 10000)

    def _preset_failed(self, message: str) -> None:
        self._preset_worker = None
        self.camera_connected = False
        self.camera_status = f"Disconnected: {message}"
        self._update_camera_status_label()
        self._show_preset(self._current_preset())
        logger.error("Changing the depth preset failed: %s", message)
        self.statusBar().showMessage(f"Changing the depth preset failed: {message}", 10000)

    def _camera_box(self) -> QWidget:
        """The demo's simulated camera, made to behave like a real one: its picture quality, and a bump that knocks
        it out of place without telling the app. One per Settings panel, all kept in step."""
        box = QWidget()
        column = QVBoxLayout(box)
        column.setContentsMargins(8, 6, 8, 8)
        row = QHBoxLayout()
        row.addWidget(QLabel("Picture:"))
        quality = QComboBox()
        quality.addItems(list(PRESETS))
        quality.setCurrentText(self._quality_combos[0].currentText() if self._quality_combos else quality.currentText())
        quality.setToolTip("Perfect, or with the noise, holes and wrong pixels of a real depth camera")
        quality.currentTextChanged.connect(self._on_camera_quality)
        row.addWidget(quality, stretch=1)
        column.addLayout(row)
        bump = QPushButton("Undo bump" if self.camera.is_bumped else "Bump camera")
        bump.setToolTip("Knock the camera out of place without telling the app, to see the warning")
        bump.clicked.connect(self._toggle_bump)
        column.addWidget(bump)
        self._quality_combos.append(quality)
        self._bump_buttons.append(bump)
        self.sim_quality, self.bump_btn = self._quality_combos[0], self._bump_buttons[0]
        return box

    def _on_camera_quality(self, name: str) -> None:
        self.camera.set_faults(name)
        for combo in self._quality_combos:
            if combo.currentText() != name:
                combo.blockSignals(True)
                combo.setCurrentText(name)
                combo.blockSignals(False)
        self._update_camera_status_label()

    def _show_settings_panels(self, show: bool) -> None:
        for panel in self._settings_panels:
            panel.setVisible(show)
        # the settings take the jog controls' place on the Manual tab while open (E-STOP stays in the toolbar)
        self._jog_column.setVisible(not show)
        if show:   # a scene loaded from one tab's panel: the other shows the same choice
            name = self._twin_world.scenario.get("name") if self._twin_world is not None else None
            for panel in self._settings_panels:
                if panel.scene_combo is not None and panel.scene_combo.findData(name) >= 0:
                    panel.scene_combo.setCurrentIndex(panel.scene_combo.findData(name))

    def _open_settings(self) -> None:
        self.settings_btn.setChecked(True)

    def _scene_change_refused(self) -> Optional[str]:
        """Why the demo table can't be rearranged right now (objects would move from under the arm), or None."""
        if self._twin_world is None:
            return "Scenes are only for demo mode."
        if self.prompt_panel.is_busy():
            return "A prompt is running: wait for it to finish (or press Stop), then try again."
        if getattr(self.robot, "motion", None) is not None or (
                self._click_worker is not None and self._click_worker.isRunning()):
            return "The arm is moving: try again when it has stopped."
        return None

    def _show_scene_prompts(self) -> None:
        """Demo: the loaded scene's own prompts after "Try:" (live mode keeps the general ones)."""
        prompts = self._twin_world.scenario.get("prompts") if self._twin_world is not None else None
        if prompts:
            self.prompt_panel.set_examples(prompts)
        else:
            self.prompt_panel.set_examples(PromptPanel.EXAMPLES, featured=False)

    def _after_scene_change(self) -> None:
        """The table was rearranged: the robot tools and the object tracking start afresh."""
        if getattr(self, "prompt_panel", None) is not None:
            self._show_scene_prompts()
        self.tool_executor.forget_scene()
        self.scene_builder.reset_tracking()
        self._twin_scene.reset_tracking()
        self.drift.capture()               # the table looks different now; the camera hasn't moved

    def shuffle_scene(self, seed: Optional[int] = None) -> tuple[bool, str, Optional[int]]:
        """Demo: set the scene's objects out somewhere new (see twin/shuffle.py); `seed` repeats a layout.
        Returns (done, what to tell the user, the layout number)."""
        refused = self._scene_change_refused()
        if refused:
            return False, refused, None
        seed = int(seed) if seed is not None else random.randint(1, 99999)
        pose = self.robot.get_pose()
        world = self._twin_world
        layout = shuffle_layout(world.snapshot(), seed, world.places(), (pose.x, pose.y), self._camera_sees)
        if layout is None:
            return False, f"No layout {seed} keeps everything reachable and apart. Try another number.", seed
        self.robot._held = None            # whatever it was carrying stays behind
        self.robot._held_grip = None
        self.robot.open_gripper()
        turns = shuffle_turns(layout, seed)   # turned, too: the gripper has to line its fingers up with each
        for object_id, (x, y, z) in layout.items():
            world.set_object_position_mm(object_id, x, y, z, turns[object_id])
        self._after_scene_change()
        logger.info("Demo scene shuffled: layout %d", seed)
        return True, f"Shuffled: layout {seed}.", seed

    def _camera_sees(self, x: float, y: float, size: float, margin_px: float = 40.0) -> bool:
        """Whether a cube of this size standing at (x, y) is fully inside the simulated camera's picture."""
        to_camera = np.linalg.inv(self.camera.camera_to_robot_transform())
        k = self.camera.get_intrinsics()
        for dx in (-size / 2, size / 2):
            for dy in (-size / 2, size / 2):
                for z in (0.0, size):
                    q = to_camera @ np.array([x + dx, y + dy, z, 1.0])
                    if q[2] <= 0:
                        return False
                    u, v = k.fx * q[0] / q[2] + k.cx, k.fy * q[1] / q[2] + k.cy
                    if not (margin_px <= u <= k.width - margin_px and margin_px <= v <= k.height - margin_px):
                        return False
        return True

    def load_scene(self, name: str) -> tuple[bool, str]:
        """Demo: set out another scene (or the same one again, as it started). Refused while the arm is busy,
        since objects would vanish from under it. Returns (done, what to tell the user)."""
        refused = self._scene_change_refused()
        if refused:
            return False, refused
        self.robot._held = None            # whatever it was carrying goes with the old scene
        self.robot._held_grip = None
        self.robot.open_gripper()
        scene = self._twin_world.switch_scenario(name)
        self._after_scene_change()
        self.config.setdefault("twin", {})["scenario"] = name
        try:
            config_path = self._config_file
            raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            raw.setdefault("twin", {})["scenario"] = name
            atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            logger.warning("Could not remember the scene in config.yaml: %s", exc)
        title = scene.get("title", name)
        logger.info("Demo scene loaded: %s", title)
        self.statusBar().showMessage(f"Demo scene: {title}", 5000)
        return True, f"Loaded: {title}."

    def _pick_here(self) -> str:
        """Manual tab, "Pick here" (off the UI thread): the object nearest the gripper, within PICK_HERE_MM seen from
        above, picked up the way a prompt does it -- the camera finds it (the arm first moves out of its view), the
        fingers are centred and turned to it. Says what it did; raises, in words, when it can't."""
        if self.prompt_panel.is_busy():
            raise ValueError("A prompt is running: wait for it (or press Stop).")
        executor = self.tool_executor
        if executor.holding:
            raise ValueError(f"Already holding the {executor.holding}: open the gripper first.")
        here = self.robot.get_pose()
        executor.execute("list_objects", {})
        seen = [o for o in executor._last_scene if executor._covered_by(o) is None]
        if not seen:
            raise ValueError("The camera doesn't see anything to pick up.")
        nearest = min(seen, key=lambda o: math.hypot(o.xyz_robot[0] - here.x, o.xyz_robot[1] - here.y))
        distance = math.hypot(nearest.xyz_robot[0] - here.x, nearest.xyz_robot[1] - here.y)
        if distance > PICK_HERE_MM:
            raise ValueError(f"Nothing under the gripper: the nearest is the {nearest.label}, {distance:.0f} mm away "
                             f"at ({nearest.xyz_robot[0]:.0f}, {nearest.xyz_robot[1]:.0f}). Jog closer and try again.")
        result = executor.execute("pick", {"object_id": nearest.id})
        note = (executor.last_record.get("grip") or {}).get("note")
        return result + (f": {note}." if note else ".")

    def _closed_by_hand(self) -> None:
        """The Manual tab closed the gripper: the robot tools are told what it holds (the demo knows; the real
        gripper has no sensor, so there nothing changes)."""
        held_info = getattr(self.robot, "held_info", None)
        if held_info is not None:
            self.tool_executor.took_by_hand(held_info())

    def _arm_geometry(self):
        """Where the arm is now (its links), so the depth detector doesn't take it for an object."""
        state = getattr(self.robot, "arm_state", None)
        if state is not None:
            return state()[0]
        pose = self.robot.get_pose()
        # the arm model's heights are from the table (its base stands on it), the real Dobot's from its own zero,
        # some 35 mm above your table: taken as they were, the arm was looked for too low, and parts of it (the
        # marker card, the gripper) were reported as objects
        table_z = getattr(self, "_table_z_mm", None)      # (as measured; not measured again from in here)
        return self.robot_profile.geometry(pose.x, pose.y, pose.z, pose.r, table_z=table_z or 0.0)

    def _describe_setup(self) -> dict:
        """For the Model tab: the circumstances of a prompt (called on the agent's thread; reads only)."""
        scene = self._twin_world.scenario.get("title") if self._twin_world is not None else None
        return {"mode": self.config.get("mode", "demo"), "scene": scene,
                "step_by_step": bool(self.display_settings["step_by_step"])}

    def _apply_reasoning_setting(self) -> None:
        self.ollama_client.think = bool(self.display_settings["show_reasoning"])

    def _save_display_settings(self, values: dict) -> None:
        """Remembered in both modes: these are about how things look, not about the robot."""
        self.config["display"] = dict(values)
        config_path = self._config_file
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        raw["display"] = dict(values)
        atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))

    def _twin_detections(self) -> list:
        """What the camera finds right now, for the 3D view (runs off the UI thread)."""
        self._twin_scene.set_calibration(self.scene_builder.t_cam_to_robot)
        return [(o.label, o.xyz_robot, o.confidence, o.footprint) for o in self._twin_scene.get_scene()]

    def _on_robot_setting_changed(self, key: str, value: float) -> None:
        """The arm speed or gripper wait was changed in the Manual tab: remember it for the next start
        (live mode only; in the demo the choice lasts for the session)."""
        if key == "gripper_opening_mm":
            # the xArm's: how far its fingers open, for the planning, the robot (real or simulated) and the drawing
            self.tool_executor.gripper.opening_mm = value
            if getattr(self.robot, "gripper", None) is not None:
                self.robot.gripper.opening_mm = value
            if hasattr(self.robot, "opening_mm"):
                self.robot.opening_mm = value
            self.robot_profile.open_gap_mm = value
            self.config["robot"].setdefault("gripper", {})["opening_mm"] = value
            if self.config.get("mode", "demo") != "demo":
                try:
                    config_path = self._config_file
                    raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
                    section = raw.setdefault(self._robot_section, {})
                    section["gripper"] = dict(section.get("gripper") or {}, opening_mm=value)
                    atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
                except (OSError, ValueError, KeyError, TypeError) as exc:
                    logger.warning("Could not save the gripper opening to config.yaml: %s", exc)
            self.statusBar().showMessage(f"The gripper now opens {value:.0f} mm", 4000)
            return
        self.config["robot"][key] = value
        if self.config.get("mode", "demo") == "demo":
            return
        try:
            config_path = self._config_file
            raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            raw.setdefault(self._robot_section, {})[key] = value
            atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
            logger.info("Robot setting saved to config.yaml: %s = %s", key, value)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            logger.warning("Could not save %s to config.yaml: %s", key, exc)

    # ---- automatic Z floor -----------------------------------------------------
    def _detect_floor(self) -> None:
        """Measure the table with the depth camera and offer to set Z min just above it."""
        if not self._calibrated:
            QMessageBox.warning(self, "Calibrate first",
                                "Detecting the table height needs the camera calibration, to convert "
                                "what the camera sees into the robot's coordinates.")
            return
        if self._floor_worker is not None:
            return
        self.statusBar().showMessage("Measuring the table...", 0)
        self._floor_worker = CallableWorker(self._measure_table)
        self._floor_worker.finished_ok.connect(self._on_table_measured)
        self._floor_worker.failed.connect(self._on_table_measure_failed)
        self._floor_worker.start()

    def _measure_table(self):
        """Runs off the UI thread."""
        return measure_table(self.camera, self.scene_builder.t_cam_to_robot)
    def _on_table_measure_failed(self, message: str) -> None:
        self._floor_worker = None
        self.statusBar().clearMessage()
        QMessageBox.warning(self, "Could not measure the table", message)

    def _on_table_measured(self, plane) -> None:
        self._floor_worker = None
        self.statusBar().clearMessage()
        if plane is None:
            QMessageBox.warning(
                self, "No table found",
                "The camera didn't see a large, flat, level surface within the workspace. Make sure "
                "the table is in view and mostly clear, and that the calibration is correct.")
            return
        if not self._heights_checked():
            # without the table touch the camera's heights are unchecked: today's calibration put the table at
            # z = -179, where the tip touches it at about -35, and Z min was set 145 mm below the table -- no
            # longer a floor at all
            QMessageBox.warning(
                self, "Table height not set",
                f"The camera sees the table at z = {plane.z_mm:.0f} mm, but this calibration's heights haven't been "
                "checked against the arm: the table-touch step (step 5 in the Calibration tab) wasn't done. Without "
                "it the camera's heights can be far off (on this arm by 174 mm once), and a Z min set from them "
                "could let the arm drive into the table.\n\nDo the table-touch step: it measures the table with the "
                "arm's tip and sets Z min from that.")
            return
        floor, margin = suggest_floor(plane, self._calibration_error_mm)
        error = self._calibration_error_mm
        lines = [
            f"Table surface: z = {plane.z_mm:.0f} mm (robot coordinates), seen from "
            f"{plane.inlier_count} depth points ({plane.inlier_fraction:.0%} of the workspace view).",
            f"Suggested Z min: {floor:.0f} mm  (table + {margin:.0f} mm safety margin"
            + (f", because your calibration error is {error:.1f} mm)." if error is not None else ")."),
        ]
        warnings = []
        if plane.tilt_deg > 3.0:
            warnings.append(f"The table looks tilted by {plane.tilt_deg:.1f} degrees in robot coordinates. "
                            "A real table is level, so the calibration is probably inaccurate. "
                            "Recalibrate before trusting this number.")
        try:
            current_z = self.robot.get_pose().z
            if current_z < floor:
                warnings.append(f"The arm is currently at z = {current_z:.0f} mm, below this floor.")
        except Exception:  # noqa: BLE001 - robot may be disconnected; the number is still useful
            pass
        text = "\n\n".join(lines + warnings + ["Set Z min to this now?"])
        reply = QMessageBox.question(
            self, "Table height detected", text,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No if warnings else QMessageBox.StandardButton.Yes)
        if reply == QMessageBox.StandardButton.Yes:
            self.jog_panel.set_z_min(round(floor, 1))

    # ---- has the camera moved? ------------------------------------------------------------------------------
    def _panel_extras(self) -> dict:
        demo = self._twin_world is not None
        folder = self.config.get("paths", {}).get("sessions_dir", "sessions") + ("_demo" if demo else "")
        return dict(sessions_dir=PROJECT_ROOT / folder, context={"mode": self.config.get("mode", "demo")},
                    get_transform=lambda: self.scene_builder.t_cam_to_robot,
                    on_check_camera=self._check_camera_from_panel, on_remember_view=self._remember_view,
                    gripper=self.tool_executor.gripper,
                    place_cubes=self._place_more_cubes if demo else None,
                    on_cleared=self._calibration_cleared, on_wrist=self._reload_wrist,
                    wrist_settings=self._wrist_settings(), on_camera_setup=self._open_camera_setup,
                    arm_busy=lambda: self.arm_busy("calibration"), continuous=self.continuous,
                    # (live: the study's cube size to start with; the demo's calibration cube is measured)
                    cube_size_mm=None if demo else cube_mm(self.config))

    def _open_camera_setup(self) -> None:
        """Camera setup (step 0 of calibrating): place the camera and set its picture against targets
        (app/ui/camera_setup_dialog.py). Its own window, beside this one; one at a time."""
        dialog = getattr(self, "_camera_setup", None)
        try:
            visible = dialog is not None and dialog.isVisible()
        except RuntimeError:                     # (closed: Qt has deleted it)
            visible = False
        if visible:
            dialog.raise_()
            dialog.activateWindow()
            return
        from app.ui.camera_setup_dialog import CameraSetupDialog
        demo = self._twin_world is not None
        # the demo: the 3D model (the simulated camera's own picture isn't shown); live: the camera's picture
        make_view = self._make_twin_view if demo else (lambda: VideoWidget(self.camera, zoomable=True))
        cube = float((self.config["vision"].get("known_sizes_mm") or {}).get("cube", 25.0))
        expected = int(self.config["camera"].get("setup_cubes", 0))     # (0: not set -- any number; one is enough)
        if demo:                     # the demo's cubes are its own size, and as many as its world has
            sizes = [m["size"][0] for m in self._twin_world.object_meta.values()
                     if str(m.get("label", "")).endswith("cube")]
            cube = float(sorted(sizes)[len(sizes) // 2]) if sizes else cube
            expected = len(sizes)
        self._camera_setup = CameraSetupDialog(
            self.camera, make_view, self.config, self._save_config_value, self._controls_key(),
            self._calibration_path(), self._camera_setup_dir(), demo,
            robot=self.robot, cube_mm=cube, on_start_calibration=self._start_calibration_from_setup,
            hooks=self._camera_setup_hooks(), parent=self, lock_key=self._lock_key(), expected_cubes=expected,
            cubes_key=None if demo else "setup_cubes")
        self._camera_setup.show()

    def _hold_for_camera_setup(self, reason: Optional[str]) -> None:
        """While Camera setup compares, sweeps the exposure or moves the arm for its shake test: nothing else uses the
        camera or the arm -- the tabs (prompts, calibration, jogging), the depth preset and the watcher's Start run
        are held. E-STOP (the toolbar) stays."""
        self._camera_setup_busy = reason
        self.tabs.setEnabled(reason is None)
        if reason:
            self.statusBar().showMessage(f"{reason}: the app waits for it (E-STOP still works).")
        else:
            self.statusBar().clearMessage()

    def _arm_refused(self) -> Optional[str]:
        """Why the arm can't be moved for Camera setup's shake test right now, or None."""
        if self._watcher_active:
            return "the watcher's session is open: end it first."
        if getattr(self.robot, "_estopped", False):
            return "E-STOP is on: reset it first (Manual tab)."
        return self._preset_change_refused()

    def _camera_setup_hooks(self):
        """What Camera setup may read and set of the app: the depth preset (and switching it for a comparison), the
        detection, and the calibration in use."""
        from types import SimpleNamespace

        def calibration_preset():
            calib = load_calibration(self._calibration_path())
            return (calib.extras or {}).get("depth_preset") if calib is not None else None
        return SimpleNamespace(
            presets=DEPTH_PRESETS, current_preset=self._current_preset, preset_refused=self._preset_change_refused,
            switch_preset=lambda name: self.camera.switch_depth_preset(name),
            apply_preset=lambda name: self._on_depth_preset(name, asked=True), preset_switching=self._preset_switching,
            arm_refused=self._arm_refused, hold=self._hold_for_camera_setup,
            calibration_preset=calibration_preset, is_calibrated=lambda: bool(self._calibrated),
            get_transform=lambda: self.scene_builder.t_cam_to_robot, detect_both=self._detect_both,
            current_detection=lambda: "any" if self.detection_settings.find == FIND_ANY else "cubes",
            apply_detection=lambda key: self.detection_settings.update(find=FIND_ANY if key == "any" else FIND_CUBES),
            # the demo: the simulator's exact calibration for wherever its camera is now
            restore_builtin=self._restore_builtin_calibration if self._twin_world is not None else None)

    def _detect_both(self, frame, transform) -> dict:
        """Both detectors on one picture, as the app would use each (its settings' size, height and pick-area rules):
        {"any": [LocatedObject], "cubes": [LocatedObject]} -- for Camera setup's comparison."""
        detector, settings = self.detector, self.detection_settings
        depth_found = [loc for _, loc in detector.depth.find(frame.rgb, frame.depth, frame.intrinsics, transform)
                       if settings.keeps(loc) is None]
        colour_found = []
        for det in detector.colour.detect(frame.rgb):
            loc = locate_detection(det, frame.depth, frame.intrinsics, transform)
            if loc is not None and settings.keeps(loc) is None:
                colour_found.append(loc)
        return {"any": depth_found, "cubes": colour_found}

    def _start_calibration_from_setup(self) -> None:
        """Camera setup's "Start calibration": the Calibration tab, and the cube calibration (it asks first)."""
        panel = getattr(self, "calibration_tab", None)
        if panel is None or not hasattr(panel, "_start_cube"):
            return
        self.tabs.setCurrentWidget(panel)
        panel._start_cube()

    def _place_more_cubes(self, count: int) -> str:
        """Demo, cube calibration: what the user does by hand at the lab -- put 1 or 2 more cubes, like the one in the
        gripper, on the table near the middle, well apart."""
        world = self._twin_world
        held = getattr(self.robot, "_held", None)
        size = world.object_meta[held]["size"] if held in world.object_meta else (20.0, 20.0, 20.0)
        ox, _ = self.robot_profile.scene_offset_mm
        placed = []
        for index, (y, colour, name) in enumerate(((-60.0, [0.1, 0.2, 0.8, 1], "blue"),
                                                    (100.0, [0.1, 0.6, 0.2, 1], "green"))[:count]):
            x = 230.0 + ox
            n = sum(1 for object_id in world.object_ids if object_id.startswith(f"{name}_extra_cube"))
            world.add_object({"id": f"{name}_extra_cube{n or ''}", "label": f"{name} cube" + (f" {n + 1}" if n else ""),
                              "color_rgba": colour, "size_mm": list(size), "position_mm": [x, y, size[2] / 2.0]})
            placed.append(f"a {name} one at ({x:.0f}, {y:.0f})")
        return f"Demo: {' and '.join(placed)} put on the table."

    def _start_drift_watch(self) -> None:
        """Demo: remember the perfect starting view. Live: compare with the saved one, if any."""
        if self._twin_world is not None:
            QTimer.singleShot(400, self.drift.capture)
        elif self._calibrated and self.drift.has_reference:
            QTimer.singleShot(3000, self._startup_drift_check)

    def _startup_drift_check(self) -> None:
        self._drift_say = None
        self._drift_startup = True
        self.drift.check()

    def _check_camera_from_panel(self, say: Callable) -> None:
        self._drift_say = say
        say("Checking the camera position...")
        self.drift.check()

    def _remember_view(self, say: Callable) -> None:
        reply = QMessageBox.question(
            self, "Remember this view?",
            "Only do this if the calibration is good right now (for example after verifying it). From now on "
            "the app will warn if the camera looks moved compared with this view.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        say("Saving the view...")
        self._forget_remember_view()

        def saved() -> None:
            self._forget_remember_view()
            say("Saved. The app will now warn if the camera moves.")

        def failed(message: str) -> None:
            self._forget_remember_view()
            say(f"The view couldn't be saved: {message}. Try again.", "bad")
        self._remember_answers = (saved, failed)
        self.drift.reference_saved.connect(saved)
        self.drift.capture_failed.connect(failed)
        self.drift.capture()

    def _forget_remember_view(self) -> None:
        """The answers "Remember this view" waits for, disconnected (else the next capture, for anything, said
        "Saved." on the Calibration tab)."""
        answers, self._remember_answers = getattr(self, "_remember_answers", None), None
        if answers is None:
            return
        for signal, slot in zip((self.drift.reference_saved, self.drift.capture_failed), answers):
            try:
                signal.disconnect(slot)
            except TypeError:                 # (not connected any more)
                pass

    def _on_drift_report(self, report) -> None:
        if report.status == "moved":
            self.drift_label.setText("<span style='color:#ff8a8a'>Camera moved? Recalibrate</span>")
        elif report.status == "ok":
            self.drift_label.setText("<span style='color:#7fe0b0'>Camera position OK</span>")
        else:
            self.drift_label.setText("")
        if self._drift_say is not None:
            self._drift_say(report.message, {"moved": "bad", "ok": "good"}.get(report.status, "warn"))
            self._drift_say = None
        elif report.status == "moved" and getattr(self, "_drift_startup", False):
            self._notify("The camera may have moved", report.message)
        self._drift_startup = False

    def _toggle_bump(self) -> None:
        if self.drift.checking or self.drift._capturing:
            self.statusBar().showMessage("Wait for the camera check to finish before bumping again.", 3000)
            return
        if self.camera.is_bumped:
            self.camera.unbump()
        else:
            self.camera.bump()
        for button in self._bump_buttons:
            button.setText("Undo bump" if self.camera.is_bumped else "Bump camera")
        self._update_camera_status_label()
        self.drift.check()

    def _notify(self, title: str, text: str) -> None:
        """A message the app raises by itself (nobody clicked anything). It must not block the window, or
        the E-STOP button could not be pressed until it was dismissed: so it is not modal."""
        box = QMessageBox(QMessageBox.Icon.Warning, title, text, QMessageBox.StandardButton.Ok, self)
        box.setWindowModality(Qt.WindowModality.NonModal)
        box.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        box.show()

    def _log_memory(self) -> None:
        """One line a minute in the log (app.log too), so a slow memory build-up can be seen afterwards, and a
        warning if the app itself is far bigger than it ever should be. (The language model is separate.)"""
        app_mb = app_memory_mb()
        system = system_memory_gb()
        if app_mb is None:
            return
        logger.info("Memory: this app %.0f MB%s", app_mb,
                    f"; PC {system[1]:.1f} of {system[0]:.1f} GB free" if system else "")
        if app_mb > ALARM_APP_MB and not self._memory_warned:
            self._memory_warned = True
            logger.critical("The app is using %.1f GB, far more than the usual ~%.0f MB", app_mb / 1000, NORMAL_APP_MB)
            self._notify(
                "The app is using a lot of memory",
                f"This app is using {app_mb / 1000:.1f} GB. It normally needs well under 1 GB, so something is wrong "
                "(the language model is counted separately). Nothing has been closed or changed: save your work and "
                "restart it when convenient, and please send app.log from the project folder.")

    # ---- Detection window -------------------------------------------------------------------------------
    def _open_detection(self) -> None:
        if self._setup_locked() and QMessageBox.question(
                self, "Locked for study", "The camera setup is locked for the study, the detection with it. Open the "
                "Detection window anyway? (Any change is logged.)") != QMessageBox.StandardButton.Yes:
            return
        if getattr(self, "_detection_dialog", None) is None:
            from app.ui.detection_dialog import DetectionDialog, ExposureHooks
            demo = self._vision_section == "vision_demo"
            # the camera's exposure too (coloured cubes need a fixed one): kept where Camera setup keeps it
            exposure = ExposureHooks(
                camera=self.camera, save=lambda values: self._save_config_value(("camera", self._controls_key()), values),
                locked=self._setup_locked, refused=self._preset_change_refused,
                saved=lambda: self.config["camera"].get(self._controls_key()) or {}) \
                if hasattr(self.camera, "controls") else None
            self._detection_dialog = DetectionDialog(self.detection_settings, self, demo=demo,
                                                     exposure=exposure)   # one window, reused
            self._detection_dialog.setWindowTitle("Detection (demo)" if demo else "Detection (real camera)")
        self._detection_dialog.show()
        self._detection_dialog.raise_()
        self._detection_dialog.activateWindow()

    def _on_detection_settings_changed(self) -> None:
        """What the camera counts as an object changed: what the tools and the 3D view have seen is looked at
        afresh (another detector names things its own way), and the choice kept (a moment after the last change)."""
        self.scene_builder.reset_tracking()
        self._twin_scene.reset_tracking()
        self._detection_save.start(600)
        if self._setup_locked():               # (locked for the study: every change is on record)
            self._log_setup_change(f"detection settings changed while locked: {self.detection_settings.to_config()}")

    def _save_detection_settings(self) -> None:
        values = self.detection_settings.to_config()
        section = self._vision_section           # vision: the real camera's; vision_demo: the demo's own
        self.config.setdefault(section, {}).update(values)
        try:
            config_path = self._config_file
            raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            raw.setdefault(section, {}).update(values)
            atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
            logger.info("Detection settings (%s) saved to config.yaml: %s", section, values)
        except Exception as exc:  # noqa: BLE001 - not saved is worth a line in the log, not a crash
            logger.warning("Couldn't save the detection settings to config.yaml: %s", exc)

    def _pick_area_outline(self) -> Optional[list[tuple[float, float]]]:
        """The pick area's corners on the table, as camera pixels (for the dashed outline on the feed), or None."""
        area = self.detection_settings.pick_area
        if not area or not self._calibrated:
            return None
        try:
            intrinsics = self.camera.get_intrinsics()
            to_camera = np.linalg.inv(np.asarray(self.scene_builder.t_cam_to_robot, float))
        except Exception:  # noqa: BLE001 - no picture of the area is no reason to fail
            return None
        table_z = getattr(self, "_table_z_mm", None) if self._twin_world is None else 0.0
        corners = [(area["x"][0], area["y"][0]), (area["x"][1], area["y"][0]),
                   (area["x"][1], area["y"][1]), (area["x"][0], area["y"][1])]
        pixels = []
        for x, y in corners:
            cx, cy, cz = (to_camera @ np.array([x, y, table_z or 0.0, 1.0]))[:3]
            if cz <= 1.0:
                return None
            pixels.append((intrinsics.fx * cx / cz + intrinsics.cx, intrinsics.fy * cy / cz + intrinsics.cy))
        return pixels

    def _open_watcher(self) -> None:
        """The study's watcher (watcher/window.py), in a window of its own beside this one."""
        if getattr(self, "_watcher_window", None) is None:
            from watcher.window import WatcherWindow
            context = self._watcher_context()
            context.on_session_active, context.make_3d_view = self._on_watcher_session, self._make_twin_view
            self._watcher_window = WatcherWindow(context)
        self._watcher_window.show()
        self._watcher_window.raise_()
        self._watcher_window.activateWindow()

    def _watcher_context(self):
        """What the watcher (and Watcher active's recorder) works with: the app's robot, camera and tools as they are
        now."""
        from watcher.window import WatcherContext
        return WatcherContext(
            robot=self.robot, camera=self.camera, scene_builder=self.scene_builder, executor=self.tool_executor,
            agent=self.agent, config=self.config, mode=self.config.get("mode", "demo"), estop=self._on_estop,
            poses_dir=self._poses_dir(), calibration_file=self._calibration_path(), twin_world=self._twin_world,
            held=self._watcher_held, calibration_state=self._calibration_state)

    def _watcher_held(self) -> Optional[str]:
        """Why the watcher mustn't start a session or a run now (None: it may): Camera setup using the camera or the
        arm, a calibration step, a click-to-move or the Manual tab moving the arm, or a prompt typed here still
        running -- or one stopped whose model call hasn't come back yet (the two would send moves to the same arm
        through the same tools). See arm_busy."""
        return self.arm_busy("watcher")

    def arm_busy(self, asking: str) -> Optional[str]:
        """Why the arm is someone else's right now (None: free), in words: the one check every part of the app that
        moves the arm makes before it starts -- a calibration step ("calibration"), the Manual tab's buttons
        ("manual"), click-to-move ("click"), a prompt ("prompt"), the watcher's Start ("watcher"). Each one's own
        work is left out (it guards that itself). E-STOP never asks: it always works."""
        if self._camera_setup_busy:
            return f"{self._camera_setup_busy}: wait for it to finish"
        panel = getattr(self, "calibration_tab", None)
        if asking != "calibration" and getattr(panel, "_worker", None) is not None:
            return "a calibration step is running: wait for it to finish (or press its Stop)"
        prompts = getattr(self, "prompt_panel", None)
        if asking != "prompt" and prompts is not None and (prompts.is_busy() or getattr(prompts, "_abandoned", None)):
            return "a prompt typed in the main window is still running (or finishing after Stop)"
        if asking != "click" and self._click_worker is not None and self._click_worker.isRunning():
            return "the arm is still moving to where you clicked"
        jog = getattr(self, "jog_panel", None)
        if asking != "manual" and jog is not None and any(w.isRunning() for w in list(jog._workers)):
            return "the arm is still doing what the Manual tab asked (a jog, Home, the gripper)"
        if asking == "calibration" and self._watcher_active:
            return "the watcher's session is open: end it first"
        return None

    def _on_watcher_session(self, active: bool) -> None:
        # while the watcher runs a session nobody types a prompt of their own in between
        self._watcher_active = bool(active)
        self.prompt_panel.setEnabled(not active)
        # the twin is the study's ideal-hardware reference: its camera is perfect for the session, then as it was
        if self._twin_world is not None and getattr(self, "sim_quality", None) is not None:
            if active:
                self._quality_before_watcher = self.sim_quality.currentText()
                self._on_camera_quality("Perfect")
            elif getattr(self, "_quality_before_watcher", None):
                self._on_camera_quality(self._quality_before_watcher)
                self._quality_before_watcher = None

    def _open_system_check(self) -> None:
        def make_context() -> CheckContext:
            return CheckContext(
                mode=self.config.get("mode", "demo"), config=self.config, robot=self.robot, camera=self.camera,
                detector=self.detector, get_transform=lambda: self.scene_builder.t_cam_to_robot,
                calibrated=self._calibrated, calibration_error_mm=self._calibration_error_mm,
                calibration_file=self._calibration_path(),
                drift_check=lambda: self.drift.check_now() if self.drift.has_reference else None,
                ollama=self.ollama_client, model=self.agent.model)
        if getattr(self, "_system_check", None) is None:
            self._system_check = SystemCheckDialog(make_context, self, log_panel=self.log_panel)   # one window, reused: not one per click
        self._system_check.show()
        self._system_check.raise_()
        self._system_check.activateWindow()
        self._system_check.run()

    def _table_z(self) -> Optional[float]:
        """The table's height in robot coordinates, for putting things down on it. Demo: the simulator's
        table is z = 0. Live: what the tip measured when it touched the table (calibration step 5),
        otherwise what the depth camera sees (measured once and kept). Runs on the agent's thread."""
        if self._twin_world is not None:
            return 0.0
        if self._table_z_mm is None and time.monotonic() - self._table_z_tried_at > 60.0:
            self._table_z_tried_at = time.monotonic()      # if it can't be seen, don't retry on every look at the table
            plane = measure_table(self.camera, self.scene_builder.t_cam_to_robot)
            if plane is not None:
                self._table_z_mm, self._table_z_source = plane.z_mm, "camera"
                logger.info("Table height for placing objects: z = %.0f mm (from the camera)", plane.z_mm)
        return self._table_z_mm

    def _heights_checked(self) -> bool:
        """Whether the camera's heights have been checked against the arm (the table-touch step), so a table height
        it measures can be trusted for Z min. The demo's built-in calibration is exact."""
        if self._twin_world is not None:
            return True
        calib = load_calibration(self._calibration_path())
        return calib is not None and ("table" in str(calib.method) or str(calib.method).startswith("cube"))

    def _on_table_touched(self, z_touch: float) -> None:
        """The calibration panel found the table at this robot height (the tip was touching it):
        set the Z floor just above it. Exact, so no guessing from the camera is involved."""
        self._table_z_mm, self._table_z_source = z_touch, "touch"
        # The tip measured the table itself, in the arm's own frame: the camera's calibration error has nothing to do
        # with it. (The floor was put twice that error above the table -- 39 mm with a 19.5 mm calibration -- and a
        # 24 mm cube was "outside the safe workspace": its sides are lower than that.)
        margin = TOUCHED_FLOOR_MM
        floor = z_touch + margin
        self.jog_panel.set_z_min(round(floor, 1))
        self.statusBar().showMessage(
            f"Table height set: z = {z_touch:.0f} mm. Z min is now {floor:.0f} mm "
            f"(table + {margin:.0f} mm margin).", 8000)
    def _calibration_view(self) -> QWidget:
        """Demo: the Calibration tab's 3D model; a click on the table moves the arm there, as on the other tabs --
        except while a calibration is under way (the table touched, the cube held, a step running)."""
        view = self._make_twin_view()

        def clicked(x_mm: float, y_mm: float) -> None:
            if self._calibration_busy():
                self.statusBar().showMessage("Click-to-move is off while a calibration is under way.", 4000)
                return
            self._on_table_clicked(x_mm, y_mm)
        view.table_clicked.connect(clicked)
        return view

    def _build_calibration_tab(self) -> QWidget:
        calib_path = self._calibration_path()
        try:
            if self._twin_world is not None:  # demo mode
                panel = CalibrationPanel(
                    self.robot, self.camera, calib_path, self._on_calibrated,
                    on_table_touched=self._on_table_touched, **self._panel_extras(),
                    note=("Demo mode: you don't need to calibrate. The simulator already knows exactly "
                          "where its camera is, so the demo uses a built-in exact calibration. This tab "
                          "is only for practising the steps. The view is the 3D model (calibrating by hand, "
                          "clicking points on the camera's picture, is for the real camera)."),
                    on_reset_builtin=self._restore_builtin_calibration,
                    # the 3D model, the real Magician's shape -- not the simulated camera's picture, which draws the
                    # arm from plain shapes (the calibration still uses that camera, unseen)
                    feed_widget=self._calibration_view())
                # learning the cube calibration: watched, or done with each step checked (cube_tour.py)
                self.cube_tour = CubeTour(panel, self)
                panel.cube_box.layout().insertWidget(1, self.cube_tour)
                return panel
            return CalibrationPanel(self.robot, self.camera, calib_path, self._on_calibrated,
                                    on_table_touched=self._on_table_touched, **self._panel_extras())
        except Exception as exc:  # noqa: BLE001 - e.g. camera unavailable, no intrinsics yet
            logger.error("Calibration tab unavailable: %s", exc)
            placeholder = QLabel(f"Calibration unavailable: {exc}")
            placeholder.setWordWrap(True)
            placeholder.setStyleSheet("padding: 20px; color: #e0a030;")
            return placeholder

    # ---- the cube calibration walk-through (demo: cube_tour.py) ---------------------------------------------------
    TOUR_CUBE = "red cube"
    LEARN_SCENE = "learn_cube_calibration"

    def _set_out_one_cube(self, size_mm: float) -> None:
        """Demo: the table cleared but for one cube of `size_mm`, in the middle of the working area (the cube
        calibration's table). Whatever the gripper held goes with the old scene."""
        robot, world = self.robot, self._twin_world
        robot._held, robot._held_grip = None, None
        robot.open_gripper()
        cube = {"id": "red_cube", "label": self.TOUR_CUBE, "color_rgba": [0.8, 0.1, 0.1, 1], "size_mm": size_mm,
                "position_mm": [230.0, 0.0, size_mm / 2.0]}
        world.switch_scenario(self.LEARN_SCENE, {
            "name": self.LEARN_SCENE, "title": f"One {size_mm:.0f} mm cube, for calibrating",
            "description": "One cube on an empty table, for the cube calibration (Calibration tab).",
            "objects": [cube], "prompts": [], "places": {}, "cube_mm": size_mm})
        self._after_scene_change()

    def _set_out_scene(self, name: Optional[str], cube_mm: Optional[float] = None) -> None:
        """Demo: set out scene `name` again (the one-cube calibration table with its cube size, or a scene file)."""
        if name == self.LEARN_SCENE:
            self._set_out_one_cube(float(cube_mm or 20.0))
            return
        self.robot._held, self.robot._held_grip = None, None
        self.robot.open_gripper()
        self._twin_world.switch_scenario(name or DEFAULT_SCENE)
        self._after_scene_change()

    def _calibration_cube_mm(self) -> float:
        tour = getattr(self, "cube_tour", None)
        return float(tour.size_box.currentData()) if tour is not None else 20.0

    def _calibration_busy(self) -> bool:
        """A cube calibration under way (the table touched, the cube held, a step running, the walk-through)."""
        panel = getattr(self, "calibration_tab", None)
        tour = getattr(self, "cube_tour", None)
        return bool((tour is not None and tour.mode is not None) or getattr(panel, "_worker", None) is not None
                    or getattr(panel, "_cube_phase1", None) is not None or getattr(panel, "_touches", None)
                    or getattr(panel, "_progress", None) is not None)

    def _on_tab_changed(self, index: int) -> None:
        """Demo: opening the Calibration tab sets out its one-cube table (the scene that was there is remembered);
        going to the Prompt tab puts that scene back, unless a calibration is under way. (The Manual tab leaves it:
        it is where the arm is jogged while calibrating.)"""
        widget = self.tabs.widget(index)
        if widget is self.calibration_tab:
            if self._twin_world.scenario.get("name") == self.LEARN_SCENE or self._scene_change_refused():
                return
            self._scene_before_calibration = self._twin_world.scenario.get("name")
            self._set_out_one_cube(self._calibration_cube_mm())
            self.statusBar().showMessage("Demo: one cube on the table for calibrating (the Prompt tab puts the scene "
                                         "back)", 5000)
        elif index == self._prompt_tab_index:
            before = getattr(self, "_scene_before_calibration", None)
            if (before is None or self._twin_world.scenario.get("name") != self.LEARN_SCENE
                    or self._calibration_busy() or self._scene_change_refused()):
                return
            self._scene_before_calibration = None
            self._set_out_scene(before)
            self.statusBar().showMessage(f"Demo: the scene is back ({self._twin_world.scenario.get('title', before)})",
                                         5000)

    def _calibration_cube_resized(self) -> None:
        """Demo: another cube size chosen on the Calibration tab (the walk-through not running): that cube instead."""
        if (self._twin_world.scenario.get("name") == self.LEARN_SCENE and not self._calibration_busy()
                and not self._scene_change_refused()):
            self._set_out_one_cube(self._calibration_cube_mm())

    def tour_setup(self, size_mm: float, lab_like: bool, speed_factor: float) -> Optional[str]:
        """Set the demo up for the walk-through: one cube of `size_mm` on an empty table, the camera and the wrist as
        at the lab (or perfect), the arm `speed_factor` times its speed. What was in use is kept to put back
        (tour_teardown). Returns why it can't start, or None."""
        refused = self._scene_change_refused()
        if refused:
            return refused
        if getattr(self.calibration_tab, "_worker", None) is not None:
            return "A calibration step is running: wait for it to finish."
        if getattr(self.calibration_tab, "_cube_phase1", None) is not None:
            return "A cube calibration is waiting for its next step: press Finish first."
        robot, world = self.robot, self._twin_world
        path = self._calibration_path()
        self._tour_saved = {
            "calibration": path.read_bytes() if path.exists() else None,
            "scene": world.scenario.get("name"), "scene_cube_mm": world.scenario.get("cube_mm"),
            "faults": self.sim_quality.currentText(),
            "speed": robot.max_speed,
            "wrist": (robot.fingers_turned_deg, robot.wrist_gain, robot.wrist_backlash_deg),
            "known": (dict(self.scene_builder.known_sizes), dict(self._twin_scene.known_sizes)),
        }
        self._set_out_one_cube(size_mm)
        self._on_camera_quality("Realistic" if lab_like else "Perfect")
        robot.fingers_turned_deg, robot.wrist_gain, robot.wrist_backlash_deg = (3.0, 0.95, 2.0) if lab_like else (
            0.0, 1.0, 0.0)
        robot._wrist_real = None
        robot.max_speed = self._tour_saved["speed"] * speed_factor
        for builder in (self.scene_builder, self._twin_scene):
            builder.known_sizes["cube"] = float(size_mm)
        logger.info("Calibration walk-through: a %.0f mm cube%s, the arm %gx its speed", size_mm,
                    ", like the lab" if lab_like else "", speed_factor)
        return None

    def tour_teardown(self) -> None:
        """Put back what tour_setup found: the scene, the camera, the wrist, the speed, the known sizes, and the
        calibration in use (the one made while learning is dropped, with any run left part-way)."""
        saved = getattr(self, "_tour_saved", None)
        if saved is None:
            return
        self._tour_saved = None
        robot, world = self.robot, self._twin_world
        robot._held, robot._held_grip = None, None
        robot.open_gripper()
        robot.fingers_turned_deg, robot.wrist_gain, robot.wrist_backlash_deg = saved["wrist"]
        robot._wrist_real = None
        robot.max_speed = saved["speed"]
        self._on_camera_quality(saved["faults"])
        self.scene_builder.known_sizes, self._twin_scene.known_sizes = saved["known"]
        self._set_out_scene(saved["scene"], saved.get("scene_cube_mm"))
        path = self._calibration_path()
        from app.calibration.cube import progress_path
        progress_path(path).unlink(missing_ok=True)
        panel = getattr(self, "calibration_tab", None)
        if panel is not None and hasattr(panel, "_progress"):
            panel._progress = None
        if saved["calibration"] is None:
            self._restore_builtin_calibration()
        else:
            self._continuous_replaced()
            path.write_bytes(saved["calibration"])
            transform = self._load_or_identity_transform()
            self.scene_builder.set_calibration(transform, self._saved_correction(transform))
            self.drift.capture()
        logger.info("Calibration walk-through ended: the demo is as it was")

    def tour_cube(self) -> Optional[tuple[float, float, float]]:
        """The walk-through's cube: (x, y, the height of its top), or None if it isn't on the table."""
        world = self._twin_world
        for object_id, meta in list(world.object_meta.items()):
            if meta.get("label") == self.TOUR_CUBE:
                x, y, z = world.get_object_position_mm(object_id)
                return x, y, z + meta["size"][2] / 2.0
        return None

    def _restore_builtin_calibration(self) -> None:
        """Demo mode: drop a practised (rougher) calibration and go back to the exact one."""
        self._continuous_replaced()
        self._calibration_path().unlink(missing_ok=True)
        self.scene_builder.set_calibration(self.camera.camera_to_robot_transform())
        if hasattr(self.robot, "tool_centre_mm"):
            self.robot.tool_centre_mm = (0.0, 0.0)          # (the gripper's offset goes with a calibration)
        self._calibrated_jaw = None
        self._apply_jaw()
        self._calibrated_wrist = None                     # (the wrist model goes with it too)
        self._apply_wrist()
        self._calibrated = True
        self._calibration_error_mm = 0.0
        self.drift.capture()
        self.statusBar().showMessage("Demo: built-in exact calibration restored", 4000)

    def _calibration_cleared(self) -> None:
        """The Calibration tab cleared the calibration: none in use (the demo: back to its exact one)."""
        self._continuous_replaced()
        if self._twin_world is not None:
            self._restore_builtin_calibration()
            return
        self.scene_builder.set_calibration(np.eye(4))
        if hasattr(self.robot, "tool_centre_mm"):
            self.robot.tool_centre_mm = (0.0, 0.0)          # (the gripper's offset goes with a calibration)
        self._calibrated_jaw = None
        self._apply_jaw()
        self._calibrated_wrist = None                     # (the wrist model goes with it too)
        self._apply_wrist()
        self._calibrated = False
        self._calibration_error_mm = None
        self._table_z_mm = None
        self.statusBar().showMessage("Calibration cleared: picking by camera is off until you calibrate", 6000)

    # ---- the continuous calibration (ui/continuous_monitor.py) --------------------------------------------------
    def _continuous_held(self) -> Optional[str]:
        """Why the continuous calibration mustn't look (or correct) now, or None: the arm busy, a cube calibration's
        steps under way, a watcher run going (its calibration stays the same from start to end)."""
        why = self.arm_busy("continuous")
        if why:
            return why
        panel = getattr(self, "calibration_tab", None)
        if getattr(panel, "_cube_phase1", None) is not None or getattr(panel, "_cube_running", False):
            return "the cube calibration's steps are under way (Finish them first)"
        watcher = getattr(self, "_watcher_window", None)
        if watcher is not None and getattr(watcher, "session", None) is not None:
            if getattr(watcher, "state", "") in ("running", "verdict"):
                return "a watcher run is under way (corrections wait until it has ended)"
            if getattr(watcher, "_busy", False):
                return "the watcher is looking at the table"
        return None

    def _sheet_corners(self, frame, intrinsics, transform: np.ndarray):
        """The A4 sheet's corners in the camera's coordinates: found in the picture (live), or where the twin's
        camera really is (demo: the twin's sheet isn't in its pictures)."""
        from app.calibration import continuous
        if self._twin_world is not None:
            return continuous.twin_corners(self.camera, table_z=0.0)
        return continuous.real_corners(frame, intrinsics, transform)

    def _apply_continuous(self, t_cam_to_robot: np.ndarray, action: str, record: dict) -> None:
        """The continuous calibration corrected the calibration (or went back to the last good one): saved in place
        (everything the cube calibration measured kept with it; not archived -- the one it started from is), and used
        from now on."""
        from app.calibration.storage import save_calibration
        from app.hardware.interfaces import Intrinsics
        path = self._calibration_path()
        calib = load_calibration(path)
        if calib is not None:
            extras = dict(calib.extras or {})
            extras["continuous"] = {**self.continuous.summary(), "last_action": action, **(record or {}),
                                    "at": time.strftime("%Y-%m-%d %H:%M:%S")}
            method = calib.method if "continuous" in calib.method else f"{calib.method} + continuous"
            try:
                save_calibration(path, t_cam_to_robot, Intrinsics(**calib.intrinsics), method=method,
                                 reprojection_error_mm=calib.reprojection_error_mm, num_samples=calib.num_samples,
                                 extras=extras, archive=False)
            except OSError as exc:    # (used all the same: the continuous calibration has moved on to it)
                logger.warning("The continuous calibration's correction couldn't be saved: %s", exc)
        self.scene_builder.set_calibration(t_cam_to_robot, self._saved_correction(t_cam_to_robot))
        # (the table's height is kept: measured by the arm itself -- the cube calibration's touches -- it doesn't
        # change when the camera moves; measured afresh through the camera, it was the rougher estimate)
        if getattr(self, "_table_z_source", None) == "camera":     # (seen through the calibration before: again)
            self._table_z_mm = None
            self._table_z_tried_at = -1e9
        self.drift.capture()      # the view now, for the "has the camera moved?" check
        self.statusBar().showMessage("Continuous calibration: " + ("corrected the calibration" if action == "correct"
                                                                   else "went back to the last good calibration"),
                                     5000)

    def _continuous_replaced(self) -> None:
        continuous = getattr(self, "continuous", None)      # (none yet while the window is being built)
        if continuous is not None:
            continuous.calibration_replaced()

    def _calibration_state(self) -> dict:
        """For the watcher's run record: which calibration is in use, and what the continuous calibration has done."""
        path = self._calibration_path()
        try:
            stamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(path.stat().st_mtime))
        except OSError:
            stamp = None
        calib = load_calibration(path)
        from app.vision import paper
        return {"file": path.name, "saved": stamp, "method": calib.method if calib is not None else None,
                "error_mm": self._calibration_error_mm, "continuous": self.continuous.summary(),
                "paper": paper.PAPER_NAME}

    def _on_calibrated(self, t_cam_to_robot: np.ndarray, error_mm: float | None = None) -> None:
        self._continuous_replaced()       # (its reference was the old calibration's)
        self.scene_builder.set_calibration(t_cam_to_robot, self._saved_correction(t_cam_to_robot))
        self._calibrated = True
        self._calibration_error_mm = error_mm
        self._table_z_mm = None   # measured against the old calibration
        self._table_z_tried_at = -1e9
        self.drift.capture()   # remember how the camera sees the table, for spotting a moved camera later
        self.drift_label.setText("")
        self.statusBar().showMessage("Calibration applied -- click-to-move is now enabled", 5000)

    def _start_click_move(self, target: Pose) -> None:
        """Shared by every click-to-move surface (Manual and Prompt tabs, camera or 3D view)."""
        busy = self.arm_busy("click")
        if busy:
            # A prompt or a calibration step is driving the arm; a second motion sequence would interleave with it.
            self.statusBar().showMessage(f"Click ignored: {busy}.", 4000)
            return
        if self._click_worker is not None and self._click_worker.isRunning():
            self.statusBar().showMessage("Click ignored: the arm is still moving.", 3000)
            return
        clamp = getattr(self.robot, "clamp_pose", None)
        if clamp is not None:
            safe = clamp(target)
            off = ((safe.x - target.x) ** 2 + (safe.y - target.y) ** 2 + (safe.z - target.z) ** 2) ** 0.5
            if off > 3.0:
                # The robot would silently go to the nearest allowed point instead -- not where you clicked.
                self.statusBar().showMessage(
                    f"Out of reach: ({target.x:.0f}, {target.y:.0f}, {target.z:.0f}) is outside the "
                    "safe workspace. Not moving.", 5000)
                return
        self.statusBar().showMessage(f"Moving to x={target.x:.0f}, y={target.y:.0f}, z={target.z:.0f}", 3000)
        self._click_worker = CallableWorker(self.robot.move_to, target)
        self._click_worker.start()

    def _on_table_clicked(self, x_mm: float, y_mm: float) -> None:
        """Demo mode: a click on the table in the 3D view -> hover the tool above that spot."""
        self._start_click_move(Pose(x=x_mm, y=y_mm, z=CLICK_TO_MOVE_APPROACH_HEIGHT_MM))

    def _on_click_to_move(self, u: int, v: int) -> None:
        # Without a calibration the camera->robot transform is the identity, so the
        # "target" is just raw camera coordinates (e.g. z=679, the depth in mm). Sending
        # that to the arm caused inverse-resolve-limit alarms, so refuse until calibrated.
        if not self._calibrated:
            self.statusBar().showMessage(
                "Click-to-move disabled: calibrate first (Calibration tab)", 5000)
            return
        try:
            frame = self.camera.get_frame()
        except Exception as exc:  # noqa: BLE001 - camera may be disconnected/unavailable
            logger.warning("Click-to-move: could not get camera frame: %s", exc)
            return
        if frame.depth is None:
            self.statusBar().showMessage("Click ignored: the camera frame has no depth.", 4000)
            return
        depth_mm = foreground_depth(frame.depth, u, v)
        if depth_mm <= 0:
            self.statusBar().showMessage(
                "Click ignored: no depth reading there (too close, shiny or out of range). "
                "Click a nearby spot.", 5000)
            return
        point_cam = pixel_to_camera_point(u, v, depth_mm, frame.intrinsics)
        x, y, z = camera_point_to_robot(point_cam, self.scene_builder.t_cam_to_robot)
        if self.scene_builder.correction is not None:
            x, y = self.scene_builder.correction.apply(x, y)
        self._start_click_move(Pose(x=x, y=y, z=z + CLICK_TO_MOVE_APPROACH_HEIGHT_MM))

    def _update_robot_status_label(self) -> None:
        color = "#4caf50" if self.robot_connected else "#e05050"
        self.robot_status_label.setText(
            f'Robot: <span style="color:{color}">{self.robot_status}</span>'
        )
        self.robot_status_label.setTextFormat(Qt.TextFormat.RichText)

    def _update_camera_status_label(self) -> None:
        color = "#4caf50" if self.camera_connected else "#e05050"
        self.camera_status_label.setText(
            f'Camera: <span style="color:{color}">{self.camera_status}</span>' + self._demo_camera_note()
        )
        self.camera_status_label.setTextFormat(Qt.TextFormat.RichText)

    def _demo_camera_note(self) -> str:
        """" · picture: Poor", " · bumped" in amber when the demo's camera is set to behave like an imperfect one: left
        on "Poor", it saw one cube as a "purple bar", a "purple cylinder" and a "purple ball", and nothing on screen
        said why (and the setting isn't kept: after a restart it was "Perfect" again, and the cause was gone too)."""
        notes = []
        combos = getattr(self, "_quality_combos", None) or []
        quality = combos[0].currentText() if combos else "Perfect"
        if quality and quality != "Perfect":
            notes.append(f"picture: {quality}")
        if getattr(getattr(self, "camera", None), "is_bumped", False):
            notes.append("bumped")
        return "".join(f' · <span style="color:#e0a030">{note}</span>' for note in notes)

    def _refresh_llm_status(self) -> None:
        if self._llm_status_worker is not None:
            return  # a check is already in flight
        self._llm_status_worker = CallableWorker(self._check_llm_status)
        self._llm_status_worker.finished_ok.connect(self._on_llm_status_checked)
        self._llm_status_worker.failed.connect(self._on_llm_status_checked)
        self._llm_status_worker.start()

    def _check_llm_status(self) -> str:
        if not self.ollama_client.is_reachable():
            if not self.ollama_client.try_start_local_server():
                return f"Unreachable ({self.ollama_client.endpoint})"
        try:
            models = self.ollama_client.list_models()
        except Exception as exc:  # noqa: BLE001 - report, don't crash the status check
            return f"Reachable, but could not list models: {exc}"
        model = self.agent.model
        self._model_in_memory = next((m["size_gb"] for m in self.ollama_client.loaded_models() if m["name"] == model),
                                     None)
        if any(model in m for m in models):
            return f"Ready ({model})"
        return f"Reachable, but '{model}' not pulled -- run `ollama pull {model}`"

    def _on_llm_status_checked(self, status: str) -> None:
        self._llm_status = status
        self._llm_status_worker = None
        if getattr(self, "_model_load_worker", None) is None and status.startswith(("Ready", "Reachable")):
            size = getattr(self, "_model_in_memory", None)
            if size:
                self._set_model_state(f"ready · {size:.1f} GB", "#4caf50")
            elif self._manages_model_memory():
                self._set_model_state("not loaded", "#8fa8ba")
            if not getattr(self, "_installed_models", None):
                self._fill_model_list()        # Ollama answers now (it may have been started late)
        elif not status.startswith(("Ready", "Reachable")):
            self._set_model_state("Ollama not running", "#e05050")
        self._update_llm_label()

    def _on_estop(self) -> None:
        panel = getattr(self, "calibration_tab", None)
        if hasattr(panel, "_cancel"):
            panel._cancel.set()   # a calibration run in progress must not carry on after the stop
        self.robot.stop()
        # the stop lets go of what the gripper held (demo and real): the next prompt must not be told it still holds it
        self.tool_executor.let_go_by_hand()
        if self.prompt_panel.waiting_for_you():
            self.prompt_panel.answer("stop")   # a step waiting for Go must not go ahead after the stop
        # and the prompt ends here, not whenever the model next answers (you couldn't even load a scene till then)
        self.prompt_panel.cancel("E-STOP")
        # (over the window it was pressed in: from the watcher's own button, behind the watcher it went unseen)
        QMessageBox.warning(QApplication.activeWindow() or self, "E-STOP", "Robot motion halted and gripper released.")

    # ---- the language model: which one, loaded or not ------------------------------------------------------
    def _manages_model_memory(self) -> bool:
        """Whether this app loads and unloads models in Ollama (not in the tests: they mustn't touch yours)."""
        return bool(self.config["llm"].get("manage_memory", True))

    def _fill_model_list(self) -> None:
        """Ask Ollama what is installed (off the UI thread), then fill the Model list and load the chosen model."""
        if getattr(self, "_model_list_worker", None) is not None or not self._manages_model_memory():
            return
        self._model_list_worker = CallableWorker(self.ollama_client.installed_models)
        self._model_list_worker.finished_ok.connect(self._on_model_list)
        self._model_list_worker.failed.connect(lambda message: setattr(self, "_model_list_worker", None))
        self._model_list_worker.start()

    def _on_model_list(self, installed: list) -> None:
        self._model_list_worker = None
        self._installed_models = {m.name: m for m in installed}
        listed = [m for m in installed if m.listed]   # every model that can call the robot's tools (V4.3)
        if not listed:
            return
        listed.sort(key=model_list_order)
        chosen = choose_model(installed, self.agent.model)
        combo = self.model_selector
        combo.blockSignals(True)
        combo.set_model_rows(listed)
        combo.setCurrentIndex(max(0, combo.findData(chosen)))
        combo.blockSignals(False)
        if chosen != self.agent.model:
            logger.info("LLM model %s is not installed: using %s", self.agent.model, chosen)
        self._use_model(chosen, save=False)

    def _on_model_picked(self, _index: int) -> None:
        """You picked a model in the list: used from the next prompt, loaded now, the other one freed -- for this
        sitting only (V4.3): the default in config.yaml (the study's Qwen) stays, and comes back when the app starts."""
        name = self.model_selector.currentData()
        if not name or name == self.agent.model:
            return
        info = getattr(self, "_installed_models", {}).get(name)
        if info is not None and info.thinking_only:
            QMessageBox.warning(self, "A thinking-only model",
                                f"{name} always thinks before it answers, and that can't be switched off. On this PC "
                                "that takes minutes for every step, so prompts may time out.\n\nFor the robot, a "
                                "model that answers directly is better, e.g. qwen3:4b-instruct-2507.")
        elif info is not None and (not info.tested or info.too_big):
            QMessageBox.warning(self, "A model to try",
                                f"{name}: " + "; ".join(model_notes(info)) + ".\n\nIt is used until the app is "
                                f"closed; the default ({self.config['llm'].get('model')}) comes back on the next start.")
        self._use_model(name, save=False)
        default = self.config["llm"].get("model")
        if name != default:
            self.statusBar().showMessage(f"Using {name} for this sitting; the default stays {default}.", 8000)

    def _use_model(self, name: str, save: bool) -> None:
        self.agent.model = name
        logger.info("LLM model: %s", name)
        if save and name != self.config["llm"].get("model"):
            try:
                self._save_config_value(("llm", "model"), name)
            except (OSError, ValueError, KeyError, TypeError) as exc:
                logger.warning("Could not remember the model in config.yaml: %s", exc)
        self._load_model(name)

    def _load_model(self, name: str) -> None:
        """Into memory now, the others out (two don't fit in 16 GB without a graphics card): off the UI thread."""
        if not self._manages_model_memory():
            return
        self._set_model_state("loading…", "#e0a030")

        def work() -> tuple[list[str], float, float]:
            gone = self.ollama_client.unload_others(name)
            seconds = self.ollama_client.load(name)
            try:
                # the instructions and tools read once now, not by the first prompt (about 2 minutes on a CPU: the
                # first prompt after loading timed out)
                seconds += self.ollama_client.prepare(name, SYSTEM_PROMPT, TOOL_SCHEMAS)
            except Exception as exc:  # noqa: BLE001 - the model is loaded; the first prompt just takes longer
                logger.warning("The model could not read the instructions ahead: %s", exc)
            size = next((m["size_gb"] for m in self.ollama_client.loaded_models() if m["name"] == name), 0.0)
            return gone, seconds, size

        worker = self._model_load_worker = CallableWorker(work)
        worker.finished_ok.connect(lambda result, w=worker, n=name: self._on_model_loaded(n, result)
                                   if w is self._model_load_worker else None)
        worker.failed.connect(lambda message, w=worker: self._on_model_load_failed(message)
                              if w is self._model_load_worker else None)
        worker.start()

    def _on_model_loaded(self, name: str, result) -> None:
        gone, seconds, size = result
        self._model_load_worker = None
        self._set_model_state(f"ready · {size:.1f} GB" if size else "ready", "#4caf50")
        freed = f"; freed {', '.join(gone)}" if gone else ""
        self.statusBar().showMessage(f"{name} loaded in {seconds:.0f} s{freed}", 6000)

    def _on_model_load_failed(self, message: str) -> None:
        self._model_load_worker = None
        self._set_model_state("not loaded", "#e05050")
        logger.warning("Could not load the model: %s", message)

    def _set_model_state(self, text: str, colour: str) -> None:
        self._model_state = (text, colour)
        self.model_state_label.setText(text)
        self.model_state_label.setStyleSheet(f"color: {colour};")
        self._update_llm_label()

    def _update_llm_label(self) -> None:
        """The status bar: the model and whether it is in memory (seen on every tab), or what is wrong with Ollama."""
        status = self._llm_status
        if status.startswith("Ready"):
            text, colour = self._model_state
            short = self.model_selector.currentData(Qt.ItemDataRole.UserRole + 4) or self.agent.model
            shown = f"{short} · {text}"
        else:
            shown, colour = status, "#e0a030"
        self.llm_status_label.setText(f'LLM: <span style="color:{colour}">{shown}</span>')
        self.llm_status_label.setTextFormat(Qt.TextFormat.RichText)

    def _on_prompt_busy(self, busy: bool) -> None:
        """A running prompt needs its model, and its cube size: the lists are locked until it ends."""
        self.prompt_busy = busy
        for combo in self._cube_combos:
            combo.setEnabled(not busy)
        if not busy:
            QTimer.singleShot(0, self._offer_cube_size)
        self.model_selector.setEnabled(not busy)
        self.model_selector.setToolTip("Locked while a prompt runs: it needs its model" if busy else
                                       "The language model that turns your prompts into robot actions. Picking one "
                                       "loads it into memory and frees the one before, until the app is closed (the "
                                       "default, in config.yaml, stays). Every installed model that can use tools is "
                                       "listed; more that run on a laptop: ollama pull "
                                       + ", ".join(n for n in MODELS_FOR_A_LAPTOP[1:]) + ".")

    def _on_robot_changed(self, _index: int) -> None:
        key = self.robot_selector.currentData()
        if key == self.robot_profile.key:
            return
        busy = self._restart_refused()
        if busy:
            self.statusBar().showMessage(f"Not switched: {busy}.", 6000)
            self.robot_selector.blockSignals(True)
            self.robot_selector.setCurrentIndex(self.robot_selector.findData(self.robot_profile.key))
            self.robot_selector.blockSignals(False)
            return
        # As for the mode: the robot, its twin and everything built round them are made at start-up, so the choice
        # is saved and the app restarted into it.
        name = robots.ROBOT_NAMES[key]
        reply = QMessageBox.question(
            self, "Restart required",
            f"Switch to the {name}? The app restarts to rebuild the robot and its "
            f"{'twin' if self.config.get('mode', 'demo') == 'demo' else 'connection'}.\n\n"
            "Each robot keeps its own settings, calibration and saved places.\n\nRestart now?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            self.robot_selector.blockSignals(True)
            self.robot_selector.setCurrentIndex(self.robot_selector.findData(self.robot_profile.key))
            self.robot_selector.blockSignals(False)
            return
        config_path = self._config_file
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        raw["robot_model"] = key
        section = robots.profile(key).config_section
        if section not in raw:
            raw[section] = default_robot_settings(key)
        atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))
        logger.info("Switching robot to %s (restarting)", name)
        self._restarting = True       # (the same model is loaded again: not unloaded on the way out)
        subprocess.Popen([sys.executable, "-m", "app.main", "--skip-chooser"], cwd=str(config_path.parent))
        self.close()

    def _on_mode_changed(self, mode: str) -> None:
        if mode == self.config.get("mode", "demo"):
            return
        busy = self._restart_refused()
        if busy:
            self.statusBar().showMessage(f"Not switched: {busy}.", 6000)
            self.mode_selector.blockSignals(True)
            self.mode_selector.setCurrentText(self.config.get("mode", "demo"))
            self.mode_selector.blockSignals(False)
            return
        # Switching backends (demo <-> live) mid-session would mean tearing down and
        # rebuilding the robot/camera/scene/agent and every tab that references them.
        # Simpler and safer: persist the choice and restart the app into it.
        config_path = self._config_file
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        raw["mode"] = mode
        atomic_write_text(config_path, yaml.safe_dump(raw, sort_keys=False))

        reply = QMessageBox.question(
            self, "Restart required",
            f"Switched to '{mode}' mode in config.yaml. This requires a restart "
            f"to take effect (rebuilding the robot/camera connections).\n\n"
            f"Restart now?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self._restarting = True
            subprocess.Popen([sys.executable, "-m", "app.main", "--skip-chooser"], cwd=str(config_path.parent))
            self.close()
        else:
            self.mode_selector.blockSignals(True)
            self.mode_selector.setCurrentText(self.config.get("mode", "demo"))
            self.mode_selector.blockSignals(False)

    def _restart_refused(self) -> Optional[str]:
        """Why the app can't restart into another robot or mode right now (it would close under the work: see
        _may_close; and the new one would start beside it), or None."""
        doing = self._camera_setup_doing()
        if doing:
            return f"{doing}: switch when it has finished"
        if getattr(getattr(self, "calibration_tab", None), "_worker", None) is not None:
            return "a calibration step is running: switch when it has finished"
        return None

    def _camera_setup_doing(self) -> Optional[str]:
        """What Camera setup's window is doing (a sweep, a comparison, the shake test), or None."""
        dialog = getattr(self, "_camera_setup", None)
        try:
            busy = dialog is not None and dialog.is_busy()
        except RuntimeError:                     # (closed: Qt has deleted it)
            busy = False
        return self._camera_setup_busy or ("Camera setup is busy" if busy else None)

    def _may_close(self) -> bool:
        """Not closed from under Camera setup's action (it puts the camera and the arm back when it ends), nor from
        under a calibration step: that one is asked to stop (Stop finishes the move and puts the cube down: longer
        than shutdown waits), and the window closes once it has."""
        doing = self._camera_setup_doing()
        if doing:
            QMessageBox.information(self, "Not closing", f"{doing}: the app can be closed when it ends.")
            return False
        panel = getattr(self, "calibration_tab", None)
        if getattr(panel, "_worker", None) is None:
            return True
        if getattr(self, "_close_when_calibration_stops", False):
            # asked again while it is still stopping: close anyway? (a robot that stopped answering never finishes)
            return QMessageBox.question(
                self, "Close anyway?",
                "The calibration step is still stopping (finishing its move, putting the cube down). Close now "
                "anyway? The robot is disconnected under it.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes
        if QMessageBox.question(
                self, "A calibration step is running",
                "Stop it and close? It finishes its current move and puts the cube down first; the app closes once "
                "it has. (E-STOP stops at once.)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return False
        self._close_when_calibration_stops = True
        if hasattr(panel, "_stop"):
            panel._stop()
        self.statusBar().showMessage("Stopping the calibration: the app closes once it has (E-STOP stops at once).")

        def close_once_stopped() -> None:
            if getattr(panel, "_worker", None) is not None:
                QTimer.singleShot(200, close_once_stopped)
                return
            self._close_when_calibration_stops = False
            self.close()
        QTimer.singleShot(200, close_once_stopped)
        return False

    def closeEvent(self, event) -> None:
        # the watcher's window first: it uses this window's robot, camera and simulated world, and refuses to close
        # while a run is going or waits for a verdict -- then this window stays open too
        watcher = getattr(self, "_watcher_window", None)
        if watcher is not None and watcher.isVisible() and not watcher.close():
            event.ignore()
            return
        if not self._may_close():
            event.ignore()
            return
        try:
            # let a calibration run or camera check finish (or notice it should stop) before the
            # robot and camera are pulled out from under it
            for part in (getattr(self, "calibration_tab", None), getattr(self, "drift", None),
                         getattr(self, "continuous", None)):
                if hasattr(part, "shutdown"):
                    part.shutdown()
            if hasattr(self, "jog_panel"):
                self.jog_panel.stop_pose_monitor()
            if self._preset_switching():         # the camera half-way through restarting its streams
                self._preset_worker.wait(15000)
            self.robot.disconnect()
            self.camera.disconnect()
            if self._twin_world is not None:
                self._twin_world.stop()
            if self._manages_model_memory() and not getattr(self, "_restarting", False):
                self.ollama_client.unload(self.agent.model)      # its memory back as soon as you're done
        finally:
            super().closeEvent(event)

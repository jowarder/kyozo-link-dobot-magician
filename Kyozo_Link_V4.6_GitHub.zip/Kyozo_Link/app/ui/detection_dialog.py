"""The "Detection" window: what the camera counts as an object (see vision/detection_settings.py). Changes take effect
at once (the camera feed shows them) and are kept in config.yaml.

It also has the camera's exposure: finding coloured cubes by their colour needs a fixed one (automatic exposure, on the
black cloth with a white sheet, washed a red cube out to pink, and it wasn't found). Choosing "Coloured cubes only"
with automatic exposure on offers to fix it where it is. The same setting as Camera setup's, kept in the same place
(config.yaml camera: controls), and not changed while Camera setup is locked for the study."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable, Optional

from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (QButtonGroup, QCheckBox, QDialog, QDoubleSpinBox, QFormLayout, QGroupBox, QHBoxLayout,
                             QLabel, QMessageBox, QPushButton, QRadioButton, QSpinBox, QVBoxLayout, QWidget)

from app.ui.scroll import scrollable
from app.ui.settings_panel import ToggleSwitch
from app.vision.detection_settings import DEFAULT_PICK_AREA, FIND_ANY, FIND_CUBES, DetectionSettings

logger = logging.getLogger(__name__)

DEFAULTS = DetectionSettings()


@dataclass
class ExposureHooks:
    """What the window needs for the camera's exposure: the camera (controls / set_control), where to keep its picture
    settings, and why not to change them now (Camera setup locked for the study; the camera in use)."""
    camera: object
    save: Callable[[dict], None]                       # all the picture settings, as camera_controls.settings_to_keep
    locked: Callable[[], bool] = lambda: False
    refused: Callable[[], Optional[str]] = lambda: None
    saved: Callable[[], dict] = lambda: {}            # the picture settings kept now (config.yaml camera: controls)


def _spin(low: float, high: float, step: float, suffix: str, decimals: int = 0) -> QDoubleSpinBox:
    box = QDoubleSpinBox()
    box.setRange(low, high)
    box.setSingleStep(step)
    box.setDecimals(decimals)
    box.setSuffix(suffix)
    box.setKeyboardTracking(False)       # applied when typing is done, not at every digit
    return box


class DetectionDialog(QDialog):
    def __init__(self, settings: DetectionSettings, parent=None, demo: Optional[bool] = None,
                 exposure: Optional[ExposureHooks] = None):
        """`demo`: these are the demo's own settings (True) or the real camera's (False): said at the top, as the
        two are kept apart. None says nothing. `exposure`: the camera's exposure, offered here too (None: not)."""
        super().__init__(parent)
        self.settings = settings
        self.exposure = exposure
        self.setWindowTitle("Detection")
        self.setMinimumWidth(460)
        outer = QVBoxLayout(self)
        # the settings scroll when the screen is short (at 150% scaling the whole window didn't fit, and Close was
        # below the screen); Defaults and Close stay at the bottom, always in reach
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(0, 0, 0, 0)
        if demo is not None:
            note = QLabel("For the demo only: the real camera keeps its own settings." if demo else
                          "For the real camera: the demo keeps its own settings.")
            note.setStyleSheet("color: #8fa8ba;")
            layout.addWidget(note)

        find = QGroupBox("Find")
        find_layout = QVBoxLayout(find)
        self.any_btn = QRadioButton("Any object, whatever its colour or shape (by how it stands up from the table)")
        self.cubes_btn = QRadioButton("Coloured cubes only (by their colour)")
        self._find_group = QButtonGroup(self)
        for button in (self.any_btn, self.cubes_btn):
            self._find_group.addButton(button)
            find_layout.addWidget(button)
        layout.addWidget(find)

        # the camera's exposure: coloured cubes need a fixed one
        self.exposure_box = QGroupBox("Camera exposure")
        exposure_layout = QVBoxLayout(self.exposure_box)
        self.exposure_auto = ToggleSwitch()
        self.exposure_auto.setToolTip("On: the camera chooses the brightness, picture by picture. Off: a fixed exposure, "
                                      "the same in every picture.")
        auto_row = QHBoxLayout()
        auto_row.addWidget(self.exposure_auto)
        auto_label = QLabel("Automatic exposure")
        auto_label.setBuddy(self.exposure_auto)
        auto_row.addWidget(auto_label)
        auto_row.addStretch()
        exposure_layout.addLayout(auto_row)
        # when to use which
        when = QLabel("On: fine with Any object (it finds by depth) and changing light. Off: for Coloured cubes only "
                      "and the study; set it until the cubes look clearly red, blue and green.")
        when.setWordWrap(True)
        when.setStyleSheet("color: #8fa8ba;")
        exposure_layout.addWidget(when)
        value_row = QHBoxLayout()
        value_row.addWidget(QLabel("Fixed exposure:"))
        self.exposure_value = QSpinBox()
        self.exposure_value.setKeyboardTracking(False)
        self.exposure_value.setToolTip("Lower: darker, the colours stronger (a white sheet stops glaring). Higher: "
                                       "brighter. Look at the camera feed: the cubes clearly red, blue and green.")
        value_row.addWidget(self.exposure_value)
        self.fix_btn = QPushButton("Fix it where it is now")
        self.fix_btn.setToolTip("Automatic exposure off, keeping the exposure it is using right now.")
        value_row.addWidget(self.fix_btn)
        value_row.addStretch()
        exposure_layout.addLayout(value_row)
        self.exposure_note = QLabel("")
        self.exposure_note.setWordWrap(True)
        self.exposure_note.setStyleSheet("color: #8fa8ba;")
        exposure_layout.addWidget(self.exposure_note)
        layout.addWidget(self.exposure_box)
        self.exposure_box.setVisible(exposure is not None)

        ignore = QGroupBox("Leave out (against phantom objects)")
        form = QFormLayout(ignore)
        self.min_height = _spin(2.0, 40.0, 1.0, " mm", 1)
        self.min_height.setToolTip("Lower than this above the table counts as the table: a card mat, a sheet of paper, "
                                   "depth noise. (Any object only: colours aren't judged by height.)")
        form.addRow("Lower than:", self.min_height)
        self.min_size = _spin(0.0, 40.0, 1.0, " mm across")
        self.min_size.setToolTip("Smaller than this, seen from above, is not an object: bits of noise, a cable's edge.")
        form.addRow("Smaller than:", self.min_size)
        self.steady = QSpinBox()
        self.steady.setRange(1, 4)
        self.steady.setSuffix(" look(s) in a row")
        self.steady.setKeyboardTracking(False)
        self.steady.setToolTip("Only what is seen in this many camera pictures in a row, about where it was: things "
                               "that come and go from one picture to the next are noise. Each look takes a moment.")
        form.addRow("Not seen in:", self.steady)
        layout.addWidget(ignore)

        area = QGroupBox("Pick area")
        area_layout = QVBoxLayout(area)
        self.area_on = QCheckBox("Only find objects inside this area (its middle inside), in the arm's coordinates")
        area_layout.addWidget(self.area_on)
        rows = QFormLayout()
        self.x_low, self.x_high = _spin(-300, 350, 5, " mm"), _spin(-300, 350, 5, " mm")
        self.y_low, self.y_high = _spin(-350, 350, 5, " mm"), _spin(-350, 350, 5, " mm")
        for label, low, high in (("X (out from the base):", self.x_low, self.x_high),
                                 ("Y (+ is the arm's left):", self.y_low, self.y_high)):
            line = QHBoxLayout()
            line.addWidget(QLabel("from"))
            line.addWidget(low)
            line.addWidget(QLabel("to"))
            line.addWidget(high)
            line.addStretch()
            rows.addRow(label, line)
        area_layout.addLayout(rows)
        hint = QLabel("The camera feed shows the area as a dashed outline. Tip: jog the gripper to two opposite "
                      "corners of your mat and read X and Y off the Manual tab.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #8fa8ba;")
        area_layout.addWidget(hint)
        layout.addWidget(area)

        buttons = QHBoxLayout()
        defaults_btn = QPushButton("Defaults")
        defaults_btn.setToolTip("Any object, lower than 5 mm and smaller than 8 mm left out, one look, no pick area")
        defaults_btn.clicked.connect(self._defaults)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        buttons.addWidget(defaults_btn)
        buttons.addStretch()
        buttons.addWidget(close_btn)
        layout.addStretch()                # (any spare height below the settings, not spread between them)
        outer.addWidget(scrollable(content), stretch=1)
        outer.addLayout(buttons)
        self._fit_to_screen(content)

        self._show(settings)
        for button in (self.any_btn, self.cubes_btn):
            button.toggled.connect(self._apply)
        for box in (self.min_height, self.min_size, self.x_low, self.x_high, self.y_low, self.y_high):
            box.valueChanged.connect(self._apply)
        self.steady.valueChanged.connect(self._apply)
        self.area_on.toggled.connect(self._apply)
        self.cubes_btn.toggled.connect(self._cubes_chosen)
        self.exposure_auto.toggled.connect(self._exposure_auto_changed)
        self.exposure_value.valueChanged.connect(self._exposure_value_changed)
        self.fix_btn.clicked.connect(lambda: self.fix_exposure())
        self.show_exposure()

    def _fit_to_screen(self, content: QWidget) -> None:
        """As tall as the settings need, but never taller than the screen's free space (then they scroll)."""
        screen = (self.parent().screen() if self.parent() is not None else None) or QGuiApplication.primaryScreen()
        width = max(self.minimumWidth(), content.sizeHint().width() + 40)
        wanted = content.heightForWidth(width - 40) if content.hasHeightForWidth() else content.sizeHint().height()
        wanted += 90                                            # (the buttons, the margins, the title bar)
        room = screen.availableGeometry().height() - 60 if screen is not None else wanted
        self.resize(width, max(300, min(wanted, room)))

    # ---- the camera's exposure -------------------------------------------------------------------------------------
    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.show_exposure()               # (Camera setup may have changed it since)

    def _controls(self) -> dict:
        if self.exposure is None or not hasattr(self.exposure.camera, "controls"):
            return {}
        try:
            return self.exposure.camera.controls()
        except Exception as exc:  # noqa: BLE001 - the camera not answering: nothing to show
            logger.info("Detection window: the camera's settings couldn't be read: %s", exc)
            return {}

    def show_exposure(self) -> None:
        """The exposure as the camera has it now."""
        if self.exposure is None:
            return
        controls = self._controls()
        auto, value = controls.get("exposure_auto"), controls.get("exposure")
        locked = self.exposure.locked()
        self._showing_exposure = True
        try:
            if auto is not None:
                self.exposure_auto.setChecked(bool(auto.value))
            if value is not None:
                self.exposure_value.setRange(int(value.low or 1), int(value.high or 10000))
                self.exposure_value.setSingleStep(int(value.step or 1))
                self.exposure_value.setValue(int(value.value))
        finally:
            self._showing_exposure = False
        self.exposure_auto.setEnabled(auto is not None and not locked)
        manual = auto is None or not self.exposure_auto.isChecked()
        self.exposure_value.setEnabled(value is not None and manual and not locked)
        self.fix_btn.setEnabled(value is not None and not manual and not locked)
        if not controls:
            note = "This camera's exposure can't be set from here."
        elif locked:
            note = "Locked for the study (Camera setup): unlock it there to change the exposure."
        elif self.cubes_btn.isChecked() and not manual:
            note = "Coloured cubes only finds cubes by their colour: fix the exposure (automatic off), or a cube may " \
                   "wash out and not be found."
        else:
            note = ""                      # (nothing to warn about: no extra line)
        self.exposure_note.setText(note)
        self.exposure_note.setVisible(bool(note))

    def _may_change(self) -> bool:
        if self.exposure is None or self.exposure.locked():
            return False
        why = self.exposure.refused()
        if why:
            QMessageBox.information(self, "Camera exposure", f"Not now: {why}")
            self.show_exposure()
            return False
        return True

    def _set(self, name: str, value) -> bool:
        try:
            self.exposure.camera.set_control(name, value)
            return True
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Camera exposure", str(exc))
            return False

    def _keep(self) -> None:
        """Kept as Camera setup keeps it (config.yaml camera: controls), so the next start sets the camera up the same."""
        from app.hardware.camera_controls import settings_to_keep
        now = {name: c.value for name, c in self._controls().items()}
        if now:
            # (over what was kept: a setting the camera didn't answer for this time stays, not dropped)
            kept = dict(self.exposure.saved() or {})
            for name in now:
                kept.pop(name, None)
            self.exposure.save({**kept, **settings_to_keep(now)})

    def fix_exposure(self) -> bool:
        """Automatic exposure off, the exposure kept at what it is using now. True if done."""
        if not self._may_change():
            return False
        # automatic off first, then read what it was using: read while automatic, a camera may report its last manual
        # value rather than the one it chose -- and that written back would undo it
        done = self._set("exposure_auto", False)
        value = self._controls().get("exposure") if done else None
        now = int(value.value) if value is not None else None
        done = done and (now is None or self._set("exposure", now))
        if done:
            self._keep()
            logger.info("Detection window: exposure fixed at %s (automatic off)", now)
        self.show_exposure()
        return done

    def _exposure_auto_changed(self, on: bool) -> None:
        if getattr(self, "_showing_exposure", False):
            return
        if not on:
            self.fix_exposure()
            return
        if self._may_change() and self._set("exposure_auto", True):
            self._keep()
            logger.info("Detection window: automatic exposure on")
        self.show_exposure()

    def _exposure_value_changed(self, value: int) -> None:
        if getattr(self, "_showing_exposure", False) or not self._may_change():
            return
        if self._set("exposure", int(value)):
            self._keep()
            logger.info("Detection window: exposure %s", value)
        self.show_exposure()

    def _cubes_chosen(self, chosen: bool) -> None:
        """Coloured cubes only, with automatic exposure on: offered to fix it."""
        if not chosen or self._showing or self.exposure is None or self.exposure.locked():
            self.show_exposure()
            return
        auto = self._controls().get("exposure_auto")
        if auto is not None and bool(auto.value) and QMessageBox.question(
                self, "Fix the exposure?",
                "Coloured cubes only finds the cubes by their colour, and automatic exposure washes colours out (a red "
                "cube can read as pink, and isn't found).\n\nTurn automatic exposure off now, keeping the exposure the "
                "camera is using? (You can adjust it below, watching the camera feed.)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes) == QMessageBox.StandardButton.Yes:
            self.fix_exposure()
        self.show_exposure()

    def _show(self, s: DetectionSettings) -> None:
        self._showing = True
        try:
            (self.any_btn if s.find == FIND_ANY else self.cubes_btn).setChecked(True)
            self.min_height.setValue(s.min_height_mm)
            self.min_size.setValue(s.min_size_mm)
            self.steady.setValue(s.steady_looks)
            area = s.pick_area or DEFAULT_PICK_AREA
            self.area_on.setChecked(s.pick_area is not None)
            self.x_low.setValue(area["x"][0])
            self.x_high.setValue(area["x"][1])
            self.y_low.setValue(area["y"][0])
            self.y_high.setValue(area["y"][1])
            self._enable()
        finally:
            self._showing = False

    def _enable(self) -> None:
        self.min_height.setEnabled(self.any_btn.isChecked())
        for box in (self.x_low, self.x_high, self.y_low, self.y_high):
            box.setEnabled(self.area_on.isChecked())

    def _apply(self, *_args) -> None:
        if self._showing:
            return
        self._enable()
        area = None
        if self.area_on.isChecked():
            area = {"x": sorted([self.x_low.value(), self.x_high.value()]),
                    "y": sorted([self.y_low.value(), self.y_high.value()])}
        self.settings.update(find=FIND_ANY if self.any_btn.isChecked() else FIND_CUBES,
                             min_height_mm=self.min_height.value(), min_size_mm=self.min_size.value(),
                             steady_looks=self.steady.value(), pick_area=area)

    def _defaults(self) -> None:
        self._show(DEFAULTS)
        self._apply()

"""The simulated camera's view, drawn in the same style as the 3D view, that you can zoom and pan.

The simulated camera's own picture (PyBullet) is what the detector and the depth readings
use; this widget is only for showing it. It is painted from exactly the same viewpoint and
lens as that camera, so a click here is reported as the pixel (u, v) of that camera's image
and reads the right depth. The camera itself is fixed (that is the whole point of calibrating
it), so unlike the 3D view there is no rotating -- only zoom and pan, which don't change
which pixel a point on the table lands on.

Left out on purpose: the tool-tip marker, joint readout and tip trail. A real camera doesn't
show them, and the calibration exercise is to find the tool yourself. Nor the printed calibration marker on the tool
(the black-and-white card): not wanted on the arm drawn here, the 3D view leaves it out too. The simulated camera
still has it (SimRobot), so the demo's automatic calibration with a marker works as before.
"""
from __future__ import annotations

import logging
import math
from typing import Optional

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont, QLinearGradient, QPainter, QPen
from PyQt6.QtWidgets import QWidget

from app.ui.display_settings import DisplaySettings
from app.ui.scene_painter import SceneEffects, look_at, paint_scene

MIN_ZOOM, MAX_ZOOM = 0.4, 10.0
logger = logging.getLogger(__name__)
CLICK_SLOP_PX = 5.0   # moved less than this between press and release: a click, not a drag


class SimCameraWidget(QWidget):
    pixel_clicked = pyqtSignal(int, int)   # (u, v) in the camera image, like VideoWidget

    def __init__(self, camera, world, robot, fps: int = 30, parent=None, settings: Optional[DisplaySettings] = None):
        """`settings`: the Settings window's choices; only the "look" ones apply here (shadows, lighting, the
        mat) -- helpers such as the reach map are not something a camera would see."""
        super().__init__(parent)
        self.camera = camera
        self.settings = settings or DisplaySettings()
        self.settings.changed.connect(self.update)
        self.world = world
        self.robot = robot
        self.setMinimumSize(320, 180)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self._zoom = 1.0
        self._pan = QPointF(0.0, 0.0)          # screen pixels, from "image centred"
        self._press: Optional[QPointF] = None
        self._press_button = None
        self._drag_distance = 0.0
        self._last_key: Optional[tuple] = None
        self._marks: list[dict] = []
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(int(1000 / fps))

    # ---- geometry: camera image pixels <-> widget pixels ------------------------------------
    def _scale(self) -> float:
        """Widget pixels per camera pixel: fit the whole image, then apply the zoom."""
        fit = min(self.width() / self.camera.width, self.height() / self.camera.height)
        return fit * self._zoom

    def _image_origin(self) -> tuple[float, float]:
        """Widget position of camera pixel (0, 0)."""
        s = self._scale()
        return (self.width() / 2 + self._pan.x() - self.camera.width * s / 2,
                self.height() / 2 + self._pan.y() - self.camera.height * s / 2)

    def _to_pixel(self, x: float, y: float) -> tuple[float, float]:
        ox, oy = self._image_origin()
        s = self._scale()
        return (x - ox) / s, (y - oy) / s

    # ---- redraw only when something changed ----------------------------------------------
    def _tick(self) -> None:
        if not self.isVisible():
            return
        objects = self.world.snapshot()
        geometry, gripper_closed = self.robot.arm_state()
        key = (tuple((o["id"], o["pos"], o.get("yaw")) for o in objects), geometry.tcp, geometry.elbow, geometry.reachable,
               gripper_closed, self.robot.get_pose().r, self.camera.eye_position, self.camera.target_position)
        if key != self._last_key:
            self._last_key = key
            self.update()

    # ---- mouse ---------------------------------------------------------------------------------
    def mousePressEvent(self, event) -> None:
        self._press = event.position()
        self._press_button = event.button()
        self._drag_distance = 0.0
        self.setFocus()

    def mouseMoveEvent(self, event) -> None:
        if self._press is None:
            return
        delta = event.position() - self._press
        self._press = event.position()
        self._drag_distance += abs(delta.x()) + abs(delta.y())
        if self._drag_distance >= CLICK_SLOP_PX:
            self._pan += delta
            self.update()

    def mouseReleaseEvent(self, event) -> None:
        was_click = self._press is not None and self._drag_distance < CLICK_SLOP_PX
        button = self._press_button
        self._press = None
        if not was_click:
            return
        if button == Qt.MouseButton.MiddleButton:
            self.reset_view()
        elif button == Qt.MouseButton.LeftButton:
            u, v = self._to_pixel(event.position().x(), event.position().y())
            if 0 <= u < self.camera.width and 0 <= v < self.camera.height:
                self.pixel_clicked.emit(int(u), int(v))

    def wheelEvent(self, event) -> None:
        """Zoom about the cursor: the point under it stays put."""
        x, y = event.position().x(), event.position().y()
        u, v = self._to_pixel(x, y)
        self._zoom = max(MIN_ZOOM, min(MAX_ZOOM, self._zoom * (1.15 ** (event.angleDelta().y() / 120.0))))
        s = self._scale()
        self._pan = QPointF(x - self.width() / 2 + (self.camera.width / 2 - u) * s,
                            y - self.height() / 2 + (self.camera.height / 2 - v) * s)
        self.update()

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_R:
            self.reset_view()

    def set_marks(self, marks: list[dict]) -> None:
        """Draw markers over the picture: dicts with `u`, `v` (camera pixels), `kind` ("expected" or
        "found") and an optional `label`. An empty list clears them."""
        self._marks = list(marks)
        self.update()

    def reset_view(self) -> None:
        self._zoom = 1.0
        self._pan = QPointF(0.0, 0.0)
        self.update()

    # ---- drawing -----------------------------------------------------------------------------------
    def paintEvent(self, event) -> None:
        # PyQt ends the whole app, without a word, on an error in here: log it and keep going instead
        try:
            self._paint(event)
        except Exception:  # noqa: BLE001
            if not getattr(self, "_paint_failed", False):
                logger.exception("The camera view couldn't be drawn")
            self._paint_failed = True

    def _paint(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        background = QLinearGradient(0, 0, 0, h)
        background.setColorAt(0.0, QColor("#0c1824"))
        background.setColorAt(1.0, QColor("#182c3c"))
        painter.fillRect(self.rect(), QBrush(background))

        objects = self.world.snapshot()
        geometry, gripper_closed = self.robot.arm_state()
        ox, oy = self._image_origin()
        s = self._scale()
        millimetres = lambda point: tuple(v * 1000.0 for v in point)  # noqa: E731 - the camera works in metres
        view = look_at(millimetres(self.camera.eye_position), millimetres(self.camera.target_position),
                       focal=self.camera.get_intrinsics().fy * s)
        intrinsics = self.camera.get_intrinsics()
        font = QFont(self.font())
        font.setPointSize(10)
        font.setBold(True)
        paint_scene(painter, w, h, view, objects, geometry, gripper_closed, font,
                    center=(ox + intrinsics.cx * s, oy + intrinsics.cy * s),
                    held_id=getattr(self.robot, "held_object", None), jaw_stop_mm=getattr(self.robot, "jaw_stop_mm", None),
                    reach_mm=getattr(self.robot, "max_reach_mm", None) or 300.0,
                    tool_rotation_deg=self.robot.get_pose().r,
                    effects=SceneEffects(**{key: self.settings[key] for key in
                                            ("soft_shadows", "rim_light", "highlights", "measuring_mat", "gripper_glow")}))

        # Outside the camera's image nothing can be clicked: dim it, and outline the edge.
        frame = QRectF(ox, oy, self.camera.width * s, self.camera.height * s)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(6, 12, 20, 110))
        painter.drawRect(QRectF(0, 0, w, max(0.0, frame.top())))
        painter.drawRect(QRectF(0, frame.bottom(), w, max(0.0, h - frame.bottom())))
        painter.drawRect(QRectF(0, max(0.0, frame.top()), max(0.0, frame.left()),
                                min(h, frame.bottom()) - max(0.0, frame.top())))
        painter.drawRect(QRectF(frame.right(), max(0.0, frame.top()), max(0.0, w - frame.right()),
                                min(h, frame.bottom()) - max(0.0, frame.top())))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(120, 175, 190, 130), 1.2, Qt.PenStyle.DashLine))
        painter.drawRect(frame)

        for mark in self._marks:
            x, y = ox + mark["u"] * s, oy + mark["v"] * s
            kind = mark.get("kind")
            if kind == "arrow":         # a calibration spot's miss: from the spot, the way it was missed (enlarged)
                tip = QPointF(ox + mark["u2"] * s, oy + mark["v2"] * s)
                painter.setBrush(QColor("#ffd166"))
                painter.setPen(QPen(QColor(10, 24, 34), 1.0))
                painter.drawEllipse(QPointF(x, y), 3.5, 3.5)
                painter.setPen(QPen(QColor("#ffd166"), 2.2))
                painter.drawLine(QPointF(x, y), tip)
                dx, dy = tip.x() - x, tip.y() - y
                length = max(1e-6, (dx * dx + dy * dy) ** 0.5)
                ux, uy = dx / length, dy / length
                for side in (1.0, -1.0):
                    painter.drawLine(tip, QPointF(tip.x() - 7 * ux + 4 * side * uy, tip.y() - 7 * uy - 4 * side * ux))
            elif kind == "found":
                painter.setPen(QPen(QColor("#ff6b6b"), 2.2))
                painter.drawLine(QPointF(x - 8, y - 8), QPointF(x + 8, y + 8))
                painter.drawLine(QPointF(x - 8, y + 8), QPointF(x + 8, y - 8))
            elif kind == "sample":      # a calibration point that was clicked
                painter.setPen(QPen(QColor(10, 24, 34), 1.5))
                painter.setBrush(QColor("#4bb8ad"))
                painter.drawEllipse(QPointF(x, y), 5.0, 5.0)
            elif kind == "selected":    # the point selected in the list
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.setPen(QPen(QColor(10, 24, 34), 5.0))
                painter.drawEllipse(QPointF(x, y), 13.0, 13.0)
                painter.setPen(QPen(QColor("#ffd166"), 2.6))
                painter.drawEllipse(QPointF(x, y), 13.0, 13.0)
                painter.drawLine(QPointF(x - 20, y), QPointF(x - 8, y))
                painter.drawLine(QPointF(x + 8, y), QPointF(x + 20, y))
                painter.drawLine(QPointF(x, y - 20), QPointF(x, y - 8))
                painter.drawLine(QPointF(x, y + 8), QPointF(x, y + 20))
            else:
                painter.setPen(QPen(QColor("#6bdc8b"), 2.2))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(QPointF(x, y), 9.0, 9.0)
            if mark.get("label"):
                offset = 16 if kind == "selected" else 12
                painter.setPen(QColor(10, 24, 34))
                painter.drawText(QPointF(x + offset + 1, y - 7), str(mark["label"]))
                painter.setPen(QColor("#ffd166") if kind == "selected" else QColor(230, 240, 245))
                painter.drawText(QPointF(x + offset, y - 8), str(mark["label"]))

        small = QFont(self.font())
        small.setPointSize(9)
        painter.setFont(small)
        painter.setPen(QColor(150, 175, 195))
        painter.drawText(QPointF(12, h - 12), "Click: pick a point   Wheel: zoom   Drag: pan   R: reset view   "
                                              "(dimmed = outside the camera's view)")
        if abs(self._zoom - 1.0) > 0.01:
            painter.setPen(QColor(215, 230, 240))
            painter.drawText(QPointF(12, 20), f"zoom {self._zoom:.1f}x")
        painter.end()

"""The Settings panel: docked beside the 3D view, like an inspector in a design tool. Folding sections --
the demo scene, then the 3D view's look, helpers and extras -- each option a compact row with a switch.
Changes apply at once and are remembered; hover over an option to see what it does."""
from __future__ import annotations

from typing import Callable, Optional

from PyQt6.QtCore import QEasingCurve, QPropertyAnimation, QRectF, QSize, Qt, pyqtProperty, pyqtSignal
from PyQt6.QtGui import QColor, QPainter
from PyQt6.QtGui import QIntValidator
from PyQt6.QtWidgets import (QAbstractButton, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

from app.ui.display_settings import DEFAULTS, GROUPS, OPTIONS, SUMMARIES, VIEW_GROUPS, DisplaySettings
from app.ui.theme import ACCENT, BACKGROUND, BORDER, MUTED, PANEL, RAISED, TEXT

PANEL_WIDTH = 300      # room for a line of description under each option
GROUP_TITLES = {"Look": "Look", "Helpers": "Helpers", "Extras": "Extras", "Prompts": "Prompts"}
SWITCH_OFF = QColor("#3a5263")
KNOB = QColor("#eef6fa")


class ToggleSwitch(QAbstractButton):
    """A small on/off switch: a rounded track that turns teal, with a knob that slides across."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)     # Tab to it, Space to switch it
        self.setFixedSize(30, 17)
        self._position = 0.0                                  # 0 = off (left), 1 = on (right)
        self._slide = QPropertyAnimation(self, b"knob", self)
        self._slide.setDuration(130)
        self._slide.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.toggled.connect(self._animate)

    def sizeHint(self) -> QSize:
        return QSize(30, 17)

    def _get_knob(self) -> float:
        return self._position

    def _set_knob(self, value: float) -> None:
        self._position = value
        self.update()

    knob = pyqtProperty(float, _get_knob, _set_knob)

    def _animate(self, on: bool) -> None:
        self._slide.stop()
        if not self.isVisible():               # being set up (or switched while hidden): no slide, just be there
            self._position = 1.0 if on else 0.0
            return
        self._slide.setStartValue(self._position)
        self._slide.setEndValue(1.0 if on else 0.0)
        self._slide.start()

    def paintEvent(self, event) -> None:
        position = self._position if self._slide.state() == QPropertyAnimation.State.Running else (
            1.0 if self.isChecked() else 0.0)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        track = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        on, off = QColor(ACCENT), SWITCH_OFF
        painter.setPen(QColor(ACCENT) if self.hasFocus() else Qt.PenStyle.NoPen)
        painter.setBrush(QColor(int(off.red() + (on.red() - off.red()) * position),
                                int(off.green() + (on.green() - off.green()) * position),
                                int(off.blue() + (on.blue() - off.blue()) * position)))
        radius = track.height() / 2
        painter.drawRoundedRect(track, radius, radius)
        diameter = track.height() - 5
        x = track.left() + 2.5 + position * (track.width() - diameter - 5)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(KNOB)
        painter.drawEllipse(QRectF(x, track.top() + 2.5, diameter, diameter))
        painter.end()


class OptionRow(QFrame):
    """One option: its name, a short description under it, and its switch. Click anywhere on the row;
    hover for the full explanation."""

    def __init__(self, title: str, summary: str, tip: str, switch: ToggleSwitch, parent=None):
        super().__init__(parent)
        self.switch = switch
        self.setObjectName("optionRow")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(tip)
        row = QHBoxLayout(self)
        row.setContentsMargins(10, 5, 10, 5)
        text = QVBoxLayout()
        text.setSpacing(0)
        name = QLabel(title)
        name.setStyleSheet(f"color: {TEXT};")
        text.addWidget(name)
        if summary:
            line = QLabel(summary)
            line.setWordWrap(True)
            line.setStyleSheet(f"color: {MUTED}; font-size: 8pt;")
            text.addWidget(line)
        for i in range(text.count()):
            text.itemAt(i).widget().setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)   # clicks go to the row
        row.addLayout(text, stretch=1)
        row.addWidget(switch, alignment=Qt.AlignmentFlag.AlignVCenter)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint()):
            self.switch.toggle()
        super().mouseReleaseEvent(event)


class Section(QWidget):
    """A heading that folds its content away (chevron), with an optional count on the right."""

    def __init__(self, title: str, content: QWidget, open_: bool = True, parent=None):
        super().__init__(parent)
        self.content = content
        column = QVBoxLayout(self)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        self.header = QPushButton()          # (a QPushButton: unlike a tool button it can left-align its text)
        self.header.setObjectName("sectionHeader")
        self.header.setCursor(Qt.CursorShape.PointingHandCursor)
        self.header.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)   # the full width
        self.header.clicked.connect(lambda: self.set_open(not self.content.isVisibleTo(self)))
        self.title = title
        self.count = ""
        column.addWidget(self.header)
        column.addWidget(content)
        self.set_open(open_)

    def set_open(self, open_: bool) -> None:
        self.content.setVisible(open_)
        self._label(open_)

    def set_count(self, text: str) -> None:
        self.count = text
        self._label(self.content.isVisibleTo(self))

    def _label(self, open_: bool) -> None:
        self.header.setText(f"{'▾' if open_ else '▸'}  {self.title}" + (f"     {self.count}" if self.count else ""))


class SettingsPanel(QFrame):
    """Docked beside a 3D view. Every panel in the app shares the one DisplaySettings, so they stay in step."""
    close_requested = pyqtSignal()

    def __init__(self, settings: DisplaySettings, scenes: Optional[list[dict]] = None,
                 current_scene: Optional[Callable[[], Optional[str]]] = None,
                 on_load_scene: Optional[Callable[[str], tuple[bool, str]]] = None,
                 on_shuffle: Optional[Callable[[Optional[int]], tuple[bool, str, Optional[int]]]] = None,
                 extra_sections: Optional[list] = None, view_options: bool = True, parent=None):
        """`scenes` ([{"name", "title", "description"}]) and `on_load_scene(name) -> (done, message)`: the demo
        scene picker (left out if not given). `on_shuffle(layout number or None) -> (done, message, number)`.
        `extra_sections`: [(title, widget)] after the scene (the camera). `view_options`: the 3D view's options too
        (False in live mode, which has no 3D view: just the extra sections)."""
        super().__init__(parent)
        self.settings = settings
        self.boxes: dict[str, ToggleSwitch] = {}
        self.sections: dict[str, Section] = {}
        self.setObjectName("settingsPanel")
        self.setFixedWidth(PANEL_WIDTH)
        self.setStyleSheet(
            f"QFrame#settingsPanel {{ background: {PANEL}; border-left: 1px solid {BORDER}; }}"
            f"QFrame#optionRow {{ background: transparent; border-radius: 4px; }}"
            f"QFrame#optionRow:hover {{ background: {RAISED}; }}"
            f"QPushButton#sectionHeader {{ background: {BACKGROUND}; color: {MUTED}; border: none; border-radius: 0;"
            f"  border-top: 1px solid {BORDER}; border-bottom: 1px solid {BORDER}; padding: 6px 8px;"
            f"  text-align: left; font-size: 8.5pt; font-weight: bold; }}"
            f"QPushButton#sectionHeader:hover {{ color: {TEXT}; }}"
            f"QPushButton#small {{ padding: 3px 8px; font-size: 8.5pt; }}"
            f"QPushButton#panelClose {{ background: transparent; border: none; color: {MUTED}; padding: 0 6px;"
            f"  font-size: 11pt; }}"
            f"QPushButton#panelClose:hover {{ color: {TEXT}; }}")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        title_row = QHBoxLayout()
        title_row.setContentsMargins(10, 8, 4, 8)
        title = QLabel("Settings")
        title.setStyleSheet(f"color: {TEXT}; font-weight: bold;")
        close = QPushButton("×")
        close.setObjectName("panelClose")
        close.setToolTip("Hide the settings panel (the Settings button brings it back)")
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.clicked.connect(self.close_requested.emit)
        title_row.addWidget(title)
        title_row.addStretch()
        title_row.addWidget(close)
        outer.addLayout(title_row)

        body = QWidget()
        column = QVBoxLayout(body)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        self.scene_combo: Optional[QComboBox] = None
        if scenes and on_load_scene is not None:
            column.addWidget(Section("Scene", self._scene_box(scenes, current_scene, on_load_scene, on_shuffle)))
        for title_text, widget in extra_sections or []:
            column.addWidget(Section(title_text, widget))
        for group in GROUPS if view_options else ():
            content = QWidget()
            rows = QVBoxLayout(content)
            rows.setContentsMargins(4, 4, 4, 6)
            rows.setSpacing(0)
            for option in (o for o in OPTIONS if o.group == group):
                switch = ToggleSwitch()
                switch.setChecked(settings[option.key])
                switch.toggled.connect(lambda on, key=option.key: self.settings.set(key, on))
                rows.addWidget(OptionRow(option.label, SUMMARIES.get(option.key, ""), option.tip, switch))
                self.boxes[option.key] = switch
            section = Section(GROUP_TITLES[group], content)
            self.sections[group] = section
            column.addWidget(section)
        column.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(body)
        outer.addWidget(scroll, stretch=1)

        footer = QHBoxLayout()
        footer.setContentsMargins(8, 6, 8, 8)
        footer.setSpacing(4)
        view_keys = [o.key for o in OPTIONS if o.group in VIEW_GROUPS]
        buttons = (("All on", {k: True for k in view_keys}, "Switch every 3D-view option on"),
                   ("All off", {k: False for k in view_keys}, "Switch every 3D-view option off"),
                   ("Defaults", dict(DEFAULTS), "Back to how the app starts out")) if view_options else ()
        for text, values, tip in buttons:
            button = QPushButton(text)
            button.setObjectName("small")
            button.setToolTip(tip)
            button.clicked.connect(lambda _=False, v=values: self.settings.update(v))
            footer.addWidget(button)
        outer.addLayout(footer)

        settings.changed.connect(self._sync)
        self._update_counts()

    def _scene_box(self, scenes: list[dict], current_scene, on_load_scene, on_shuffle=None) -> QWidget:
        box = QWidget()
        column = QVBoxLayout(box)
        column.setContentsMargins(10, 8, 10, 8)
        column.setSpacing(6)
        self.scene_combo = QComboBox()
        descriptions = {scene["name"]: scene["description"] for scene in scenes}
        for scene in scenes:
            self.scene_combo.addItem(scene["title"], scene["name"])
            self.scene_combo.setItemData(self.scene_combo.count() - 1, scene["description"],
                                         Qt.ItemDataRole.ToolTipRole)
        now = current_scene() if current_scene is not None else None
        if now is not None and self.scene_combo.findData(now) >= 0:
            self.scene_combo.setCurrentIndex(self.scene_combo.findData(now))
        self.scene_combo.setToolTip(descriptions.get(self.scene_combo.currentData(), ""))
        self.scene_combo.currentIndexChanged.connect(
            lambda _i: self.scene_combo.setToolTip(descriptions.get(self.scene_combo.currentData(), "")))
        buttons = QHBoxLayout()
        buttons.setSpacing(4)
        self.load_scene_btn = QPushButton("Load")
        self.load_scene_btn.setObjectName("small")
        self.load_scene_btn.setToolTip("Clear the table and set out this scene")
        self.reset_scene_btn = QPushButton("Reset")
        self.reset_scene_btn.setObjectName("small")
        self.reset_scene_btn.setToolTip("Put everything in the scene now loaded back where it started")
        buttons.addWidget(self.load_scene_btn)
        buttons.addWidget(self.reset_scene_btn)
        self.shuffle_btn: Optional[QPushButton] = None
        self.layout_field: Optional[QLineEdit] = None
        if on_shuffle is not None:
            self.shuffle_btn = QPushButton("Shuffle")
            self.shuffle_btn.setObjectName("small")
            self.shuffle_btn.setToolTip("Set the objects out somewhere new: always in reach, apart, clear of the bins "
                                        "and in the camera's view. Bins stay put; Reset puts everything back.")
            buttons.addWidget(self.shuffle_btn)
        self.scene_status = QLabel()
        self.scene_status.setWordWrap(True)
        self.scene_status.setStyleSheet("font-size: 8.5pt;")

        def load(name: Optional[str]) -> None:
            if not name:
                return
            done, message = on_load_scene(name)
            self.scene_status.setStyleSheet("font-size: 8.5pt; color: " + ("#7fe0b0;" if done else "#f5a742;"))
            self.scene_status.setText(message)
        self.load_scene_btn.clicked.connect(lambda: load(self.scene_combo.currentData()))
        self.reset_scene_btn.clicked.connect(lambda: load(current_scene() if current_scene is not None else None))
        column.addWidget(self.scene_combo)
        column.addLayout(buttons)
        if on_shuffle is not None:
            again = QHBoxLayout()
            again.setSpacing(4)
            hint = QLabel("Layout no.")
            hint.setStyleSheet(f"color: {MUTED}; font-size: 8pt;")
            self.layout_field = QLineEdit()
            self.layout_field.setPlaceholderText("e.g. 4821")
            self.layout_field.setValidator(QIntValidator(1, 99999))
            self.layout_field.setToolTip("Type a layout number and press Enter to set out that exact layout again")
            again.addWidget(hint)
            again.addWidget(self.layout_field, stretch=1)
            column.addLayout(again)

            def shuffle(seed: Optional[int]) -> None:
                done, message, number = on_shuffle(seed)
                self.scene_status.setStyleSheet("font-size: 8.5pt; color: " + ("#7fe0b0;" if done else "#f5a742;"))
                self.scene_status.setText(message)
                if number is not None:
                    self.layout_field.setText(str(number))
            self.shuffle_btn.clicked.connect(lambda: shuffle(None))
            self.layout_field.returnPressed.connect(
                lambda: shuffle(int(self.layout_field.text())) if self.layout_field.text() else None)
        column.addWidget(self.scene_status)
        return box

    def _update_counts(self) -> None:
        for group, section in self.sections.items():
            keys = [o.key for o in OPTIONS if o.group == group]
            section.set_count(f"{sum(self.settings[k] for k in keys)}/{len(keys)}")

    def _sync(self) -> None:
        """Keep the switches in step when the settings change another way (All on, the other tab's panel...)."""
        for key, switch in self.boxes.items():
            if switch.isChecked() != self.settings[key]:
                switch.setChecked(self.settings[key])     # slides; its toggled -> settings.set is a no-op now
        self._update_counts()

"""The window at start-up: which robot, demo or live. Nothing is connected until you press Start, so the app never
tries the other robot's port or address. The last choice is already picked: Enter starts as before."""
from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QButtonGroup, QDialog, QGridLayout, QHBoxLayout, QLabel, QPushButton, QVBoxLayout,
                             QWidget)

from app import APP_NAME, robots
from app.ui.theme import ACCENT, BORDER, MUTED, RAISED

ROBOT_NOTES = {"dobot_magician": "4-axis desktop arm · USB", "xarm6": "6-axis arm · network"}
MODE_NOTES = {"demo": "its 3D twin, no hardware", "live": "the real robot and camera"}

CHOICE_STYLE = f"""
QPushButton {{ background-color: {RAISED}; border: 1px solid {BORDER}; border-radius: 8px; padding: 10px 14px;
               text-align: left; }}
QPushButton:hover {{ border-color: {MUTED}; }}
QPushButton:checked {{ border: 2px solid {ACCENT}; background-color: #1f4048; }}
"""


class RobotChooser(QDialog):
    def __init__(self, config: dict, mode: Optional[str] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle(APP_NAME)
        self.setMinimumWidth(520)
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        title = QLabel("Which robot?")
        title.setStyleSheet("font-size: 16pt; font-weight: bold;")
        layout.addWidget(title)

        self.robot_group = QButtonGroup(self)
        self.robot_buttons = {}
        robot_row = QHBoxLayout()
        for key, name in robots.ROBOT_NAMES.items():
            button = self._choice(f"{name}\n{ROBOT_NOTES.get(key, '')}")
            self.robot_group.addButton(button)
            self.robot_buttons[key] = button
            robot_row.addWidget(button)
        layout.addLayout(robot_row)

        layout.addWidget(QLabel("Mode:"))
        self.mode_group = QButtonGroup(self)
        self.mode_buttons = {}
        mode_row = QHBoxLayout()
        for key in ("demo", "live"):
            button = self._choice(f"{key.capitalize()}\n{MODE_NOTES[key]}")
            self.mode_group.addButton(button)
            self.mode_buttons[key] = button
            mode_row.addWidget(button)
        layout.addLayout(mode_row)

        self.summary = QLabel()
        self.summary.setWordWrap(True)
        self.summary.setStyleSheet(f"color: {MUTED};")
        layout.addWidget(self.summary)

        buttons = QGridLayout()
        quit_button = QPushButton("Quit")
        quit_button.clicked.connect(self.reject)
        self.start_button = QPushButton("Start")
        self.start_button.setDefault(True)
        self.start_button.setStyleSheet(f"background-color: {ACCENT}; color: #08151c; font-weight: bold; "
                                        "padding: 8px 28px;")
        self.start_button.clicked.connect(self.accept)
        buttons.addWidget(quit_button, 0, 0, Qt.AlignmentFlag.AlignLeft)
        buttons.addWidget(self.start_button, 0, 1, Qt.AlignmentFlag.AlignRight)
        layout.addLayout(buttons)

        # the last choice, already picked
        self.robot_buttons[robots.robot_key(config)].setChecked(True)
        mode = mode if mode in self.mode_buttons else config.get("mode", "demo")
        self.mode_buttons[mode if mode in self.mode_buttons else "demo"].setChecked(True)
        self.robot_group.buttonClicked.connect(lambda _b: self._update_summary())
        self.mode_group.buttonClicked.connect(lambda _b: self._update_summary())
        self._update_summary()
        self.start_button.setFocus()

    def _choice(self, text: str) -> QPushButton:
        button = QPushButton(text)
        button.setCheckable(True)
        button.setMinimumHeight(64)
        button.setStyleSheet(CHOICE_STYLE)
        button.setFocusPolicy(Qt.FocusPolicy.TabFocus)   # Enter goes to Start, not to the last button clicked
        return button

    @property
    def robot(self) -> str:
        return next(key for key, button in self.robot_buttons.items() if button.isChecked())

    @property
    def mode(self) -> str:
        return next(key for key, button in self.mode_buttons.items() if button.isChecked())

    def _update_summary(self) -> None:
        """What Start will do, so the wrong robot isn't driven by mistake."""
        name = robots.ROBOT_NAMES[self.robot]
        if self.mode == "demo":
            text = f"Starts the {name}'s 3D twin. Nothing is connected."
        elif self.robot == "xarm6":
            ip = str((self.config.get("xarm6") or {}).get("ip") or "")
            text = (f"Connects to the {name} at {ip}." if ip else
                    f"No address for the {name} yet: set xarm6: ip: in config.yaml (the address UFACTORY Studio "
                    "connects to). The app will start and say it isn't connected.")
        else:
            port = (self.config.get("robot") or {}).get("port") or "its USB port"
            text = f"Connects to the {name} on {port} (or wherever it answers)."
        self.summary.setText(text)

    def choice(self) -> tuple[str, str]:
        return self.robot, self.mode

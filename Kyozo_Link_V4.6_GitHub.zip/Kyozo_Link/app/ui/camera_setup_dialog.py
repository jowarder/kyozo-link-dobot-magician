"""Camera setup: place the camera and set its picture before calibrating -- live readings against targets, the
picture settings, and a reference to check against later (app/vision/camera_setup.py does the measuring).

Two modes: Setup (move the camera, set the picture, until every gauge is in its target) and Session check (at the
start of a lab session: has the camera moved, or its settings changed, since the saved reference?). "Lock for study"
keeps the settings from being changed by accident -- here and in the app's own Settings and Detection windows (the
demo's lock apart from the lab camera's); unlocking asks, and is logged.

What takes a while (comparing, the exposure sweep, the shake test) runs as one action at a time: meanwhile the window's
settings and the app's tabs are held (E-STOP stays), and the window can't be closed until it ends.
"""
from __future__ import annotations

import json
import logging
import math
import threading
import time
from collections import deque
from pathlib import Path
from typing import Callable, Optional

from PyQt6.QtCore import QRectF, Qt, QTimer
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QFrame, QGridLayout,
                             QHBoxLayout, QLabel, QMessageBox, QPushButton, QScrollArea, QSizePolicy, QSlider,
                             QSpinBox, QTabWidget, QVBoxLayout, QWidget)

from app.hardware.camera_controls import AUTO_FOR, CONTROL_LABELS, Control, settings_to_keep  # noqa: F401
from app.ui.worker import CallableWorker
from app.vision import camera_setup as cs
from app.vision import drift

logger = logging.getLogger(__name__)

GREEN, AMBER, RED, GREY = QColor("#6bdc8b"), QColor("#f5a742"), QColor("#ff6b6b"), QColor("#8fa8ba")
STATUS_LOOK = {cs.MEETS: ("✓ meets", "#6bdc8b"), cs.CLOSE: ("! close", "#f5a742"), cs.FAILS: ("✕ fails", "#ff6b6b"),
               cs.UNKNOWN: ("– no reading", "#8fa8ba")}
SETTLING = "Settling"       # every blocking reading acceptable, but not yet for STEADY_S
VERDICT_LOOK = {cs.MEETS_TARGETS: ("#6bdc8b", "Every reading is in its target range, and steady."),
                cs.GOOD_ENOUGH: ("#6bdc8b", "Every reading that blocks calibration is acceptable."),
                SETTLING: ("#f5a742", ""), cs.NOT_READY: ("#ff6b6b", "")}
# each gauge's scale: the reading's range shown, left to right
SCALES = {"height_cm": (25.0, 70.0), "tilt_deg": (0.0, 70.0), "cube_px": (15.0, 80.0), "top_ratio": (70.0, 130.0),
          "saturation": (40.0, 255.0), "clipped_pct": (0.0, 15.0), "top_points": (0.0, 400.0),
          "noise_mm": (0.0, 2.5), "shake_mm": (0.0, 1.2), "warmup_min": (0.0, 20.0), "edge_margin_pct": (0.0, 40.0)}
MOUNT_ROWS = ("height_cm", "tilt_deg", "cube_px", "edge_margin_pct")    # what Mount mode shows, big
# out of sight until "Show advanced" (Rafi, 2026-10-19: "only keep what is required"): readings only for finding a
# fault, and picture settings set once and locked for the study. The depth preset and detection comparisons, Camera
# capabilities, the Shake test and Mount mode go with them.
ADVANCED_READINGS = ("edge_margin_pct", "clipped_pct", "noise_mm", "shake_mm")
ADVANCED_CONTROLS = ("gain", "white_balance", "projector_power", "anti_flicker")
ADVANCED_STEPS = ("Depth preset", "Detection")
SLIDER_MAX = {"depth_exposure": 6000}      # a slider's useful end (the depth exposure's own runs to 165000)
EDGE_FRAME = 0.10           # the frame drawn on the picture: cubes should stay inside it
STEADY_S = 5.0              # a reading counts as meeting its target once it has for this long
GAP_S = 3.0                 # readings further apart than this (paused, a comparison): steadiness starts again
SPREAD_S = 2.0              # the spread shown: over this long
SLIDER_DELAY_MS = 300       # a slider's setting is sent this long after it stops moving (drag, keys, wheel alike)
SHAKE_TIMEOUT_S = 30.0      # the shake test's moves must be done by then
MOVED_MM, TURNED_DEG = 2.0, 0.3     # Session check: more than this since the reference, and the camera moved
COMPARE_LOOKS = 20                  # looks per setting when comparing
DETECTION_NAMES = {"any": "Any object", "cubes": "Coloured cubes"}
# the measures each comparison shows: (key, label, unit, lower is better, good below, bad above)
PRESET_ROWS = (("centre_jitter_mm", "Centre jitter", "mm", 0.3, 0.8), ("top_read_pct", "Cube top read", "%", None, None),
               ("top_points", "Top points (typical)", "", None, None), ("angle_jitter_deg", "Angle jitter", "°", 1.0, 2.0),
               ("noise_mm", "Noise", "mm", 0.8, 1.5))
DETECTION_ROWS = (("missed_pct", "Missed a cube", "% of looks", 10.0, 30.0), ("named", "Named", "", None, None),
                  ("jitter_mm", "Position jitter", "mm", 0.5, 1.0), ("off_depth_mm", "Off the depth reading", "mm",
                                                                     1.0, 2.0),
                  ("angle_jitter_deg", "Angle (jitter)", "°", 1.0, 2.0))
STEPS = ("Position", "Picture", "Depth preset", "Save reference", "Calibrate", "Detection", "Lock for study")


def log_change(folder: Path, what: str, settings: Optional[dict] = None) -> None:
    """One line in the camera setup's changes.log (a research record: what changed, when, the settings then)."""
    try:
        folder.mkdir(parents=True, exist_ok=True)
        with open(folder / "changes.log", "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {what}; settings: {json.dumps(settings or {})}\n")
    except OSError as exc:
        logger.warning("Couldn't log the camera setup change: %s", exc)


def shake_test(robot, camera, lift_mm: float = 30.0, timeout_s: float = SHAKE_TIMEOUT_S) -> dict:
    """The arm `lift_mm` straight up and back down where it is, while the camera watches the table: how far the
    camera moved meanwhile. Checks the arm really rose that far (the robot's safety limits may shorten or shift a move
    without saying) and came back; raises if not, or if the moves aren't done within `timeout_s` -- never a result
    while the arm may still be moving. Returns {"shake_mm", "offset_mm", "normal"} (the table as seen meanwhile)."""
    from app.hardware.interfaces import Pose
    here = robot.get_pose()
    bounds = getattr(robot, "bounds", None)
    if isinstance(bounds, dict) and "z" in bounds and here.z + lift_mm > float(bounds["z"][1]) + 0.5:
        raise RuntimeError(f"The arm is too high to rise {lift_mm / 10:.0f} cm here (its limit is z = "
                           f"{float(bounds['z'][1]):.0f} mm): move it lower first.")
    done = threading.Event()
    problem, rose = [], []

    def move():
        try:
            robot.move_to(Pose(here.x, here.y, here.z + lift_mm, here.r))
            rose.append(robot.get_pose())
            robot.move_to(Pose(here.x, here.y, here.z, here.r))
        except Exception as exc:  # noqa: BLE001
            problem.append(str(exc))
        finally:
            done.set()
    mover = threading.Thread(target=move, daemon=True)
    offsets, normals = [], []
    deadline = time.monotonic() + timeout_s
    mover.start()
    try:
        while (not done.is_set() or len(offsets) < 3) and time.monotonic() < deadline:
            frame = camera.get_frame()
            plane = cs.fit_table(frame.depth, frame.intrinsics)
            if plane is not None:
                offsets.append(float(plane.offset))
                normals.append(plane.normal)
    finally:
        finished = done.wait(max(0.0, deadline - time.monotonic()))     # (a camera error: the arm still finishes)
    if not finished:
        raise TimeoutError(f"The arm hadn't finished its moves after {timeout_s:.0f} s: check it (E-STOP if it is "
                           "still moving). The shake isn't known.")
    if problem:
        raise RuntimeError(f"The arm couldn't move for the test: {problem[0]}")
    up = rose[0] if rose else None
    if up is None or up.z - here.z < 0.8 * lift_mm or math.hypot(up.x - here.x, up.y - here.y) > 2.0:
        risen = 0.0 if up is None else up.z - here.z
        raise RuntimeError(f"The arm didn't rise {lift_mm / 10:.0f} cm straight up here (it rose {risen:.0f} mm): "
                           "its limits are near. Move it to the middle of the table, lower, and try again.")
    back = robot.get_pose()
    off = math.dist((back.x, back.y, back.z), (here.x, here.y, here.z))
    if off > 2.0:
        raise RuntimeError(f"The arm didn't come back to where it started ({off:.1f} mm off): check it.")
    distance = abs(sum(offsets) / len(offsets)) if offsets else 0.0
    shake = cs.shake_from(offsets, normals, distance)
    if shake is None:
        raise RuntimeError("Not enough pictures of the table to tell: is the table in view?")
    normal = sum(normals) / len(normals)
    return {"shake_mm": shake, "offset_mm": sum(offsets) / len(offsets),
            "normal": tuple(float(v) for v in normal / max(1e-9, float((normal @ normal) ** 0.5)))}


def _angle_between(a, b) -> Optional[float]:
    if a is None or b is None or len(a) != 3 or len(b) != 3:
        return None
    dot = sum(float(x) * float(y) for x, y in zip(a, b))
    return math.degrees(math.acos(max(-1.0, min(1.0, dot))))


def _fmt(name: str, value: Optional[float]) -> str:
    if value is None:
        return "–"
    unit = cs.TARGETS[name][1]
    if name in ("top_points", "saturation", "cube_px", "warmup_min"):
        text = f"{value:.0f}"
    elif name in ("noise_mm", "shake_mm", "clipped_pct"):
        text = f"{value:.1f}"
    else:
        text = f"{value:.1f}"
    return f"{text} {unit}".strip() if unit not in ("%", "°") else f"{text}{unit}"


def _target_text(name: str) -> str:
    label, unit, (lo, hi), (alo, ahi), blocks, what = cs.TARGETS[name]

    def span(a, b):
        if b >= 1e4:
            return f"≥ {a:g}{(' ' + unit) if unit and unit not in '%°' else unit}"
        if a <= 0:
            return f"≤ {b:g}{(' ' + unit) if unit and unit not in '%°' else unit}"
        return f"{a:g}–{b:g}{(' ' + unit) if unit and unit not in '%°' else unit}"
    return f"{what} · target {span(lo, hi)} · acceptable {span(alo, ahi)}" + ("" if blocks else " · advisory")


class Gauge(QWidget):
    """A thin track: the acceptable range (grey), the target range (green), the spread lately (shaded) and the
    reading now (a tick)."""

    def __init__(self, name: str, parent=None):
        super().__init__(parent)
        self.name = name
        self.value: Optional[float] = None
        self.spread: Optional[tuple] = None
        self.best: Optional[float] = None       # the best seen so far (dashed), to go back to while mounting
        self.setMinimumHeight(16)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set(self, value: Optional[float], spread: Optional[tuple]) -> None:
        self.value, self.spread = value, spread
        self.update()

    def _x(self, v: float) -> float:
        lo, hi = SCALES[self.name]
        return 4 + (self.width() - 8) * max(0.0, min(1.0, (v - lo) / (hi - lo)))

    def paintEvent(self, _event) -> None:    # noqa: N802 (Qt)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        mid, h = self.height() / 2.0, 6.0
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(255, 255, 255, 18))
        painter.drawRoundedRect(QRectF(4, mid - h / 2, self.width() - 8, h), 3, 3)
        _, _, target, acceptable, _, _ = cs.TARGETS[self.name]
        for (lo, hi), colour in ((acceptable, QColor(255, 255, 255, 55)), (target, GREEN)):
            x0, x1 = self._x(lo), self._x(hi)
            painter.setBrush(colour)
            painter.drawRoundedRect(QRectF(x0, mid - h / 2, max(2.0, x1 - x0), h), 3, 3)
        if self.spread is not None:
            x0, x1 = self._x(self.spread[0]), self._x(self.spread[1])
            painter.setBrush(QColor(255, 255, 255, 60))
            painter.drawRect(QRectF(x0 - 1, mid - 6, max(2.0, x1 - x0 + 2), 12))
        if self.best is not None:
            pen = QPen(QColor("#9fe3d6"), 1.5)
            pen.setStyle(Qt.PenStyle.DashLine)
            painter.setPen(pen)
            x = self._x(self.best)
            painter.drawLine(int(x), int(mid - 8), int(x), int(mid + 8))
        if self.value is not None:
            painter.setPen(QPen(QColor("#e8eef3"), 2))
            x = self._x(self.value)
            painter.drawLine(int(x), int(mid - 7), int(x), int(mid + 7))
        painter.end()


def best_of(name: str, values: list) -> Optional[float]:
    """The best of the readings seen: one in the target range nearest its middle, else the nearest to it."""
    values = [v for v in values if v is not None]
    if not values:
        return None
    _, _, (lo, hi), _, _, _ = cs.TARGETS[name]
    hi = min(hi, SCALES[name][1])
    middle = (lo + hi) / 2.0
    return min(values, key=lambda v: abs(v - middle))


class MountView(QDialog):
    """Mount mode: the camera's placing readings, big enough to read from a metre or two while both hands are on the
    mount, with what to do and a beep when it's right."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mount mode")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(900, 640)
        layout = QVBoxLayout(self)
        self.headline = QLabel("Move the camera...")
        self.headline.setStyleSheet("font-size: 28px; font-weight: 600;")
        layout.addWidget(self.headline)
        grid = QGridLayout()
        self.cells = {}
        for row, name in enumerate(MOUNT_ROWS):
            label = QLabel(cs.TARGETS[name][0])
            label.setStyleSheet("font-size: 22px; color: #b8c7d1;")
            value = QLabel("–")
            value.setStyleSheet("font-size: 44px; font-weight: 600;")
            hint = QLabel("")
            hint.setWordWrap(True)
            hint.setStyleSheet("font-size: 20px;")
            best = QLabel("")
            best.setStyleSheet("font-size: 14px; color: #9fe3d6;")
            grid.addWidget(label, row, 0)
            grid.addWidget(value, row, 1)
            grid.addWidget(hint, row, 2)
            grid.addWidget(best, row, 3)
            self.cells[name] = (value, hint, best)
        grid.setColumnStretch(2, 1)
        layout.addLayout(grid)
        self.aim = QLabel("")
        self.aim.setWordWrap(True)
        self.aim.setStyleSheet("font-size: 20px; color: #f5a742;")
        layout.addWidget(self.aim)
        layout.addStretch()
        bottom = QHBoxLayout()
        self.beep_box = QCheckBox("Beep when it's right")
        self.beep_box.setChecked(True)
        bottom.addWidget(self.beep_box)
        bottom.addStretch()
        close = QPushButton("Back to Camera setup")
        close.clicked.connect(self.close)
        bottom.addWidget(close)
        layout.addLayout(bottom)
        self.was_right = False

    def show_readings(self, values: dict, statuses: dict, best: dict, hints: list) -> bool:
        """Show one reading; True if the camera is placed right (every placing reading in its target)."""
        right = all(statuses.get(n) == cs.MEETS for n in MOUNT_ROWS)
        for name, (value_label, hint_label, best_label) in self.cells.items():
            status = statuses.get(name, cs.UNKNOWN)
            colour = STATUS_LOOK[status][1]
            value_label.setText(_fmt(name, values.get(name)))
            value_label.setStyleSheet(f"font-size: 44px; font-weight: 600; color: {colour};")
            hint = cs.hint_for(name, values.get(name)) if status != cs.MEETS else "✓ right"
            hint_label.setText(hint)
            hint_label.setStyleSheet(f"font-size: 20px; color: {colour};")
            best_label.setText(f"best so far {_fmt(name, best.get(name))}" if best.get(name) is not None else "")
        self.headline.setText("✓ The camera is placed right: clamp it there." if right else "Move the camera...")
        self.headline.setStyleSheet("font-size: 28px; font-weight: 600; color: %s;" % ("#6bdc8b" if right else
                                                                                      "#e8eef3"))
        self.aim.setText("\n".join(hints))
        if right and not self.was_right and self.beep_box.isChecked():
            QApplication.beep()
        self.was_right = right
        return right


class ComparePanel(QWidget):
    """Two settings side by side over the same looks: each one's measures, the better one framed, why, and a button to
    use it."""

    def __init__(self, title: str, note: str, rows: tuple, run_text: str, parent=None):
        super().__init__(parent)
        self.rows = rows
        layout = QVBoxLayout(self)
        head = QHBoxLayout()
        text = QLabel(f"<b>{title}</b><br><span style='color:#8fa8ba;'>{note}</span>")
        text.setWordWrap(True)
        head.addWidget(text, 1)
        self.run_btn = QPushButton(run_text)
        head.addWidget(self.run_btn)
        layout.addLayout(head)
        self.cards_row = QHBoxLayout()
        layout.addLayout(self.cards_row)
        self.cards: dict = {}
        self.result_label = QLabel("")
        self.result_label.setWordWrap(True)
        bottom = QHBoxLayout()
        bottom.addWidget(self.result_label, 1)
        self.use_btn = QPushButton("Use")
        self.use_btn.setVisible(False)
        bottom.addWidget(self.use_btn)
        layout.addLayout(bottom)
        layout.addStretch()

    def show_result(self, result: dict, current: str) -> None:
        for i in reversed(range(self.cards_row.count())):
            widget = self.cards_row.itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()
        self.cards = {}
        winner, tie = result["winner"], result["tie"]
        for name, summary in result["results"].items():
            card = QFrame()
            framed = name == winner and not tie
            card.setStyleSheet("QFrame { border: %s; border-radius: 10px; }" %
                               ("2px solid #6bdc8b" if framed else "1px solid #2b4250"))
            grid = QGridLayout(card)
            badge = "Recommended" if framed else ("in use" if name == current else "")
            grid.addWidget(QLabel(f"<b>{name}</b>"), 0, 0)
            tag = QLabel(badge)
            tag.setStyleSheet("color: %s; border: none;" % ("#6bdc8b" if framed else "#8fa8ba"))
            grid.addWidget(tag, 0, 1, alignment=Qt.AlignmentFlag.AlignRight)
            for r, (key, label, unit, good, bad) in enumerate(self.rows, start=1):
                value = summary.get(key)
                if isinstance(value, list):
                    shown = " ".join(value) or "none"
                    mark = ""
                elif value is None:
                    shown, mark = "–", ""
                else:
                    shown = f"{value:.2f}".rstrip("0").rstrip(".") + (f" {unit}" if unit else "")
                    mark = "" if good is None else ("✓" if value <= good else "!" if value <= bad else "✕")
                name_label = QLabel(label)
                name_label.setStyleSheet("border: none; color: #b8c7d1;")
                value_label = QLabel(shown)
                value_label.setStyleSheet("border: none; font-family: Consolas, monospace;")
                mark_label = QLabel(mark)
                mark_label.setStyleSheet("border: none; color: %s;" % {"✓": "#6bdc8b", "!": "#f5a742",
                                                                       "✕": "#ff6b6b"}.get(mark, "#8fa8ba"))
                grid.addWidget(name_label, r, 0)
                grid.addWidget(value_label, r, 1, alignment=Qt.AlignmentFlag.AlignRight)
                grid.addWidget(mark_label, r, 2)
            looks = summary.get("looks", 0)
            seen = QLabel(f"{looks} looks, {summary.get('seen', 0)} cubes")
            seen.setStyleSheet("border: none; color: #6f8796; font-size: 11px;")
            grid.addWidget(seen, len(self.rows) + 1, 0, 1, 3)
            self.cards_row.addWidget(card)
            self.cards[name] = card
        self.result_label.setText(("" if tie else f"<b>Use {winner}.</b> ") + result["why"])
        self.use_btn.setText(f"Use {winner}")
        self.use_btn.setVisible(not tie and winner != current)


class CameraSetupDialog(QDialog):
    def __init__(self, camera, make_view: Callable[[], QWidget], config: dict,
                 save_value: Callable[[tuple, object], None], controls_key: str, calibration_path: Path,
                 references_dir: Path, demo: bool, robot=None, cube_mm: float = 25.0,
                 on_start_calibration: Optional[Callable[[], None]] = None, hooks=None, parent=None,
                 lock_key: str = "setup_locked", expected_cubes: int = 0, cubes_key: Optional[str] = None):
        super().__init__(parent)
        self.setWindowTitle("Camera setup")
        # a window of its own: maximize (the readings and the picture bigger) and minimize, as any other
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)      # (closed: gone, not left behind hidden)
        self.camera, self.config, self.save_value, self.controls_key = camera, config, save_value, controls_key
        self.calibration_path, self.references_dir, self.demo = calibration_path, references_dir, demo
        self.robot, self.cube_mm, self.on_start_calibration = robot, cube_mm, on_start_calibration
        self.lock_key, self.expected_cubes, self.cubes_key = lock_key, int(expected_cubes), cubes_key
        self._tick_worker: Optional[CallableWorker] = None          # a look under way
        self._action: Optional[str] = None                          # what takes a while, under way (one at a time)
        self._action_worker: Optional[CallableWorker] = None
        self._history: deque = deque()          # (time, {name: value})
        self._steady_since: Optional[float] = None
        self._last_at: Optional[float] = None
        self.settling = True
        self.missing = 0                        # cubes on the table not seen
        self._session_extras: dict = {}         # Session check: the settings and the picture's shift, from the last look
        self._shake_view: Optional[tuple] = None    # (table offset, its direction) during the shake test
        self._slider_timers: dict = {}
        self.reading: Optional[cs.SetupReading] = None
        self.statuses: dict = {}
        self.verdict_text = cs.NOT_READY
        self.shake_mm: Optional[float] = None
        self.best_seen: dict = {}           # the best reading of each so far (while mounting: where to go back to)
        self._seen: dict = {}
        self.mount_view: Optional[MountView] = None
        self.reference = self._load_reference()
        self._reference_view = self._load_reference_view()
        self.mode = "setup"
        # the app's own settings this window can compare and set (main_window._camera_setup_hooks): the depth preset,
        # the detection, the calibration in use; None (tests, no app): those tabs say so
        self.hooks = hooks
        self.comparisons: dict = dict((self.reference or {}).get("comparisons", {}))
        # as big as suits it, but never more than the screen (a laptop at 150% scaling has ~1280 x 680 to show it in)
        screen = QApplication.primaryScreen()
        room = screen.availableGeometry() if screen is not None else None
        self.resize(min(1180, int(room.width() * 0.95)) if room else 1180,
                    min(820, int(room.height() * 0.92)) if room else 760)

        root = QVBoxLayout(self)
        # ---- top: mode, camera, lock -----------------------------------------------------------------------------
        top = QHBoxLayout()
        self.mode_group = QButtonGroup(self)
        for i, (key, text) in enumerate((("setup", "Setup"), ("session", "Session check"))):
            btn = QPushButton(text)
            btn.setCheckable(True)
            btn.setChecked(key == "setup")
            btn.clicked.connect(lambda _c, k=key: self._set_mode(k))
            self.mode_group.addButton(btn, i)
            top.addWidget(btn)
        info = camera.describe() if hasattr(camera, "describe") else {}
        self.camera_label = QLabel(" · ".join(str(info[k]) for k in ("name", "serial", "firmware") if info.get(k)))
        self.camera_label.setStyleSheet("color: #8fa8ba; padding-left: 10px;")
        top.addWidget(self.camera_label)
        top.addStretch()
        top.addWidget(QLabel("Cubes on the table:"))
        self.cubes_spin = QSpinBox()
        self.cubes_spin.setRange(0, 12)
        self.cubes_spin.setSpecialValueText("not set")
        self.cubes_spin.setValue(self.expected_cubes)
        self.cubes_spin.setToolTip("How many cubes you put on the table, if you want them all checked: one the depth "
                                   "doesn't see well is then said (and blocks calibrating), not quietly left out. "
                                   "'not set' (the usual): any number -- one cube of any colour is enough to "
                                   "calibrate")
        self.cubes_spin.valueChanged.connect(self._set_expected_cubes)
        top.addWidget(self.cubes_spin)
        # what's set once (and locked for the study) or only for finding a fault, out of sight until asked for
        from app.ui.settings_panel import ToggleSwitch
        self.advanced_switch = ToggleSwitch()
        self.advanced_switch.setChecked(bool(self.config.get("camera", {}).get("setup_advanced", False)))
        self.advanced_switch.setToolTip("Also the readings, settings, comparisons and tests set once or only used when "
                                        "something is wrong (all still applied, saved and recorded when hidden)")
        advanced_label = QLabel("Show advanced")
        advanced_label.setStyleSheet("padding-left: 4px; padding-right: 10px;")
        top.addWidget(self.advanced_switch)
        top.addWidget(advanced_label)
        self.lock_btn = QPushButton()
        self.lock_btn.clicked.connect(self._toggle_lock)
        top.addWidget(self.lock_btn)
        root.addLayout(top)
        # ---- where the setup is: the steps, in order ------------------------------------------------------------
        steps = QHBoxLayout()
        self.step_labels = {}
        for step in STEPS:
            label = QLabel(f"○ {step}")
            label.setStyleSheet("color: #8fa8ba;")
            steps.addWidget(label)
            self.step_labels[step] = label
        steps.addStretch()
        root.addLayout(steps)
        # ---- verdict -----------------------------------------------------------------------------------------------
        head = QFrame()
        head.setStyleSheet("QFrame { border: 1px solid #2b4250; border-radius: 10px; }")
        hl = QHBoxLayout(head)
        self.verdict_icon = QLabel("●")
        self.verdict_icon.setStyleSheet("font-size: 22px; border: none;")
        hl.addWidget(self.verdict_icon)
        box = QVBoxLayout()
        self.verdict_label = QLabel(cs.NOT_READY)
        self.verdict_label.setStyleSheet("font-size: 16px; font-weight: 600; border: none;")
        self.verdict_detail = QLabel("Looking...")
        self.verdict_detail.setWordWrap(True)
        self.verdict_detail.setStyleSheet("color: #b8c7d1; border: none;")
        box.addWidget(self.verdict_label)
        box.addWidget(self.verdict_detail)
        hl.addLayout(box, 1)
        self.last_calibration = QLabel(self._last_calibration_text())
        self.last_calibration.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.last_calibration.setStyleSheet("color: #b8c7d1; border: none;")
        hl.addWidget(self.last_calibration)
        root.addWidget(head)
        # ---- the rest scrolls (the verdict above and the buttons below stay in sight) -------------------------------
        page = QWidget()
        body = QVBoxLayout(page)
        body.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(page)
        # ---- middle: the view, and the readings -----------------------------------------------------------------
        middle = QHBoxLayout()
        left = QVBoxLayout()
        self.view = make_view()
        self.view.setMinimumSize(420, 300)
        left.addWidget(self.view, 1)
        self.cubes_label = QLabel("")
        self.cubes_label.setWordWrap(True)
        self.cubes_label.setStyleSheet("color: #b8c7d1;")
        left.addWidget(self.cubes_label)
        middle.addLayout(left, 5)
        # the cubes outlined on the picture (a camera picture; the demo's 3D view has none)
        self.set_marks = getattr(self.view, "set_marks", None)
        grid_box = QFrame()
        grid_box.setStyleSheet("QFrame#readings { border: 1px solid #2b4250; border-radius: 10px; }")
        grid_box.setObjectName("readings")
        grid = QGridLayout(grid_box)
        grid.setColumnStretch(1, 1)
        self.rows: dict = {}
        self.reading_widgets: dict = {}           # name -> every widget of its row (shown or hidden with it)
        self.group_titles: list = []              # (title, its readings)
        row = 0
        for group, names in cs.GROUPS:
            title = QLabel(group.upper())
            title.setStyleSheet("color: #6f8796; font-size: 11px; letter-spacing: 1px; padding-top: 6px;")
            grid.addWidget(title, row, 0, 1, 4)
            self.group_titles.append((title, names))
            row += 1
            for name in names:
                label, _, _, _, blocks, _ = cs.TARGETS[name]
                name_label = QLabel(label + ("  <span style='color:#6f8796;font-size:10px;'>[blocks]</span>"
                                             if blocks else ""))
                gauge = Gauge(name)
                value_label = QLabel("–")
                value_label.setStyleSheet("font-family: Consolas, monospace;")
                value_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                status_label = QLabel(STATUS_LOOK[cs.UNKNOWN][0])
                status_label.setMinimumWidth(92)
                target_label = QLabel(_target_text(name))
                target_label.setWordWrap(True)
                target_label.setStyleSheet("color: #6f8796; font-size: 11px;")
                grid.addWidget(name_label, row, 0)
                grid.addWidget(gauge, row, 1)
                grid.addWidget(value_label, row, 2)
                grid.addWidget(status_label, row, 3)
                grid.addWidget(target_label, row + 1, 1, 1, 3)
                self.rows[name] = (gauge, value_label, status_label, target_label)
                self.reading_widgets[name] = (name_label, gauge, value_label, status_label, target_label)
                row += 2
        middle.addWidget(grid_box, 6)
        body.addLayout(middle, 1)
        # ---- the picture settings ---------------------------------------------------------------------------------
        self.controls_box = QFrame()
        self.controls_box.setObjectName("controls")
        self.controls_box.setStyleSheet("QFrame#controls { border: 1px solid #2b4250; border-radius: 10px; }")
        self.controls_layout = QGridLayout(self.controls_box)
        self.control_widgets: dict = {}
        self.control_rows: dict = {}              # name -> its row's widgets (shown or hidden with it)
        self.tabs = QTabWidget()
        self.tabs.addTab(self.controls_box, "Picture settings")
        self.preset_panel = ComparePanel(
            "Depth preset", "Affects the calibration: how whole and how steady the cubes' tops read. "
            f"{COMPARE_LOOKS} looks with each (the camera restarts its streams to switch: a few seconds); keep the "
            "cubes spread over the table, both zones too.", PRESET_ROWS, "Compare presets")
        self.preset_panel.run_btn.clicked.connect(self._compare_presets)
        self.preset_panel.use_btn.clicked.connect(self._use_preset)
        self.tabs.addTab(self.preset_panel, "Depth preset")
        self.detection_panel = ComparePanel(
            "Detection", "Affects the robot's picks, not the calibration (it always goes by depth): both of the app's "
            f"detectors on the same {COMPARE_LOOKS} pictures, against the depth reading. Needs a calibration. For "
            "choosing the setting only, not an accuracy result: the depth reading it is held against is the one the "
            "'Any object' detector itself uses.",
            DETECTION_ROWS, "Compare detection")
        self.detection_panel.run_btn.clicked.connect(self._compare_detection)
        self.detection_panel.use_btn.clicked.connect(self._use_detection)
        self.tabs.addTab(self.detection_panel, "Detection")
        if demo and hasattr(camera, "place"):
            self.tabs.insertTab(0, self._demo_tab(), "Demo camera")
            self.tabs.setCurrentIndex(0)
        body.addWidget(self.tabs)
        self._build_controls()
        self._show_comparisons()
        # ---- footnote and actions ---------------------------------------------------------------------------------
        note = self.targets_note = QLabel(f"Targets {cs.TARGETS_VERSION}, {cs.TARGETS_SOURCE}. Every reading is saved "
                                          f"with the reference. A reading counts once it has met its target for "
                                          f"{STEADY_S:.0f} s.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #6f8796; font-size: 11px;")
        body.addWidget(note)
        root.addWidget(scroll, 1)
        actions = QHBoxLayout()
        self.best_btn = QPushButton("Find best exposure")
        self.best_btn.setToolTip("Tries exposures, keeping the one where the cubes' colours are strongest without "
                                 "washing out (the cubes must be on the table)")
        self.best_btn.clicked.connect(self._find_best_exposure)
        self.caps_btn = QPushButton("Camera capabilities")
        self.caps_btn.setToolTip("What this camera offers: every setting it supports with its range, its picture "
                                 "sizes (read only)")
        self.caps_btn.clicked.connect(self._show_capabilities)
        self.shake_btn = QPushButton("Shake test")
        self.shake_btn.setToolTip("The arm moves 3 cm straight up and back where it is, while the camera watches "
                                  "the table: does the camera move with it? (Not while anything else uses the arm.)")
        self.shake_btn.clicked.connect(self._shake_test)
        self.mount_btn = QPushButton("Mount mode")
        self.mount_btn.setToolTip("Big readings and what to do, readable from a metre or two while you place the "
                                  "camera; it beeps when the camera is placed right")
        self.mount_btn.clicked.connect(self.open_mount_mode)
        self.save_btn = QPushButton("Save reference")
        self.save_btn.setToolTip("Keep these readings and settings: each session's check compares against them "
                                 "(and they go in the paper's methods)")
        self.save_btn.clicked.connect(self._save_reference)
        self.start_btn = QPushButton("Start calibration")
        self.start_btn.setToolTip("The cube calibration, once every reading that blocks it is acceptable")
        self.start_btn.clicked.connect(self._start_calibration)
        for widget in (self.mount_btn, self.best_btn, self.caps_btn, self.shake_btn):
            actions.addWidget(widget)
        actions.addStretch()
        actions.addWidget(self.save_btn)
        actions.addWidget(self.start_btn)
        root.addLayout(actions)

        self._show_lock()
        self.advanced_switch.toggled.connect(self._show_advanced)
        self._show_advanced(self.advanced_switch.isChecked(), save=False)
        self._awaiting: Optional[tuple] = None          # (depth preset asked for, why, give up at)
        self._preset_wait = QTimer(self)
        self._preset_wait.setInterval(100)
        self._preset_wait.timeout.connect(self._check_preset_done)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(700)
        self._tick()

    # ---- what is shown: the essentials, or everything ----------------------------------------------------------------
    def _show_advanced(self, on: bool, save: bool = True) -> None:
        """The readings, settings, comparisons and tests set once (and locked for the study) or only used to find a
        fault: shown, or out of sight. Hidden, they still apply, are saved and are recorded; a hidden reading that
        fails is still named in the verdict."""
        for name, widgets in self.reading_widgets.items():
            for widget in widgets:
                widget.setVisible(on or name not in ADVANCED_READINGS)
        for title, names in self.group_titles:
            title.setVisible(on or any(n not in ADVANCED_READINGS for n in names))
        for name, widgets in self.control_rows.items():
            for widget in widgets:
                widget.setVisible(on or name not in ADVANCED_CONTROLS)
        for panel in (self.preset_panel, self.detection_panel):
            index = self.tabs.indexOf(panel)
            if index >= 0:
                self.tabs.setTabVisible(index, on)
        for widget in (self.caps_btn, self.shake_btn, self.mount_btn, self.targets_note):
            widget.setVisible(on)
        try:
            self._show_steps()
        except Exception:  # noqa: BLE001 - (before the first look: shown at the next)
            pass
        if save and bool(self.config.get("camera", {}).get("setup_advanced", False)) != bool(on):
            try:
                self.save_value(("camera", "setup_advanced"), bool(on))
            except Exception as exc:  # noqa: BLE001 - not remembered is no reason to fail
                logger.info("Camera setup: 'Show advanced' not remembered: %s", exc)

    # ---- looking ---------------------------------------------------------------------------------------------------
    def _warmup_min(self) -> Optional[float]:
        if self.demo:
            return 99.0                                  # the simulator's depth doesn't drift
        started = getattr(self.camera, "connected_at", None)
        return None if started is None else (time.monotonic() - started) / 60.0

    def measure_once(self) -> cs.SetupReading:
        frame = self.camera.get_frame()
        return cs.measure(frame.rgb, frame.depth, frame.intrinsics, self.cube_mm, warmup_min=self._warmup_min())

    def _look(self, session: bool) -> tuple:
        """One look (off the UI thread): the readings, and for the Session check the settings now and how the
        picture has shifted since the reference's."""
        frame = self.camera.get_frame()
        reading = cs.measure(frame.rgb, frame.depth, frame.intrinsics, self.cube_mm, warmup_min=self._warmup_min())
        extras: dict = {}
        if session:
            extras["controls"] = self._current_controls()
            if self._reference_view is not None:
                extras["picture"] = drift._picture_shift(self._reference_view, drift._shrunk_gray(frame.rgb))
                extras["picture_tried"] = True
        return reading, extras

    def _tick(self) -> None:
        if self._tick_worker is not None or self._action is not None:
            return
        if not self.isVisible() and self.reading is not None:      # (hidden: no need to keep looking)
            return
        worker = CallableWorker(self._look, self.mode == "session")
        worker.finished_ok.connect(self._on_look)
        worker.failed.connect(self._on_failed)
        self._tick_worker = worker
        worker.start()

    def _on_failed(self, message: str) -> None:
        self._tick_worker = None
        self.verdict_detail.setText(f"The camera couldn't look: {message}")

    def _on_look(self, result: tuple) -> None:
        self._tick_worker = None
        reading, self._session_extras = result
        self.apply_reading(reading)

    def _reset_steadiness(self) -> None:
        """What was read before doesn't count (a setting changed, the camera moved): steady starts again."""
        self._history.clear()
        self._last_at = None

    def _set_expected_cubes(self, count: int) -> None:
        self.expected_cubes = int(count)
        if self.cubes_key:
            self.save_value(("camera", self.cubes_key), int(count))
        if self.reading is not None:
            self.apply_reading(self.reading)

    def _shake_still_holds(self, reading: cs.SetupReading) -> None:
        """The shake test's result is for the camera where it was then: moved since, it no longer counts."""
        if self.shake_mm is None or self._shake_view is None or reading.plane_offset_mm is None:
            return
        offset, normal = self._shake_view
        turned = _angle_between(normal, reading.plane_normal)
        if abs(reading.plane_offset_mm - offset) > MOVED_MM or (turned is not None and turned > TURNED_DEG):
            logger.info("The camera moved since the shake test: its result no longer counts")
            self.shake_mm, self._shake_view = None, None

    def apply_reading(self, reading: cs.SetupReading, now: Optional[float] = None) -> None:
        """Show one look's readings (also called directly by the tests)."""
        now = time.monotonic() if now is None else now
        if self._last_at is None or now - self._last_at > GAP_S:      # (paused, or reset: steady starts again)
            self._history.clear()
            self._steady_since = now
        self._last_at = now
        self._shake_still_holds(reading)
        reading.shake_mm = self.shake_mm
        self.reading = reading
        values = reading.values(self.cube_mm)
        self._history.append((now, values))
        while self._history and now - self._history[0][0] > STEADY_S:
            self._history.popleft()
        self.statuses = {}
        for name, (gauge, value_label, status_label, _) in self.rows.items():
            value = values.get(name)
            recent = [v[name] for t, v in self._history if v.get(name) is not None and now - t <= SPREAD_S]
            spread = (min(recent), max(recent)) if len(recent) > 1 else None
            # steady: the worst of the last few seconds counts (a reading flashing into its target doesn't)
            window = [cs.status_of(name, v.get(name)) for _, v in self._history]
            order = [cs.UNKNOWN, cs.FAILS, cs.CLOSE, cs.MEETS]
            status = min(window, key=order.index) if window else cs.UNKNOWN
            if name == "warmup_min":
                status = cs.status_of(name, value)       # (it only grows)
            self.statuses[name] = status
            gauge.set(value, spread)
            plus = f" ± {(spread[1] - spread[0]) / 2:.1f}" if spread and spread[1] - spread[0] > 0.05 else ""
            value_label.setText(_fmt(name, value) + plus if value is not None else "–")
            text, colour = STATUS_LOOK[status]
            status_label.setText(text)
            status_label.setStyleSheet(f"color: {colour};")
            hint = cs.hint_for(name, value) if status != cs.MEETS else ""
            self.rows[name][3].setText(_target_text(name) + (f"<br><span style='color:{colour};'>{hint}</span>"
                                                             if hint else ""))
        for name in MOUNT_ROWS:
            self._seen.setdefault(name, deque(maxlen=600)).append(values.get(name))
            self.best_seen[name] = best_of(name, list(self._seen[name]))
            self.rows[name][0].best = self.best_seen[name]
        self.missing = max(0, self.expected_cubes - len(reading.judged())) if self.expected_cubes else 0
        verdict = cs.verdict(self.statuses, self.missing)
        # a reading counts once it has held for STEADY_S: until then, one that would pass is "settling"
        self.settling = now - (self._steady_since if self._steady_since is not None else now) < STEADY_S
        self.verdict_text = SETTLING if self.settling and verdict != cs.NOT_READY else verdict
        self._show_verdict(reading)
        self._show_cubes(reading)
        if self.mount_view is not None and self.mount_view.isVisible():
            self.mount_view.show_readings(values, self.statuses, self.best_seen, cs.aim_hints(reading))

    def _show_verdict(self, reading: cs.SetupReading) -> None:
        colour, detail = VERDICT_LOOK[self.verdict_text]
        if self.verdict_text == cs.NOT_READY:
            failing = [cs.TARGETS[n][0] for n, s in self.statuses.items()
                       if cs.TARGETS[n][4] and s in (cs.FAILS, cs.UNKNOWN)]
            parts = [self._missing_text(reading)] if self.missing else []
            if failing:
                parts.append("Fix first: " + ", ".join(failing) + ".")
            detail = " ".join(parts)
        elif self.verdict_text == SETTLING:
            held = self._last_at - self._steady_since if self._last_at and self._steady_since else 0.0
            detail = (f"Every reading that blocks calibration is acceptable: holding steady ({held:.0f} of "
                      f"{STEADY_S:.0f} s)...")
        elif self.verdict_text == cs.GOOD_ENOUGH:
            left = [cs.TARGETS[n][0] for n, s in self.statuses.items() if s != cs.MEETS]
            if left:
                detail += " Not yet in target: " + ", ".join(left) + "."
        if self.mode == "session":
            detail = self._session_text(reading)
        if not self.advanced_switch.isChecked():
            failing = [cs.TARGETS[n][0] for n, s in self.statuses.items() if n in ADVANCED_READINGS and s == cs.FAILS]
            # (not measured or not quite in target: only "Meets targets" waits for them -- the Shake test is hidden)
            pending = [cs.TARGETS[n][0] for n, s in self.statuses.items()
                       if n in ADVANCED_READINGS and s in (cs.UNKNOWN, cs.CLOSE)]
            if failing:
                detail += f" (Hidden: {', '.join(failing)} out of target -- 'Show advanced' to see.)"
            elif pending and self.verdict_text == cs.GOOD_ENOUGH:
                detail += (f" ('Meets targets' also needs {', '.join(pending)}: 'Show advanced'"
                           + (", then the Shake test" if "Shake" in pending else "") + ". Not needed to calibrate.)")
        self.verdict_label.setText(self.verdict_text if self.mode == "setup" else "Session check")
        self.verdict_icon.setStyleSheet(f"font-size: 22px; border: none; color: {colour};")
        self.verdict_detail.setText(detail)
        self.start_btn.setEnabled(self.verdict_text in (cs.GOOD_ENOUGH, cs.MEETS_TARGETS) and self._action is None
                                  and self.on_start_calibration is not None)
        self._show_steps()

    def _missing_text(self, reading: cs.SetupReading) -> str:
        seen = len(reading.judged())
        text = f"Only {seen} of the {self.expected_cubes} cubes on the table seen"
        if reading.rejects:
            text += " (" + "; ".join(f"a {r['colour']} one: {r['why']}" for r in reading.rejects) + ")"
        return text + ". Move closer, or use the Default depth preset (or set how many are on the table, above)."

    def _show_cubes(self, reading: cs.SetupReading) -> None:
        if not reading.cubes:
            self.cubes_label.setText("No cube seen: put a cube on the table (red, green or blue; for the watcher's "
                                     "readings, all of them, spread over where the tasks are).")
        else:
            judged = reading.judged()
            others = len(reading.cubes) - len(judged)
            self.cubes_label.setText("Seen: " + "; ".join(
                f"{c.colour} {c.px:.0f} px, {c.top_points} pts, top {min(c.top_mm):.0f} mm, sat {c.saturation:.0f}"
                for c in judged)
                + (f" (and {others} black or grey thing{'s' if others != 1 else ''} the size of a cube, not judged: "
                   "the arm's parts, if it stands in view)" if others else ""))
        if self.set_marks is not None:
            marks = []
            if reading.image_size:                  # the frame the cubes should stay inside
                w, h = reading.image_size
                m = EDGE_FRAME * min(w, h)
                marks.append({"kind": "poly", "points": [(m, m), (w - m, m), (w - m, h - m), (m, h - m)],
                              "colour": (143, 168, 186), "width": 1, "label": "keep the cubes inside"})
            for c in reading.cubes:
                ok = (cs.status_of("saturation", c.saturation) != cs.FAILS
                      and cs.status_of("top_points", c.top_points) != cs.FAILS)
                if c.outline:
                    marks.append({"kind": "poly", "points": c.outline, "colour": (120, 255, 160) if ok else
                                  (255, 107, 107), "width": 2, "label": c.colour})
            self.set_marks(marks)

    # ---- session check ---------------------------------------------------------------------------------------------
    def _set_mode(self, mode: str) -> None:
        self.mode = mode
        if self.reading is not None:
            self._show_verdict(self.reading)

    def _session_text(self, reading: cs.SetupReading) -> str:
        """Has the camera moved since the reference -- up or down, tilted, turned (the table shows those), or slid
        along the table (only the picture shows that) -- and are its settings, depth preset and detection as saved?"""
        if self.reference is None:
            return "No reference saved yet: set the camera up, then press Save reference."
        extras = self._session_extras
        normal = (self.reference.get("reading") or {}).get("plane_normal")
        shift = cs.plane_shift(self.reference.get("values", {}), reading, normal)
        parts, moved = [], []
        if shift is None:
            parts.append("The table isn't seen well enough to compare.")
        else:
            if abs(shift["height_mm"]) > MOVED_MM:
                moved.append(f"height {shift['height_mm']:+.1f} mm")
            if abs(shift["tilt_deg"]) > TURNED_DEG:
                moved.append(f"tilt {shift['tilt_deg']:+.2f}°")
            if shift.get("turned_deg") is not None and shift["turned_deg"] > TURNED_DEG:
                moved.append(f"turned {shift['turned_deg']:.2f}°")
        picture = extras.get("picture")
        if picture is not None:
            slid, rotation, scale, _ = picture
            factor = (reading.image_size[0] / drift.REFERENCE_WIDTH) if reading.image_size else 1.0
            if slid >= drift.MOVED_SHIFT_PX:
                moved.append(f"the picture slid {slid * factor:.0f} px")
            if abs(rotation) >= drift.MOVED_ROTATION_DEG:
                moved.append(f"the picture turned {rotation:.1f}°")
            if abs(scale) >= drift.MOVED_SCALE:
                moved.append(f"the picture is {abs(scale) * 100:.0f}% {'closer' if scale > 0 else 'further'}")
        elif extras.get("picture_tried"):
            parts.append("(The picture couldn't be compared: too few distinctive features in view.)")
        elif self._reference_view is None:
            parts.append("(No reference picture: only the table is compared -- a camera slid along the table isn't "
                         "seen. Save the reference again to add one.)")
        since = f"Since the reference ({self.reference.get('saved', '?')}): "
        if moved:
            parts.insert(0, since + "the camera moved (" + "; ".join(moved) + "): recalibrate.")
        elif shift is not None:
            parts.insert(0, since + f"the camera hasn't moved (height {shift['height_mm']:+.1f} mm, tilt "
                         f"{shift['tilt_deg']:+.2f}°" + (", the picture matches" if picture is not None else "") + ").")
        if "controls" not in extras:
            parts.append("Checking the settings...")
        else:
            changed = self._settings_changed(extras["controls"])
            parts.append(("Settings changed: " + ", ".join(changed) + ".") if changed else "Settings as saved.")
        return " ".join(parts)

    def _settings_changed(self, now: dict) -> list:
        """What differs from the reference: the picture settings that recreate the picture (not a value the camera's
        automatic one chooses), the depth preset, the detection."""
        saved = settings_to_keep((self.reference or {}).get("controls", {}))
        if not now:
            return ["(the camera's settings couldn't be read)"] if saved else []
        changed = [CONTROL_LABELS.get(k, k) for k in saved if k in now and now[k] != saved[k]]
        preset_then = (self.reference or {}).get("depth_preset")
        preset_now = getattr(self.camera, "depth_preset", None)
        if preset_then and preset_now and preset_then != preset_now:
            changed.append(f"depth preset ({preset_then} then, {preset_now} now)")
        detection_then = (self.reference or {}).get("detection")
        if detection_then and self.hooks is not None:
            detection_now = self.hooks.current_detection()
            if detection_now != detection_then:
                changed.append(f"detection ({DETECTION_NAMES.get(detection_then, detection_then)} then, "
                               f"{DETECTION_NAMES.get(detection_now, detection_now)} now)")
        return changed

    # ---- picture settings ------------------------------------------------------------------------------------------
    def _current_controls(self) -> dict:
        try:
            return {name: c.value for name, c in self.camera.controls().items()}
        except Exception:  # noqa: BLE001
            return {}

    def _build_controls(self) -> None:
        try:
            controls = self.camera.controls() if hasattr(self.camera, "controls") else {}
        except Exception as exc:  # noqa: BLE001
            logger.info("No camera settings: %s", exc)
            controls = {}
        if not controls:
            self.controls_layout.addWidget(QLabel("This camera offers no picture settings to the app."), 0, 0)
            return
        row = 0
        for name in CONTROL_LABELS:
            control = controls.get(name)
            if control is None or name.endswith("_auto"):
                continue
            label = QLabel(control.label)
            label.setStyleSheet("color: #b8c7d1;")
            self.controls_layout.addWidget(label, row, 0)
            auto_name = AUTO_FOR.get(name)
            auto_box = None
            if auto_name in controls and name != "gain":
                auto_box = QCheckBox("automatic")
                auto_box.setChecked(bool(controls[auto_name].value))
                auto_box.toggled.connect(lambda on, a=auto_name: self._set_control(a, on))
                self.controls_layout.addWidget(auto_box, row, 1)
            if control.kind == "choice":
                widget = QComboBox()
                for value, text in control.choices.items():
                    widget.addItem(text, value)
                widget.setCurrentIndex(max(0, widget.findData(control.value)))
                widget.activated.connect(lambda _i, n=name, w=widget: self._set_control(n, w.currentData()))
                self.controls_layout.addWidget(widget, row, 2)
                value_label = None
            else:
                widget = QSlider(Qt.Orientation.Horizontal)
                # (the depth exposure's range runs to 165000, and 1200 sat a pixel from the slider's end: only the part
                # of it that's of use, with steps that move it)
                if name in SLIDER_MAX:
                    high = max(min(int(control.high), SLIDER_MAX[name]), int(control.value))
                    widget.setRange(int(control.low), high)
                    widget.setSingleStep(max(int(control.step or 1), 10))
                    widget.setPageStep(max(10, (high - int(control.low)) // 20))
                else:
                    widget.setRange(int(control.low), int(control.high))
                    widget.setSingleStep(int(control.step or 1))
                widget.setValue(int(control.value))
                value_label = QLabel(str(control.value))
                value_label.setMinimumWidth(52)
                # sent a moment after it stops moving: a drag, the arrow keys, the wheel or a click on the track
                send = QTimer(self)
                send.setSingleShot(True)
                send.setInterval(SLIDER_DELAY_MS)
                send.timeout.connect(lambda n=name, w=widget: self._set_control(n, w.value()))
                self._slider_timers[name] = send
                widget.valueChanged.connect(lambda v, lab=value_label, t=send: (lab.setText(str(v)), t.start()))
                self.controls_layout.addWidget(widget, row, 2)
                self.controls_layout.addWidget(value_label, row, 3)
            self.control_widgets[name] = (widget, auto_box, value_label)
            self.control_rows[name] = [w for w in (label, auto_box, widget, value_label) if w is not None]
            row += 1
        self.controls_layout.setColumnStretch(2, 1)
        self._sync_auto()

    def _sync_auto(self) -> None:
        """A manual setting can't be moved while its automatic one is on; nothing can while locked, or while an
        action runs."""
        frozen = self._locked() or self._action is not None
        for name, (widget, auto_box, _) in self.control_widgets.items():
            auto_on = auto_box is not None and auto_box.isChecked()
            widget.setEnabled(not frozen and not auto_on)
            if auto_box is not None:
                auto_box.setEnabled(not frozen)
        if hasattr(self, "best_btn"):          # (the settings are built before the buttons)
            self.best_btn.setEnabled(not frozen and "exposure" in self.control_widgets)

    def _set_control(self, name: str, value) -> None:
        if self._locked() or self._action is not None:
            self._sync_controls_from_camera()          # (the widget back as the camera has it)
            return
        refused = self._app_refuses()
        if refused:
            self._sync_controls_from_camera()
            QMessageBox.information(self, "Camera setup", f"Not changed: {refused}")
            return
        try:
            got = self.camera.set_control(name, value)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Camera setup", str(exc))
            self._sync_controls_from_camera()
            return
        self._save_controls()
        self._reset_steadiness()
        logger.info("Camera setup: %s = %s (saved)", name, got)
        self._sync_auto()

    def _save_controls(self) -> None:
        """Keep every setting that recreates the picture (config.yaml camera: controls / controls_demo), not only the
        one just changed: the next start then sets the camera up as it is now."""
        now = self._current_controls()
        if now:
            # over what was kept: a setting the camera didn't answer for this time (a failed read) stays, not dropped
            kept = {k: v for k, v in dict(self.config.get("camera", {}).get(self.controls_key) or {}).items()
                    if k not in now}
            self.save_value(("camera", self.controls_key), {**kept, **settings_to_keep(now)})

    def _app_refuses(self) -> Optional[str]:
        """Why the app won't have the camera's picture changed now (a calibration step or a prompt using it, the arm
        moving: as for the depth preset), or None."""
        refused = getattr(self.hooks, "preset_refused", None) if self.hooks is not None else None
        return refused() if refused is not None else None

    # ---- lock ---------------------------------------------------------------------------------------------------------
    def _locked(self) -> bool:
        return bool(self.config["camera"].get(self.lock_key, False))

    def _show_lock(self) -> None:
        locked = self._locked()
        self.lock_btn.setText("🔒 Locked for study" if locked else "Lock for study")
        self.lock_btn.setToolTip("Unlock to change the camera's settings (asks, and is logged)" if locked else
                                 "Keep the settings as they are for the whole study")
        self._sync_auto()

    def _toggle_lock(self) -> None:
        locked = self._locked()
        if locked and QMessageBox.question(
                self, "Unlock the camera's settings?",
                "The study compares rounds made with the same camera settings. Unlock to change them? (The change is "
                "logged; recalibrate after changing any of them.)") != QMessageBox.StandardButton.Yes:
            return
        self.save_value(("camera", self.lock_key), not locked)
        logger.warning("Camera setup %s for the study", "unlocked" if locked else "locked")
        self._log_change("unlocked" if locked else "locked")
        self._show_lock()

    def _log_change(self, what: str) -> None:
        log_change(self.references_dir, what, self._current_controls())

    # ---- reference -------------------------------------------------------------------------------------------------
    def _load_reference(self) -> Optional[dict]:
        path = self.references_dir / "reference.json"
        try:
            return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
        except (OSError, ValueError):
            return None

    def _load_reference_view(self):
        """The reference's picture, small and grey (to tell a camera slid along the table: the table alone can't)."""
        path = self.references_dir / "reference_view.npz"
        try:
            import numpy as np
            with np.load(path) as data:
                return data["gray"]
        except Exception:  # noqa: BLE001 - none saved yet (or unreadable): the table alone is compared
            return None

    def reference_record(self) -> dict:
        reading = self.reading or cs.SetupReading()
        info = self.camera.describe() if hasattr(self.camera, "describe") else {}
        return {"saved": time.strftime("%Y-%m-%d %H:%M"), "targets_version": cs.TARGETS_VERSION,
                "verdict": self.verdict_text, "values": reading.values(self.cube_mm),
                "statuses": self.statuses, "reading": reading.as_dict(), "controls": self._current_controls(),
                "camera": info, "depth_preset": getattr(self.camera, "depth_preset", None),
                "last_calibration": self._last_calibration_text(), "comparisons": self.comparisons,
                "detection": self.hooks.current_detection() if self.hooks is not None else None,
                "expected_cubes": self.expected_cubes, "shake_mm": self.shake_mm}

    def _save_reference(self) -> None:
        if self.reading is None or self._action is not None:
            return
        if self.verdict_text in (cs.NOT_READY, SETTLING) and QMessageBox.question(
                self, "Save reference?", ("Some readings that block calibration aren't acceptable yet. "
                                          if self.verdict_text == cs.NOT_READY else
                                          "The readings haven't held steady for 5 s yet. ")
                + "Save this as the reference anyway?") != QMessageBox.StandardButton.Yes:
            return
        record = self.reference_record()
        try:
            self.references_dir.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            text = json.dumps(record, indent=2, default=str)
            (self.references_dir / f"reference_{stamp}.json").write_text(text, encoding="utf-8")
            (self.references_dir / "reference.json").write_text(text, encoding="utf-8")
            view = None
            try:
                import numpy as np
                frame = self.camera.get_frame()
                view = drift._shrunk_gray(frame.rgb)
                for name in (f"reference_view_{stamp}.npz", "reference_view.npz"):
                    np.savez_compressed(self.references_dir / name, gray=view)
                if not self.demo:            # (the demo's simulated picture isn't kept as a picture)
                    import cv2
                    cv2.imwrite(str(self.references_dir / f"reference_{stamp}.png"),
                                cv2.cvtColor(frame.rgb, cv2.COLOR_RGB2BGR))
            except Exception as exc:  # noqa: BLE001 - the readings are the reference; the picture is extra
                logger.info("No reference picture: %s", exc)
        except OSError as exc:
            QMessageBox.warning(self, "Camera setup", f"Couldn't save the reference: {exc}")
            return
        self.reference = record
        if view is not None:
            self._reference_view = view
        self._log_change("reference saved")
        self.verdict_detail.setText(f"Reference saved ({record['saved']}): each session's check compares against it.")

    def _last_calibration_text(self) -> str:
        try:
            data = json.loads(self.calibration_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return "No calibration yet"
        when = time.strftime("%d %b %H:%M", time.localtime(self.calibration_path.stat().st_mtime))
        error = data.get("reproj_error_mm", data.get("reprojection_error_mm"))
        return (f"Last calibration\n{error:.2f} mm · {data.get('method', '?')} · {when}" if error is not None
                else f"Last calibration\n{data.get('method', '?')} · {when}")

    # ---- actions: what takes a while, one at a time ----------------------------------------------------------------
    def _start_action(self, what: str, fn: Callable, args: tuple, on_done: Callable, on_failed: Callable) -> bool:
        """Run `fn` off the UI thread as the window's one action: meanwhile the looking pauses, the window's settings
        and buttons and the app's tabs are held (E-STOP stays), and the window can't be closed."""
        if self._action is not None:
            QMessageBox.information(self, "Camera setup", f"Wait: {self._action} is still running.")
            return False
        self._action = what
        self._timer.stop()
        self._set_busy(True)
        self._hold(what)
        self._launch_when_idle(fn, args, on_done, on_failed)
        return True

    def _launch_when_idle(self, fn: Callable, args: tuple, on_done: Callable, on_failed: Callable) -> None:
        if self._tick_worker is not None:          # a look is under way: start once it's done
            QTimer.singleShot(50, lambda: self._launch_when_idle(fn, args, on_done, on_failed))
            return
        worker = CallableWorker(fn, *args)
        worker.finished_ok.connect(lambda result: self._action_finished(on_done, result))
        worker.failed.connect(lambda message: self._action_finished(on_failed, message))
        self._action_worker = worker
        worker.start()

    def _action_finished(self, then: Callable, value) -> None:
        self._action, self._action_worker = None, None
        self._hold(None)
        self._set_busy(False)
        self._reset_steadiness()
        try:
            then(value)
        finally:
            self._timer.start(700)

    def _hold(self, what: Optional[str]) -> None:
        """The app held (its tabs, the watcher's Start run, the depth preset) while an action runs, or let go."""
        hold = getattr(self.hooks, "hold", None) if self.hooks is not None else None
        if hold is not None:
            hold(f"Camera setup is {what}" if what else None)

    def _set_busy(self, busy: bool) -> None:
        for widget in (self.tabs, self.save_btn, self.lock_btn, self.best_btn, self.shake_btn, self.caps_btn,
                       self.cubes_spin):
            widget.setEnabled(not busy)
        if busy:
            self.start_btn.setEnabled(False)
        else:
            self._sync_auto()
            self._show_comparisons()

    def is_busy(self) -> bool:
        return self._action is not None

    def _show_capabilities(self) -> None:
        try:
            text = self.camera.capabilities() if hasattr(self.camera, "capabilities") else "Not available."
        except Exception as exc:  # noqa: BLE001
            text = f"Couldn't ask the camera: {exc}"
        box = QMessageBox(self)
        box.setWindowTitle("Camera capabilities")
        box.setText(text)
        box.exec()

    def find_best_exposure(self, candidates: Optional[list] = None, settle_s: float = 0.4, settle_frames: int = 3,
                           watch_frame_time: bool = False) -> Optional[int]:
        """Try exposures (manual), keep one whose picture scores near the best for the cubes' colours
        (camera_setup.best_exposure_score), the cubes' brightness nearest the middle (camera_setup.pick_exposure);
        returns it, or None if no cube was seen at any -- and then the camera's
        exposure is put back as it was (also if anything goes wrong). After each change `settle_frames` pictures are
        let go by (still taken with the old exposure). Very long exposures are left out: up to 8 times the camera's
        usual one, and (`watch_frame_time`, the real camera) none that slows its pictures down."""
        controls = self.camera.controls()
        control = controls.get("exposure")
        if control is None:
            return None
        before = {name: controls[name].value for name in ("exposure_auto", "exposure", "gain") if name in controls}
        found = None
        try:
            if "exposure_auto" in controls:
                self.camera.set_control("exposure_auto", False)
            if candidates is None:
                usual = float(control.default or control.value or control.high)
                low = max(1.0, float(control.low))
                high = max(low * 2.0, min(float(control.high), 8.0 * max(usual, float(control.value or 0))))
                candidates = sorted({int(round(low * (high / low) ** (i / 9))) for i in range(10)})
            usual_frame_s = self._frame_time() if watch_frame_time else None
            looked: list = []                    # (exposure, its reading)
            for value in candidates:
                self.camera.set_control("exposure", value)
                time.sleep(settle_s)
                for _ in range(settle_frames):
                    self.camera.get_frame()
                started = time.monotonic()
                frame = self.camera.get_frame()
                took = time.monotonic() - started
                if usual_frame_s is not None and took > 2.0 * usual_frame_s + 0.05:
                    logger.info("Exposure %s slows the camera's pictures (%.0f ms, usually %.0f): no longer ones tried",
                                value, 1000 * took, 1000 * usual_frame_s)
                    break
                looked.append((value, cs.measure(frame.rgb, frame.depth, frame.intrinsics, self.cube_mm,
                                                 warmup_min=self._warmup_min())))
            # judged together: the cubes are where something read coloured at any of the exposures (one too dark to
            # read coloured at a short exposure is still judged there -- and marked down)
            places = cs.coloured_places([reading for _, reading in looked])
            scored = []
            for value, reading in looked:
                score = cs.best_exposure_score(reading, places)
                brightness = cs.cubes_brightness(reading, places)
                logger.info("Exposure %s: score %.0f, the cubes' brightness %s", value, score,
                            "-" if brightness is None else f"{brightness:.0f}")
                scored.append((value, score, brightness))
            best = cs.pick_exposure(scored)
            if best is not None:
                self.camera.set_control("exposure", best)
                found = best
            return found
        finally:
            if found is None:                  # nothing better found (or a problem): the camera as it was
                try:
                    self.camera.apply_controls(before)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Couldn't put the exposure back as it was: %s", exc)

    def _frame_time(self) -> Optional[float]:
        """How long a picture usually takes to come (the shortest of a few)."""
        times = []
        for _ in range(4):
            started = time.monotonic()
            self.camera.get_frame()
            times.append(time.monotonic() - started)
        return min(times) if times else None

    def _find_best_exposure(self) -> None:
        if self._locked():
            return
        refused = self._app_refuses()
        if refused:
            QMessageBox.information(self, "Find best exposure", f"Not now: {refused}")
            return
        if self._start_action("finding the best exposure", self.find_best_exposure,
                              (None, 0.0 if self.demo else 0.4, 0 if self.demo else 3, not self.demo),
                              self._best_done, lambda message: self._best_done(None, message)):
            self.verdict_detail.setText("Trying exposures... (keep the cubes where they are)")

    def _best_done(self, best, message: str = "") -> None:
        self._sync_controls_from_camera()
        if best is None:
            QMessageBox.information(self, "Find best exposure", (message or "No cube was seen at any exposure: put "
                                    "the cubes on the table first.") + " The exposure is back as it was.")
            return
        self._save_controls()
        self._reset_steadiness()
        self.verdict_detail.setText(f"Exposure set to {best} (manual): the cubes' colours read well there, with "
                                    "room for the light to change.")

    # ---- the shake test ----------------------------------------------------------------------------------------------
    def run_shake_test(self, lift_mm: float = 30.0) -> float:
        """The arm 3 cm up and back down while the camera watches the table; the camera's movement meanwhile (mm).
        See shake_test: it raises rather than guess."""
        result = shake_test(self.robot, self.camera, lift_mm)
        self._shake_view = (result["offset_mm"], result["normal"])
        return result["shake_mm"]

    def _shake_test(self) -> None:
        if self.robot is None:
            QMessageBox.information(self, "Shake test", "No robot to move: connect the arm first.")
            return
        busy = getattr(self.hooks, "arm_refused", None) if self.hooks is not None else None
        refused = busy() if busy is not None else None
        if refused:
            QMessageBox.information(self, "Shake test", f"Not now: {refused}")
            return
        if QMessageBox.question(self, "Shake test", "The arm moves 3 cm straight up and back down where it is now. "
                                "Keep the area clear, E-STOP in reach. Go?") != QMessageBox.StandardButton.Yes:
            return
        self._start_action("running the shake test", self.run_shake_test, (), self._shake_done,
                           lambda message: self._shake_done(None, message))

    def _shake_done(self, shake, message: str = "") -> None:
        if shake is None:
            self._shake_view = None
            QMessageBox.warning(self, "Shake test", message or "Not enough pictures of the table to tell.")
        else:
            self.shake_mm = shake

    # ---- the demo: practising with the simulated camera ----------------------------------------------------------
    def _demo_tab(self) -> QWidget:
        """Practice on the demo before the lab: move the simulated camera, or give it the lab's trouble to fix (too
        far, colours washed out by the automatic exposure, the High Accuracy preset)."""
        tab = QWidget()
        grid = QGridLayout(tab)
        intro = QLabel("Practise here before the lab. <b>Practice like the lab</b> gives the demo camera last night's "
                       "trouble: too far away, its automatic exposure washing the cubes' colours out, and the High "
                       "Accuracy preset. Fix it as you would at the lab: move it (below) until Height and Cube size "
                       "are green, Find best exposure, compare the depth presets, then calibrate.")
        intro.setWordWrap(True)
        intro.setStyleSheet("color: #b8c7d1;")
        grid.addWidget(intro, 0, 0, 1, 4)
        self.demo_sliders = {}
        for row, (key, label, low, high, value) in enumerate((
                ("up", "Raise / lower (cm)", -30, 30, getattr(self.camera, "view_up_mm", 0.0) / 10.0),
                ("back", "Back / forward (cm)", -30, 30, getattr(self.camera, "view_back_mm", 0.0) / 10.0),
                ("tilt", "Tilt on the mount (° towards straight down)", -20, 40,
                 getattr(self.camera, "view_tilt_deg", 0.0))), start=1):
            grid.addWidget(QLabel(label), row, 0)
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(low, high)
            slider.setValue(int(round(value)))
            shown = QLabel()
            grid.addWidget(slider, row, 1, 1, 2)
            grid.addWidget(shown, row, 3)
            slider.valueChanged.connect(self._demo_slider_moved)
            self.demo_sliders[key] = (slider, shown)
        self._demo_move = QTimer(self)
        self._demo_move.setSingleShot(True)
        self._demo_move.setInterval(SLIDER_DELAY_MS)
        self._demo_move.timeout.connect(self._move_demo_camera)
        self._show_demo_place()
        buttons = QHBoxLayout()
        lab = QPushButton("Practice like the lab")
        lab.clicked.connect(self.practice_like_the_lab)
        reset = QPushButton("Reset the demo camera")
        reset.clicked.connect(self.reset_demo_camera)
        exact = QPushButton("Use the simulator's exact calibration here")
        exact.setToolTip("Skip calibrating: the simulator knows exactly where its camera is now")
        exact.clicked.connect(self._exact_calibration)
        exact.setEnabled(self.hooks is not None and getattr(self.hooks, "restore_builtin", None) is not None)
        for b in (lab, reset, exact):
            buttons.addWidget(b)
        buttons.addStretch()
        grid.addLayout(buttons, 4, 0, 1, 4)
        self.demo_note = QLabel("")
        self.demo_note.setWordWrap(True)
        self.demo_note.setStyleSheet("color: #f5a742;")
        grid.addWidget(self.demo_note, 5, 0, 1, 4)
        grid.setColumnStretch(1, 1)
        grid.setRowStretch(6, 1)
        return tab

    def _demo_slider_moved(self) -> None:
        self._show_demo_place()
        self._demo_move.start()

    def _show_demo_place(self) -> None:
        for key, (slider, shown) in self.demo_sliders.items():
            shown.setText(f"{slider.value():+d} {'°' if key == 'tilt' else 'cm'}")

    def _move_demo_camera(self) -> None:
        self.move_demo_camera(*(self.demo_sliders[k][0].value() for k in ("up", "back", "tilt")))

    def move_demo_camera(self, up_cm: float, back_cm: float, tilt_deg: float) -> None:
        """Practice: the demo camera raised `up_cm`, moved back `back_cm` and tilted `tilt_deg` from where it was
        mounted (the sliders follow)."""
        self.camera.place(10.0 * up_cm, 10.0 * back_cm, tilt_deg)
        for key, value in (("up", up_cm), ("back", back_cm), ("tilt", tilt_deg)):
            slider = self.demo_sliders[key][0]
            slider.blockSignals(True)
            slider.setValue(int(round(value)))
            slider.blockSignals(False)
        self._show_demo_place()
        self._reset_steadiness()                    # (the readings before the move don't count)
        self.demo_note.setText("The camera moved: the calibration in use no longer fits it (as at the lab). "
                               "Calibrate again, or use the simulator's exact calibration here.")

    def practice_like_the_lab(self) -> None:
        """The lab's trouble on the demo camera: 35% too far, colours washed out, the High Accuracy preset."""
        if "exposure_auto" in self.camera.controls():
            self.camera.set_control("exposure_auto", True)
        self.camera.washed_out = True
        if self.hooks is not None and "High Accuracy" in self.hooks.presets:
            self.hooks.switch_preset("High Accuracy")
        self.move_demo_camera(12.0, 15.0, -5.0)        # too high, too far back, too flat
        self._sync_controls_from_camera()
        self._save_controls()
        self.demo_note.setText("Like the lab: too far, colours washed out (automatic exposure), High Accuracy. "
                               "Fix them one by one: the gauges say what to do.")

    def reset_demo_camera(self) -> None:
        self.camera.washed_out = False
        if "exposure_auto" in self.camera.controls():
            self.camera.set_control("exposure_auto", True)
        if self.hooks is not None and self.hooks.current_preset() != self.hooks.presets[0]:
            self.hooks.switch_preset(self.hooks.presets[0])
        self.move_demo_camera(0.0, 0.0, 0.0)
        self._sync_controls_from_camera()
        self._save_controls()
        self.demo_note.setText("The demo camera is back as mounted.")

    def _exact_calibration(self) -> None:
        if self.hooks is not None and getattr(self.hooks, "restore_builtin", None) is not None:
            self.hooks.restore_builtin()
            self.demo_note.setText("Calibrated: the simulator's exact calibration for where the camera is now.")
            self.last_calibration.setText(self._last_calibration_text())

    def _sync_controls_from_camera(self) -> None:
        """The settings' widgets as the camera has them now (after the demo changed them)."""
        controls = self._current_controls()
        for name, (widget, auto_box, value_label) in self.control_widgets.items():
            auto_name = AUTO_FOR.get(name)
            if auto_box is not None and auto_name in controls:
                auto_box.blockSignals(True)
                auto_box.setChecked(bool(controls[auto_name]))
                auto_box.blockSignals(False)
            if name in controls and isinstance(widget, QSlider):
                widget.blockSignals(True)
                widget.setValue(int(controls[name]))
                widget.blockSignals(False)
                if value_label is not None:
                    value_label.setText(str(controls[name]))
        self._sync_auto()

    # ---- steps -------------------------------------------------------------------------------------------------------
    def step_states(self) -> dict:
        """Each step: done (True), or not yet (False)."""
        ok = lambda names: all(self.statuses.get(n) in (cs.MEETS, cs.CLOSE) for n in names)   # noqa: E731
        calibrated = False
        if self.hooks is not None:
            calibrated = bool(self.hooks.is_calibrated()) and (self.hooks.calibration_preset() in
                                                               (None, self.hooks.current_preset()))
        return {"Position": ok(("height_cm", "cube_px")), "Picture": ok(("saturation", "clipped_pct")),
                "Depth preset": "depth_preset" in self.comparisons, "Save reference": self.reference is not None,
                "Calibrate": calibrated, "Detection": "detection" in self.comparisons, "Lock for study": self._locked()}

    def _show_steps(self) -> None:
        states = self.step_states()
        # (the comparisons' steps only with "Show advanced": out of sight, nothing to do there)
        advanced = self.advanced_switch.isChecked()
        shown = [s for s in STEPS if advanced or s not in ADVANCED_STEPS]
        current = next((s for s in shown if not states[s]), None)
        for step, label in self.step_labels.items():
            label.setVisible(step in shown)
            done = states[step]
            label.setText(("✓ " if done else "● " if step == current else "○ ") + step)
            label.setStyleSheet("color: %s;%s" % ("#6bdc8b" if done else "#e8eef3" if step == current else "#8fa8ba",
                                                  " font-weight: 600;" if step == current else ""))

    # ---- comparing: the depth preset -----------------------------------------------------------------------------
    def compare_presets(self, looks: int = COMPARE_LOOKS, settle_s: float = 3.0, blocks: int = 2) -> dict:
        """Look `looks` times with each depth preset and say which is better for the calibration
        (camera_setup.look_summary / choose). Interleaved, A B B A (with two presets): a slow change in the room or
        the camera's warming falls on both alike, and the change between one preset's two blocks says how big a
        difference is only noise. Each switch is checked -- a camera that won't take a preset stops the comparison
        (never one preset compared with itself) -- and after it `settle_s` and a few pictures are let go by. The one
        in use is put back at the end."""
        hooks = self.hooks
        original = hooks.current_preset()
        names = [original] + [p for p in hooks.presets if p != original]
        order = [names if b % 2 == 0 else list(reversed(names)) for b in range(max(1, blocks))]
        per_block: dict = {name: [] for name in names}
        each = max(2, looks // max(1, blocks))
        try:
            for block in order:
                for name in block:
                    if hooks.current_preset() != name:
                        said = hooks.switch_preset(name)
                        if hooks.current_preset() != name:
                            raise RuntimeError(f"The camera wouldn't switch to the {name} preset, so there is nothing "
                                               f"to compare it with ({said or 'it stayed on ' + str(hooks.current_preset())}).")
                        self._settle(settle_s)
                    readings = []
                    for _ in range(each):
                        try:
                            readings.append(self.measure_once())
                        except Exception as exc:  # noqa: BLE001 - a missed look is one fewer
                            logger.info("A look while comparing presets failed: %s", exc)
                    per_block[name].append(readings)
        finally:
            if hooks.current_preset() != original:
                hooks.switch_preset(original)
        results = {name: cs.look_summary([r for b in per_block[name] for r in b], self.cube_mm) for name in names}
        noise = cs.block_noise({name: [cs.look_summary(b, self.cube_mm) for b in per_block[name] if b]
                                for name in names}, cs.PRESET_TIES)
        winner, why, tie = cs.choose(results, original, cs.PRESET_TIES, by_seen=True, noise=noise)
        return {"results": results, "winner": winner, "why": why, "tie": tie, "current": original, "noise": noise,
                "order": [n for block in order for n in block], "when": time.strftime("%Y-%m-%d %H:%M")}

    def _settle(self, settle_s: float) -> None:
        """After a stream restart: wait, and let a few pictures go by (the depth settles over the first ones)."""
        if settle_s <= 0:
            return
        time.sleep(settle_s)
        for _ in range(5):
            try:
                self.camera.get_frame()
            except Exception:  # noqa: BLE001 - only waiting
                pass

    def _compare_presets(self) -> None:
        if self.hooks is None:
            return
        refused = self.hooks.preset_refused()
        if refused:
            QMessageBox.information(self, "Compare presets", refused)
            return
        if self._start_action("comparing the depth presets", self.compare_presets,
                              (COMPARE_LOOKS, 0.0 if self.demo else 3.0),
                              lambda result: self._compared("depth_preset", result),
                              lambda message: self._compare_failed(self.preset_panel, message)):
            self.preset_panel.result_label.setText("Comparing... the camera switches presets and back (keep the "
                                                   "cubes where they are).")

    def _use_preset(self) -> None:
        result = self.comparisons.get("depth_preset")
        if result is None or self.hooks is None:
            return
        refused = self.hooks.preset_refused()
        if refused:
            QMessageBox.information(self, "Depth preset", f"Not changed: {refused}")
            return
        if not self._may_change(f"depth preset {result['winner']}"):
            return
        self.hooks.apply_preset(result["winner"])
        self.preset_panel.use_btn.setEnabled(False)
        # it switches in the background: logged and said once the camera has (or hasn't) taken it
        self._awaiting = (result["winner"], result["why"], time.monotonic() + 60.0)
        self._preset_wait.start()

    def _check_preset_done(self) -> None:
        if self._awaiting is None:
            self._preset_wait.stop()
            return
        name, why, give_up = self._awaiting
        switching = getattr(self.hooks, "preset_switching", None)
        if switching is not None and switching() and time.monotonic() < give_up:
            return
        self._preset_wait.stop()
        self._awaiting = None
        self.preset_panel.use_btn.setEnabled(True)
        now = self.hooks.current_preset()
        if now == name:
            self._log_change(f"depth preset set to {name} ({why})")
            self.preset_panel.use_btn.setVisible(False)
            self._reset_steadiness()
            QMessageBox.information(self, "Depth preset", f"Depth preset: {name}. A calibration belongs to the preset "
                                    "it was made with: calibrate again.")
        else:
            self._log_change(f"depth preset NOT changed to {name}: the camera is on {now}")
            QMessageBox.warning(self, "Depth preset", f"The camera didn't change to {name}: it is on {now} (the "
                                "app's status bar says why).")

    # ---- comparing: the detection --------------------------------------------------------------------------------
    def compare_detection(self, looks: int = COMPARE_LOOKS) -> dict:
        """Both of the app's detectors on the same `looks` pictures (in robot coordinates, by the calibration in use),
        against where the depth reading puts each cube; which is better for the robot's picks."""
        import numpy as np
        hooks = self.hooks
        transform = np.asarray(hooks.get_transform(), float)
        per = {key: [] for key in DETECTION_NAMES}
        truth_points: dict = {}
        expected: list = []
        for _ in range(looks):
            frame = self.camera.get_frame()
            reading = cs.measure(frame.rgb, frame.depth, frame.intrinsics, self.cube_mm)
            if len(reading.cubes) > len(expected):
                expected = [c.colour for c in reading.cubes]
            for cube in reading.cubes:
                if cube.centre_mm:
                    xy = (transform @ np.append(np.asarray(cube.centre_mm, float), 1.0))[:2]
                    truth_points.setdefault(cube.colour, []).append((float(xy[0]), float(xy[1])))
            found = hooks.detect_both(frame, transform)
            for key in per:
                per[key].append([(str(loc.label).split()[0].lower(), float(loc.xyz_robot[0]), float(loc.xyz_robot[1]),
                                  float(loc.footprint[2]) if getattr(loc, "footprint", None) else None)
                                 for loc in found.get(key, [])])
        truth = {colour: (float(np.mean([p[0] for p in pts])), float(np.mean([p[1] for p in pts])))
                 for colour, pts in truth_points.items()}
        results = {DETECTION_NAMES[key]: cs.detection_summary(per[key], expected, truth) for key in per}
        current = DETECTION_NAMES[hooks.current_detection()]
        winner, why, tie = cs.choose(results, current, cs.DETECTION_TIES)
        why += " (For choosing the setting: its truth is the depth reading.)"
        return {"results": results, "winner": winner, "why": why, "tie": tie, "current": current,
                "when": time.strftime("%Y-%m-%d %H:%M")}

    def _compare_detection(self) -> None:
        if self.hooks is None:
            return
        if not self.hooks.is_calibrated():
            QMessageBox.information(self, "Compare detection", "Calibrate first: the detectors place the cubes on the "
                                    "robot's table by the calibration (without one, both see nothing).")
            return
        if self._start_action("comparing the detection", self.compare_detection, (COMPARE_LOOKS,),
                              lambda result: self._compared("detection", result),
                              lambda message: self._compare_failed(self.detection_panel, message)):
            self.detection_panel.result_label.setText("Comparing... (keep the cubes where they are)")

    def _use_detection(self) -> None:
        result = self.comparisons.get("detection")
        if result is None or self.hooks is None or not self._may_change(f"detection {result['winner']}"):
            return
        key = next(k for k, v in DETECTION_NAMES.items() if v == result["winner"])
        self.hooks.apply_detection(key)
        if self.hooks.current_detection() == key:
            self._log_change(f"detection set to {result['winner']} ({result['why']})")
            self.detection_panel.use_btn.setVisible(False)
        else:
            self._log_change(f"detection NOT changed to {result['winner']}")
            QMessageBox.warning(self, "Detection", f"The detection didn't change to {result['winner']}.")

    # ---- comparing: shared ---------------------------------------------------------------------------------------
    def _compared(self, kind: str, result: dict) -> None:
        self.comparisons[kind] = result
        self._show_comparisons()
        self._show_steps()
        self._log_change(f"compared {kind}: {result['winner']}{' (a tie)' if result['tie'] else ''}")

    def _compare_failed(self, panel: "ComparePanel", message: str) -> None:
        panel.result_label.setText(f"Couldn't compare: {message}")

    def _show_comparisons(self) -> None:
        for kind, panel in (("depth_preset", self.preset_panel), ("detection", self.detection_panel)):
            panel.run_btn.setEnabled(self.hooks is not None and self._action is None)
            result = self.comparisons.get(kind)
            if self.hooks is None:
                panel.result_label.setText("Not available here (open Camera setup from the app's Calibration tab).")
                continue
            if result is None:
                panel.result_label.setText("Not compared yet.")
                continue
            current = (self.hooks.current_preset() if kind == "depth_preset"
                       else DETECTION_NAMES[self.hooks.current_detection()])
            panel.show_result(result, current)
            panel.result_label.setText(panel.result_label.text() + f" <span style='color:#6f8796;'>(compared "
                                       f"{result.get('when', '')})</span>")

    def _may_change(self, what: str) -> bool:
        """Locked for the study: changing a setting asks first (and is logged by the caller)."""
        if not self._locked():
            return True
        return QMessageBox.question(self, "Locked for study", f"The camera setup is locked for the study. Change the "
                                    f"{what} anyway? (It is logged.)") == QMessageBox.StandardButton.Yes

    def open_mount_mode(self) -> None:
        if self.mount_view is None:
            self.mount_view = MountView(self)
        self.mount_view.showMaximized()          # (read from a metre or two away)
        self.mount_view.raise_()
        if self.reading is not None:
            self.mount_view.show_readings(self.reading.values(self.cube_mm), self.statuses, self.best_seen,
                                          cs.aim_hints(self.reading))

    def _start_calibration(self) -> None:
        if self.on_start_calibration is not None and self._action is None:
            self.close()
            self.on_start_calibration()

    def _refuse_closing(self) -> bool:
        """True (and said) while an action runs: it puts the camera and the arm back as they were when it ends."""
        if self._action is None:
            return False
        QMessageBox.information(self, "Camera setup", f"Wait: {self._action} is still running; the window can be "
                                "closed when it ends.")
        return True

    def reject(self) -> None:
        """Esc. QDialog's own closes the window (and deletes it) without a closeEvent: under a running action its
        worker was left with no window, and what it found was lost. Refused then, as closing is."""
        if self._refuse_closing():
            return
        self._wind_down()
        super().reject()

    def closeEvent(self, event) -> None:      # noqa: N802 (Qt)
        if self._refuse_closing():
            event.ignore()
            return
        self._wind_down()
        super().closeEvent(event)

    def _wind_down(self) -> None:
        """Before the window goes: its timers stopped, a look under way let finish, its marks taken off the app's
        picture. (Run again when QDialog's closeEvent calls reject: nothing left to do then.)"""
        self._timer.stop()
        self._preset_wait.stop()
        for send in self._slider_timers.values():
            send.stop()
        if self._tick_worker is not None:      # (a look under way: let it finish before the window goes)
            self._tick_worker.wait(6000)
        if self.mount_view is not None:
            self.mount_view.close()
        if self.set_marks is not None:
            self.set_marks([])

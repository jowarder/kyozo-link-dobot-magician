"""Draws the simulated workspace with Qt: dark table with a grid, the arm, the objects.

Shared by the 3D view (Manual and Prompt tabs, a camera you move with the mouse) and the
simulated camera feed (Calibration tab, a fixed camera). Both get exactly the same look;
only the viewpoint differs. Drawing only reads state: it never touches the robot or world.
"""
from __future__ import annotations

import functools
import math
from dataclasses import dataclass
from typing import Callable, Optional

import cv2
import numpy as np
from PyQt6.QtCore import QLineF, QPointF, QRectF, Qt
from PyQt6.QtGui import (QBrush, QColor, QFont, QImage, QPainter, QPen, QPolygonF, QRadialGradient)

from app import robots

Vec = tuple[float, float, float]
Color = tuple[float, float, float]

LIGHT = (-0.35, -0.5, 0.8)
_norm = math.sqrt(sum(c * c for c in LIGHT))
LIGHT = tuple(c / _norm for c in LIGHT)

TABLE_X = (-80.0, 380.0)    # the Dobot's demo table; each robot has its own (robots.active().table_x, table_y)
TABLE_Y = (-320.0, 320.0)  # wide enough to hold the reach arc
REACH_MM = 300.0  # matches max_reach_mm in config.yaml
FRAME_COLOR = (0.22, 0.24, 0.29)  # the arm's main colour (dark slate); a module attribute so it's one place to change
# Mesh shading: a high ambient so the real arm's black parts stay visible on the dark background.
MESH_AMBIENT = 0.62
MESH_DIFFUSE = 0.5
WARN_ORANGE = (0.55, 0.28, 0.05)   # the arm's black parts when a target is past its reach
RIM_COLOR = np.array([0.55, 0.78, 0.95])   # rim light: a cool edge along the outline
RIM_STRENGTH = 0.6
SPECULAR_STRENGTH = 0.16      # kept low: the mesh is flat-shaded, so a strong highlight lights up whole facets
SMOOTH_SPECULAR_STRENGTH = 0.3   # smooth-shaded (per pixel), a highlight is a soft spot, not a lit facet
SPECULAR_POWER = 60.0
GLOW_HOLDING = np.array([0.35, 0.95, 0.55])   # gripper glow: holding something
GLOW_EMPTY = np.array([1.0, 0.7, 0.25])       # closed on nothing
SHADOW_DARKNESS = 0.55         # soft shadows: how dark the darkest part is (0..1)
# Soft shadows get their own light, almost overhead and a little behind the robot: the shading light
# (LIGHT) is further back, which put most of the shadow under the base where nobody sees it.
SHADOW_LIGHT = tuple(c / math.sqrt(0.25 ** 2 + 0.2 ** 2 + 1.0) for c in (-0.25, 0.2, 1.0))
SHADOW_SCALE = 0.5             # drawn at half size, then blurred and stretched: soft and cheap
MAT_COLOR = (0.07, 0.17, 0.16)  # measuring mat: dark green-teal, like a cutting mat


@dataclass(frozen=True)
class SceneEffects:
    """Optional effects (the Settings window's "look" and a few helpers). All off: the V1.8 look."""
    soft_shadows: bool = False
    rim_light: bool = False
    highlights: bool = False
    measuring_mat: bool = False
    gripper_glow: bool = False
    reach_map: bool = False

    @classmethod
    def from_settings(cls, settings) -> "SceneEffects":
        return cls(**{name: bool(settings[name]) for name in cls.__dataclass_fields__})


@functools.lru_cache(maxsize=256)
def _reach_band(key: str, z_mm: int) -> Optional[tuple[float, float]]:
    return robots.active().reach_band(float(z_mm))


def qcolor(c: Color, alpha: int = 255, scale: float = 1.0) -> QColor:
    r, g, b = (max(0.0, min(1.0, v * scale)) for v in c)
    return QColor(int(r * 255), int(g * 255), int(b * 255), alpha)


def lighter(c: Color, amount: float) -> Color:
    return tuple(min(1.0, v + (1.0 - v) * amount) for v in c)  # type: ignore[return-value]


def _draw_item(painter: QPainter, item, pen_scale: float) -> None:
    """One shape with QPainter: either a draw callback, or ("poly"/"tri", [(x, y)...], fill rgba,
    outline rgba or None[, OpenCV fixed-point points]). A mesh triangle is outlined in its own
    colour so no seams show."""
    if callable(item):
        item()
        return
    kind, points, fill, outline = item[:4]
    colour = QColor(*fill)
    painter.setBrush(QBrush(colour))
    if kind == "tri":
        painter.setPen(QPen(colour, 0.8 * pen_scale))
    else:
        painter.setPen(QPen(QColor(*outline), pen_scale) if outline is not None else Qt.PenStyle.NoPen)
    painter.drawPolygon(QPolygonF([QPointF(x, y) for x, y in points]))


_SUBPIXEL_BITS = 4   # OpenCV's fixed-point coordinates: 1/16 pixel


def _fixed_point(points: np.ndarray, ratio: float) -> np.ndarray:
    """Logical pixel coordinates -> OpenCV's fixed-point device pixels (int32), clipped so far-off
    projected corners stay inside its range."""
    limit = 1 << 26
    return np.clip(np.round(np.asarray(points) * (ratio * (1 << _SUBPIXEL_BITS))), -limit, limit).astype(np.int32)


def _raster_solids(painter: QPainter, items: list, width: int, height: int, pen_scale: float,
                   smooth: Optional[dict] = None) -> None:
    """The solid shapes, already sorted far to near, filled with OpenCV onto one transparent image and
    drawn once. The real arm is a few thousand triangles: one QPainter call each costs tens of
    microseconds from Python, so a frame took well over 100 ms; OpenCV's fills are C++ and take a few
    microseconds. Anti-aliased filling onto a clear image gives premultiplied alpha, as QImage wants.
    `smooth`: the triangles to light pixel by pixel (see _smooth_shade); their items carry their number."""
    device = painter.device()
    ratio = device.devicePixelRatioF() if device is not None else 1.0
    cols, rows = max(1, int(round(width * ratio))), max(1, int(round(height * ratio)))
    canvas = np.zeros((rows, cols, 4), np.uint8)
    # which smooth-shaded triangle each pixel shows (-1: something else), filled in the same order as the picture
    ids = np.full((rows, cols), -1, np.int32) if smooth else None
    for item in items:
        kind, points, fill, outline = item[:4]
        pts = item[4] if len(item) > 4 else _fixed_point(points, ratio)
        colour = (fill[2], fill[1], fill[0], 255)
        number = item[5] if len(item) > 5 and item[5] is not None else -1
        if kind == "tri":
            cv2.fillConvexPoly(canvas, pts, colour, cv2.LINE_AA, _SUBPIXEL_BITS)
            if number < 0:     # (a smooth-shaded one has no seams to hide: its pixels are all lit again below)
                cv2.polylines(canvas, [pts], True, colour, 1, cv2.LINE_AA, _SUBPIXEL_BITS)
        else:
            cv2.fillPoly(canvas, [pts], colour, cv2.LINE_AA, _SUBPIXEL_BITS)
            if outline is not None:
                cv2.polylines(canvas, [pts], True, (outline[2], outline[1], outline[0], 255),
                              max(1, int(round(pen_scale * ratio))), cv2.LINE_AA, _SUBPIXEL_BITS)
        if ids is not None:
            if kind == "tri":
                cv2.fillConvexPoly(ids, pts, number, cv2.LINE_8, _SUBPIXEL_BITS)
            else:
                cv2.fillPoly(ids, [pts], -1, cv2.LINE_8, _SUBPIXEL_BITS)
    if ids is not None:
        _smooth_shade(canvas, ids, smooth, ratio)
    image = QImage(canvas.data, cols, rows, cols * 4, QImage.Format.Format_ARGB32_Premultiplied)
    image.setDevicePixelRatio(ratio)
    painter.drawImage(QPointF(0.0, 0.0), image)


def _smooth_shade(canvas: np.ndarray, ids: np.ndarray, smooth: dict, ratio: float) -> None:
    """Phong shading for the triangles in `smooth`: every pixel they show lit by its own normal, blended from the
    triangle's corner normals by where in it the pixel is, with the same light as the flat triangles (ambient +
    diffuse, and the highlight and rim light when they are on). One colour per triangle showed every facet of the
    xArm's round links, however many there were. The silhouette stays anti-aliased (its fringe, just outside).

    For speed, each triangle's blend is worked out once as a plane over the screen (its normal = x*Kx + y*Ky + K1),
    and the view direction is the camera's for the whole picture: per pixel it is then a handful of sums."""
    found = np.flatnonzero(ids.ravel() >= 0)
    if found.size == 0:
        return
    width = ids.shape[1]
    rows, cols = np.divmod(found, width)
    tri = ids.ravel()[found]
    # per triangle: [x y 1] at its corners -> the corner normals, solved for the plane's coefficients
    corners = smooth["xy"].astype(np.float64) * ratio                             # (T,3,2) device pixels
    points = np.concatenate([corners, np.ones(corners.shape[:2] + (1,))], axis=2)  # (T,3,3)
    flat = np.abs(np.linalg.det(points)) < 1e-6                                     # seen edge-on: no plane
    points[flat] = np.eye(3)
    coefficients = np.linalg.solve(points, smooth["normals"].astype(np.float64))   # (T,3,3): rows x, y, 1
    coefficients[flat] = 0.0
    coefficients[flat, 2] = smooth["normals"][flat].mean(axis=1)
    k = coefficients.astype(np.float32)[tri]                                       # (P,3,3)
    x = cols.astype(np.float32)[:, None] + 0.5
    y = rows.astype(np.float32)[:, None] + 0.5
    n = x * k[:, 0] + y * k[:, 1] + k[:, 2]
    n /= np.maximum(np.sqrt(np.einsum("ij,ij->i", n, n)), 1e-6)[:, None]
    light = np.asarray(LIGHT, np.float32)
    intensity = MESH_AMBIENT + MESH_DIFFUSE * np.clip(n @ light, 0.0, None)
    lit = smooth["colours"].astype(np.float32)[tri] * intensity[:, None]
    view = np.asarray(smooth["view"], np.float32)                                  # towards the camera
    if smooth["highlights"]:
        half = view + light
        half /= np.linalg.norm(half)
        lit += (SMOOTH_SPECULAR_STRENGTH * np.clip(n @ half, 0.0, 1.0) ** SPECULAR_POWER)[:, None]
    if smooth["rim"]:
        lit += (RIM_STRENGTH * (1.0 - np.clip(n @ view, 0.0, 1.0)) ** 3)[:, None] * RIM_COLOR.astype(np.float32)
    # a pixel a smooth triangle covers is solid (the seams between its anti-aliased triangles let the background
    # through); the anti-aliased silhouette is the fringe just outside, which keeps its flat colour and coverage
    flat_canvas = canvas.reshape(-1, 4)
    flat_canvas[found, :3] = (np.clip(lit[:, ::-1], 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
    flat_canvas[found, 3] = 255


def _to_table(points: np.ndarray) -> np.ndarray:
    """Where each point's shadow falls on the table (z = 0), with the light coming from SHADOW_LIGHT."""
    light = np.asarray(SHADOW_LIGHT)
    shadow = points - (points[..., 2:3] / light[2]) * light
    shadow[..., 2] = 0.3
    return shadow


def _soft_shadows(painter: QPainter, width: int, height: int, project_many, triangles: Optional[np.ndarray],
                  boxes: list[np.ndarray]) -> None:
    """Soft shadows on the table: each part of the arm and each object is flattened onto the table along
    the light, filled into a small mask, blurred, and laid over the table as see-through black. Clipped
    to the table top, so nothing falls into the empty space around it.

    Each part is filled as its outline (convex hull), not triangle by triangle: 8 fills instead of a
    couple of thousand, and once blurred the difference doesn't show."""
    device = painter.device()
    ratio = device.devicePixelRatioF() if device is not None else 1.0
    scale = ratio * SHADOW_SCALE
    cols, rows = max(1, int(width * scale)), max(1, int(height * scale))
    mask = np.zeros((rows, cols), np.uint8)
    shift = 2                                              # quarter-pixel fixed point
    unit = scale * (1 << shift)
    casters = list(boxes)
    if triangles is not None and len(triangles):
        # One fill per part. (Not cv2.fillPoly with all the triangles in one call: it treats overlapping
        # shapes as holes, even-odd.)
        casters += [triangles[part].reshape(-1, 3)[::3] for part in robots.active().part_slices()]
    for corners in casters:
        xy, ok = project_many(_to_table(corners))
        if ok.all():
            hull = cv2.convexHull(np.round(xy * unit).astype(np.int32))
            cv2.fillConvexPoly(mask, hull, 255, cv2.LINE_8, shift)
    if not mask.any():
        return
    blur = max(1.5, 0.012 * min(cols, rows))
    soft = cv2.GaussianBlur(mask, (0, 0), blur)
    table = np.zeros_like(mask)
    tx, ty = robots.active().table_x, robots.active().table_y
    top, ok = project_many(np.array([(tx[0], ty[0], 0.0), (tx[1], ty[0], 0.0),
                                     (tx[1], ty[1], 0.0), (tx[0], ty[1], 0.0)]))
    if ok.all():
        cv2.fillPoly(table, [np.round(top * unit).astype(np.int32)], 255, cv2.LINE_AA, shift)
    alpha = (soft.astype(np.uint16) * table // 255 * int(255 * SHADOW_DARKNESS) // 255).astype(np.uint8)
    image_data = np.zeros((rows, cols, 4), np.uint8)
    image_data[:, :, 3] = alpha                           # premultiplied black: colour stays 0
    image = QImage(image_data.data, cols, rows, cols * 4, QImage.Format.Format_ARGB32_Premultiplied)
    painter.save()
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    painter.drawImage(QRectF(0.0, 0.0, width, height), image)
    painter.restore()


def arm_mesh_colours(colours: np.ndarray, reachable: bool) -> np.ndarray:
    """The real arm's materials, adjusted for this view: its near-black parts take FRAME_COLOR (dark
    slate, readable on the dark background), or the warning orange when the target is out of reach."""
    dark = colours.max(axis=1) < 0.25
    out = colours.copy()
    out[dark] = FRAME_COLOR if reachable else WARN_ORANGE
    return out


@dataclass
class ViewCamera:
    position: Vec
    forward: Vec
    right: Vec
    up: Vec
    focal: float   # in pixels


def look_at(position: Vec, target: Vec, focal: float) -> ViewCamera:
    """A camera at `position` looking at `target`, with the world's +Z as up."""
    distance = math.dist(position, target)
    forward = tuple((t - c) / distance for t, c in zip(target, position))
    right = (forward[1], -forward[0], 0.0)
    rn = math.hypot(right[0], right[1]) or 1.0
    right = (right[0] / rn, right[1] / rn, 0.0)
    up = (right[1] * forward[2] - right[2] * forward[1],
          right[2] * forward[0] - right[0] * forward[2],
          right[0] * forward[1] - right[1] * forward[0])
    return ViewCamera(position, forward, right, up, focal)  # type: ignore[arg-type]


@dataclass
class SceneHandle:
    project: Callable[[Vec], Optional[tuple[float, float, float]]]   # world point -> (x, y, depth) or None
    draw_label: Callable[..., None]                                   # (anchor, text, color, dx=, dy=)


def paint_scene(painter: QPainter, width: int, height: int, camera: ViewCamera, objects: list,
                geometry, gripper_closed: bool, font: QFont, *, show_labels: bool = True,
                show_axes: bool = True, pen_scale: float = 1.0, held_id: Optional[str] = None,
                reach_mm: Optional[float] = None, tool_rotation_deg: float = 0.0,
                center: Optional[tuple[float, float]] = None, decorations: Optional[list] = None,
                effects: Optional[SceneEffects] = None, jaw_stop_mm: Optional[float] = None) -> SceneHandle:
    """Paint the table, objects and arm over whatever background the caller has filled in.
    `pen_scale` thickens lines and text offsets for a big canvas that is later scaled down.
    `center` is where the camera's optical axis lands on the canvas (default: the middle).
    `effects`: the optional extras (see SceneEffects); None draws the plain look. `jaw_stop_mm`: closed on
    something it couldn't hold, how far apart the fingers stopped (not closed through it)."""
    fx = effects or SceneEffects()
    robot = robots.active()
    if reach_mm is None:
        reach_mm = robot.max_reach_mm
    TABLE_X, TABLE_Y = robot.table_x, robot.table_y   # noqa: N806 - this robot's table
    min_radius = robot.min_radius_mm
    cam_pos, forward, right, up, focal = (camera.position, camera.forward, camera.right, camera.up,
                                          camera.focal)
    w, h = width, height
    cx0, cy0 = center if center is not None else (w / 2, h / 2)

    def project_many(points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """(..., 3) world points -> ((..., 2) canvas points, (...) in front of the camera)."""
        rel = np.asarray(points, dtype=np.float64) - np.asarray(cam_pos)
        zc = rel @ np.asarray(forward)
        safe = np.where(zc > 5.0, zc, 5.0)
        xy = np.stack([cx0 + focal * (rel @ np.asarray(right)) / safe, cy0 - focal * (rel @ np.asarray(up)) / safe],
                      axis=-1)
        return xy, zc > 5.0

    def project(p: Vec):
        v = (p[0] - cam_pos[0], p[1] - cam_pos[1], p[2] - cam_pos[2])
        zc = v[0] * forward[0] + v[1] * forward[1] + v[2] * forward[2]
        if zc < 5.0:
            return None
        xc = v[0] * right[0] + v[1] * right[1] + v[2] * right[2]
        yc = v[0] * up[0] + v[1] * up[1] + v[2] * up[2]
        return (cx0 + focal * xc / zc, cy0 - focal * yc / zc, zc)

    def depth(p: Vec) -> float:
        v = (p[0] - cam_pos[0], p[1] - cam_pos[1], p[2] - cam_pos[2])
        return v[0] * forward[0] + v[1] * forward[1] + v[2] * forward[2]

    background_layer: list = []   # table, grid, arc, shadows: always behind the solids
    solids: list = []             # (depth, draw) sorted far to near
    smooth_tris: list = []        # batches of triangles lit pixel by pixel (add_mesh with corner normals)
    device = painter.device()
    ratio = device.devicePixelRatioF() if device is not None else 1.0   # device pixels per logical pixel

    def add_polygon(target: list, points: list[Vec], color: QColor, outline: Optional[QColor] = None,
                    sort_point: Optional[Vec] = None) -> None:
        projected = [project(p) for p in points]
        if any(q is None for q in projected):
            return
        key = depth(sort_point) if sort_point else sum(q[2] for q in projected) / len(projected)
        target.append((key, ("poly", [(q[0], q[1]) for q in projected], color.getRgb(),
                             outline.getRgb() if outline is not None else None)))

    def add_box(target: list, center: Vec, size: Vec, base: Color, outline: bool = True,
               depth_bias: float = 0.0, yaw_deg: float = 0.0) -> None:
        cx, cy, cz = center
        hx, hy, hz = size[0] / 2, size[1] / 2, size[2] / 2
        c, s = math.cos(math.radians(yaw_deg)), math.sin(math.radians(yaw_deg))
        turn = lambda v: (v[0] * c - v[1] * s, v[0] * s + v[1] * c, v[2])  # noqa: E731 - about the vertical
        faces = [  # (normal, four corners)
            ((0, 0, 1), [(-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)]),
            ((0, 0, -1), [(-hx, -hy, -hz), (-hx, hy, -hz), (hx, hy, -hz), (hx, -hy, -hz)]),
            ((1, 0, 0), [(hx, -hy, -hz), (hx, hy, -hz), (hx, hy, hz), (hx, -hy, hz)]),
            ((-1, 0, 0), [(-hx, -hy, -hz), (-hx, -hy, hz), (-hx, hy, hz), (-hx, hy, -hz)]),
            ((0, 1, 0), [(-hx, hy, -hz), (-hx, hy, hz), (hx, hy, hz), (hx, hy, -hz)]),
            ((0, -1, 0), [(-hx, -hy, -hz), (hx, -hy, -hz), (hx, -hy, hz), (-hx, -hy, hz)]),
        ]
        for normal, corners in faces:
            reach = turn((normal[0] * hx, normal[1] * hy, normal[2] * hz))
            normal, corners = turn(normal), [turn(corner) for corner in corners]
            face_center = (cx + reach[0], cy + reach[1], cz + reach[2])
            to_camera = (cam_pos[0] - face_center[0], cam_pos[1] - face_center[1], cam_pos[2] - face_center[2])
            if sum(a * b for a, b in zip(normal, to_camera)) <= 0:
                continue  # facing away
            shade = 0.5 + 0.5 * max(0.0, sum(a * b for a, b in zip(normal, LIGHT)))
            pts = [(cx + a, cy + b, cz + c) for a, b, c in corners]
            edge = qcolor(base, 255, 0.55) if outline else None
            face_base = base
            if fx.highlights:   # a flat face catches the light as one soft sheen, not a sharp spot
                length = math.sqrt(sum(v * v for v in to_camera)) or 1.0
                half = [LIGHT[k] + to_camera[k] / length for k in range(3)]
                half_len = math.sqrt(sum(v * v for v in half)) or 1.0
                sheen = max(0.0, sum(normal[k] * half[k] / half_len for k in range(3))) ** 8 * 0.3
                face_base, shade = lighter(base, sheen), shade + sheen * 0.3
            # Sorted by this FACE's own depth, not the whole box's centre: a box has real depth extent
            # (the tray floor and its near wall are at quite different distances from the camera), and
            # a single shared key made a nearby cube's top sort behind a farther part of the tray,
            # painting the wall over it -- looked like the cube had sunk into the tray.
            sort_point = face_center
            if depth_bias:
                # A held object's true depth genuinely overlaps a wall or another cube it's passing
                # near while it's mid-air, which no single-point sort can always get right (that needs
                # a real depth buffer, which this painter doesn't have). Nudging its sort point toward
                # the camera settles the tie in its favour -- it's being carried, so it should read as
                # in front of whatever it's passing over, not spliced into it.
                sort_point = (face_center[0] - forward[0] * depth_bias, face_center[1] - forward[1] * depth_bias,
                             face_center[2] - forward[2] * depth_bias)
            add_polygon(target, pts, qcolor(face_base, 255, shade), edge, sort_point=sort_point)

    def add_prism(target: list, cx: float, cy: float, radius: float, z0: float, z1: float,
                  base: Color, sides: int = 24) -> None:
        ring = [(cx + radius * math.cos(2 * math.pi * i / sides),
                 cy + radius * math.sin(2 * math.pi * i / sides)) for i in range(sides)]
        centre = (cx, cy, (z0 + z1) / 2)
        for i in range(sides):
            (ax, ay), (bx, by) = ring[i], ring[(i + 1) % sides]
            mid_angle = 2 * math.pi * (i + 0.5) / sides
            normal = (math.cos(mid_angle), math.sin(mid_angle), 0.0)
            face_mid = (cx + radius * normal[0], cy + radius * normal[1], centre[2])
            to_camera = (cam_pos[0] - face_mid[0], cam_pos[1] - face_mid[1], cam_pos[2] - face_mid[2])
            if sum(a * b for a, b in zip(normal, to_camera)) <= 0:
                continue
            shade = 0.5 + 0.5 * max(0.0, sum(a * b for a, b in zip(normal, LIGHT)))
            face = qcolor(base, 255, shade)
            add_polygon(target, [(ax, ay, z0), (bx, by, z0), (bx, by, z1), (ax, ay, z1)],
                        face, face, sort_point=face_mid)  # same-colour edge hides seams between facets
        add_polygon(target, [(x, y, z1) for x, y in ring], qcolor(base, 255, 1.0),
                    qcolor(base, 255, 0.6), sort_point=(cx, cy, z1))

    def add_ball(target: list, cx: float, cy: float, cz: float, radius: float, base: Color,
                   rings: int = 8, sides: int = 16) -> None:
        """A ball, as facets shaded by the light (the ones facing away left out)."""
        def point(i: int, j: int) -> Vec:
            polar, around = math.pi * i / rings, 2 * math.pi * j / sides
            return (cx + radius * math.sin(polar) * math.cos(around), cy + radius * math.sin(polar) * math.sin(around),
                    cz + radius * math.cos(polar))
        for i in range(rings):
            for j in range(sides):
                corners = [point(i, j), point(i, j + 1), point(i + 1, j + 1), point(i + 1, j)]
                mid = tuple(sum(c[k] for c in corners) / 4 for k in range(3))
                length = math.dist(mid, (cx, cy, cz)) or 1.0
                normal = tuple((mid[k] - (cx, cy, cz)[k]) / length for k in range(3))
                to_camera = (cam_pos[0] - mid[0], cam_pos[1] - mid[1], cam_pos[2] - mid[2])
                if sum(a * b for a, b in zip(normal, to_camera)) <= 0:
                    continue
                shade = 0.5 + 0.5 * max(0.0, sum(a * b for a, b in zip(normal, LIGHT)))
                face = qcolor(base, 255, shade)
                add_polygon(target, corners, face, face, sort_point=mid)

    def add_stroke(target: list, a: Vec, b: Vec, width_mm: float, color: QColor) -> None:
        pa, pb = project(a), project(b)
        if pa is None or pb is None:
            return
        mid_depth = (pa[2] + pb[2]) / 2
        stroke_width = max(pen_scale, width_mm * focal / mid_depth)

        def draw() -> None:
            painter.setPen(QPen(color, stroke_width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            painter.drawLine(QPointF(pa[0], pa[1]), QPointF(pb[0], pb[1]))
        target.append((mid_depth, draw))

    def add_sphere(target: list, p: Vec, radius_mm: float, base: Color) -> None:
        q = project(p)
        if q is None:
            return
        radius = max(1.5 * pen_scale, radius_mm * focal / q[2])

        def draw() -> None:
            gradient = QRadialGradient(q[0] - radius * 0.35, q[1] - radius * 0.4, radius * 1.3)
            gradient.setColorAt(0.0, qcolor(lighter(base, 0.55)))
            gradient.setColorAt(1.0, qcolor(base, 255, 0.55))
            painter.setBrush(QBrush(gradient))
            painter.setPen(QPen(qcolor(base, 255, 0.4), pen_scale))
            painter.drawEllipse(QPointF(q[0], q[1]), radius, radius)
        target.append((q[2] - radius_mm * 0.5, draw))

    def add_mesh(target: list, triangles: np.ndarray, colours: np.ndarray,
                 depth_bias: Optional[np.ndarray] = None, shading: Optional[np.ndarray] = None) -> None:
        """Triangles (N,3,3 world mm), each sorted on its own among everything else.
        Back faces are skipped; each triangle is outlined in its own colour so no seams show.
        `depth_bias` (N,) mm moves a triangle's sort key toward the camera (see add_box). `shading`: (N,3,3)
        corner normals: lit pixel by pixel (smooth_tris, _smooth_shade), round parts look round; else one colour
        each, by their own normal."""
        corner_normals = shading if shading is not None and shading.ndim == 3 else None
        if corner_normals is not None:
            shading = corner_normals.sum(axis=1)
            shading = shading / np.maximum(np.linalg.norm(shading, axis=1), 1e-9)[:, None]
        cam = np.asarray(cam_pos, dtype=np.float64)
        normals = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
        lengths = np.linalg.norm(normals, axis=1)
        keep = (lengths > 1e-9) & (np.einsum("ij,ij->i", normals, cam - triangles.mean(axis=1)) > 0)
        bias = depth_bias[keep] if depth_bias is not None else None
        rel = triangles[keep] - cam
        zc = rel @ np.asarray(forward)
        keep_near = (zc > 5.0).all(axis=1)
        rel, zc = rel[keep_near], zc[keep_near]
        keys = zc.mean(axis=1) - (bias[keep_near] if bias is not None else 0.0)
        xy = np.stack([cx0 + focal * (rel @ np.asarray(right)) / zc,
                       cy0 - focal * (rel @ np.asarray(up)) / zc], axis=-1)   # (M, 3, 2)
        fixed = _fixed_point(xy, ratio)                                        # for OpenCV, all at once
        unit = (shading[keep][keep_near] if shading is not None
                else normals[keep][keep_near] / lengths[keep][keep_near][:, None])
        shade = MESH_AMBIENT + MESH_DIFFUSE * np.clip(unit @ np.asarray(LIGHT), 0.0, None)
        lit = colours[keep][keep_near] * shade[:, None]
        if fx.rim_light or fx.highlights:
            view = -rel.mean(axis=1)                                   # triangle -> camera
            view /= np.linalg.norm(view, axis=1)[:, None]
            if fx.highlights:    # Blinn-Phong: bright where the surface turns the light straight at the camera
                half = view + np.asarray(LIGHT)
                half /= np.linalg.norm(half, axis=1)[:, None]
                lit = lit + SPECULAR_STRENGTH * np.clip(np.einsum("ij,ij->i", unit, half), 0.0, 1.0)[:, None] ** SPECULAR_POWER
            if fx.rim_light:     # surfaces seen edge-on (the outline) catch a cool back light
                facing = np.clip(np.einsum("ij,ij->i", unit, view), 0.0, 1.0)
                lit = lit + RIM_STRENGTH * ((1.0 - facing) ** 3)[:, None] * RIM_COLOR
        rgb = (np.clip(lit, 0.0, 1.0) * 255).astype(int)
        fills = [(r, g, b, 255) for r, g, b in rgb.tolist()]
        numbers = [None] * len(fills)
        if corner_normals is not None and len(fills):
            first = sum(len(batch["xy"]) for batch in smooth_tris)
            smooth_tris.append({"xy": xy, "normals": corner_normals[keep][keep_near],
                                "colours": colours[keep][keep_near]})
            numbers = list(range(first, first + len(fills)))
        target.extend((key, ("tri", points, fill, None, pts, number))
                      for key, points, fill, pts, number in zip(keys.tolist(), xy, fills, fixed, numbers))

    # ---- table ---------------------------------------------------------------
    table_center = ((TABLE_X[0] + TABLE_X[1]) / 2, 0.0, -7.0)
    add_box(background_layer, table_center, (TABLE_X[1] - TABLE_X[0], TABLE_Y[1] - TABLE_Y[0], 14.0),
            MAT_COLOR if fx.measuring_mat else (0.13, 0.2, 0.24))
    # (spacing mm, [(every mm, colour, width)] from finest to boldest): which lines, and how they look
    if fx.measuring_mat:
        spacing = 10.0
        styles = ((100, QColor(170, 230, 205, 120), 1.5), (50, QColor(150, 215, 190, 70), 1.1),
                  (10, QColor(140, 205, 180, 26), 0.8))
    else:
        spacing = 20.0
        styles = ((100, QColor(120, 175, 190, 95), 1.4), (20, QColor(120, 175, 190, 45), 1.0))

    def line_style(value: float):
        return next(s for s in styles if round(value) % s[0] == 0)

    grid_lines = []
    x = TABLE_X[0]
    while x <= TABLE_X[1] + 0.1:
        grid_lines.append(((x, TABLE_Y[0], 0.2), (x, TABLE_Y[1], 0.2), line_style(x)))
        x += spacing
    y = TABLE_Y[0]
    while y <= TABLE_Y[1] + 0.1:
        grid_lines.append(((TABLE_X[0], y, 0.2), (TABLE_X[1], y, 0.2), line_style(y)))
        y += spacing
    grid_layer: list = []
    batches: dict = {}   # one drawLines call per line style, not one call per line
    for a, b, style in grid_lines:
        pa, pb = project(a), project(b)
        if pa is not None and pb is not None:
            batches.setdefault(style[0], (style, []))[1].append(QLineF(pa[0], pa[1], pb[0], pb[1]))
    for _, ((_, colour, line_width), lines) in sorted(batches.items()):   # finest first, boldest on top
        def draw(lines=lines, colour=colour, line_width=line_width) -> None:
            painter.setPen(QPen(colour, line_width * pen_scale))
            painter.drawLines(lines)
        grid_layer.append((0.0, draw))

    if fx.measuring_mat:   # a ruler along the front and right-hand edges: numbers every 50 mm
        ruler: list = [((x, TABLE_Y[0] + 9.0, 0.3), f"{x:.0f}") for x in range(0, int(TABLE_X[1]) + 1, 50)]
        ruler += [((TABLE_X[1] - 12.0, y, 0.3), f"{y:.0f}") for y in range(int(TABLE_Y[0]) // 50 * 50 + 50, int(TABLE_Y[1]) - 19, 50)]

        def draw_ruler() -> None:
            small = QFont(font)
            small.setPointSizeF(max(6.0, font.pointSizeF() * 0.72))
            small.setBold(False)
            painter.setFont(small)
            painter.setPen(QColor(170, 230, 205, 150))
            for point, text in ruler:
                q = project(point)
                if q is not None:
                    painter.drawText(QPointF(q[0] - 8 * pen_scale, q[1] + 4 * pen_scale), text)
            ticks = [((x, TABLE_Y[0], 0.3), (x, TABLE_Y[0] + (6.0 if x % 50 else 12.0), 0.3))
                     for x in range(int(TABLE_X[0]) + 10, int(TABLE_X[1]), 10)]
            painter.setPen(QPen(QColor(170, 230, 205, 110), pen_scale))
            tick_lines = [QLineF(pa[0], pa[1], pb[0], pb[1]) for pa, pb in ((project(a), project(b)) for a, b in ticks)
                          if pa is not None and pb is not None]
            painter.drawLines(tick_lines)
        grid_layer.append((0.0, draw_ruler))

    def add_reach_arc(radius: float, color: QColor) -> None:
        points = [project((radius * math.cos(math.radians(a)), radius * math.sin(math.radians(a)), 0.4))
                  for a in range(-100, 101, 4)]
        points = [q for q in points if q is not None]

        def draw() -> None:
            painter.setPen(QPen(color, 1.6 * pen_scale, Qt.PenStyle.DashLine))
            for a, b in zip(points, points[1:]):
                painter.drawLine(QPointF(a[0], a[1]), QPointF(b[0], b[1]))
        grid_layer.append((0.0, draw))

    # The workable area is the ring between the two: nearer the base than MIN_RADIUS_MM the arm can't
    # reach down to the table (see SimRobot/DobotRobot's reach floor); farther than reach_mm (the
    # robot's own max_reach_mm, not a guess) it can't stretch at all.
    band = _reach_band(robot.key, int(round(geometry.tcp[2]))) if fx.reach_map else None
    if fx.reach_map:
        # The ring the tip can reach at its current height, within the joint limits AND the app's own
        # limits (the no-go zone by the base, the reach cap); it moves as the tip goes up and down.
        low, high = robot.joint_limits_deg["J1"]
        low, high = max(low, -180.0), min(high, 180.0)     # J1 of the xArm turns twice round
        inner = max(min_radius, band[0]) if band else min_radius
        outer = min(reach_mm, band[1]) if band else min_radius

        def ring(radius: float) -> list[Vec]:
            return [(radius * math.cos(math.radians(a)), radius * math.sin(math.radians(a)), 0.35)
                    for a in np.linspace(low, high, 61)]

        def fill(points: list[Vec], colour: QColor, edge: Optional[QColor] = None, dashed: bool = False) -> None:
            projected = [project(p) for p in points]
            if any(q is None for q in projected):
                return
            polygon = QPolygonF([QPointF(q[0], q[1]) for q in projected])

            def draw() -> None:
                painter.setBrush(QBrush(colour))
                if edge is None:
                    painter.setPen(Qt.PenStyle.NoPen)
                else:
                    painter.setPen(QPen(edge, 1.6 * pen_scale, Qt.PenStyle.DashLine if dashed else Qt.PenStyle.SolidLine))
                painter.drawPolygon(polygon)
            grid_layer.append((0.0, draw))
        # no-go: from the base out to the inner edge (red), then the workable ring (teal glow)
        fill([(0.0, 0.0, 0.35)] + ring(inner), QColor(235, 80, 70, 38), QColor(245, 110, 90, 150), dashed=True)
        if outer > inner:
            fill(ring(outer) + ring(inner)[::-1], QColor(75, 200, 185, 34), QColor(120, 230, 210, 150))
            glow = ring(inner + (outer - inner) * 0.08) + ring(outer - (outer - inner) * 0.08)[::-1]
            fill(glow, QColor(75, 200, 185, 20))
    else:
        add_reach_arc(reach_mm, QColor(170, 205, 220, 150))
        add_reach_arc(min_radius, QColor(245, 167, 66, 150))

    # ---- base ------------------------------------------------------------------
    # The real Magician's shape (magician_model.py) when its mesh files are there; otherwise a drawn
    # stand-in. The mesh includes the base, so the drawn base is only for the stand-in.
    held_size = next((o["size"] for o in objects if o["id"] == held_id), None) if held_id else None
    arm_mesh = robot.posed_mesh(geometry, tool_rotation_deg, gripper_closed,
                                min(held_size[:2]) if held_size else None, jaw_stop_mm)
    if arm_mesh is None:
        # White plinth + turret with a dark foot trim and a camera/sensor nub that turns with J1,
        # after the real Magician's base (white housing, black angled sensor module on the turret).
        base_white = (0.94, 0.94, 0.92)
        base_trim = (0.06, 0.06, 0.07)
        add_box(solids, (0.0, 0.0, 6.0), (150.0, 120.0, 12.0), base_white)
        add_prism(solids, 0.0, 0.0, 44.0, 12.0, 17.0, base_trim)
        add_prism(solids, 0.0, 0.0, 40.0, 17.0, 46.0, base_white)
        add_prism(solids, 0.0, 0.0, 34.0, 46.0, geometry.shoulder[2] - 10.0, base_white)
        base_az = math.atan2(geometry.wrist[1], geometry.wrist[0]) if math.hypot(*geometry.wrist[:2]) > 1e-6 else 0.0
        bux, buy = math.cos(base_az), math.sin(base_az)
        nub_h = geometry.shoulder[2] - 26.0
        nub_from = (34.0 * bux, 34.0 * buy, nub_h)
        nub_to = (54.0 * bux, 54.0 * buy, nub_h)
        add_stroke(solids, nub_from, nub_to, 22.0, qcolor(base_trim))

    # ---- objects and their shadows -------------------------------------------
    labels: list = []
    shadow_boxes: list[np.ndarray] = []   # soft shadows: the 8 corners of each thing that casts one
    for item in objects:
        ox, oy, oz = item["pos"]
        width_mm, depth_mm, height_mm = item["size"]
        color = lighter(item["color"], 0.28)  # the simulator's dark colours vanish on this background
        if item["shape"] == "tray":
            floor_h = 4.0
            # the floor is under everything in the tray: sorted by its middle, it came after the sides of a cube
            # standing in it at about the same distance, and was painted over the bottom cube of a stack there
            add_box(solids, (ox, oy, floor_h / 2), (width_mm, depth_mm, floor_h), color,
                    depth_bias=-max(width_mm, depth_mm))
            wall = tuple(c * 0.85 for c in color)
            # the walls stand on the tray's edges, as in the simulator (and its collision checks): they were drawn
            # 2 mm further in
            add_box(solids, (ox, oy + depth_mm / 2, height_mm / 2), (width_mm, 4.0, height_mm), wall)
            add_box(solids, (ox, oy - depth_mm / 2, height_mm / 2), (width_mm, 4.0, height_mm), wall)
            add_box(solids, (ox + width_mm / 2, oy, height_mm / 2), (4.0, depth_mm, height_mm), wall)
            add_box(solids, (ox - width_mm / 2, oy, height_mm / 2), (4.0, depth_mm, height_mm), wall)
            anchor = (ox, oy, height_mm + 4.0)
        else:
            # Held and mid-air right now: bias it to sort in front of whatever it's passing over
            # (a tray wall, another cube), instead of an arbitrary single-point tie the wrong way.
            bias = max(width_mm, depth_mm, height_mm) * 2.0 if item["id"] == held_id else 0.0
            yaw = item.get("yaw", 0.0)
            if item["shape"] == "ball":
                add_ball(solids, ox, oy, oz, width_mm / 2, color)
            elif item["shape"] == "cylinder":
                add_prism(solids, ox, oy, width_mm / 2, oz - height_mm / 2, oz + height_mm / 2, color)
            else:
                add_box(solids, (ox, oy, oz), (width_mm, depth_mm, height_mm), color, depth_bias=bias, yaw_deg=yaw)
            yc, ys = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
            corner = lambda sx, sy: (sx * width_mm / 2 * yc - sy * depth_mm / 2 * ys,  # noqa: E731
                                     sx * width_mm / 2 * ys + sy * depth_mm / 2 * yc)
            if fx.soft_shadows:
                shadow_boxes.append(np.array([(ox + corner(sx, sy)[0], oy + corner(sx, sy)[1], oz + sz * height_mm / 2)
                                              for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]))
            else:
                shadow_shift = max(0.0, oz) * 0.4
                foot = [(ox + corner(sx, sy)[0] + shadow_shift, oy + corner(sx, sy)[1] + shadow_shift * 0.9, 0.3)
                        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
                add_polygon(grid_layer, foot, QColor(0, 0, 0, 90))
            anchor = (ox, oy, oz + height_mm / 2 + 2.0)
        labels.append((anchor, item["label"], color))

    # ---- arm ---------------------------------------------------------------------
    # Black open parallelogram frame with white plastic caps, after the real Magician: the rear-arm
    # and forearm are each an outer bar (white cap / black middle / white cap) plus a thinner inner
    # bar set back toward the column, which is what actually keeps the tool pointing straight down.
    # Not pure black: reads as the same "plastic" as the real arm, but with enough luminance above
    # the viewport's own near-black background to actually be visible on it.
    frame = FRAME_COLOR if geometry.reachable else (0.55, 0.28, 0.05)  # stretched past reach: warn orange
    outline = qcolor((0.03, 0.03, 0.04))
    cap_white = (0.93, 0.93, 0.91)
    hub_color = (0.1, 0.1, 0.12) if geometry.reachable else frame
    bolt_color = (0.58, 0.58, 0.62)
    nozzle = (0.98, 0.55, 0.15) if gripper_closed else (0.29, 0.85, 0.8)
    chain = [geometry.shoulder, geometry.elbow, geometry.wrist, geometry.tool_corner, geometry.tcp]
    if not fx.soft_shadows or arm_mesh is None:
        for a, b in zip(chain, chain[1:]):  # shadow of the arm on the table
            sa = (a[0] + a[2] * 0.4, a[1] + a[2] * 0.36, 0.3)
            sb = (b[0] + b[2] * 0.4, b[1] + b[2] * 0.36, 0.3)
            add_stroke(grid_layer, sa, sb, 20.0, QColor(0, 0, 0, 70))

    if arm_mesh is not None:
        # The gripper and what it carries sort as one group: both get the held object's bias, so the
        # fingers can be in front of it or behind it by their true depth (see add_box's depth_bias).
        tool_bias = max(held_size) * 2.0 if held_size else 0.0
        colours = arm_mesh_colours(arm_mesh[1], geometry.reachable)
        if fx.gripper_glow and gripper_closed:   # the gripper glows: green holding, amber closed on nothing
            glow, amount = (GLOW_HOLDING, 0.5) if held_id else (GLOW_EMPTY, 0.35)
            tool = arm_mesh[2]
            colours[tool] = colours[tool] * (1.0 - amount) + glow * amount
        add_mesh(solids, arm_mesh[0], colours, depth_bias=np.where(arm_mesh[2], tool_bias, 0.0),
                 shading=arm_mesh[3] if len(arm_mesh) > 3 else None)
    else:
        # every arm point lies in one vertical plane (through the base rotation and straight up);
        # (ux, uy) is the horizontal direction of that plane, used to offset the frame's inner bar.
        plane_r = math.hypot(geometry.tool_corner[0], geometry.tool_corner[1])
        ux, uy = (geometry.tool_corner[0] / plane_r, geometry.tool_corner[1] / plane_r) if plane_r > 1e-6 else (1.0, 0.0)

        def in_plane_perp(a: Vec, b: Vec) -> Vec:
            ar, br = a[0] * ux + a[1] * uy, b[0] * ux + b[1] * uy
            dr, dz = br - ar, b[2] - a[2]
            length = math.hypot(dr, dz) or 1.0
            pr, pz = -dz / length, dr / length
            return (pr * ux, pr * uy, pz)

        def offset(p: Vec, perp: Vec, amount: float) -> Vec:
            return (p[0] + perp[0] * amount, p[1] + perp[1] * amount, p[2] + perp[2] * amount)

        def add_bolts(center: Vec, radius: float) -> None:
            for dz, dr in ((radius * 0.55, 0.0), (-radius * 0.55, 0.0), (0.0, radius * 0.55), (0.0, -radius * 0.55)):
                add_sphere(solids, (center[0] + ux * dr, center[1] + uy * dr, center[2] + dz), 2.4, bolt_color)

        def add_frame_link(a: Vec, b: Vec, width_mm: float, inner_offset_mm: float) -> None:
            """One Magician-style bar: white cap / black frame / white cap, plus the thinner inner bar
            and a diagonal brace that read as the arm's open parallelogram."""
            def lerp(t: float) -> Vec:
                return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)
            cap_frac = 0.32
            a_cap, b_cap = lerp(cap_frac), lerp(1.0 - cap_frac)
            add_stroke(solids, a, b, width_mm + 5.0, outline)
            add_stroke(solids, a_cap, b_cap, width_mm, qcolor(frame))
            add_stroke(solids, offset(a_cap, in_plane_perp(a, b), width_mm * 0.2),
                       offset(b_cap, in_plane_perp(a, b), width_mm * 0.2), width_mm * 0.22,
                       qcolor(lighter(frame, 0.5), 200))
            add_stroke(solids, a, a_cap, width_mm, qcolor(cap_white))
            add_stroke(solids, b, b_cap, width_mm, qcolor(cap_white))
            perp = in_plane_perp(a, b)
            a2, b2 = offset(a, perp, inner_offset_mm), offset(b, perp, inner_offset_mm)
            add_stroke(solids, a2, b2, width_mm * 0.42, qcolor(frame, 255, 0.8))
            add_stroke(solids, a, b2, width_mm * 0.16, qcolor(frame, 255, 0.65))  # diagonal brace

        def add_cable_loop(p1: Vec, p2: Vec, height_mm: float) -> None:
            segments = 8
            points = []
            for i in range(segments + 1):
                t = i / segments
                base_pt = (p1[0] + (p2[0] - p1[0]) * t, p1[1] + (p2[1] - p1[1]) * t, p1[2] + (p2[2] - p1[2]) * t)
                points.append((base_pt[0], base_pt[1], base_pt[2] + math.sin(math.pi * t) * height_mm))
            for pa, pb in zip(points, points[1:]):
                add_stroke(solids, pa, pb, 6.0, qcolor(frame, 255, 0.9))

        add_frame_link(geometry.shoulder, geometry.elbow, 30.0, 11.0)
        add_frame_link(geometry.elbow, geometry.wrist, 25.0, 9.0)
        add_sphere(solids, geometry.shoulder, 15.0, hub_color)
        add_sphere(solids, geometry.elbow, 13.0, hub_color)
        add_bolts(geometry.shoulder, 15.0)
        add_bolts(geometry.elbow, 13.0)
        loop_p1 = (geometry.shoulder[0] + (geometry.elbow[0] - geometry.shoulder[0]) * 0.76,
                  geometry.shoulder[1] + (geometry.elbow[1] - geometry.shoulder[1]) * 0.76,
                  geometry.shoulder[2] + (geometry.elbow[2] - geometry.shoulder[2]) * 0.76)
        loop_p2 = (geometry.elbow[0] + (geometry.wrist[0] - geometry.elbow[0]) * 0.24,
                  geometry.elbow[1] + (geometry.wrist[1] - geometry.elbow[1]) * 0.24,
                  geometry.elbow[2] + (geometry.wrist[2] - geometry.elbow[2]) * 0.24)
        add_cable_loop(loop_p1, loop_p2, 16.0)

        # wrist mount + a two-finger parallel gripper (not a pen holder) at the tip. Everything here also
        # gets a highlight edge, same as the main links -- against the viewport's dark background a plain
        # black-on-black bar all but disappears (that was the "gap" between the arm and the gripper).
        mount_cap = (geometry.wrist[0] + (geometry.tool_corner[0] - geometry.wrist[0]) * 0.35,
                    geometry.wrist[1] + (geometry.tool_corner[1] - geometry.wrist[1]) * 0.35,
                    geometry.wrist[2] + (geometry.tool_corner[2] - geometry.wrist[2]) * 0.35)
        add_stroke(solids, geometry.wrist, geometry.tool_corner, 20.0, outline)
        add_stroke(solids, geometry.wrist, mount_cap, 15.0, qcolor(cap_white))
        add_stroke(solids, mount_cap, geometry.tool_corner, 15.0, qcolor(frame))
        add_stroke(solids, mount_cap, geometry.tool_corner, 5.0, qcolor(lighter(frame, 0.55), 220))
        add_sphere(solids, geometry.wrist, 14.0, hub_color)
        add_bolts(geometry.wrist, 14.0)

        lat = (-uy, ux, 0.0)
        pivot = (geometry.tool_corner[0] + (geometry.tcp[0] - geometry.tool_corner[0]) * 0.55,
                geometry.tool_corner[1] + (geometry.tcp[1] - geometry.tool_corner[1]) * 0.55,
                geometry.tool_corner[2] + (geometry.tcp[2] - geometry.tool_corner[2]) * 0.55)
        add_stroke(solids, geometry.tool_corner, pivot, 11.0, outline)
        add_stroke(solids, geometry.tool_corner, pivot, 8.0, qcolor(frame))
        add_stroke(solids, geometry.tool_corner, pivot, 3.0, qcolor(lighter(frame, 0.55), 220))
        spread = 5.0 if gripper_closed else 15.0
        for sign in (1.0, -1.0):
            tip = (pivot[0] + lat[0] * spread * sign, pivot[1] + lat[1] * spread * sign, geometry.tcp[2])
            add_stroke(solids, pivot, tip, 7.0, outline)
            add_stroke(solids, pivot, tip, 5.0, qcolor(frame))
            add_stroke(solids, pivot, tip, 2.0, qcolor(lighter(frame, 0.6), 220))
            add_sphere(solids, tip, 2.6, nozzle)   # keeps the open/closed colour cue from before
        add_sphere(solids, pivot, 4.5, bolt_color)
    if decorations:   # e.g. the calibration marker on the tool: one group, drawn in the order given
        card = decorations[0][0]
        cx_, cy_, cz_ = (sum(p[i] for p in card) / len(card) for i in range(3))
        for order, (points, grey) in enumerate(decorations):
            add_polygon(solids, points, qcolor((grey, grey, grey)), None, sort_point=(cx_, cy_, cz_ + 2.0 + 0.01 * order))

    # ---- paint in order ---------------------------------------------------------
    painter.setPen(Qt.PenStyle.NoPen)
    for _, item in background_layer:
        _draw_item(painter, item, pen_scale)
    for _, item in grid_layer:
        _draw_item(painter, item, pen_scale)
    if fx.soft_shadows:
        _soft_shadows(painter, width, height, project_many, arm_mesh[0] if arm_mesh is not None else None,
                      shadow_boxes)
    ordered = sorted(solids, key=lambda entry: -entry[0])
    if all(not callable(item) and item[2][3] == 255 for _, item in ordered):
        smooth = None
        if smooth_tris:
            smooth = {name: np.concatenate([batch[name] for batch in smooth_tris])
                      for name in ("xy", "normals", "colours")}
            smooth.update(highlights=fx.highlights, rim=fx.rim_light, view=-np.asarray(forward, float))
        _raster_solids(painter, [item for _, item in ordered], width, height, pen_scale, smooth)
    else:   # the drawn stand-in arm (strokes and spheres): one QPainter call per shape
        for _, item in ordered:
            _draw_item(painter, item, pen_scale)

    painter.setFont(font)

    def draw_label(anchor: Vec, text: str, color: QColor, dx: float = 34.0, dy: float = -30.0) -> None:
        q = project(anchor)
        if q is None:
            return
        dx, dy = dx * pen_scale, dy * pen_scale
        end = QPointF(q[0] + dx, q[1] + dy)
        painter.setPen(QPen(color, 1.4 * pen_scale))
        painter.drawLine(QPointF(q[0], q[1]), end)
        text_width = painter.fontMetrics().horizontalAdvance(text)
        x = end.x() + 4 if dx >= 0 else end.x() - text_width - 4  # leftward labels end at the line
        painter.setPen(QColor(0, 0, 0, 170))
        painter.drawText(QPointF(x + 1, end.y() + 1), text)
        painter.setPen(color)
        painter.drawText(QPointF(x, end.y()), text)

    if show_labels:
        for anchor, text, color in labels:
            draw_label(anchor, text, qcolor(lighter(color, 0.35)))

    if show_axes:
        origin = (-28.0, -78.0, 1.0)
        for vec, name, hex_color in (((1, 0, 0), "+X", "#ff6b6b"), ((0, 1, 0), "+Y", "#6bdc8b"),
                                     ((0, 0, 1), "+Z", "#6ba8ff")):
            end = (origin[0] + vec[0] * 70, origin[1] + vec[1] * 70, origin[2] + vec[2] * 70)
            pa, pb = project(origin), project(end)
            if pa is None or pb is None:
                continue
            painter.setPen(QPen(QColor(hex_color), 2.4 * pen_scale))
            painter.drawLine(QPointF(pa[0], pa[1]), QPointF(pb[0], pb[1]))
            painter.drawText(QPointF(pb[0] + 5, pb[1] + 4), name)

    return SceneHandle(project=project, draw_label=draw_label)

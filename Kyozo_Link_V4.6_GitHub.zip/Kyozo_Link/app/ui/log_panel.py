"""Live application log: shows everything the app logs (twin, hardware, vision,
calibration, LLM) in one place, not just the console. Shown in the Log tab (beside Calibration) and inside the
System check window ("Show log"): the same lines in both, live, and Clear empties both.
"""
from __future__ import annotations

import logging

from PyQt6.QtCore import pyqtSignal, QObject
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget, QVBoxLayout, QTextEdit

LEVEL_COLORS = {
    logging.DEBUG: "#888888",
    logging.INFO: "#d0d0d0",
    logging.WARNING: "#e0a030",
    logging.ERROR: "#e05050",
    logging.CRITICAL: "#ff3030",
}


class QtLogSignal(QObject):
    """Logging handlers run on whatever thread logs the message; this signal
    marshals the formatted line onto the Qt event loop so appending to the
    QTextEdit is always done on the UI thread."""
    message_logged = pyqtSignal(str, int)  # formatted text, levelno


class QtLogHandler(logging.Handler):
    def __init__(self, signal: QtLogSignal):
        super().__init__()
        self.signal = signal
        self.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s",
                                             datefmt="%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            text = self.format(record)
        except Exception:  # noqa: BLE001 - never let logging crash the app
            text = record.getMessage()
        try:
            self.signal.message_logged.emit(text, record.levelno)
        except RuntimeError:
            # the window is gone (closed, or the app shutting down): it no longer shows anything, and a line logged
            # from anywhere after that raised here -- so it stops listening
            logging.getLogger().removeHandler(self)


class LogPanel(QWidget):
    """Made when the app starts and collecting from then on, shown or not: shown, it has everything since."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._signal = QtLogSignal()
        self._signal.message_logged.connect(self._append)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.document().setMaximumBlockCount(5000)   # keep the oldest lines from piling up forever
        self.text_edit.setStyleSheet("background-color: #111; font-family: Consolas, monospace;")
        layout.addWidget(self.text_edit)

        self.handler = QtLogHandler(self._signal)
        self._views: list[QTextEdit] = []    # the same log shown elsewhere too (the Log tab)

    def _append(self, text: str, levelno: int) -> None:
        color = LEVEL_COLORS.get(levelno, "#d0d0d0")
        line = f'<span style="color:{color}">{text}</span>'
        for edit in [self.text_edit, *self._views]:
            edit.append(line)

    def add_view(self) -> QTextEdit:
        """Another view of this log: everything so far, then each new line as it comes (and Clear empties it too)."""
        view = QTextEdit()
        view.setReadOnly(True)
        view.document().setMaximumBlockCount(5000)
        view.setStyleSheet(self.text_edit.styleSheet())
        view.setHtml(self.text_edit.toHtml())
        self._views.append(view)
        view.destroyed.connect(lambda _=None, v=view: self._views.remove(v) if v in self._views else None)
        return view

    def attach_to_root_logger(self, level: int = logging.INFO) -> None:
        root = logging.getLogger()
        root.addHandler(self.handler)
        if root.level > level or root.level == logging.NOTSET:
            root.setLevel(level)

    def text(self) -> str:
        return self.text_edit.toPlainText()

    def clear(self) -> None:
        for edit in [self.text_edit, *self._views]:
            edit.clear()

    def scroll_to_end(self) -> None:
        bar = self.text_edit.verticalScrollBar()
        bar.setValue(bar.maximum())


class LogTab(QWidget):
    """The Log tab: the app's log as it happens, with Copy and Clear (app.log keeps it all)."""

    def __init__(self, log: LogPanel, parent=None):
        super().__init__(parent)
        self.log = log
        layout = QVBoxLayout(self)
        row = QHBoxLayout()
        row.addWidget(QLabel("Everything the app has logged since it started (also saved in app.log)"))
        row.addStretch()
        self.copy_btn = QPushButton("Copy log")
        self.copy_btn.clicked.connect(lambda: QGuiApplication.clipboard().setText(self.log.text()))
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setToolTip("Empty this view of the log (app.log keeps it all)")
        self.clear_btn.clicked.connect(self.log.clear)
        row.addWidget(self.copy_btn)
        row.addWidget(self.clear_btn)
        layout.addLayout(row)
        self.view = log.add_view()
        layout.addWidget(self.view)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        bar = self.view.verticalScrollBar()
        bar.setValue(bar.maximum())       # opened: at the newest line

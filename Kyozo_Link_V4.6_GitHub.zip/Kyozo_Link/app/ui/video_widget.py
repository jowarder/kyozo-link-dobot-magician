"""Live camera feed widget with click-to-move support.

NOTE: polls camera.get_frame() from a QTimer on the UI thread. Fine for the
sim camera; if the real Orbbec camera's get_frame() call proves slow enough
to cause UI stutter during hardware bring-up, move this polling to a
background QThread that emits frames via a signal.
"""
from __future__ import annotations

from typing import Optional

import cv2
import numpy as np
from PyQt6.QtCore import QPointF, Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QImage, QPixmap, QMouseEvent
from PyQt6.QtWidgets import QLabel

from app.hardware.interfaces import Camera

# label colour -> overlay colour (RGB); anything else falls back to white
_OVERLAY_COLORS = {"red": (255, 107, 107), "blue": (107, 168, 255), "green": (107, 220, 139),
                   "yellow": (255, 209, 102)}


class VideoWidget(QLabel):
    pixel_clicked = pyqtSignal(int, int)  # original-resolution (u, v)

    def __init__(self, camera: Camera, fps: int = 20, detector=None, zoomable: bool = False, parent=None,
                 outline_provider=None, detections_when=None):
        """`detector`, if given, draws what it sees on the feed (boxes + names). Clicks
        and `latest_frame()` always use the untouched camera image. `zoomable` adds wheel zoom,
        drag to pan and R to reset -- for picking points precisely -- and then a click is only
        reported on release, so a drag isn't mistaken for one. `outline_provider()`: corners (camera pixels) of an
        area to outline with a dashed line (the pick area), or None. `detections_when()`: False while what the
        detector finds means nothing yet (no calibration: it can't tell the table from what stands on it, and boxed
        the arm, the paper's edges and the sheet -- the lab, 2026-10-21); then a note says so instead."""
        super().__init__(parent)
        self.camera = camera
        self._detector = detector
        self._outline_provider = outline_provider
        self._detections_when = detections_when
        self._latest_frame = None
        self._detections: list = []
        self._frame_count = 0
        self._latest_rgb: Optional[np.ndarray] = None
        self._zoomable = zoomable
        self._marks: list[dict] = []
        self._zoom = 1.0
        self._centre: Optional[tuple[float, float]] = None   # middle of the visible part, in image pixels
        self._view = (0, 0, 1, 1)                             # visible part now: x, y, width, height (image pixels)
        self._press: Optional[QPointF] = None
        self._drag_distance = 0.0
        self.setMinimumSize(320, 180)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet("background-color: #0c1824; color: #9fb4c4; border: 1px solid #23394a;")
        self.setText("Connecting to camera...")
        if zoomable:
            self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._update_frame)
        self._timer.start(int(1000 / fps))
    def _with_overlay(self, rgb: np.ndarray) -> np.ndarray:
        if self._detector is None:
            return rgb
        if self._detections_when is not None and not self._detections_when():
            shown = np.ascontiguousarray(rgb).copy()
            self._draw_outline(shown)
            note = "Not calibrated yet: objects are shown once the camera is calibrated (Calibration tab)"
            cv2.putText(shown, note, (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 4, cv2.LINE_AA)
            cv2.putText(shown, note, (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 209, 102), 1, cv2.LINE_AA)
            self._detections = []
            return shown
        if self._frame_count % getattr(self._detector, "overlay_every", 4) == 0:   # colour: ~5 Hz is plenty
            try:
                if getattr(self._detector, "needs_depth", False):
                    frame = self._latest_frame
                    self._detections = self._detector.detect(rgb, frame.depth, frame.intrinsics) if frame else []
                else:
                    self._detections = self._detector.detect(rgb)
            except Exception:  # noqa: BLE001 - an overlay must never break the feed
                self._detections = []
        self._frame_count += 1
        shown = np.ascontiguousarray(rgb).copy()
        self._draw_outline(shown)
        for det in self._detections:
            x, y, w, h = det.bbox
            color = _OVERLAY_COLORS.get(det.label.split()[0], (255, 255, 255))
            cv2.rectangle(shown, (x - 3, y - 3), (x + w + 3, y + h + 3), color, 2)
            cv2.putText(shown, det.label, (x - 3, max(14, y - 9)), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                        (0, 0, 0), 3, cv2.LINE_AA)
            cv2.putText(shown, det.label, (x - 3, max(14, y - 9)), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                        color, 1, cv2.LINE_AA)
        return shown

    def _draw_outline(self, image: np.ndarray) -> None:
        """The pick area: a dashed outline on the table (objects whose middle is outside it are left out)."""
        if self._outline_provider is None:
            return
        try:
            corners = self._outline_provider()
        except Exception:  # noqa: BLE001 - an outline must never break the feed
            corners = None
        if not corners:
            return
        colour = (255, 209, 102)
        for (x0, y0), (x1, y1) in zip(corners, corners[1:] + corners[:1]):
            length = max(1.0, float(np.hypot(x1 - x0, y1 - y0)))
            dashes = int(length // 14)
            for i in range(0, dashes + 1, 2):
                a, b = i / max(dashes, 1), min(1.0, (i + 1) / max(dashes, 1))
                cv2.line(image, (int(x0 + (x1 - x0) * a), int(y0 + (y1 - y0) * a)),
                         (int(x0 + (x1 - x0) * b), int(y0 + (y1 - y0) * b)), colour, 2, cv2.LINE_AA)
        x, y = corners[0]
        cv2.putText(image, "pick area", (int(x) + 6, int(y) - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.55, colour, 1, cv2.LINE_AA)

    def _visible_region(self, width: int, height: int) -> tuple[int, int, int, int]:
        """The part of the image being shown, as x, y, w, h -- the whole image unless zoomed in."""
        if self._zoom <= 1.0 or self._centre is None:
            return 0, 0, width, height
        view_w, view_h = width / self._zoom, height / self._zoom
        cx = min(max(self._centre[0], view_w / 2), width - view_w / 2)
        cy = min(max(self._centre[1], view_h / 2), height - view_h / 2)
        self._centre = (cx, cy)
        return int(round(cx - view_w / 2)), int(round(cy - view_h / 2)), int(round(view_w)), int(round(view_h))

    def _update_frame(self) -> None:
        if not self.isVisible():
            return  # each tab has its own feed; don't poll the camera for hidden ones
        try:
            frame = self.camera.get_frame()
        except Exception:
            return
        self._latest_rgb = frame.rgb
        self._latest_frame = frame
        shown = self._with_overlay(frame.rgb)
        self._show(shown)

    def set_marks(self, marks: list[dict]) -> None:
        """Draw markers over the picture: dicts with `u`, `v` (camera pixels), `kind` ("expected"
        or "found") and an optional `label`. An empty list clears them."""
        self._marks = list(marks)
        if self._latest_rgb is not None:
            self._show(self._with_overlay(self._latest_rgb))

    def _draw_marks(self, image: np.ndarray) -> np.ndarray:
        image = np.ascontiguousarray(image).copy()
        for mark in self._marks:
            if mark.get("kind") == "poly":  # an outline (the watcher's ghost of where a cube or a zone goes): `points`
                points = np.array([[int(round(u)), int(round(v))] for u, v in mark["points"]], np.int32)
                colour = tuple(int(c) for c in mark.get("colour", (235, 240, 245)))
                if mark.get("fill"):            # (0-255: how strongly it is filled in its colour)
                    layer = image.copy()
                    cv2.fillPoly(layer, [points], colour, cv2.LINE_AA)
                    alpha = float(mark["fill"]) / 255.0
                    cv2.addWeighted(layer, alpha, image, 1.0 - alpha, 0.0, dst=image)
                cv2.polylines(image, [points], True, (10, 24, 34), mark.get("width", 2) + 2, cv2.LINE_AA)
                cv2.polylines(image, [points], True, colour, mark.get("width", 2), cv2.LINE_AA)
                if mark.get("label"):
                    at = (int(points[:, 0].min()), int(points[:, 1].min()) - 6)
                    cv2.putText(image, str(mark["label"]), (at[0] + 1, at[1] + 1), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                (10, 24, 34), 2, cv2.LINE_AA)
                    cv2.putText(image, str(mark["label"]), at, cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour, 1, cv2.LINE_AA)
                continue
            centre = (int(round(mark["u"])), int(round(mark["v"])))
            kind = mark.get("kind")
            colour = (235, 240, 245)
            if kind == "arrow":         # a calibration spot's miss: from the spot, the way it was missed (enlarged)
                tip = (int(round(mark["u2"])), int(round(mark["v2"])))
                colour = (255, 209, 102)
                cv2.circle(image, centre, 4, colour, -1, cv2.LINE_AA)
                cv2.arrowedLine(image, centre, tip, (10, 24, 34), 4, cv2.LINE_AA, tipLength=0.25)
                cv2.arrowedLine(image, centre, tip, colour, 2, cv2.LINE_AA, tipLength=0.25)
            elif kind == "found":
                cv2.line(image, (centre[0] - 9, centre[1] - 9), (centre[0] + 9, centre[1] + 9), (255, 107, 107), 2)
                cv2.line(image, (centre[0] - 9, centre[1] + 9), (centre[0] + 9, centre[1] - 9), (255, 107, 107), 2)
            elif kind == "sample":      # a calibration point that was clicked
                cv2.circle(image, centre, 5, (10, 24, 34), -1)
                cv2.circle(image, centre, 4, (75, 184, 173), -1)
            elif kind == "selected":    # the point selected in the list
                colour = (255, 209, 102)
                cv2.circle(image, centre, 14, (10, 24, 34), 5, cv2.LINE_AA)
                cv2.circle(image, centre, 14, colour, 2, cv2.LINE_AA)
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    cv2.line(image, (centre[0] + 9 * dx, centre[1] + 9 * dy), (centre[0] + 21 * dx, centre[1] + 21 * dy),
                             colour, 2, cv2.LINE_AA)
            else:
                cv2.circle(image, centre, 10, (107, 220, 139), 2)
            if mark.get("label"):
                position = (centre[0] + (17 if kind == "selected" else 12), centre[1] - 8)
                cv2.putText(image, str(mark["label"]), (position[0] + 1, position[1] + 1), cv2.FONT_HERSHEY_SIMPLEX,
                            0.6, (10, 24, 34), 2, cv2.LINE_AA)
                cv2.putText(image, str(mark["label"]), position, cv2.FONT_HERSHEY_SIMPLEX, 0.6, colour, 1, cv2.LINE_AA)
        return image

    def _show(self, shown: np.ndarray) -> None:
        if self._marks:
            shown = self._draw_marks(shown)
        h, w, _ = shown.shape
        x, y, view_w, view_h = self._visible_region(w, h)
        self._view = (x, y, view_w, view_h)
        if (view_w, view_h) != (w, h):
            shown = np.ascontiguousarray(shown[y:y + view_h, x:x + view_w])
        image = QImage(shown.data, shown.shape[1], shown.shape[0], 3 * shown.shape[1], QImage.Format.Format_RGB888)
        pixmap = QPixmap.fromImage(image).scaled(
            self.width(), self.height(), Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.setPixmap(pixmap)

    def _pixel_at(self, position: QPointF) -> Optional[tuple[float, float]]:
        """The camera-image pixel under a widget position, or None if it's outside the picture."""
        pixmap = self.pixmap()
        if self._latest_rgb is None or pixmap is None or pixmap.isNull():
            return None
        pix_w, pix_h = pixmap.width(), pixmap.height()
        click_x = position.x() - (self.width() - pix_w) / 2
        click_y = position.y() - (self.height() - pix_h) / 2
        if not (0 <= click_x < pix_w and 0 <= click_y < pix_h):
            return None
        x, y, view_w, view_h = self._view
        return x + click_x / pix_w * view_w, y + click_y / pix_h * view_h

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if self._zoomable:
            self._press = event.position()
            self._drag_distance = 0.0
            self.setFocus()
            return
        point = self._pixel_at(event.position())
        if point is not None:
            self.pixel_clicked.emit(int(point[0]), int(point[1]))

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if not self._zoomable or self._press is None:
            return
        delta = event.position() - self._press
        self._press = event.position()
        self._drag_distance += abs(delta.x()) + abs(delta.y())
        pixmap = self.pixmap()
        if self._drag_distance >= 5.0 and self._zoom > 1.0 and self._centre is not None \
                and pixmap is not None and not pixmap.isNull():
            per_pixel = self._view[2] / pixmap.width()   # image pixels per screen pixel
            self._centre = (self._centre[0] - delta.x() * per_pixel, self._centre[1] - delta.y() * per_pixel)
            if self._latest_rgb is not None:
                self._show(self._with_overlay(self._latest_rgb))

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if not self._zoomable or self._press is None:
            return
        was_click = self._drag_distance < 5.0
        self._press = None
        if was_click and event.button() == Qt.MouseButton.LeftButton:
            point = self._pixel_at(event.position())
            if point is not None:
                self.pixel_clicked.emit(int(point[0]), int(point[1]))

    def wheelEvent(self, event) -> None:
        if not self._zoomable or self._latest_rgb is None:
            return
        point = self._pixel_at(event.position())
        pixmap = self.pixmap()
        if point is None or pixmap is None or pixmap.isNull():
            return
        h, w, _ = self._latest_rgb.shape
        fraction_x = (event.position().x() - (self.width() - pixmap.width()) / 2) / pixmap.width()
        fraction_y = (event.position().y() - (self.height() - pixmap.height()) / 2) / pixmap.height()
        self._zoom = max(1.0, min(8.0, self._zoom * (1.15 ** (event.angleDelta().y() / 120.0))))
        view_w, view_h = w / self._zoom, h / self._zoom
        # keep the point under the cursor where it is
        self._centre = (point[0] - fraction_x * view_w + view_w / 2, point[1] - fraction_y * view_h + view_h / 2)
        self._show(self._with_overlay(self._latest_rgb))

    def keyPressEvent(self, event) -> None:
        if self._zoomable and event.key() == Qt.Key.Key_R:
            self._zoom, self._centre = 1.0, None
            if self._latest_rgb is not None:
                self._show(self._with_overlay(self._latest_rgb))

    def latest_frame(self) -> Optional[np.ndarray]:
        return self._latest_rgb
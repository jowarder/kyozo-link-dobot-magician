"""The Model tab: everything about each prompt, top to bottom -- every model turn in seven stages, what the app
did with each instruction (its checks, every arm move and every joint), and checks at the end.

The model only ever writes instructions (text); the app checks them and moves the arm. The page keeps the two
apart: blue for the model, grey for the app. Each stage says where its information comes from (measured by
Ollama, worked out by the app, or the model's own reasoning). See app/llm/trace.py.
"""
from __future__ import annotations

import html
import json
import logging
import re
import time
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import (QApplication, QFileDialog, QFrame, QHBoxLayout, QLabel, QPushButton, QTextBrowser,
                             QVBoxLayout, QWidget)

from app.hardware.gripper import SQUARE_MM
from app import robots
from app.twin.kinematics import JOINT_LIMITS_DEG
from app.ui.settings_panel import ToggleSwitch

logger = logging.getLogger(__name__)

SHOWN = 30          # prompts on the page at once; all of them are in prompt_logs/
TEXT, MUTED, ACCENT = "#d7e6f0", "#8fa8ba", "#4bb8ad"
OK, WARN, BAD = "#7fe0b0", "#f5a742", "#ff8a8a"
MODEL_BG, MODEL_HEAD, APP_BG, APP_HEAD, CARD = "#12283a", "#18384d", "#101c28", "#162634", "#152636"
JOINT_NAMES = {"J1": "base", "J2": "rear arm", "J3": "forearm", "J4": "wrist"}


def _e(value) -> str:
    return html.escape(str(value))


def _span(text: str, colour: str, bold: bool = False) -> str:
    return f"<span style='color:{colour};{'font-weight:600;' if bold else ''}'>{text}</span>"


def _tag(text: str, colour: str) -> str:
    return f"<span style='color:{colour};'>[{_e(text)}]</span>"


def problems(trace: dict) -> list[str]:
    """What's worth a look in this prompt (for the "Only problems" filter and the summary's tags)."""
    end = trace.get("end") or {}
    found = []
    if end.get("refusals"):
        found.append(f"{end['refusals']} refused")
    if end.get("guesses"):
        found.append(f"{len(end['guesses'])} guess" + ("es" if len(end["guesses"]) > 1 else ""))
    if end.get("ambiguities"):
        found.append("ambiguous")
    if (end.get("goal") or {}).get("status") == "not met":
        found.append("goal not met")
    if end.get("reply") and not end["reply"].get("ok"):
        found.append("reply not backed up")
    if end.get("loops"):
        found.append("looping")
    for turn in trace.get("turns", []):
        for call in turn.get("calls", []):
            if call.get("app") and call["app"].get("stopped"):
                found.append(f"stopped ({call['app']['stopped']})")
    return found


# ---- the page ---------------------------------------------------------------------------------------------------------------
def render(traces: list[dict], standalone: bool = False) -> str:
    """The page. `standalone`: with its own dark background and font, to open in a browser (Save)."""
    body = "".join(render_trace(t) for t in traces) or (
        f"<p style='color:{MUTED};'>Nothing yet. Send a prompt on the Prompt tab: every step the model takes, and "
        "everything the app does with it, appears here.</p>")
    look = "background-color:#0f1c29; font-family:Segoe UI, sans-serif; " if standalone else ""
    return f"<html><body style='{look}color:{TEXT}; font-size:9.5pt;'>{body}</body></html>"


def render_trace(trace: dict) -> str:
    out = [_summary(trace)]
    for turn in trace.get("turns", []):
        out.append(_turn(trace, turn))
    if trace.get("finished"):
        out.append(_end(trace))
    else:
        out.append(f"<p style='color:{WARN};'>… still running</p>")
    return "".join(out) + "<hr/>"


def _table(rows: str, bg: str, border: str = "#2a4459") -> str:
    return (f"<table width='100%' cellspacing='0' cellpadding='5' style='background-color:{bg}; "
            f"border:1px solid {border}; margin-top:6px;'>{rows}</table>")


def _summary(trace: dict) -> str:
    end = trace.get("end") or {}
    setup = trace.get("setup") or {}
    info = trace.get("model_info") or {}
    budget = end.get("budget") or {}
    goal = (end.get("goal") or {}).get("status")
    tags = [_tag(p, WARN) for p in problems(trace)]
    if goal == "met":
        tags.append(_tag("goal met", OK))
    elif goal == "not checked" and trace.get("finished"):
        tags.append(_tag("goal not checked", MUTED))
    meta = [f"{_e(trace.get('started', ''))}" + (f" · took {trace['took_s']:.0f} s" if trace.get("took_s") else ""),
            f"{_e(trace.get('model'))}" + (f" ({_e(info['parameters'])}, {_e(info.get('compression'))})"
                                           if info.get("parameters") else "")
            + f" · temperature {trace.get('temperature')} · reasoning {'on' if trace.get('reasoning') else 'off'}",
            f"{_e(setup.get('mode', '?'))} mode" + (f" · scene {_e(setup['scene'])}" if setup.get("scene") else "")
            + (" · step by step" if setup.get("step_by_step") else "")]
    if budget:
        meta.append(f"{len(trace.get('turns', []))} model turns · {budget.get('steps')} of {budget.get('limit')} steps · "
                    f"model {budget.get('model_s', 0):.1f} s · arm {budget.get('robot_s', 0):.1f} s · "
                    f"{budget.get('tokens_read', 0):,} tokens read, {budget.get('tokens_written', 0):,} written")
    u = trace.get("understood") or {}
    understood = (f"Read as: <b>{_e(u.get('task'))}</b>"
                  + (f" · object <b>\"{_e(u['object'])}\"</b>" if u.get("object") else "")
                  + (f" · destination <b>\"{_e(u['destination'])}\"</b>" if u.get("destination") else "")
                  + (f" · expected: {_e(', '.join(u['expected']))}" if u.get("expected") else "")
                  + "".join(f"<br>{_span('⚠ ' + _e(n), WARN)}" for n in u.get("notes", []))
                  + f" {_span('(the app' + chr(39) + 's reading)', MUTED)}")
    rows = (f"<tr><td><span style='font-size:11pt; font-weight:600;'>\"{_e(trace.get('prompt'))}\"</span>"
            f" &nbsp; {' '.join(tags)}</td></tr>"
            f"<tr><td style='color:{MUTED};'>{' &nbsp;·&nbsp; '.join(meta)}</td></tr>"
            f"<tr><td>{understood}</td></tr>")
    return _table(rows, CARD)


def _stage(number: str, name: str, source: str, text: str) -> str:
    return (f"<tr><td width='120' valign='top'><b>{number} {name}</b><br>"
            f"<span style='color:{MUTED}; font-size:8pt;'>{source}</span></td>"
            f"<td valign='top' style='color:{TEXT};'>{text}</td></tr>")


def _turn(trace: dict, turn: dict) -> str:
    stats = turn.get("stats") or {}
    receive = turn.get("receive") or {}
    calls = turn.get("calls") or []
    instruction = (" · ".join(f"{_e(c['name'])} {_e(json.dumps(c['args'], ensure_ascii=False))}" for c in calls)
                   if calls else "reply: " + _e((turn.get("reply") or "")[:90]))
    title = ("App · turn " + str(turn["number"]) + ": the look before the model's first answer"
             if turn.get("by") == "the app" else "Model · turn " + str(turn["number"]))
    head = (f"<tr><td colspan='2' style='background-color:{MODEL_HEAD};'>{_span(title, ACCENT, True)}"
            f" &nbsp; <code>{instruction}</code> &nbsp; {_span(_e(turn.get('time', '')), MUTED)}</td></tr>")
    # 1 receive
    parts = receive.get("parts_estimated") or {}
    read = receive.get("tokens_read")
    memory = ""
    limit = receive.get("memory_limit")
    if read and limit:
        memory = f" · memory {100 * read / limit:.0f}% of {limit:,}"
    elif read:
        memory = " · memory limit: Ollama's default"
    receive_text = ((f"{read:,} tokens" if read else "tokens not reported")
                    + (f" (+{receive['new']:,} new since the last turn)" if receive.get("new") else "")
                    + (f" · read in {stats['read_s']:.1f} s" if stats.get("read_s") else "") + memory
                    + f"<br>{_span('parts (estimated): ' + ' · '.join(f'{k} {v:,}' for k, v in parts.items()), MUTED)}")
    rows = [head, _stage("1", "Receive", "measured", receive_text)]
    # 2 understand
    done = turn.get("progress") or []
    expected = (trace.get("understood") or {}).get("expected") or []
    rows.append(_stage("2", "Understand", "app", ("done so far: " + ", ".join(_e(d) for d in done) if done
                                                  else "nothing done yet")
                       + (f" · task shape: {_e(' → '.join(expected))}" if expected else "")))
    if calls:
        for call in calls:
            rows.extend(_call_stages(call, stats, turn))
    else:
        rows.append(_stage("3", "Find objects", "app", _span("nothing new to find", MUTED)))
        rows.append(_stage("4", "Options", "app", "another action, or stop and reply · chose: <b>stop and reply</b>"))
        rows.append(_stage("5", "Choose", "answer", "<b>finish</b>, no further instruction" + _reasoning(turn)))
        rows.append(_stage("6", "Fill in", "checks", _reply_line(trace)))
        rows.append(_stage("7", "Answer", "measured", f"\"{_e(turn.get('reply'))}\"" + _answer_figures(stats, turn)))
    out = _table("".join(rows), MODEL_BG, "#3a6f7a")
    for call in calls:
        if call.get("app"):
            out += _app(call)
    return out


def _call_stages(call: dict, stats: dict, turn: dict) -> list[str]:
    rows = []
    if call["matches"]:
        lines = []
        for match in call["matches"]:
            cells = "; ".join(f"{_e(r['candidate'])}: name {r['name']}, colour {r['colour']}, kind {_e(r['kind'])}, "
                              f"{r['role']} → " + (_span(r["verdict"], OK) if r["verdict"] == "exact" else
                                                   _span(r["verdict"], WARN) if r["verdict"] == "partial" else
                                                   _span("no", MUTED))
                              for r in match["rows"][:4])
            lines.append(f"\"{_e(match['phrase'])}\" → <b>{_e(match['best'] or 'nothing matches')}</b>"
                         + (_span(" (a guess)", WARN) if match["guess"] else "") + f"<br>{_span(cells, MUTED)}")
        find = "<br>".join(lines)
    elif call["name"] == "list_objects":
        find = _span("not yet: it hasn't looked at the table", MUTED)
    else:
        find = _span("no words to match for this action", MUTED)
    rows.append(_stage("3", "Find objects", "app", find))
    opts = call["options"]
    rows.append(_stage("4", "Options", "app",
                       f"{len(opts['open'])} of {opts['total']} actions possible · closed: {_e(', '.join(opts['closed']))} "
                       f"({_e(opts['why_closed'])})" + (f" · {_e(call['fits_task'])}" if call.get("fits_task") else "")))
    rows.append(_stage("5", "Choose", "answer + rule",
                       f"<b>{_e(call['name'])}</b>" + (f", following: {_e(call['rule'])}" if call.get("rule") else "")
                       + _reasoning(turn)))
    fills = "; ".join(f"{_e(f['field'])} = <b>{_e(json.dumps(f['value'], ensure_ascii=False))}</b>, from {_e(f['from'])}"
                      for f in call["fills"]) or "no values needed"
    checks = call["checks"]
    passed = sum(1 for c in checks if c["ok"])
    failed = [c for c in checks if not c["ok"]]
    check_text = (_span(f"checks {passed}/{len(checks)} ✓", OK) if not failed else
                  _span(f"checks {passed}/{len(checks)}", WARN) + " · " +
                  "; ".join(_span("✗ " + _e(c["check"]) + ": " + _e(c["detail"]), WARN) for c in failed))
    rows.append(_stage("6", "Fill in", "answer + checks", f"{fills}<br>{check_text}"))
    raw = json.dumps({"name": call["name"], "arguments": call["raw_args"]}, ensure_ascii=False)
    rows.append(_stage("7", "Answer", "measured", f"<code>{_e(raw)}</code>" + _answer_figures(stats, turn)))
    return rows


def _reasoning(turn: dict) -> str:
    if turn.get("reasoning"):
        return f"<br><i>\"{_e(turn['reasoning'][:700])}\"</i> {_span('(its reasoning)', MUTED)}"
    return ""


def _answer_figures(stats: dict, turn: dict) -> str:
    bits = []
    if stats.get("tokens_written") is not None:
        bits.append(f"{stats['tokens_written']} tokens written")
    if stats.get("stop_reason"):
        bits.append("finished" if stats["stop_reason"] == "stop" else f"stopped: {_e(stats['stop_reason'])}")
    split = []
    for key, name in (("load_s", "load"), ("read_s", "read"), ("write_s", "write")):
        if stats.get(key):
            split.append(f"{name} {stats[key]:.1f}")
    bits.append(f"decided in {turn.get('decided_s', 0):.1f} s" + (f" ({' · '.join(split)})" if split else ""))
    return "<br>" + _span(" · ".join(bits), MUTED)


def _reply_line(trace: dict) -> str:
    reply = (trace.get("end") or {}).get("reply")
    if not reply:
        return _span("checked when the prompt ends", MUTED)
    return _span("reply is true ✓: " + _e(reply["detail"]), OK) if reply["ok"] else _span("⚠ " + _e(reply["detail"]), WARN)


# ---- the app's part ---------------------------------------------------------------------------------------------------------
def _robot_of(joints: dict):
    """The robot a recorded move was made by: the xArm 6 has J5 and J6 (a log from either robot can be opened)."""
    return robots.profile("xarm6" if "J6" in joints else "dobot_magician")


def _joint_words(before: dict, after: dict) -> str:
    said = []
    for joint in _robot_of(before).joint_names:
        change = after[joint] - before[joint]
        if abs(change) < 0.5:
            continue
        amount = f"{abs(change):.1f}°"
        if "J6" in before:
            said.append({"J1": f"base turns {amount} {'left' if change > 0 else 'right'}",
                         "J2": f"shoulder tilts {amount}", "J3": f"elbow bends {amount}",
                         "J4": f"forearm turns {amount}", "J5": f"wrist tilts {amount}",
                         "J6": f"tool turns {amount}"}[joint])
            continue
        said.append({"J1": f"base turns {amount} {'left' if change > 0 else 'right'}",
                     "J2": f"rear arm tilts {amount} {'forward' if change > 0 else 'back'}",
                     "J3": f"forearm tips {amount} {'down' if change > 0 else 'up'}",
                     "J4": f"wrist turns {amount}"}[joint])
    return " · ".join(said) or "no joint changes"


def _gauge(joint: str, before: float, after: float, limits: dict = JOINT_LIMITS_DEG) -> str:
    low, high = limits[joint]
    span = high - low
    a, b = (before - low) / span * 100, (after - low) / span * 100
    left, width = max(0.0, min(a, b)), max(1.0, abs(b - a))
    right = max(0.0, 100 - left - width)
    cells = ""
    if left > 0.5:
        cells += f"<td width='{left:.0f}%' style='background-color:#23394a;'></td>"
    cells += f"<td width='{width:.0f}%' style='background-color:{ACCENT if abs(b - a) >= 0.5 else '#7fa8a3'};'></td>"
    if right > 0.5:
        cells += f"<td width='{right:.0f}%' style='background-color:#23394a;'></td>"
    return f"<table width='100%' cellspacing='0' cellpadding='0' height='7'><tr>{cells}</tr></table>"


def _move_rows(move: dict) -> str:
    target = move.get("target") if move["kind"] in ("move", "home") else None
    where = f" → ({target[0]:.0f}, {target[1]:.0f}, {target[2]:.0f})" if target else ""
    route = f" · {move['route']}" if move.get("route") else ""
    error = f" · {_span('failed: ' + _e(move['error']), BAD)}" if move.get("error") else ""
    seconds = f" · {move.get('seconds', 0.0):.1f} s"
    title = f"<b>{_e(move['kind'])}{where}</b>{_span(route + seconds, MUTED)}{error}"
    before, after = move.get("joints_before"), move.get("joints_after")
    if move["kind"] != "move" or not before or not after:
        body = _span("no joint moves: only the gripper's air valve" if "gripper" in move["kind"] else
                     "joint angles not available", MUTED)
        return f"<tr><td colspan='3'>{title}<br>{body}</td></tr>"
    rows = f"<tr><td colspan='3'>{title}<br>{_span(_joint_words(before, after), TEXT)}</td></tr>"
    robot = _robot_of(before)
    names = JOINT_NAMES if robot.key == "dobot_magician" else robot.joint_labels
    for joint in robot.joint_names:
        change = after[joint] - before[joint]
        rows += (f"<tr><td width='110' style='color:{MUTED};'>{joint} {names[joint]}</td>"
                 f"<td>{_gauge(joint, before[joint], after[joint], robot.joint_limits_deg)}</td>"
                 f"<td width='170' align='right' style='font-family:Consolas,monospace;'>"
                 f"{before[joint]:.1f}° → {after[joint]:.1f}°"
                 + (f" ({change:+.1f})" if abs(change) >= 0.05 else "") + "</td></tr>")
    if move.get("tightest_on_path"):
        joint, margin = move["tightest_on_path"]
        rows += (f"<tr><td colspan='3' style='color:{MUTED};'>closest to a limit along the way: {joint} "
                 f"{names.get(joint, '')}, {margin:.1f}° to spare</td></tr>")
    return rows


def _app(call: dict) -> str:
    app = call["app"]
    head_bits = [_span("App", TEXT, True)]
    if app.get("stopped"):
        head_bits.append(_span(f"stopped {app['stopped']}: nothing was done", WARN))
    elif app["refused"]:
        head_bits.append(_span("refused the instruction: the arm didn't move", WARN))
    if app.get("target_from"):
        head_bits.append(f"target from {_e(app['target_from'])}")
    safety = app.get("safety") or []
    if safety:
        head_bits.append("reach checked: " + " ".join(
            _span(("✓ " if s["ok"] else "✗ ") + f"({s['at'][0]}, {s['at'][1]}, {s['at'][2]})", OK if s["ok"] else WARN)
            for s in safety))
    rows = f"<tr><td colspan='3' style='background-color:{APP_HEAD};'>{' · '.join(head_bits)}</td></tr>"
    if app["refused"] and app.get("reason"):
        rows += f"<tr><td colspan='3'>{_span('Why: ' + _e(app['reason']), WARN)}</td></tr>"
    rows += _grip_row(app)
    for move in app.get("moves") or []:
        rows += _move_rows(move)
    foot = []
    if app.get("moves"):
        foot.append(f"joint angles {_e(app['joint_source'])}")
        if app.get("largest_joint_move"):
            joint, change = app["largest_joint_move"]
            foot.append(f"largest move {joint} {JOINT_NAMES.get(joint, '')} {change:+.1f}°")
        if app.get("closest_to_limit"):
            joint, margin = app["closest_to_limit"][:2]
            foot.append(f"closest to a limit {joint} {JOINT_NAMES.get(joint, '')}, {margin:.1f}° to spare")
    after = []
    if app.get("holding_after") is not None or app.get("arm_after"):
        after.append(f"holding {_e(app.get('holding_after') or 'nothing')}")
    if app.get("arm_after"):
        x, y, z = app["arm_after"]
        after.append(f"arm at ({x:.0f}, {y:.0f}, {z:.0f})")
    rows += (f"<tr><td colspan='3' style='background-color:{APP_HEAD};'>"
             + (_span(" · ".join(foot + after), MUTED) + "<br>" if foot or after else "")
             + f"Replied to the model: <b>\"{_e(app['result'][:260])}\"</b></td></tr>")
    return (f"<table width='96%' align='right' cellspacing='0' cellpadding='5' style='background-color:{APP_BG}; "
            f"border:1px solid #2a4459; margin-top:4px;'>{rows}</table>"
            f"<p style='color:{MUTED}; font-size:8pt; margin:2px 0 0 30px;'>↓ the model reads the reply</p>")


TIGHT_MM = 2.0   # less room than this between the object and the open fingers: worth a look


def _grip_row(app: dict) -> str:
    """The two-finger gripper's part: the object's measured size, which way the fingers were turned and how much
    room there was, how deep they closed; or why it couldn't be gripped. And, putting down, any turn on the way."""
    grip, release, angle = app.get("grip"), app.get("release"), app.get("angle")
    parts = []
    if angle:
        if angle.get("refused"):
            parts.append(_span("Angle", TEXT, True) + " · " + _span(
                f"the {_e(angle['object'])}'s turn kept changing between pictures (by up to {angle['spread_deg']:.0f}°): "
                "not picked", WARN))
        else:
            parts.append(_span("Angle", TEXT, True) + f" · the {_e(angle['object'])}'s turn read from {angle['looks']} "
                         f"pictures, within {angle['spread_deg']:.1f}° of each other"
                         + (" (looked again: the first ones disagreed)" if angle.get("again") else ""))
    packing = app.get("packing")
    if packing:
        planned = "; ".join(f"the {_e(p['object'])} {'on the ' + _e(p['on']) if p.get('on') else 'on the floor'} at "
                            f"({p['at'][0]}, {p['at'][1]}), long side at {p['turned_to']:.0f}°" for p in packing["planned"])
        parts.append(_span("Plan", TEXT, True) + f" · into the {_e(packing['place'])}, biggest first: " + (planned or "nothing fits"))
        if packing.get("left_out"):
            parts.append(_span("Left out", TEXT, True) + " · " + _span("; ".join(
                f"the {_e(label)}: {_e(why)}" for label, why in packing["left_out"]), WARN))
    if grip:
        size = grip.get("footprint")
        if not size:
            measured = f"no outline of the {_e(grip['object'])} from the camera"
        elif size[1] - size[0] <= SQUARE_MM:     # every side the same: say how it is turned, within a quarter turn
            measured = (f"camera measured the {_e(grip['object'])} {size[0]:.0f} × {size[1]:.0f} mm, square, "
                        f"turned {(size[2] + 45.0) % 90.0 - 45.0:+.0f}°")
        else:
            measured = (f"camera measured the {_e(grip['object'])} {size[0]:.0f} × {size[1]:.0f} mm, long side at "
                        f"{size[2]:.0f}°")
        if grip.get("refused"):
            parts.append(_span("Gripper", TEXT, True) + f" · {measured} · " + _span(_e(grip["refused"]), WARN))
        else:
            tight = grip.get("across_mm") and grip.get("spare_mm", 99) < TIGHT_MM
            parts.append(_span("Gripper", TEXT, True) + f" · {measured} · "
                         + _span(_e(grip.get("note", "")), WARN if tight else TEXT)
                         + (" · " + _span("a tight fit: the camera or calibration being a little off could make the "
                                          "fingers land on it", WARN) if tight else ""))
            if grip.get("wrist"):
                parts.append(_span("Wrist", TEXT, True) + " · " + _e(grip["wrist"]))
    if release:
        turned = release.get("turned", 0.0)
        parts.append(_span("Gripper", TEXT, True) + " · " + (
            f"kept the object's turn while carrying it (r {release['r']:.0f}°)" if not turned else
            f"turned the object {turned:+.0f}° on the way: the wrist couldn't hold its turn there, and turned this "
            "much it looks the same"))
    return "".join(f"<tr><td colspan='3'>{p}</td></tr>" for p in parts)


def _end(trace: dict) -> str:
    end = trace.get("end") or {}
    goal = end.get("goal") or {}
    reply = end.get("reply") or {}
    rows = [f"<tr><td><b>Checks at the end</b> &nbsp; {_span('the model said: ' + chr(34) + _e(trace.get('final_message', '')[:200]) + chr(34), MUTED)}</td></tr>"]
    colour = OK if goal.get("status") == "met" else WARN if goal.get("status") == "not met" else MUTED
    rows.append(f"<tr><td>{_span('Goal ' + _e(goal.get('status', '?')), colour, True)} · {_e(goal.get('detail', ''))}</td></tr>")
    if reply:
        rows.append(f"<tr><td>{_span('Reply true ✓' if reply['ok'] else 'Reply not backed up ⚠', OK if reply['ok'] else WARN, True)}"
                    f" · {_e(reply['detail'])}</td></tr>")
    for guess in end.get("guesses", []):
        rows.append(f"<tr><td>{_span('Guess ⚠', WARN, True)} · {_e(guess)}</td></tr>")
    for note in end.get("ambiguities", []):
        rows.append(f"<tr><td>{_span('Ambiguous ⚠', WARN, True)} · {_e(note)}</td></tr>")
    if end.get("refusals"):
        rows.append(f"<tr><td>{_span(str(end['refusals']) + ' refused', WARN, True)} · "
                    + "; ".join(f"{_e(r['refused'])} → {_e(r['then'])}" for r in end.get("recoveries", [])) + "</td></tr>")
    if end.get("loops"):
        rows.append(f"<tr><td>{_span('Looping ⚠', WARN, True)} · repeated: {_e(', '.join(end['loops']))}</td></tr>")
    if not end.get("refusals") and not end.get("loops"):
        rows.append(f"<tr><td>{_span('No refusals, no loops ✓', OK, True)}</td></tr>")
    joints = end.get("joints") or {}
    if joints.get("moves"):
        closest = joints.get("closest")
        rows.append(f"<tr><td><b>Joints</b> · {joints['moves']} arm moves"
                    + (f" · tightest: {closest[0]} {JOINT_NAMES.get(closest[0], '')}, {closest[1]:.1f}° from its limit"
                       if closest else "") + "</td></tr>")
    budget = end.get("budget") or {}
    if budget:
        rows.append(f"<tr><td><b>Budget</b> · {budget['steps']} of {budget['limit']} steps · model {budget['model_s']:.1f} s"
                    f" · arm {budget['robot_s']:.1f} s · {budget['tokens_read']:,} tokens read</td></tr>")
    return _table("".join(rows), CARD)


# ---- the fingers and wrist: the fingers angle check and the rotation pick test --------------------------------------------
def wrist_html(model, test: Optional[dict], used: bool) -> str:
    """What the fingers angle check measured (hardware/wrist.py), whether picks use it, and the last rotation pick test."""
    if model is None:
        head = (_span("Fingers and wrist", TEXT, True) + " · " + _span(
            "no fingers angle check with this calibration: picks use only the fingers' angle from the calibration. "
            "Run it on the Calibration tab, after a cube calibration.", MUTED))
    else:
        note = " · " + _span(_e(model.mount_note), WARN) if model.mount_note else ""
        state = (_span("used for every pick", OK) + note if used else _span(
            "not used for picks" + (": " + _e("; ".join(model.problems)) if model.problems else
                                    " (made with another fingers' angle)"), WARN))
        details = (f"offset {model.offset_deg:+.1f}° · gain {model.gain:.3f} (turns {model.gain * 100:.1f}% of what it "
                   f"is told) · backlash {model.backlash_deg:.1f}° · scatter {model.scatter_deg:.1f}° · "
                   f"{model.samples} put-downs")
        made = ", ".join(x for x in (
            f"measured {_e(model.measured_at)}" if model.measured_at else "",
            f"{model.cube_mm:.0f} mm cube" if model.cube_mm else "",
            f"{_e(model.depth_preset)} depth preset" if model.depth_preset else "") if x)
        head = _span("Fingers and wrist", TEXT, True) + f" · {details} · {state}" + (
            f"<br>{_span(made, MUTED)}" if made else "")
    if test:
        sides = ", ".join(f"from {k} {v:+.1f}°" for k, v in (test.get("by_side") or {}).items())
        spread = f", spread {test['spread_deg']:.1f}°" if test.get("spread_deg") is not None else ""
        good = test["worst_deg"] <= 3.0 and not test.get("missed")
        head += ("<br>" + _span("Last rotation pick test", TEXT, True)
                 + f" ({'correction on' if test.get('corrected') else 'correction off'}, {_e(test.get('measured_at', ''))}) · "
                 + _span(f"fingers {test['mean_deg']:.1f}° off on average, worst {test['worst_deg']:.1f}°{spread}",
                         OK if good else WARN)
                 + f" · held {test['held']} of {test['rounds']}" + (f", {test['missed']} missed" if test.get("missed") else "")
                 + (f" · {sides}" if sides else ""))
    return head


class WristPlot(QWidget):
    """The fingers angle check's put-downs: how far the wrist really was from where it was told (degrees, up), against
    the angle it was told (across); from below in teal, from above in orange, with the fitted lines."""
    BELOW, ABOVE = QColor(ACCENT), QColor(WARN)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.model = None
        self.setFixedSize(220, 110)
        self.setToolTip("The fingers angle check: how far the wrist really turned from where it was told (up), "
                        "against the angle told (across, -40 to +40°). Teal: approached from below; orange: from "
                        "above. The gap between the lines is the backlash; their slope, the gain.")

    def set_model(self, model) -> None:
        self.model = model
        self.setVisible(model is not None and bool(model.points))
        self.update()

    def paintEvent(self, event) -> None:
        if self.model is None or not self.model.points:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        box = QRectF(26, 6, self.width() - 32, self.height() - 22)
        painter.fillRect(self.rect(), QColor(CARD))
        errors = [real - told for told, _, real in self.model.points]
        span = max(3.0, max(abs(e) for e in errors) * 1.2)

        def at(told: float, error: float) -> QPointF:
            return QPointF(box.left() + (told + 45.0) / 90.0 * box.width(),
                           box.center().y() - error / span * box.height() / 2.0)
        painter.setPen(QPen(QColor(MUTED), 1))
        painter.drawLine(at(-45, 0), at(45, 0))
        painter.drawText(QRectF(0, box.top() - 4, 24, 12), int(Qt.AlignmentFlag.AlignRight), f"+{span:.0f}°")
        painter.drawText(QRectF(0, box.bottom() - 8, 24, 12), int(Qt.AlignmentFlag.AlignRight), f"-{span:.0f}°")
        painter.drawText(QRectF(box.left(), box.bottom() + 2, box.width(), 12), int(Qt.AlignmentFlag.AlignCenter),
                         "wrist told -40° … +40°")
        m = self.model
        for side, colour in ((-1, self.BELOW), (1, self.ABOVE)):
            painter.setPen(QPen(colour, 1.5))
            painter.drawLine(at(-42, m.real_wrist(-42, side) + 42), at(42, m.real_wrist(42, side) - 42))
            painter.setBrush(colour)
            for told, s, real in m.points:
                if s == side:
                    painter.drawEllipse(at(told, real - told), 2.5, 2.5)
        painter.end()


# ---- the tab ----------------------------------------------------------------------------------------------------------------
class ModelTab(QWidget):
    def __init__(self, logs_dir: Path, parent=None):
        super().__init__(parent)
        self.logs_dir = Path(logs_dir)
        self.traces: list[dict] = []
        layout = QVBoxLayout(self)
        bar = QHBoxLayout()
        title = QLabel("<b>Model</b> — what the model decided, and what the app did with each instruction")
        self.count = QLabel()
        self.count.setStyleSheet(f"color: {MUTED};")
        self.only_problems = ToggleSwitch()
        self.only_problems.setToolTip("Show only prompts with something worth a look: refused steps, guesses, "
                                      "an ambiguous prompt, a goal not met, a reply not backed up, a loop")
        self.only_problems.toggled.connect(lambda _on: self.refresh())
        only_label = QLabel("Only problems")
        copy_btn = QPushButton("Copy")
        copy_btn.setToolTip("Copy the page as text")
        copy_btn.clicked.connect(self.copy)
        save_btn = QPushButton("Save")
        save_btn.setToolTip("Save the page as a web page you can open in a browser")
        save_btn.clicked.connect(self.save_dialog)
        clear_btn = QPushButton("Clear")
        clear_btn.setToolTip("Clear the page (every prompt stays saved in the prompt_logs folder)")
        clear_btn.clicked.connect(self.clear)
        bar.addWidget(title)
        bar.addWidget(self.count)
        bar.addStretch()
        bar.addWidget(self.only_problems)
        bar.addWidget(only_label)
        for button in (copy_btn, save_btn, clear_btn):
            bar.addWidget(button)
        layout.addLayout(bar)
        self.wrist_box = QFrame()             # the fingers angle check: above every prompt (it is about every pick)
        self.wrist_box.setStyleSheet(f"QFrame {{ background: {CARD}; border-radius: 4px; }}")
        wrist_row = QHBoxLayout(self.wrist_box)
        wrist_row.setContentsMargins(8, 6, 8, 6)
        self.wrist_label = QLabel()
        self.wrist_label.setWordWrap(True)
        self.wrist_label.setTextFormat(Qt.TextFormat.RichText)
        self.wrist_label.setStyleSheet(f"color: {TEXT}; background: transparent;")
        self.wrist_plot = WristPlot()
        wrist_row.addWidget(self.wrist_label, stretch=1)
        wrist_row.addWidget(self.wrist_plot)
        layout.addWidget(self.wrist_box)
        self.set_wrist(None, None, used=False)
        self.page = QTextBrowser()
        self.page.setOpenExternalLinks(False)
        layout.addWidget(self.page, stretch=1)
        self.refresh()

    def set_wrist(self, model, test: Optional[dict], used: bool) -> None:
        """The fingers angle check saved with the calibration (a WristModel or None), the last rotation pick test (its
        saved dict or None), and whether picks use the check now."""
        self.wrist_label.setText(wrist_html(model, test, used))
        self.wrist_plot.set_model(model)

    def update_trace(self, trace: dict) -> None:
        """A prompt's record, new or updated (called after every turn while it runs)."""
        key = (trace.get("started"), trace.get("prompt"))
        if self.traces and (self.traces[-1].get("started"), self.traces[-1].get("prompt")) == key:
            self.traces[-1] = trace
        else:
            self.traces.append(trace)
        if trace.get("finished"):
            self._save_json(trace)
        self.refresh()

    def visible_traces(self) -> list[dict]:
        shown = [t for t in self.traces if not self.only_problems.isChecked() or problems(t)]
        return shown[-SHOWN:]

    def refresh(self) -> None:
        bar = self.page.verticalScrollBar()
        at_bottom = bar.value() >= bar.maximum() - 20
        self.page.setHtml(render(self.visible_traces()))
        n = len(self.traces)
        self.count.setText(f"{n} prompt{'s' if n != 1 else ''} this session")
        if at_bottom:
            bar.setValue(bar.maximum())

    def copy(self) -> None:
        QApplication.clipboard().setText(self.page.toPlainText())

    def save_dialog(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save the Model page", str(self.logs_dir / "model_page.html"),
                                              "Web page (*.html)")
        if path:
            self.save_to(Path(path))

    def save_to(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(render(self.visible_traces(), standalone=True), encoding="utf-8")

    def clear(self) -> None:
        self.traces.clear()
        self.refresh()

    def _save_json(self, trace: dict) -> None:
        try:
            self.logs_dir.mkdir(parents=True, exist_ok=True)
            slug = re.sub(r"[^a-z0-9]+", "_", str(trace.get("prompt", "")).lower()).strip("_")[:40] or "prompt"
            stamp = time.strftime("%Y%m%d_%H%M%S")
            (self.logs_dir / f"{stamp}_{slug}.json").write_text(json.dumps(trace, indent=1, ensure_ascii=False),
                                                                encoding="utf-8")
        except OSError as exc:
            logger.warning("Could not save the prompt's record: %s", exc)

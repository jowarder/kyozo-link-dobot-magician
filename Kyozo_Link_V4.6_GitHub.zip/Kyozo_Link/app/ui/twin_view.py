"""Interactive 3D view of the simulated workspace (demo mode), drawn with Qt.

Drawn here rather than by PyBullet's renderer so it can be crisp and styled: dark theme,
grid table, axes, name labels, the tool contact point (TCP), a reach map, and a camera you
move with the mouse. It only reads state (object positions from the world, arm geometry
from the sim robot); the simulated *camera* that feeds the detector is separate.

What it shows is set in the Settings window (display_settings.py): each effect and helper can be
switched on or off, and the view redraws as soon as one changes.
"""
from __future__ import annotations

import logging
import math
import time
from collections import deque
from pathlib import Path
from typing import Callable, Optional

import numpy as np
from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (QBrush, QColor, QFont, QImage, QLinearGradient, QPainter, QPen, QPolygonF,
                         QRadialGradient)
from PyQt6.QtWidgets import QHBoxLayout, QPushButton, QWidget

from app.hardware import motion
from app import robots
from app.twin.kinematics import joint_angles
from app.ui.display_settings import DisplaySettings
from app.ui.scene_painter import SceneEffects, ViewCamera, look_at, paint_scene
from app.ui.worker import CallableWorker

logger = logging.getLogger(__name__)

DEFAULT_YAW, DEFAULT_PITCH, DEFAULT_DIST = -38.0, 30.0, 720.0
DEFAULT_TARGET = (140.0, 0.0, 75.0)
# name -> (yaw, pitch, distance, target): the view buttons
VIEWS = {
    "3D": (DEFAULT_YAW, DEFAULT_PITCH, DEFAULT_DIST, DEFAULT_TARGET),
    "Top": (180.0, 88.0, 820.0, (150.0, 0.0, 0.0)),     # from above, the robot's front (+X) at the top
    "Front": (0.0, 12.0, 760.0, (120.0, 0.0, 110.0)),   # looking back at the robot from in front of it
    "Side": (-90.0, 12.0, 760.0, (120.0, 0.0, 110.0)),  # from the robot's right
}
AUTO_ROTATE_DEG_PER_TICK = 0.25
DETECTIONS_EVERY_S = 1.0
STATUS_COLOURS = {"ok": QColor("#6bdc8b"), "near": QColor("#f5a742"), "over": QColor("#ff6b6b")}
LABEL_COLOURS = {"red": QColor(255, 107, 107), "blue": QColor(107, 168, 255), "green": QColor(107, 220, 139),
                 "yellow": QColor(255, 209, 102)}
HOLO = QColor(120, 230, 255)   # the ghost arm and the path preview
PLAN = QColor(255, 196, 90)    # step-by-step: the move waiting for your Go


class TwinView(QWidget):
    table_clicked = pyqtSignal(float, float)  # (x, y) in mm on the table, from a click (not a drag)

    def __init__(self, world, robot, fps: int = 30, parent=None, settings: Optional[DisplaySettings] = None,
                 camera_view: Optional[Callable[[], Optional[tuple]]] = None,
                 detections_source: Optional[Callable[[], list]] = None,
                 screenshots_dir: Optional[Path] = None):
        """`camera_view()`: (4x4 camera-to-robot transform in mm, intrinsics) as the calibration has it, for
        the camera cone. `detections_source()`: [(label, (x, y, z) top centre, confidence[, footprint])] -- what
        the camera finds, for "What the camera sees"; called off the UI thread."""
        super().__init__(parent)
        self.world = world
        self.robot = robot
        self.settings = settings or DisplaySettings()
        self.camera_view = camera_view
        self.detections_source = detections_source
        self.screenshots_dir = Path(screenshots_dir) if screenshots_dir is not None else Path("screenshots")
        self.setMinimumSize(360, 280)
        self.setMouseTracking(False)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self._reset_camera()
        self._drag_pos: Optional[QPointF] = None
        self._drag_button = None
        self._drag_distance = 0.0
        self._marker: Optional[tuple[float, float, float]] = None  # (x, y, time it expires)
        self._trail: deque = deque(maxlen=160)  # recent tool-tip positions
        self._last_key = None        # what the scene looked like at the last redraw
        self._toast: Optional[tuple[str, float]] = None   # (message, time it disappears)
        self._detections: list = []
        self._detections_at = 0.0
        self._detections_worker: Optional[CallableWorker] = None
        self._backdrops: dict = {}   # the studio glow and darkened corners, drawn once per size/view
        self._plan = None            # step-by-step: where the next step will take the tip, before you say Go
        self._hint_height = 16.0     # the help line at the bottom: taller when it wraps onto a second line

        self._buttons = QWidget(self)
        row = QHBoxLayout(self._buttons)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(4)
        style = ("QPushButton { color: #cfe3ee; background: rgba(8, 18, 28, 190); border: 1px solid #2c4a5c; "
                 "border-radius: 4px; padding: 2px 8px; } QPushButton:hover { background: rgba(40, 80, 100, 220); }")
        self.view_buttons: dict[str, QPushButton] = {}
        for name in VIEWS:
            button = QPushButton(name)
            button.setStyleSheet(style)
            button.setToolTip(f"{name} view")
            button.clicked.connect(lambda _=False, n=name: self.set_view(n))
            row.addWidget(button)
            self.view_buttons[name] = button
        self.screenshot_button = QPushButton("Save image")
        self.screenshot_button.setStyleSheet(style)
        self.screenshot_button.setToolTip("Save this view as a picture in the screenshots folder")
        self.screenshot_button.clicked.connect(self.save_screenshot)
        row.addSpacing(8)
        row.addWidget(self.screenshot_button)
        self._apply_settings()
        self.settings.changed.connect(self._apply_settings)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(int(1000 / fps))

    # ---- settings ------------------------------------------------------------------------------
    def _apply_settings(self) -> None:
        for button in self.view_buttons.values():
            button.setVisible(self.settings["view_buttons"])
        self.screenshot_button.setVisible(self.settings["screenshot_button"])
        self._buttons.adjustSize()
        self._place_buttons()
        if not self.settings["tip_trail"]:
            self._trail.clear()
        if not self.settings["camera_detections"]:
            self._detections = []
        self.update()

    def show_plan(self, target) -> None:
        """Step-by-step mode: draw the route to `target` (a Pose) and a ghost arm there; None clears it."""
        self._plan = target
        self.update()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._place_buttons()

    def _place_buttons(self) -> None:
        """Bottom left, just above the help line: clear of the joint panel (top right) at any width."""
        self._buttons.move(10, max(30, int(self.height() - self._buttons.height() - self._hint_height - 14)))

    # ---- camera ---------------------------------------------------------------
    def _reset_camera(self) -> None:
        self.set_view("3D", redraw=False)

    def set_view(self, name: str, redraw: bool = True) -> None:
        yaw, pitch, dist, target = VIEWS[name]
        scale = robots.active().view_scale       # a bigger arm, seen from further out
        self.yaw, self.pitch, self.dist = yaw, pitch, dist * scale
        self.target = [v * scale for v in target]
        if redraw:
            self.update()

    def _camera(self):
        yaw, pitch = math.radians(self.yaw), math.radians(self.pitch)
        position = (self.target[0] + self.dist * math.cos(pitch) * math.cos(yaw),
                    self.target[1] + self.dist * math.cos(pitch) * math.sin(yaw),
                    self.target[2] + self.dist * math.sin(pitch))
        view = look_at(position, tuple(self.target), 1.0)
        return position, view.forward, view.right, view.up

    def _tick(self) -> None:
        """Redraw only when the scene changed: the arm's real shape is the costly part to draw, and
        the view used to redraw it 30 times a second even when nothing moved. Dragging, zooming and
        the settings ask for a redraw themselves; a fading marker or message, or auto-rotate, keeps
        it animating."""
        if not self.isVisible():
            return
        if self.settings["auto_rotate"] and self._drag_pos is None:
            self.yaw = (self.yaw + AUTO_ROTATE_DEG_PER_TICK) % 360.0
            self.update()
        if (self.settings["camera_detections"] and self.detections_source is not None
                and self._detections_worker is None and time.monotonic() - self._detections_at > DETECTIONS_EVERY_S):
            self._refresh_detections()
        geometry, gripper_closed = self.robot.arm_state()
        key = (tuple((o["id"], o["pos"], o.get("yaw")) for o in self.world.snapshot()), geometry.tcp, geometry.elbow,
               geometry.reachable, gripper_closed, getattr(self.robot, "held_object", None),
               self.robot.get_pose().r, getattr(self.robot, "motion", None), getattr(self.robot, "jaw_stop_mm", None),
               self._overlay_key())
        if key != self._last_key or self._marker is not None or self._toast is not None:
            self._last_key = key
            self.update()

    def _overlay_key(self) -> tuple:
        """The extra outlines as they are now (a change -- the watcher's zones drawn again after a run -- is a redraw,
        though nothing moved)."""
        overlay = getattr(self, "overlay_provider", None)
        if overlay is None:
            return ()
        try:
            return tuple((o.get("label"), tuple(o.get("colour", ())), o.get("fill"), o.get("width"),
                          tuple(tuple(pt) for pt in o["points"])) for o in overlay() or [])
        except Exception:  # noqa: BLE001 - an outline it can't read is just not compared
            return ()

    def _refresh_detections(self) -> None:
        self._detections_at = time.monotonic()
        worker = CallableWorker(self.detections_source)
        self._detections_worker = worker

        def done(result) -> None:
            self._detections_worker = None
            if self.settings["camera_detections"]:
                self._detections = list(result or [])
                self.update()

        def failed(message: str) -> None:
            self._detections_worker = None
            logger.info("What the camera sees: not available (%s)", message)
        worker.finished_ok.connect(done)
        worker.failed.connect(failed)
        worker.start()

    # ---- screenshot -------------------------------------------------------------------------------
    def save_screenshot(self) -> Optional[Path]:
        """The view as a PNG in the screenshots folder (without the buttons)."""
        try:
            self.screenshots_dir.mkdir(parents=True, exist_ok=True)
            path = self.screenshots_dir / time.strftime("twin_%Y%m%d_%H%M%S.png")
            self._buttons.hide()
            try:
                saved = self.grab().save(str(path))
            finally:
                self._buttons.show()
            if not saved:
                raise OSError("the picture could not be written")
        except OSError as exc:
            self._toast = (f"Could not save the image: {exc}", time.monotonic() + 4.0)
            self.update()
            return None
        logger.info("Saved the 3D view to %s", path)
        self._toast = (f"Saved {path.parent.name}/{path.name}", time.monotonic() + 3.0)
        self.update()
        return path

    # ---- mouse ----------------------------------------------------------------
    def _table_point(self, sx: float, sy: float) -> Optional[tuple[float, float]]:
        """The point on the table (z = 0) under a screen position, or None if it's sky."""
        cam_pos, forward, right, up = self._camera()
        focal = 1.25 * min(self.width(), self.height())
        a, b = (sx - self.width() / 2) / focal, -(sy - self.height() / 2) / focal
        direction = tuple(forward[i] + right[i] * a + up[i] * b for i in range(3))
        if direction[2] >= -1e-6:
            return None
        t = -cam_pos[2] / direction[2]
        return cam_pos[0] + t * direction[0], cam_pos[1] + t * direction[1]

    def mousePressEvent(self, event) -> None:
        self._drag_pos = event.position()
        self._drag_button = event.button()
        self._drag_distance = 0.0

    def mouseReleaseEvent(self, event) -> None:
        was_click = (self._drag_pos is not None and self._drag_distance < 5.0
                     and event.button() == Qt.MouseButton.LeftButton)
        self._drag_pos = None
        if not was_click:
            return
        point = self._table_point(event.position().x(), event.position().y())
        table_x, table_y = robots.active().table_x, robots.active().table_y
        if point is not None and table_x[0] <= point[0] <= table_x[1] and table_y[0] <= point[1] <= table_y[1]:
            self._marker = (point[0], point[1], time.monotonic() + 1.8)
            self.table_clicked.emit(point[0], point[1])

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_R:
            self._reset_camera()
            self._trail.clear()
            self.update()

    def mouseMoveEvent(self, event) -> None:
        if self._drag_pos is None:
            return
        dx = event.position().x() - self._drag_pos.x()
        dy = event.position().y() - self._drag_pos.y()
        self._drag_distance += abs(dx) + abs(dy)
        self._drag_pos = event.position()
        if self._drag_button == Qt.MouseButton.LeftButton:
            if self.settings["auto_rotate"] and self._drag_distance > 5.0:
                self.settings.set("auto_rotate", False)    # grabbing the view stops the turning
            self.yaw -= dx * 0.35
            self.pitch = max(6.0, min(85.0, self.pitch + dy * 0.35))
        else:
            _, _, right, up = self._camera()
            scale = self.dist / (1.25 * min(self.width(), self.height()))
            for i in range(3):
                self.target[i] += (-dx * right[i] + dy * up[i]) * scale
        self.update()

    def wheelEvent(self, event) -> None:
        self.dist = max(300.0, min(2200.0 * robots.active().view_scale,
                                  self.dist * (0.9 ** (event.angleDelta().y() / 120.0))))
        self.update()

    # ---- drawing --------------------------------------------------------------
    def paintEvent(self, event) -> None:
        # PyQt ends the whole app, without a word, on an error in here: log it and keep going instead
        try:
            self._paint(event)
        except Exception:  # noqa: BLE001
            if not getattr(self, "_paint_failed", False):
                logger.exception("The 3D view couldn't be drawn")
            self._paint_failed = True

    def _paint(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        s = self.settings

        background = QLinearGradient(0, 0, 0, h)
        background.setColorAt(0.0, QColor("#0c1824"))
        background.setColorAt(1.0, QColor("#182c3c"))
        painter.fillRect(self.rect(), QBrush(background))

        objects = self.world.snapshot()
        geometry, gripper_closed = self.robot.arm_state()

        cam_pos, forward, right, up = self._camera()
        camera = ViewCamera(cam_pos, forward, right, up, focal=1.25 * min(w, h))
        if s["studio_background"]:
            self._draw_backdrop_glow(painter, camera, w, h)
        font = QFont(self.font())
        font.setPointSize(10)
        font.setBold(True)
        held_id = getattr(self.robot, "held_object", None)
        pose = self.robot.get_pose()   # also needed below for the status panel, regardless of the toggle
        scene = paint_scene(painter, w, h, camera, objects, geometry, gripper_closed, font,
                            show_labels=s["labels"], held_id=held_id,
                            reach_mm=getattr(self.robot, "max_reach_mm", None) or 300.0,
                            tool_rotation_deg=pose.r, effects=SceneEffects.from_settings(s),
                            jaw_stop_mm=getattr(self.robot, "jaw_stop_mm", None))
        # No calibration marker card here: on a real arm it's only stuck on while calibrating, so it
        # is drawn only in the Calibration tab's camera view, where the demo's automatic calibration uses it.
        project = scene.project
        tcp = geometry.tcp

        if s["camera_cone"]:
            self._draw_camera_cone(painter, project)
        if s["camera_detections"]:
            self._draw_detections(painter, project, font)
        overlay = getattr(self, "overlay_provider", None)   # extra outlines on the table (the study's watcher)
        if overlay is not None:
            self._draw_outlines(painter, project, font, overlay())
        moving = getattr(self.robot, "motion", None)
        if moving is None and self._plan is not None:     # waiting for your Go: what that step will do
            here = self.robot.get_pose()
            self._draw_path(painter, project, here, self._plan, colour=PLAN)
            self._draw_ghost(painter, project, camera, self._plan, colour=PLAN)
        if moving is not None and s["path_preview"]:
            self._draw_path(painter, project, *moving)
        if moving is not None and s["ghost_target"]:
            self._draw_ghost(painter, project, camera, moving[1])
        if s["height_line"]:
            self._draw_height_line(painter, project, tcp, font)
        if s["joint_gauges"]:
            self._draw_joint_arcs(painter, project, geometry, pose.r)
        if s["gripper_glow"] and gripper_closed:
            self._draw_gripper_halo(painter, project, camera, tcp, holding=held_id is not None)

        # ---- overlays: where the last click asked the arm to go, tip trail and ring, text ------
        if self._marker is not None:
            mx, my, expires = self._marker
            remaining = expires - time.monotonic()
            if remaining <= 0:
                self._marker = None
            else:  # fades out
                alpha = int(255 * min(1.0, remaining / 0.8))
                target_ring = [project((mx + 14 * math.cos(t), my + 14 * math.sin(t), 0.6))
                               for t in [i * math.pi / 12 for i in range(25)]]
                if all(q is not None for q in target_ring):
                    painter.setBrush(Qt.BrushStyle.NoBrush)
                    painter.setPen(QPen(QColor(255, 255, 255, alpha), 2.0, Qt.PenStyle.DashLine))
                    painter.drawPolyline(QPolygonF([QPointF(q[0], q[1]) for q in target_ring]))

        if s["tip_trail"]:
            if not self._trail or math.dist(self._trail[-1], tcp) > 1.0:
                self._trail.append(tcp)
            self._draw_trail(painter, project)
        if s["labels"]:
            ring = [project((tcp[0] + 10 * math.cos(t), tcp[1] + 10 * math.sin(t), tcp[2] + 0.5))
                    for t in [i * math.pi / 12 for i in range(25)]]
            if all(q is not None for q in ring):
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.setPen(QPen(QColor("#ffd166"), 2.2))
                painter.drawPolyline(QPolygonF([QPointF(q[0], q[1]) for q in ring]))
            facing = math.radians(pose.r)  # which way the end effector is turned on the table (r = J1 + J4)
            centre_px = project((tcp[0], tcp[1], tcp[2] + 0.5))
            tick_px = project((tcp[0] + 19 * math.cos(facing), tcp[1] + 19 * math.sin(facing), tcp[2] + 0.5))
            if centre_px is not None and tick_px is not None:
                painter.setPen(QPen(QColor("#ffd166"), 2.2))
                painter.drawLine(QPointF(centre_px[0], centre_px[1]), QPointF(tick_px[0], tick_px[1]))

            painter.setFont(font)
            # opposite side to the cube labels, so the TCP label doesn't collide when it's over a cube
            scene.draw_label(tcp, "TCP", QColor("#ffd166"), dx=-38.0, dy=-30.0)

        if s["studio_background"]:
            painter.drawImage(0, 0, self._backdrop("vignette", w, h, (w / 2, h / 2)))

        small = QFont(self.font())
        small.setPointSize(9)
        painter.setFont(small)
        painter.setPen(QColor(150, 175, 195))
        # ("click to move" only where a click does move it: not in the watcher, where nobody moves the arm by hand)
        clicks = self.receivers(self.table_clicked) > 0
        hint = "   ".join((["Click table: move arm there"] if clicks else []) + [
            "Drag: rotate", "Right-drag: pan", "Wheel: zoom", "R: reset view",
            "Teal ring: where the tip can reach at this height" if s["reach_map"]
            else "Dashed arcs: the workable ring between them"])
        # wraps onto more lines when the view is narrow, instead of running off the edge
        flags = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom) | int(Qt.TextFlag.TextWordWrap)
        needed = painter.boundingRect(QRectF(12, 0, max(40, w - 24), 400), flags, hint).height()
        painter.drawText(QRectF(12, h - 8 - needed, max(40, w - 24), needed), flags, hint)
        if abs(needed - self._hint_height) > 0.5:
            self._hint_height = needed
            QTimer.singleShot(0, self._place_buttons)     # keep the view buttons just above it
        painter.setPen(QColor(215, 230, 240))
        painter.drawText(QPointF(12, 20),
                         f"TCP  x {tcp[0]:.0f}   y {tcp[1]:.0f}   z {tcp[2]:.0f} mm")
        if not geometry.reachable:
            painter.setFont(font)
            painter.setPen(QColor("#f5a742"))
            painter.drawText(QPointF(12, 40), "Target out of reach (approximate limits)")
        if s["joint_panel"]:
            if s["joint_gauges"]:
                self._draw_gauge_panel(painter, geometry, gripper_closed, pose.r, objects)
            else:
                self._draw_status_panel(painter, geometry, gripper_closed, pose.r, objects)
        if self._toast is not None:
            self._draw_toast(painter, small)
        painter.end()

    # ---- the helpers, each on its own -------------------------------------------------------------
    def _draw_backdrop_glow(self, painter: QPainter, camera: ViewCamera, w: int, h: int) -> None:
        """A soft light behind the robot, so it stands in a pool of light rather than on flat dark."""
        centre = _project_with(camera, w, h, (60.0, 0.0, 120.0))
        cx, cy = (centre[0], centre[1]) if centre is not None else (w / 2, h / 2)
        painter.drawImage(0, 0, self._backdrop("glow", w, h, (round(cx / 6) * 6, round(cy / 6) * 6)))

    def _backdrop(self, kind: str, w: int, h: int, centre: tuple[float, float]) -> QImage:
        """A full-size soft gradient is slow to paint every frame, so each is drawn once into an image and
        reused until the view's size (or, for the glow, where the robot is on screen) changes."""
        key = (kind, w, h, centre)
        image = self._backdrops.get(key)
        if image is None:
            if len(self._backdrops) > 6:
                self._backdrops.clear()
            image = QImage(w, h, QImage.Format.Format_ARGB32_Premultiplied)
            image.fill(Qt.GlobalColor.transparent)
            gradient = QRadialGradient(centre[0], centre[1], max(w, h) * (0.55 if kind == "glow" else 0.75))
            if kind == "glow":
                gradient.setColorAt(0.0, QColor(60, 110, 135, 70))
                gradient.setColorAt(1.0, QColor(60, 110, 135, 0))
            else:
                gradient.setColorAt(0.55, QColor(0, 0, 0, 0))
                gradient.setColorAt(1.0, QColor(0, 0, 0, 150))
            p = QPainter(image)
            p.fillRect(0, 0, w, h, QBrush(gradient))
            p.end()
            self._backdrops[key] = image
        return image

    def _draw_trail(self, painter: QPainter, project) -> None:
        points = [project(p) for p in self._trail]
        painter.setBrush(Qt.BrushStyle.NoBrush)
        for i in range(1, len(points)):  # where the tip has been, fading with age: a soft glow and a bright core
            a, b = points[i - 1], points[i]
            if a is None or b is None:
                continue
            age = i / len(points)
            painter.setPen(QPen(QColor(255, 190, 80, int(55 * age)), 7.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            painter.drawLine(QPointF(a[0], a[1]), QPointF(b[0], b[1]))
            painter.setPen(QPen(QColor(255, 225, 140, int(30 + 190 * age)), 1.8))
            painter.drawLine(QPointF(a[0], a[1]), QPointF(b[0], b[1]))

    def _draw_path(self, painter: QPainter, project, start, end, colour: QColor = HOLO) -> None:
        """The route the arm is taking: straight, or swinging round the base (see hardware/motion.py)."""
        HOLO = colour   # noqa: N806 - the same drawing, in the colour asked for
        route = [project((p.x, p.y, p.z)) for p in motion.path_points(start, end, 48)]
        route = [q for q in route if q is not None]
        if len(route) < 2:
            return
        polygon = QPolygonF([QPointF(q[0], q[1]) for q in route])
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 45), 8.0, Qt.PenStyle.SolidLine,
                            Qt.PenCapStyle.RoundCap))
        painter.drawPolyline(polygon)
        painter.setPen(QPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 220), 2.0, Qt.PenStyle.DashLine))
        painter.drawPolyline(polygon)
        # where it stops: a ring on the table under the target, and a drop line
        ring = [project((end.x + 12 * math.cos(t), end.y + 12 * math.sin(t), 0.5))
                for t in [i * math.pi / 12 for i in range(25)]]
        foot, top = project((end.x, end.y, 0.5)), project((end.x, end.y, end.z))
        if all(q is not None for q in ring):
            painter.setPen(QPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 200), 1.8))
            painter.drawPolyline(QPolygonF([QPointF(q[0], q[1]) for q in ring]))
        if foot is not None and top is not None:
            painter.setPen(QPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 120), 1.2, Qt.PenStyle.DotLine))
            painter.drawLine(QPointF(foot[0], foot[1]), QPointF(top[0], top[1]))
        if motion.passes_near_base(start, end):
            painter.setFont(QFont(self.font().family(), 9))
            mid = route[len(route) // 2]
            painter.setPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 230))
            painter.drawText(QPointF(mid[0] + 8, mid[1] - 8), "swings round the base")

    def _draw_ghost(self, painter: QPainter, project, camera: ViewCamera, end, colour: QColor = HOLO) -> None:
        """A see-through stick figure of the arm where it is going."""
        HOLO = colour   # noqa: N806 - the same drawing, in the colour asked for
        ghost = robots.active().geometry(end.x, end.y, end.z, end.r)
        chain = [(0.0, 0.0, 0.0), (0.0, 0.0, ghost.shoulder[2]), ghost.shoulder, ghost.elbow, ghost.wrist,
                 ghost.tool_corner, ghost.tcp]
        points = [project(p) for p in chain]
        for a, b, p3 in zip(points, points[1:], chain[1:]):
            if a is None or b is None:
                continue
            width = max(2.0, 18.0 * camera.focal / max(b[2], 1.0))
            painter.setPen(QPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 40), width, Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap))
            painter.drawLine(QPointF(a[0], a[1]), QPointF(b[0], b[1]))
            painter.setPen(QPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 150), 1.4))
            painter.drawLine(QPointF(a[0], a[1]), QPointF(b[0], b[1]))
        painter.setBrush(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 90))
        painter.setPen(QPen(QColor(HOLO.red(), HOLO.green(), HOLO.blue(), 200), 1.2))
        for q in points[2:]:
            if q is not None:
                painter.drawEllipse(QPointF(q[0], q[1]), 3.5, 3.5)

    def _draw_height_line(self, painter: QPainter, project, tcp, font: QFont) -> None:
        top, foot = project(tcp), project((tcp[0], tcp[1], 0.4))
        if top is None or foot is None:
            return
        painter.setPen(QPen(QColor(255, 209, 102, 170), 1.4, Qt.PenStyle.DashLine))
        painter.drawLine(QPointF(top[0], top[1]), QPointF(foot[0], foot[1]))
        painter.setPen(QPen(QColor(255, 209, 102, 200), 1.6))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QPointF(foot[0], foot[1]), 4.0, 2.2)
        label = f"{max(0.0, tcp[2]):.0f} mm"
        mid = ((top[0] + foot[0]) / 2 + 7, (top[1] + foot[1]) / 2 + 4)
        small = QFont(font)
        small.setPointSize(9)
        painter.setFont(small)
        painter.setPen(QColor(0, 0, 0, 170))
        painter.drawText(QPointF(mid[0] + 1, mid[1] + 1), label)
        painter.setPen(QColor(255, 225, 150))
        painter.drawText(QPointF(mid[0], mid[1]), label)

    def _draw_joint_arcs(self, painter: QPainter, project, geometry, tool_rotation: float) -> None:
        """Small arcs in the 3D view: J1 round the base on the table, J2 at the shoulder from straight
        up, J3 at the elbow from level -- each in its limit colour. (Another robot: J1 only, its other joints
        don't turn in the Dobot's way.)"""
        robot = robots.active()
        joints = robot.joints(geometry, tool_rotation)
        joint_status = robot.joint_status
        azimuth = math.radians(joints["J1"])
        ux, uy = math.cos(azimuth), math.sin(azimuth)

        def arc(points) -> None:
            projected = [project(p) for p in points]
            if all(q is not None for q in projected):
                painter.drawPolyline(QPolygonF([QPointF(q[0], q[1]) for q in projected]))

        painter.setBrush(Qt.BrushStyle.NoBrush)
        steps = 24
        painter.setPen(QPen(STATUS_COLOURS[joint_status("J1", joints["J1"])], 2.2))
        ring = 96.0 * robot.view_scale
        arc([(ring * math.cos(azimuth * i / steps), ring * math.sin(azimuth * i / steps), 1.0) for i in range(steps + 1)])
        if robot.key != "dobot_magician":
            return
        sx, sy, sz = geometry.shoulder
        j2 = math.radians(joints["J2"])
        painter.setPen(QPen(STATUS_COLOURS[joint_status("J2", joints["J2"])], 2.2))
        arc([(sx + 34 * math.sin(j2 * i / steps) * ux, sy + 34 * math.sin(j2 * i / steps) * uy,
              sz + 34 * math.cos(j2 * i / steps)) for i in range(steps + 1)])
        ex, ey, ez = geometry.elbow
        j3 = math.radians(joints["J3"])
        painter.setPen(QPen(STATUS_COLOURS[joint_status("J3", joints["J3"])], 2.2))
        arc([(ex + 30 * math.cos(j3 * i / steps) * ux, ey + 30 * math.cos(j3 * i / steps) * uy,
              ez - 30 * math.sin(j3 * i / steps)) for i in range(steps + 1)])

    def _draw_gripper_halo(self, painter: QPainter, project, camera: ViewCamera, tcp, holding: bool) -> None:
        q = project(tcp)
        if q is None:
            return
        radius = max(10.0, 34.0 * camera.focal / max(q[2], 1.0))
        colour = QColor(90, 240, 140) if holding else QColor(255, 180, 70)
        halo = QRadialGradient(q[0], q[1], radius)
        halo.setColorAt(0.0, QColor(colour.red(), colour.green(), colour.blue(), 90))
        halo.setColorAt(1.0, QColor(colour.red(), colour.green(), colour.blue(), 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(halo))
        painter.drawEllipse(QPointF(q[0], q[1]), radius, radius)

    def _draw_camera_cone(self, painter: QPainter, project) -> None:
        """The camera where the calibration puts it, and the patch of table it sees."""
        view = self.camera_view() if self.camera_view is not None else None
        if view is None:
            return
        transform, intrinsics = view
        transform = np.asarray(transform, dtype=np.float64)
        centre = transform[:3, 3]
        corners = []
        for u, v in ((0, 0), (intrinsics.width, 0), (intrinsics.width, intrinsics.height), (0, intrinsics.height)):
            ray = transform[:3, :3] @ np.array([(u - intrinsics.cx) / intrinsics.fx, (v - intrinsics.cy) / intrinsics.fy, 1.0])
            if ray[2] >= -1e-6:
                return                     # a corner doesn't look down at the table: nothing sensible to draw
            corners.append(centre - centre[2] / ray[2] * ray)
        c = project(tuple(centre))
        footprint = [project((p[0], p[1], 0.6)) for p in corners]
        if c is None or any(q is None for q in footprint):
            return
        teal = QColor(75, 200, 185)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(teal.red(), teal.green(), teal.blue(), 26))
        painter.drawPolygon(QPolygonF([QPointF(q[0], q[1]) for q in footprint]))
        painter.setPen(QPen(QColor(teal.red(), teal.green(), teal.blue(), 150), 1.2, Qt.PenStyle.DashLine))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPolygon(QPolygonF([QPointF(q[0], q[1]) for q in footprint]))
        painter.setPen(QPen(QColor(teal.red(), teal.green(), teal.blue(), 90), 1.0))
        for q in footprint:
            painter.drawLine(QPointF(c[0], c[1]), QPointF(q[0], q[1]))
        painter.setPen(QPen(QColor(10, 24, 34), 1.5))
        painter.setBrush(teal)
        painter.drawRoundedRect(QRectF(c[0] - 9, c[1] - 6, 18, 12), 3, 3)
        painter.setPen(QColor(170, 235, 225))
        painter.setFont(QFont(self.font().family(), 9))
        painter.drawText(QPointF(c[0] + 12, c[1] - 8), "camera (as calibrated)")

    def _draw_outlines(self, painter: QPainter, project, font, outlines: list[dict]) -> None:
        """Outlines given in table coordinates: dicts with `points` [(x, y, z) mm], `colour` (r, g, b), an optional
        `width`, `label` and `fill` (0-255: how strongly it is filled in its colour; e.g. the watcher's ghost of where
        each cube goes, and the zones, the task's own filled)."""
        for outline in outlines or []:
            pts = [project(tuple(pt)) for pt in outline["points"]]
            if any(q is None for q in pts):
                continue
            colour = QColor(*outline.get("colour", (235, 240, 245)))
            poly = QPolygonF([QPointF(q[0], q[1]) for q in pts] + [QPointF(pts[0][0], pts[0][1])])
            if outline.get("fill"):
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(colour.red(), colour.green(), colour.blue(), int(outline["fill"])))
                painter.drawPolygon(poly)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(QColor(10, 24, 34), outline.get("width", 2) + 2.0))
            painter.drawPolyline(poly)
            painter.setPen(QPen(colour, outline.get("width", 2)))
            painter.drawPolyline(poly)
            if outline.get("label"):
                painter.setFont(font)
                top = min(pts, key=lambda q: q[1])
                painter.drawText(QPointF(top[0] - 10, top[1] - 6), str(outline["label"]))

    def _draw_detections(self, painter: QPainter, project, font: QFont) -> None:
        """Where the camera finds each object: a wire box under the top centre it reports, as big as it measured it
        (its footprint, and as tall as its narrow side), or a 25 mm cube when it has no size."""
        small = QFont(font)
        small.setPointSize(8)
        small.setBold(False)
        painter.setFont(small)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        for label, (x, y, z), confidence, *measured in self._detections:
            colour = LABEL_COLOURS.get(str(label).split()[0], QColor(230, 240, 245))
            width, length, angle = (measured[0] if measured and measured[0] else None) or (25.0, 25.0, 0.0)
            c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
            hl, hw = length / 2.0, width / 2.0
            corners = [(x + i * hl * c - j * hw * s, y + i * hl * s + j * hw * c, z + dz) for dz in (0.0, -min(width, length))
                       for i, j in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
            points = [project(p) for p in corners]
            if any(q is None for q in points):
                continue
            painter.setPen(QPen(colour, 1.4, Qt.PenStyle.DashLine))
            for i in range(4):
                for a, b in ((i, (i + 1) % 4), (i + 4, (i + 1) % 4 + 4), (i, i + 4)):
                    painter.drawLine(QPointF(points[a][0], points[a][1]), QPointF(points[b][0], points[b][1]))
            painter.setPen(colour)
            painter.drawText(QPointF(points[2][0] + 6, points[2][1] - 4), f"seen {confidence:.0%}")

    def _draw_toast(self, painter: QPainter, font: QFont) -> None:
        text, expires = self._toast
        remaining = expires - time.monotonic()
        if remaining <= 0:
            self._toast = None
            return
        alpha = int(255 * min(1.0, remaining / 0.6))
        painter.setFont(font)
        width = painter.fontMetrics().horizontalAdvance(text) + 24
        box = QRectF((self.width() - width) / 2, self.height() - 60, width, 26)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(8, 18, 28, int(alpha * 0.85)))
        painter.drawRoundedRect(box, 6, 6)
        painter.setPen(QColor(215, 235, 240, alpha))
        painter.drawText(box, Qt.AlignmentFlag.AlignCenter, text)

    # ---- the panel in the top right ---------------------------------------------------------------------
    def _panel_frame(self, painter: QPainter, width: float, height: float) -> float:
        left = self.width() - width - 12
        painter.setPen(QPen(QColor(90, 130, 150, 120), 1))
        painter.setBrush(QColor(8, 18, 28, 190))
        painter.drawRoundedRect(QRectF(left, 12, width, height), 8, 8)
        return left

    def _held_label(self, objects: list) -> Optional[str]:
        held_id = getattr(self.robot, "held_object", None)
        return next((o["label"] for o in objects if o["id"] == held_id), None) if held_id else None

    def _draw_gauge_panel(self, painter: QPainter, geometry, gripper_closed: bool, tool_rotation: float,
                          objects: list) -> None:
        """The joints as gauges in the robot's own conventions (J1-J4 for the Dobot, J1-J6 for the xArm): a bar for
        the joint's range, a marker for where it is, green / orange near a limit / red past one."""
        robot = robots.active()
        joints = robot.joints(geometry, tool_rotation)
        names = robot.joint_labels
        held = self._held_label(objects)
        line_h, pad, width = 22, 10, 236 if len(robot.joint_names) <= 4 else 262
        height = pad * 2 + 16 + line_h * len(robot.joint_names) + 8 + 18 * 2
        left = self._panel_frame(painter, width, height)
        title = QFont(self.font())
        title.setPointSize(8)
        title.setBold(True)
        body = QFont(self.font())
        body.setPointSize(9)
        y = 12 + pad + 10
        painter.setFont(title)
        painter.setPen(QColor("#4bb8ad"))
        painter.drawText(QPointF(left + pad, y), f"JOINTS  (limits: {robot.short_name} spec)")
        painter.setFont(body)
        bar_left, bar_width = left + (98 if len(robot.joint_names) <= 4 else 124), 70
        for key in robot.joint_names:
            y += line_h
            angle = joints[key]
            low, high = robot.joint_limits_deg[key]
            status = robot.joint_status(key, angle)
            painter.setPen(QColor(150, 175, 195))
            painter.drawText(QPointF(left + pad, y), f"{key}  {names[key]}")
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(40, 60, 75))
            painter.drawRoundedRect(QRectF(bar_left, y - 8, bar_width, 6), 3, 3)
            fraction = (min(max(angle, low), high) - low) / (high - low)
            painter.setBrush(STATUS_COLOURS[status])
            painter.drawEllipse(QPointF(bar_left + fraction * bar_width, y - 5), 4.5, 4.5)
            painter.setPen(STATUS_COLOURS[status] if status != "ok" else QColor(225, 238, 246))
            painter.drawText(QRectF(left, y - 14, width - pad, 18), Qt.AlignmentFlag.AlignRight, f"{angle:+.1f}°")
        y += 8
        for name, value, active in (("Gripper", "closed" if gripper_closed else "open", gripper_closed),
                                    ("Holding", held or "nothing", bool(held))):
            y += 18
            painter.setPen(QColor(150, 175, 195))
            painter.drawText(QPointF(left + pad, y), name)
            painter.setPen(QColor("#ffb454") if active else QColor(225, 238, 246))
            painter.drawText(QRectF(left, y - 13, width - pad, 18), Qt.AlignmentFlag.AlignRight, value)

    def _draw_status_panel(self, painter: QPainter, geometry, gripper_closed: bool, tool_rotation: float,
                           objects: list) -> None:
        """Joint angles and gripper state, top right (the V1.8 panel, when the gauges are off)."""
        held = self._held_label(objects)
        robot = robots.active()
        if robot.key == "dobot_magician":
            joints = joint_angles(geometry, tool_rotation)
            rows = [("J1  Base", f"{joints.base:+.1f}°"), ("J2  Shoulder", f"{joints.shoulder:.1f}°"),
                    ("J3  Elbow", f"{joints.elbow:.1f}°"), ("J4  Tool", f"{joints.tool:+.1f}°")]
        else:
            angles = robot.joints(geometry, tool_rotation)
            rows = [(f"{key}  {robot.joint_labels[key]}", f"{angles[key]:+.1f}°") for key in robot.joint_names]
        state = [("Gripper", "closed" if gripper_closed else "open"), ("Holding", held or "nothing")]

        title_font = QFont(self.font())
        title_font.setPointSize(8)
        title_font.setBold(True)
        body_font = QFont(self.font())
        body_font.setPointSize(9)
        line_h, pad, width = 18, 10, 176 if len(rows) <= 4 else 214
        height = pad * 2 + 16 + line_h * len(rows) + 8 + line_h * len(state)
        left = self._panel_frame(painter, width, height)

        y = 12 + pad + 10
        painter.setFont(title_font)
        painter.setPen(QColor("#4bb8ad"))
        painter.drawText(QPointF(left + pad, y), f"JOINTS  ({len(rows)} degrees of freedom)")
        painter.setFont(body_font)
        for name, value in rows:
            y += line_h
            painter.setPen(QColor(150, 175, 195))
            painter.drawText(QPointF(left + pad, y), name)
            painter.setPen(QColor(225, 238, 246))
            painter.drawText(QRectF(left, y - 13, width - pad, 18), Qt.AlignmentFlag.AlignRight, value)
        y += 8
        for name, value in state:
            y += line_h
            painter.setPen(QColor(150, 175, 195))
            painter.drawText(QPointF(left + pad, y), name)
            active = (name == "Gripper" and gripper_closed) or (name == "Holding" and held)
            painter.setPen(QColor("#ffb454") if active else QColor(225, 238, 246))
            painter.drawText(QRectF(left, y - 13, width - pad, 18), Qt.AlignmentFlag.AlignRight, value)


def _project_with(camera: ViewCamera, w: int, h: int, p) -> Optional[tuple[float, float, float]]:
    v = [p[i] - camera.position[i] for i in range(3)]
    zc = sum(v[i] * camera.forward[i] for i in range(3))
    if zc < 5.0:
        return None
    xc = sum(v[i] * camera.right[i] for i in range(3))
    yc = sum(v[i] * camera.up[i] for i in range(3))
    return (w / 2 + camera.focal * xc / zc, h / 2 - camera.focal * yc / zc, zc)

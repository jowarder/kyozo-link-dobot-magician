"""Demo mode: learn the cube calibration by watching it done, or by doing it with the app checking each step.

A panel at the top of the Calibration tab's cube section. Pick the cube (20 mm, forgiving; or 25 mm, as at the lab:
1.25 mm of room each side in the Dobot's 27.5 mm gripper), whether the demo should be like the lab (the camera's
noise, a gripper mounted 3 degrees turned, a wrist 5 % short with 2 degrees of slack), and how fast the arm goes.
Start sets out a table with just that cube; Exit puts back the scene, the camera, the speed and the calibration that
were in use before (nothing done while learning is kept).

Watch: the demo does each step itself, with the normal buttons, and stops after it to explain what happened ("Do
this step", "Run to the end", "Repeat"). Practise: you do the steps (Manual tab to jog, Calibration tab buttons); the
panel follows along, says what isn't right yet, and ticks each step when it is.

The steps and their checks are here; the host (the main window) sets the demo up and puts it back (tour_setup,
tour_teardown, tour_cube).
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Callable, Optional

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import (QApplication, QCheckBox, QComboBox, QGroupBox, QLabel, QPushButton, QSizePolicy,
                             QVBoxLayout, QWidget)

from app.calibration.cube import CubeOutcome, middle_turn
from app.hardware.interfaces import Pose
from app.ui.flow_layout import FlowLayout
from app.ui.worker import CallableWorker

logger = logging.getLogger(__name__)

SIZES_MM = (20.0, 25.0)
SPEEDS = (("As fast as the real Dobot", 1.0), ("5x faster", 5.0), ("20x faster", 20.0))
TOUCH_FROM_CUBE_MM = 55.0      # the two table touches: this far beyond the cube and this far before it, along the arm
STRETCHED_MM = 240.0           # a touch this far out counts as "stretched out"
TOUCHED_MM = 1.0               # fingertips within this of the table: touching
NEAR_CUBE_MM = 70.0            # a touch this near the cube is "beside" it
MIDDLE_DEG = 3.0               # the wrist this near its middle: in the middle
HIGHLIGHT = "border: 2px solid #ffd166;"
GOOD, WARN, MUTED, TEXT = "#7fe0b0", "#f5a742", "#8fa8ba", "#d7e6f0"


def allowed_turn_deg(size_mm: float, opening_mm: float) -> float:
    """How far a square of this size can be turned against the fingers and still fit between them, open."""
    if size_mm * math.sqrt(2.0) <= opening_mm:
        return 45.0
    low, high = 0.0, 45.0
    for _ in range(40):
        mid = (low + high) / 2.0
        a = math.radians(mid)
        low, high = (mid, high) if size_mm * (math.cos(a) + math.sin(a)) <= opening_mm else (low, mid)
    return low


@dataclass
class Step:
    key: str
    title: str
    what: str            # what to do (Practise) / what the demo does (Watch)
    why: str
    press: str           # the button (and where it is)
    good: str            # what a good result looks like
    button: Optional[str] = None      # the Calibration tab's button to highlight (an attribute of the panel)


def steps_for(size: float, opening: float, finger_mm: float) -> list[Step]:
    room = (opening - size) / 2.0
    turn = allowed_turn_deg(size, opening)
    grip_up = max(1.0, size - finger_mm)
    tight = size >= 24.0
    return [
        Step("home", "Home the arm",
             "Open the gripper and press Home (Manual tab).",
             "The Dobot has no sensors on its joints: until it is homed, its coordinates can be centimetres out "
             "after it was switched off and on. Every touch and every spot after this goes by those coordinates.",
             "Manual tab: Home", "The arm stands at x 200, y 0, z 50, the wrist straight."),
        Step("touch_far", "Touch the table, arm stretched out",
             f"Jog the open gripper out to about 27-28 cm from the robot's middle (beyond the cube), then down until "
             f"the fingertips just touch the table (the smallest jog step for the last mm). Press 'Fingertips on "
             f"the table'.",
             "Stretched out, the Dobot stands 2-3 mm higher or lower than near its base. Two touches, far and near, "
             "let it put the cube down just above the table everywhere, so the cube doesn't drop and turn.",
             "Calibration tab: Fingertips on the table", f"T1 at {STRETCHED_MM / 10:.0f} cm or more out, the "
             f"fingertips within {TOUCHED_MM:.0f} mm of the table; the arm rises 1 mm by itself.", "touch_btn"),
        Step("touch_near", "Touch the table beside the cube",
             "Lift a little, move in beside the cube (between it and the robot, not over it) and touch the table "
             "again. Press 'Fingertips on the table'.",
             f"The Dobot's fingers reach only {finger_mm:.0f} mm down: less than the cube is tall, so the table is "
             "touched beside the cube, not round it. With far and near touched, the table's height is known all "
             "along the arm.",
             "Calibration tab: Fingertips on the table", f"T2 within {NEAR_CUBE_MM / 10:.0f} cm of the cube; the "
             "message says how the table slopes between the touches.", "touch_btn"),
        Step("middle", "Wrist to the middle, over the cube",
             f"Jog up about 3 cm, over the cube, the gripper open, then press 'Wrist to middle'.",
             "The whole run is made with the wrist in its middle (the gripper along the arm): the wrist turning would "
             "move the fingers' middle a little, and the calibration would measure that instead of the camera. "
             + (f"With a {size:.0f} mm cube it also lines the fingers up with its sides: turned more than about "
                f"{turn:.0f}° the open fingers no longer fit round it." if tight else
                f"A {size:.0f} mm cube fits between the open fingers turned up to about {turn:.0f}°."),
             "Calibration tab: Wrist to middle", "The wrist within 3° of its middle, the open gripper above the "
             "cube.", "middle_btn"),
        Step("grip", "Grip the cube",
             f"Lower the open gripper round the cube until the gripper rests on its top (the fingertips about "
             f"{grip_up:.0f} mm above the table), then close the gripper (Manual tab). Don't lift it.",
             f"The fingers squeeze the cube square to them and hold it the same way all run. "
             + (f"Only {room:.2f} mm of room each side: the fingers must come down right over its middle, or one "
                "lands on the cube." if tight else f"{room:.2f} mm of room each side: forgiving."),
             "Manual tab: jog down, then close the gripper", "The cube between the fingers, held; still standing "
             "on the table."),
        Step("calibrate", "Calibrate with a cube",
             "Choose how many spots (the demo uses Fast: 6), and press 'Calibrate with a cube'. Watch it: it centres "
             "the cube, looks at the empty table from its waiting places, then puts the cube down at each spot, moves "
             "away while the camera looks, and takes it back. Every 5 spots it checks the arm hasn't lost its place.",
             "The camera finds the cube against the empty table at every spot; the robot knows where it put it. "
             "Matching the two gives where the camera is. The table's own surface gives its tilt and height.",
             "Calibration tab: Calibrate with a cube", "Passed. Typical error under 2.0 mm (every mode), no more than a "
             "fifth of the spots over 3 mm, slip under 3 mm. The result lists each spot's miss and the fingers' angle and offset.",
             "cube_btn"),
        Step("pick_test", "Pick test",
             "Press 'Pick test': the cube is put at 3 spots the calibration never saw, found by the camera alone, "
             "and picked up from where the camera says it is.",
             "The calibration's error measured where it wasn't fitted: the honest number, and a real pick.",
             "Calibration tab: Pick test", "The camera puts the cube within about 1 mm of where the robot left it; "
             "3 of 3 held.", "pick_test_btn"),
        Step("fingers", "Fingers angle check",
             "Press 'Fingers angle check': 20 put-downs, the wrist at -40 to +40°, coming to each angle from below "
             "and from above.",
             "How the wrist really turns: the fingers' offset, the gain (how much of a turn it really makes), "
             "backlash (slack when it changes direction) and scatter. Saved with the calibration; every pick then "
             "makes up for them.",
             "Calibration tab: Fingers angle check", "Offset within a few degrees, gain 0.95-1.05, backlash a few "
             "degrees, scatter under 1.5°; 'Saved with the calibration'.", "fingers_btn"),
        Step("rotation_off", "Rotation pick test, correction off",
             "Untick 'correction on' and press 'Rotation pick test': the cube put down turned at random, found, and "
             "picked as before this check existed.",
             "The 'before' number: how far off the fingers are without the correction.",
             "Calibration tab: Rotation pick test ('correction on' unticked)", "Like the lab: a degree or more off "
             "on average. Perfect demo: about 0.", "rotation_btn"),
        Step("rotation_on", "Rotation pick test, correction on",
             "Tick 'correction on' and press 'Rotation pick test' again.",
             "The 'after' number: picks with the correction, the wrist always coming to its angle from below, the "
             "last 15 mm slowly.",
             "Calibration tab: Rotation pick test ('correction on' ticked)", "Clearly smaller than without, worst "
             f"well under {turn:.0f}° (the turn a {size:.0f} mm cube allows).", "rotation_btn"),
        Step("finish", "Finish",
             "Press 'Finish': the cube goes back on the table and the calibration is in use.",
             "Done. (In this walk-through, Exit puts back the calibration that was in use before.)",
             "Calibration tab: Finish", "'Done. The calibration with the cube is in use.'", "finish_cube_btn"),
    ]


REPEATABLE = {"home", "touch_far", "touch_near", "pick_test", "fingers", "rotation_off", "rotation_on"}


class CubeTour(QGroupBox):
    """See the module's docstring. `panel`: the CalibrationPanel; `host`: has tour_setup(size, lab_like, speed) ->
    refusal or None, tour_teardown(), tour_cube() -> (x, y, top z) or None, and `robot`."""

    def __init__(self, panel, host, parent=None):
        super().__init__("Learn cube calibration (demo)", parent)
        self.panel, self.host = panel, host
        self.mode: Optional[str] = None           # "watch" or "practise" while running
        self.steps: list[Step] = []
        self.index = 0
        self.ticked: set = set()
        self.auto = False                          # Watch: run to the end
        self.waiting = False                       # Watch: a step's action is under way
        self.size = SIZES_MM[0]
        self._worker: Optional[CallableWorker] = None
        self._highlighted = None
        self._highlight_style = ""
        self._homed = False
        self._failed = ""

        column = QVBoxLayout(self)
        intro = QLabel("Learn the cube calibration on the demo before the real arm: watch it done step by step, "
                       "or do it yourself with each step checked. Exit puts everything back as it was.")
        intro.setWordWrap(True)
        intro.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)   # (wraps, never widens)
        column.addWidget(intro)
        # rows that wrap onto the next line when the column is narrow: side by side, at 150% scaling, they made the
        # column wider than the window and cut its right side off
        setup = _flow_row(column)
        self.size_box = QComboBox()
        for size in SIZES_MM:
            self.size_box.addItem(f"{size:.0f} mm cube" + (" (like the lab)" if size >= 24 else " (forgiving)"), size)
        self.size_box.setToolTip("20 mm: room to spare in the 27.5 mm gripper. 25 mm: as at the lab, only 1.25 mm "
                                 "each side: the wrist and the fingers must be just right.")
        self.mode_box = QComboBox()
        self.mode_box.addItem("Watch", "watch")
        self.mode_box.addItem("Practise", "practise")
        self.mode_box.setToolTip("Watch: the demo does each step and explains it. Practise: you do them; each is "
                                 "checked.")
        self.speed_box = QComboBox()
        for text, factor in SPEEDS:
            self.speed_box.addItem(text, factor)
        self.speed_box.setCurrentIndex(1)
        self.lab_box = QCheckBox("Like the lab")
        self.lab_box.setToolTip("The camera's noise, a gripper mounted 3° turned, a wrist that turns 5% short with 2° "
                                "of slack: the fingers angle check and the rotation pick test then show real numbers.")
        for widget in (self.size_box, self.mode_box, self.speed_box, self.lab_box):
            setup.addWidget(widget)
        buttons = _flow_row(column)
        self.start_btn = QPushButton("Start")
        self.start_btn.clicked.connect(self.start)
        self.next_btn = QPushButton("Do this step")
        self.next_btn.clicked.connect(self.do_step)
        self.run_btn = QPushButton("Run to the end")
        self.run_btn.clicked.connect(self.run_to_end)
        self.repeat_btn = QPushButton("Repeat the last step")
        self.repeat_btn.clicked.connect(self.repeat)
        self.exit_btn = QPushButton("Exit")
        self.exit_btn.clicked.connect(self.exit)
        for button in (self.start_btn, self.next_btn, self.run_btn, self.repeat_btn, self.exit_btn):
            buttons.addWidget(button)
        self.steps_label = QLabel()
        self.steps_label.setWordWrap(True)
        self.steps_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        column.addWidget(self.steps_label)
        self.detail = QLabel()
        self.detail.setWordWrap(True)
        self.detail.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.detail.setStyleSheet("background: #16303a; padding: 8px; border-radius: 4px;")
        column.addWidget(self.detail)
        self.status = QLabel()
        self.status.setWordWrap(True)
        self.status.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        column.addWidget(self.status)
        self.timer = QTimer(self)
        self.timer.setInterval(300)
        self.timer.timeout.connect(self.tick)
        self._refresh()

    # ---- starting and stopping -------------------------------------------------------------------------------------
    def start(self) -> None:
        if self.mode is not None:
            return
        self.size = float(self.size_box.currentData())
        refused = self.host.tour_setup(self.size, self.lab_box.isChecked(), float(self.speed_box.currentData()))
        if refused:
            self._say(refused, WARN)
            return
        gripper = self.host.robot.gripper
        self.steps = steps_for(self.size, gripper.opening_mm, gripper.finger_depth_mm)
        self.mode = self.mode_box.currentData()
        self.index, self.ticked, self.auto, self.waiting, self._homed, self._failed = 0, set(), False, False, False, ""
        self.panel.done_steps.clear()
        self.panel._touches, self.panel._touched_at = [], None
        self.panel.touch_label.setText("Table: not touched yet")
        self.panel._show_touches()
        self.panel.style_box.setCurrentIndex(self.panel.style_box.findData("cube"))
        self.panel.cube_size.setValue(self.size)
        if self.mode == "watch":
            self.panel.cube_mode.setCurrentIndex(self.panel.cube_mode.findData("fast"))
        self.timer.start()
        self._say("Started: one cube on an empty table. " + ("Press 'Do this step', or 'Run to the end'."
                                                            if self.mode == "watch" else
                                                            "Do the first step; this panel follows along."), GOOD)
        self._refresh()

    def busy(self) -> bool:
        return (self._worker is not None) or (self.panel._worker is not None)

    def exit(self) -> None:
        if self.mode is None:
            return
        if self.busy():
            self._say("The arm is busy: wait for it (or press Stop), then Exit.", WARN)
            return
        self.timer.stop()
        self._highlight(None)
        self.mode, self.auto, self.waiting = None, False, False
        panel = self.panel
        panel._cube_phase1 = None
        panel._wrist_model = None
        panel.done_steps.clear()
        panel._touches, panel._touched_at = [], None
        panel.touch_label.setText("Table: not touched yet")
        panel._show_touches()
        panel.cube_size.setValue(0.0)
        self.host.tour_teardown()
        panel._refresh_buttons()
        self._say("Back as it was before the walk-through: the scene, the camera, the speed and the calibration.",
                  GOOD)
        self._refresh()

    # ---- Watch: the demo does the steps --------------------------------------------------------------------------
    def do_step(self) -> None:
        if self.mode != "watch" or self.busy() or self.waiting or self.index >= len(self.steps):
            return
        if QApplication.activeModalWidget() is not None:          # (answer the open message first)
            QTimer.singleShot(500, self.do_step)
            return
        self._failed = ""
        step = self.steps[self.index]
        self.waiting = True
        self._say(f"Doing: {step.title}...", TEXT)
        try:
            getattr(self, f"_do_{step.key}")()
        except Exception as exc:  # noqa: BLE001 - shown, the walk-through stops
            self.waiting, self.auto = False, False
            self._say(f"{step.title}: couldn't start ({exc}).", WARN)
        self._refresh()

    def run_to_end(self) -> None:
        if self.mode != "watch":
            return
        self.auto = True
        self.do_step()

    def repeat(self) -> None:
        """Watch: do the last finished step again (those that can be: a touch, a test)."""
        if self.mode != "watch" or self.busy() or self.waiting or self.index == 0:
            return
        last = self.steps[self.index - 1]
        if last.key not in REPEATABLE or (last.key in ("home", "touch_far", "touch_near") and "grip" in self.ticked):
            self._say(f"'{last.title}' can't be done again from here.", WARN)
            return
        self.index -= 1
        self.ticked.discard(last.key)
        self.panel.done_steps.pop(_DONE_KEYS.get(last.key, last.key), None)
        self.do_step()

    def _run(self, work: Callable, then: Optional[Callable] = None) -> None:
        """`work` (arm moves) off the UI thread; then `then()` back on it."""
        worker = CallableWorker(work)
        self._worker = worker

        def done(_result):
            self._worker = None
            if then is not None:
                then()

        def failed(message: str):
            self._worker = None
            self._failed = message
        worker.finished_ok.connect(done)
        worker.failed.connect(failed)
        worker.start()

    def _cube(self) -> tuple[float, float, float]:
        cube = self.host.tour_cube()
        if cube is None:
            raise RuntimeError("the cube isn't on the table")
        return cube

    def _touch_points(self) -> tuple[tuple[float, float], tuple[float, float]]:
        x, y, _ = self._cube()
        reach = math.hypot(x, y)
        ux, uy = x / reach, y / reach
        d = TOUCH_FROM_CUBE_MM
        return (x + d * ux, y + d * uy), (x - d * ux, y - d * uy)

    def _do_home(self) -> None:
        robot = self.host.robot

        def work():
            robot.open_gripper()
            robot.home()
        self._run(work, then=lambda: setattr(self, "_homed", True))

    def _touch_at(self, x: float, y: float) -> None:
        robot = self.host.robot
        cube_top = self._cube()[2]

        def work():
            here = robot.get_pose()
            up = max(here.z, cube_top + 25.0)
            robot.move_to(Pose(here.x, here.y, up, here.r))
            r = middle_turn(x, y)
            robot.move_to(Pose(x, y, up, r))
            robot.move_to(Pose(x, y, 3.0, r))
            robot.move_to(Pose(x, y, 0.0, r), max(2.0, min(robot.max_speed, 10.0)))   # the last mm: gently
        self._run(work, then=self.panel._touch_table)

    def _do_touch_far(self) -> None:
        self._touch_at(*self._touch_points()[0])

    def _do_touch_near(self) -> None:
        self._touch_at(*self._touch_points()[1])

    def _do_middle(self) -> None:
        robot = self.host.robot
        x, y, top = self._cube()

        def work():
            here = robot.get_pose()
            robot.move_to(Pose(here.x, here.y, top + 30.0, here.r))
            robot.move_to(Pose(x, y, top + 30.0, here.r))
        self._run(work, then=self.panel._wrist_to_middle)

    def _do_grip(self) -> None:
        robot = self.host.robot
        x, y, top = self._cube()
        finger = robot.gripper.finger_depth_mm
        grip_z = max(1.0, top - finger + 0.3)            # the gripper resting on the cube (the Dobot's short fingers)

        def work():
            r = middle_turn(x, y)
            robot.move_to(Pose(x, y, top + 30.0, r))
            robot.move_to(Pose(x, y, grip_z, r))
            robot.close_gripper()
        self._run(work)

    def _do_calibrate(self) -> None:
        self.panel._start_cube(confirm=False)

    def _do_pick_test(self) -> None:
        self.panel._pick_test()

    def _do_fingers(self) -> None:
        self.panel._fingers_check()

    def _do_rotation_off(self) -> None:
        self.panel.rotation_corrected.setChecked(False)
        self.panel._rotation_test()

    def _do_rotation_on(self) -> None:
        self.panel.rotation_corrected.setChecked(True)
        self.panel._rotation_test()

    def _do_finish(self) -> None:
        self.panel._finish_cube()

    # ---- following along: is the current step done? ---------------------------------------------------------------
    def check(self, step: Step) -> tuple[bool, str]:
        """(done, what isn't right yet) for `step`, from the robot, the demo and the Calibration tab as they are now."""
        robot, panel = self.host.robot, self.panel
        pose = robot.get_pose()
        key = step.key
        if key == "home":
            at_home = math.dist((pose.x, pose.y, pose.z), (200.0, 0.0, 50.0)) < 1.0 and abs(pose.r) < 1.0
            if at_home or self._homed:
                return True, ""
            return False, "Press Home on the Manual tab (the arm goes to x 200, y 0, z 50)."
        touches = list(panel._touches)
        if key in ("touch_far", "touch_near"):
            cube = self.host.tour_cube()
            for t in touches:
                far = math.hypot(t[0], t[1]) >= STRETCHED_MM
                near = (not far and cube is not None and math.dist(t[:2], cube[:2]) <= NEAR_CUBE_MM)
                if abs(t[2]) <= TOUCHED_MM and ((key == "touch_far" and far) or (key == "touch_near" and near)):
                    return True, ""
            if touches:
                last = touches[-1]
                if abs(last[2]) > TOUCHED_MM:
                    return False, (f"The last touch was {last[2]:.1f} mm above the table: the fingertips didn't touch. "
                                   "Press 'Forget touches', lower them until they just touch, and press again.")
            if key == "touch_far":
                return False, (f"The fingertips are {math.hypot(pose.x, pose.y) / 10:.1f} cm out: touch the table "
                               f"with the arm stretched out, {STRETCHED_MM / 10:.0f} cm or more.")
            return False, "Touch the table beside the cube (within 7 cm of it), between it and the robot."
        cube = self.host.tour_cube()
        if key == "middle":
            if cube is None:
                return False, "The cube isn't on the table."
            off = (pose.r - middle_turn(pose.x, pose.y) + 180.0) % 360.0 - 180.0
            over = math.dist((pose.x, pose.y), cube[:2])
            if getattr(robot, "_gripper_closed", False):
                return False, "Open the gripper first (Manual tab)."
            if pose.z < cube[2] + 5.0:
                return False, "Lift the gripper clear of the cube (a few cm above it) before turning the wrist."
            if over > 15.0:
                return False, f"Move over the cube: the gripper is {over:.0f} mm from it."
            if abs(off) > MIDDLE_DEG:
                return False, f"The wrist is turned {off:+.0f}° from its middle: press 'Wrist to middle'."
            return True, ""
        if key == "grip":
            if getattr(robot, "held_object", None) is not None:
                off = (pose.r - middle_turn(pose.x, pose.y) + 180.0) % 360.0 - 180.0
                if abs(off) > MIDDLE_DEG + 2.0:
                    return False, (f"Held, but the wrist is turned {off:+.0f}°: open, lift, press 'Wrist to middle' "
                                   "and grip it again.")
                return True, ""
            if getattr(robot, "_gripper_closed", False):
                problem = getattr(robot, "last_grip_problem", "") or "nothing between the fingers"
                return False, f"The gripper closed but isn't holding the cube ({problem}). Open it and try again."
            if cube is not None:
                over = math.dist((pose.x, pose.y), cube[:2])
                if over > 1.5 and self.size >= 24.0:
                    return False, (f"The gripper's middle is {over:.1f} mm from the cube's: with a {self.size:.0f} mm "
                                   "cube that is too far, a finger would land on it. Jog closer.")
                if pose.z > cube[2]:
                    return False, "Lower the open gripper round the cube until it rests on its top, then close it."
            return False, "Close the gripper on the cube (Manual tab)."
        done = panel.done_steps.get(_DONE_KEYS.get(key, key))
        if key == "calibrate":
            if isinstance(done, CubeOutcome):
                if done.passed:
                    return True, ""
                return False, ("It didn't pass: " + (done.reason or "see below") + ". Grip the cube again and press "
                               "'Calibrate with a cube'.")
            if isinstance(done, str):
                return False, f"It stopped: {done}."
            return False, "Press 'Calibrate with a cube'."
        if key in ("rotation_off", "rotation_on"):
            want = key == "rotation_on"
            if panel.rotation_corrected.isChecked() != want and done is None:
                return False, f"{'Tick' if want else 'Untick'} 'correction on' first."
        press = step.press.split(': ', 1)[-1]
        if isinstance(done, str):
            return False, f"It stopped: {done}. Press '{press}' again."
        if done is not None:
            # only a step that worked counts (a fingers check with no model, a pick or rotation test that measured
            # nothing used to be ticked as done)
            failed = (getattr(done, "cancelled", False) or getattr(done, "reason", "")
                      or (hasattr(done, "model") and getattr(done, "model") is None)
                      or (hasattr(done, "rounds") and not getattr(done, "rounds"))
                      or (hasattr(done, "held") and not getattr(done, "held")))
            if not failed:
                return True, ""
            why = getattr(done, "reason", "") or "nothing was measured"
            return False, f"It didn't work: {why}. Press '{press}' again."
        return False, f"Press '{press}'."

    def tick(self) -> None:
        if self.mode is None or self.index >= len(self.steps):
            return
        if QApplication.activeModalWidget() is not None:
            # a message is open (e.g. "Bounds updated" after a calibration): the step that showed it isn't over
            # until it is answered -- going on meanwhile started the next steps underneath it
            return
        step = self.steps[self.index]
        if self.mode == "practise":
            done, hint = self.check(step)
            if done:
                self._advance(step)
            else:
                self._say(hint, WARN if hint else TEXT)
            return
        if not self.waiting or self.busy():
            return
        done, hint = self.check(step)
        self.waiting = False
        if not done:
            self.auto = False
            self._say(f"'{step.title}' didn't finish: " + (self._failed or hint) + " (The message below says more.)",
                      WARN)
            self._refresh()
            return
        self._advance(step)
        if self.auto and self.index < len(self.steps):
            QTimer.singleShot(400, self.do_step)

    def _advance(self, step: Step) -> None:
        self.ticked.add(step.key)
        self.index += 1
        if self.index >= len(self.steps):
            self._say("All done: that is the whole cube calibration. Exit puts back the calibration in use before; "
                      "Start goes through it again (try the other cube size, or 'Like the lab').", GOOD)
        else:
            self._say(f"✓ {step.title}. " + ("Next: " + self.steps[self.index].title + "."), GOOD)
        self._refresh()

    # ---- showing it ------------------------------------------------------------------------------------------------
    def _say(self, text: str, colour: str = TEXT) -> None:
        self.status.setText(f"<span style='color:{colour};'>{text}</span>")

    def _highlight(self, name: Optional[str]) -> None:
        if self._highlighted is not None:
            self._highlighted.setStyleSheet(self._highlight_style)
            self._highlighted = None
        button = getattr(self.panel, name, None) if name else None
        if button is not None:
            self._highlight_style = button.styleSheet()
            button.setStyleSheet(self._highlight_style + HIGHLIGHT)
            self._highlighted = button

    def _refresh(self) -> None:
        running = self.mode is not None
        for widget in (self.size_box, self.mode_box, self.speed_box, self.lab_box):
            widget.setEnabled(not running)
        self.start_btn.setVisible(not running)
        watch = self.mode == "watch"
        for widget in (self.next_btn, self.run_btn, self.repeat_btn):
            widget.setVisible(watch)
        self.exit_btn.setVisible(running)
        if not running:
            self.steps_label.setText(f"<span style='color:{MUTED};'>11 steps: home, touch the table twice, wrist to "
                                     "middle, grip, calibrate, pick test, fingers angle check, rotation pick test "
                                     "(off, then on), finish.</span>")
            self.detail.setVisible(False)
            self._highlight(None)
            return
        lines = []
        for n, step in enumerate(self.steps):
            mark, colour = (("✓", GOOD) if step.key in self.ticked else ("▶", TEXT) if n == self.index
                            else ("○", MUTED))
            lines.append(f"<span style='color:{colour};'>{mark} {n + 1}. {step.title}</span>")
        self.steps_label.setText("<br>".join(lines))
        if self.index >= len(self.steps):
            self.detail.setVisible(False)
            self._highlight(None)
            return
        step = self.steps[self.index]
        self.detail.setVisible(True)
        self.detail.setText(
            f"<b style='color:{TEXT};'>Step {self.index + 1} of {len(self.steps)} · {step.title}</b><br>"
            f"<span style='color:{TEXT};'><b>{'The demo will' if watch else 'Do'}:</b> {step.what}</span><br>"
            f"<span style='color:{MUTED};'><b>Why:</b> {step.why}</span><br>"
            f"<span style='color:#ffd166;'><b>Press:</b> {step.press}</span><br>"
            f"<span style='color:{GOOD};'><b>Good result:</b> {step.good}</span>")
        self.next_btn.setEnabled(not self.waiting)
        self.repeat_btn.setEnabled(not self.waiting and self.index > 0
                                   and self.steps[self.index - 1].key in REPEATABLE)
        self._highlight(step.button)


def _flow_row(column: QVBoxLayout) -> FlowLayout:
    row = QWidget()
    row.setObjectName("tourRow")
    row.setStyleSheet("#tourRow { background: transparent; }")   # (the group box's colour shows through)
    column.addWidget(row)
    return FlowLayout(row)


_DONE_KEYS = {"touch_far": "touch", "touch_near": "touch", "calibrate": "cube"}

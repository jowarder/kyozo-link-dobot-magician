"""Generic QThread wrapper for running blocking robot/LLM calls off the UI thread."""
from __future__ import annotations

from typing import Callable

from PyQt6.QtCore import QThread, pyqtSignal


_running: set = set()   # workers that have started and whose thread has not finished yet


class CallableWorker(QThread):
    finished_ok = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, fn: Callable, *args, **kwargs):
        super().__init__()
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        # A QThread object destroyed while its thread is still finishing makes Qt abort the whole
        # program. The result signal is sent just before run() returns, so whoever handles it may
        # drop their last reference at that very moment. So the worker keeps itself alive until
        # the thread has really ended.
        self.finished.connect(self._release)

    def start(self, *args, **kwargs) -> None:
        _running.add(self)
        super().start(*args, **kwargs)

    def _release(self) -> None:
        self.wait()   # the thread is done; this returns at once but makes sure it has fully exited
        _running.discard(self)

    def run(self) -> None:
        try:
            result = self.fn(*self.args, **self.kwargs)
        except Exception as exc:  # noqa: BLE001 - surface to UI via signal
            self.failed.emit(str(exc))
            return
        self.finished_ok.emit(result)


class PoseMonitorThread(QThread):
    """Continuously polls robot.get_pose() so the UI shows the live TCP position --
    including moves the UI didn't command itself, e.g. physically moving the arm
    by hand. Runs until stop() is called."""
    pose_updated = pyqtSignal(object)  # Pose
    error = pyqtSignal(str)

    def __init__(self, robot, poll_interval_s: float = 0.3):
        super().__init__()
        self.robot = robot
        self.poll_interval_s = poll_interval_s
        self._running = True

    def run(self) -> None:
        while self._running:
            try:
                pose = self.robot.get_pose()
                self.pose_updated.emit(pose)
            except Exception as exc:  # noqa: BLE001 - surface to UI, keep polling
                self.error.emit(str(exc))
            self.msleep(int(self.poll_interval_s * 1000))

    def stop(self) -> None:
        self._running = False

"""Watcher active: a recorded prompt has ended -- its name (pre-filled, never one already used) and, if you like, your
verdict and a note. Closed without saving, it is saved under the name suggested."""
from __future__ import annotations

from PyQt6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit, QVBoxLayout)

VERDICTS = (("No verdict", ""), ("Pass", "pass"), ("Fail", "fail"), ("Skip", "skip"))


class PromptNameDialog(QDialog):
    def __init__(self, parent, prompt: str, outcome: str, suggested: str):
        super().__init__(parent)
        self.setWindowTitle("Name this recorded prompt")
        self.suggested = suggested
        box = QVBoxLayout(self)
        said = QLabel(f"<b>“{prompt}”</b><br>Outcome: <b>{outcome}</b>. Everything about it is recorded; give it a name "
                      "to find it by (closing this keeps the name below).")
        said.setWordWrap(True)
        box.addWidget(said)
        form = QFormLayout()
        self.name = QLineEdit(suggested)
        self.name.selectAll()
        self.name.setToolTip("Letters, digits, - and _ (spaces become _). A name already used gets _2, _3...")
        self.verdict = QComboBox()
        for words, key in VERDICTS:
            self.verdict.addItem(words, key)
        self.note = QLineEdit()
        self.note.setPlaceholderText("Note (optional)")
        form.addRow("Task name", self.name)
        form.addRow("Your verdict", self.verdict)
        form.addRow("Note", self.note)
        box.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save)
        buttons.accepted.connect(self.accept)
        box.addWidget(buttons)
        self.resize(520, self.sizeHint().height())

    def answer(self) -> tuple[str, str, str]:
        """(name, verdict: "" / pass / fail / skip, note)."""
        return (self.name.text().strip() or self.suggested, self.verdict.currentData() or "", self.note.text())

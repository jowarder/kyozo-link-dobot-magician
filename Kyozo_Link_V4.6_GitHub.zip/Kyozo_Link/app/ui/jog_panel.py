"""Manual jog controls: step size, XYZ nudge buttons, gripper toggle, saved poses,
and a workspace-bounds editor (with "use current position" buttons for quickly
capturing safe limits while jogging).

Robot calls run on a background CallableWorker so the UI never freezes while
the (simulated or real) arm is moving.
"""
from __future__ import annotations

import json
import logging
import math
from pathlib import Path
from typing import Callable, Optional

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton, QLabel,
    QListWidget, QLineEdit, QGroupBox, QDoubleSpinBox, QMessageBox, QComboBox, QSpinBox,
)

from app.fileutil import atomic_write_text
from app.hardware.interfaces import Robot, Pose
from app import robots
from app.ui.worker import CallableWorker, PoseMonitorThread

logger = logging.getLogger(__name__)

DEFAULT_JOG_STEP_MM = 10.0
QUICK_STEPS_MM = (1.0, 5.0, 10.0)   # the step buttons beside the step box
DEFAULT_TURN_DEG = 15.0
_UNKNOWN = object()
# Speed of the arm (mm/s) and how long the app waits after a gripper command (s), as offered in the
# drop-downs. The configured value is added if it is not one of these.
SPEED_CHOICES = [("Very slow", 20.0), ("Slow", 50.0), ("Normal", 100.0), ("Fast", 150.0)]
GRIPPER_WAIT_CHOICES = [("Quick", 0.4), ("Normal", 0.8), ("Careful", 1.5), ("Extra careful", 2.5)]
MIN_BOUNDS_RANGE_MM = 20.0


class JogPanel(QWidget):
    def __init__(self, robot: Robot, poses_dir: Path, workspace_bounds: dict,
                 on_bounds_changed: Callable[[dict], None],
                 on_detect_floor: Optional[Callable[[], None]] = None,
                 on_setting_changed: Optional[Callable[[str, float], None]] = None,
                 on_pick_here: Optional[Callable[[], str]] = None,
                 on_gripper_opened: Optional[Callable[[], None]] = None,
                 on_gripper_closed: Optional[Callable[[], None]] = None,
                 arm_busy: Optional[Callable[[], Optional[str]]] = None, parent=None):
        """`on_pick_here()`: picks up the object under the gripper the way a prompt does (run off the UI thread; says
        what it did, raises with why not). `on_gripper_opened()`: the gripper was opened by hand (what it held is
        let go: the robot tools are told). `on_gripper_closed()`: it was closed by hand (the tools are told what it
        took hold of, when that is known). `arm_busy()`: why the arm is someone else's right now (a calibration step,
        a prompt, Camera setup...), or None: every button here that sends the robot a command asks it first."""
        super().__init__(parent)
        self.arm_busy = arm_busy
        self.on_pick_here = on_pick_here
        self.on_gripper_opened = on_gripper_opened
        self.on_gripper_closed = on_gripper_closed
        self.on_setting_changed = on_setting_changed   # (config key, value): to remember the choice
        self.robot = robot
        self.poses_dir = poses_dir
        self.poses_dir.mkdir(parents=True, exist_ok=True)
        self.on_bounds_changed = on_bounds_changed
        self.on_detect_floor = on_detect_floor
        self._workers: list[CallableWorker] = []

        layout = QVBoxLayout(self)

        self.pose_label = QLabel("x=--, y=--, z=--")
        self.pose_label.setStyleSheet("font-size: 14pt; font-weight: bold;")
        # (wrapped: one long line -- "Robot not available: <the error>" -- made the whole column wider than its
        # pane, and its right side was cut off: X+, Home, Clear Alarms, the bounds' Max)
        self.pose_label.setWordWrap(True)
        layout.addWidget(self.pose_label)
        self.error_label = QLabel("")   # why a move was refused or failed; clears itself
        self.error_label.setWordWrap(True)
        self.error_label.setStyleSheet("color: #ff8a8a;")
        self.error_label.hide()
        layout.addWidget(self.error_label)
        self._error_timer = QTimer(self)
        self._error_timer.setSingleShot(True)
        self._error_timer.timeout.connect(self.error_label.hide)
        self.info_label = QLabel("")    # what a gripper action did ("Holding the blue cube"); clears itself
        self.info_label.setWordWrap(True)
        self.info_label.setStyleSheet("color: #7fdcb0;")
        self.info_label.hide()
        layout.addWidget(self.info_label)
        self._info_timer = QTimer(self)
        self._info_timer.setSingleShot(True)
        self._info_timer.timeout.connect(self.info_label.hide)

        # Polls the real TCP position continuously (not just after commanded moves),
        # so physically moving the arm by hand shows up live too.
        self._pose_monitor = PoseMonitorThread(robot)
        self._pose_monitor.pose_updated.connect(self._on_pose_updated)
        self._pose_monitor.error.connect(self._on_pose_error)
        self._pose_monitor.start()

        jog_group = QGroupBox("Jog")
        jog_layout = QVBoxLayout(jog_group)

        step_row = QHBoxLayout()
        step_row.addWidget(QLabel("Step (mm):"))
        self.step_spinbox = QDoubleSpinBox()
        self.step_spinbox.setRange(0.1, 100.0)
        self.step_spinbox.setValue(DEFAULT_JOG_STEP_MM)
        self.step_spinbox.setSingleStep(1.0)
        step_row.addWidget(self.step_spinbox)
        # one click to a fine step, for lining the fingers up round an object
        for step in QUICK_STEPS_MM:
            button = QPushButton(f"{step:g}")
            button.setToolTip(f"Jog {step:g} mm at a time")
            # (the theme's 12 px side padding left 8 px of a 34 px button for the text: "10" came out "1(")
            button.setStyleSheet("padding: 6px 4px;")
            button.setFixedWidth(40)
            button.clicked.connect(lambda _checked=False, s=step: self.step_spinbox.setValue(s))
            step_row.addWidget(button)
        step_row.addStretch()
        jog_layout.addLayout(step_row)

        grid = QGridLayout()
        grid.addWidget(self._make_jog_button("Y+", 0, 1, 0), 0, 1)
        grid.addWidget(self._make_jog_button("X-", -1, 0, 0), 1, 0)
        grid.addWidget(self._make_jog_button("X+", 1, 0, 0), 1, 2)
        grid.addWidget(self._make_jog_button("Y-", 0, -1, 0), 2, 1)
        grid.addWidget(self._make_jog_button("Z+", 0, 0, 1), 0, 3)
        grid.addWidget(self._make_jog_button("Z-", 0, 0, -1), 2, 3)
        jog_layout.addLayout(grid)

        # the gripper's turn (the pose's r): R- / R+ by a step, within the wrist's range
        turn_row = QHBoxLayout()
        turn_row.addWidget(QLabel("Turn (°):"))
        self.turn_spinbox = QDoubleSpinBox()
        self.turn_spinbox.setRange(1.0, 90.0)
        self.turn_spinbox.setValue(DEFAULT_TURN_DEG)
        self.turn_spinbox.setSingleStep(5.0)
        turn_row.addWidget(self.turn_spinbox)
        for text, sign in (("R-", -1.0), ("R+", 1.0)):
            button = QPushButton(text)
            button.setToolTip("Turn the gripper (the fingers) by the step, about the vertical")
            button.clicked.connect(lambda _checked=False, s=sign: self._run_async(
                self._turn, s * self.turn_spinbox.value()))
            turn_row.addWidget(button)
        turn_row.addStretch()
        jog_layout.addLayout(turn_row)
        layout.addWidget(jog_group)

        gripper_row = QHBoxLayout()
        open_btn = QPushButton("Open Gripper")
        open_btn.clicked.connect(lambda: self._run_async(self._open, button=open_btn, busy_text="Opening..."))
        close_btn = QPushButton("Close Gripper")
        close_btn.clicked.connect(lambda: self._run_async(self._close, button=close_btn, busy_text="Closing...",
                                                          on_done=self._say))
        home_btn = QPushButton("Home")
        home_btn.clicked.connect(self._on_home_clicked)
        gripper_row.addWidget(open_btn)
        gripper_row.addWidget(close_btn)
        gripper_row.addWidget(home_btn)
        if self.on_pick_here is not None:
            pick_btn = QPushButton("Pick here")
            pick_btn.setToolTip("Pick up the object under the gripper (within about 4 cm), the way a prompt does: "
                                "the camera finds it, and the fingers are centred and turned to it")
            pick_btn.clicked.connect(lambda: self._run_async(self.on_pick_here, button=pick_btn, busy_text="Picking...",
                                                             on_done=self._say))
            gripper_row.addWidget(pick_btn)
        layout.addLayout(gripper_row)
        layout.addWidget(self._build_speed_group())

        if hasattr(self.robot, "enable_motors"):
            # the xArm's controller: its errors are cleared and its motors switched on from here (as in UFACTORY Studio)
            status_row = QHBoxLayout()
            for text, tip, action in (
                    ("Enable motors", "Switch the arm's motors on (after it was switched off, or a fault)",
                     self.robot.enable_motors),
                    ("Clear errors", "Clear the controller's error (after a collision, a joint limit...) and get it "
                                     "ready to move", self.robot.clear_errors),
                    ("Check errors", "Say what error the controller has, if any", None)):
                button = QPushButton(text)
                button.setToolTip(tip)
                if action is None:
                    button.clicked.connect(self._on_check_errors)
                else:
                    button.clicked.connect(lambda _checked=False, a=action, t=text: self._run_async(
                        a, on_done=lambda _r=None, t=t: self._say(f"{t}: done.")))
                status_row.addWidget(button)
            layout.addLayout(status_row)
        elif hasattr(self.robot, "get_alarms") and hasattr(self.robot, "clear_alarms"):
            alarm_row = QHBoxLayout()
            check_alarms_btn = QPushButton("Check Alarms")
            check_alarms_btn.clicked.connect(self._on_check_alarms)
            clear_alarms_btn = QPushButton("Clear Alarms")
            clear_alarms_btn.clicked.connect(self._on_clear_alarms)
            alarm_row.addWidget(check_alarms_btn)
            alarm_row.addWidget(clear_alarms_btn)
            layout.addLayout(alarm_row)
        if hasattr(self.robot, "reset_estop"):
            reset_estop_btn = QPushButton("Reset after E-STOP" if hasattr(self.robot, "enable_motors") else "Reset E-STOP")
            reset_estop_btn.clicked.connect(self._on_reset_estop)
            layout.addWidget(reset_estop_btn)

        poses_group = QGroupBox("Saved Poses")
        poses_layout = QVBoxLayout(poses_group)
        self.pose_list = QListWidget()
        poses_layout.addWidget(self.pose_list)
        save_row = QHBoxLayout()
        self.new_pose_name = QLineEdit()
        self.new_pose_name.setPlaceholderText("pose name")
        save_btn = QPushButton("Save current")
        save_btn.clicked.connect(self._save_pose)
        go_btn = QPushButton("Go to selected")
        go_btn.clicked.connect(self._go_to_selected)
        save_row.addWidget(self.new_pose_name)
        save_row.addWidget(save_btn)
        poses_layout.addLayout(save_row)
        poses_layout.addWidget(go_btn)
        layout.addWidget(poses_group)

        layout.addWidget(self._build_bounds_group(workspace_bounds))

        layout.addStretch()
        self._reload_poses()
        self.refresh_pose_label()

    # ---- speed and gripper timing --------------------------------------------
    def _build_speed_group(self) -> QGroupBox:
        group = QGroupBox("Speed")
        grid = QGridLayout(group)
        grid.addWidget(QLabel("Arm speed:"), 0, 0)
        self.speed_combo = self._make_choice_combo(SPEED_CHOICES, getattr(self.robot, "max_speed", None),
                                                   "{:.0f} mm/s", "Configured")
        self.speed_combo.setToolTip("How fast the arm moves: jogging, click-to-move, prompts and calibration sweeps. "
                                    "Slow is gentler and safer while you are learning the setup.")
        self.speed_combo.currentIndexChanged.connect(self._on_speed_chosen)
        grid.addWidget(self.speed_combo, 0, 1)
        self.gripper_combo = self._make_choice_combo(GRIPPER_WAIT_CHOICES, getattr(self.robot, "gripper_settle_s", None),
                                                     "{:.1f} s", "Configured")
        self.gripper_combo.setToolTip(
            "The Dobot gripper / suction cup has no speed control: it is only on or off. What can be set is how long "
            "the app waits after opening or closing it before moving on, so the air has time to build up or drain. "
            "If a picked object is dropped while lifting, choose a longer wait.")
        if getattr(self.robot, "gripper_settle_s", None) is None:
            self.gripper_combo.clear()
            self.gripper_combo.addItem("Instant (simulated gripper)", 0.0)
            self.gripper_combo.setEnabled(False)
            self.gripper_combo.setToolTip("The simulated gripper acts instantly, so there is nothing to wait for. "
                                          "On the real robot this sets how long the app waits after opening or closing it.")
        self.gripper_combo.currentIndexChanged.connect(self._on_gripper_wait_chosen)
        if robots.active().key == "xarm6":
            self._add_xarm_settings(grid)        # its gripper has a motor: how far it opens, how fast; no air to wait for
        else:
            grid.addWidget(QLabel("Gripper wait:"), 1, 0)
            grid.addWidget(self.gripper_combo, 1, 1)
        grid.setColumnStretch(1, 1)
        return group

    def _add_xarm_settings(self, grid: QGridLayout) -> None:
        """The xArm's own settings: how far the gripper opens (and how fast, on the real one), and how hard a knock
        stops the arm (its collision detection)."""
        grid.addWidget(QLabel("Gripper opens:"), 1, 0)
        self.opening_spin = QSpinBox()
        self.opening_spin.setRange(10, 86)
        self.opening_spin.setSuffix(" mm")
        spec = getattr(self.robot, "gripper", None)
        opening = getattr(self.robot, "opening_mm", None) or (spec.opening_mm if spec is not None else 40.0)
        self.opening_spin.setValue(int(round(opening)))
        self.opening_spin.setToolTip(
            "How far the fingers open to pick and let go (up to 86 mm). Wider takes bigger objects, but the open "
            "fingers need more room: at 40 mm they just fit in the demo's 72 mm tray. Objects are picked up to "
            "3 mm narrower than this.")
        self.opening_spin.editingFinished.connect(
            lambda: self.on_setting_changed("gripper_opening_mm", float(self.opening_spin.value()))
            if self.on_setting_changed is not None else None)
        grid.addWidget(self.opening_spin, 1, 1)
        if hasattr(self.robot, "set_gripper_speed"):
            grid.addWidget(QLabel("Gripper speed:"), 2, 0)
            self.gripper_speed_combo = self._make_choice_combo(
                (("Slow", 1000.0), ("Normal", 2000.0), ("Fast", 3500.0), ("Fastest", 5000.0)),
                float(getattr(self.robot, "gripper_speed", 2000)), "{:.0f} r/min", "Configured")
            self.gripper_speed_combo.setToolTip("How fast the fingers close and open (the gripper motor's speed). "
                                                "The xArm Gripper has no separate force setting.")
            self.gripper_speed_combo.currentIndexChanged.connect(lambda i: self._apply_choice(
                self.gripper_speed_combo, i, self.robot.set_gripper_speed, "gripper_speed", "gripper speed"))
            grid.addWidget(self.gripper_speed_combo, 2, 1)
        if hasattr(self.robot, "set_collision_sensitivity"):
            grid.addWidget(QLabel("Collision stop:"), 3, 0)
            self.collision_combo = self._make_choice_combo(
                (("Off", 0.0), ("Least sensitive", 1.0), ("Low", 2.0), ("Medium", 3.0), ("High", 4.0),
                 ("Most sensitive", 5.0)), float(getattr(self.robot, "collision_sensitivity", 3)), "{:.0f}", "Configured")
            self.collision_combo.setToolTip(
                "How hard a knock makes the arm stop by itself (the controller's collision detection). More sensitive "
                "stops sooner, but may stop on a fast move with nothing there. Off is not recommended.")
            self.collision_combo.currentIndexChanged.connect(lambda i: self._apply_choice(
                self.collision_combo, i, self.robot.set_collision_sensitivity, "collision_sensitivity",
                "collision sensitivity"))
            grid.addWidget(self.collision_combo, 3, 1)

    def _on_check_errors(self) -> None:
        try:
            words = self.robot.describe_error()
        except Exception as exc:  # noqa: BLE001 - report, don't crash
            QMessageBox.warning(self, "Check errors failed", str(exc))
            return
        QMessageBox.information(self, "Controller errors", words or "No errors.")

    @staticmethod
    def _make_choice_combo(choices, current, unit: str, extra_name: str) -> QComboBox:
        """A drop-down of (name, value) choices with the value in brackets, on the one nearest `current`."""
        combo = QComboBox()
        options = list(choices)
        if current is not None and all(abs(v - current) > 1e-6 for _, v in options):
            options.append((extra_name, float(current)))
            options.sort(key=lambda item: item[1])
        for name, value in options:
            combo.addItem(f"{name} ({unit.format(value)})", value)
        if current is not None:
            combo.setCurrentIndex(min(range(len(options)), key=lambda i: abs(options[i][1] - current)))
        combo._applied = combo.currentIndex()       # what the robot is using now, to go back to if it refuses a change
        return combo

    def _on_speed_chosen(self, index: int) -> None:
        self._apply_choice(self.speed_combo, index, self.robot.set_speed, "max_speed", "speed")

    def _on_gripper_wait_chosen(self, index: int) -> None:
        def apply(seconds: float) -> None:
            self.robot.gripper_settle_s = float(seconds)
        self._apply_choice(self.gripper_combo, index, apply, "gripper_settle_s", "gripper wait")

    def _apply_choice(self, combo: QComboBox, index: int, apply: Callable[[float], None], key: str, what: str) -> None:
        """Applies a drop-down choice off the UI thread; if the robot refuses, puts the drop-down back."""
        value = float(combo.itemData(index))
        previous = combo._applied
        worker = CallableWorker(apply, value)
        self._workers.append(worker)

        def done(_=None):
            self._workers.remove(worker) if worker in self._workers else None
            combo._applied = index
            if self.on_setting_changed is not None:
                self.on_setting_changed(key, value)

        def failed(message: str):
            self._workers.remove(worker) if worker in self._workers else None
            self._show_robot_error(f"Could not change the {what}: {message}")
            combo.blockSignals(True)
            combo.setCurrentIndex(previous)
            combo.blockSignals(False)

        worker.finished_ok.connect(done)
        worker.failed.connect(failed)
        worker.start()

    # ---- jog / gripper / poses --------------------------------------------
    def _turn(self, delta: float) -> None:
        """Turn the gripper by `delta` degrees where it is, if the wrist (the Dobot's J4 = r - J1; the xArm's r
        itself) has the room."""
        pose = self.robot.get_pose()
        r = pose.r + delta
        robot = robots.active()
        wrist = robot.tool_turn(pose.x, pose.y, r)
        low, high = robot.tool_turn_limits_deg
        if not low + 1.0 <= wrist <= high - 1.0:
            name = "J4" if robot.tool_turn_relative else "the tool's turn"
            raise ValueError(f"The wrist can't turn further this way: {name} would be {wrist:+.0f}° (its range is "
                             f"{low:+.0f}° to {high:+.0f}°). Turn it the other way.")
        self.robot.move_to(Pose(x=pose.x, y=pose.y, z=pose.z, r=r))

    def _open(self) -> None:
        self.robot.open_gripper()
        if self.on_gripper_opened is not None:
            self.on_gripper_opened()

    def _close(self) -> str:
        """Close, and say what it holds, or why nothing (the demo knows; the real gripper has no sensor for it)."""
        self.robot.close_gripper()
        if self.on_gripper_closed is not None:
            self.on_gripper_closed()
        held = getattr(self.robot, "held_object", _UNKNOWN)
        if held is _UNKNOWN:
            return ""
        if held is None:
            why = getattr(self.robot, "last_grip_problem", "") or "nothing between the fingers"
            return f"!Closed on nothing: {why}."
        world = getattr(self.robot, "world", None)
        label = world.object_meta[held]["label"] if world is not None and held in world.object_meta else held
        return f"Holding the {label}."

    def _say(self, message) -> None:
        """A gripper action's message: in green, or red when it starts with "!"."""
        if not message:
            return
        text = str(message)
        if text.startswith("!"):
            self._show_robot_error(text[1:])
            return
        self.info_label.setText(text)
        self.info_label.show()
        self._info_timer.start(12000)

    def _make_jog_button(self, text: str, ux: float, uy: float, uz: float) -> QPushButton:
        btn = QPushButton(text)
        btn.clicked.connect(lambda: self._jog(ux * self.step_spinbox.value(), uy * self.step_spinbox.value(),
                                              uz * self.step_spinbox.value()))
        return btn

    def _jog(self, dx: float, dy: float, dz: float) -> None:
        """Jog by a step. Where the workspace bounds stop it short, say so: the arm just stopped, without a word,
        above a table it had to reach (Z min was 39 mm up), and it looked broken."""
        pose = getattr(self, "_last_pose", None)
        clamp = getattr(self.robot, "clamp_pose", None)
        if pose is not None and clamp is not None:
            wanted = Pose(x=pose.x + dx, y=pose.y + dy, z=pose.z + dz, r=pose.r)
            allowed = clamp(wanted)
            if dz < 0 and allowed.z > wanted.z + 0.5:
                self._show_robot_error(f"Z min ({allowed.z:.1f} mm) stops it here. To go lower, set Z min lower in "
                                       "Workspace Bounds below (carefully: it is the floor that keeps the tip off "
                                       "the table).")
            elif dz > 0 and allowed.z < wanted.z - 0.5:
                self._show_robot_error(f"Z max ({allowed.z:.1f} mm) stops it here.")
            elif (dx or dy) and abs(allowed.x - wanted.x) + abs(allowed.y - wanted.y) > 0.5:
                self._show_robot_error("The edge of the workspace (its bounds, or the arm's reach) stops it here.")
        self._run_async(self.robot.jog, dx, dy, dz)

    def _run_async(self, fn, *args, button: Optional[QPushButton] = None, busy_text: str = "",
                   on_done: Optional[Callable] = None) -> None:
        """Runs a robot command off the UI thread. With `button`, that button shows `busy_text` and is
        disabled until the command is done, so a slow command visibly is being worked on (and a second
        click doesn't queue a second one). Refused, saying why, while the arm is someone else's (arm_busy)."""
        if self._refused():
            return
        worker = CallableWorker(fn, *args)
        self._workers.append(worker)
        label = button.text() if button is not None else ""
        if button is not None:
            button.setEnabled(False)
            button.setText(busy_text or label)

        def _cleanup(w=worker):
            if w in self._workers:
                self._workers.remove(w)
            if button is not None:
                button.setText(label)
                button.setEnabled(True)

        worker.finished_ok.connect(lambda result: (self.refresh_pose_label(), _cleanup(),
                                                   on_done(result) if on_done is not None else None))
        worker.failed.connect(lambda msg: (self._show_robot_error(msg), _cleanup()))
        worker.start()

    def _refused(self) -> bool:
        """True (and why, shown where a refused move's reason is) while the arm is someone else's."""
        why = self.arm_busy() if self.arm_busy is not None else None
        if why:
            self.error_label.setText(f"Not now: {why}.")
            self.error_label.show()
            self._error_timer.start(10000)
            return True
        return False

    def _show_robot_error(self, message: str) -> None:
        logger.error("Robot command failed: %s", message)
        self.error_label.setText(f"Robot: {message}")
        self.error_label.show()
        self._error_timer.start(10000)

    def refresh_pose_label(self) -> None:
        # The background PoseMonitorThread keeps this fresh continuously; this is
        # just an immediate update right after a commanded move completes.
        try:
            pose = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001 - robot may be disconnected (live mode)
            self._on_pose_error(str(exc))
            return
        self._on_pose_updated(pose)

    def _on_pose_updated(self, pose: Pose) -> None:
        self._last_pose = pose
        self.pose_label.setText(f"x={pose.x:.1f}  y={pose.y:.1f}  z={pose.z:.1f}  r={pose.r:.1f}")

    def _on_pose_error(self, message: str) -> None:
        self.pose_label.setText(f"Robot not available: {message}")

    def stop_pose_monitor(self) -> None:
        self._pose_monitor.stop()
        self._pose_monitor.wait(1000)

    def _on_home_clicked(self) -> None:
        if self._refused():
            return
        reply = QMessageBox.question(
            self, "Home robot",
            "This moves the arm through its full homing sequence (~15-20s). "
            "Make sure the area around the robot is clear.\n\nProceed?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self._run_async(self.robot.home)

    def _on_check_alarms(self) -> None:
        try:
            alarms = self.robot.get_alarms()
        except Exception as exc:  # noqa: BLE001 - report, don't crash
            QMessageBox.warning(self, "Check alarms failed", str(exc))
            return
        active = any(b != 0 for b in alarms)
        QMessageBox.information(
            self, "Alarm status",
            f"{'ALARM ACTIVE' if active else 'No alarms'}\nraw: {list(alarms)}",
        )

    def _on_clear_alarms(self) -> None:
        try:
            self.robot.clear_alarms()
        except Exception as exc:  # noqa: BLE001 - report, don't crash
            QMessageBox.warning(self, "Clear alarms failed", str(exc))
            return
        QMessageBox.information(
            self, "Alarms cleared",
            "Sent the clear-alarms command. If the arm still won't move, some "
            "hardware fault states only reset via a physical power cycle.",
        )

    def _on_reset_estop(self) -> None:
        try:
            self.robot.reset_estop()
        except Exception as exc:  # noqa: BLE001 - report, don't crash
            QMessageBox.warning(self, "Reset E-STOP failed", str(exc))
            return
        QMessageBox.information(self, "E-STOP reset", "Robot motion re-enabled.")

    def _save_pose(self) -> None:
        name = self.new_pose_name.text().strip()
        if not name:
            return
        pose = self.robot.get_pose()
        path = self.poses_dir / f"{name}.json"
        atomic_write_text(path, json.dumps({"x": pose.x, "y": pose.y, "z": pose.z, "r": pose.r}))
        self.new_pose_name.clear()
        self._reload_poses()

    def _reload_poses(self) -> None:
        self.pose_list.clear()
        for path in sorted(self.poses_dir.glob("*.json")):
            self.pose_list.addItem(path.stem)

    def _go_to_selected(self) -> None:
        item = self.pose_list.currentItem()
        if item is None:
            return
        path = self.poses_dir / f"{item.text()}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        # (only the pose: a place may also say its size or that it is a printed spot)
        self._run_async(self.robot.move_to, Pose(**{k: data[k] for k in ("x", "y", "z", "r") if k in data}))

    # ---- workspace bounds ---------------------------------------------------
    def _build_bounds_group(self, workspace_bounds: dict) -> QGroupBox:
        group = QGroupBox("Workspace Bounds (safety, mm)")
        grid = QGridLayout(group)
        self._bound_fields: dict[str, QDoubleSpinBox] = {}

        grid.addWidget(QLabel(""), 0, 0)
        grid.addWidget(QLabel("Min"), 0, 1)
        grid.addWidget(QLabel(""), 0, 2)
        grid.addWidget(QLabel("Max"), 0, 3)
        grid.addWidget(QLabel(""), 0, 4)

        for row, axis in enumerate(("x", "y", "z"), start=1):
            lo, hi = workspace_bounds.get(axis, [-1000, 1000])
            grid.addWidget(QLabel(axis.upper()), row, 0)

            min_field = self._make_bounds_spinbox(lo)
            grid.addWidget(min_field, row, 1)
            min_btn = QPushButton("Use current")
            min_btn.clicked.connect(lambda _, a=axis, f=min_field: self._use_current_for(a, f))
            grid.addWidget(min_btn, row, 2)

            max_field = self._make_bounds_spinbox(hi)
            grid.addWidget(max_field, row, 3)
            max_btn = QPushButton("Use current")
            max_btn.clicked.connect(lambda _, a=axis, f=max_field: self._use_current_for(a, f))
            grid.addWidget(max_btn, row, 4)

            self._bound_fields[f"{axis}_min"] = min_field
            self._bound_fields[f"{axis}_max"] = max_field

        if self.on_detect_floor is not None:
            detect_btn = QPushButton("Detect table height (sets Z min automatically)")
            detect_btn.setToolTip("Measures the table with the depth camera, using your calibration. "
                                  "The arm does not move.")
            detect_btn.clicked.connect(self.on_detect_floor)
            grid.addWidget(detect_btn, 4, 0, 1, 5)

        apply_btn = QPushButton("Apply && Save")
        apply_btn.clicked.connect(self._apply_bounds)
        grid.addWidget(apply_btn, 5, 0, 1, 5)

        return group

    def set_z_min(self, value: float) -> None:
        """Fill in the Z floor and apply/save it like a normal bounds change."""
        self._bound_fields["z_min"].setValue(value)
        self._apply_bounds()

    def _make_bounds_spinbox(self, value: float) -> QDoubleSpinBox:
        spin = QDoubleSpinBox()
        spin.setRange(-2000.0, 2000.0)
        spin.setDecimals(1)
        spin.setValue(value)
        return spin

    def _use_current_for(self, axis: str, field: QDoubleSpinBox) -> None:
        try:
            pose = self.robot.get_pose()
        except Exception as exc:  # noqa: BLE001 - robot may be disconnected
            QMessageBox.warning(self, "Robot not available", str(exc))
            return
        field.setValue(getattr(pose, axis))

    def _apply_bounds(self) -> None:
        bounds = {
            "x": [self._bound_fields["x_min"].value(), self._bound_fields["x_max"].value()],
            "y": [self._bound_fields["y_min"].value(), self._bound_fields["y_max"].value()],
            "z": [self._bound_fields["z_min"].value(), self._bound_fields["z_max"].value()],
        }
        narrow_axes = []
        for axis, (lo, hi) in bounds.items():
            if lo >= hi:
                QMessageBox.warning(self, "Invalid bounds",
                                     f"{axis.upper()} min ({lo}) must be less than max ({hi}).")
                return
            if hi - lo < MIN_BOUNDS_RANGE_MM:
                narrow_axes.append(f"{axis.upper()}: {lo:.1f} to {hi:.1f} ({hi - lo:.1f} mm)")

        if narrow_axes:
            reply = QMessageBox.warning(
                self, "Unusually narrow bounds",
                "These axes have a range under " + f"{MIN_BOUNDS_RANGE_MM:.0f} mm, which will make the "
                "arm appear stuck (almost every move gets clamped back to nearly the same point):\n\n"
                + "\n".join(narrow_axes) +
                "\n\nThis is usually a mistake -- e.g. 'Use current' was clicked while the arm was "
                "mid-motion. Apply anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        if hasattr(self.robot, "bounds"):
            self.robot.bounds = bounds  # takes effect immediately, no restart needed
        self.on_bounds_changed(bounds)   # may adjust `bounds` in place (e.g. the demo's own table floor)
        for axis in ("x", "y", "z"):
            self._bound_fields[f"{axis}_min"].setValue(bounds[axis][0])
            self._bound_fields[f"{axis}_max"].setValue(bounds[axis][1])
        QMessageBox.information(self, "Bounds updated",
                                 "Workspace bounds applied and saved to config.yaml.")

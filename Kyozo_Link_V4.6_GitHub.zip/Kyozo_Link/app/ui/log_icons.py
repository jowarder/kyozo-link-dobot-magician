"""Small line icons for the Prompt tab's log, drawn here (no icon files): each line of the conversation starts with
one, in the line's own colour, so your prompts, the robot's steps, its reply and errors are told apart at a glance.

`icon(document, name, colour)` registers the icon with the log's QTextDocument (once per name and colour) and returns
the <img> tag to put in front of the line."""
from __future__ import annotations

from PyQt6.QtCore import QByteArray, QRectF, QUrl, Qt
from PyQt6.QtGui import QImage, QPainter, QTextDocument
from PyQt6.QtSvg import QSvgRenderer

SIZE_PX = 15          # as shown, beside 9-10 pt text
PIXELS = 48           # drawn this big and scaled down: sharp on a high-resolution screen too

# 24 x 24 outline drawings, stroked in the line's colour
SHAPES = {
    "you": '<circle cx="12" cy="8" r="4"/><path d="M5 20c0-3.9 3.1-6.5 7-6.5s7 2.6 7 6.5"/>',
    "wait": '<path d="M7 3h10M7 21h10M8 3c0 4.5 8 4.5 8 9s-8 4.5-8 9M16 3c0 4.5-8 4.5-8 9s8 4.5 8 9"/>',
    "look": '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    "pick": '<path d="M8 11V5.5a1.5 1.5 0 0 1 3 0V10M11 9.5V4a1.5 1.5 0 0 1 3 0v6M14 10V5.5a1.5 1.5 0 0 1 3 0V12'
            'M17 8.5a1.5 1.5 0 0 1 3 0V14a7 7 0 0 1-7 7h-1.5a6 6 0 0 1-5.1-2.8L4 14.6a1.6 1.6 0 0 1 2.6-1.8L8 14.5V11"/>',
    "place": '<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>',
    "move": '<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>',
    "refused": '<circle cx="12" cy="12" r="9"/><path d="M5.7 5.7l12.6 12.6"/>',
    "robot": '<rect x="5" y="8" width="14" height="11" rx="2"/><path d="M12 8V5M10 4h4"/>'
             '<circle cx="9.5" cy="13" r="1"/><circle cx="14.5" cy="13" r="1"/><path d="M10 16.5h4M3 12v3M21 12v3"/>',
    "error": '<circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5v.5"/>',
    "stopped": '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
    "info": '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.5v.5"/>',
}


def _render(name: str, colour: str) -> QImage:
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="{colour}" '
           f'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{SHAPES[name]}</svg>')
    image = QImage(PIXELS, PIXELS, QImage.Format.Format_ARGB32_Premultiplied)
    image.fill(Qt.GlobalColor.transparent)
    painter = QPainter(image)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(painter, QRectF(0, 0, PIXELS, PIXELS))
    painter.end()
    return image


def icon(document: QTextDocument, name: str, colour: str) -> str:
    """The <img> tag for icon `name` in `colour` ("#rrggbb"), registered with `document` the first time."""
    url = f"icon://{name}/{colour.lstrip('#')}"
    if document.resource(QTextDocument.ResourceType.ImageResource.value, QUrl(url)) is None:
        document.addResource(QTextDocument.ResourceType.ImageResource.value, QUrl(url), _render(name, colour))
    return f'<img src="{url}" width="{SIZE_PX}" height="{SIZE_PX}" style="vertical-align: middle;">'

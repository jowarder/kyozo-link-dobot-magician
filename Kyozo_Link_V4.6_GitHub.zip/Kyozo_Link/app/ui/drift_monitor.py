"""Keeps the camera reference for the current calibration, and checks against it.

Runs the slow work (several camera frames, feature matching) off the UI thread and reports
back with a signal. See app/vision/drift.py for what is compared.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable, Optional

import numpy as np
from PyQt6.QtCore import QObject, pyqtSignal

from app.ui.worker import CallableWorker
from app.vision.drift import DriftReport, ViewReference, capture_reference, check_view

logger = logging.getLogger(__name__)


class DriftMonitor(QObject):
    report_ready = pyqtSignal(object)   # DriftReport
    reference_saved = pyqtSignal()
    capture_failed = pyqtSignal(str)    # the view couldn't be remembered: why

    def __init__(self, camera, get_transform: Callable[[], np.ndarray], reference_file: Optional[Path],
                 parent=None):
        """`reference_file`: where the reference is kept between runs, or None to keep it in
        memory only (the demo starts from a perfect view every time)."""
        super().__init__(parent)
        self.camera = camera
        self.get_transform = get_transform
        self.reference_file = reference_file
        self.reference: Optional[ViewReference] = ViewReference.load(reference_file) if reference_file else None
        self._workers: list[CallableWorker] = []
        self._capturing = False
        self._capture_again = False
        self._checking = False
        self._check_again = False

    @property
    def has_reference(self) -> bool:
        return self.reference is not None

    # ---- remembering the view -----------------------------------------------------------------------
    def capture(self) -> None:
        """Remember what the camera sees now, through the calibration now in use. If the
        calibration changes while this runs, it is run again so the two always match."""
        if self._capturing:
            self._capture_again = True
            return
        self._capturing = True
        transform = self.get_transform().copy()
        self._run(lambda: capture_reference(self.camera, transform),
                  lambda reference: self._captured(reference, transform), self._capture_failed)

    def _captured(self, reference: ViewReference, transform: np.ndarray) -> None:
        self._capturing = False
        if self._capture_again or not np.allclose(transform, self.get_transform()):
            self._capture_again = False
            self.capture()   # the calibration changed underneath us; this reference would not match it
            return
        self.reference = reference
        if self.reference_file is not None:
            try:
                reference.save(self.reference_file)
            except OSError:
                logger.warning("Could not save the camera reference", exc_info=True)
        self.reference_saved.emit()

    def _capture_failed(self, message: str) -> None:
        self._capturing = False
        logger.warning("Could not capture the camera reference: %s", message)
        self.capture_failed.emit(message)

    # ---- checking ----------------------------------------------------------------------------------------
    @property
    def checking(self) -> bool:
        return self._checking

    def check(self) -> None:
        """Compare now. One check runs at a time: asking again while one is running just makes it
        run once more when it ends, so rapid requests can't pile up threads all rendering and
        matching pictures at once."""
        if self.reference is None:
            self.report_ready.emit(DriftReport(
                "unknown", "There is no saved reference view to compare with yet. It is saved when you finish "
                           "a calibration, or press 'Remember this view as calibrated'."))
            return
        if self._checking:
            self._check_again = True
            return
        self._checking = True
        reference, transform = self.reference, self.get_transform().copy()
        self._run(lambda: check_view(self.camera, transform, reference), self._check_done,
                  lambda message: self._check_done(DriftReport("unknown", f"Could not check: {message}")))

    def _check_done(self, report: DriftReport) -> None:
        self._checking = False
        again, self._check_again = self._check_again, False
        if again:
            self.check()          # what the camera sees may have changed since; the newest result is the one shown
        else:
            self.report_ready.emit(report)

    def check_now(self) -> DriftReport:
        """Synchronous version, for tests and scripts."""
        if self.reference is None:
            return DriftReport("unknown", "no reference")
        return check_view(self.camera, self.get_transform(), self.reference)

    def shutdown(self) -> None:
        """Wait (briefly) for anything still running, so the window can close cleanly."""
        for worker in list(self._workers):
            worker.wait(5000)

    # ---- plumbing ---------------------------------------------------------------------------------------------
    def _run(self, work: Callable, on_done: Callable, on_fail: Callable) -> None:
        worker = CallableWorker(work)
        self._workers.append(worker)

        def finish(handler):
            def wrapper(value):
                if worker in self._workers:
                    self._workers.remove(worker)
                handler(value)
            return wrapper
        worker.finished_ok.connect(finish(on_done))
        worker.failed.connect(finish(on_fail))
        worker.start()

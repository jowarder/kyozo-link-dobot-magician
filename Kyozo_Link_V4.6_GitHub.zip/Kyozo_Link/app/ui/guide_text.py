"""Instructions that wrap properly at any display scaling, and grow to show all their text.

A word-wrapped QLabel measures its lines with one set of font metrics and draws them with another when Windows
scales the display by a fraction (150%): the ends of long lines were cut off, on the right and sometimes on the
left. A text document lays out and draws with the same metrics, so nothing is clipped. This one has no frame and
no scroll bar of its own: it is exactly as tall as its text, inside the panel that scrolls.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFrame, QSizePolicy, QTextBrowser

from app.ui.theme import ACCENT, MUTED, TEXT

STYLE = f"""
body {{ color: {TEXT}; }}
h4 {{ color: {ACCENT}; margin-top: 10px; margin-bottom: 3px; font-size: 100%; }}
p {{ margin-top: 2px; margin-bottom: 4px; }}
ul, ol {{ margin-top: 0px; margin-bottom: 4px; margin-left: 2px; -qt-list-indent: 1; }}
li {{ margin-bottom: 3px; }}
.muted {{ color: {MUTED}; }}
"""


class GuideText(QTextBrowser):
    def __init__(self, html: str, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setOpenLinks(False)
        self.setStyleSheet("QTextBrowser { background: transparent; border: none; }")
        self.viewport().setAutoFillBackground(False)
        self.document().setDefaultStyleSheet(STYLE)
        self.document().setDocumentMargin(2)
        self.setHtml(html)
        self.document().documentLayout().documentSizeChanged.connect(lambda _size: self._fit())

    def _fit(self) -> None:
        height = int(self.document().size().height()) + 4
        if height != self.height():
            self.setFixedHeight(height)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.document().setTextWidth(self.viewport().width())
        self._fit()

    def wheelEvent(self, event) -> None:
        event.ignore()          # the panel round it scrolls, not this (it shows all its text anyway)

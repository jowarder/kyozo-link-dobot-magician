"""Top-down map of where the calibration points are, with empty areas highlighted."""
from __future__ import annotations

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QColor, QFont, QPainter, QPen
from PyQt6.QtWidgets import QWidget

from app.calibration.guidance import Cell, covered_cells


class CoverageMap(QWidget):
    """Robot base at the bottom, away from it at the top, +Y to the left (a top-down view of a
    right-handed frame with x pointing away from you)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(170)
        self._cells: list[Cell] = []
        self._points: list[tuple[float, float]] = []
        self._suspects: set[int] = set()

    def set_state(self, cells: list[Cell], points_xy: list[tuple[float, float]], suspects: list[int]) -> None:
        self._cells, self._points, self._suspects = cells, points_xy, set(suspects)
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor("#0c1824"))
        if not self._cells:
            painter.setPen(QColor("#9fb4c4"))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No workspace area to show")
            return

        x0 = min(c.x0 for c in self._cells)
        x1 = max(c.x1 for c in self._cells)
        y0 = min(c.y0 for c in self._cells)
        y1 = max(c.y1 for c in self._cells)
        margin = 22.0
        box = QRectF(margin, 8, self.width() - 2 * margin, self.height() - 8 - margin)

        def to_screen(x: float, y: float) -> QPointF:
            # +Y to the left, +X (away from the robot) up
            sx = box.right() - (y - y0) / (y1 - y0) * box.width()
            sy = box.bottom() - (x - x0) / (x1 - x0) * box.height()
            return QPointF(sx, sy)

        covered = covered_cells(self._cells, self._points)
        for cell in self._cells:
            a, b = to_screen(cell.x0, cell.y1), to_screen(cell.x1, cell.y0)
            rect = QRectF(a.x(), b.y(), b.x() - a.x(), a.y() - b.y()).normalized()
            if not cell.usable:
                painter.setPen(QPen(QColor(60, 75, 88), 1))
                painter.setBrush(QColor(20, 32, 44))
            elif (cell.row, cell.col) in covered:
                painter.setPen(QPen(QColor(60, 120, 115), 1))
                painter.setBrush(QColor(28, 68, 66, 160))
            else:
                painter.setPen(QPen(QColor(245, 167, 66), 1.5, Qt.PenStyle.DashLine))
                painter.setBrush(QColor(245, 167, 66, 35))
            painter.drawRect(rect)
            if cell.usable and (cell.row, cell.col) not in covered:
                painter.setPen(QColor(245, 167, 66))
                painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "+")

        for index, (x, y) in enumerate(self._points):
            p = to_screen(x, y)
            suspect = index in self._suspects
            painter.setBrush(QColor("#ff6b6b") if suspect else QColor("#4dd8c8"))
            painter.setPen(QPen(QColor("white"), 1.2))
            painter.drawEllipse(p, 5.5, 5.5)
            painter.setPen(QColor("white"))
            small = QFont(self.font())
            small.setPointSize(7)
            painter.setFont(small)
            painter.drawText(QPointF(p.x() + 7, p.y() - 4), str(index + 1))

        painter.setPen(QColor(150, 175, 195))
        painter.drawText(QPointF(margin, self.height() - 6), "robot base (bottom)")
        painter.drawText(QPointF(box.right() - 46, self.height() - 6), "+X is up")

"""Runs the continuous calibration (app/calibration/continuous.py) in the app: a look every CHECK_EVERY_S while the arm is
idle, off the UI thread; what each look decided, said; corrections handed to the main window to use and save.

The calibration is the one in use when it starts (a cube calibration, say): from then on it is kept right. A new
calibration made any other way (the Calibration tab, an earlier one gone back to, cleared) ends it -- its reference
belonged to the old one -- and it is started again by hand. It carries on after the app is closed and opened again.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Callable, Optional

import numpy as np
from PyQt6.QtCore import QObject, QTimer, pyqtSignal

from app.calibration import continuous as cc
from app.ui.worker import CallableWorker

logger = logging.getLogger(__name__)

WARN_AGAIN_S = 300.0     # the same warning written to the app's log at most this often


class ContinuousCalibration(QObject):
    status = pyqtSignal(str, str)      # (what it is doing, in words; tone: "", "good", "warn", "bad")

    def __init__(self, camera, calibration_file: Path, get_transform: Callable[[], np.ndarray],
                 apply_transform: Callable[[np.ndarray, str, dict], None],
                 can_check: Callable[[], Optional[str]], corners: Callable, has_calibration: Callable[[], bool],
                 parent=None):
        """`apply_transform(T, action, record)`: use T from now on (and save it). `can_check()`: why not to look now
        (the arm busy, a watcher run under way), or None. `corners(frame, intrinsics, T)`: the sheet's corners in the
        camera's coordinates, or (None, why). `has_calibration()`: a real calibration is in use."""
        super().__init__(parent)
        self.camera = camera
        self.calibration_file = Path(calibration_file)
        self.get_transform = get_transform
        self.apply_transform = apply_transform
        self.can_check = can_check
        self.corners = corners
        self.has_calibration = has_calibration
        self.tracker: Optional[cc.Tracker] = None
        self._worker: Optional[CallableWorker] = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._last_text = ""
        self._last_tone = ""
        self._last_look: Optional[str] = None
        self._warned: dict[str, float] = {}
        self.session_corrections = 0              # since the app was opened (the watcher records it per run)
        self._starting = False

    # ---- on / off ------------------------------------------------------------------------------------------------
    @property
    def on(self) -> bool:
        return self.tracker is not None and self._timer.isActive()

    @property
    def busy(self) -> bool:
        return self._worker is not None

    def start(self) -> None:
        """Remember how the sheet and the background look now, through the calibration in use, and start keeping it."""
        if self._starting or self._worker is not None:
            return
        if not self.has_calibration():
            self._say("Not started: calibrate first (with the cube), then start the continuous calibration.", "bad")
            return
        why = self.can_check()
        if why:
            self._say(f"Not started: {why}.", "bad")
            return
        transform = np.asarray(self.get_transform(), float).copy()
        self._starting = True
        self._say("Starting: looking for the sheet...")

        self._run(lambda: cc.start_reference(self.camera, transform, self.corners),
                  lambda reference: self._started(reference, transform), self._start_failed)

    def _started(self, reference: cc.Reference, transform: np.ndarray) -> None:
        self._starting = False
        if not np.allclose(transform, self.get_transform()):
            self._say("Not started: the calibration changed while it looked. Press Start again.", "warn")
            return
        try:
            reference.save(cc.reference_file(self.calibration_file))
        except OSError as exc:
            self._say(f"Not started: couldn't save its reference ({exc}).", "bad")
            return
        from app.calibration.storage import archive_calibration
        archive_calibration(self.calibration_file)        # (the one it starts from, kept in Earlier calibrations)
        self.tracker = cc.Tracker(reference, transform)
        cc.save_state(self.calibration_file, {"on": True, "started": reference.created, "corrections": 0,
                                              "reverted": 0})
        cc.append_log(self.calibration_file, {"when": reference.created, "decision": "start",
                                              "text": "started from the calibration in use"})
        logger.info("Continuous calibration started")
        self._timer.start(int(cc.CHECK_EVERY_S * 1000))
        self._say("On: it looks every 10 s while the arm is idle, and keeps the calibration right by itself.", "good")

    def _start_failed(self, message: str) -> None:
        self._starting = False
        self._say(f"Not started: {message}. The sheet must be in view, whole, the arm out of its way (park it), and "
                  "nothing on its edges.", "bad")

    def stop(self, why: str = "stopped") -> None:
        was_on = self.tracker is not None
        self._timer.stop()
        self.tracker = None
        if was_on:
            state = cc.load_state(self.calibration_file)
            state.update(on=False, stopped=time.strftime("%Y-%m-%d %H:%M:%S"), why=why)
            cc.save_state(self.calibration_file, state)
            cc.append_log(self.calibration_file, {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "decision": "off",
                                                  "text": why})
            logger.info("Continuous calibration off: %s", why)
        self._say(f"Off ({why})." if was_on else "Off.", "warn" if was_on and why != "stopped" else "")

    def calibration_replaced(self) -> None:
        """A calibration made some other way is in use now: the reference was the old one's."""
        if self.tracker is not None:
            self.stop("a new calibration is in use: press Start to keep that one right")
        elif cc.load_state(self.calibration_file).get("on"):
            # (on when the app closed, not resumed yet -- the first seconds after start: not to be resumed now, on a
            # calibration it wasn't keeping)
            state = cc.load_state(self.calibration_file)
            state.update(on=False, why="a new calibration is in use")
            cc.save_state(self.calibration_file, state)

    def resume(self) -> None:
        """At start-up: on again if it was on when the app closed (and the calibration is still the one it kept)."""
        if self.tracker is not None or self._starting:
            return                                     # (started by hand already)
        state = cc.load_state(self.calibration_file)
        if not state.get("on") or not self.has_calibration():
            return
        reference = cc.Reference.load(cc.reference_file(self.calibration_file))
        if reference is None:
            return
        tracker = cc.Tracker(reference, np.asarray(self.get_transform(), float))
        total_mm, total_deg = tracker.total()
        if total_mm > cc.TOTAL_MM or total_deg > cc.TOTAL_DEG:
            self._say("Not resumed: the calibration in use isn't the one it was keeping. Press Start.", "warn")
            return
        tracker.corrections = int(state.get("corrections", 0))
        tracker.reverted = int(state.get("reverted", 0))
        self.tracker = tracker
        self._timer.start(int(cc.CHECK_EVERY_S * 1000))
        logger.info("Continuous calibration resumed (on when the app was closed)")
        self._say("On again (it was on when the app closed).", "good")

    def shutdown(self) -> None:
        self._timer.stop()
        if self._worker is not None:
            self._worker.wait(5000)

    # ---- the looks -------------------------------------------------------------------------------------------------
    def check_now(self) -> None:
        """A look straight away (the Calibration tab's button), not waiting for the next one."""
        self._tick(by_hand=True)

    def _tick(self, by_hand: bool = False) -> None:
        if self.tracker is None or self._worker is not None:
            return
        why = self.can_check()
        if why:
            if by_hand:
                self._say(f"Not now: {why}.", "warn")
            else:
                self._say(f"On, waiting: {why}.")
            return
        tracker, transform = self.tracker, np.asarray(self.get_transform(), float).copy()
        if not np.allclose(transform, tracker.transform):
            self.calibration_replaced()          # (changed under it some way it wasn't told of)
            return
        self._run(lambda: cc.run_check(self.camera, transform, tracker.reference, self.corners),
                  lambda check: self._checked(tracker, transform, check),
                  lambda message: self._say(f"On: a look failed ({message}); trying again in 10 s.", "warn"))

    def _checked(self, tracker: cc.Tracker, transform: np.ndarray, check: cc.Check) -> None:
        if tracker is not self.tracker or not np.allclose(transform, self.get_transform()):
            return                                 # (stopped, or the calibration changed, while it looked)
        why = self.can_check()
        if why:
            # something began while it looked (a watcher run's Start, a prompt): this look is let go -- a correction
            # now would change the calibration under it (a run keeps one calibration from start to end)
            self._say(f"On, waiting: {why}.")
            return
        self._last_look = check.when
        decision = tracker.add(check)
        cc.append_log(self.calibration_file, {"when": check.when, "check": check.record(),
                                              "decision": decision.action, "text": decision.text,
                                              **({"record": decision.record} if decision.record else {})})
        if decision.action in ("correct", "revert") and decision.transform is not None:
            if decision.action == "correct":
                self.session_corrections += 1
            self.apply_transform(decision.transform, decision.action, decision.record)
            logger.info("Continuous calibration: %s", decision.text)
            self._save_counts()
            if tracker.stopped:                   # (gone back to the last good one, then given up)
                self.stop(tracker.stopped)
                self._say(decision.text, "bad")
                return
        elif decision.action == "keep":
            logger.info("Continuous calibration: %s", decision.text)
        elif decision.action == "stop":
            logger.warning("Continuous calibration: %s", decision.text)
            self.stop(decision.text)
            self._say(decision.text, "bad")
            return
        elif decision.action == "warn" and time.monotonic() - self._warned.get(decision.text, -1e9) > WARN_AGAIN_S:
            self._warned[decision.text] = time.monotonic()
            logger.warning("Continuous calibration: %s", decision.text)
        tone = {"ok": "good", "keep": "good", "correct": "good", "warn": "warn", "revert": "warn"}.get(decision.action, "")
        self._say(f"On · last look {check.when[-8:]} · {decision.text}", tone)

    def _save_counts(self) -> None:
        state = cc.load_state(self.calibration_file)
        state.update(corrections=self.tracker.corrections if self.tracker else 0,
                     reverted=self.tracker.reverted if self.tracker else 0)
        cc.save_state(self.calibration_file, state)

    # ---- for the watcher's record and the Calibration tab ----------------------------------------------------------
    def summary(self) -> dict:
        tracker = self.tracker
        out = {"on": self.on, "corrections_since_app_opened": self.session_corrections, "last_look": self._last_look}
        if tracker is not None:
            total_mm, total_deg = tracker.total()
            out.update(corrections=tracker.corrections, reverted=tracker.reverted,
                       from_start_mm=round(total_mm, 2), from_start_deg=round(total_deg, 3),
                       started=tracker.reference.created)
        return out

    @property
    def text(self) -> tuple[str, str]:
        return self._last_text, self._last_tone

    def _say(self, text: str, tone: str = "") -> None:
        self._last_text, self._last_tone = text, tone
        self.status.emit(text, tone)

    def _run(self, work: Callable, on_done: Callable, on_fail: Callable) -> None:
        worker = CallableWorker(work)
        self._worker = worker

        def finish(handler):
            def wrapper(value):
                if self._worker is worker:
                    self._worker = None
                handler(value)
            return wrapper
        worker.finished_ok.connect(finish(on_done))
        worker.failed.connect(finish(on_fail))
        worker.start()

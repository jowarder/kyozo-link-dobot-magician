"""Dark theme for the whole window, matching the colours of the 3D view."""
from __future__ import annotations

from PyQt6.QtGui import QColor, QPalette
from PyQt6.QtWidgets import QApplication

BACKGROUND = "#0f1c29"
PANEL = "#152636"
RAISED = "#1d3348"
BORDER = "#2a4459"
TEXT = "#d7e6f0"
MUTED = "#8fa8ba"
ACCENT = "#4bb8ad"

STYLESHEET = f"""
QWidget {{ background-color: {BACKGROUND}; color: {TEXT}; }}
QLabel, QCheckBox {{ background: transparent; }}
QMainWindow, QToolBar, QStatusBar {{ background-color: {PANEL}; border: none; }}
QToolBar {{ padding: 4px; spacing: 6px; border-bottom: 1px solid {BORDER}; }}
QStatusBar {{ border-top: 1px solid {BORDER}; }}
QTabWidget::pane {{ border: 1px solid {BORDER}; top: -1px; }}
QTabBar::tab {{ background: {PANEL}; color: {MUTED}; padding: 7px 18px; border: 1px solid {BORDER};
               border-bottom: none; margin-right: 2px; border-top-left-radius: 5px; border-top-right-radius: 5px; }}
QTabBar::tab:selected {{ background: {RAISED}; color: {TEXT}; border-bottom: 2px solid {ACCENT}; }}
QTabBar::tab:hover:!selected {{ color: {TEXT}; }}
QGroupBox {{ background-color: {PANEL}; border: 1px solid {BORDER}; border-radius: 6px;
            margin-top: 12px; padding: 8px 6px 6px 6px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {ACCENT};
                   background-color: {BACKGROUND}; }}
QPushButton {{ background-color: {RAISED}; border: 1px solid {BORDER}; border-radius: 5px; padding: 6px 12px; }}
QPushButton:hover {{ border-color: {ACCENT}; }}
QPushButton:pressed {{ background-color: {ACCENT}; color: #06131c; }}
QPushButton:checked {{ background-color: #1c4a4f; border-color: {ACCENT}; color: {TEXT}; }}
QPushButton[featured="true"] {{ border-color: {ACCENT}; color: {ACCENT}; font-weight: 600; }}
QPushButton:disabled {{ color: #5b7385; background-color: {PANEL}; }}
QLineEdit, QTextEdit, QListWidget, QDoubleSpinBox, QSpinBox, QComboBox {{
    background-color: #0b1620; border: 1px solid {BORDER}; border-radius: 4px; padding: 4px;
    selection-background-color: {ACCENT}; selection-color: #06131c; }}
QLineEdit:focus, QTextEdit:focus, QDoubleSpinBox:focus {{ border-color: {ACCENT}; }}
QListWidget::item {{ padding: 3px; }}
QListWidget::item:selected {{ background-color: {RAISED}; color: {TEXT}; }}
QComboBox QAbstractItemView {{ background-color: {PANEL}; selection-background-color: {RAISED}; }}
QScrollBar:vertical {{ background: {BACKGROUND}; width: 10px; }}
QScrollBar::handle:vertical {{ background: {BORDER}; border-radius: 5px; min-height: 24px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QProgressBar {{ background-color: #0b1620; border: 1px solid {BORDER}; border-radius: 5px; }}
QProgressBar::chunk {{ background-color: {ACCENT}; border-radius: 4px; }}
QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 15px; height: 15px; border: 1px solid {MUTED}; border-radius: 3px;
                       background-color: #0b1620; }}
QCheckBox::indicator:hover {{ border-color: {ACCENT}; }}
QCheckBox::indicator:checked {{ background-color: {ACCENT}; border-color: {ACCENT}; }}
QCheckBox::indicator:disabled {{ border-color: #3a5263; background-color: {PANEL}; }}
QSplitter::handle {{ background-color: {BACKGROUND}; }}
QSplitter::handle:horizontal {{ border-left: 1px solid {BORDER}; border-right: 1px solid {BORDER};
                               margin: 40px 1px; border-radius: 2px; background-color: {PANEL}; }}
QSplitter::handle:hover {{ background-color: {ACCENT}; }}
QToolTip {{ background-color: {RAISED}; color: {TEXT}; border: 1px solid {ACCENT}; }}
QMessageBox, QDialog {{ background-color: {PANEL}; }}
"""


def apply_dark_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    palette = QPalette()
    for role, colour in ((QPalette.ColorRole.Window, BACKGROUND), (QPalette.ColorRole.WindowText, TEXT),
                         (QPalette.ColorRole.Base, "#0b1620"), (QPalette.ColorRole.Text, TEXT),
                         (QPalette.ColorRole.Button, RAISED), (QPalette.ColorRole.ButtonText, TEXT),
                         (QPalette.ColorRole.Highlight, ACCENT), (QPalette.ColorRole.HighlightedText, "#06131c"),
                         (QPalette.ColorRole.PlaceholderText, "#5b7385")):
        palette.setColor(role, QColor(colour))
    app.setPalette(palette)
    app.setStyleSheet(STYLESHEET)

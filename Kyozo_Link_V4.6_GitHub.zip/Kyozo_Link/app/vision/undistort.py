"""Taking the lens's bend out of the camera's pictures, once, where they come in.

Every part of the app turns a pixel and its depth into a point as if the lens were perfect (a pinhole: x = (u - cx)
* z / fx). A real lens bends the picture a little, most towards its corners: a few pixels there, which is a few mm
on the table. Rather than teach every one of those places about the lens, the pictures themselves are straightened
(colour smoothly, depth pixel by pixel, never mixing two distances) and the pinhole sum is then right everywhere.

Coefficients are OpenCV's order: k1, k2, p1, p2[, k3[, k4, k5, k6]].
"""
from __future__ import annotations

from typing import Optional, Sequence

import cv2
import numpy as np

from app.hardware.interfaces import Intrinsics


def has_distortion(coefficients: Optional[Sequence[float]]) -> bool:
    return coefficients is not None and any(abs(float(c)) > 1e-7 for c in coefficients)


def _matrix(k: Intrinsics) -> np.ndarray:
    return np.array([[k.fx, 0.0, k.cx], [0.0, k.fy, k.cy], [0.0, 0.0, 1.0]])


class Undistorter:
    """Straightens pictures from a lens with these coefficients (the intrinsics stay as they are)."""

    def __init__(self, k: Intrinsics, coefficients: Sequence[float]):
        self.coefficients = tuple(float(c) for c in coefficients)
        self._maps = cv2.initUndistortRectifyMap(_matrix(k), np.array(self.coefficients), None, _matrix(k),
                                                 (k.width, k.height), cv2.CV_32FC1)

    def apply(self, rgb: Optional[np.ndarray], depth: Optional[np.ndarray]) -> tuple:
        map_x, map_y = self._maps
        out_rgb = None if rgb is None else cv2.remap(rgb, map_x, map_y, cv2.INTER_LINEAR,
                                                     borderMode=cv2.BORDER_CONSTANT)
        out_depth = None if depth is None else cv2.remap(depth, map_x, map_y, cv2.INTER_NEAREST,
                                                         borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        return out_rgb, out_depth


class Distorter:
    """The opposite, for the demo: bends perfect pictures as a lens with these coefficients would."""

    def __init__(self, k: Intrinsics, coefficients: Sequence[float]):
        v, u = np.mgrid[0:k.height, 0:k.width].astype(np.float32)
        points = np.stack([u.ravel(), v.ravel()], axis=1).reshape(-1, 1, 2)
        ideal = cv2.undistortPoints(points, _matrix(k), np.array(coefficients, float), P=_matrix(k))
        ideal = ideal.reshape(k.height, k.width, 2)
        self._maps = (np.ascontiguousarray(ideal[..., 0]), np.ascontiguousarray(ideal[..., 1]))

    def apply(self, rgb: np.ndarray, depth: np.ndarray) -> tuple:
        map_x, map_y = self._maps
        return (cv2.remap(rgb, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT),
                cv2.remap(depth, map_x, map_y, cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT, borderValue=0))

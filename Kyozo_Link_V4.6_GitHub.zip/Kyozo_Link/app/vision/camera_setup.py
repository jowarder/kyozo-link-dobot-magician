"""Camera setup: how well placed and set the camera is for the cubes, from one picture -- no calibration needed.

The table is the biggest flat surface the depth sees: its plane (in the camera's own coordinates) gives the camera's
height above it and its tilt from straight down. The cubes are what stands up from it about a cube's height: for each,
how big its top is in the picture, how many depth points it has, how big it measures, and how strong and how bright
its colour is. Then each reading is held against a target and an acceptable range (TARGETS), and the setup as a whole
gets a verdict: not ready, good enough to calibrate, or meets every target.

The targets come from the lab (2026-10-11): calibrations failed with the cube's top 27 px across and 34-94 depth
points on it (it measured 15-21 mm of 25: "the spots disagree by 2.3 mm"), and with colours washed out (saturation 91,
brightness 250: the colour finder saw nothing); they passed at 40 px and 150-350 points. Four calibrations are thin
evidence: the targets are v1, provisional, until checked against the lab camera's own readings (and are reported as
such). The camera's height is advisory: the cube size in the picture says how near it is, whatever its tilt (at 45 cm
and 30 degrees from straight down the cubes are 52 cm along the camera's line of sight).
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from typing import Optional

import cv2
import numpy as np

TARGETS_VERSION = "v1"
TARGETS_SOURCE = ("provisional: from 4 calibrations at the lab on 2026-10-11 (2 passed, 2 failed), to be checked "
                  "against the lab camera's own readings")

# name -> (label, unit, target (low, high), acceptable (low, high), blocks calibration, what the target means)
TARGETS: dict[str, tuple] = {
    "height_cm": ("Height", "cm", (40.0, 50.0), (35.0, 58.0), False,
                  "Camera height above the table (the cube size decides how near it must be)"),
    "tilt_deg": ("Tilt", "°", (10.0, 40.0), (0.0, 55.0), False, "From straight down"),
    "cube_px": ("Cube size", "px", (35.0, 50.0), (30.0, 65.0), True,
                "Across a cube's top in the picture, as a 25 mm cube's (it says how near the camera is)"),
    "edge_margin_pct": ("Edge margin", "%", (10.0, 100.0), (5.0, 100.0), False,
                        "The cube nearest the picture's edge, how far inside it (the edges are seen worst)"),
    "top_ratio": ("Cube top read", "%", (92.0, 108.0), (85.0, 115.0), True, "Its top's measured size, of the cube's"),
    "saturation": ("Saturation", "", (130.0, 255.0), (100.0, 255.0), True,
                   "Colour strength, weakest cube (the watcher needs 90)"),
    "clipped_pct": ("Clipped pixels", "%", (0.0, 2.0), (0.0, 8.0), False, "Of the cubes' tops, at full brightness"),
    "top_points": ("Top points", "", (150.0, 100000.0), (110.0, 100000.0), True, "Depth points on each cube's top"),
    "noise_mm": ("Noise", "mm", (0.0, 0.8), (0.0, 1.5), False,
                 "The table's flatness as the depth sees it (advisory until checked on the lab's camera)"),
    "shake_mm": ("Shake", "mm", (0.0, 0.3), (0.0, 0.6), False,
                 "How far the camera moves while the arm does (run the shake test: needed for 'meets targets')"),
    "warmup_min": ("Warm-up", "min", (15.0, 1e9), (10.0, 1e9), True, "Since the camera started: its depth drifts"),
}
GROUPS = (("Geometry", ("height_cm", "tilt_deg", "cube_px", "edge_margin_pct")),
          ("Image", ("saturation", "clipped_pct")),
          ("Depth", ("top_points", "top_ratio", "noise_mm")),
          ("Stability", ("shake_mm", "warmup_min")))

MEETS, CLOSE, FAILS, UNKNOWN = "meets", "close", "fails", "unknown"
NOT_READY, GOOD_ENOUGH, MEETS_TARGETS = "Not ready", "Good enough to calibrate", "Meets targets"

STRIDE = 6                  # the table's plane from every 6th pixel each way (plenty, and quick)
PLANE_TOLERANCE_MM = 4.0    # a point this near the plane is the table's
TOP_BAND_MM = 4.0           # a cube's top: within this of its highest points
CLIP_LEVEL = 250            # a colour channel this bright is clipped
REFERENCE_CUBE_MM = 25.0    # the cube size the "cube size in the picture" target is for
LEVEL_SLANT_DEG = 15.0      # the red-blue line slanting more than this across the picture: said (Mount mode)


@dataclass
class Plane:
    normal: np.ndarray          # unit, pointing towards the camera (camera coordinates, mm)
    offset: float               # normal . p + offset = 0 on the plane; the camera's distance to it
    inliers: float              # the share of the sampled points on it
    rms_mm: float               # how far they are from it, typically

    def height(self, points: np.ndarray) -> np.ndarray:
        """Each point's height above the plane (mm; towards the camera positive)."""
        return points @ self.normal + self.offset


@dataclass
class CubeReading:
    colour: str
    pixel: tuple                # (u, v) of the middle of its top
    px: float                   # its top's side in the picture, pixels
    top_points: int
    top_mm: tuple               # its top's measured size (narrow, long), mm
    height_mm: float
    saturation: float           # the top's median colour saturation (0-255)
    value: float                # ...and brightness
    clipped_pct: float
    outline: list = field(default_factory=list)   # the top's corners in the picture, for drawing
    centre_mm: tuple = ()       # the middle of its top, camera coordinates (mm)
    angle_deg: float = 0.0      # its sides' turn on the table (0-90: a square looks the same every quarter turn)


@dataclass
class SetupReading:
    """One look's measurements (None where it couldn't tell)."""
    height_cm: Optional[float] = None
    tilt_deg: Optional[float] = None
    table_confidence: float = 0.0
    noise_mm: Optional[float] = None
    plane_offset_mm: Optional[float] = None
    cubes: list = field(default_factory=list)
    warmup_min: Optional[float] = None
    shake_mm: Optional[float] = None
    image_size: tuple = ()      # (width, height) of the picture, pixels
    plane_normal: tuple = ()    # the table's direction from the camera (unit, camera coordinates): a turn shows here
    # what stood up from the table about a cube's height but wasn't taken as a cube (too few depth points on its top,
    # or its top read too small): {"colour", "pixel", "why"} -- a cube the depth sees badly, said rather than dropped
    rejects: list = field(default_factory=list)

    def judged(self) -> list:
        """The cubes the readings judge: the coloured ones, if any. At the lab, 2026-10-21, the gripper standing low in
        the picture was found as two "cubes" (black and grey, a 3 x 17 mm top, 72 depth points): judged as the
        weakest cube, they turned Saturation, Cube top read and Top points red beside a blue cube that met them all.
        With nothing coloured seen, all of them (a black or white cube is still judged)."""
        coloured = [c for c in self.cubes if c.colour not in ACHROMATIC]
        return coloured or list(self.cubes)

    def edge_margin_pct(self) -> Optional[float]:
        """How far inside the picture's edges the cube nearest one is, as a share of the picture's short side."""
        cubes = self.judged()
        if not cubes or not self.image_size:
            return None
        w, h = self.image_size
        corners = [pt for c in cubes for pt in (c.outline or [c.pixel])]
        nearest = min(min(u, w - u, v, h - v) for u, v in corners)
        return round(max(0.0, 100.0 * nearest / min(w, h)), 1)

    def values(self, cube_mm: float) -> dict:
        """The readings TARGETS judges (the weakest cube for the per-cube ones; see judged)."""
        cubes = self.judged()
        out = {"height_cm": self.height_cm, "tilt_deg": self.tilt_deg, "noise_mm": self.noise_mm,
               "warmup_min": self.warmup_min, "shake_mm": self.shake_mm, "edge_margin_pct": self.edge_margin_pct()}
        if cubes:
            # as a 25 mm cube's: the target is the camera's distance, whatever the cubes' size (19 mm ones too)
            out["cube_px"] = min(c.px for c in cubes) * (REFERENCE_CUBE_MM / cube_mm if cube_mm > 0 else 1.0)
            out["top_points"] = float(min(c.top_points for c in cubes))
            out["saturation"] = min(c.saturation for c in cubes)
            out["clipped_pct"] = max(c.clipped_pct for c in cubes)
            ratios = [100.0 * min(c.top_mm) / cube_mm for c in cubes if c.top_mm and cube_mm > 0]
            out["top_ratio"] = max(ratios, key=lambda r: abs(r - 100.0)) if ratios else None   # the furthest off
        else:
            for name in ("cube_px", "top_points", "saturation", "clipped_pct", "top_ratio", "edge_margin_pct"):
                out[name] = None
        if self.table_confidence < 0.3:           # the table seen too little to trust its plane
            out["height_cm"] = out["tilt_deg"] = out["noise_mm"] = None
        return out

    def as_dict(self) -> dict:
        d = asdict(self)
        return d


def points_from_depth(depth: np.ndarray, intrinsics, stride: int = 1) -> tuple[np.ndarray, np.ndarray]:
    """(N x 3 camera-coordinate points in mm, their (row, col) pixels) of every `stride`-th valid depth pixel."""
    h, w = depth.shape
    rows, cols = np.mgrid[0:h:stride, 0:w:stride]
    z = depth[rows, cols].astype(np.float64)
    valid = z > 0
    rows, cols, z = rows[valid], cols[valid], z[valid]
    x = (cols - intrinsics.cx) * z / intrinsics.fx
    y = (rows - intrinsics.cy) * z / intrinsics.fy
    return np.stack([x, y, z], axis=1), np.stack([rows, cols], axis=1)


def fit_table(depth: np.ndarray, intrinsics, rng: Optional[np.random.Generator] = None,
              iterations: int = 150) -> Optional[Plane]:
    """The table: the plane most of the depth lies on (RANSAC, then a least-squares fit of its points)."""
    points, _ = points_from_depth(depth, intrinsics, STRIDE)
    if len(points) < 200:
        return None
    rng = rng or np.random.default_rng(0)
    best, best_count = None, 0
    for _ in range(iterations):
        a, b, c = points[rng.choice(len(points), 3, replace=False)]
        normal = np.cross(b - a, c - a)
        norm = np.linalg.norm(normal)
        if norm < 1e-6:
            continue
        normal /= norm
        offset = -normal @ a
        count = int((np.abs(points @ normal + offset) < PLANE_TOLERANCE_MM).sum())
        if count > best_count:
            best, best_count = (normal, offset), count
    if best is None:
        return None
    normal, offset = best
    inliers = points[np.abs(points @ normal + offset) < PLANE_TOLERANCE_MM]
    centre = inliers.mean(axis=0)
    _, _, vt = np.linalg.svd(inliers - centre, full_matrices=False)
    normal = vt[2]
    if normal[2] > 0:                       # towards the camera (it looks along +z)
        normal = -normal
    offset = -float(normal @ centre)
    residual = inliers @ normal + offset
    # robust: the typical point's distance (1.4826 x the median absolute one), not swayed by a few stray ones
    return Plane(normal=normal, offset=offset, inliers=len(inliers) / len(points),
                 rms_mm=float(1.4826 * np.median(np.abs(residual - np.median(residual)))))


def find_cubes(rgb: np.ndarray, depth: np.ndarray, intrinsics, plane: Plane, cube_mm: float,
               rejects: Optional[list] = None) -> list[CubeReading]:
    """What stands up from the table about a cube's height, with a top about a cube's size: each one's readings.
    `rejects` (if given) gets what was about a cube's size in the picture but wasn't taken: a cube seen badly."""
    h, w = depth.shape
    points, pixels = points_from_depth(depth, intrinsics, 1)
    heights = np.zeros((h, w), np.float32)
    heights[pixels[:, 0], pixels[:, 1]] = plane.height(points)
    xyz = np.zeros((h, w, 3), np.float32)
    xyz[pixels[:, 0], pixels[:, 1]] = points
    standing = ((heights > 0.5 * cube_mm) & (heights < 1.6 * cube_mm)).astype(np.uint8)
    standing = cv2.morphologyEx(standing, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(standing, connectivity=8)
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    from app.vision.depth_detector import colour_name
    cubes = []
    for label in range(1, count):
        if stats[label, cv2.CC_STAT_AREA] < 30:
            continue
        region = labels == label
        top_height = float(np.percentile(heights[region], 90))
        top = region & (heights > top_height - TOP_BAND_MM)
        n_top = int(top.sum())
        # how big a cube's top would be here in the picture: less than a tenth of that is a speck, not a cube
        z_here = float(np.median(xyz[region][:, 2]))
        side_px = cube_mm * float(intrinsics.fx) / z_here if z_here > 0 else 0.0
        cube_sized = stats[label, cv2.CC_STAT_AREA] >= 0.1 * side_px * side_px

        def reject(why: str, region=region, cube_sized=cube_sized) -> None:
            if rejects is not None and cube_sized:
                ys, xs = np.nonzero(region)
                rejects.append({"colour": colour_name(rgb[region]), "pixel": (float(xs.mean()), float(ys.mean())),
                                "why": why})
        if n_top < 10:
            reject(f"only {n_top} depth points on its top")
            continue
        rows, cols = np.nonzero(top)
        rect = cv2.minAreaRect(np.stack([cols, rows], axis=1).astype(np.float32))
        (pu, pv), (pw, ph), _ = rect
        top_xyz = xyz[top]
        # its top's size along the table: the 3D points projected on the plane, the smallest rectangle round them
        e1 = np.cross(plane.normal, [1.0, 0.0, 0.0])
        if np.linalg.norm(e1) < 1e-6:
            e1 = np.cross(plane.normal, [0.0, 1.0, 0.0])
        e1 /= np.linalg.norm(e1)
        e2 = np.cross(plane.normal, e1)
        flat = np.stack([top_xyz @ e1, top_xyz @ e2], axis=1).astype(np.float32)
        (_, _), (mw, mh), turn = cv2.minAreaRect(flat)
        size = sorted((float(mw), float(mh)))
        if size[1] > 1.8 * cube_mm:
            continue                                   # not a cube: the robot's base, a cable, the tray
        if size[1] < 0.4 * cube_mm:
            reject(f"its top read {size[1]:.0f} mm across, of {cube_mm:.0f}")
            continue
        colours = rgb[top]
        sat = hsv[..., 1][top].astype(float)
        val = hsv[..., 2][top].astype(float)
        clipped = float((colours.max(axis=1) >= CLIP_LEVEL).mean() * 100.0)
        box = cv2.boxPoints(rect) if pw and ph else []        # (turned as the cube is: its true corners)
        cubes.append(CubeReading(colour=colour_name(colours), pixel=(float(pu), float(pv)),
                                 px=float(math.sqrt(max(pw * ph, 0.0))), top_points=n_top,
                                 top_mm=(round(size[0], 1), round(size[1], 1)), height_mm=round(top_height, 1),
                                 saturation=float(np.median(sat)), value=float(np.median(val)),
                                 clipped_pct=round(clipped, 2),
                                 outline=[(float(x), float(y)) for x, y in box],
                                 centre_mm=tuple(float(v) for v in top_xyz.mean(axis=0)),
                                 angle_deg=float(turn) % 90.0))
    cubes.sort(key=lambda c: c.pixel[0])
    return cubes


def measure(rgb: np.ndarray, depth: np.ndarray, intrinsics, cube_mm: float = 25.0,
            warmup_min: Optional[float] = None) -> SetupReading:
    """One picture's readings (see SetupReading)."""
    reading = SetupReading(warmup_min=warmup_min, image_size=(int(depth.shape[1]), int(depth.shape[0])))
    plane = fit_table(depth, intrinsics)
    if plane is None:
        return reading
    reading.table_confidence = round(float(plane.inliers), 2)
    reading.height_cm = round(abs(plane.offset) / 10.0, 1)
    reading.tilt_deg = round(math.degrees(math.acos(min(1.0, abs(float(plane.normal[2]))))), 1)
    reading.noise_mm = round(plane.rms_mm, 2)
    reading.plane_offset_mm = round(float(plane.offset), 2)
    reading.plane_normal = tuple(round(float(v), 6) for v in plane.normal)
    reading.cubes = find_cubes(rgb, depth, intrinsics, plane, cube_mm, reading.rejects)
    return reading


def status_of(name: str, value: Optional[float]) -> str:
    if value is None:
        return UNKNOWN
    _, _, target, acceptable, _, _ = TARGETS[name]
    if target[0] <= value <= target[1]:
        return MEETS
    if acceptable[0] <= value <= acceptable[1]:
        return CLOSE
    return FAILS


def hint_for(name: str, value: Optional[float]) -> str:
    """What to do about a reading off its target, in a few words ('' if it meets it)."""
    if value is None:
        return {"shake_mm": "Run the shake test", "height_cm": "The table isn't seen well enough to say",
                "warmup_min": "", "cube_px": "Put the cubes on the table"}.get(name, "No cube seen yet")
    _, _, (low, high), _, _, _ = TARGETS[name]
    if low <= value <= high:
        return ""
    below = value < low
    return {
        "height_cm": f"{'Raise' if below else 'Lower'} the camera about {abs(value - (low if below else high)):.0f} cm",
        "tilt_deg": ("Turn the camera to look more straight down" if not below else
                     "Nearly straight down: fine for the depth, but the arm hides more of the table as it reaches -- "
                     "tilt it to look from the robot's front, 10-40° from straight down"),
        "cube_px": "Move the camera closer" if below else "Move the camera further away",
        "top_ratio": ("The depth misses the cubes' edges: move closer, raise the projector power, or use the "
                      "Default depth preset" if below else "The cubes' tops read too big: check for glare"),
        "saturation": "Colours are washed out: lower the exposure (or a grey mat under the cubes)",
        "clipped_pct": "Too bright: lower the exposure",
        "top_points": "Few depth points: move closer, raise the projector power",
        "noise_mm": "Noisy depth: let it warm up, raise the projector power, avoid sunlight",
        "shake_mm": "The camera shakes when the arm moves: clamp it firmer",
        "warmup_min": f"Warming up: {low - value:.0f} more minutes",
        "edge_margin_pct": "A cube is near the picture's edge: aim towards it, or move the camera back a little",
    }.get(name, "")


def aim_hints(reading: SetupReading) -> list[str]:
    """Where to point the camera, from where the cubes sit in the picture (Mount mode): towards the middle of them,
    and level -- with a cube on zone A and one on zone B (the same distance from the robot), the line between them
    should run straight across the picture."""
    if not reading.cubes or not reading.image_size:
        return ["Put the cubes on the table: spread over where the tasks are, one on each zone."]
    w, h = reading.image_size
    us = [c.pixel[0] for c in reading.cubes]
    vs = [c.pixel[1] for c in reading.cubes]
    hints = []
    du = ((min(us) + max(us)) / 2.0 - w / 2.0) / w
    dv = ((min(vs) + max(vs)) / 2.0 - h / 2.0) / h
    if abs(du) > 0.12:
        hints.append(f"The cubes sit {'right' if du > 0 else 'left'} of the picture's middle: turn the camera a "
                     f"little to the {'right' if du > 0 else 'left'}.")
    if abs(dv) > 0.15:
        hints.append(f"The cubes sit in the {'lower' if dv > 0 else 'upper'} part of the picture: tilt the camera "
                     f"{'down' if dv > 0 else 'up'} a little.")
    # the level check: the red and the blue cube in a straight line across in front of the robot (along a ruler
    # laid parallel to its base) -- by colour, so every other cube can stay out for the rest of the checks
    reds = [c for c in reading.cubes if c.colour == "red"]
    blues = [c for c in reading.cubes if c.colour == "blue"]
    if len(reds) == 1 and len(blues) == 1:
        left, right = sorted((reds[0], blues[0]), key=lambda c: c.pixel[0])
        slope = math.degrees(math.atan2(right.pixel[1] - left.pixel[1], right.pixel[0] - left.pixel[0]))
        # (only a clear slant: a camera looking from a little to the side sees the line slanting somewhat however it
        # is turned, and the calibration takes the camera at any angle -- what matters is that both zones fit)
        if abs(slope) > LEVEL_SLANT_DEG:
            hints.append(f"The robot's left-right (the red-blue line) runs diagonally across the picture "
                         f"({abs(slope):.0f}°): turn or swing the camera so it runs more straight across -- both "
                         "zones then fit, with room at the sides.")
    else:
        hints.append("Level check: put the red and the blue cube in a straight line across in front of the robot "
                     "(along a ruler parallel to its base); the other cubes anywhere.")
    margin = reading.edge_margin_pct()
    if margin is not None and margin < TARGETS["edge_margin_pct"][2][0]:
        near = min(reading.cubes, key=lambda c: min(c.pixel[0], w - c.pixel[0], c.pixel[1], h - c.pixel[1]))
        hints.append(f"The {near.colour} cube is near the picture's edge: aim towards it, or move the camera back.")
    return hints or ["Aimed well: the cubes are in the middle of the picture, level."]


def verdict(statuses: dict[str, str], missing: int = 0) -> str:
    """Not ready (a check that blocks calibration fails, or isn't known, or `missing` cubes on the table aren't
    seen), good enough to calibrate (every blocking one at least acceptable), or meets targets (every check in its
    target range)."""
    blocking = [name for name, spec in TARGETS.items() if spec[4]]
    if missing > 0 or any(statuses.get(name, UNKNOWN) in (FAILS, UNKNOWN) for name in blocking):
        return NOT_READY
    if all(statuses.get(name, UNKNOWN) == MEETS for name in TARGETS):
        return MEETS_TARGETS
    return GOOD_ENOUGH


def plane_shift(reference: dict, reading: SetupReading, reference_normal=None) -> Optional[dict]:
    """How the camera moved since the reference (Session check), as the table shows it: the height change, the tilt
    change, and how far the table's direction turned (any way: a camera turned sideways keeps its tilt but not its
    view of the table). A camera slid along the table changes none of these: the picture shows that
    (app/vision/drift.py's picture comparison)."""
    if reading.height_cm is None or reference.get("height_cm") is None:
        return None
    turned = None
    if reference_normal is not None and len(reference_normal) == 3 and len(reading.plane_normal) == 3:
        cos = float(np.clip(np.dot(np.asarray(reference_normal, float), np.asarray(reading.plane_normal, float)),
                            -1.0, 1.0))
        turned = round(math.degrees(math.acos(cos)), 2)
    return {"height_mm": round(10.0 * (reading.height_cm - reference["height_cm"]), 1),
            "tilt_deg": round((reading.tilt_deg or 0.0) - (reference.get("tilt_deg") or 0.0), 2),
            "turned_deg": turned}


def shake_from(offsets: list[float], normals: list[np.ndarray], distance_mm: float) -> Optional[float]:
    """The camera's movement while the arm moved: how much the table's distance and its direction changed between
    pictures (a turn of the camera moves what it sees by the angle times the distance)."""
    if len(offsets) < 3:
        return None
    moved = max(offsets) - min(offsets)
    angles = [math.degrees(math.acos(max(-1.0, min(1.0, float(n @ normals[0]))))) for n in normals]
    turned = math.radians(max(angles)) * distance_mm
    return round(max(moved, turned), 2)


DARK_VALUE = 110.0          # a cube's top darker than this: its colour reading is noise as much as colour
MID_VALUE = 170.0           # ...and this bright: the middle of the good range, with room for the light to change
NEAR_BEST = 0.9             # Find best exposure: of the exposures scoring this share of the best, the cubes' brightness
                            # nearest MID_VALUE (the lab, 2026-10-21: the best by score was the darkest passable one)
ACHROMATIC = ("black", "grey", "white")     # no colour to judge an exposure by (not the study's cubes)
PLACE_PX = 30.0             # an object this near a place a cube read coloured is that cube (an exposure sweep)


def coloured_places(readings: list) -> list:
    """Where the coloured cubes are, over several pictures (an exposure sweep): the pixel of every object that reads
    coloured in at least one of them. A real cube read "black" when too dark, or "white" when washed out, is still
    found there by the pictures where it reads coloured; a laptop or the arm's black parts read colourless in all."""
    return [c.pixel for r in readings for c in r.cubes if c.colour not in ACHROMATIC]


def best_exposure_score(reading: SetupReading, places: Optional[list] = None) -> float:
    """How good a picture's colours are for finding cubes by colour: the weakest cube's saturation, less what's lost
    to clipping and to a too dark picture (higher is better; -1 when it sees no cube). A dark picture is marked down
    hard: on a real sensor the noise in dark pixels reads as strong colour, so a too short exposure would otherwise
    look best. `places` (coloured_places of the whole sweep): the cubes judged are the objects there, whatever they
    read in this picture -- one too dark to read coloured counts, and is marked down for it."""
    # only the coloured ones: at the lab a laptop, a mouse and the arm's black parts stood up from the table too, read
    # as black and grey "cubes", and the weakest of those decided -- every exposure scored below zero and the
    # darkest tried was kept. But not by this picture's colour alone (a dark blue cube reads "black" too short)
    if places is not None:
        cubes = [c for c in reading.cubes if any(math.dist(c.pixel, p) <= PLACE_PX for p in places)]
    else:
        cubes = [c for c in reading.cubes if c.colour not in ACHROMATIC]
    if not cubes:
        return -1.0
    weakest = min(c.saturation for c in cubes)
    clipped = max(c.clipped_pct for c in cubes)
    darkest = min(c.value for c in cubes)
    if darkest < DARK_VALUE:
        # (too dark, the noise reads as full colour: at the lab a blue cube's top, at brightness 50 of 255, read
        # saturation 255 -- "the strongest colour" -- and the sweep kept an exposure it didn't even see the cube at)
        weakest = min(weakest, 255.0 * darkest / DARK_VALUE)
    return weakest - 4.0 * clipped - 2.0 * max(0.0, DARK_VALUE - darkest)


def cubes_brightness(reading: SetupReading, places: Optional[list] = None) -> Optional[float]:
    """The darkest judged cube's brightness (0-255), as best_exposure_score judges them; None if none."""
    if places is not None:
        cubes = [c for c in reading.cubes if any(math.dist(c.pixel, p) <= PLACE_PX for p in places)]
    else:
        cubes = [c for c in reading.cubes if c.colour not in ACHROMATIC]
    return min(c.value for c in cubes) if cubes else None


def pick_exposure(scored: list) -> Optional[int]:
    """Of (exposure, score, brightness) for each tried: among those scoring NEAR_BEST of the best (and >= 0), the one
    whose cubes' brightness is nearest MID_VALUE -- the colour is about as good there, with room for the light to
    change either way. None if none scored."""
    good = [s for s in scored if s[1] >= 0]
    if not good:
        return None
    top = max(s[1] for s in good)
    near = [s for s in good if s[1] >= NEAR_BEST * top]
    return min(near, key=lambda s: (abs((s[2] if s[2] is not None else 0.0) - MID_VALUE), -s[1]))[0]


# ---- comparing settings over many looks (Camera setup: the depth preset, the detection) ----------------------------
# (a preset that misses a cube more often loses first: fewer cubes also means less jitter to add up)
PRESET_TIES = (("missed_pct", 10.0), ("centre_jitter_mm", 0.15), ("top_off_pct", 5.0), ("angle_jitter_deg", 0.5))
DETECTION_TIES = (("missed_pct", 10.0), ("off_depth_mm", 0.5), ("jitter_mm", 0.3), ("no_angle", 0.5))


def _wrap90(a: float) -> float:
    return (a + 45.0) % 90.0 - 45.0


def _tracks(looks: list, key=lambda c: c.colour, where=lambda c: c.pixel) -> list:
    """The same cube's sightings across looks: by colour, and nearest where it was first seen (two of a colour)."""
    first = max(looks, key=len) if looks else []
    tracks = [[c] for c in first]
    for look in looks:
        if look is first:
            continue
        for c in look:
            mine = [t for t in tracks if key(t[0]) == key(c)]
            if mine:
                min(mine, key=lambda t: math.dist(where(t[0]), where(c))).append(c)
    return tracks


def _jitter(points: list) -> float:
    """How far the points are from their middle, typically (RMS, mm)."""
    if len(points) < 2:
        return 0.0
    a = np.asarray(points, float)
    return float(np.sqrt(np.mean(np.sum((a - a.mean(axis=0)) ** 2, axis=1))))


def _angle_jitter(angles: list) -> float:
    if len(angles) < 2:
        return 0.0
    ref = angles[0]
    offs = np.array([_wrap90(a - ref) for a in angles])
    return float(np.sqrt(np.mean((offs - offs.mean()) ** 2)))


def look_summary(readings: list, cube_mm: float) -> dict:
    """What many looks under one setting say about the calibration to come: how steady each cube's centre and angle
    are (the worst cube), how whole its top reads, how many depth points it has, the depth noise, and how often
    every cube was seen."""
    looks = [r.cubes for r in readings]
    if not any(looks):
        return {"looks": len(readings), "seen": 0}
    tracks = _tracks(looks)
    most = max(len(look) for look in looks)
    values = [r.values(cube_mm) for r in readings]
    tops = [v["top_ratio"] for v in values if v.get("top_ratio") is not None]
    points = [v["top_points"] for v in values if v.get("top_points") is not None]
    noise = [r.noise_mm for r in readings if r.noise_mm is not None]
    all_seen = round(100.0 * sum(len(look) == most for look in looks) / len(looks), 1)
    return {"looks": len(readings), "seen": most, "all_seen_pct": all_seen, "missed_pct": round(100.0 - all_seen, 1),
            "centre_jitter_mm": round(max(_jitter([c.centre_mm for c in t]) for t in tracks), 2),
            "angle_jitter_deg": round(max(_angle_jitter([c.angle_deg for c in t]) for t in tracks), 2),
            "top_read_pct": round(float(np.median(tops)), 1) if tops else None,
            "top_off_pct": round(float(np.median([abs(t - 100.0) for t in tops])), 1) if tops else None,
            "top_points": int(np.median(points)) if points else None,
            "noise_mm": round(float(np.median(noise)), 2) if noise else None}


def choose(results: dict, current: str, ties: tuple, by_seen: bool = False, noise: Optional[dict] = None) -> tuple:
    """(the better setting, why in words, whether it was a tie). Measures compared in order, lower better; the first
    that differs by more than its tie margin decides -- the margin is at least how much the measure changed between
    blocks of looks with the same setting (`noise`), so a difference within the readings' own spread is a tie.
    `by_seen`: one that sees more of the cubes wins first. A setting that saw nothing loses; a tie keeps `current`."""
    usable = [n for n in results if results[n].get("seen", 1)
              and all(results[n].get(m) is not None for m, _ in ties)]
    if not usable:
        return current, "No cube was seen with any of them: put the cubes on the table.", True
    if len(usable) == 1:
        return usable[0], f"Only {usable[0]} saw the cubes.", False
    a, b = usable[0], usable[1]
    if by_seen and results[a].get("seen") != results[b].get("seen"):
        winner, loser = (a, b) if results[a]["seen"] > results[b]["seen"] else (b, a)
        return winner, (f"{winner} sees {results[winner]['seen']} cubes; {loser} only "
                        f"{results[loser]['seen']}."), False
    noise = noise or {}
    for measure, margin in ties:
        margin = max(margin, float(noise.get(measure) or 0.0))
        va, vb = float(results[a][measure]), float(results[b][measure])
        if abs(va - vb) > margin:
            winner, loser = (a, b) if va < vb else (b, a)
            return winner, _why(measure, results[winner][measure], results[loser][measure], winner, loser), False
    return current, f"About the same (within the readings' own noise): {current} stays.", True


def block_noise(blocks: dict, ties: tuple) -> dict:
    """How much each measure changed between blocks of looks with the same setting (the most, over the settings):
    `blocks` is {setting: [look_summary of each block]}."""
    out = {}
    for measure, _ in ties:
        spans = []
        for summaries in blocks.values():
            values = [s.get(measure) for s in summaries if s.get(measure) is not None]
            if len(values) > 1:
                spans.append(max(values) - min(values))
        out[measure] = round(max(spans), 3) if spans else 0.0
    return out


def _why(measure: str, win: float, lose: float, winner: str, loser: str) -> str:
    if measure == "centre_jitter_mm":
        times = f"{lose / win:.0f}x " if win > 0.01 and lose / win >= 1.5 else ""
        return f"Cube centres {times}steadier with {winner} ({win:.2f} mm, against {lose:.2f} mm)."
    if measure == "top_off_pct":
        return f"The cubes' tops read whole with {winner} (off by {win:.0f}%, against {lose:.0f}%)."
    if measure == "angle_jitter_deg":
        return f"The cubes' angles are steadier with {winner} ({win:.1f}°, against {lose:.1f}°)."
    if measure == "missed_pct":
        return f"{winner} finds every cube more often (misses {win:.0f}% of looks, against {lose:.0f}%)."
    if measure == "off_depth_mm":
        return f"{winner} puts the cubes where the depth reading has them ({win:.1f} mm off, against {lose:.1f} mm)."
    if measure == "jitter_mm":
        return f"{winner}'s positions are steadier ({win:.2f} mm, against {lose:.2f} mm)."
    if measure == "no_angle":
        return f"{winner} gives each cube's angle (needed for picks); {loser} doesn't."
    return f"{winner} is better."


def detection_summary(looks: list, expected: list, truth: dict) -> dict:
    """What a detector made of many looks: `looks` holds, per look, its (colour, x, y, angle or None) finds in robot
    coordinates; `expected` the cubes' colours as the depth sees them; `truth` each colour's middle (x, y) from the
    depth reading. How often it missed a cube, which colours it named, how steady and how far off the depth reading
    its positions are, whether it gives angles."""
    if not looks:
        return {"looks": 0, "seen": 0}
    want = sorted(expected)
    missed = sum(1 for look in looks if sorted(c for c, *_ in look if c in want) != want)
    named = sorted({c for look in looks for c, *_ in look})
    tracks = _tracks([list(look) for look in looks], key=lambda f: f[0], where=lambda f: (f[1], f[2]))
    jitter = max((_jitter([(f[1], f[2]) for f in t]) for t in tracks), default=None)
    off = []
    for t in tracks:
        if t[0][0] in truth:
            mx, my = float(np.mean([f[1] for f in t])), float(np.mean([f[2] for f in t]))
            off.append(math.dist((mx, my), truth[t[0][0]]))
    with_angle = [t for t in tracks if any(f[3] is not None for f in t)]
    return {"looks": len(looks), "seen": len(tracks),
            "missed_pct": round(100.0 * missed / len(looks), 1), "named": named,
            "jitter_mm": round(jitter, 2) if jitter is not None else None,
            "off_depth_mm": round(max(off), 2) if off else None,
            "angle_given": bool(with_angle), "no_angle": 0.0 if with_angle else 1.0,
            "angle_jitter_deg": round(max(_angle_jitter([f[3] for f in t if f[3] is not None])
                                          for t in with_angle), 2) if with_angle else None}

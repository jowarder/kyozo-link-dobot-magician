"""Finds the table surface in the depth image, in robot coordinates.

Used to set the Z floor without anyone measuring anything: the table is the biggest
near-horizontal flat surface the depth camera sees, and the calibration converts it to the
robot's frame. No arm movement is involved.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np

from app.hardware.interfaces import Intrinsics

# Region of the robot's frame the table must be found in (mm): the workspace and a little more.
# Keeps a far wall or the floor beyond the table edge from being mistaken for the table.
REGION_X = (-100.0, 450.0)
REGION_Y = (-350.0, 350.0)
MAX_TILT_DEG = 25.0   # a plane steeper than this is a wall or the arm, not the table
# A table the robot can work on sits within its own vertical range. A "plane" far outside it
# means the calibration is wrong (or the camera sees a ceiling or a wall), not that the table is there.
Z_RANGE = (-250.0, 150.0)
INLIER_TOL_MM = 4.0
MIN_POINTS = 300


@dataclass
class TablePlane:
    z_mm: float            # height of the table surface at the middle of the workspace (robot z)
    tilt_deg: float        # how far the surface is from horizontal in robot coordinates
    residual_mm: float     # spread of the points around the fitted plane
    inlier_count: int
    inlier_fraction: float # share of the workspace points that lie on the table


def fit_table_plane(depth: np.ndarray, intrinsics: Intrinsics, t_cam_to_robot: np.ndarray,
                    step: int = 6, iterations: int = 300, seed: int = 0,
                    centre_xy: tuple[float, float] = (200.0, 0.0)) -> Optional[TablePlane]:
    """Robust (RANSAC) fit of the dominant near-horizontal plane in the workspace.

    Returns None if there aren't enough points or nothing flat and horizontal is found."""
    rows, cols = np.mgrid[0:depth.shape[0]:step, 0:depth.shape[1]:step]
    z = depth[rows, cols].astype(np.float64)
    valid = (z > 0) & (z < 3000)
    u, v, z = cols[valid], rows[valid], z[valid]
    camera_points = np.stack([(u - intrinsics.cx) * z / intrinsics.fx,
                              (v - intrinsics.cy) * z / intrinsics.fy, z, np.ones_like(z)])
    points = (t_cam_to_robot @ camera_points)[:3].T
    inside = ((points[:, 0] > REGION_X[0]) & (points[:, 0] < REGION_X[1])
              & (points[:, 1] > REGION_Y[0]) & (points[:, 1] < REGION_Y[1]))
    points = points[inside]
    if points.shape[0] < MIN_POINTS:
        return None

    rng = np.random.default_rng(seed)
    min_nz = math.cos(math.radians(MAX_TILT_DEG))
    best_count, best_mask = 0, None
    for _ in range(iterations):
        p0, p1, p2 = points[rng.choice(points.shape[0], 3, replace=False)]
        normal = np.cross(p1 - p0, p2 - p0)
        length = np.linalg.norm(normal)
        if length < 1e-6:
            continue
        normal /= length
        if normal[2] < 0:
            normal = -normal
        if normal[2] < min_nz:
            continue
        distance = np.abs((points - p0) @ normal)
        mask = distance < INLIER_TOL_MM
        count = int(mask.sum())
        if count > best_count:
            best_count, best_mask = count, mask
    if best_mask is None or best_count < MIN_POINTS // 3:
        return None

    inliers = points[best_mask]
    centroid = inliers.mean(axis=0)
    _, _, vt = np.linalg.svd(inliers - centroid, full_matrices=False)
    normal = vt[2]
    if normal[2] < 0:
        normal = -normal
    signed = (inliers - centroid) @ normal
    # height of the plane above the chosen workspace point
    z_at_centre = centroid[2] - (normal[0] * (centre_xy[0] - centroid[0])
                                 + normal[1] * (centre_xy[1] - centroid[1])) / normal[2]
    if not (Z_RANGE[0] <= z_at_centre <= Z_RANGE[1]):
        return None
    return TablePlane(
        z_mm=float(z_at_centre),
        tilt_deg=float(math.degrees(math.acos(min(1.0, normal[2])))),
        residual_mm=float(signed.std()),
        inlier_count=int(best_count),
        inlier_fraction=float(best_count / points.shape[0]),
    )


def median_depth(camera, frames: int = 5, flush: int = 2):
    """(depth, last frame): per-pixel median of a few frames' valid readings, so depth noise
    averages out. Pixels with no valid reading in any frame stay 0. Several frames, so call
    from a worker thread where the UI must stay responsive."""
    for _ in range(flush):   # a real camera queues pictures; skip the oldest
        camera.get_frame()
    stack = []
    for _ in range(frames):
        frame = camera.get_frame()
        if frame.depth is None:
            raise RuntimeError("The camera gave no depth data.")
        stack.append(frame.depth)
    return median_of(stack), frame


def median_of(depths: list[np.ndarray]) -> np.ndarray:
    """Per-pixel median of depth pictures' valid (> 0) readings; 0 where none was valid."""
    stack = [np.where(d > 0, d, np.inf).astype(np.float32) for d in depths]
    # (np.nanmedian does this too, but takes minutes when many pixels have no depth, which
    # real cameras always have.)
    ordered = np.sort(np.stack(stack), axis=0)          # invalid readings (inf) sort to the end
    valid = np.isfinite(ordered).sum(axis=0)
    middle = np.maximum(valid - 1, 0) // 2
    depth = np.take_along_axis(ordered, middle[None], axis=0)[0]
    depth[valid == 0] = 0.0
    return depth


def measure_table(camera, t_cam_to_robot: np.ndarray, frames: int = 5) -> Optional[TablePlane]:
    """Fit the table from a few camera frames."""
    depth, frame = median_depth(camera, frames)
    return fit_table_plane(depth, frame.intrinsics, t_cam_to_robot)

def suggest_floor(plane: TablePlane, calibration_error_mm: Optional[float]) -> tuple[float, float]:
    """(z floor, margin used). The margin covers the calibration error, because that is how
    far off the table height can be; never less than 10 mm."""
    error = calibration_error_mm if calibration_error_mm is not None else 10.0
    margin = max(10.0, 2.0 * error, 3.0 * plane.residual_mm)
    return plane.z_mm + margin, margin

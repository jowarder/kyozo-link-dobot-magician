"""Builds the current scene: detected objects with robot-frame 3D positions."""
from __future__ import annotations

import itertools
import math
from collections import deque
from dataclasses import dataclass, replace
from typing import Optional

import numpy as np

from app.hardware.interfaces import Camera
from app.vision.detector import Detector
from app.vision.locator import locate_detection, LocatedObject


@dataclass
class SceneObject:
    id: str
    label: str
    xyz_robot: tuple[float, float, float]
    confidence: float
    footprint: Optional[tuple[float, float, float]] = None   # (width, length, angle of the long side), see locator


SAME_SPOT_MM = 8.0   # an object seen this close to where one was is that one, whatever it is called now
STEADY_MM = 10.0     # seen again this close in the next look(s): there (see DetectionSettings.steady_looks)
UNDER_MM = 15.0      # something whose middle is this near another's, and higher, is on top of it
COLOURLESS = ("grey", "gray", "black", "white", "silver")   # only cubes: never one of the study's (the arm, the base)
CUBES_ONLY_LONG = 1.6      # only cubes: an outline up to this many cube sizes long (a side face in it) is still one
CUBE_READINGS = 24         # the cubes' own measurements kept (each cube's narrow side, as measured, in each look)...
MIN_CUBE_READINGS = 6      # ...and how many it takes to say what size the cubes on the table are (measured_cube_mm)
KNOWN_SIZE_TOL_MM = 6.0   # a top measured within this of an object's known size, both ways, is taken to be that size
                          # (the lab's camera read 25 mm cubes as anything from 20 x 26 to 28 x 30 mm, and called one
                          # too wide for the gripper)


class SceneBuilder:
    """Runs detection + localization on the latest camera frame and assigns stable-ish IDs
    by matching to the previous frame's nearest object of the same label (simple tracking).
    """

    def __init__(self, camera: Camera, detector: Detector, t_cam_to_robot: np.ndarray,
                 match_distance_mm: float = 30.0, known_sizes: Optional[dict] = None, cubes_only: bool = False):
        """`known_sizes`: what the objects are known to measure, by the last word of their name ({"cube": 25.0}:
        every cube's top is 25 x 25 mm), used instead of the camera's measurement when that is near it. `cubes_only`:
        nothing but cubes is used (config.yaml, vision: cubes_only), so a cylinder or ball measured near a cube's
        known size is that cube, read round for a moment (the lab, 2026-10-22: a blue cube flickered to "blue
        cylinder" and back)."""
        self.cubes_only = cubes_only
        self.camera = camera
        self.known_sizes = {str(k).lower(): float(v) for k, v in (known_sizes or {}).items()}
        self.detector = detector
        self.t_cam_to_robot = t_cam_to_robot
        self.match_distance_mm = match_distance_mm
        self._id_counter = itertools.count(1)
        self._previous: list[SceneObject] = []
        # the narrow side of each cube-like top as measured, before the known size is put on it: what the cubes on the
        # table really measure, against the size set (app.cube_size.size_mismatch)
        self.cube_readings: deque = deque(maxlen=CUBE_READINGS)
        self.correction = None    # correction.XYCorrection over the table, from a cube calibration, or None

    def set_calibration(self, t_cam_to_robot: np.ndarray, correction=None) -> None:
        self.t_cam_to_robot = t_cam_to_robot
        self.correction = correction

    def _corrected(self, located: list[LocatedObject]) -> list[LocatedObject]:
        if self.correction is None:
            return located
        out = []
        for loc in located:
            x, y = self.correction.apply(loc.xyz_robot[0], loc.xyz_robot[1])
            out.append(replace(loc, xyz_robot=(x, y, loc.xyz_robot[2])))
        return out

    def _known(self, located: list[LocatedObject]) -> list[LocatedObject]:
        """Each object of a known size given that size (its outline's turn kept), if the camera measured it near
        enough to it; one measured far off (two cubes side by side, read as one) keeps what was measured."""
        if not self.known_sizes:
            return located
        out = []
        for loc in located:
            words = loc.label.split()
            if getattr(self, "cubes_only", False) and words and words[0].lower() in COLOURLESS:
                # only the coloured cubes are on the table: something grey, black or white is the robot's own (the
                # parked gripper, read as "a grey block" in the way, refused every move -- the lab, 2026-10-22), the
                # base or the table's edge
                continue
            # a "block" measured near a known cube's size is that cube: its top read a little long one way (a side face
            # or a shadow taken for top -- the lab, 2026-10-22: a 25 mm green cube read 23.7 x 27.5, named a block, so
            # neither its size nor its name was the cube's, and it was gripped on its edge)
            only = getattr(self, "cubes_only", False)
            other = ("block", "cylinder", "ball") if only else ("block",)
            cube = self.known_sizes.get("cube")
            if (cube is not None and loc.footprint is not None and words and words[-1].lower() in other + ("cube",)
                    and abs(min(loc.footprint[:2]) - cube) <= 2 * KNOWN_SIZE_TOL_MM and hasattr(self, "cube_readings")):
                self.cube_readings.append(float(min(loc.footprint[:2])))
            near = cube is not None and loc.footprint is not None and (
                all(abs(v - cube) <= KNOWN_SIZE_TOL_MM for v in loc.footprint[:2]) or
                # (only cubes: a side face taken in makes one side long, up to ~35 mm for 25; two side by side ~50)
                (only and abs(min(loc.footprint[:2]) - cube) <= KNOWN_SIZE_TOL_MM
                 and max(loc.footprint[:2]) <= CUBES_ONLY_LONG * cube))
            if words and words[-1].lower() in other and near:
                loc = replace(loc, label=" ".join(words[:-1] + ["cube"]))
                words = loc.label.split()
            size = self.known_sizes.get(words[-1].lower()) if words else None
            footprint = loc.footprint
            if (size is not None and footprint is not None
                    and (all(abs(v - size) <= KNOWN_SIZE_TOL_MM for v in footprint[:2])
                         or (only and words[-1].lower() == "cube" and near))):
                loc = replace(loc, footprint=(size, size, footprint[2]))
            out.append(loc)
        return out

    def measured_cube_mm(self) -> Optional[float]:
        """What the cubes on the table measure (the middle of the recent readings of their narrow sides), or None until
        there are enough readings. A cube 20 mm with the size set to 25 is read near 25 and called 25 mm (within
        KNOWN_SIZE_TOL_MM): this is what it really measured."""
        readings = getattr(self, "cube_readings", ())
        return float(np.median(readings)) if len(readings) >= MIN_CUBE_READINGS else None

    def note_moved(self, object_id: str, xyz_robot: tuple[float, float, float]) -> None:
        """The robot has just carried an object here. Tracking matches each object to where it was last seen,
        within `match_distance_mm`; after a longer move it would otherwise get a new id, and an id the model
        is still using ("put the blue cube on obj_3") would stop working."""
        self._previous = [replace(o, xyz_robot=tuple(xyz_robot)) if o.id == object_id else o for o in self._previous]

    def reset_tracking(self) -> None:
        """Forget the objects seen so far (a new scene was set out): ids start again from the next look."""
        self._previous = []
        self.cube_readings.clear()

    def _look(self, detector=None) -> list[LocatedObject]:
        frame = self.camera.get_frame()
        if frame.depth is None:
            raise RuntimeError("Camera frame has no depth data; scene localization requires depth.")
        if detector is not None:                   # (footprints_near: the depth detector's outlines)
            detector.cubes_only = self.cubes_only
            return self._known(self._corrected(detector.locate(frame, self.t_cam_to_robot)))
        if hasattr(self.detector, "locate"):       # finds and measures in one go (the depth detector)
            self.detector.cubes_only = self.cubes_only
            return self._known(self._corrected(self.detector.locate(frame, self.t_cam_to_robot)))
        located = []
        for det in self.detector.detect(frame.rgb):
            loc = locate_detection(det, frame.depth, frame.intrinsics, self.t_cam_to_robot)
            if loc is not None:
                located.append(loc)
        return self._known(self._corrected(located))

    def footprints_near(self, x: float, y: float, looks: int, within_mm: float = 15.0) -> list[tuple]:
        """The footprint of whatever is seen nearest (x, y) (within `within_mm`), from each of `looks` fresh pictures
        that show one: to read an object's turn more surely than from one picture (the tracking isn't touched)."""
        return [footprint for footprint, _ in self.looks_near(x, y, looks, within_mm)]

    def looks_near(self, x: float, y: float, looks: int, within_mm: float = 15.0) -> list[tuple]:
        """footprints_near's, each with where it was seen in that picture: [(footprint, (x, y, z) robot mm)] -- a pick
        reads where the cube is now from the same pictures it reads its turn from (V4.3)."""
        out = []
        # the depth detector reads an outline's turn; the colour finder gives none: the depth one, if there is one
        depth = getattr(self.detector, "depth", None)
        for _ in range(looks):
            try:
                located = self._look(depth if hasattr(depth, "locate") else None)
            except Exception:  # noqa: BLE001 - a picture missed is one reading fewer
                continue
            near = [loc for loc in located if loc.footprint is not None
                    and math.dist(loc.xyz_robot[:2], (x, y)) <= within_mm]
            if near:
                seen = min(near, key=lambda loc: math.dist(loc.xyz_robot[:2], (x, y)))
                out.append((seen.footprint, tuple(float(v) for v in seen.xyz_robot)))
        return out

    def get_scene(self) -> list[SceneObject]:
        located = self._look()
        settings = getattr(self.detector, "settings", None)
        looks = getattr(settings, "steady_looks", 1) if settings is not None else 1
        for _ in range(max(0, int(looks) - 1)):
            # against phantoms: only what is seen again in the next picture(s), about where it was (depth noise on
            # a real camera makes things that come and go from one picture to the next)
            again = self._look()
            located = [loc for loc in located
                       if any(math.dist(loc.xyz_robot[:2], other.xyz_robot[:2]) <= STEADY_MM for other in again)]

        current: list[SceneObject] = []
        used_prev: set[str] = set()
        for loc in located:
            match = self._find_match(loc, used_prev)
            if match is not None:
                used_prev.add(match.id)
                current.append(SceneObject(id=match.id, label=self._kept_label(loc, match, located),
                                           xyz_robot=loc.xyz_robot, confidence=loc.confidence,
                                           footprint=loc.footprint))
            else:
                new_id = f"obj_{next(self._id_counter)}"
                current.append(SceneObject(id=new_id, label=loc.label, xyz_robot=loc.xyz_robot,
                                           confidence=loc.confidence, footprint=loc.footprint))

        self._previous = current
        return current

    @staticmethod
    def _kept_label(loc: LocatedObject, before: SceneObject, located: list[LocatedObject]) -> str:
        """Its name: as seen now -- unless it is in a pile now (something on it, or it on something) and only the
        kind changed (same colour): then as it was seen before. With a cube on it, a cylinder seen from above is
        mostly hidden and its edge looked square: it was renamed "grey cube", and a prompt about "the cylinder" lost
        it; the cube on top of it was renamed "black cylinder" too."""
        if loc.label == before.label or loc.label.split()[:-1] != before.label.split()[:-1]:
            return loc.label
        in_a_pile = any(other is not loc and math.dist(other.xyz_robot[:2], loc.xyz_robot[:2]) <= UNDER_MM
                        and abs(other.xyz_robot[2] - loc.xyz_robot[2]) > 5.0 for other in located)
        return before.label if in_a_pile else loc.label

    def _find_match(self, loc: LocatedObject, used_ids: set[str]) -> SceneObject | None:
        best, best_dist = None, self.match_distance_mm
        for prev in self._previous:
            if prev.id in used_ids or prev.label != loc.label:
                continue
            dist = np.linalg.norm(np.array(prev.xyz_robot) - np.array(loc.xyz_robot))
            if dist < best_dist:
                best, best_dist = prev, dist
        if best is None:
            # the same object where it was, named a little differently this time ("grey" / "white" in other light):
            # it keeps its id, so a prompt that is using it doesn't lose it
            for prev in self._previous:
                if prev.id in used_ids:
                    continue
                dist = np.linalg.norm(np.array(prev.xyz_robot) - np.array(loc.xyz_robot))
                if dist < min(best_dist, SAME_SPOT_MM):
                    best, best_dist = prev, dist
        return best

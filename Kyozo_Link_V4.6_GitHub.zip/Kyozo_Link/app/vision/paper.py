"""The study's printed A4 sheet: where it goes, its four corner spots, and finding it with the camera.

The sheet lies landscape in front of the robot, its long side along the robot's left-right (y), its middle at
DESIGNED_CENTRE. Its four corner spots are where the cubes start; each spot's outline is printed turned by the arm's
own angle there (atan2(y, x)), so with the wrist in its middle (J4 = 0) the fingers close squarely on a cube put on
its outline -- no wrist turn, no gripper-angle error, for the first pick from each spot. A straight outline at the
middle is where the cube calibration starts ("Cube calibration with paper").

Robot coordinates, mm: x straight out from the base, +y the robot's left. Turns in degrees, counter-clockwise seen
from above.

The camera finds the sheet itself (white on the dark cloth) once a calibration exists: find_paper. Its pose -- where
the sheet's middle really is and how far it is turned -- is kept next to the calibration it was found with (paper_path:
calibration.json's in calibration_paper.json), and every spot follows it.
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

import numpy as np

# the paper it is printed on (config.yaml, study: paper: a4 or letter): (name, (long side, short side) mm). US Letter
# because that's what the lab's printers hold (Rafi, 2026-10-18): an A4 page printed on it measured 278 x 216 mm and
# wasn't found. The spots and the centre are at the same robot positions on both: they fit on either with room.
PAPERS = {"a4": ("A4", (297.0, 210.0)), "letter": ("US Letter", (279.4, 215.9))}


def _configured_paper() -> str:
    try:
        from app.config import load_config
        name = str((load_config().get("study") or {}).get("paper", "a4")).strip().lower()
    except Exception:  # noqa: BLE001 - no config to read: the design's A4
        name = "a4"
    return name if name in PAPERS else "a4"


PAPER = _configured_paper()
PAPER_NAME, PAPER_MM = PAPERS[PAPER]       # (along y: the robot's left-right, along x: out from the base)


def use_paper(name: str) -> None:
    """Lay out and look for this paper from now on ("a4" or "letter")."""
    global PAPER, PAPER_NAME, PAPER_MM
    key = str(name).strip().lower()
    if key not in PAPERS:
        raise ValueError(f"No paper called {name!r}: {', '.join(PAPERS)}")
    PAPER = key
    PAPER_NAME, PAPER_MM = PAPERS[key]


DESIGNED_CENTRE = (225.0, 0.0)
CUBE_MM = 25.0
# the corner spots, as designed: number -> (x, y). Near-left, far-left, far-right, near-right.
SPOTS = {1: (180.0, 80.0), 2: (265.0, 80.0), 3: (265.0, -80.0), 4: (180.0, -80.0)}
SPOT_NAMES = {1: "near-left", 2: "far-left", 3: "far-right", 4: "near-right"}
SIZE_TOLERANCE_MM = 6.0                   # a bright patch measuring further than this from the paper isn't the sheet
WELL_PLACED = (8.0, 3.0)                  # mm, degrees from the designed place: further, "place the paper again"
MOVED = (3.0, 1.0)                        # mm, degrees: the paper moved since it was found


def designed_turn(x: float, y: float) -> float:
    """The arm's angle at (x, y), J1 = atan2(y, x): the turn a cube there needs for the wrist in its middle to grip
    it squarely (r = J1 + J4, J4 = 0)."""
    return math.degrees(math.atan2(y, x))


@dataclass
class PaperPose:
    """Where the sheet's middle is and how far it is turned from its designed lie (0: long side along y)."""
    x: float = DESIGNED_CENTRE[0]
    y: float = DESIGNED_CENTRE[1]
    turn_deg: float = 0.0
    found: str = "designed"                # "camera" (measured), "twin" (the simulator: exact), "designed"
    when: str = ""

    def to_robot(self, x: float, y: float) -> tuple[float, float]:
        """A designed point of the sheet (robot frame, as if the sheet lay where designed) where it really is."""
        dx, dy = x - DESIGNED_CENTRE[0], y - DESIGNED_CENTRE[1]
        t = math.radians(self.turn_deg)
        return (self.x + dx * math.cos(t) - dy * math.sin(t), self.y + dx * math.sin(t) + dy * math.cos(t))

    def spot(self, number: int) -> tuple[float, float, float]:
        """(x, y, outline turn) of a corner spot where the sheet really is: its printed turn is the designed arm
        angle, turned with the sheet."""
        sx, sy = SPOTS[number]
        x, y = self.to_robot(sx, sy)
        return x, y, designed_turn(sx, sy) + self.turn_deg

    def centre_mark(self) -> tuple[float, float, float]:
        x, y = self.to_robot(*DESIGNED_CENTRE)
        return x, y, self.turn_deg

    def corners(self) -> list[tuple[float, float]]:
        half_y, half_x = PAPER_MM[0] / 2.0, PAPER_MM[1] / 2.0
        cx, cy = DESIGNED_CENTRE
        return [self.to_robot(cx + ax * half_x, cy + ay * half_y) for ax, ay in ((-1, -1), (1, -1), (1, 1), (-1, 1))]

    def offset_from_designed(self) -> tuple[float, float, float]:
        """(towards the robot's left mm, away from the robot mm, turned deg) from where the sheet was designed."""
        return self.y - DESIGNED_CENTRE[1], self.x - DESIGNED_CENTRE[0], self.turn_deg

    def describe(self) -> str:
        left, out, turn = self.offset_from_designed()
        parts = []
        if abs(out) >= 0.5:
            parts.append(f"{abs(out):.0f} mm {'further from' if out > 0 else 'towards'} the robot")
        if abs(left) >= 0.5:
            parts.append(f"{abs(left):.0f} mm to the robot's {'left' if left > 0 else 'right'}")
        if abs(turn) >= 0.2:
            parts.append(f"turned {abs(turn):.1f}° {'anticlockwise' if turn > 0 else 'clockwise'}")
        return ", ".join(parts) or "where it was designed to be"

    def well_placed(self) -> bool:
        left, out, turn = self.offset_from_designed()
        return math.hypot(left, out) <= WELL_PLACED[0] and abs(turn) <= WELL_PLACED[1]

    def moved_from(self, other: "PaperPose") -> Optional[str]:
        """Why this pose isn't `other`'s (the paper slid), or None."""
        shift = math.hypot(self.x - other.x, self.y - other.y)
        turn = abs(((self.turn_deg - other.turn_deg) + 90.0) % 180.0 - 90.0)
        if shift > MOVED[0] or turn > MOVED[1]:
            return f"the paper moved {shift:.1f} mm and turned {turn:.1f}° since it was found"
        return None


DESIGNED = PaperPose()


def paper_path(calibration_file) -> Path:
    """Where the paper found with this calibration file is kept: one file each (calibration.json's in
    calibration_paper.json), so the demo's twin sheet is never taken for the real one. An old shared paper.json is
    ignored -- which calibration found it isn't known."""
    path = Path(calibration_file)
    return path.with_name(path.stem + "_paper.json")


def save_paper(path, pose: PaperPose) -> None:
    from app.fileutil import atomic_write_text
    atomic_write_text(Path(path), json.dumps(asdict(pose), indent=1))


def load_paper(path) -> Optional[PaperPose]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return PaperPose(**{k: data[k] for k in ("x", "y", "turn_deg", "found", "when") if k in data})
    except (OSError, ValueError, TypeError):
        return None


# ---- finding the sheet with the camera ----------------------------------------------------------------------------
@dataclass
class PaperFound:
    pose: Optional[PaperPose]
    size_mm: Optional[tuple[float, float]] = None      # (long, short) as measured
    reason: str = ""                                   # why not found, in words
    # the sheet's 4 corners in the CAMERA's coordinates (mm), found without the calibration: the tightest rectangle
    # round the outline on the sheet's own plane (calibration/continuous.py compares them through the calibration)
    corners_cam: Optional[np.ndarray] = None           # 4 x 3
    normal_cam: Optional[np.ndarray] = None            # the sheet's plane: its unit normal, towards the camera


def find_paper(rgb: np.ndarray, depth: np.ndarray, intrinsics, t_cam_to_robot: np.ndarray) -> PaperFound:
    """The sheet in one camera picture: the biggest bright, colourless patch; its outline's pixels carried onto the
    table through the camera (the table's plane, fitted to the sheet's own depth) and the calibration; the tightest
    rectangle round them in robot coordinates. Accepted only if it measures A4 (within SIZE_TOLERANCE_MM)."""
    import cv2
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    value, sat = hsv[..., 2].astype(np.float32), hsv[..., 1].astype(np.float32)
    level, _ = cv2.threshold(hsv[..., 2], 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    mask = ((value >= max(level, 90)) & (sat <= 70)).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return PaperFound(None, reason="nothing white in the picture")
    biggest = max(contours, key=cv2.contourArea)
    region = np.zeros_like(mask)
    cv2.drawContours(region, [biggest], -1, 1, thickness=-1)
    # the table's plane under the sheet, in the camera's coordinates, from the sheet's own depth (inside its edges)
    inner = cv2.erode(region, np.ones((15, 15), np.uint8)).astype(bool) & (depth > 0)
    rows, cols = np.nonzero(inner)
    if len(rows) < 200:
        return PaperFound(None, reason="the paper's depth isn't seen")
    step = max(1, len(rows) // 4000)
    rows, cols = rows[::step], cols[::step]
    z = depth[rows, cols].astype(np.float64)
    pts = np.stack([(cols - intrinsics.cx) * z / intrinsics.fx, (rows - intrinsics.cy) * z / intrinsics.fy, z], axis=1)
    centre = np.median(pts, axis=0)
    _, _, vt = np.linalg.svd(pts - centre, full_matrices=False)
    normal = vt[2]
    # the outline's pixels as rays, met with that plane, then into the robot's coordinates
    edge = biggest[:, 0, :].astype(np.float64)
    rays = np.stack([(edge[:, 0] - intrinsics.cx) / intrinsics.fx, (edge[:, 1] - intrinsics.cy) / intrinsics.fy,
                     np.ones(len(edge))], axis=1)
    along = (centre @ normal) / (rays @ normal)
    cam = rays * along[:, None]
    # the corners in the camera's own coordinates: the tightest rectangle on the sheet's plane (no calibration used)
    basis = vt[:2]
    box = cv2.boxPoints(cv2.minAreaRect(((cam - centre) @ basis.T).astype(np.float32))).astype(np.float64)
    corners_cam = centre + box @ basis
    normal_cam = normal if normal @ centre < 0 else -normal          # (towards the camera, at the origin)
    robot = (np.asarray(t_cam_to_robot, float) @ np.hstack([cam, np.ones((len(cam), 1))]).T).T[:, :2]
    (cx, cy), (w, h), angle = cv2.minAreaRect(robot.astype(np.float32))
    long_side, short_side = max(w, h), min(w, h)
    size = (round(float(long_side), 1), round(float(short_side), 1))
    if abs(long_side - PAPER_MM[0]) > SIZE_TOLERANCE_MM or abs(short_side - PAPER_MM[1]) > SIZE_TOLERANCE_MM:
        bigger = long_side > PAPER_MM[0] + SIZE_TOLERANCE_MM or short_side > PAPER_MM[1] + SIZE_TOLERANCE_MM
        return PaperFound(None, size, reason=(
            f"the white patch measures {long_side:.0f} x {short_side:.0f} mm, not {PAPER_NAME} ({PAPER_MM[0]:.0f} x "
            f"{PAPER_MM[1]:.0f}; config.yaml study: paper says which): " +("bigger than the sheet -- tape over its edges or corners (tape it underneath, "
                                       "or with dark tape inside its edges), or the arm or something white or shiny "
                                       "touching it in the picture?" if bigger else
                                       "is all of the paper in view (the arm out of the way)?")))
    # the long side's direction, as a turn from the robot's y axis, kept within +-45
    long_angle = angle + (90.0 if h > w else 0.0)
    turn = ((long_angle - 90.0) + 90.0) % 180.0 - 90.0     # (a rectangle: the same every half turn)
    import time
    return PaperFound(PaperPose(round(float(cx), 2), round(float(cy), 2), round(float(turn), 2), "camera",
                                time.strftime("%Y-%m-%d %H:%M:%S")), size, corners_cam=corners_cam,
                      normal_cam=normal_cam)


def find_paper_with(camera, t_cam_to_robot, looks: int = 3) -> PaperFound:
    """find_paper on a few pictures, the middle one of the poses kept (one picture's glare doesn't decide)."""
    found = []
    last = PaperFound(None, reason="no picture")
    for _ in range(max(1, looks)):
        frame = camera.get_frame()
        last = find_paper(frame.rgb, frame.depth, camera.get_intrinsics(), t_cam_to_robot)
        if last.pose is not None:
            found.append(last)
    if not found:
        return last
    found.sort(key=lambda f: (f.pose.x, f.pose.y))
    return found[len(found) // 2]

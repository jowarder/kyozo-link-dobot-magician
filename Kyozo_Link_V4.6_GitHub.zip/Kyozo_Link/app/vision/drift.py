"""Noticing that the camera has moved since it was calibrated.

A calibration is only true for the camera's position at the time. If the camera or its mount
gets nudged, everything the camera reports is quietly wrong. So when calibration finishes we
save a reference: a small picture and where the table was. Later we compare:

  * the picture -- static things (table edge, robot base, cables) shift if the camera moved;
    we match features and see how the picture as a whole has slid, turned or scaled. The arm
    and any moved objects simply fail to match and are ignored.
  * the table -- seen through the calibration, it should still be at the same height and level.
    A camera that moved or tilted puts it somewhere else.

Neither is perfect, so a result can also be "can't tell" (a plain, featureless view).
"""
from __future__ import annotations

import io
import logging
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from app.fileutil import atomic_write_bytes, set_aside_damaged
from app.vision.table import measure_table

logger = logging.getLogger(__name__)

REFERENCE_WIDTH = 640
MOVED_SHIFT_PX = 1.5       # the picture slid this much (measured at 640 px wide: ~3 px in the full picture, ~2 mm)
MOVED_ROTATION_DEG = 0.35
MOVED_SCALE = 0.01         # closer/further away by this fraction
MOVED_TABLE_DZ_MM = 5.0
MOVED_TABLE_TILT_DEG = 1.0
MIN_INLIERS = 15


@dataclass
class ViewReference:
    gray: np.ndarray                     # the picture, shrunk to REFERENCE_WIDTH wide
    table_z_mm: Optional[float]          # table height in the robot frame, through the calibration
    table_tilt_deg: Optional[float]
    created: str

    def save(self, path: str | Path) -> None:
        buffer = io.BytesIO()
        np.savez_compressed(buffer, gray=self.gray, created=self.created,
                            table_z_mm=np.nan if self.table_z_mm is None else self.table_z_mm,
                            table_tilt_deg=np.nan if self.table_tilt_deg is None else self.table_tilt_deg)
        atomic_write_bytes(path, buffer.getvalue())

    @staticmethod
    def load(path: str | Path) -> Optional["ViewReference"]:
        file = Path(path)
        if not file.exists():
            return None
        try:
            # opened here, so it is closed even when numpy can't read it (it then left it open, and on Windows
            # the damaged file couldn't be set aside)
            with open(file, "rb") as handle, np.load(handle, allow_pickle=False) as data:
                z, tilt = float(data["table_z_mm"]), float(data["table_tilt_deg"])
                return ViewReference(data["gray"], None if math.isnan(z) else z,
                                     None if math.isnan(tilt) else tilt, str(data["created"]))
        except Exception as exc:  # noqa: BLE001 - empty, truncated, or not an archive at all: just no reference
            logger.warning("Could not read the saved camera reference %s (%s); it will be remade at the next "
                           "calibration", file.name, exc)
            set_aside_damaged(file)
            return None


@dataclass
class DriftReport:
    status: str                      # "ok", "moved" or "unknown"
    message: str
    shift_px: Optional[float] = None       # in the full-size picture
    rotation_deg: Optional[float] = None
    table_dz_mm: Optional[float] = None
    table_dtilt_deg: Optional[float] = None
    matches: int = 0

    @property
    def moved(self) -> bool:
        return self.status == "moved"


def reference_path(calibration_file: str | Path) -> Path:
    """Where the reference for a calibration file is kept: next to it."""
    path = Path(calibration_file)
    return path.with_name(path.stem + ".reference.npz")


def _shrunk_gray(rgb: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    scale = REFERENCE_WIDTH / gray.shape[1]
    return cv2.resize(gray, (REFERENCE_WIDTH, int(round(gray.shape[0] * scale))), interpolation=cv2.INTER_AREA)


def capture_reference(camera, transform: np.ndarray) -> ViewReference:
    frame = camera.get_frame()
    try:
        plane = measure_table(camera, transform)
    except Exception:  # noqa: BLE001 - a reference without the table part is still useful
        plane = None
    return ViewReference(_shrunk_gray(frame.rgb), None if plane is None else plane.z_mm,
                         None if plane is None else plane.tilt_deg, time.strftime("%Y-%m-%d %H:%M:%S"))


def picture_affine(reference: np.ndarray, current: np.ndarray,
                   mask: Optional[np.ndarray] = None) -> Optional[tuple[np.ndarray, int]]:
    """How the current picture has moved relative to the reference, as the 2 x 3 matrix carrying a reference pixel to
    where it is now (a turn, a scale and a shift; both pictures REFERENCE_WIDTH wide), and the matched features that
    agree with it -- or None if there weren't enough distinctive ones. `mask`: where in the reference features may be
    taken from (non-zero; None: anywhere), e.g. not on something that may itself have moved."""
    orb = cv2.ORB_create(nfeatures=2000, fastThreshold=8)
    kp_ref, des_ref = orb.detectAndCompute(reference, mask)
    kp_now, des_now = orb.detectAndCompute(current, None)
    if des_ref is None or des_now is None or len(kp_ref) < MIN_INLIERS or len(kp_now) < MIN_INLIERS:
        return None
    pairs = cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(des_ref, des_now, k=2)
    # keep only distinctive matches: a repeating pattern (a grid) matches many places equally well
    good = [m for m, n in (p for p in pairs if len(p) == 2) if m.distance < 0.75 * n.distance]
    if len(good) < MIN_INLIERS:
        return None
    src = np.float32([kp_ref[m.queryIdx].pt for m in good])
    dst = np.float32([kp_now[m.trainIdx].pt for m in good])
    matrix, inliers = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=2.0,
                                                  maxIters=3000, confidence=0.995)
    if matrix is None or inliers is None or int(inliers.sum()) < MIN_INLIERS:
        return None
    return matrix, int(inliers.sum())


def _picture_shift(reference: np.ndarray, current: np.ndarray) -> Optional[tuple[float, float, float, int]]:
    """How the current picture has moved relative to the reference: (shift px, rotation deg,
    scale change, matched features), or None if there weren't enough distinctive features."""
    found = picture_affine(reference, current)
    if found is None:
        return None
    matrix, count = found
    centre = np.array([reference.shape[1] / 2, reference.shape[0] / 2, 1.0])
    shift = float(np.linalg.norm(matrix @ centre - centre[:2]))
    rotation = math.degrees(math.atan2(matrix[1, 0], matrix[0, 0]))
    scale = math.hypot(matrix[0, 0], matrix[1, 0]) - 1.0
    return shift, rotation, scale, count


def check_view(camera, transform: np.ndarray, reference: ViewReference) -> DriftReport:
    """Compare what the camera sees now with the reference saved at calibration."""
    frame = camera.get_frame()
    picture = _picture_shift(reference.gray, _shrunk_gray(frame.rgb))
    try:
        plane = measure_table(camera, transform)
    except Exception:  # noqa: BLE001
        plane = None

    problems: list[str] = []
    report = DriftReport("unknown", "")
    factor = frame.rgb.shape[1] / REFERENCE_WIDTH
    if picture is not None:
        shift, rotation, scale, count = picture
        report.shift_px, report.rotation_deg, report.matches = shift * factor, rotation, count
        if shift >= MOVED_SHIFT_PX:
            problems.append(f"the picture has slid by about {shift * factor:.0f} px")
        if abs(rotation) >= MOVED_ROTATION_DEG:
            problems.append(f"the picture has turned by {rotation:.1f} degrees")
        if abs(scale) >= MOVED_SCALE:
            problems.append(f"the scene looks {abs(scale) * 100:.0f}% {'closer' if scale > 0 else 'further away'}")
    if plane is not None and reference.table_z_mm is not None:
        report.table_dz_mm = plane.z_mm - reference.table_z_mm
        if abs(report.table_dz_mm) >= MOVED_TABLE_DZ_MM:
            problems.append(f"the table now measures {abs(report.table_dz_mm):.0f} mm "
                            f"{'higher' if report.table_dz_mm > 0 else 'lower'} than at calibration")
        if reference.table_tilt_deg is not None:
            report.table_dtilt_deg = plane.tilt_deg - reference.table_tilt_deg
            if abs(report.table_dtilt_deg) >= MOVED_TABLE_TILT_DEG:
                problems.append(f"the table now looks tilted by an extra {abs(report.table_dtilt_deg):.1f} degrees")

    if problems:
        report.status = "moved"
        report.message = "The camera looks moved since calibration: " + "; ".join(problems) + ". Recalibrate."
    elif picture is None and (plane is None or reference.table_z_mm is None):
        report.message = ("Can't tell whether the camera has moved: the view has too few distinctive features "
                          "and the table couldn't be measured.")
    else:
        report.status = "ok"
        checked = []
        if picture is not None:
            checked.append(f"the picture matches ({report.matches} features)")
        if report.table_dz_mm is not None:
            checked.append(f"the table is where it was ({report.table_dz_mm:+.1f} mm)")
        report.message = "The camera hasn't moved since calibration: " + " and ".join(checked) + "."
    return report

"""Finds objects by shape, not colour: anything standing up from the table, whatever it is made of.

The depth camera gives every pixel's distance; with the calibration that is a height above the table. Whatever
stands more than MIN_HEIGHT_MM up, within the arm's reach and away from the arm itself, is part of an object:

1. every flat patch (a cube's top, a cylinder's top, the part of a lower cube a stack leaves showing, the crown of
   a ball) is where one object begins;
2. from those, each object takes in its own sides and curved surface, highest first, so the side of a cube on top
   of another goes with the upper one and the lower one's own top stays the lower one's;
3. each is then measured (outline, size, how it is turned, height) and named by its colour and its shape:
   "white cube", "brown block", "grey cylinder", "orange ball", "blue bar", "black disc".

It finds what the colour detector can't (white, black, grey, wood, any colour) and names shapes, but it can't tell
two objects apart that touch at the same height, and it doesn't see what the depth camera can't: clear glass or
plastic (seen through), and at times very dark matte or mirror-shiny surfaces (gaps in the depth picture).
"""
from __future__ import annotations

import heapq
import logging
import math
import threading
from typing import Callable, Optional

import cv2
import numpy as np

from app.vision.detector import Detection
from app.vision.locator import LocatedObject, measure_footprint

logger = logging.getLogger(__name__)

MIN_HEIGHT_MM = 5.0          # less than this above the table is the table (and its noise, a sheet of paper)
PICK_AREA_MARGIN_MM = 40.0   # with a pick area set, looked at this far past its edges (objects judged by their middle)
MAX_HEIGHT_MM = 150.0
REACH_MM = (110.0, 330.0)    # nearer is the robot's own base; farther the arm can't reach
BEHIND_DEG = 95.0            # further round than this from straight out (J1 turns +-90) is behind the arm: never reached
TABLE_BAND_MM = 15.0         # the table is looked for this near the height it was measured at...
TABLE_FIT_MM = 3.0           # ...and fitted as a plane to what lies this close to it (a real one isn't level in the
                             # arm's frame: a calibration tilt of 1.5 degrees, a warped card mat)
MAX_TABLE_TILT_DEG = 8.0     # a fit tilted more than this is not the table: then taken as level
MIN_TABLE_POINTS = 500
FLAT_MM = 3.0                # a top's height varies less than this across it (its steps split tops apart)
FLAT_SLOPE = 0.35            # rising less than this much per mm across the table is flat: part of a top (a side
                             # is vertical; judged in mm on the table, not per pixel, which an angled camera skews)
SLOPE_STEP_PX = 2            # the slope is taken across this many pixels either side, after smoothing the noise
MIN_SEED_PX = 12             # a flat patch smaller than this is noise, not a top
MIN_OBJECT_PX = 40
BULGE_RATIO = 1.4            # an outline this much wider than its flat top bulges out: a ball
ARM_CLEARANCE_MM = 32.0      # points this near the arm's links are the arm (or what it carries)
GRIPPER_BODY_MM = 75.0       # ...and this near the tool's axis, above the fingers, the gripper's body (its air cylinder
                             # stands out 70 mm to one side: on the real arm, it and the marker card were "objects")
FLOOD_MARGIN_MM = 4.0        # a straight-sided object's surface reaches this far past its top's outline, seen from above
UNDER_JOIN_MM = 25.0         # the visible ends of something under a stack are this near the stack
SLIVER_MM = 15.0             # a flat top this narrow is a sliver: what sticks out from under a stack
SLIVER_TOUCH_MM = 6.0        # ...and it lies against the stack's top, seen from above
UPHILL_MM = 1.5              # an object's surface is taken in going down from its top (this much up: noise)
REACH_OUT = 1.6              # an object's surface reaches this far out from its top's middle, times the top's own
                             # size (a ball's widest point is ~1.4 times its flat crown's)
HIGH_TOP_MM = 62.0           # ... a top this high (a tower of three): its turn always by its flat top -- two cubes'
                             # side faces pull the outline (1.5 degrees read 7.0, under the 5-degree rule: missed)
RAISED_PULL_DEG = 5.0        # ... and its outline's turn this far from its flat top's: read by the top
RAISED_TOP_MM = 37.0         # a top this far above the table stands on something: its turn read from its flat top
PLACE_SIZE_MM = 50.0         # something this big round a saved place is that place (a tray, a bin), not an object
WALL_MM = 4.0                # a tray's or bin's wall, where its size is known (the demo's)
THIN_MM = 4.0                # narrower than this is a wall or an edge (a tray's, a bin's), not an object
MIN_FILL = 0.35              # an object covers at least this much of its outline seen from above; a bin's walls cut
                             # into pieces by the edge of the reach (an L of thin walls) cover ~15%
CORNER = 0.6                 # a top's corners: beyond this share of its half-width and half-length from its middle
ROUND_CORNERS = 0.45         # filled less than this (1: a full rectangle, ~0.13: a circle), it is round
TOP_LEVEL_MM = 3.0           # a top, for its shape: what is this near its (smoothed) height
WHOLE_TOP = 0.7              # a flat top this much of that is whole (not broken up by noise)
COLOUR_TOP_MM = 4.0          # only cubes: a top face by colour is its colour's pixels this near its flat top's height...
COLOUR_TOP_MIN_MM = 12.0     # ...at least this wide...
COLOUR_TOP_SQUARE = 1.3      # ...and no longer than this times its width (else its turn is read as before)
SMOOTH_PX = 5                # heights are averaged over this many pixels square (within the objects) before the tops are
                             # found: a real depth camera's noise cut one cube's top into two or three
STEP_MM = 2.0                # two tops touching are split where their (smoothed) heights jump by more than this
SPLIT_SHARE = 0.2            # two tops touching at one height are split by colour where each colour is at least this
SPLIT_WHOLE = 0.7            # ...share of the top's coloured pixels, and mostly (this share) in one piece
PIECE_LEVEL_MM = 5.0         # pieces of one colour this level with each other...
PIECE_GAP_MM = 4.0           # ...and this close, seen from above, are one object (a top broken up by the camera's holes)
HOLE_GAP_MM = 15.0           # ...or this far apart with only a hole in the depth picture between them (no table seen)
HOLE_SEARCH_PX = 12          # (looked for this many pixels round the two)


def colour_name(rgb_pixels: np.ndarray) -> str:
    """A plain colour word for a set of pixels (N x 3, RGB): the middle of their hue, saturation and brightness."""
    if rgb_pixels.size == 0:
        return "grey"
    hsv = cv2.cvtColor(rgb_pixels.reshape(-1, 1, 3).astype(np.uint8), cv2.COLOR_RGB2HSV).reshape(-1, 3)
    saturation, value = np.median(hsv[:, 1]), np.median(hsv[:, 2])
    if value < 55:
        return "black"
    if saturation < 50:
        return "white" if value > 165 else "grey"
    coloured = hsv[hsv[:, 1] >= 50]
    # hue is a circle (0..179): take the middle on the circle, so reds either side of 0 don't average to cyan
    angles = coloured[:, 0].astype(float) * 2.0 * math.pi / 180.0
    hue = (math.degrees(math.atan2(np.sin(angles).mean(), np.cos(angles).mean())) / 2.0) % 180.0
    if hue < 8 or hue >= 170:
        return "red"
    if hue < 20:
        return "orange" if value > 170 else "brown"
    if hue < 35:
        return "yellow" if value > 150 else "brown"
    if hue < 85:
        return "green"
    if hue < 100:
        return "teal"
    if hue < 130:
        return "blue"
    if hue < 160:
        return "purple"
    return "pink"


def colour_groups(rgb_pixels: np.ndarray) -> np.ndarray:
    """Each pixel's colour group, for telling two touching tops apart (N x 3, RGB -> N): 0 the warm ones (red, orange,
    brown, yellow, pink), 1 green, 2 blue and purple, -1 none (grey, dark, or a hue between two: teal, the edge where
    green meets blue). Wide groups, clear gaps between them: a top's own shading never spans two."""
    hsv = cv2.cvtColor(rgb_pixels.reshape(-1, 1, 3).astype(np.uint8), cv2.COLOR_RGB2HSV).reshape(-1, 3)
    hue, coloured = hsv[:, 0], (hsv[:, 1] >= 80) & (hsv[:, 2] >= 55)
    groups = np.full(len(hsv), -1, np.int8)
    groups[coloured & ((hue < 35) | (hue >= 160))] = 0
    groups[coloured & (hue >= 40) & (hue < 80)] = 1
    groups[coloured & (hue >= 100) & (hue < 155)] = 2
    return groups


# colour_groups' group of each top colour word (-1: none -- teal lies between two)
GROUP_OF = {"red": 0, "orange": 0, "brown": 0, "yellow": 0, "pink": 0, "green": 1, "blue": 2, "purple": 2}


def under_colour(rgb_pixels: np.ndarray, top_word: str) -> str:
    """The colour word for an object seen only by its sides, under one of colour `top_word`: its pixels in the top's
    own colour group left out (depth noise at the edge between them mixes the top's in), and "teal" -- the hue between
    green and blue -- settled by which of the two groups most of them are in. Study 3, S-14: a green cube under a
    blue one was named "teal" (the warm lamp, its shaded sides, the blue edge mixed in), and "the blue cube to the
    left of the green cube" was refused: "there is no green one"."""
    groups = colour_groups(rgb_pixels)
    own = GROUP_OF.get(top_word, -1)
    keep = groups != own if own >= 0 else np.ones(len(groups), bool)
    pixels = rgb_pixels[keep] if keep.sum() >= 10 else rgb_pixels
    word = colour_name(pixels)
    if word == "teal":
        kept = groups[keep] if keep.sum() >= 10 else groups
        green, blue = int((kept == 1).sum()), int((kept == 2).sum())
        if max(green, blue) >= 10 and max(green, blue) >= 2 * min(green, blue):
            word = "green" if green > blue else "blue"
    return word


# colours that the same object's shaded sides can pass for (a white top's sides look grey, a yellow one's brown)
FAMILY = {"white": "light", "grey": "light", "black": "black", "red": "red", "orange": "warm", "brown": "warm",
          "yellow": "warm", "green": "green", "teal": "green", "blue": "blue", "purple": "purple", "pink": "purple"}
BAND_MM = 3.0              # the sides are read in slices this tall
MIN_UNDER_MM = 8.0         # a change of colour lower down counts only if it holds for this much (and the top's
                           # colour for this much above it): an object under this one


def shape_name(width: float, length: float, height: float, round_top: bool, bulges: bool) -> str:
    """cube, block, bar, cylinder, ball, disc or flat piece, from the measurements (mm)."""
    if round_top and bulges and height >= 0.6 * length:
        return "ball"
    if height < 0.35 * width and height < 12.0:
        return "disc" if round_top else "flat piece"
    if length >= 2.2 * width:
        return "bar"
    if round_top:
        return "cylinder"
    if length - width <= max(3.0, 0.12 * length):
        # a square top: a cube (by its top: a cube on another shows sides down to the table, and looks twice as tall)
        return "cube"
    return "block"


def _in_box(x: float, y: float, bounds) -> bool:
    bx, by, hw, hh, c, s = bounds
    dx, dy = x - bx, y - by
    return abs(dx * c + dy * s) <= hw and abs(-dx * s + dy * c) <= hh


def _segment_distance(points: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    # plain arithmetic, no matrix products (see find: they go to OpenBLAS, which isn't safe from two threads at once)
    ab = b - a
    rel = points - a
    t = np.clip((rel[:, 0] * ab[0] + rel[:, 1] * ab[1] + rel[:, 2] * ab[2])
                / max(float(ab[0] ** 2 + ab[1] ** 2 + ab[2] ** 2), 1e-9), 0.0, 1.0)
    off = rel - t[:, None] * ab
    return np.sqrt(off[:, 0] ** 2 + off[:, 1] ** 2 + off[:, 2] ** 2)


def _robot():
    """The robot this run drives (its reach and size), or None before the robots package can be loaded."""
    try:
        from app import robots
        return robots.active()
    except Exception:  # noqa: BLE001
        return None


class DepthObjectDetector:
    """Objects by depth. `get_transform()` gives the camera -> robot calibration; `table_z_provider()` the table's
    height in the robot frame (None: worked out from the picture); `arm_provider()` the arm's geometry (its points
    are left out); `places_provider()` the saved places {name: (x, y, z)} (a tray round one is not an object)."""

    needs_depth = True
    overlay_every = 20          # frames between refreshes of a live feed's boxes: this costs more than colour

    def __init__(self, get_transform: Callable[[], np.ndarray],
                 table_z_provider: Callable[[], Optional[float]] = lambda: None,
                 arm_provider: Callable[[], Optional[object]] = lambda: None,
                 places_provider: Callable[[], dict] = lambda: {},
                 place_areas_provider: Callable[[], dict] = lambda: {}, settings=None):
        """`place_areas_provider()`: the inside of each tray or bin at a place {name: (width, depth, wall top z)}, when
        known (the demo's): its walls are then left out, not taken for part of what stands next to them. `settings`:
        a DetectionSettings (vision/detection_settings.py), for the height below which things are table, and the
        pick area (looked at with a margin: what stands across its edge is seen whole)."""
        self.get_transform = get_transform
        self.table_z_provider = table_z_provider
        self.arm_provider = arm_provider
        self.places_provider = places_provider
        self.place_areas_provider = place_areas_provider
        self.settings = settings
        self._lock = threading.Lock()

    # -- the detector interface: boxes for the camera feed, and located objects for the scene ----------------------
    def detect(self, rgb: np.ndarray, depth: Optional[np.ndarray] = None, intrinsics=None) -> list[Detection]:
        if depth is None or intrinsics is None:
            return []                    # a picture alone says nothing about height
        return [det for det, _ in self.find(rgb, depth, intrinsics, self.get_transform())]

    def locate(self, frame, t_cam_to_robot: np.ndarray) -> list[LocatedObject]:
        return [loc for _, loc in self.find(frame.rgb, frame.depth, frame.intrinsics, t_cam_to_robot)]

    # -- the work -----------------------------------------------------------------------------------------------------
    def find(self, rgb, depth, k, transform) -> list[tuple[Detection, LocatedObject]]:
        with self._lock:          # one look at a time (the prompt's and the camera feed's)
            return self._find(rgb, depth, k, transform)

    def _find(self, rgb, depth, k, transform) -> list[tuple[Detection, LocatedObject]]:
        h, w = depth.shape
        v, u = np.mgrid[0:h, 0:w]
        z = depth.astype(np.float32)
        valid = z > 0
        cx_, cy_ = (u - k.cx) * z / k.fx, (v - k.cy) * z / k.fy
        # element by element, not as a matrix product: numpy hands those to OpenBLAS, and this runs on two threads at
        # once (a prompt looking, and the camera feed's boxes) -- two OpenBLAS calls at once crashed the app outright
        rot, shift = transform[:3, :3], transform[:3, 3]
        px = rot[0, 0] * cx_ + rot[0, 1] * cy_ + rot[0, 2] * z + shift[0]
        py = rot[1, 0] * cx_ + rot[1, 1] * cy_ + rot[1, 2] * z + shift[1]
        pz = rot[2, 0] * cx_ + rot[2, 1] * cy_ + rot[2, 2] * z + shift[2]
        radius = np.hypot(px, py)
        near_mm, far_mm = _robot().detect_reach_mm if _robot() is not None else REACH_MM
        in_reach = (valid & (radius > near_mm) & (radius < far_mm)
                    & (np.abs(np.degrees(np.arctan2(py, px))) < BEHIND_DEG))
        area = self.settings.pick_area if self.settings is not None else None
        if area:
            in_reach &= ((px > area["x"][0] - PICK_AREA_MARGIN_MM) & (px < area["x"][1] + PICK_AREA_MARGIN_MM)
                         & (py > area["y"][0] - PICK_AREA_MARGIN_MM) & (py < area["y"][1] + PICK_AREA_MARGIN_MM))
        min_height = self.settings.min_height_mm if self.settings is not None else MIN_HEIGHT_MM
        table = self.table_z_provider()
        if table is None:
            if not in_reach.any():
                return []
            table = float(np.median(pz[in_reach]))    # mostly table: its middle height is the table's
        # heights from the table as the camera sees it here, not from one measured height: on the real arm the mat
        # came out 3 mm below that at one end and 6 mm above at the other, and dozens of bits of it were "objects"
        tilt_x, tilt_y, level = self._table_plane(px, py, pz, in_reach, table)
        height = pz - (tilt_x * px + tilt_y * py + level)
        mask = in_reach & (height > min_height) & (height < MAX_HEIGHT_MM)
        mask &= ~self._arm_mask(px, py, pz, mask)
        mask &= ~self._walls(px, py, height)
        mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)).astype(bool)
        if not mask.any():
            return []
        # from here on only the part of the picture with objects in it (the rest is table)
        ys, xs = np.nonzero(mask)
        margin = SLOPE_STEP_PX + 3
        y0, y1 = max(0, ys.min() - margin), min(h, ys.max() + margin + 1)
        x0, x1 = max(0, xs.min() - margin), min(w, xs.max() + margin + 1)
        mask, height = mask[y0:y1, x0:x1], height[y0:y1, x0:x1].astype(np.float32)
        px, py, pz, rgb = px[y0:y1, x0:x1], py[y0:y1, x0:x1], pz[y0:y1, x0:x1], rgb[y0:y1, x0:x1]
        filled = np.where(mask, height, 0.0).astype(np.float32)
        smooth = self._smoothed(filled, mask)
        flat = mask & (self._slope(filled, mask, px, py) < FLAT_SLOPE)
        # tops: flat patches, split where the height steps (two tops side by side at different heights)
        count, seeds = cv2.connectedComponents(flat.astype(np.uint8), connectivity=4)
        seeds = self._split_levels(seeds, count, smooth)
        seeds = self._split_colours(seeds, rgb)
        labels = self._flood(seeds, mask, smooth, px, py)
        labels, seeds = self._join_pieces(labels, seeds, pz, px, py, rgb, ~valid[y0:y1, x0:x1])

        places = [(float(x), float(y)) for x, y, *_ in self.places_provider().values()]
        found, tops = [], []            # tops: each one's top seen from above (None: seen only by its sides)
        for label in np.unique(labels):
            if label <= 0:
                continue
            region = labels == label
            if region.sum() < MIN_OBJECT_PX:
                continue
            top = region & (seeds == label)
            points = np.stack([px[region], py[region], pz[region]], axis=1)
            top_points = np.stack([px[top], py[top], pz[top]], axis=1)
            if top_points.shape[0] < MIN_SEED_PX:
                continue
            footprint, (cx, cy) = measure_footprint(points[:, :2])
            if footprint is None:
                continue
            width, length, angle = footprint
            top_footprint, top_middle = measure_footprint(top_points[:, :2])
            if getattr(self, "cubes_only", False) and top_footprint is not None and min(top_footprint[:2]) >= 12.0:
                # only cubes: the middle is the flat top's -- the whole outline takes in a side face the camera sees
                # and is pulled toward it (in the twin 0.2-1 mm further off; at the lab a cube's edge was caught)
                cx, cy = top_middle
            if top_footprint is not None and min(top_footprint[:2]) >= 12.0:
                raised = float(np.median(top_points[:, 2])) - float(tilt_x * cx + tilt_y * cy + level)
                period = 90.0 if abs(top_footprint[0] - top_footprint[1]) < 3.0 else 180.0
                pulled = abs((top_footprint[2] - angle + period / 2.0) % period - period / 2.0)
                if raised > RAISED_TOP_MM:
                    # stacked: its middle is its flat top's -- the outline takes in the side faces the camera sees,
                    # reaching far below the top, and was pulled ~1 mm toward them: off the fingers' middle (the twin,
                    # 2026-10-24: the top of 8 app-built towers picked 8 times so, 5 or fewer by the outline)
                    cx, cy = top_middle
                if raised > RAISED_TOP_MM and (pulled > RAISED_PULL_DEG or raised > HIGH_TOP_MM):
                    # stacked, and its outline turned well away from its flat top: the side faces the camera sees,
                    # reaching far below the top, turned it (the twin, 2026-10-24: 21.9 degrees for a cube at 31.4 on
                    # one at -4.8 -- steady, so nothing caught it, and the fingers came down on it). Its turn is its
                    # flat top's then. Squared up on the one below, the outline's turn is the truer (the top's wanders 2)
                    footprint = (width, length, top_footprint[2])
                    width, length, angle = footprint
            if getattr(self, "cubes_only", False):
                # only cubes: the turn is its top face's, by colour -- the outline takes in the side faces the camera
                # sees, and the flat top loses its corners to depth noise; turned near 45 degrees both came out square
                # to the table (study 4, S-08: a blue cube at 45.6 read 1.0, gripped across its corners, it stuck in
                # the fingers)
                coloured = self._colour_top_turn(region, top_points, px, py, pz, rgb)
                if coloured is not None:
                    footprint = (width, length, coloured)
                    width, length, angle = footprint
            if (top_footprint is not None and max(top_footprint[:2]) >= PLACE_SIZE_MM
                    and self._fill(top_points[:, :2], top_footprint[0], top_footprint[1]) < MIN_FILL
                    and any(self._inside(px_, py_, cx, cy, width, length, angle) for px_, py_ in places)):
                # the tray (or bin) round a saved place -- its top a thin ring of walls round it: a place, not an
                # object. (Judged by the whole outline, two cubes in a tray with bits of wall between them were
                # dropped as "the tray", and the next thing was put down on one of them.)
                continue
            if width < THIN_MM or self._fill(points[:, :2], width, length) < MIN_FILL:
                continue                          # a wall, or walls: part of a tray or bin, or the table's edge
            top_z = float(np.median(top_points[:, 2]))
            # round or not by its flat top when that is big enough to tell (a block's is a clean rectangle, a
            # cylinder's a disc, while its outline can take in bits of neighbours packed close); by the whole outline
            # when the top is only a ball's crown, ~7 mm across: too few points to tell a circle from a square
            if top_footprint is not None and min(top_footprint[:2]) >= 12.0:
                # the top by its (smoothed) level, not only what the slope test kept as flat: with a real camera's
                # noise that was ragged and broken, and its lost corners made every cube "a cylinder"
                # -- unless the flat top is whole (a clean picture): then by that, as it was
                at_top = self._main_part(region & (smooth >= float(np.median(smooth[top])) - TOP_LEVEL_MM))
                flat_top = self._main_part(top)
                if flat_top.sum() >= WHOLE_TOP * at_top.sum():
                    at_top = flat_top
                round_top = self._round(np.stack([px[at_top], py[at_top]], axis=1))
            else:
                round_top = self._round(points[:, :2])
            if getattr(self, "cubes_only", False):
                # only cubes on the table (config.yaml, vision: cubes_only; set by the SceneBuilder): a top read round
                # is a cube's with its corners lost to depth noise -- named a cylinder, its turn set to 0 and its
                # middle taken from a circle, a turned cube was gripped square and missed (the lab, 2026-10-22)
                round_top = False
            # a ball's outline is two or three times its flat crown; a cylinder's side, seen at an angle, adds some 15%
            # to its top (a 24 mm can was "a grey ball" at 1.15)
            bulges = top_footprint is not None and max(width, length) > BULGE_RATIO * max(top_footprint[:2])
            if round_top:
                # a round one's middle is its outline circle's: the sides the camera sees crowd points onto the near
                # edge, and trimming the outline's stray points then took more off the far side (~1.5 mm)
                (cx, cy), radius = cv2.minEnclosingCircle(points[:, :2].astype(np.float32))
            table_here = float(tilt_x * cx + tilt_y * cy + level)
            name = f"{colour_name(rgb[top])} {shape_name(width, length, top_z - table_here, round_top, bulges)}"
            if round_top and bulges:
                # a ball's size is that circle's: part of it is out of sight, and its outline measured it 16 x 20 mm
                # for 22 -- the tray was then planned with too little room round it (a cylinder's flat top is all in
                # view: its outline is right)
                footprint = (round(2.0 * radius, 1), round(2.0 * radius, 1), 0.0)
            elif round_top:
                # a disc's tightest rectangle comes at any angle, a new one each picture: it has no turn
                footprint = (footprint[0], footprint[1], 0.0)
            ry, rx = np.nonzero(region)
            left, top_row, right, bottom = rx.min(), ry.min(), rx.max(), ry.max()
            detection = Detection(label=name, bbox=(int(x0 + left), int(y0 + top_row), int(right - left + 1),
                                                    int(bottom - top_row + 1)),
                                  center_px=(int(x0 + (left + right) // 2), int(y0 + (top_row + bottom) // 2)),
                                  confidence=1.0, mask=region[top_row:bottom + 1, left:right + 1])
            found.append((detection, LocatedObject(label=name, xyz_robot=(float(cx), float(cy), top_z),
                                                   confidence=1.0, footprint=footprint)))
            tops.append(top_points[:, :2])
            for under in self._underneath(region, top, pz, rgb, table_here, name, detection, (cx, cy), footprint):
                found.append(under)
                tops.append(None)
        return self._join_ends(found, tops)

    @staticmethod
    def _table_plane(px, py, pz, in_reach, table: float) -> tuple[float, float, float]:
        """The table under the objects as a plane, z = tilt_x * x + tilt_y * y + level, fitted to the points near the
        height it was measured at (again and again, keeping those within TABLE_FIT_MM of the last fit: the low
        objects drop out). Level at `table` if there is too little of it to go by, or the fit leans too far."""
        near = in_reach & (np.abs(pz - table) < TABLE_BAND_MM)
        xs, ys, zs = px[near][::5].astype(np.float64), py[near][::5].astype(np.float64), pz[near][::5].astype(np.float64)
        flat = (0.0, 0.0, float(table))
        if xs.size < MIN_TABLE_POINTS:
            return flat
        keep = np.ones(xs.size, bool)
        fit = flat
        for _ in range(4):
            x, y, z = xs[keep], ys[keep], zs[keep]
            if x.size < MIN_TABLE_POINTS:
                return flat
            # least squares by its normal equations, solved by hand (no matrix routines: see _find)
            n, sx, sy, sz = float(x.size), x.sum(), y.sum(), z.sum()
            sxx, syy, sxy, sxz, syz = (x * x).sum(), (y * y).sum(), (x * y).sum(), (x * z).sum(), (y * z).sum()
            m = ((sxx, sxy, sx), (sxy, syy, sy), (sx, sy, n))
            rhs = (sxz, syz, sz)

            def det3(a):
                return (a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1]) - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
                        + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]))
            d = det3(m)
            if abs(d) < 1e-9:
                return flat
            solved = []
            for col in range(3):
                swapped = [list(row) for row in m]
                for r in range(3):
                    swapped[r][col] = rhs[r]
                solved.append(det3(swapped) / d)
            fit = (float(solved[0]), float(solved[1]), float(solved[2]))
            keep = np.abs(zs - (fit[0] * xs + fit[1] * ys + fit[2])) < TABLE_FIT_MM
        if math.degrees(math.atan(math.hypot(fit[0], fit[1]))) > MAX_TABLE_TILT_DEG:
            return flat
        return fit

    @staticmethod
    def _join_ends(found: list, tops: list) -> list:
        """An object under a stack that sticks out from under it (a 40 mm block under a 25 mm cube) shows its top at
        both ends: each end was reported as an object of its own ("a brown bar"). An end at the height of an object
        found under a stack, of its colour and next to it, is that object: joined to it, it also gives its size.
        Whether an end is a sliver is judged by its own flat top: filled out to its sides, a 4 x 10 mm end of a
        block under a 20 mm cube measured 21 mm round, and was reported as "a brown ball".
        And where nothing was found under a stack (packed close in a tray, its sides are out of sight), a sliver of
        another colour against its top, lower down, is what it stands on: a 24 mm cylinder's rim round a 20 mm cube
        on it was reported as a cube of its own."""
        def sliver(points) -> bool:
            if points is None or len(points) < 3:
                return False
            (_, _), (a, b), _ = cv2.minAreaRect(points.astype(np.float32))
            return min(a, b) <= SLIVER_MM

        unders = [i for i, points in enumerate(tops) if points is None]
        drop = set()
        for u in unders:
            under = found[u][1]
            ends = []
            for i, points in enumerate(tops):
                if points is None or i in drop:
                    continue
                loc = found[i][1]
                # the same colour (not just close: an orange ball next to a brown block isn't the block), at its
                # height, a sliver (what sticks out from under a stack), and right beside the stack
                if (loc.label.split()[0] == under.label.split()[0]
                        and abs(loc.xyz_robot[2] - under.xyz_robot[2]) <= 4.0
                        and sliver(points)
                        and math.dist(loc.xyz_robot[:2], under.xyz_robot[:2])
                        <= max(under.footprint[:2]) / 2.0 + UNDER_JOIN_MM):
                    ends.append(points)
                    drop.add(i)
            if ends:
                width, length, angle = under.footprint
                c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
                corners = np.array([(under.xyz_robot[0] + i * length / 2 * c - j * width / 2 * s,
                                     under.xyz_robot[1] + i * length / 2 * s + j * width / 2 * c)
                                    for i, j in ((-1, -1), (1, -1), (1, 1), (-1, 1))])
                joined = np.concatenate([corners] + ends)
                (cx, cy), (w, h), turn = cv2.minAreaRect(joined.astype(np.float32))
                size = (round(float(min(w, h)), 1), round(float(max(w, h)), 1), round(turn + (90.0 if h > w else 0.0), 1) % 180.0)
                shape = shape_name(size[0], size[1], 0.0 + 99.0, False, False)
                label = f"{under.label.split()[0]} {shape}"
                found[u] = (found[u][0], LocatedObject(label=label, xyz_robot=(float(cx), float(cy), under.xyz_robot[2]),
                                                       confidence=under.confidence, footprint=size))
        # a sliver against a stack with nothing found under it: what the stack stands on
        has_under = {i for i in range(len(tops) - 1) if tops[i] is not None and tops[i + 1] is None}
        for i, points in enumerate(tops):
            if i in drop or not sliver(points):
                continue
            loc = found[i][1]
            for j, other in enumerate(tops):
                stack = found[j][1]
                if (j == i or other is None or j in drop or j in has_under or stack.footprint is None
                        or stack.xyz_robot[2] < loc.xyz_robot[2] + MIN_UNDER_MM
                        or loc.label.split()[0] == stack.label.split()[0]):
                    continue
                width, length, angle = stack.footprint
                (_, _), (a, b), _ = cv2.minAreaRect(points.astype(np.float32))
                if max(a, b) > length + 2 * SLIVER_TOUCH_MM:
                    continue                      # longer than the stack: something lying beside it, not a rim
                c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
                d = points - np.array(stack.xyz_robot[:2])
                out_along = np.abs(d[:, 0] * c + d[:, 1] * s) - length / 2.0
                out_across = np.abs(-d[:, 0] * s + d[:, 1] * c) - width / 2.0
                if np.hypot(np.maximum(out_along, 0.0), np.maximum(out_across, 0.0)).min() > SLIVER_TOUCH_MM:
                    continue                      # not against it
                corners = np.array([(stack.xyz_robot[0] + a * length / 2 * c - b * width / 2 * s,
                                     stack.xyz_robot[1] + a * length / 2 * s + b * width / 2 * c)
                                    for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))])
                (cx, cy), (w, h), turn = cv2.minAreaRect(np.concatenate([corners, points]).astype(np.float32))
                size = (round(float(min(w, h)), 1), round(float(max(w, h)), 1), round(turn + (90.0 if h > w else 0.0), 1) % 180.0)
                label = f"{loc.label.split()[0]} {shape_name(size[0], size[1], 99.0, False, False)}"
                found[i] = (found[i][0], LocatedObject(label=label, xyz_robot=(float(cx), float(cy), loc.xyz_robot[2]),
                                                       confidence=min(loc.confidence, 0.8), footprint=size))
                has_under.add(j)
                break
        return [item for i, item in enumerate(found) if i not in drop]

    def _underneath(self, region, top, pz, rgb, table, name, detection, centre, footprint) -> list:
        """Objects under this one that the camera sees only the sides of: a blue cube on a red cube shows a blue top
        and sides that turn red halfway down. Each change of colour down the sides (holding for MIN_UNDER_MM, with
        the colour above it holding as long) is the top of another object, reported as covered by this one -- the
        tools then know it is there and move the top one aside to get it. Same-colour objects can't be told apart."""
        side = region & ~top
        if side.sum() < 40:
            return []
        heights = pz[side] - table
        colours = rgb[side]
        order = np.argsort(-heights)
        heights, colours = heights[order], colours[order]
        top_height = float(np.median(pz[top]) - table)
        bands = []                                   # (upper edge, family, colour word), top down
        edge = top_height
        while edge > MIN_HEIGHT_MM:
            inside = (heights <= edge) & (heights > edge - BAND_MM)
            if inside.sum() >= 10:
                word = colour_name(colours[inside])
                bands.append((edge, FAMILY.get(word, word), word))
            edge -= BAND_MM
        found = []
        family = FAMILY.get(name.split()[0], name.split()[0])
        above_from = top_height
        for i, (edge, band_family, word) in enumerate(bands):
            if band_family == family:
                continue
            # its colour has to hold down the sides for MIN_UNDER_MM (one stray band allowed): as "most of what is
            # below", the middle cube of three (red between yellow and purple) was only half of it, and went unseen
            run, stray, j = 0, 0, i
            while j < len(bands):
                if bands[j][1] == band_family:
                    run += 1
                elif stray == 0 and j + 1 < len(bands) and bands[j + 1][1] == band_family:
                    stray += 1
                else:
                    break
                j += 1
            if run * BAND_MM < MIN_UNDER_MM or above_from - edge < MIN_UNDER_MM or edge < MIN_UNDER_MM:
                continue
            below = side & (pz - table <= edge)
            # seen only by its sides (two faces at most: their outline says little about its own), so it is right
            # under the one above -- one showing its own top would have been found by that -- and taken to be the
            # same size: where the one above is, and its outline. Its name: by its colour, and square or not.
            width, length, _ = footprint
            shape = shape_name(width, length, edge, False, False)
            label = f"{under_colour(rgb[below & (pz - table > edge - MIN_UNDER_MM)], name.split()[0])} {shape}"
            found.append((Detection(label=label, bbox=detection.bbox, center_px=detection.center_px, confidence=0.8,
                                    mask=None),
                          LocatedObject(label=label, xyz_robot=(float(centre[0]), float(centre[1]), float(edge + table)),
                                        confidence=0.8, footprint=footprint)))
            family, above_from = band_family, edge          # and perhaps another under that one
        return found

    def _walls(self, px, py, height) -> np.ndarray:
        """The walls of the trays and bins whose size is known: thin, so without a flat top of their own, they were
        taken in by whatever stood next to them (a cube by a wall came out as a 25 x 32 mm "ball")."""
        out = np.zeros(height.shape, bool)
        try:
            areas = self.place_areas_provider() or {}
            places = self.places_provider() or {}
        except Exception:  # noqa: BLE001 - nothing known: nothing left out
            return out
        for name, (width, depth, wall_top) in areas.items():
            if name not in places:
                continue
            x, y = places[name][0], places[name][1]
            dx, dy = np.abs(px - x), np.abs(py - y)
            inside = (dx < width / 2.0 - 1.0) & (dy < depth / 2.0 - 1.0)
            outline = (dx < width / 2.0 + WALL_MM + 2.0) & (dy < depth / 2.0 + WALL_MM + 2.0)
            out |= outline & ~inside & (height < wall_top + 2.0)
        return out

    def _arm_mask(self, px, py, pz, candidates) -> np.ndarray:
        """Points on (or right by) the arm: its links, the tool, what it carries, a marker card on the tool."""
        out = np.zeros(candidates.shape, bool)
        try:
            geometry = self.arm_provider()
        except Exception:  # noqa: BLE001 - no arm reading: nothing left out
            geometry = None
        if geometry is None or not candidates.any():
            return out
        idx = np.nonzero(candidates)
        points = np.stack([px[idx], py[idx], pz[idx]], axis=1)
        chain = [np.array(p, float) for p in (geometry.shoulder, geometry.elbow, geometry.wrist,
                                                geometry.tool_corner, geometry.tcp)]
        chain_ends = list(zip(chain, chain[1:])) + [(chain[3], chain[3] + np.array([0.0, 0.0, 60.0]))]
        near = np.zeros(points.shape[0], bool)
        robot = _robot()
        clearance = robot.arm_clearance_mm if robot is not None else ARM_CLEARANCE_MM
        body = robot.gripper_body_mm if robot is not None else GRIPPER_BODY_MM
        for a, b in chain_ends:
            near |= _segment_distance(points, a, b) < clearance
        tcp = chain[4]
        near |= ((np.hypot(points[:, 0] - tcp[0], points[:, 1] - tcp[1]) < body)
                 & (points[:, 2] > tcp[2] + 15.0) & (points[:, 2] < chain[3][2] + 60.0))
        out[idx[0][near], idx[1][near]] = True
        return out

    @staticmethod
    def _slope(height: np.ndarray, mask: np.ndarray, px: np.ndarray, py: np.ndarray) -> np.ndarray:
        """How steep the surface is at each point: height change per mm across the table, the larger of along the
        picture's rows and columns. Heights are smoothed first (within the objects only, not with the table round
        them): a real depth camera's millimetre of noise would otherwise make every top look rough."""
        weight = cv2.blur(mask.astype(np.float32), (5, 5))
        smooth = cv2.blur(np.where(mask, height, 0.0).astype(np.float32), (5, 5)) / np.maximum(weight, 1e-6)
        s = SLOPE_STEP_PX
        steep = np.full(height.shape, np.inf, np.float32)
        inner = np.zeros(height.shape, bool)
        inner[s:-s, s:-s] = (mask[s:-s, 2 * s:] & mask[s:-s, :-2 * s] & mask[2 * s:, s:-s] & mask[:-2 * s, s:-s])
        rise_x = np.abs(smooth[s:-s, 2 * s:] - smooth[s:-s, :-2 * s])
        run_x = np.hypot(px[s:-s, 2 * s:] - px[s:-s, :-2 * s], py[s:-s, 2 * s:] - py[s:-s, :-2 * s])
        rise_y = np.abs(smooth[2 * s:, s:-s] - smooth[:-2 * s, s:-s])
        run_y = np.hypot(px[2 * s:, s:-s] - px[:-2 * s, s:-s], py[2 * s:, s:-s] - py[:-2 * s, s:-s])
        steep[s:-s, s:-s] = np.maximum(rise_x / np.maximum(run_x, 1e-3), rise_y / np.maximum(run_y, 1e-3))
        steep[~inner] = np.inf
        return steep

    @staticmethod
    def _smoothed(filled: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """Heights smoothed over SMOOTH_PX square, within the objects: the middle value, so a wildly wrong pixel is
        dropped rather than spread round (averaged, one stretched a cube's top to 59 x 26 mm), then averaged a little
        (the table round them doesn't count)."""
        middle = cv2.medianBlur(filled.astype(np.float32), SMOOTH_PX)
        middle = np.where(mask, middle, 0.0).astype(np.float32)
        inside = (mask & (middle > 0)).astype(np.float32)
        weight = cv2.blur(inside, (3, 3))
        smooth = cv2.blur(middle, (3, 3)) / np.maximum(weight, 1e-6)
        return np.where(inside > 0, smooth, 0.0).astype(np.float32)

    @staticmethod
    def _split_levels(seeds: np.ndarray, count: int, height: np.ndarray) -> np.ndarray:
        """A flat patch whose heights jump somewhere is two tops that touch at a step: split it there, so a top and a
        lower, partly covered top next to it stay apart. Split where the heights, in order, jump by more than STEP_MM
        -- not into fixed 6 mm levels: a top's noise across a level's edge (a 21 mm cube: 18 to 24 mm) split one cube
        in two, and each half was an object of its own ("a purple cylinder" and "a purple ball")."""
        out = seeds.copy()
        next_label = count
        for label in range(1, count):
            where = seeds == label
            values = height[where]
            if values.size < MIN_SEED_PX:
                out[where] = 0
                continue
            if values.max() - values.min() <= 2 * FLAT_MM:
                continue
            ordered = np.sort(values)
            cuts = ordered[1:][np.diff(ordered) > STEP_MM]
            if cuts.size == 0:
                continue
            levels = np.searchsorted(cuts, values, side="right")
            for level in np.unique(levels)[1:]:
                piece = np.zeros_like(where)
                piece[where] = levels == level
                out[piece] = next_label
                next_label += 1
        return out

    @staticmethod
    def _split_colours(seeds: np.ndarray, rgb: np.ndarray) -> np.ndarray:
        """A flat top of two clear colours, each a good share of it and mostly in one piece, is two tops that touch at
        one height: split it, each pixel to the colour it is nearest to. Study 2, S-10_Run2 to S-20 (10 runs): a green
        and a blue cube left touching were one 31 x 54 mm "teal block" (green and blue's middle) -- with "a blue block"
        under it, from the blue sides below its top -- so "there is no green cube", and too wide to pick up."""
        out = seeds.copy()
        next_label = int(seeds.max()) + 1
        for label in np.unique(seeds[seeds > 0]):
            top = seeds == label
            if top.sum() < 2 * MIN_SEED_PX:
                continue
            groups = np.full(seeds.shape, -1, np.int8)
            groups[top] = colour_groups(rgb[top])
            counts = {g: int((groups == g).sum()) for g in (0, 1, 2)}
            coloured = sum(counts.values())
            big = [g for g, n in counts.items() if n >= max(MIN_SEED_PX, SPLIT_SHARE * coloured)]
            if len(big) < 2:
                continue
            parts = []
            for g in big:
                n, pieces, stats, _ = cv2.connectedComponentsWithStats((groups == g).astype(np.uint8), connectivity=8)
                biggest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
                if stats[biggest, cv2.CC_STAT_AREA] < SPLIT_WHOLE * counts[g]:
                    break                                    # speckled, not two pieces side by side: one top
                parts.append(pieces == biggest)
            else:
                # the rest of the top (its edges, a glint, the strip where the colours meet) to the nearest piece
                distance = np.stack([cv2.distanceTransform((~part).astype(np.uint8), cv2.DIST_L2, 3) for part in parts])
                nearest = np.argmin(distance, axis=0)
                for i in range(1, len(parts)):
                    out[top & (nearest == i)] = next_label
                    next_label += 1
        return out

    @staticmethod
    def _through_holes(a: np.ndarray, b: np.ndarray, holes: np.ndarray) -> bool:
        """Whether two pieces (masks) meet through holes in the depth picture alone, in the picture near them."""
        ys, xs = np.nonzero(a | b)
        if ys.size == 0:
            return False
        r0, r1 = max(0, ys.min() - HOLE_SEARCH_PX), ys.max() + HOLE_SEARCH_PX + 1
        c0, c1 = max(0, xs.min() - HOLE_SEARCH_PX), xs.max() + HOLE_SEARCH_PX + 1
        a, b, holes = a[r0:r1, c0:c1], b[r0:r1, c0:c1], holes[r0:r1, c0:c1]
        _, parts = cv2.connectedComponents((a | b | holes).astype(np.uint8), connectivity=8)
        return bool(np.intersect1d(np.unique(parts[a]), np.unique(parts[b])).size)

    @staticmethod
    def _main_part(mask: np.ndarray) -> np.ndarray:
        """The biggest connected part of a mask, without specks: a real camera's wildly wrong pixels that happen to be
        at the right height stretched a 20 mm cube's top to 68 x 25 mm, and made it "round"."""
        opened = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        count, parts, stats, _ = cv2.connectedComponentsWithStats(opened, connectivity=8)
        if count <= 1:
            return mask
        biggest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        return parts == biggest

    @staticmethod
    def _join_pieces(labels, seeds, pz, px, py, rgb, holes=None):
        """Pieces of one top that the camera's holes and noise broke apart: of one colour, level with each other and
        next to each other, seen from above -- or a little further apart with only a hole in the depth picture between
        them, not table (a 10 mm bar was cut in two by one) -- they are one object. (A stack of two of one colour is not
        level; two objects of one colour touching at one height couldn't be told apart anyway.)"""
        info = {}
        for label in np.unique(seeds[seeds > 0]):
            top = seeds == label
            if top.sum() < MIN_SEED_PX:
                continue
            region = labels == label
            word = colour_name(rgb[top])
            xs, ys = px[region], py[region]
            # the colour word itself, not its family: the pieces of one top are lit alike (by family, an orange ball
            # packed against a brown block's end was joined to it, "an orange block")
            info[int(label)] = (word, float(np.median(pz[top])),
                                np.stack([xs, ys], axis=1).astype(np.float32))
        keys = sorted(info)
        parent = {k: k for k in keys}

        def root(k):
            while parent[k] != k:
                parent[k] = parent[parent[k]]
                k = parent[k]
            return k
        for i, a in enumerate(keys):
            for b in keys[i + 1:]:
                fa, ha, pa = info[a]
                fb, hb, pb = info[b]
                if fa != fb or abs(ha - hb) > PIECE_LEVEL_MM:
                    continue
                # nearest points of the two, seen from above (subsampled: a few hundred points each at most)
                sa, sb = pa[:: max(1, len(pa) // 200)], pb[:: max(1, len(pb) // 200)]
                dx = sa[:, None, 0] - sb[None, :, 0]
                dy = sa[:, None, 1] - sb[None, :, 1]
                gap = float(np.sqrt((dx * dx + dy * dy).min()))
                if gap <= PIECE_GAP_MM or (holes is not None and gap <= HOLE_GAP_MM
                                           and DepthObjectDetector._through_holes(labels == a, labels == b, holes)):
                    parent[root(b)] = root(a)
        labels, seeds = labels.copy(), seeds.copy()
        for k in keys:
            r = root(k)
            if r != k:
                labels[labels == k] = r
                seeds[seeds == k] = r
        return labels, seeds

    @staticmethod
    def _flood(seeds: np.ndarray, mask: np.ndarray, height: np.ndarray, px: np.ndarray, py: np.ndarray) -> np.ndarray:
        """Each object's surface, grown from its top, highest points first: a side belongs to the top above it,
        not to a lower top it touches in the picture. It stays near its top, seen from above: a box's sides are right
        under the edge of its top, a ball's surface a little way out (REACH_OUT); further out it would be taking in
        whatever it touches in the picture (a cube in a tray took in the tray's walls)."""
        labels = np.where(mask, seeds, -1).astype(np.int32)
        labels[mask & (labels == 0)] = 0           # 0: object, not yet anyone's; -1: not an object
        centre, reach, box = {}, {}, {}
        for label in np.unique(seeds[seeds > 0]):
            where = seeds == label
            cx, cy = float(px[where].mean()), float(py[where].mean())
            centre[label] = (cx, cy)
            reach[label] = float(np.hypot(px[where] - cx, py[where] - cy).max()) * REACH_OUT + 4.0
            if where.sum() >= MIN_SEED_PX:
                (bx, by), (bw, bh), turn = cv2.minAreaRect(np.stack([px[where], py[where]], axis=1).astype(np.float32))
                if min(bw, bh) >= 12.0:
                    # a flat top this big is a box's or a cylinder's: straight sides, right under its edge. Kept to
                    # that, it doesn't take in the sides of what it stands on or of its neighbours (packed in a
                    # tray, a cube came out 39 x 47 mm and "a block", with the block under it)
                    box[label] = (bx, by, bw / 2.0 + FLOOD_MARGIN_MM, bh / 2.0 + FLOOD_MARGIN_MM,
                                  math.cos(math.radians(turn)), math.sin(math.radians(turn)))
        heap = [(-float(height[y, x]), int(y), int(x)) for y, x in zip(*np.nonzero(labels > 0))]
        heapq.heapify(heap)
        rows, cols = labels.shape
        while heap:
            _, y, x = heapq.heappop(heap)
            label = labels[y, x]
            (cx, cy), limit, bounds = centre[label], reach[label], box.get(label)
            here = height[y, x]
            for ny, nx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
                if (0 <= ny < rows and 0 <= nx < cols and labels[ny, nx] == 0
                        and height[ny, nx] <= here + UPHILL_MM
                        and (_in_box(px[ny, nx], py[ny, nx], bounds) if bounds is not None
                             else math.hypot(px[ny, nx] - cx, py[ny, nx] - cy) <= limit)):
                    labels[ny, nx] = label
                    heapq.heappush(heap, (-float(height[ny, nx]), ny, nx))
        return labels

    @staticmethod
    def _fill(points: np.ndarray, width: float, length: float) -> float:
        """How much of its outline (width x length, mm) the points cover seen from above, counted in 2 mm squares."""
        if width * length <= 16.0:
            return 1.0
        cells = np.unique(np.floor(points / 2.0).astype(np.int64), axis=0).shape[0]
        return min(1.0, cells * 4.0 / (width * length))

    @staticmethod
    def _colour_top_turn(region: np.ndarray, top_points: np.ndarray, px: np.ndarray, py: np.ndarray, pz: np.ndarray,
                         rgb: np.ndarray) -> Optional[float]:
        """A cube's turn from its top face as the colour picture shows it: the object's pixels in its own colour group
        and within COLOUR_TOP_MM of its flat top's height (its sides are lower, the table another colour), their
        tightest rectangle (0..180, as measure_footprint gives it). None when they don't make a square top -- a few
        pixels, or two colours' worth -- and the turn is then read as before."""
        groups = colour_groups(rgb[region])
        counts = np.bincount(groups[groups >= 0].astype(np.int64), minlength=3)
        if counts.sum() < MIN_OBJECT_PX:
            return None
        level = pz[region] >= float(np.median(top_points[:, 2])) - COLOUR_TOP_MM
        keep = (groups == int(counts.argmax())) & level
        if keep.sum() < MIN_OBJECT_PX:
            return None
        footprint, _ = measure_footprint(np.stack([px[region][keep], py[region][keep]], axis=1))
        if footprint is None or footprint[0] < COLOUR_TOP_MIN_MM or footprint[1] > COLOUR_TOP_SQUARE * footprint[0]:
            return None
        return float(footprint[2])

    @staticmethod
    def _round(points: np.ndarray) -> bool:
        """Whether a top is round, by the corners of the tightest rectangle round it: a square top fills them, a
        circle leaves them all but empty (in each corner square of 40% its sides, a circle covers some 13%). (By how
        much of that rectangle the outline filled, a real camera's ragged edges and lost corners made every cube "a
        cylinder".)"""
        if points.shape[0] < MIN_SEED_PX:
            return False
        pts = points.astype(np.float32)
        (cx, cy), (rw, rh), turn = cv2.minAreaRect(pts)
        if rw * rh <= 0:
            return False
        c, s = math.cos(math.radians(turn)), math.sin(math.radians(turn))
        dx, dy = pts[:, 0] - cx, pts[:, 1] - cy
        u = (dx * c + dy * s) / (rw / 2.0)
        v = (-dx * s + dy * c) / (rh / 2.0)
        in_corners = float(((np.abs(u) > CORNER) & (np.abs(v) > CORNER)).sum())
        filled = in_corners / ((1.0 - CORNER) ** 2 * pts.shape[0])     # 1 for a full rectangle
        return filled < ROUND_CORNERS

    @staticmethod
    def _inside(x: float, y: float, cx: float, cy: float, width: float, length: float, angle: float) -> bool:
        turn = math.radians(angle)
        dx, dy = x - cx, y - cy
        along, across = dx * math.cos(turn) + dy * math.sin(turn), -dx * math.sin(turn) + dy * math.cos(turn)
        return abs(along) <= length / 2.0 and abs(across) <= width / 2.0

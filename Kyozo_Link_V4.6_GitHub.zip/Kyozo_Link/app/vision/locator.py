"""Converts 2D detections + depth into 3D robot-frame coordinates."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np

from app.hardware.interfaces import Intrinsics
from app.vision.detector import Detection


@dataclass
class LocatedObject:
    label: str
    xyz_robot: tuple[float, float, float]  # mm, robot base frame
    confidence: float
    # the top face seen from above: (width, length, angle of the long side in degrees, 0..180), in mm and the
    # robot's frame; None when the detector gave no outline
    footprint: Optional[tuple[float, float, float]] = None


def pixel_to_camera_point(u: int, v: int, depth_mm: float, intrinsics: Intrinsics) -> np.ndarray:
    """Back-projects a pixel + depth into a 3D point in the camera's optical frame (mm)."""
    x = (u - intrinsics.cx) * depth_mm / intrinsics.fx
    y = (v - intrinsics.cy) * depth_mm / intrinsics.fy
    z = depth_mm
    return np.array([x, y, z, 1.0])


def camera_point_to_robot(point_cam: np.ndarray, t_cam_to_robot: np.ndarray) -> tuple[float, float, float]:
    """Applies the 4x4 camera->robot transform (from calibration) to a homogeneous camera point."""
    point_robot = t_cam_to_robot @ point_cam
    return float(point_robot[0]), float(point_robot[1]), float(point_robot[2])


FOREGROUND_PERCENTILE = 20.0


def foreground_depth(depth: np.ndarray, u: int, v: int, radius: int = 3,
                     percentile: float = FOREGROUND_PERCENTILE) -> float:
    """Depth of the thing the click is on, from the valid depth values around the pixel;
    0.0 if there are none.

    Deliberately leans toward the *nearer* surface rather than taking the median. A click on
    or near a thin object (the gripper tip, a cube's edge) lands on a patch that is partly
    the object and partly the table behind it; the median can then pick the table, tens of
    millimetres too far away, and that one bad depth throws off a whole calibration. Valid
    pixels are never nearer than the object itself, so a low percentile is safe."""
    patch = depth[max(0, v - radius):v + radius + 1, max(0, u - radius):u + radius + 1]
    valid = patch[patch > 0]
    return float(np.percentile(valid, percentile)) if valid.size else 0.0


TOP_FACE_BAND_MM = 6.0   # points within this of the highest ones count as the top face
MIN_TOP_POINTS = 8


def _locate_top_face(det: Detection, depth: np.ndarray, intrinsics: Intrinsics,
                      t_cam_to_robot: np.ndarray) -> LocatedObject | None:
    """Position of the object's top-face centre, in robot coordinates.

    From an angled camera the blob's centre mixes the top with the side faces, which
    shifts the estimate toward the camera by up to half the object. Working in robot
    coordinates (z up) lets us keep only the highest points -- the top face -- and average
    those, so the result is the top centre regardless of the viewing angle."""
    x, y, w, h = det.bbox
    patch = depth[y:y + h, x:x + w]
    inside = det.mask[:patch.shape[0], :patch.shape[1]] & (patch > 0)
    rows, cols = np.nonzero(inside)
    if rows.size < MIN_TOP_POINTS:
        return None
    if rows.size > 600:  # plenty for an average; keeps this cheap at video rate
        keep = np.linspace(0, rows.size - 1, 600).astype(int)
        rows, cols = rows[keep], cols[keep]
    z = patch[rows, cols].astype(np.float64)
    u, v = cols + x, rows + y
    camera_points = np.stack([(u - intrinsics.cx) * z / intrinsics.fx,
                              (v - intrinsics.cy) * z / intrinsics.fy, z, np.ones_like(z)])
    robot_points = (t_cam_to_robot @ camera_points)[:3].T
    top_height = np.percentile(robot_points[:, 2], 90)
    top = robot_points[robot_points[:, 2] >= top_height - TOP_FACE_BAND_MM]
    if top.shape[0] < MIN_TOP_POINTS:
        return None
    footprint, (cx, cy) = measure_footprint(top[:, :2])
    return LocatedObject(label=det.label, xyz_robot=(float(cx), float(cy), float(top[:, 2].mean())),
                         confidence=det.confidence, footprint=footprint)


def _trimmed_turn(points: np.ndarray, mean: np.ndarray, start: float) -> float:
    """The turn of the tightest rectangle round 98% of the points (1% off each side, each way), searched near the
    tightest round all of them (`start`): a few stray edge pixels tip that one by several degrees -- the camera's
    reading of a still cube's turn jumped 4-7° between pictures -- but hardly move this one."""
    dx, dy = points[:, 0] - mean[0], points[:, 1] - mean[1]
    best_area, best = None, start
    for step, reach in ((1.0, 10.0), (0.25, 1.0)):
        centre = best
        for a in np.arange(centre - reach, centre + reach + 1e-9, step):
            c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
            u, v = dx * c + dy * s, dy * c - dx * s
            u_low, u_high = np.percentile(u, (1, 99))
            v_low, v_high = np.percentile(v, (1, 99))
            area = float((u_high - u_low) * (v_high - v_low))
            if best_area is None or area < best_area - 1e-9:
                best_area, best = area, float(a)
    return best


def measure_footprint(points: np.ndarray) -> tuple[Optional[tuple[float, float, float]], tuple[float, float]]:
    """((width, length, angle of the long side, 0..180 degrees), (x, y) of its centre) of the top face, from its
    points seen from above (N x 2, mm). The turn comes from the tightest rectangle round them; the sides and the
    centre from where 98% of the points lie along each of its axes (a stray edge pixel doesn't move them). (Adding
    the pixel each edge point stands for measured the demo's cubes ~0.8 mm too wide: the colour mask already takes
    in the edge pixels the object only partly covers.)

    The centre is the rectangle's, not the points' average: from an angled camera the top few mm of the sides
    facing it count as "top" too, and they pile points up along the near edges -- the average moved ~2.5 mm
    toward the camera, more than a cube in the gripper's fingers can be off (1.25 mm, 25 mm in 27.5 mm).
    A side is vertical, so seen from above it lies along the edge and doesn't move the rectangle."""
    mean = points.mean(axis=0)
    if points.shape[0] < MIN_TOP_POINTS:
        return None, (float(mean[0]), float(mean[1]))
    (_, _), (_, _), angle = cv2.minAreaRect(points.astype(np.float32))
    angle = _trimmed_turn(points, mean, float(angle))
    turn = np.radians(angle)
    axes = np.array([[np.cos(turn), np.sin(turn)], [-np.sin(turn), np.cos(turn)]])
    # element by element, no matrix products: this also runs for the camera feed's boxes, on another thread than a
    # prompt's look, and two OpenBLAS calls at once can crash the app
    dx, dy = points[:, 0] - mean[0], points[:, 1] - mean[1]
    along = np.stack([dx * axes[0, 0] + dy * axes[0, 1], dx * axes[1, 0] + dy * axes[1, 1]], axis=1)
    low = np.percentile(along, 1, axis=0)
    high = np.percentile(along, 99, axis=0)
    middle = (low + high) / 2.0
    centre = mean + middle[0] * axes[0] + middle[1] * axes[1]
    spans = (high - low) / 0.98
    if spans[0] >= spans[1]:
        length, width, long_angle = spans[0], spans[1], angle
    else:
        length, width, long_angle = spans[1], spans[0], angle + 90.0
    footprint = (round(float(width), 1), round(float(length), 1), round(float(long_angle), 1) % 180.0)
    return footprint, (float(centre[0]), float(centre[1]))


def locate_detection(det: Detection, depth: np.ndarray, intrinsics: Intrinsics,
                      t_cam_to_robot: np.ndarray, depth_patch_radius: int = 3) -> LocatedObject | None:
    """Maps a detection to robot coordinates: its top-face centre when the detector gave
    a pixel mask, otherwise a median depth around the blob centre."""
    if det.mask is not None:
        top = _locate_top_face(det, depth, intrinsics, t_cam_to_robot)
        if top is not None:
            return top
    u, v = det.center_px
    h, w = depth.shape
    r = depth_patch_radius
    y0, y1 = max(0, v - r), min(h, v + r + 1)
    x0, x1 = max(0, u - r), min(w, u + r + 1)
    patch = depth[y0:y1, x0:x1]
    valid = patch[patch > 0]
    if valid.size == 0:
        return None
    depth_mm = float(np.median(valid))

    point_cam = pixel_to_camera_point(u, v, depth_mm, intrinsics)
    xyz_robot = camera_point_to_robot(point_cam, t_cam_to_robot)
    return LocatedObject(label=det.label, xyz_robot=xyz_robot, confidence=det.confidence)

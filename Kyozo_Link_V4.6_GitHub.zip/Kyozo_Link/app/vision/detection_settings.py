"""What the camera counts as an object, as set in the Detection window (and kept in config.yaml under vision:).

Two ways of finding things:
  * "any"   -- anything standing up from the table, whatever its colour or shape (the depth camera:
               vision/depth_detector.py);
  * "cubes" -- only coloured cubes, by their colour (vision/detector.py: the colours in config.yaml).

And what is left out, against phantom objects (on the real camera: bits of a card mat, cables, the arm's own
parts, depth noise):
  * anything lower than `min_height_mm` above the table (depth only),
  * anything smaller than `min_size_mm` across, seen from above,
  * anything not seen in `steady_looks` looks in a row (one look is one camera picture),
  * anything whose middle is outside the pick area, when one is set: a rectangle on the table in the arm's
    coordinates (mm).

One SwitchingDetector stands in for the detector everywhere (the prompts, the camera feed, the 3D view's "what the
camera sees", the system check), so a change in the window takes effect everywhere at once.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from app.vision.detector import Detection
from app.vision.locator import LocatedObject, locate_detection

logger = logging.getLogger(__name__)

FIND_ANY, FIND_CUBES = "any", "cubes"
DETECTOR_FOR = {FIND_ANY: "depth", FIND_CUBES: "color_blob"}      # config.yaml's vision: detector:
DEFAULT_PICK_AREA = {"x": [150.0, 300.0], "y": [-200.0, 200.0]}   # offered when the pick area is first switched on


@dataclass
class DetectionSettings:
    find: str = FIND_ANY
    min_height_mm: float = 5.0
    min_size_mm: float = 8.0
    steady_looks: int = 1
    pick_area: Optional[dict] = None           # {"x": [low, high], "y": [low, high]} in mm, or None: anywhere in reach
    changed: list = field(default_factory=list, repr=False, compare=False)   # callbacks, called with no arguments

    @classmethod
    def from_config(cls, vision: dict) -> "DetectionSettings":
        area = vision.get("pick_area")
        if area is not None:
            try:
                area = {"x": sorted(float(v) for v in area["x"]), "y": sorted(float(v) for v in area["y"])}
            except (KeyError, TypeError, ValueError):
                logger.warning("Ignoring vision: pick_area in config.yaml (it needs x: [low, high] and y: [low, high])")
                area = None
        return cls(find=FIND_CUBES if vision.get("detector") == "color_blob" else FIND_ANY,
                   min_height_mm=float(vision.get("min_height_mm", 5.0)),
                   min_size_mm=float(vision.get("min_size_mm", 8.0)),
                   steady_looks=max(1, int(vision.get("steady_looks", 1))),
                   pick_area=area)

    def to_config(self) -> dict:
        """The keys to write under vision: in config.yaml."""
        return {"detector": DETECTOR_FOR[self.find], "min_height_mm": round(self.min_height_mm, 1),
                "min_size_mm": round(self.min_size_mm, 1), "steady_looks": int(self.steady_looks),
                "pick_area": self.pick_area}

    def update(self, **values) -> None:
        for name, value in values.items():
            setattr(self, name, value)
        for callback in list(self.changed):
            callback()

    def in_pick_area(self, x: float, y: float, margin: float = 0.0) -> bool:
        area = self.pick_area
        if not area:
            return True
        return (area["x"][0] - margin <= x <= area["x"][1] + margin
                and area["y"][0] - margin <= y <= area["y"][1] + margin)

    def keeps(self, loc: LocatedObject) -> Optional[str]:
        """None if this one counts as an object; else why not (for the log)."""
        x, y = loc.xyz_robot[0], loc.xyz_robot[1]
        if not self.in_pick_area(x, y):
            return "outside the pick area"
        footprint = getattr(loc, "footprint", None)
        if footprint is not None and min(footprint[:2]) < self.min_size_mm:
            return f"{min(footprint[:2]):.0f} mm across, smaller than {self.min_size_mm:.0f}"
        return None


class SwitchingDetector:
    """The detector the rest of the app uses: the depth detector or the colour one, as the settings say, with what
    the settings leave out left out. Answers the same calls as either (detect for the camera feed, locate and find
    for the scene)."""

    def __init__(self, settings: DetectionSettings, depth_detector, colour_detector,
                 get_transform: Callable[[], np.ndarray]):
        self.settings = settings
        self.depth = depth_detector
        self.colour = colour_detector
        self.get_transform = get_transform
        self.needs_depth = True              # the colour one too: its finds are placed on the table to be judged

    @property
    def current(self):
        return self.depth if self.settings.find == FIND_ANY else self.colour

    @property
    def overlay_every(self) -> int:
        return getattr(self.current, "overlay_every", 4)

    def detect(self, rgb: np.ndarray, depth: Optional[np.ndarray] = None, intrinsics=None) -> list[Detection]:
        if depth is None or intrinsics is None:
            return [] if self.settings.find == FIND_ANY else self.colour.detect(rgb)
        return [det for det, _ in self.find(rgb, depth, intrinsics, self.get_transform())]

    def locate(self, frame, t_cam_to_robot: np.ndarray) -> list[LocatedObject]:
        return [loc for _, loc in self.find(frame.rgb, frame.depth, frame.intrinsics, t_cam_to_robot)]

    def find(self, rgb, depth, intrinsics, transform) -> list[tuple[Detection, LocatedObject]]:
        if self.settings.find == FIND_ANY:
            pairs = self.depth.find(rgb, depth, intrinsics, transform)
        else:
            pairs = []
            for det in self.colour.detect(rgb):
                loc = locate_detection(det, depth, intrinsics, transform)
                if loc is not None:
                    pairs.append((det, loc))
        kept = []
        for det, loc in pairs:
            why = self.settings.keeps(loc)
            if why is None:
                kept.append((det, loc))
            else:
                logger.debug("Left out the %s at (%.0f, %.0f): %s", loc.label, loc.xyz_robot[0], loc.xyz_robot[1], why)
        return kept

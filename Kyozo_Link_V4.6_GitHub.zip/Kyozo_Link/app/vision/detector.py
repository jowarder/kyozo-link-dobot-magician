"""Object detection backends: color-blob (default, zero-training) and YOLOv8 (optional).

MVP decision: the default detector is classic HSV color-blob thresholding,
not YOLOv8. YOLOv8 needs trained weights or labeled data for "cube"-shaped
objects (not a COCO class), which isn't available yet. Color-blob detection
works immediately for the colored-cube test objects with zero setup. Swap to
YOLOv8Detector (Milestone 10) once you have training data for more general
objects -- both live behind the same Detector interface.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class Detection:
    label: str
    bbox: tuple[int, int, int, int]  # x, y, w, h in pixels
    center_px: tuple[int, int]
    confidence: float
    mask: Optional[np.ndarray] = None  # bool array the size of bbox: which pixels belong to the object


class Detector:
    def detect(self, rgb: np.ndarray) -> list[Detection]:
        raise NotImplementedError


def _hue_ranges(bounds: dict) -> list[tuple[np.ndarray, np.ndarray]]:
    """The HSV ranges for one colour. Hue is a circle (0 to 179 in OpenCV) and red sits on the
    seam, so a range starting at 0 also covers the matching stretch just below 180: a red
    object with a little colour noise lands on either side of it."""
    low, high = list(bounds["hsv_low"]), list(bounds["hsv_high"])
    ranges = [(np.array(low, dtype=np.uint8), np.array(high, dtype=np.uint8))]
    if low[0] == 0 and high[0] > 0:
        ranges.append((np.array([180 - high[0], low[1], low[2]], dtype=np.uint8),
                       np.array([179, high[1], high[2]], dtype=np.uint8)))
    return ranges


class ColorBlobDetector(Detector):
    def __init__(self, colors: dict[str, dict], min_area_px: int = 200, max_area_px: int = 6000):
        self.colors = colors
        self.min_area_px = min_area_px
        self.max_area_px = max_area_px  # a cube is small; huge same-coloured regions are surfaces

    def detect(self, rgb: np.ndarray) -> list[Detection]:
        hsv = cv2.cvtColor(cv2.medianBlur(rgb, 3), cv2.COLOR_RGB2HSV)   # the blur takes the edge off sensor noise
        detections: list[Detection] = []
        for label, bounds in self.colors.items():
            mask = np.zeros(hsv.shape[:2], np.uint8)
            for low, high in _hue_ranges(bounds):
                mask |= cv2.inRange(hsv, low, high)
            kernel = np.ones((5, 5), np.uint8)
            mask = cv2.morphologyEx(cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel), cv2.MORPH_OPEN, kernel)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area < self.min_area_px or area > self.max_area_px:
                    continue
                x, y, w, h = cv2.boundingRect(cnt)
                # judged on the tightest turned rectangle, not the upright box: a cube turned 45 degrees fills
                # only half its upright box and was thrown away as "not filled"
                (_, _), (rw, rh), _ = cv2.minAreaRect(cnt)
                aspect = max(rw, rh) / min(rw, rh) if min(rw, rh) > 0 else 99.0
                extent = area / (rw * rh) if rw * rh else 0.0
                if aspect > 2.0 or extent < 0.6:
                    continue  # not roughly square/filled: table edges, paper, cables
                cx, cy = x + w // 2, y + h // 2
                confidence = min(1.0, area / (self.min_area_px * 10))
                blob = np.zeros((h, w), np.uint8)
                cv2.drawContours(blob, [cnt - np.array([[x, y]])], -1, 255, thickness=-1)
                detections.append(Detection(
                    label=f"{label} cube", bbox=(x, y, w, h),
                    center_px=(cx, cy), confidence=confidence, mask=blob > 0,
                ))
        return detections


class YOLOv8Detector(Detector):
    """Optional backend for general objects. Requires `ultralytics` and trained weights."""

    def __init__(self, weights_path: str, confidence_threshold: float = 0.4):
        try:
            from ultralytics import YOLO
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("ultralytics is not installed. Run `pip install ultralytics`.") from exc
        self.model = YOLO(weights_path)
        self.confidence_threshold = confidence_threshold

    def detect(self, rgb: np.ndarray) -> list[Detection]:
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        results = self.model.predict(bgr, verbose=False)[0]
        detections: list[Detection] = []
        for box in results.boxes:
            conf = float(box.conf[0])
            if conf < self.confidence_threshold:
                continue
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            label = results.names[int(box.cls[0])]
            detections.append(Detection(
                label=label, bbox=(x1, y1, x2 - x1, y2 - y1),
                center_px=((x1 + x2) // 2, (y1 + y2) // 2), confidence=conf,
            ))
        return detections


# Extra colours for the demo scenes (yellow and purple cubes). Added in demo mode only: on the real
# robot a yellowish wooden table or a purple sleeve could pass for a cube, so for real objects in these
# colours add the ranges to config.yaml (vision: colors:) once they have been checked on the real camera.
DEMO_EXTRA_COLORS = {
    "yellow": {"hsv_low": [20, 120, 70], "hsv_high": [34, 255, 255]},
    "purple": {"hsv_low": [135, 100, 50], "hsv_high": [165, 255, 255]},
}


def with_demo_colors(vision_config: dict) -> dict:
    """The colour detector's settings with DEMO_EXTRA_COLORS added (config.yaml's own ranges win) -- the colour
    detector's, whichever detector config.yaml picks for the app."""
    merged = dict(vision_config)
    if merged.get("detector") not in (None, "color_blob"):
        merged["detector"] = "color_blob"
    merged["colors"] = {**DEMO_EXTRA_COLORS, **vision_config.get("colors", {})}
    return merged


def build_detector(config: dict) -> Detector:
    backend = config.get("detector", "color_blob")
    if backend == "color_blob":
        return ColorBlobDetector(colors=config["colors"], min_area_px=config.get("min_area_px", 200),
                                 max_area_px=config.get("max_area_px", 6000))
    if backend == "yolov8":
        return YOLOv8Detector(weights_path=config["yolo_weights"])
    raise ValueError(f"Unknown detector backend: {backend}")

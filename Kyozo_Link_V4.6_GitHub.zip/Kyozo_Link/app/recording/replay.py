"""Replays a recorded session for offline debugging (no hardware required)."""
from __future__ import annotations

import json
from pathlib import Path

import cv2


class SessionReplay:
    def __init__(self, session_dir: str | Path):
        self.session_dir = Path(session_dir)
        self.events = json.loads((self.session_dir / "events.json").read_text(encoding="utf-8"))

    def frames(self):
        for event in self.events:
            if event["type"] == "frame":
                bgr = cv2.imread(str(self.session_dir / "frames" / event["file"]))
                yield event["t"], cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)

    def commands(self):
        for event in self.events:
            if event["type"] == "command":
                yield event

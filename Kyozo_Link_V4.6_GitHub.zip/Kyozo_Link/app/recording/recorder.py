"""Captures live sessions (frames, robot commands, LLM decisions) for offline replay."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np


@dataclass
class SessionRecorder:
    session_dir: Path
    _events: list = field(default_factory=list)
    _frame_count: int = 0

    def __post_init__(self):
        self.session_dir.mkdir(parents=True, exist_ok=True)
        (self.session_dir / "frames").mkdir(exist_ok=True)

    def log_frame(self, rgb: np.ndarray) -> None:
        filename = f"frame_{self._frame_count:06d}.png"
        cv2.imwrite(str(self.session_dir / "frames" / filename), cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
        self._events.append({"type": "frame", "t": time.time(), "file": filename})
        self._frame_count += 1

    def log_command(self, name: str, arguments: dict, result: str) -> None:
        self._events.append({"type": "command", "t": time.time(), "name": name,
                              "arguments": arguments, "result": result})

    def log_llm_decision(self, prompt: str, final_message: str) -> None:
        self._events.append({"type": "llm", "t": time.time(), "prompt": prompt,
                              "final_message": final_message})

    def save(self) -> None:
        (self.session_dir / "events.json").write_text(json.dumps(self._events, indent=2), encoding="utf-8")

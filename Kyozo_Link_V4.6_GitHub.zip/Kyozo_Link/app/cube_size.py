"""The study's cubes' size: one setting for the app, the twin and the watcher.

It is config.yaml's vision: known_sizes_mm: cube -- what the app's camera takes a cube measured near it to be (see
SceneBuilder), and, since 2026-10-26, the size the watcher sets the twin's cubes out at, finds the Dobot's cubes by
and scores with (the task files' own cube_size_mm is the size they were written for). Chosen in the app's Settings >
Cubes; every session and run records it. Until 2026-10-26 every study's cubes were 25 mm.
"""
from __future__ import annotations

CUBE_SIZES_MM = (25.0, 20.0)       # the sizes offered: the study's first cubes, and the smaller ones (2026-10-26)
DEFAULT_CUBE_MM = 25.0
CONFIG_PATH = ("vision", "known_sizes_mm", "cube")
MATCH_MM = 2.0     # the cubes measure within this of another size offered...
OFF_MM = 3.5       # ...and at least this far from the one set: they are the other size (size_mismatch)


def cube_mm(config: dict) -> float:
    """The cube size config.yaml sets (vision: known_sizes_mm: cube), or 25 mm."""
    try:
        value = float(((config or {}).get("vision") or {}).get("known_sizes_mm", {}).get("cube", DEFAULT_CUBE_MM))
    except (TypeError, ValueError, AttributeError):
        return DEFAULT_CUBE_MM
    return value if value > 0 else DEFAULT_CUBE_MM


def describe(size_mm: float) -> str:
    """"25 mm" (no ".0")."""
    return f"{size_mm:g} mm"


def size_mismatch(measured_mm, setting_mm) -> "float | None":
    """The size offered (CUBE_SIZES_MM) that the cubes on the table measure, when it isn't the one set; else None.
    Study 2's lab notes: 20 or 25 mm cubes, the size set beside them -- a 20 mm cube measured near 25 is called 25 mm
    (SceneBuilder: KNOWN_SIZE_TOL_MM), gripped and stacked as one. Only a clear difference: a 25 mm cube's top was read
    anything from 20 to 28 mm across in the lab, so it takes the middle of several readings near the other size."""
    if measured_mm is None or not setting_mm:
        return None
    nearest = min(CUBE_SIZES_MM, key=lambda size: abs(size - measured_mm))
    if nearest != setting_mm and abs(measured_mm - nearest) <= MATCH_MM and abs(measured_mm - setting_mm) >= OFF_MM:
        return nearest
    return None

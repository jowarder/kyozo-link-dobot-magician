"""Raw protocol commands for the real Dobot Magician that pydobot's high-level
`Dobot` class doesn't expose: homing, alarm state, and a real hard-stop.

Discovered during hardware bring-up: `pydobot.Dobot` has no `.home()` or
`.stop()` despite being referenced as if it did, and manually back-driving a
joint by hand can trip a controller-level alarm that blocks all queued PTP
motion until the queue is stopped/cleared and restarted (a plain "clear
alarms" command alone was not sufficient in testing).
"""
from __future__ import annotations

import struct

from pydobot.enums.CommunicationProtocolIDs import CommunicationProtocolIDs
from pydobot.enums.ControlValues import ControlValues
from pydobot.enums import PTPMode
from pydobot.message import Message


def home(device) -> int | None:
    """Starts the homing sequence -- moves the arm to its reference position.
    Can take 15-20 seconds; callers should warn the user the arm will move
    before calling this. Returns its place in the command queue (the robot is
    finished when `current_queue_index` reaches it), or None if it didn't say."""
    msg = Message()
    msg.id = CommunicationProtocolIDs.SET_HOME_CMD
    msg.ctrl = ControlValues.THREE
    msg.params = bytearray([0, 0, 0, 0])
    response = device._send_command(msg)
    if response is None or len(response.params) < 4:
        return None
    return struct.unpack_from("<I", response.params, 0)[0]


def queue_move(device, x: float, y: float, z: float, r: float, straight: bool = True) -> int:
    """Queue a move and return its place in the robot's command queue. The move has finished when
    `current_queue_index` reaches that number. Returns straight away.

    straight=True: the tip travels in a straight line (MOVL). straight=False: every joint turns
    evenly from start to end (MOVJ), so the tip swings round the base in an arc -- the way to get
    from one side of the base to the other, since a straight line across the front passes through
    the space next to the base that the arm cannot reach, and the controller stops there (alarm 0x22)."""
    msg = Message()
    msg.id = CommunicationProtocolIDs.SET_PTP_CMD
    msg.ctrl = ControlValues.THREE
    msg.params = bytearray([(PTPMode.MOVL_XYZ if straight else PTPMode.MOVJ_XYZ).value])
    for value in (x, y, z, r):
        msg.params.extend(bytearray(struct.pack("f", value)))
    response = device._send_command(msg)
    if response is None or len(response.params) < 4:
        # (which: no reply at all within the wait, or a reply without the move's place in the queue -- said, so the
        # log tells a link that dropped it from a controller that turned it down)
        detail = ("no reply" if response is None else
                  f"a reply without a queue number: id {getattr(response, 'id', '?')}, {len(response.params)} bytes")
        error = RuntimeError(f"The robot did not acknowledge the move command ({detail}).")
        try:
            from app.hardware.dobot_link import frame_bytes
            error.frame = frame_bytes(msg).hex(" ")  # (for the log: exactly what went out)
        except Exception:  # noqa: BLE001 - a log detail, never a reason to fail differently
            error.frame = ""
        raise error
    return struct.unpack_from("<I", response.params, 0)[0]


def current_queue_index(device) -> int:
    """The queue number of the command the robot has most recently finished."""
    msg = Message()
    msg.id = CommunicationProtocolIDs.GET_QUEUED_CMD_CURRENT_INDEX
    response = device._send_command(msg)
    if response is None or len(response.params) < 4:
        raise RuntimeError("The robot did not reply to a status request.")
    return struct.unpack_from("<I", response.params, 0)[0]


def set_end_effector(device, suction: bool, on: bool, pump: bool = True) -> None:
    """Switches the suction cup (or the two-finger gripper) on/off *immediately*. `pump`: False switches the air
    pump off altogether ("off" alone only turns the air round: the gripper opens, the cup lets go, and the pump
    keeps running).

    pydobot's own `suck()` / `grip()` put the command in the robot's motion queue. That is a
    problem in two ways: it only runs once the queue is executing (so it does nothing after an
    E-STOP or an alarm has stopped the queue -- including the release the E-STOP itself asks for),
    and it waits its turn behind any motion. Sent outside the queue (isQueued = 0) it acts at once.
    Raises if the robot doesn't acknowledge it, rather than pretending the object is held."""
    msg = Message()
    msg.id = (CommunicationProtocolIDs.SET_GET_END_EFFECTOR_SUCTION_CUP if suction
              else CommunicationProtocolIDs.SET_GET_END_EFFECTOR_GRIPPER)
    msg.ctrl = ControlValues.ONE          # write, not queued
    msg.params = bytearray([0x01 if pump else 0x00, 0x01 if on and pump else 0x00])   # [pump on, grip/suck]
    if device._send_command(msg) is None:
        raise RuntimeError("The robot did not acknowledge the gripper command.")


def get_alarms(device) -> list[int]:
    msg = Message()
    msg.id = CommunicationProtocolIDs.GET_ALARMS_STATE
    msg.ctrl = ControlValues.ZERO
    response = device._send_command(msg)
    return list(response.params) if response else []


def clear_alarms(device) -> None:
    msg = Message()
    msg.id = CommunicationProtocolIDs.CLEAR_ALL_ALARMS_STATE
    msg.ctrl = ControlValues.ONE
    device._send_command(msg)


def stop_queued_motion(device) -> None:
    """Immediately stops queued command execution -- the closest equivalent to
    an E-stop in the Dobot protocol -- and clears the queue so no stale
    commands run once execution is resumed."""
    msg = Message()
    msg.id = CommunicationProtocolIDs.SET_QUEUED_CMD_STOP_EXEC
    msg.ctrl = ControlValues.ONE
    device._send_command(msg)

    msg = Message()
    msg.id = CommunicationProtocolIDs.SET_QUEUED_CMD_CLEAR
    msg.ctrl = ControlValues.ONE
    device._send_command(msg)


def get_ptp_common_params(device) -> tuple[float, float] | None:
    """(velocity, acceleration) ratios, percent, that every move is scaled by -- or None if it didn't say."""
    msg = Message()
    msg.id = CommunicationProtocolIDs.SET_GET_PTP_COMMON_PARAMS
    msg.ctrl = ControlValues.ZERO
    response = device._send_command(msg)
    if response is None or len(response.params) < 8:
        return None
    return struct.unpack_from("<ff", response.params, 0)


def set_ptp_common_params(device, velocity: float, acceleration: float) -> None:
    """Every move (straight or swinging round the base) at this percent of its speed and acceleration. Queued:
    it applies from the next move."""
    device._set_ptp_common_params(velocity, acceleration)


def resume_queued_motion(device) -> None:
    msg = Message()
    msg.id = CommunicationProtocolIDs.SET_QUEUED_CMD_START_EXEC
    msg.ctrl = ControlValues.ONE
    device._send_command(msg)

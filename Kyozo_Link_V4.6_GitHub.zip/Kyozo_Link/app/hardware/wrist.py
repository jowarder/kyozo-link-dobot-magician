"""How the wrist really turns, and the correction that makes the fingers point where a pick wants them.

The app plans every grip in ideal terms: the fingers close along jaw_axis_deg + r (gripper.py), jaw_axis_deg being
the fingers' angle the cube calibration measured. A real wrist is a little off that in three ways, measured by the
fingers angle check (calibration/wrist_check.py) and fitted here:

  offset    a fixed turn left over (the wrist's zero, or a fingers' angle measured a little off)
  gain      the wrist turns this many times what it is told (0.95: 5 % short)
  backlash  slack in its gears: approached from below, it stops half the slack short; from above, half beyond

As the wrist's own angle w (the Dobot's J4 = r - J1, the xArm's J6 = r; see GripperSpec.wrist_turn), told to turn to
w, the fingers end up at   w_real = offset + gain * w + side * backlash / 2,   side -1 approached from below, +1 from
above. Picks always come to their final angle from below (WristModel.APPROACH_SIDE), so backlash is a known constant;
the correction asks for the w that gives the wanted one.
"""
from __future__ import annotations

import logging
import math
import time
from dataclasses import asdict, dataclass, field
from typing import Optional

import numpy as np

from app.hardware.interfaces import Pose

logger = logging.getLogger(__name__)

# the model is trusted (used for picks) only within these: outside them the measurement is more likely wrong than the
# wrist (a cube that turned as it was let go, a bad look)
GAIN_RANGE = (0.85, 1.15)
MAX_BACKLASH_DEG = 8.0
# an offset is one turn the same everywhere -- the easiest thing to correct, whatever its size: 15° until study 3, when
# the lab's check measured +20.1° (gain 0.99, scatter 4.9°), refused, and every pick went down ~20° off the cube's sides
# ("diagonal" picks; cubes came out of the fingers turned +10° on average, up to +22°, the same anywhere on the table:
# study_3 S-01..S-20). Over MOUNT_NOTE_DEG it is used and the gripper's mounting named as worth putting right.
MAX_OFFSET_DEG = 30.0
MOUNT_NOTE_DEG = 15.0
# the put-downs' scatter: 1.5° until 2026-10-22, when Rafi chose to trust (and use) the lab's checks up to 10° -- the
# Dobot's wrist slack and the camera's angle readings scattered 3.5-8.9° with the gripper tight on the wrist. A check
# saved earlier is judged again by these limits when it is loaded.
MAX_SCATTER_DEG = 10.0
MIN_SAMPLES = 6
# a put-down this far off the fit of the others (and over 3 times their scatter) is left out of it: a cube that turned
# as it was let go. At most MAX_LEFT_OUT, and only while enough are left to tell (see _enough)
OUTLIER_DEG = 6.0
MAX_LEFT_OUT = 2
WRIST_LIMIT_MARGIN_DEG = 1.0   # the corrected wrist angle kept this far inside its limits


@dataclass
class WristModel:
    offset_deg: float = 0.0
    gain: float = 1.0
    backlash_deg: float = 0.0
    scatter_deg: float = 0.0           # how far the put-downs typically were from the fit (repeatability), degrees
    samples: int = 0
    trusted: bool = True
    problems: list = field(default_factory=list)   # why it isn't trusted, in words
    measured_at: str = ""
    cube_mm: Optional[float] = None
    depth_preset: Optional[str] = None
    jaw_axis_deg: Optional[float] = None           # the fingers' angle in use when it was measured (it is on top)
    points: list = field(default_factory=list)     # (told, side, real) for each put-down, degrees: for the plot
    left_out: list = field(default_factory=list)   # put-downs left out of the fit, (told, side, real): see OUTLIER_DEG

    APPROACH_SIDE = -1                 # picks come to their final angle from below (the wrist turning up to it)

    def real_wrist(self, told: float, side: int = APPROACH_SIDE) -> float:
        return self.offset_deg + self.gain * told + side * max(0.0, self.backlash_deg) / 2.0

    def told_for(self, wanted: float, side: int = APPROACH_SIDE) -> float:
        """The wrist angle to ask for so it ends up at `wanted` (coming from `side`). (Backlash as measured is kept,
        to be judged the same when loaded; slack below none is used as none.)"""
        return (wanted - self.offset_deg - side * max(0.0, self.backlash_deg) / 2.0) / self.gain

    def to_dict(self) -> dict:
        out = asdict(self)
        for key in ("offset_deg", "gain", "backlash_deg", "scatter_deg"):
            out[key] = round(float(out[key]), 3 if key == "gain" else 2)
        out["points"] = [[round(float(a), 2), int(s), round(float(b), 2)] for a, s, b in self.points]
        out["left_out"] = [[round(float(a), 2), int(s), round(float(b), 2)] for a, s, b in self.left_out]
        return out

    @classmethod
    def from_dict(cls, data: Optional[dict]) -> Optional["WristModel"]:
        if not data:
            return None
        known = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        model = cls(**known)
        model.points = [tuple(p) for p in model.points]
        model.left_out = [tuple(p) for p in model.left_out]
        if model.samples >= MIN_SAMPLES or model.points:   # (judged again by today's limits, not those it was saved under)
            judge(model)
        return model

    def describe(self) -> str:
        text = (f"offset {self.offset_deg:+.1f}°, the wrist turns {self.gain * 100:.1f}% of what it is told, "
                f"backlash {self.backlash_deg:.1f}°, scatter {self.scatter_deg:.1f}° ({self.samples} put-downs"
                + (f", {len(self.left_out)} more left out: turned as let go" if self.left_out else "") + ")")
        if not self.trusted:
            text += "; not used: " + "; ".join(self.problems)
        elif self.mount_note:
            text += "; " + self.mount_note
        return text

    @property
    def mount_note(self) -> str:
        """A large offset that is used: the gripper is very likely turned on the wrist (worth remounting, or picks rely
        on this check staying right)."""
        if abs(self.offset_deg) <= MOUNT_NOTE_DEG:
            return ""
        return (f"the fingers sit {self.offset_deg:+.0f}° from straight -- allowed for on every pick; the gripper is "
                "probably mounted turned on the wrist (remount it, then run the cube calibration and this check again)")


def _enough(points: list) -> bool:
    """Enough put-downs to tell offset, gain and backlash apart: MIN_SAMPLES, at 3 or more angles, from both sides."""
    return (len(points) >= MIN_SAMPLES and len({round(told) for told, _, _ in points}) >= 3
            and {side for _, side, _ in points} == {-1, 1})


def _folded(points: list) -> list:
    """Each real angle within 45° of the put-downs' own typical turn from what was told (a cube looks the same every
    90°, so a reading is known only to a quarter turn). The check folded each one within 45° of what was told: with
    the fingers ~15° off that, a cube read 14.6° at -40° from below was put at -75.4°, and that one put-down made 15.6°
    of backlash and 18.2° of scatter out of a fit with none (the lab, 2026-10-26 -- reviewer 2, 2026-10-27)."""
    if not points:
        return []
    quarter = np.radians([4.0 * (real - told) for told, _, real in points])
    centre = math.degrees(math.atan2(float(np.sin(quarter).mean()), float(np.cos(quarter).mean()))) / 4.0
    return [(float(told), int(side), float(told) + centre + (float(real) - float(told) - centre + 45.0) % 90.0 - 45.0)
            for told, side, real in points]


def _solve(points: list) -> tuple:
    rows = np.array([[1.0, told, side / 2.0] for told, side, _ in points], float)
    real = np.array([r for _, _, r in points], float)
    coef, *_ = np.linalg.lstsq(rows, real, rcond=None)
    return coef, real - rows @ coef


def fit_wrist(points: list[tuple[float, int, float]]) -> WristModel:
    """The model from the put-downs: (wrist angle told, side it came from (-1 below, +1 above), real angle measured).
    Least squares for offset, gain and backlash; scatter is the typical distance from the fit. A put-down far off the
    others' fit is left out (OUTLIER_DEG): with plain least squares one cube that turned as it was let go decided the
    backlash -- 2 to 23° by which one of ten was left out."""
    points = _folded(points)
    model = WristModel(samples=len(points), points=list(points),
                       measured_at=time.strftime("%Y-%m-%d %H:%M"))
    if not _enough(points):
        judge(model)
        return model
    coef, residual = _solve(points)
    for _ in range(MAX_LEFT_OUT):
        scatter = float(np.median(np.abs(residual))) * 1.4826
        worst = int(np.argmax(np.abs(residual)))
        rest = points[:worst] + points[worst + 1:]
        if abs(residual[worst]) <= max(3.0 * scatter, OUTLIER_DEG) or not _enough(rest):
            break
        model.left_out.append(points[worst])
        points = rest
        coef, residual = _solve(points)
    model.points, model.samples = points, len(points)
    model.offset_deg, model.gain, model.backlash_deg = (float(v) for v in coef)
    model.scatter_deg = float(np.median(np.abs(residual))) * 1.4826        # as a standard deviation, outliers aside
    return judge(model)


def judge(model: WristModel) -> WristModel:
    """Trusted (used for picks) or not, and why not, by the limits above -- the same whether just measured or loaded
    (a fit refused for backlash under -1° was saved with its backlash raised to 0, and judged again on loading it was
    trusted: picks used what the panel had said they don't -- reviewer 2, 2026-10-27)."""
    if model.points and not _enough(model.points):
        model.trusted = False
        model.problems = [f"too few put-downs to tell ({len(model.points)}; needs {MIN_SAMPLES} at 3 or more angles, "
                          "approached from both sides)"]
        return model
    problems = []
    if not GAIN_RANGE[0] <= model.gain <= GAIN_RANGE[1]:
        problems.append(f"the wrist would turn {model.gain * 100:.0f}% of what it is told (not believable)")
    if not -1.0 <= model.backlash_deg <= MAX_BACKLASH_DEG:
        problems.append(f"{model.backlash_deg:.1f}° of backlash (not believable)")
    if abs(model.offset_deg) > MAX_OFFSET_DEG:
        problems.append(f"an offset of {model.offset_deg:+.1f}° (over {MAX_OFFSET_DEG:.0f}°: check how the gripper is "
                        "mounted)")
    if model.scatter_deg > MAX_SCATTER_DEG:
        problems.append(f"the put-downs scatter {model.scatter_deg:.1f}° round the fit (over {MAX_SCATTER_DEG:.1f}°: "
                        "the cube turned as it was let go, or the camera's angle readings are noisy)")
    model.trusted, model.problems = not problems, problems
    return model


class WristCorrected:
    """Stands in for the robot inside the robot tools: every pose they send is in ideal terms (the fingers at
    jaw_axis_deg + r); the robot is told the r that gives that, by `model` (None, or not trusted: as it is). Poses read
    back are turned into ideal terms again, so the tools see the r they asked for. Everything else passes through."""

    def __init__(self, robot, gripper, model: Optional[WristModel] = None, side: int = WristModel.APPROACH_SIDE):
        self._robot = robot
        self.gripper = gripper
        self.model = model
        self.side = side            # which way picks come to their angle: -1 from below, +1 from above

    def __getattr__(self, name):
        return getattr(self._robot, name)

    @property
    def active(self) -> bool:
        return self.model is not None and self.model.trusted and self.gripper.fingers

    def told_wrist(self, wrist: float) -> float:
        """The wrist joint's angle the robot is told for a planned one (the correction; as planned without one): the
        planner checks this against the wrist's limits too (GripperSpec.told_wrist), so a correction never has to be
        cut short at a limit."""
        if not self.active:
            return wrist
        return self.model.told_for(wrist, self.side)

    def pre_turn(self, configured: float) -> float:
        """How far short of its angle the wrist turns first: at least the measured slack and 2° more -- the last turn
        must cross the whole slack for it to be taken up the same way every time (with 6° of slack and a 4° pre-turn
        a pick ended 2° off)."""
        if not self.active or configured <= 0.0:
            return configured
        return max(configured, self.model.backlash_deg + 2.0)

    def told_r(self, r: float, x: float, y: float) -> float:
        if not self.active:
            return r
        base = r - self.gripper.wrist_turn(r, x, y)        # J1 for the Dobot (r = J1 + J4), 0 for the xArm
        told = self.model.told_for(r - base, self.side)
        low, high = self.gripper.j4_limits_deg
        if not low + WRIST_LIMIT_MARGIN_DEG <= told <= high - WRIST_LIMIT_MARGIN_DEG:
            # (a grip planned near the end of the wrist's range, the correction past it: the controller would refuse
            # the move -- as far as it goes instead, a degree or two short of the correction)
            clamped = max(low + WRIST_LIMIT_MARGIN_DEG, min(high - WRIST_LIMIT_MARGIN_DEG, told))
            logger.warning("The wrist correction would take %s to %.1f°, past its limit: %.1f° (the fingers end "
                           "%.1f° off)", self.gripper.wrist_name, told, clamped, abs(told - clamped))
            told = clamped
        return base + told

    def ideal_r(self, r: float, x: float, y: float) -> float:
        if not self.active:
            return r
        base = r - self.gripper.wrist_turn(r, x, y)
        return base + self.model.real_wrist(r - base, self.side)

    def _told(self, pose: Pose) -> Pose:
        return Pose(pose.x, pose.y, pose.z, self.told_r(pose.r, pose.x, pose.y))

    def move_to(self, pose: Pose, *args, **kwargs):
        return self._robot.move_to(self._told(pose), *args, **kwargs)

    def _move_to_raw(self, pose: Pose, *args, **kwargs):
        mover = getattr(self._robot, "_move_to_raw", None) or self._robot.move_to
        return mover(self._told(pose), *args, **kwargs)

    def get_pose(self) -> Pose:
        pose = self._robot.get_pose()
        return Pose(pose.x, pose.y, pose.z, self.ideal_r(pose.r, pose.x, pose.y))


def slow_move(robot, pose: Pose, speed_mm_s: float) -> None:
    """One move at `speed_mm_s`: the Dobot by its pace (it has no per-move speed), others by the move's own speed."""
    setter = getattr(robot, "set_pace", None)
    top = float(getattr(robot, "max_speed", 0.0) or 0.0)
    if callable(setter) and top > 0.0:
        before = None
        try:
            before = setter(max(5.0, min(100.0, 100.0 * speed_mm_s / top)))
        except Exception:  # noqa: BLE001 - slower is a nicety: the move still happens
            before = None
        try:
            robot.move_to(pose)
        finally:
            if before is not None:
                try:
                    setter(*before)
                except Exception:  # noqa: BLE001
                    pass
        return
    robot.move_to(pose, speed_mm_s)


def approach_from_side(robot, pose: Pose, gripper, overshoot_deg: float, side: int = WristModel.APPROACH_SIDE) -> None:
    """Turn the wrist to `pose`'s r coming from one side (-1: from below, first `overshoot_deg` short of it, then up to
    it; +1: from above), so the gears' slack is always taken up the same way (where the wrist can't go that far,
    straight to it)."""
    before = pose.r + side * overshoot_deg
    if overshoot_deg > 0.0 and gripper.wrist_fits(before, pose.x, pose.y):
        robot.move_to(Pose(pose.x, pose.y, pose.z, before))
    robot.move_to(pose)


def steady_mean(angles: list[float], period: float) -> tuple[float, float, int]:
    """(the average, the largest distance from it, how many readings were left out) of angles repeating every
    `period` degrees, one reading in four left out -- the ones furthest off: one bad picture (an edge lost, a
    reflection) shouldn't decide. Readings 0, 7, 2, 3 are 0, 2, 3 (within 1.7° of their average), not 'up to 4°'."""
    keep = list(angles)
    drop = len(keep) // 4
    for _ in range(drop):
        mean, _ = circular_spread(keep, period)
        keep.remove(max(keep, key=lambda a: abs((a - mean + period / 2.0) % period - period / 2.0)))
    mean, spread = circular_spread(keep, period)
    return mean, spread, drop


def wrap90(angle: float) -> float:
    return (angle + 45.0) % 90.0 - 45.0


def wrap(angle: float) -> float:
    return (angle + 180.0) % 360.0 - 180.0


def circular_spread(angles: list[float], period: float) -> tuple[float, float]:
    """(the average, the largest distance from it) of angles that repeat every `period` degrees (90 for a square)."""
    k = 360.0 / period
    a = np.radians(np.asarray(angles, float) * k)
    mean = math.degrees(math.atan2(np.sin(a).mean(), np.cos(a).mean())) / k
    spread = max(abs((x - mean + period / 2.0) % period - period / 2.0) for x in angles)
    return float(mean), float(spread)

"""The Dobot Magician's arm as its own controller works it out: which joint angles a point (x, y, z) needs, and
whether the controller will take it.

The controller's forward kinematics, in its own frame (x, y, z as it reports them; the gripper set as its end
effector):  out from the base = 135 sin J2 + 147 cos J3 + 59.7,  z = 135 cos J2 - 147 sin J3  (J2: the rear arm
from upright; J3: the forearm below horizontal). Checked against every move of study 2's Dobot runs (323): z to
0.15 mm, out to 59.5-63.2 mm for the last term.

Why: study 2, S-06_Run1 -- the approach above a cube 160 mm from the base, at z 42, needs J2 = -6 degrees, the rear
arm leaning back past upright. The controller refused it with alarm 0x12 ("a joint would go past its limit") and then
refused every move, even to where it already was, until the Dobot was switched off and on (S-07_Run1 met it too).
Moves at J2 down to -1.9 went fine (S-08_Run2). Near the base the arm can reach low, not high: the same spot 30 mm
lower is J2 = +4.
"""
from __future__ import annotations

import math
from typing import Optional

REAR_MM = 135.0            # J2 -> J3
FORE_MM = 147.0            # J3 -> the wrist
TOOL_OUT_MM = 59.7         # the wrist -> the tool point, outward (the controller's end-effector setting)
LAB_TABLE_Z_MM = -32.6     # the lab table in the controller's z (study 2's runs): the twin's table (z 0) judged as it

# what the controller refuses (the driver doesn't send it), and what a plan stays inside (a few degrees spare)
REFUSED = {"J2": (-4.0, 87.0), "J3": (-12.0, 92.0)}      # J2: -6 refused (S-06), -1.9 taken (S-08_Run2)
PLANNED = {"J2": (1.0, 83.0), "J3": (-8.0, 88.0)}
NAMES = {"J2": "the rear arm (J2)", "J3": "the forearm (J3)"}


def controller_joints(x: float, y: float, z: float) -> Optional[tuple[float, float]]:
    """(J2, J3) in degrees for the tool point at (x, y, z) in the controller's frame, elbow up as the Dobot works;
    None if the two arms can't stretch (or fold) to it at all."""
    out = math.hypot(x, y) - TOOL_OUT_MM
    reach = math.hypot(out, z)
    if not abs(REAR_MM - FORE_MM) < reach < REAR_MM + FORE_MM:
        return None
    cos_a = (REAR_MM ** 2 + reach ** 2 - FORE_MM ** 2) / (2.0 * REAR_MM * reach)
    rear = math.atan2(z, out) + math.acos(max(-1.0, min(1.0, cos_a)))      # the rear arm above horizontal
    fore = math.atan2(z - REAR_MM * math.sin(rear), out - REAR_MM * math.cos(rear))
    return 90.0 - math.degrees(rear), -math.degrees(fore)


def reach_problem(x: float, y: float, z: float, planning: bool = False) -> Optional[str]:
    """Why the controller would refuse (x, y, z) -- or, `planning`, why a plan shouldn't use it (a few degrees
    spare) -- in words; None if it is fine."""
    joints = controller_joints(x, y, z)
    if joints is None:
        return (f"({x:.0f}, {y:.0f}, {z:.0f}) is beyond what the arm can stretch or fold to "
                f"({math.hypot(x, y):.0f} mm out from the base)")
    limits = PLANNED if planning else REFUSED
    for name, angle in zip(("J2", "J3"), joints):
        low, high = limits[name]
        if not low <= angle <= high:
            side = "leaning back past upright" if name == "J2" and angle < low else "past its limit"
            return (f"at ({x:.0f}, {y:.0f}, {z:.0f}) {NAMES[name]} would be at {angle:.1f} degrees, {side} "
                    f"({low:.0f} to {high:.0f})")
    return None

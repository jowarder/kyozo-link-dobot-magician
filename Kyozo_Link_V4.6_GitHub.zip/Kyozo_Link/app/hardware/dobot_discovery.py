"""Finds which serial port a Dobot Magician is actually on.

Different robots enumerate on different COM ports and even use different USB-serial
chips (seen so far: WCH CH9102 on COM5, Silicon Labs CP210x on COM4), so a fixed
port in config.yaml breaks whenever the robot or the USB port changes.

Only ports from known USB-serial vendors (plus the configured port) are probed, and
the probe is a single read-only GET_POSE request, so other devices aren't poked with
anything harmful.
"""
from __future__ import annotations

import logging
import time
from typing import Optional

import serial
from serial.tools import list_ports

logger = logging.getLogger(__name__)

# WCH (CH340/CH9102), Silicon Labs (CP210x), FTDI
KNOWN_USB_SERIAL_VIDS = {0x1A86, 0x10C4, 0x0403}

# GET_POSE (id 10) request: header AA AA, len 2, id, ctrl, checksum
_GET_POSE_PACKET = bytes([0xAA, 0xAA, 0x02, 0x0A, 0x00, 0xF6])
_GET_POSE_ID = 0x0A


def open_dobot_serial(port: str, **settings) -> serial.Serial:
    """Opens the port with DTR and RTS held low.

    Measured on real hardware (CP210x-based Dobot): with the default settings the
    robot answered the first open and then stopped responding after every following
    close/reopen; with DTR/RTS low it answered 3 of 3 reopens in 0.3 s. Asserting
    those lines on open appears to reset or hang the controller."""
    ser = serial.Serial()
    ser.port = port
    for key, value in settings.items():
        setattr(ser, key, value)
    ser.dtr = False
    ser.rts = False
    ser.open()
    return ser


def probe_port(port: str, attempts: int = 2, wait_s: float = 0.5) -> tuple[bool, str]:
    """Returns (is_dobot, reason). The port handle is always closed before returning."""
    ser = None
    try:
        ser = open_dobot_serial(port, baudrate=115200, parity=serial.PARITY_NONE,
                                 stopbits=serial.STOPBITS_ONE, bytesize=serial.EIGHTBITS, timeout=1)
        for _ in range(attempts):
            ser.reset_input_buffer()
            ser.write(_GET_POSE_PACKET)
            time.sleep(wait_s)
            data = ser.read_all()
            if len(data) >= 5 and data[0] == 0xAA and data[1] == 0xAA and data[3] == _GET_POSE_ID:
                return True, "responded to GET_POSE"
        return False, "opened but no Dobot response (is the robot's DC power on?)"
    except serial.SerialException as exc:
        return False, f"could not open: {exc}"
    finally:
        if ser is not None and ser.is_open:
            ser.close()


def find_dobot_ports(preferred: Optional[str] = None) -> tuple[list[str], list[str]]:
    """Returns (responding_ports, report_lines). The preferred port is tried first."""
    ports = list(list_ports.comports())
    by_name = {p.device: p for p in ports}

    candidates: list[str] = []
    if preferred and preferred in by_name:
        candidates.append(preferred)
    for p in ports:
        if p.device not in candidates and p.vid in KNOWN_USB_SERIAL_VIDS:
            candidates.append(p.device)

    report: list[str] = []
    if preferred and preferred not in by_name:
        report.append(f"{preferred} (configured) is not present")
    found: list[str] = []
    for device in candidates:
        ok, reason = probe_port(device)
        report.append(f"{device} ({by_name[device].description}): {reason}")
        if ok:
            found.append(device)
    if not candidates:
        report.append("no USB-serial ports found -- is the robot's USB cable plugged in?")
    return found, report

"""The colour camera's picture settings the Camera setup panel offers -- exposure, gain, white balance, the depth
projector's power, anti-flicker -- in one shape for the real camera (OrbbecCamera) and the simulated one (SimCamera).
A camera offers only the ones it supports; the panel shows only those."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

# name -> its label, in the order the panel shows them
CONTROL_LABELS = {
    "exposure_auto": "Exposure: automatic",
    "exposure": "Exposure",
    "gain": "Gain",
    "white_balance_auto": "White balance: automatic",
    "white_balance": "White balance",
    "projector_power": "Projector power",
    "anti_flicker": "Anti-flicker",
    # the depth sensor's own (infrared) exposure: its automatic one, aiming at the dark mat, overexposed the white A4
    # sheet -- the sheet read 12 mm (up to 26) above the mat, with depth on only 45% of it, and phantom "white
    # objects" stood on it. Fixed at 1200 it read flat (+1.6 mm) and whole (2026-10-18, the lab's Gemini 335).
    "depth_exposure_auto": "Depth exposure: automatic",
    "depth_exposure": "Depth (infrared) exposure",
}
# the manual setting each automatic one switches off
AUTO_FOR = {"exposure": "exposure_auto", "gain": "exposure_auto", "white_balance": "white_balance_auto",
            "depth_exposure": "depth_exposure_auto"}
# the mains frequency setting (the camera's own numbers)
FLICKER_CHOICES = {0: "Off", 1: "50 Hz", 2: "60 Hz", 3: "Auto"}


@dataclass
class Control:
    name: str
    kind: str                       # "bool", "int" or "choice"
    value: object
    low: Optional[float] = None
    high: Optional[float] = None
    step: Optional[float] = None
    default: Optional[float] = None
    choices: dict = field(default_factory=dict)    # value -> label (kind "choice")

    @property
    def label(self) -> str:
        return CONTROL_LABELS.get(self.name, self.name)


def settings_to_keep(values: dict) -> dict:
    """The picture settings that recreate the picture: every one, except a manual value its automatic one is choosing
    (an exposure or gain while automatic exposure is on: the camera picks those itself)."""
    return {name: value for name, value in values.items()
            if not (AUTO_FOR.get(name) and values.get(AUTO_FOR[name]))}


def apply_order(values: dict) -> list[tuple[str, object]]:
    """The settings to set, in the order that leaves the camera as `values` says: a manual value its automatic one
    chooses left out, and automatic ones switched on last. (The real Gemini 335 switches automatic white balance off
    when a white balance is set, whatever was set before it: restored automatic first, then 4600, it stayed manual.)"""
    keep = settings_to_keep(values)
    return sorted(keep.items(), key=lambda item: (0 if item[0].endswith("_auto") and not item[1] else
                                                  2 if item[0].endswith("_auto") else 1))


def clamp_to(control: Control, value):
    """`value` as the control takes it: a bool, a choice it has, or a number within its range and on its step."""
    if control.kind == "bool":
        return bool(value)
    if control.kind == "choice":
        value = int(value)
        if value not in control.choices:
            raise ValueError(f"{control.label}: {value} isn't one of {sorted(control.choices)}")
        return value
    value = float(value)
    if control.low is not None:
        value = max(float(control.low), value)
    if control.high is not None:
        value = min(float(control.high), value)
    if control.step:
        base = float(control.low or 0.0)
        value = base + round((value - base) / float(control.step)) * float(control.step)
    return int(round(value))

"""Which way the arm travels between two points: shared by the real driver and the simulator, so the
demo arm takes the same route the real one does (and the 3D view can show that route in advance)."""
from __future__ import annotations

import math

from app.hardware.interfaces import Pose

# A straight line that passes nearer the base than this (and nearer than either end) swings round
# instead: on the real arm a straight move from (133, 202) towards (133, -202) stopped at 183 mm
# out, about 78 mm up, with alarm 0x22 -- the arm can't get that close to its base at that height.
NEAR_BASE_PATH_MM = 200.0


def passes_near_base(start: Pose, end: Pose, radius_mm: float = NEAR_BASE_PATH_MM) -> bool:
    """True if a straight line from start to end (seen from above) comes nearer the base than
    `radius_mm` AND nearer than both ends -- i.e. it cuts across in front of the base. A move straight
    towards or away from the base, or up and down, never counts: its closest point is one of its ends."""
    dx, dy = end.x - start.x, end.y - start.y
    length_sq = dx * dx + dy * dy
    if length_sq < 1e-9:
        return False
    t = max(0.0, min(1.0, -(start.x * dx + start.y * dy) / length_sq))
    closest = math.hypot(start.x + t * dx, start.y + t * dy)
    ends = min(math.hypot(start.x, start.y), math.hypot(end.x, end.y))
    return closest < radius_mm and closest < ends - 1.0


def swing_point(start: Pose, end: Pose, t: float) -> Pose:
    """A point `t` (0..1) of the way round a swing: the angle round the base, the distance out and the
    height each change evenly -- close to what the controller's joint move (MOVJ) does."""
    a0, a1 = math.atan2(start.y, start.x), math.atan2(end.y, end.x)
    turn = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi          # the short way round
    radius = math.hypot(start.x, start.y) + (math.hypot(end.x, end.y) - math.hypot(start.x, start.y)) * t
    angle = a0 + turn * t
    return Pose(x=radius * math.cos(angle), y=radius * math.sin(angle),
                z=start.z + (end.z - start.z) * t, r=start.r + (end.r - start.r) * t)


def path_points(start: Pose, end: Pose, steps: int = 40) -> list[Pose]:
    """The route the arm takes from start to end: a straight line, or a swing round the base."""
    if passes_near_base(start, end):
        return [swing_point(start, end, i / steps) for i in range(steps + 1)]
    return [Pose(x=start.x + (end.x - start.x) * i / steps, y=start.y + (end.y - start.y) * i / steps,
                 z=start.z + (end.z - start.z) * i / steps, r=start.r + (end.r - start.r) * i / steps)
            for i in range(steps + 1)]

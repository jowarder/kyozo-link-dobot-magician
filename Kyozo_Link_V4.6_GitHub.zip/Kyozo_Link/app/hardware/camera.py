"""pyorbbecsdk-backed implementation of the Camera interface for the Orbbec Gemini 335.

NOTE: pyorbbecsdk's exact API varies by SDK version. This wrapper targets the
common Pipeline/FrameSet/AlignFilter pattern from Orbbec's official samples;
verify against the SDK version installed during hardware bring-up
(Milestone 2) and adjust as needed.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

import numpy as np

from app.hardware.interfaces import Camera, Frame, Intrinsics
from app.vision.undistort import Undistorter, has_distortion

logger = logging.getLogger(__name__)

try:
    from pyorbbecsdk import Context, Pipeline, Config, OBSensorType, OBFormat, AlignFilter, OBStreamType
except ImportError:  # pragma: no cover - optional dependency until hardware bring-up
    Pipeline = None


DEPTH_PRESETS = ("Default", "High Accuracy")   # the depth sensor's presets offered in Settings > Camera

# our picture settings' names (camera_controls) -> the SDK's properties for them, the first one supported is used
# (projector power: cameras name it differently)
ORBBEC_PROPERTIES = {
    "exposure_auto": ("OB_PROP_COLOR_AUTO_EXPOSURE_BOOL",),
    "exposure": ("OB_PROP_COLOR_EXPOSURE_INT",),
    "gain": ("OB_PROP_COLOR_GAIN_INT",),
    "white_balance_auto": ("OB_PROP_COLOR_AUTO_WHITE_BALANCE_BOOL",),
    "white_balance": ("OB_PROP_COLOR_WHITE_BALANCE_INT",),
    "projector_power": ("OB_PROP_LASER_POWER_LEVEL_CONTROL_INT", "OB_PROP_LASER_ENERGY_LEVEL_INT"),
    "anti_flicker": ("OB_PROP_COLOR_POWER_LINE_FREQUENCY_INT",),
    "depth_exposure_auto": ("OB_PROP_IR_AUTO_EXPOSURE_BOOL",),
    "depth_exposure": ("OB_PROP_IR_EXPOSURE_INT",),
}


class OrbbecCamera(Camera):
    def __init__(self, serial: str = "", width: int = 1280, height: int = 720,
                 fps: int = 30, min_distance_mm: float = 300.0, undistort: bool = True,
                 depth_preset: str = "Default"):
        if Pipeline is None:
            raise RuntimeError(
                "pyorbbecsdk is not installed. Install the Orbbec SDK wheel to use real hardware."
            )
        self.serial = serial
        self.width = width
        self.height = height
        self.fps = fps
        self.min_distance_mm = min_distance_mm
        self._pipeline = None
        self._align = None
        self._intrinsics: Optional[Intrinsics] = None
        self._lock = threading.Lock()
        # the colour lens's bend, as the camera reports it (OpenCV order), and whether pictures are straightened by
        # it as they come in (app/vision/undistort.py)
        self.undistort = undistort
        self.distortion: Optional[tuple] = None
        self._undistorter: Optional[Undistorter] = None
        self.connected_at: Optional[float] = None    # time.monotonic() when it started: its distances drift at first
        self._depth_profile = None
        self._color_profile = None
        self._raw_info: Optional[tuple] = None
        # The depth sensor's preset: the one asked for, and the one it really has (None: the SDK wouldn't say). The
        # sensor only takes a new preset while it isn't streaming, so it is loaded before start() (see
        # switch_depth_preset for changing it later).
        self.wanted_preset = depth_preset
        self.depth_preset: Optional[str] = None
        self._config = None
        self._switching = threading.Event()
        self._switch_thread: Optional[threading.Thread] = None     # the one changing the preset (it may set controls)
        self.wanted_controls: dict = {}     # the picture settings set (Camera setup): put back if the camera reopens

    def connect(self) -> None:
        logger.info("Connecting to Orbbec Gemini 335 (serial=%s)", self.serial or "<first found>")
        # IMPORTANT: constructing Pipeline() with zero Orbbec devices physically
        # connected crashes the *entire process* with a native heap-corruption
        # fault (exit code STATUS_HEAP_CORRUPTION) -- not a catchable Python
        # exception. Context().query_devices() is safe to call with no hardware
        # present, so check device count first and refuse cleanly instead.
        device_count = len(Context().query_devices())
        if device_count == 0:
            raise RuntimeError(
                "No Orbbec camera detected. Constructing a Pipeline with zero "
                "devices connected crashes the whole app, so refusing before "
                "that point -- plug in the Gemini 335 and try again."
            )
        self._pipeline = Pipeline()
        config = Config()
        color_profiles = self._pipeline.get_stream_profile_list(OBSensorType.COLOR_SENSOR)
        depth_profiles = self._pipeline.get_stream_profile_list(OBSensorType.DEPTH_SENSOR)
        color_profile = color_profiles.get_video_stream_profile(self.width, self.height, OBFormat.RGB, self.fps)
        depth_profile = depth_profiles.get_video_stream_profile(self.width, self.height, OBFormat.Y16, self.fps)
        config.enable_stream(color_profile)
        config.enable_stream(depth_profile)
        # Without this, color and depth free-run independently and wait_for_frames()
        # returns framesets with only one of the two populated -- discovered by testing
        # against real hardware, where get_color_frame() was consistently None until
        # frame sync was enabled and given a few frames to lock in (see warm-up below).
        self._pipeline.enable_frame_sync()
        self._config = config
        self.depth_preset = self._load_preset(self.wanted_preset)
        self._pipeline.start(config)
        self._align = AlignFilter(align_to_stream=OBStreamType.COLOR_STREAM)

        intr = color_profile.get_intrinsic()
        self._intrinsics = Intrinsics(
            fx=intr.fx, fy=intr.fy, cx=intr.cx, cy=intr.cy,
            width=self.width, height=self.height,
        )
        self._color_profile, self._depth_profile = color_profile, depth_profile
        self.distortion = self._read_distortion(color_profile)
        logger.info("Colour lens distortion (k1, k2, p1, p2, k3, k4, k5, k6): %s; straightened: %s",
                    self.distortion, self.undistort and has_distortion(self.distortion))
        if self.undistort and has_distortion(self.distortion):
            self._undistorter = Undistorter(self._intrinsics, self.distortion)
        self._warm_up_frame_sync()
        self.connected_at = time.monotonic()

    @staticmethod
    def _read_distortion(profile) -> Optional[tuple]:
        """The lens's coefficients in OpenCV's order, or None if the SDK won't say."""
        try:
            d = profile.get_distortion()
            return tuple(float(getattr(d, name, 0.0)) for name in ("k1", "k2", "p1", "p2", "k3", "k4", "k5", "k6"))
        except Exception as exc:  # noqa: BLE001 - SDK versions differ
            logger.warning("The camera didn't say its lens distortion (%s): pictures are used as they come.", exc)
            return None

    # ---- for the cube calibration: the depth sensor's own picture, and its accuracy preset ------------------------
    def raw_depth_info(self) -> Optional[tuple]:
        """(the depth sensor's own intrinsics, its depth->colour 4x4 transform in mm), or None if the SDK won't say."""
        if self._raw_info is None and self._depth_profile is not None:
            intr = self._depth_profile.get_intrinsic()
            extrinsic = self._depth_profile.get_extrinsic_to(self._color_profile)
            transform = np.eye(4)
            transform[:3, :3] = np.array(list(extrinsic.rot), float).reshape(3, 3)
            transform[:3, 3] = np.array(list(extrinsic.transform), float)
            k = Intrinsics(fx=intr.fx, fy=intr.fy, cx=intr.cx, cy=intr.cy, width=intr.width, height=intr.height)
            self._raw_info = (k, transform)
        return self._raw_info

    def get_raw_depth(self) -> np.ndarray:
        """One depth picture as the depth sensor took it (not lined up with the colour camera), in mm."""
        if self._pipeline is None:
            raise RuntimeError("Camera not connected. Call connect() first.")
        with self._lock:
            for _ in range(5):
                frames = self._pipeline.wait_for_frames(1000)
                depth_frame = None if frames is None else frames.get_depth_frame()
                if depth_frame is not None:
                    break
            else:
                raise TimeoutError("No depth frame")
            depth = np.frombuffer(depth_frame.get_data(), dtype=np.uint16).reshape(
                depth_frame.get_height(), depth_frame.get_width()).astype(np.float32)
            depth *= depth_frame.get_depth_scale()
            depth[depth < self.min_distance_mm] = 0
        return depth

    def _load_preset(self, name: str) -> Optional[str]:
        """Load a depth preset while the pipeline isn't streaming: the preset the sensor has afterwards (`name` if it
        took), or None if the SDK won't say. Never raises: a camera that can't change presets keeps its own."""
        try:
            device = self._pipeline.get_device()
        except Exception as exc:  # noqa: BLE001 - SDK versions differ
            logger.warning("Couldn't reach the camera to set the depth preset: %s", exc)
            return None
        before = None
        try:
            before = device.get_current_preset_name()
            if before != name:
                device.load_preset(name)
                logger.info("Depth preset: %s (was %s)", name, before)
            return device.get_current_preset_name()
        except Exception as exc:  # noqa: BLE001 - SDK versions differ
            logger.warning("Couldn't load the depth preset %r: %s (it stays %s)", name, exc, before or "unknown")
            return before

    def switch_depth_preset(self, name: str) -> str:
        """Change the depth preset while the app runs: stop the streams, load it, start them again; if the camera
        won't, close and reopen it with the new preset; if that fails too, go back to the old one. Slow (seconds):
        call it off the UI thread. Returns what happened, for the user; raises RuntimeError if the camera couldn't
        be brought back at all."""
        if self._pipeline is None:
            raise RuntimeError("The camera isn't connected.")
        old = self.depth_preset or self.wanted_preset
        self._switch_thread = threading.current_thread()
        self._switching.set()
        try:
            with self._lock:
                try:
                    self._pipeline.stop()
                    got = self._load_preset(name)
                    self._pipeline.start(self._config)
                    self._warm_up_frame_sync()
                    if got == name:
                        self.wanted_preset, self.depth_preset = name, got
                        # a preset is a whole set of depth settings: the depth (infrared) exposure and the projector
                        # power chosen in Camera setup set again over it, as reopening the camera does
                        if self.wanted_controls:
                            self._apply_controls(dict(self.wanted_controls))
                        return f"Depth preset: {name}."
                    logger.warning("The depth preset didn't change by restarting the streams; reopening the camera")
                except Exception as exc:  # noqa: BLE001 - SDK versions differ
                    logger.warning("Restarting the streams with the depth preset %r failed: %s; reopening the camera",
                                   name, exc)
                for preset in (name, old):          # reopen with the new preset; failing that, with the old one
                    try:
                        self._reopen(preset)
                    except Exception as exc:  # noqa: BLE001
                        logger.error("Reopening the camera with the depth preset %r failed: %s", preset, exc)
                        continue
                    if self.depth_preset == name:
                        return f"Depth preset: {name} (the camera was reopened for it)."
                    self.wanted_preset = self.depth_preset or old
                    return (f"The camera wouldn't take the {name} preset; it is on "
                            f"{self.depth_preset or 'a preset it will not name'}.")
                raise RuntimeError(f"The camera couldn't be restarted after changing the depth preset to {name}: "
                                   "unplug it, plug it back in and use Reconnect.")
        finally:
            self._switching.clear()
            self._switch_thread = None

    def _reopen(self, preset: str) -> None:
        """Close the camera and connect again with `preset` (holding the frame lock)."""
        try:
            if self._pipeline is not None:
                self._pipeline.stop()
        except Exception:  # noqa: BLE001 - already stopped
            pass
        self._pipeline = None
        self.wanted_preset = preset
        started = self.connected_at
        self.connect()
        self.connected_at = started    # the sensor stayed powered: its warm-up isn't restarted
        if self.wanted_controls:
            self._apply_controls(dict(self.wanted_controls))

    def _warm_up_frame_sync(self, max_attempts: int = 90) -> None:
        """Frame sync takes ~10-15 frames to lock color+depth together after start().
        Burn through that here so the first UI-facing get_frame() call doesn't stall."""
        for attempt in range(max_attempts):
            frames = self._pipeline.wait_for_frames(1000)
            if frames is None:
                continue
            aligned = self._align.process(frames)
            if aligned is not None and aligned.get_color_frame() is not None \
                    and aligned.get_depth_frame() is not None:
                logger.info("Camera frame sync locked after %d frames", attempt + 1)
                return
        logger.warning("Camera frame sync did not lock within %d frames; "
                        "get_frame() may raise until it does.", max_attempts)

    def disconnect(self) -> None:
        if self._pipeline is not None:
            self._pipeline.stop()
            self._pipeline = None

    def get_intrinsics(self) -> Intrinsics:
        if self._intrinsics is None:
            raise RuntimeError("Camera not connected. Call connect() first.")
        return self._intrinsics

    def describe(self) -> dict:
        """What the camera says about itself (name, how it is connected, firmware). Best effort:
        anything the SDK won't tell us is left out."""
        info: dict = {}
        try:
            details = Context().query_devices().get_device_by_index(0).get_device_info()
        except Exception:  # noqa: BLE001 - purely informational
            return info
        for key, method in (("name", "get_name"), ("connection", "get_connection_type"),
                            ("firmware", "get_firmware_version"), ("serial", "get_serial_number")):
            try:
                info[key] = getattr(details, method)()
            except Exception:  # noqa: BLE001
                pass
        return info

    # ---- picture settings (Camera setup): exposure, gain, white balance, projector power, anti-flicker ------------
    def _device(self):
        if self._pipeline is None:
            raise RuntimeError("The camera isn't connected.")
        return self._pipeline.get_device()

    def _restarting(self) -> bool:
        """The streams are being restarted for a depth preset (by another thread): the device may be closed and
        reopened under a settings call, so none is made meanwhile."""
        return self._switching.is_set() and threading.current_thread() is not self._switch_thread

    def _property(self, name: str):
        """(the SDK's property id, its kind) for one of our control names, the first the camera supports; None if
        it supports none of them."""
        from pyorbbecsdk import OBPermissionType, OBPropertyID
        device = self._device()
        for prop_name in ORBBEC_PROPERTIES.get(name, ()):
            prop = getattr(OBPropertyID, prop_name, None)
            if prop is None:
                continue
            try:
                if device.is_property_supported(prop, OBPermissionType.PERMISSION_READ_WRITE):
                    return prop, prop_name.rsplit("_", 1)[-1].lower()
            except Exception:  # noqa: BLE001 - SDK versions differ
                continue
        return None

    def controls(self) -> dict:
        """The picture settings this camera supports, with their values and ranges (camera_controls.Control)."""
        from app.hardware.camera_controls import FLICKER_CHOICES, Control
        out = {}
        if self._restarting():
            logger.info("Camera settings not read: the depth preset is being changed")
            return out
        try:
            device = self._device()
        except Exception as exc:  # noqa: BLE001
            logger.info("No camera settings to read: %s", exc)
            return out
        for name in ORBBEC_PROPERTIES:
            found = self._property(name)
            if found is None:
                continue
            prop, kind = found
            try:
                if kind == "bool":
                    out[name] = Control(name, "bool", bool(device.get_bool_property(prop)))
                    continue
                r = device.get_int_property_range(prop)
                value = int(device.get_int_property(prop))
                if name == "anti_flicker":
                    choices = {k: v for k, v in FLICKER_CHOICES.items() if r.min <= k <= r.max}
                    out[name] = Control(name, "choice", value, choices=choices)
                else:
                    out[name] = Control(name, "int", value, low=r.min, high=r.max, step=max(1, r.step),
                                        default=r.default_value)
            except Exception as exc:  # noqa: BLE001 - one setting it won't read is left out, not the end
                logger.info("The camera's %s couldn't be read: %s", name, exc)
        return out

    def set_control(self, name: str, value):
        """Set one picture setting; returns what the camera has afterwards. Raises ValueError if it doesn't support
        it or won't take the value."""
        from app.hardware.camera_controls import clamp_to
        if self._restarting():
            raise RuntimeError("The depth preset is being changed (the camera restarts its streams): try again in a "
                               "few seconds.")
        control = self.controls().get(name)
        if control is None:
            raise ValueError(f"This camera doesn't offer the {name.replace('_', ' ')} setting.")
        value = clamp_to(control, value)
        prop, kind = self._property(name)
        device = self._device()
        try:
            if kind == "bool":
                device.set_bool_property(prop, bool(value))
                got = bool(device.get_bool_property(prop))
            else:
                device.set_int_property(prop, int(value))
                got = int(device.get_int_property(prop))
        except Exception as exc:  # noqa: BLE001
            raise ValueError(f"The camera wouldn't take {control.label.lower()} = {value}: {exc}") from exc
        logger.info("Camera %s: %s", name, got)
        self.wanted_controls[name] = got
        return got

    def apply_controls(self, values: dict) -> list[str]:
        """Set the saved picture settings (config.yaml camera: controls) in camera_controls.apply_order's order (a
        manual value its automatic one chooses isn't set: on this camera that switches the automatic one off). Returns
        what couldn't be set, in words."""
        if self._restarting():
            return ["The depth preset is being changed: the settings weren't applied."]
        return self._apply_controls(values)

    def _apply_controls(self, values: dict) -> list[str]:
        from app.hardware.camera_controls import apply_order
        problems = []
        for name, value in apply_order(values):
            try:
                self.set_control(name, value)
            except Exception as exc:  # noqa: BLE001
                problems.append(str(exc))
        for problem in problems:
            logger.warning("Camera setting not applied: %s", problem)
        return problems

    def capabilities(self) -> str:
        """What this camera offers, read only: its name and firmware, every picture setting it supports with its
        value and range, and its picture sizes."""
        lines = []
        info = self.describe()
        lines.append(" · ".join(str(info[k]) for k in ("name", "firmware", "serial") if k in info) or "Orbbec camera")
        controls = self.controls()
        from app.hardware.camera_controls import CONTROL_LABELS
        for name, label in CONTROL_LABELS.items():
            c = controls.get(name)
            if c is None:
                lines.append(f"{label}: not supported")
            elif c.kind == "int":
                lines.append(f"{label}: {c.value} (range {c.low}-{c.high}, step {c.step}, default {c.default})")
            elif c.kind == "choice":
                lines.append(f"{label}: {c.choices.get(c.value, c.value)} (offers {', '.join(c.choices.values())})")
            else:
                lines.append(f"{label}: {'on' if c.value else 'off'}")
        try:
            for label, sensor in (("Depth", OBSensorType.DEPTH_SENSOR), ("Colour", OBSensorType.COLOR_SENSOR)):
                profiles = self._pipeline.get_stream_profile_list(sensor)
                sizes = {}
                for i in range(profiles.get_count()):
                    p = profiles.get_stream_profile_by_index(i).as_video_stream_profile()
                    sizes.setdefault((p.get_width(), p.get_height()), set()).add(p.get_fps())
                lines.append(f"{label} sizes: " + "; ".join(
                    f"{w}x{h} @ {', '.join(str(f) for f in sorted(fps))} fps"
                    for (w, h), fps in sorted(sizes.items(), reverse=True)))
        except Exception as exc:  # noqa: BLE001
            lines.append(f"Picture sizes: couldn't list ({exc})")
        lines.append(f"In use: {self.width}x{self.height} @ {self.fps} fps, depth preset "
                     f"{self.depth_preset or self.wanted_preset}")
        return "\n".join(lines)

    def get_frame(self, max_attempts: int = 5) -> Frame:
        if self._pipeline is None:
            raise RuntimeError("Camera not connected. Call connect() first.")
        if self._switching.is_set() and threading.current_thread() is threading.main_thread():
            # the feed (UI thread) keeps its last picture rather than freezing the window; workers wait below
            raise RuntimeError("The depth preset is being changed")
        with self._lock:
            for attempt in range(max_attempts):
                frames = self._pipeline.wait_for_frames(1000)
                if frames is None:
                    continue
                aligned = self._align.process(frames)
                if aligned is None:
                    continue
                color_frame = aligned.get_color_frame()
                depth_frame = aligned.get_depth_frame()
                if color_frame is not None and depth_frame is not None:
                    break
            else:
                raise TimeoutError(
                    f"No synced color+depth frame after {max_attempts} attempts"
                )

            rgb = np.frombuffer(color_frame.get_data(), dtype=np.uint8).reshape(
                color_frame.get_height(), color_frame.get_width(), 3
            )
            depth_raw = np.frombuffer(depth_frame.get_data(), dtype=np.uint16).reshape(
                depth_frame.get_height(), depth_frame.get_width()
            ).astype(np.float32)
            depth_raw *= depth_frame.get_depth_scale()  # -> millimeters
            depth_raw[depth_raw < self.min_distance_mm] = 0  # filter noisy close range

        if self._undistorter is not None:
            rgb, depth_raw = self._undistorter.apply(rgb, depth_raw)
        return Frame(rgb=rgb, depth=depth_raw, intrinsics=self._intrinsics)

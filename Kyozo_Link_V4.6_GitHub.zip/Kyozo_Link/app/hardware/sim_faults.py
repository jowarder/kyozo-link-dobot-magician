"""Ways a real depth camera falls short of the simulator's perfect one.

The simulated camera gives exact depth everywhere. A real one gives noisy depth that gets
worse with distance, has holes (shiny or dark surfaces, edges of objects), and the odd wildly
wrong pixel. These let the demo rehearse that, so calibration and table detection can be
tested against it at home instead of being discovered at the lab.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class CameraFaults:
    depth_noise: float = 0.0   # 1.0 ~ a Gemini 335 at close range: 0.8 mm at 0.5 m, growing with distance squared
    holes: float = 0.0         # share of the picture lost to holes and object-edge dropouts (0 to about 0.15)
    outliers: float = 0.0      # share of pixels whose depth is wildly wrong
    color_noise: float = 0.0   # standard deviation of colour noise, in grey levels

    @property
    def is_perfect(self) -> bool:
        return not (self.depth_noise or self.holes or self.outliers or self.color_noise)


PRESETS = {
    "Perfect": CameraFaults(),
    "Realistic": CameraFaults(depth_noise=1.0, holes=0.03, outliers=0.002, color_noise=2.0),
    "Poor": CameraFaults(depth_noise=3.0, holes=0.10, outliers=0.01, color_noise=5.0),
}

BASE_NOISE_MM_PER_M2 = 3.2   # sigma = 3.2 mm * (distance in metres)^2 at depth_noise = 1
EDGE_JUMP_MM = 25.0          # a depth step bigger than this is an object edge, where real cameras drop out
MEAN_HOLE_RADIUS_PX = 8


def degrade_depth(depth_mm: np.ndarray, faults: CameraFaults, rng: np.random.Generator) -> np.ndarray:
    """A copy of a perfect depth image with the faults applied. Invalid pixels stay 0."""
    if faults.is_perfect:
        return depth_mm
    out = depth_mm.copy()
    valid = out > 0
    if faults.depth_noise > 0:
        metres = out[valid] / 1000.0
        out[valid] += (rng.standard_normal(metres.shape) * BASE_NOISE_MM_PER_M2
                       * faults.depth_noise * metres ** 2).astype(np.float32)
    if faults.holes > 0:
        height, width = out.shape
        holes = np.zeros((height, width), np.uint8)
        count = int(faults.holes * height * width / (np.pi * MEAN_HOLE_RADIUS_PX ** 2))
        for x, y, radius in zip(rng.integers(0, width, count), rng.integers(0, height, count),
                                rng.integers(3, 2 * MEAN_HOLE_RADIUS_PX - 2, count)):
            cv2.circle(holes, (int(x), int(y)), int(radius), 1, -1)
        jump = np.maximum(np.abs(np.diff(out, axis=0, prepend=out[:1])),
                          np.abs(np.diff(out, axis=1, prepend=out[:, :1]))) > EDGE_JUMP_MM
        edges = cv2.dilate(jump.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
        out[(holes > 0) | (edges & (rng.random(out.shape) < 0.7))] = 0.0
    if faults.outliers > 0:
        wrong = (rng.random(out.shape) < faults.outliers) & (out > 0)
        out[wrong] += rng.uniform(-80.0, 80.0, int(wrong.sum())).astype(np.float32)
        out[out < 0] = 0.0
    return out


def degrade_color(rgb: np.ndarray, faults: CameraFaults, rng: np.random.Generator) -> np.ndarray:
    if faults.color_noise <= 0:
        return rgb
    noisy = rgb.astype(np.int16) + rng.normal(0.0, faults.color_noise, rgb.shape).astype(np.int16)
    return np.clip(noisy, 0, 255).astype(np.uint8)

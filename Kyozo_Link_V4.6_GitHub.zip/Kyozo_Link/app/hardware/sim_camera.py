"""Simulated RGB-D camera for demo mode: renders the PyBullet twin scene from a fixed viewpoint."""
from __future__ import annotations

from typing import Optional

import cv2
import numpy as np

from app.hardware.interfaces import Camera, Frame, Intrinsics
from app.hardware.sim_faults import PRESETS, CameraFaults, degrade_color, degrade_depth
from app.twin.world import pybullet_lock
from app.vision.undistort import Distorter, Undistorter, has_distortion

# Same navy as the 3D view's background. Kept dark (value < 70) so the colour detector ignores it.
BACKGROUND_TOP = (12, 24, 36)
OUTLINE_RGB = (7, 14, 22)
BACKGROUND_BOTTOM = (16, 31, 45)   # nearly flat, so the feed's edge doesn't show against the widget behind it

try:
    import pybullet as p
except ImportError:  # pragma: no cover
    p = None


class SimCamera(Camera):
    def __init__(self, physics_client: int, width: int = 1280, height: int = 720,
                 eye_position=None, target_position=None, fov_deg: Optional[float] = None):
        # Default view: from the side and above, like the real camera on the bench -- not
        # straight down, which flattens everything and hides the arm's shape. Close enough
        # that the arm fills the picture, with the whole arm still in frame.
        if p is None:
            raise RuntimeError("pybullet is not installed.")
        self.client = physics_client
        self.width = width
        self.height = height
        # (by default: mounted as on the Dobot's bench, moved with the scene for a bigger robot, see scene_offset_mm)
        from app import robots
        robot = robots.active()
        dx, dy = (v / 1000.0 for v in robot.scene_offset_mm)
        eye, target = (0.52 + dx, -0.46 + dy, 0.46), (0.16 + dx, 0.0 + dy, 0.12)
        if getattr(robot, "demo_camera", None):          # placed for this robot's working area
            eye, target = (tuple(v / 1000.0 for v in point) for point in robot.demo_camera)
        if fov_deg is None:                               # the robot's demo camera's (see its profile)
            fov_deg = float(getattr(robot, "demo_camera_fov_deg", 38.0))
        self.eye_position = tuple(eye_position) if eye_position is not None else eye
        self.target_position = tuple(target_position) if target_position is not None else target
        self._home_view = (self.eye_position, self.target_position)   # where the camera was mounted
        self.fov_deg = fov_deg
        self._intrinsics: Optional[Intrinsics] = None
        self._view_matrix = None
        self._proj_matrix = None
        self._near = 0.1
        self._far = 2.0
        self._cached_signature: Optional[tuple] = None
        self._cached_frame: Optional[Frame] = None
        self._background_image: Optional[np.ndarray] = None
        self._view_version = 0          # bumped whenever the camera moves, so a cached picture isn't reused
        self.faults = CameraFaults()    # how imperfect the depth and colour are; see sim_faults
        self._rng = np.random.default_rng()
        # ids of the bodies to outline (the arm); set by whoever owns the robot, e.g. robot.body_ids
        self.outline_bodies = lambda: []
        # a real camera's imperfections, for testing the calibration against them (see set_lens)
        self.distortion: Optional[tuple] = None    # the lens's coefficients, as a real camera reports them
        self.depth_scale = 1.0                      # distances read this many times too long
        self._distorter: Optional[Distorter] = None
        self._undistorter: Optional[Undistorter] = None
        # the depth preset, as on the real camera (the picture doesn't change with it); `preset_trouble` rehearses a
        # camera that won't switch: None, "restart" (restarting the streams doesn't take it: reopened instead) or
        # "refuse" (it keeps its old preset whatever is tried)
        self.wanted_preset = "Default"
        self.depth_preset: Optional[str] = None
        self.preset_trouble: Optional[str] = None
        # the picture settings, as the real camera offers them (Camera setup): a manual exposure brightens or darkens
        # the colour picture -- too bright, the cubes' colours wash out as a real camera's do -- the rest change
        # nothing here
        self._controls = {"exposure_auto": True, "exposure": 100, "gain": 0, "white_balance_auto": True,
                          "white_balance": 4600, "projector_power": 4, "anti_flicker": 2}
        # practising the camera setup on the demo (Camera setup's "Demo camera" tab): where the camera is, against
        # where it was mounted, and the lab's trouble -- automatic exposure washing the cubes' colours out (as over
        # the lab's black mat). The High Accuracy depth preset loses the cubes' edges, as the lab's camera did.
        self.view_up_mm, self.view_back_mm, self.view_tilt_deg = 0.0, 0.0, 0.0
        self.washed_out = False

    def connect(self) -> None:
        self.depth_preset = self.wanted_preset
        self._update_view()
        aspect = self.width / self.height
        self._proj_matrix = p.computeProjectionMatrixFOV(
            fov=self.fov_deg, aspect=aspect, nearVal=self._near, farVal=self._far,
        )
        # fov is the *vertical* field of view and pixels are square, so fx == fy.
        fy = self.height / (2 * np.tan(np.radians(self.fov_deg) / 2))
        fx = fy
        self._intrinsics = Intrinsics(
            fx=fx, fy=fy, cx=self.width / 2, cy=self.height / 2,
            width=self.width, height=self.height,
        )

    def _update_view(self) -> None:
        self._view_matrix = p.computeViewMatrix(
            cameraEyePosition=list(self.eye_position),
            cameraTargetPosition=list(self.target_position),
            cameraUpVector=[0, 0, 1],
        )
        self._view_version += 1

    # ---- rehearsing real-world trouble ---------------------------------------------------
    def set_faults(self, faults: "CameraFaults | str") -> None:
        """Make the picture imperfect: a `CameraFaults`, or the name of a preset."""
        self.faults = PRESETS[faults] if isinstance(faults, str) else faults

    def bump(self, shift_mm=(18.0, 10.0, 0.0), yaw_deg: float = 1.5, pitch_deg: float = 0.8) -> None:
        """Knock the camera: move it and turn it slightly, without telling the app. The exact
        transform follows the new position, so anything calibrated before is now wrong."""
        eye = np.array(self._home_view[0], dtype=float) + np.array(shift_mm, dtype=float) / 1000.0
        look = np.array(self._home_view[1], dtype=float) - np.array(self._home_view[0], dtype=float)
        yaw, pitch = np.radians(yaw_deg), np.radians(pitch_deg)
        turn_z = np.array([[np.cos(yaw), -np.sin(yaw), 0], [np.sin(yaw), np.cos(yaw), 0], [0, 0, 1]])
        right = np.cross(look, [0, 0, 1])
        right /= np.linalg.norm(right)
        k = np.array([[0, -right[2], right[1]], [right[2], 0, -right[0]], [-right[1], right[0], 0]])
        turn_up = np.eye(3) + np.sin(pitch) * k + (1 - np.cos(pitch)) * (k @ k)   # Rodrigues, about the camera's right axis
        self.eye_position = tuple(eye)
        self.target_position = tuple(eye + turn_up @ (turn_z @ look))
        self._update_view()

    def set_lens(self, distortion=None, depth_scale: float = 1.0, undistort: bool = True) -> None:
        """Make the picture as a real lens and depth sensor would: bent by `distortion` (OpenCV coefficients), the
        distances `depth_scale` times too long. `undistort`: straighten the pictures again as they come in, as the
        real camera's driver does with the coefficients its camera reports (False: as if it didn't)."""
        k = self.get_intrinsics()
        self.distortion = tuple(distortion) if has_distortion(distortion) else None
        self.depth_scale = float(depth_scale)
        self._distorter = Distorter(k, self.distortion) if self.distortion else None
        self._undistorter = Undistorter(k, self.distortion) if self.distortion and undistort else None
        self._view_version += 1

    def switch_depth_preset(self, name: str) -> str:
        """As OrbbecCamera.switch_depth_preset (without the waiting)."""
        old = self.depth_preset or self.wanted_preset
        if self.preset_trouble == "refuse":
            return f"The camera wouldn't take the {name} preset; it is on {old}."
        self.wanted_preset = self.depth_preset = name
        if self.preset_trouble == "restart":
            return f"Depth preset: {name} (the camera was reopened for it)."
        return f"Depth preset: {name}."

    def unbump(self) -> None:
        self.eye_position, self.target_position = self._home_view
        self._update_view()

    @property
    def is_bumped(self) -> bool:
        return (self.eye_position, self.target_position) != self._home_view

    def disconnect(self) -> None:
        pass
    def describe(self) -> dict:
        return {"name": "simulated camera", "connection": "simulated"}

    # ---- picture settings (Camera setup), as the real camera's (app/hardware/camera.py) ---------------------------
    def controls(self) -> dict:
        from app.hardware.camera_controls import FLICKER_CHOICES, Control
        c = self._controls
        return {"exposure_auto": Control("exposure_auto", "bool", c["exposure_auto"]),
                "exposure": Control("exposure", "int", c["exposure"], low=1, high=300, step=1, default=100),
                "gain": Control("gain", "int", c["gain"], low=0, high=100, step=1, default=0),
                "white_balance_auto": Control("white_balance_auto", "bool", c["white_balance_auto"]),
                "white_balance": Control("white_balance", "int", c["white_balance"], low=2800, high=6500, step=10,
                                         default=4600),
                "projector_power": Control("projector_power", "int", c["projector_power"], low=1, high=6, step=1,
                                           default=4),
                "anti_flicker": Control("anti_flicker", "choice", c["anti_flicker"], choices=dict(FLICKER_CHOICES))}

    def set_control(self, name: str, value):
        from app.hardware.camera_controls import clamp_to
        control = self.controls().get(name)
        if control is None:
            raise ValueError(f"This camera doesn't offer the {name.replace('_', ' ')} setting.")
        self._controls[name] = clamp_to(control, value)
        return self._controls[name]

    def apply_controls(self, values: dict) -> list[str]:
        from app.hardware.camera_controls import apply_order
        problems = []
        for name, value in apply_order(values):
            try:
                self.set_control(name, value)
            except Exception as exc:  # noqa: BLE001
                problems.append(str(exc))
        return problems

    def capabilities(self) -> str:
        from app.hardware.camera_controls import CONTROL_LABELS
        lines = ["simulated camera (demo)"]
        for name, control in self.controls().items():
            value = control.choices.get(control.value, control.value) if control.kind == "choice" else control.value
            lines.append(f"{CONTROL_LABELS[name]}: {value}"
                         + (f" (range {control.low}-{control.high})" if control.kind == "int" else ""))
        lines.append(f"In use: {self.width}x{self.height}, depth preset {self.depth_preset or self.wanted_preset}")
        return "\n".join(lines)

    def place(self, up_mm: float = 0.0, back_mm: float = 0.0, tilt_deg: float = 0.0) -> None:
        """Practice (demo): move the camera as a mount does, from where it was mounted -- `up_mm` higher, `back_mm`
        further back (away from what it looks at, level with the table), and tilted `tilt_deg` on the mount towards
        straight down (negative: flatter). The simulator's exact calibration follows it, so the one in use no longer
        fits -- as when the lab's camera is moved."""
        eye0, target0 = np.array(self._home_view[0], float), np.array(self._home_view[1], float)
        look = target0 - eye0
        forward = np.array([look[0], look[1], 0.0])
        forward /= np.linalg.norm(forward)
        eye = eye0 + np.array([0.0, 0.0, up_mm / 1000.0]) - forward * (back_mm / 1000.0)
        if eye[2] < 0.15:                                      # (never down at the table)
            return
        right = np.cross(look, [0.0, 0.0, 1.0])
        right /= np.linalg.norm(right)
        a = np.radians(-tilt_deg)
        k = np.array([[0, -right[2], right[1]], [right[2], 0, -right[0]], [-right[1], right[0], 0]])
        turn = np.eye(3) + np.sin(a) * k + (1 - np.cos(a)) * (k @ k)   # on the mount, about its level axis
        look = turn @ look
        if look[2] >= -0.05 * np.linalg.norm(look):             # (still looking down at the table)
            return
        self.view_up_mm, self.view_back_mm, self.view_tilt_deg = float(up_mm), float(back_mm), float(tilt_deg)
        self.eye_position = tuple(eye)
        self.target_position = tuple(eye + look)
        self._update_view()

    @staticmethod
    def _drop_edges(depth: np.ndarray, step_mm: float = 6.0, width_px: int = 4) -> np.ndarray:
        """As the High Accuracy preset does on the real camera: no depth near where it steps (the cubes' edges), only
        the points it is sure of."""
        import cv2
        d = depth.astype(np.float32)
        jump = np.zeros(d.shape, bool)
        jump[:, 1:] |= np.abs(np.diff(d, axis=1)) > step_mm
        jump[1:, :] |= np.abs(np.diff(d, axis=0)) > step_mm
        near = cv2.dilate(jump.astype(np.uint8), np.ones((2 * width_px + 1, 2 * width_px + 1), np.uint8)) > 0
        out = d.copy()
        out[near] = 0.0
        return out

    def _exposed(self, rgb: np.ndarray) -> np.ndarray:
        """The colour picture at the manual exposure and gain (automatic: as rendered -- or, practising the lab's
        trouble, brightened and hazy, the cubes' colours washed out)."""
        c = self._controls
        if c["exposure_auto"]:
            if self.washed_out:
                return np.clip(rgb.astype(np.float32) * 1.3 + 135.0, 0, 255).astype(np.uint8)   # (sat ~90: the lab's)
            return rgb
        factor = (c["exposure"] / 100.0) * (1.0 + c["gain"] / 100.0)
        if abs(factor - 1.0) < 1e-3:
            return rgb
        return np.clip(rgb.astype(np.float32) * factor, 0, 255).astype(np.uint8)

    def get_intrinsics(self) -> Intrinsics:
        if self._intrinsics is None:
            raise RuntimeError("Camera not connected. Call connect() first.")
        return self._intrinsics

    def camera_to_robot_transform(self) -> np.ndarray:
        """Exact 4x4 camera->robot transform (mm), known because we placed the camera.

        Maps points in our camera convention (x right, y down, z forward = depth) into
        the simulated robot's frame, so the demo needs no manual calibration. PyBullet's
        view matrix is column-major, world->camera, with the camera looking down -Z and
        Y up, hence the flip to the optical convention."""
        world_to_gl = np.array(self._view_matrix, dtype=np.float64).reshape(4, 4, order="F")
        gl_to_world = np.linalg.inv(world_to_gl)
        optical_to_gl = np.diag([1.0, -1.0, -1.0, 1.0])
        transform = gl_to_world @ optical_to_gl
        transform[:3, 3] *= 1000.0  # metres -> millimetres
        return transform

    def _scene_signature(self) -> tuple:
        """Where every body is and what colour it is: if this hasn't changed, neither has
        the picture. Rendering takes ~0.6 s, so a still scene must not be redrawn."""
        signature = []
        for index in range(p.getNumBodies(physicsClientId=self.client)):
            body = p.getBodyUniqueId(index, physicsClientId=self.client)
            position, orientation = p.getBasePositionAndOrientation(body, physicsClientId=self.client)
            colours = tuple(tuple(shape[7]) for shape in p.getVisualShapeData(body, physicsClientId=self.client))
            signature.append((body, position, orientation, colours))
        return tuple(signature)

    def _background(self) -> np.ndarray:
        if self._background_image is None:
            top, bottom = np.array(BACKGROUND_TOP, np.float32), np.array(BACKGROUND_BOTTOM, np.float32)
            t = np.linspace(0.0, 1.0, self.height, dtype=np.float32)[:, None, None]
            column = top + (bottom - top) * t
            self._background_image = np.repeat(column, self.width, axis=1).astype(np.uint8)
        return self._background_image

    def get_frame(self) -> Frame:
        with pybullet_lock:
            signature = (self._view_version, self._scene_signature())
            if signature == self._cached_signature and self._cached_frame is not None:
                return self._copy(self._cached_frame)   # callers may draw on their frame
            _, _, rgba, depth_buf, segmentation = p.getCameraImage(
                width=self.width, height=self.height,
                viewMatrix=self._view_matrix, projectionMatrix=self._proj_matrix,
                renderer=p.ER_TINY_RENDERER, shadow=1, lightDirection=[0.5, -0.6, 1.0],
                physicsClientId=self.client,
            )
            outlined = list(self.outline_bodies())
        rgb = np.asarray(rgba, dtype=np.uint8).reshape(self.height, self.width, 4)[:, :, :3].copy()
        depth_buf = np.asarray(depth_buf, dtype=np.float32).reshape(self.height, self.width)
        depth_m = self._far * self._near / (self._far - (self._far - self._near) * depth_buf)
        depth_mm = depth_m * 1000.0

        nothing_hit = depth_buf >= 0.99999
        rgb[nothing_hit] = self._background()[nothing_hit]   # deep navy instead of the renderer's grey
        depth_mm[nothing_hit] = 0.0                          # like a real camera: no return = no depth
        segmentation = np.asarray(segmentation, dtype=np.int32).reshape(self.height, self.width)
        rgb = self._soften_edges(self._outline(rgb, segmentation, outlined))
        if self.depth_scale != 1.0:
            depth_mm = depth_mm * np.float32(self.depth_scale)
        if self._distorter is not None:
            rgb, depth_mm = self._distorter.apply(rgb, depth_mm)
        if self._undistorter is not None:
            rgb, depth_mm = self._undistorter.apply(rgb, depth_mm)

        frame = Frame(rgb=rgb, depth=depth_mm, intrinsics=self._intrinsics)
        self._cached_signature, self._cached_frame = signature, frame
        return self._copy(frame)

    def _copy(self, frame: Frame) -> Frame:
        """A private copy (callers may draw on it), with this camera's faults applied."""
        high_accuracy = (self.depth_preset or self.wanted_preset) == "High Accuracy"
        if self.faults.is_perfect:
            depth = frame.depth.copy()
            rgb = self._exposed(frame.rgb.copy())
        else:
            rgb = self._exposed(degrade_color(frame.rgb, self.faults, self._rng))
            depth = degrade_depth(frame.depth, self.faults, self._rng)
        if high_accuracy:
            depth = self._drop_edges(depth)
        return Frame(rgb=rgb, depth=depth, intrinsics=frame.intrinsics)

    @staticmethod
    def _outline(rgb: np.ndarray, segmentation: np.ndarray, bodies: list[int]) -> np.ndarray:
        """A dark line where each arm part meets something else, like the 3D view's outlined
        links, so the arm reads clearly against the table. Drawn only on arm pixels: cubes
        and the table are left exactly as rendered, so detection is unaffected."""
        if not bodies:
            return rgb
        arm = np.isin(segmentation, bodies)
        edge = np.zeros_like(arm)
        for dy, dx in ((0, 2), (0, -2), (2, 0), (-2, 0)):
            shifted = np.roll(segmentation, (dy, dx), axis=(0, 1))
            edge |= arm & (shifted != segmentation)
        result = rgb.copy()
        result[edge] = OUTLINE_RGB
        return result

    @staticmethod
    def _soften_edges(rgb: np.ndarray) -> np.ndarray:
        """Cheap anti-aliasing: blur only along strong edges (object outlines), leaving the
        faint table grid and flat areas sharp. The renderer has no anti-aliasing of its own."""
        edges = cv2.Canny(cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY), 60, 150)
        edges = cv2.dilate(edges, np.ones((3, 3), np.uint8)) > 0
        blurred = cv2.GaussianBlur(rgb, (0, 0), 0.9)
        result = rgb.copy()
        result[edges] = blurred[edges]
        return result

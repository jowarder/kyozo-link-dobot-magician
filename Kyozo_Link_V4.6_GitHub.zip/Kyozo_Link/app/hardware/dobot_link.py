"""A sturdier serial link than stock pydobot 1.3.2.

Problems seen on real hardware with stock `pydobot.Dobot`:
- It reads each reply after a fixed 0.1 s sleep and takes whatever bytes have arrived.
  On a slower USB-serial bridge (e.g. CP210x) that is a partial or empty reply, so
  init crashes with "index out of range" or "'NoneType' object has no attribute 'params'".
- When __init__ fails after opening the port, the handle is never closed, so the next
  attempt fails with a Windows "Access is denied".

- Its checksum is wrong for 2 sums in 256 (`% 255` where it must be `% 256`, marked "TODO verify this"): the
  Dobot drops such a message without a word. A move whose bytes happen to sum so went unanswered every time it was
  sent -- the same target, retries, Clear Alarms and all (the lab, 22 times in five days; found 2026-10-21 from the
  bytes logged: both moves unanswered that night summed to 0 and 1, sent with checksums 1 and 0).

This subclass sends every message with a right checksum, waits for a complete framed reply, drops stale bytes
before each request, and closes the port if init fails.
"""
from __future__ import annotations

import logging
import struct
import time

import pydobot
import pydobot.dobot as _pydobot_module
import serial as _real_serial
from pydobot.message import Message

from app.hardware.dobot_discovery import open_dobot_serial

logger = logging.getLogger(__name__)

REPLY_TIMEOUT_S = 1.5
QUEUED = 0x02          # a message's ctrl bit: a queued command (a move), never sent twice


def frame_bytes(msg) -> bytes:
    """`msg` as the Dobot takes it: AA AA, length, id, ctrl, params, and a checksum that makes id + ctrl + params +
    checksum a multiple of 256 (pydobot's own bytes() gets it wrong when they sum to 0 or 1, see above)."""
    msg.refresh()                                       # (its id and ctrl as plain numbers)
    params = bytes(msg.params)
    body = bytes([int(msg.id) & 0xFF, int(msg.ctrl) & 0xFF]) + params
    return bytes([0xAA, 0xAA, len(body)]) + body + bytes([(-sum(body)) & 0xFF])
WAIT_TIMEOUT_S = 90.0   # pydobot itself waits for a move forever


class _SerialWithDtrLow:
    """Stands in for the `serial` module inside pydobot.dobot so its Serial(...) call
    opens the port with DTR/RTS low (see open_dobot_serial). Everything else
    (PARITY_NONE, etc.) passes through to the real module."""

    @staticmethod
    def Serial(port, **settings):
        return open_dobot_serial(port, **settings)

    def __getattr__(self, name):
        return getattr(_real_serial, name)


_pydobot_module.serial = _SerialWithDtrLow()


class RobustDobot(pydobot.Dobot):
    link_lost = ""          # why the serial port stopped working, once it has ("" while it works)

    def __init__(self, port, verbose=False):
        try:
            super().__init__(port, verbose)
        except Exception:
            ser = getattr(self, "ser", None)
            if ser is not None and ser.is_open:
                ser.close()
            raise

    def _send_command(self, msg, wait=False):
        """pydobot's version releases its lock only after a successful exchange, so one serial
        error (a cable knocked out) leaves it held and every later call hangs. Here the lock is
        always released; and if asked to wait for a move, gives up after WAIT_TIMEOUT_S. A port that has gone (the
        Dobot switched off or unplugged: "ClearCommError failed (PermissionError(13, 'Access is denied.'))", study 2,
        S-08 and S-09) is remembered in `link_lost`: nothing sent on it can arrive, and a Dobot switched off and on
        has lost its homing -- DobotRobot refuses every move until Reconnect and Home."""
        if self.link_lost:
            raise ConnectionError(f"The Dobot's USB link was lost earlier ({self.link_lost}).")
        try:
            with self.lock:
                self._send_message(msg)
                response = self._read_message()
                ctrl = getattr(msg, "ctrl", 0)
                if response is None and not (int(getattr(ctrl, "value", ctrl) or 0) & QUEUED):
                    # a request that only reads (where the arm is, its alarms) is asked once more; a queued command
                    # never is -- sent twice, the arm would do it twice
                    logger.warning("No answer from the Dobot to id %s; asking once more",
                                   getattr(msg.id, "value", msg.id))
                    self._send_message(msg)
                    response = self._read_message()
        except _real_serial.SerialException as exc:
            self.link_lost = str(exc)[:160] or type(exc).__name__
            logger.error("The Dobot's USB link was lost: %s", self.link_lost)
            raise ConnectionError(f"The Dobot's USB link was lost ({self.link_lost}).") from exc
        if not wait:                                    # (None: no answer -- each caller says what that means)
            return response
        expected = struct.unpack_from("<I", response.params, 0)[0]
        deadline = time.monotonic() + WAIT_TIMEOUT_S
        while self._get_queued_cmd_current_index() < expected:
            if time.monotonic() > deadline:
                raise TimeoutError(f"The robot did not finish command {expected} within {WAIT_TIMEOUT_S:.0f} s.")
            time.sleep(0.1)
        return response

    def _send_message(self, msg):
        # A late reply to an earlier request must not be mistaken for this one's -- but it is said, in the log: a
        # reply that comes after REPLY_TIMEOUT_S (or one nobody asked for) is what "no answer" may really be
        waiting = self.ser.in_waiting
        if waiting:
            stale = self.ser.read(waiting)
            logger.warning("%d bytes from the Dobot nobody was waiting for, dropped before sending id %s: %s",
                           len(stale), getattr(msg.id, "value", msg.id), stale.hex(" "))
        self.ser.reset_input_buffer()
        time.sleep(0.1)                                 # (as pydobot's own: the Dobot takes a moment between)
        self.ser.write(frame_bytes(msg))

    def _read_message(self):
        # Frame: AA AA <len> <id> <ctrl> <params...> <checksum>; total = len + 4 bytes.
        deadline = time.monotonic() + REPLY_TIMEOUT_S
        buf = bytearray()
        while time.monotonic() < deadline:
            waiting = self.ser.in_waiting
            if waiting:
                buf.extend(self.ser.read(waiting))
            start = buf.find(b"\xaa\xaa")
            if start >= 0 and len(buf) >= start + 3:
                total = buf[start + 2] + 4
                if len(buf) >= start + total:
                    msg = Message(bytes(buf[start:start + total]))
                    if self.verbose:
                        print("pydobot: <<", msg)
                    return msg
            time.sleep(0.01)
        return None

"""The real UFACTORY xArm 6 with the xArm Gripper, over the network through UFACTORY's own SDK (xarm-python-sdk).

The app's poses are the same as the Dobot's: x, y, z of the tool point (between the fingertips, TCP_OFFSET_MM below
the arm's flange) in the arm's base frame, mm, the tool pointing straight down, and its turn r about the vertical in
degrees. For the xArm that is the pose (x, y, z, roll 180, pitch 0, yaw r): roll 180 turns the tool to point down,
and yaw is then the tool's turn (twin/xarm6/model.py draws it the same way).

Safety: the speed is capped (MAX_SPEED_MM_S), the controller's collision detection is on (its sensitivity is a
setting), the app's own safety box and reach limits are kept, and E-STOP stops the arm at once (the controller's
emergency stop) and opens the gripper.
"""
from __future__ import annotations

import logging
import math
import threading
from typing import Optional

from app.hardware.interfaces import OutOfReach, Pose, Robot, RobotAlarm, RobotStopped
from app.hardware.tool_centre import ToolCentre

XArmAPI = None   # UFACTORY's SDK, loaded when an xArm is made (it prints its version as it loads: not for the Dobot)


def _sdk():
    global XArmAPI
    if XArmAPI is None:
        try:
            from xarm.wrapper import XArmAPI as api
        except Exception:  # noqa: BLE001 - the SDK isn't installed: live mode with the xArm says so
            return None
        XArmAPI = api
    return XArmAPI

logger = logging.getLogger(__name__)

MAX_SPEED_MM_S = 250.0           # never faster than this, whatever is asked (the arm can do 1000)
DEFAULT_SPEED_MM_S = 100.0
ACCELERATION_MM_S2 = 500.0
TCP_OFFSET_MM = 172.0            # the xArm Gripper's tool point below the flange (UFACTORY's own figure)
GRIPPER_OPEN = 850               # the SDK's gripper positions: 850 fully open (about 85 mm), 0 closed
GRIPPER_CLOSED = 0
OPEN_STROKE_MM = 86.0           # the gap fully open (manual v1.6.1)
DEFAULT_GRIPPER_SPEED = 2000     # r/min of the gripper's motor (1000-5000)
DEFAULT_COLLISION_SENSITIVITY = 3    # 0 (off) to 5 (most sensitive)
MIN_RADIUS_MM = 200.0            # nearer its base the gripper would come down onto the arm's own base
DEFAULT_MAX_REACH_MM = 650.0
REACH_ERRORS = {21: "it can't be reached that way (kinematics)", 22: "the arm would hit itself",
                23: "a joint would pass its limit", 25: "the move couldn't be planned",
                35: "it is outside the controller's safety boundary",
                40: "no joint path without errors"}
COLLISION_ERRORS = {31: "it ran into something (collision detected)"}
STOP_ERRORS = {1: "the emergency stop button on the control box is pressed in",
               2: "the control box's emergency input was triggered",
               3: "the emergency stop of the enabling switch was pressed"}


def gripper_position(gap_mm: float) -> float:
    """The SDK's gripper position for a gap between the fingertips (mm): 0 closed to 850 open, the 86 mm stroke of
    the manual taken as even along it. (Check it once on the real gripper: open it to 500 and measure the gap.)"""
    return max(GRIPPER_CLOSED, min(GRIPPER_OPEN, gap_mm / OPEN_STROKE_MM * GRIPPER_OPEN))


class XArmRobot(ToolCentre, Robot):
    def __init__(self, ip: str, workspace_bounds: dict, max_speed: float = DEFAULT_SPEED_MM_S,
                 max_reach_mm: float = DEFAULT_MAX_REACH_MM, tcp_offset_mm: float = TCP_OFFSET_MM,
                 gripper_speed: int = DEFAULT_GRIPPER_SPEED,
                 collision_sensitivity: int = DEFAULT_COLLISION_SENSITIVITY,
                 min_radius_mm: float = MIN_RADIUS_MM, opening_mm: float = 40.0):
        if _sdk() is None:
            raise RuntimeError("The xArm SDK is not installed. Run `pip install xarm-python-sdk` to control the xArm.")
        if not ip:
            raise ValueError("No IP address for the xArm's control box: set xarm6.ip in config.yaml (the address "
                             "UFACTORY Studio connects to, e.g. 192.168.1.185).")
        self.ip = ip
        self.bounds = workspace_bounds
        self.max_speed = min(float(max_speed), MAX_SPEED_MM_S)
        self.max_reach_mm = max_reach_mm
        self.tcp_offset_mm = float(tcp_offset_mm)
        self.gripper_speed = int(gripper_speed)
        self.collision_sensitivity = int(collision_sensitivity)
        self.min_radius_mm = min_radius_mm
        self.gripper_type = "gripper"
        self.opening_mm = float(opening_mm)    # how far it opens to pick and let go (the full 86 mm is too wide)
        self._arm = None
        self._estopped = False
        self._gripper_closed: Optional[bool] = None
        self._lock = threading.Lock()

    # ---- connection ---------------------------------------------------------------------------
    def connect(self) -> None:
        logger.info("Connecting to the xArm at %s", self.ip)
        arm = XArmAPI(self.ip, is_radian=False, do_not_open=True)
        arm.connect()
        if not arm.connected:
            raise ConnectionError(f"No xArm answered at {self.ip}. Is the control box on, the network cable in, "
                                  "and this computer on the same network (UFACTORY Studio can tell)?")
        self._arm = arm
        self._estopped = False
        if arm.error_code in STOP_ERRORS:
            logger.warning("xArm: %s", STOP_ERRORS[arm.error_code])
        self._ready()
        arm.set_tcp_offset([0.0, 0.0, self.tcp_offset_mm, 0.0, 0.0, 0.0], wait=True)
        arm.set_collision_sensitivity(self.collision_sensitivity, wait=True)
        arm.set_gripper_enable(True)
        arm.set_gripper_mode(0)
        arm.set_gripper_speed(self.gripper_speed)
        logger.info("xArm connected (version %s, serial %s)", getattr(arm, "version", "?"), getattr(arm, "sn", "?"))

    def _ready(self) -> None:
        """Errors cleared, motors on, position mode, ready to move (as UFACTORY's examples start)."""
        arm = self._arm
        arm.clean_warn()
        arm.clean_error()
        arm.motion_enable(enable=True)
        arm.set_mode(0)
        arm.set_state(0)

    def disconnect(self) -> None:
        arm, self._arm = self._arm, None
        if arm is not None:
            try:
                arm.disconnect()
            except Exception:  # noqa: BLE001
                logger.warning("xArm: disconnect failed", exc_info=True)

    def _check(self, motion: bool = True):
        if self._arm is None:
            raise RuntimeError("Robot not connected. Call connect() first.")
        if motion and self._estopped:
            raise RobotStopped("Robot is E-stopped. Reset it (Clear errors / Reset after E-STOP) first.")
        return self._arm

    # ---- status buttons (the Manual tab) --------------------------------------------------------
    def enable_motors(self) -> None:
        arm = self._check(motion=False)
        arm.motion_enable(enable=True)
        arm.set_mode(0)
        arm.set_state(0)

    def clear_errors(self) -> None:
        self._check(motion=False)
        self._ready()

    def clear_alarms(self) -> None:
        self.clear_errors()

    def get_alarms(self) -> list[int]:
        arm = self._check(motion=False)
        return [arm.error_code] if arm.error_code else []

    def describe_error(self) -> str:
        """The controller's error now, in words ("" if none)."""
        if self._arm is None or not self._arm.error_code:
            return ""
        code = self._arm.error_code
        words = {**REACH_ERRORS, **COLLISION_ERRORS, **STOP_ERRORS}.get(code)
        return f"C{code}: {words}" if words else f"controller error C{code}"

    def set_collision_sensitivity(self, value: int) -> None:
        arm = self._check(motion=False)
        self.collision_sensitivity = max(0, min(5, int(value)))
        arm.set_collision_sensitivity(self.collision_sensitivity, wait=True)

    def set_speed(self, mm_per_s: float) -> None:
        self.max_speed = min(max(float(mm_per_s), 5.0), MAX_SPEED_MM_S)

    # ---- where it is ----------------------------------------------------------------------------
    def _get_pose_raw(self) -> Pose:
        arm = self._check(motion=False)
        code, position = arm.get_position(is_radian=False)
        if code != 0 or not position:
            raise RuntimeError(f"The xArm didn't say where it is (code {code}).")
        x, y, z, _roll, _pitch, yaw = (float(v) for v in position[:6])
        return Pose(x=x, y=y, z=z, r=yaw)

    def get_joints(self) -> tuple:
        arm = self._check(motion=False)
        code, angles = arm.get_servo_angle(is_radian=False)
        if code != 0 or not angles:
            return ()
        return tuple(float(a) for a in angles[:6])

    # ---- moving ---------------------------------------------------------------------------------
    def _clamp_to_bounds(self, pose: Pose) -> Pose:
        x = min(max(pose.x, self.bounds["x"][0]), self.bounds["x"][1])
        y = min(max(pose.y, self.bounds["y"][0]), self.bounds["y"][1])
        z = min(max(pose.z, self.bounds["z"][0]), self.bounds["z"][1])
        radius = math.hypot(x, y)
        if radius <= 1e-6:
            x, y = self.min_radius_mm, 0.0
        elif radius < self.min_radius_mm:
            x, y = x * self.min_radius_mm / radius, y * self.min_radius_mm / radius
        elif radius > self.max_reach_mm:
            x, y = x * self.max_reach_mm / radius, y * self.max_reach_mm / radius
        clamped = Pose(x=x, y=y, z=z, r=pose.r)
        if (clamped.x, clamped.y, clamped.z) != (pose.x, pose.y, pose.z):
            logger.warning("Pose %s clamped to workspace bounds/reach -> %s", pose, clamped)
        return clamped

    def _clamp_raw(self, pose: Pose) -> Pose:
        return self._clamp_to_bounds(pose)

    def home(self) -> None:
        self.move_to(Pose(x=300.0, y=0.0, z=250.0, r=0.0))

    def _move_to_raw(self, pose: Pose, speed: Optional[float] = None) -> None:
        arm = self._check()
        target = self._clamp_to_bounds(pose)
        yaw = (target.r + 180.0) % 360.0 - 180.0
        velocity = min(float(speed or self.max_speed), self.max_speed, MAX_SPEED_MM_S)
        code = arm.set_position(x=target.x, y=target.y, z=target.z, roll=180.0, pitch=0.0, yaw=yaw,
                                speed=velocity, mvacc=ACCELERATION_MM_S2, wait=True)
        if self._estopped:
            raise RobotStopped("Robot was E-stopped during the move.")
        if code != 0 or arm.error_code:
            self._raise_for_error(code, target)

    def _raise_for_error(self, code: int, target: Pose) -> None:
        arm = self._arm
        error = arm.error_code if arm is not None else 0
        where = f"({target.x:.0f}, {target.y:.0f}, {target.z:.0f})"
        if error in REACH_ERRORS:
            # stopped where it still could be: cleared at once, so it can be sent somewhere else (as the Dobot's)
            try:
                self._ready()
            except Exception:  # noqa: BLE001
                logger.warning("xArm: couldn't clear the error", exc_info=True)
            raise OutOfReach(f"The arm stopped before {where}: {REACH_ERRORS[error]} (C{error}).")
        if error in COLLISION_ERRORS:
            raise RobotAlarm(f"The arm stopped on the way to {where}: {COLLISION_ERRORS[error]} (C{error}). "
                             "Check what it touched, then Clear errors.")
        if error in STOP_ERRORS:
            self._estopped = True
            raise RobotStopped(f"The arm is stopped: {STOP_ERRORS[error]} (C{error}).")
        if error:
            raise RobotAlarm(f"The arm stopped on the way to {where}: controller error C{error}. Clear errors to go on.")
        raise RobotAlarm(f"The xArm refused the move to {where} (code {code}).")

    def jog(self, dx: float, dy: float, dz: float) -> None:
        current = self.get_pose()
        self.move_to(Pose(x=current.x + dx, y=current.y + dy, z=current.z + dz, r=current.r))

    # ---- the gripper ----------------------------------------------------------------------------
    def open_gripper(self) -> None:
        self.set_gripper_opening(gripper_position(self.opening_mm), motion=False)
        self._gripper_closed = False

    def close_gripper(self) -> None:
        self.set_gripper_opening(GRIPPER_CLOSED)
        self._gripper_closed = True

    def set_gripper_opening(self, position: float, motion: bool = True) -> None:
        """The fingers to `position` (the SDK's units: 0 closed to 850 fully open, about a tenth of a mm each).
        Opening is allowed after an E-STOP: letting go is not motion."""
        arm = self._check(motion=motion)
        position = max(GRIPPER_CLOSED, min(GRIPPER_OPEN, float(position)))
        code = arm.set_gripper_position(position, wait=True, speed=self.gripper_speed, auto_enable=True)
        if code != 0:
            raise RobotAlarm(f"The gripper didn't move (code {code}, gripper error {arm.get_gripper_err_code()}).")
        self._gripper_closed = position < GRIPPER_OPEN

    def set_gripper_speed(self, speed: int) -> None:
        arm = self._check(motion=False)
        self.gripper_speed = max(1000, min(5000, int(speed)))
        arm.set_gripper_speed(self.gripper_speed)

    def gripper_opening(self) -> Optional[float]:
        arm = self._check(motion=False)
        code, position = arm.get_gripper_position()
        return float(position) if code == 0 and position is not None else None

    # ---- E-STOP ---------------------------------------------------------------------------------
    def stop(self) -> None:
        logger.critical("E-STOP triggered on the xArm")
        self._estopped = True
        arm = self._arm
        if arm is None:
            return
        try:
            arm.set_state(4)            # stop now: the move in progress is dropped
        except Exception:  # noqa: BLE001
            logger.exception("Failed to stop the xArm during E-stop")
        try:
            arm.set_gripper_position(GRIPPER_OPEN, wait=False, auto_enable=True)
            self._gripper_closed = False
        except Exception:  # noqa: BLE001 - best effort
            logger.exception("Failed to open the gripper during E-stop")

    def reset_estop(self) -> None:
        self._estopped = False
        if self._arm is not None:
            self._ready()

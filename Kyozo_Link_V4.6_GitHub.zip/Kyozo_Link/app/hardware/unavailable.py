"""Stand-in Robot/Camera used when the real backend fails to construct (e.g. missing SDK).

Keeps the rest of the app (UI panels that expect a Robot/Camera instance) from
crashing at startup; every method raises a clear error describing what's
missing, so failures surface as status-bar/log messages instead of an
unhandled traceback that kills the whole app.
"""
from __future__ import annotations

from typing import Optional

from app.hardware.interfaces import Camera, Frame, Intrinsics, Pose, Robot


class UnavailableRobot(Robot):
    def __init__(self, reason: str):
        self.reason = reason

    def _raise(self) -> None:
        raise RuntimeError(f"Robot unavailable: {self.reason}")

    def connect(self) -> None:
        self._raise()

    def disconnect(self) -> None:
        pass

    def home(self) -> None:
        self._raise()

    def get_pose(self) -> Pose:
        self._raise()

    def move_to(self, pose: Pose, speed: Optional[float] = None) -> None:
        self._raise()

    def jog(self, dx: float, dy: float, dz: float) -> None:
        self._raise()

    def open_gripper(self) -> None:
        self._raise()

    def close_gripper(self) -> None:
        self._raise()

    def stop(self) -> None:
        pass


class UnavailableCamera(Camera):
    def __init__(self, reason: str):
        self.reason = reason

    def _raise(self) -> None:
        raise RuntimeError(f"Camera unavailable: {self.reason}")

    def connect(self) -> None:
        self._raise()

    def disconnect(self) -> None:
        pass

    def get_frame(self) -> Frame:
        self._raise()

    def get_intrinsics(self) -> Intrinsics:
        self._raise()

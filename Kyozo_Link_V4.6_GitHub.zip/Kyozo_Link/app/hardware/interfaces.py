"""Abstract hardware interfaces shared by live and simulated backends."""
from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np


@dataclass
class Pose:
    x: float  # mm
    y: float  # mm
    z: float  # mm
    r: float = 0.0  # end-effector rotation, degrees


@dataclass
class Intrinsics:
    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int


@dataclass
class Frame:
    rgb: np.ndarray               # HxWx3 uint8
    depth: Optional[np.ndarray]   # HxW float32, millimeters, or None
    intrinsics: Intrinsics


class RobotStopped(RuntimeError):
    """A motion was refused, or cut short, because the robot was E-stopped. Whoever is running a
    sequence of moves (a prompt, a calibration) should stop, not carry on."""


class RobotAlarm(RuntimeError):
    """The robot's own controller raised an alarm (e.g. it was asked to reach somewhere it can't)."""


class RobotNeedsPerson(RobotAlarm):
    """The arm can't go on until a person does something -- Home it after it was (re)connected, Reconnect after its
    USB link was lost, power-cycle it after an alarm that won't clear. Every move is refused until then: not something
    to try again or work round (study 2, S-08_Run1: after a power cycle and Reconnect, with no Home, the arm took
    itself to be 64 degrees round from where it was and swept two cubes off the table)."""


class OutOfReach(RobotAlarm):
    """The arm stopped because a joint would have gone past its limit on the way to the target
    (too near the base, or too low or high there). It is stopped in a reachable place and the alarm
    has already been cleared, so it can be sent somewhere else straight away."""


class Robot(ABC):
    """Common interface implemented by both the real Dobot and the simulated twin."""

    @abstractmethod
    def connect(self) -> None: ...

    @abstractmethod
    def disconnect(self) -> None: ...

    @abstractmethod
    def home(self) -> None: ...

    @abstractmethod
    def get_pose(self) -> Pose: ...

    @abstractmethod
    def move_to(self, pose: Pose, speed: Optional[float] = None) -> None:
        """Move the end effector to an absolute pose in the robot base frame (mm)."""

    @abstractmethod
    def jog(self, dx: float, dy: float, dz: float) -> None:
        """Relative move by (dx, dy, dz) mm from the current pose."""

    @abstractmethod
    def open_gripper(self) -> None: ...

    @abstractmethod
    def close_gripper(self) -> None: ...

    @abstractmethod
    def stop(self) -> None:
        """Emergency stop: halt motion immediately and release the gripper."""

    def set_speed(self, mm_per_s: float) -> None:
        """How fast later moves go (mm/s). The simulator just uses it; the real arm is told."""
        self.max_speed = float(mm_per_s)

    # -- what the study's watcher listens to ---------------------------------------------------------------------------
    def add_watcher(self, callback: Callable[[dict], None]) -> None:
        """`callback(event)` for every move, gripper command, controller alarm, clamp and E-STOP, as it happens (the
        watcher records them). An event is a dict with "kind" and "t" (time.time()) and the details."""
        self.__dict__.setdefault("_watchers", []).append(callback)

    def remove_watcher(self, callback: Callable[[dict], None]) -> None:
        watchers = self.__dict__.get("_watchers", [])
        if callback in watchers:
            watchers.remove(callback)

    def _emit(self, kind: str, **details) -> None:
        """Tells the watchers. Never raises: a watcher that fails must not stop the robot."""
        for callback in list(self.__dict__.get("_watchers", ())):
            try:
                callback(dict(details, kind=kind, t=time.time()))
            except Exception:  # noqa: BLE001
                logging.getLogger(__name__).debug("A robot watcher failed on %s", kind, exc_info=True)


class Camera(ABC):
    """Common interface implemented by both the real Orbbec camera and the simulated twin."""

    @abstractmethod
    def connect(self) -> None: ...

    @abstractmethod
    def disconnect(self) -> None: ...

    @abstractmethod
    def get_frame(self) -> Frame: ...

    @abstractmethod
    def get_intrinsics(self) -> Intrinsics: ...

"""pydobot-backed implementation of the Robot interface for the real Dobot Magician.

NOTE: verified against pydobot 1.3.2 during hardware bring-up. That version's
`Dobot` class has no `.home()` or `.stop()` despite matching common examples
online -- `dobot_protocol.py` implements those via the raw serial protocol
instead. Re-verify if you're on a different pydobot version.
"""
from __future__ import annotations

import gc
import logging
import math
import threading
import time
from typing import Optional

from app.calibration.guidance import MIN_RADIUS_MM
from app.hardware import dobot_arm, dobot_discovery, dobot_protocol
from app.hardware.interfaces import OutOfReach, Pose, Robot, RobotAlarm, RobotNeedsPerson, RobotStopped
from app.hardware.tool_centre import ToolCentre
from app.hardware.motion import passes_near_base  # noqa: F401  (also used by the tests from here)

logger = logging.getLogger(__name__)

try:
    import pydobot
except ImportError:  # pragma: no cover - optional dependency until hardware bring-up
    pydobot = None

# Dobot Magician's official max horizontal reach is ~320mm from the base column.
# Axis-aligned X/Y bounds alone can't express this -- a box that's individually
# safe on each axis (e.g. x:[-300,307], y:[-300,300]) still permits diagonal
# targets like (250,250) at ~353mm, well past what the arm can physically
# reach. Commanding an unreachable target is what triggered a motor stall
# alarm during testing. This radius cap is enforced in addition to the box.
DEFAULT_MAX_REACH_MM = 300.0

DEFAULT_GRIPPER_SETTLE_S = 0.8   # pause after the gripper command, for the air to build up / drain
DEFAULT_ACCELERATION_MM_S2 = 200.0
MOVE_TIMEOUT_S = 90.0      # a single move that takes longer than this has gone wrong
INDEX_POLL_S = 0.1
ALARM_CHECK_AFTER_S = 2.0   # don't look for alarms during the first moments of a move
ALARM_CHECK_EVERY_S = 1.0
MAX_POLL_FAILURES = 5      # consecutive unanswered status requests before giving up on a move
# A finished move that ends further than this from where it was sent was cut short. The controller
# reports the commanded position to a fraction of a millimetre when a move really completes.
ARRIVED_WITHIN_MM = 5.0
# Inverse-kinematics alarms (planning 0x10-0x12, during motion 0x20-0x22): "a joint would pass its
# limit". The arm is stopped where it still could be, and the alarm is safe to clear.
REACH_ALARMS = frozenset({0x10, 0x11, 0x12, 0x20, 0x21, 0x22})
# What the arrival check of a move read (no alarm, the arm where it was sent) stands this long, while nothing has
# moved the arm, been cleared or stopped since: the next move's "any alarm left over?" and the move record's
# before-and-after readings use it instead of asking the Dobot again. Each status request costs about 0.13 s on
# the serial link (its 0.1 s pause before every message), and study 1's Dobot runs spent 0.55-0.93 s before every
# move on six of them (S-01 Run 1's move_object: 13 moves, about 9 s). The check after every move is not skipped.
SETTLED_FOR_S = 2.0

# Why the arm can't go on until a person acts (DobotRobot.needs_person; every move refused meanwhile: RobotNeedsPerson)
NOT_HOMED = ("The Dobot hasn't been homed since it was connected: switched on, it only guesses where its arm is, so a "
             "move could go somewhere else entirely. Press Home with the area clear, then try again.")
LINK_LOST = ("The Dobot's USB link was lost ({why}): it was switched off, unplugged or reset. Switch it on, press "
             "Reconnect Robot, then Home with the area clear, then try again.")


def _pose_dict(pose: Optional[Pose]) -> Optional[dict]:
    if pose is None:
        return None
    return {"x": round(pose.x, 2), "y": round(pose.y, 2), "z": round(pose.z, 2), "r": round(pose.r, 2)}


def alarm_codes(flags: list[int]) -> list[int]:
    """The controller's alarm state is a row of bytes, one bit per alarm: alarm code = byte * 8 + bit."""
    return [index * 8 + bit for index, byte in enumerate(flags) for bit in range(8) if byte >> bit & 1]


class DobotRobot(ToolCentre, Robot):
    def __init__(self, port: str, workspace_bounds: dict, max_speed: float = 100.0,
                 gripper_type: str = "suction", max_reach_mm: float = DEFAULT_MAX_REACH_MM,
                 legacy_wait: bool = False, gripper_settle_s: float = DEFAULT_GRIPPER_SETTLE_S):
        """legacy_wait: wait for moves the way pydobot does (its own loop, under the lock). Only a fallback
        in case the controller doesn't behave as the queue-index wait expects; with it, E-STOP can't
        interrupt a move in progress. Set robot.legacy_move_wait: true in config.yaml."""
        if pydobot is None:
            raise RuntimeError(
                "pydobot is not installed. Run `pip install pydobot` to control real hardware."
            )
        self.port = port
        self.bounds = workspace_bounds  # {"x": [min, max], "y": [...], "z": [...]}
        self.max_speed = max_speed
        self.gripper_type = gripper_type
        self.max_reach_mm = max_reach_mm
        self.legacy_wait = legacy_wait
        self.gripper_settle_s = max(0.0, float(gripper_settle_s))
        self._device = None
        self._lock = threading.Lock()         # one serial exchange at a time (short)
        self._motion_lock = threading.Lock()  # one move at a time (long); nothing else waits on it
        self._stop_lock = threading.Lock()
        self._estopped = False
        self._settled: Optional[tuple] = None   # (time.monotonic(), pydobot pose reading) of the last arrival check
        self._gripper_closed: Optional[bool] = None   # unknown until the first command
        # Homed since the app connected? Switched on, the Dobot only guesses where its arm is; until it is homed its
        # coordinates can be off by centimetres (the lab: the table read 54 mm higher, the arm's joints ~8 degrees out)
        self.homed = False
        self.homed_at: Optional[float] = None       # time.monotonic() of the last homing
        self._held_up: Optional[str] = None         # why every move is refused until a person acts (see needs_person)
        self.controller_z = True    # its poses are the controller's own (dobot_arm judges them as they are)

    @property
    def needs_person(self) -> Optional[str]:
        """Why the arm can't go on until a person acts, or None: not homed since it was connected (study 2, S-08_Run1:
        power-cycled and reconnected mid-task, not homed, every move went ~64 degrees round from where it was sent and
        two cubes went off the table), its USB link lost, or an alarm that won't clear. Every move is refused
        meanwhile (Home, Clear Alarms and opening the gripper aren't); the prompt that meets it stops, and the
        watcher waits for a person."""
        device = self._device
        lost = getattr(device, "link_lost", "") if device is not None else ""
        if lost:
            return LINK_LOST.format(why=lost)
        if self._device is not None and not self.homed:
            return NOT_HOMED
        return self._held_up

    def hold_for_person(self, why: str) -> None:
        """Every move refused (needs_person) until a person has put something right and pressed Home: what the arm
        can't sense, the app saw (a cube let go of, not on the table: still in the fingers?)."""
        logger.warning("The arm waits for a person: %s", why)
        self._held_up = why
        self._emit("needs_person", why=why)

    def connect(self) -> None:
        logger.info("Looking for a Dobot (configured port: %s)", self.port)
        found, report = dobot_discovery.find_dobot_ports(self.port)
        for line in report:
            logger.info("  port scan: %s", line)
        if not found:
            raise ConnectionError("No Dobot responded on any serial port. " + "; ".join(report))
        if len(found) > 1:
            logger.warning("Multiple Dobots responded on %s; using %s. Unplug the others "
                            "to control a specific one.", found, found[0])
        if found[0] != self.port:
            logger.warning("Dobot found on %s instead of configured %s", found[0], self.port)
        self.port = found[0]

        logger.info("Connecting to Dobot Magician on %s", self.port)
        self._device = self._connect_with_retry()
        self._estopped, self._settled = False, None
        self.homed, self.homed_at, self._held_up = False, None, None     # (needs_person: Home first)
        self._apply_speed()

    def _apply_speed(self, strict: bool = False) -> None:
        """`max_speed` in config.yaml (mm/s) used to be ignored: the arm ran at the firmware default. Straight-line
        moves use the "coordinate" speed, so that is what is set. At connect a failure is only logged (not worth
        refusing to work for); when the user changes the speed (`strict`) it is reported."""
        speed = min(max(float(self.max_speed), 5.0), 500.0)
        try:
            with self._lock:
                self._device._set_ptp_coordinate_params(velocity=speed, acceleration=DEFAULT_ACCELERATION_MM_S2)
            logger.info("Move speed set to %.0f mm/s", speed)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not set the move speed (the arm keeps its default): %s", exc)
            if strict:
                raise RuntimeError(f"The robot did not accept the new speed: {exc}") from exc

    def set_pace(self, percent: float, acceleration: Optional[float] = None) -> Optional[tuple[float, float]]:
        """Every move, swings round the base included, at `percent` of its speed (and of its acceleration, unless
        given); returns the (speed, acceleration) percents it was at, to put back, or None -- nothing changed -- if
        the controller didn't say. (Calibrating, the arm goes slower: its motors skip a step less easily, and a
        skipped step moves every coordinate after it.)"""
        self._check_connection(motion=False)
        with self._lock:
            before = dobot_protocol.get_ptp_common_params(self._device)
            if before is None:
                return None
            if getattr(self, "_usual_pace", None) is None:
                self._usual_pace = (float(before[0]), float(before[1]))   # (what it was before anything slowed it)
            dobot_protocol.set_ptp_common_params(self._device, float(percent),
                                                 float(percent if acceleration is None else acceleration))
            self._pace_now = (float(percent), float(percent if acceleration is None else acceleration))
        logger.info("Moves at %.0f%% of their speed (they were at %.0f%%)", percent, before[0])
        return float(before[0]), float(before[1])

    def set_speed(self, mm_per_s: float) -> None:
        """Takes effect from the next move (the setting is queued behind any move in progress)."""
        self._check_connection(motion=False)
        previous, self.max_speed = self.max_speed, float(mm_per_s)
        try:
            self._apply_speed(strict=True)
        except Exception:
            self.max_speed = previous
            raise

    def _connect_with_retry(self, retries: int = 5, delay: float = 3.0):
        """Retries with a longer delay than you'd expect: right after the Dobot is
        powered on, its firmware isn't ready to respond yet, so an immediate
        connect attempt fails deep inside pydobot's init with a confusing
        'NoneType has no attribute params' error. Worse, that failed attempt
        leaks its serial port handle (pydobot doesn't clean up on a failed
        init), so the next attempt can hit a Windows PermissionError until the
        OS releases it -- gc.collect() encourages that to happen promptly."""
        last_exc = None
        for attempt in range(1, retries + 1):
            try:
                from app.hardware.dobot_link import RobustDobot
                return RobustDobot(port=self.port)
            except Exception as exc:  # noqa: BLE001 - surface any serial error
                last_exc = exc
                logger.warning("Dobot connect attempt %d/%d failed: %s", attempt, retries, exc)
                gc.collect()  # encourage release of a leaked serial handle from the failed attempt
                time.sleep(delay)
        raise ConnectionError(f"Could not connect to Dobot on {self.port}") from last_exc

    def disconnect(self) -> None:
        self._settled = None
        with self._lock:
            device, self._device = self._device, None
            if device is not None:
                device.close()

    def _check_connection(self, motion: bool = True, recovering: bool = False) -> None:
        """`motion=False` for things that only look (position, alarms): those still work after an
        E-STOP, which is when you most want to see where the arm ended up. `recovering`: Home and Clear Alarms, what
        a person does to put the arm right -- allowed while it needs a person; every other move isn't."""
        if self._device is None:
            raise RuntimeError("Robot not connected. Call connect() first.")
        if motion and self._estopped:
            raise RobotStopped("Robot is E-stopped. Call reset_estop() after clearing the fault.")
        why = self.needs_person if motion else None
        if why and not (recovering and not getattr(self._device, "link_lost", "")):
            self._emit("needs_person", why=why)
            raise RobotNeedsPerson(why)

    def _clamp_to_bounds(self, pose: Pose) -> Pose:
        x_min, x_max = self.bounds["x"]
        y_min, y_max = self.bounds["y"]
        z_min, z_max = self.bounds["z"]
        x = min(max(pose.x, x_min), x_max)
        y = min(max(pose.y, y_min), y_max)
        z = min(max(pose.z, z_min), z_max)

        # Too near the base column: the simplified planar solve can fold the arm back on itself instead
        # of just refusing, and the real arm can't reach down that close either (alarm 0x22 territory).
        radius = math.hypot(x, y)
        if radius <= 1e-6:
            x, y = MIN_RADIUS_MM, 0.0
        elif radius < MIN_RADIUS_MM:
            scale = MIN_RADIUS_MM / radius
            x, y = x * scale, y * scale
        elif radius > self.max_reach_mm:
            scale = self.max_reach_mm / radius
            x *= scale
            y *= scale

        clamped = Pose(x=x, y=y, z=z, r=pose.r)
        if (clamped.x, clamped.y, clamped.z) != (pose.x, pose.y, pose.z):
            logger.warning("Pose %s clamped to workspace bounds/reach -> %s", pose, clamped)
            self._emit("clamp", asked=_pose_dict(pose), to=_pose_dict(clamped))
        return clamped

    def _clamp_raw(self, pose: Pose) -> Pose:
        """Nearest point inside the safe workspace (box bounds + reach limit)."""
        return self._clamp_to_bounds(pose)

    def home(self) -> None:
        """Runs the homing sequence and waits for it to finish (15-20 s), so nothing else is
        sent while the arm is still travelling. It puts right what needs_person asks for (not a lost USB link)."""
        self._check_connection(recovering=True)
        self._settled = None
        with self._motion_lock:
            # A leftover alarm would otherwise be read a couple of seconds in and reported as the homing
            # failing, while the arm carries on homing by itself.
            self._clear_stale_reach_alarm()
            with self._lock:
                expected = dobot_protocol.home(self._device)
            if expected is not None and not self.legacy_wait:
                self._wait_for_index(expected)
        self.homed, self.homed_at, self._held_up = True, time.monotonic(), None
        self._emit("home")

    def get_alarms(self) -> list[int]:
        self._check_connection(motion=False)
        with self._lock:
            return dobot_protocol.get_alarms(self._device)

    def clear_alarms(self) -> None:
        # Inverse-resolve alarms (0x20-0x22) are documented as resetting only when
        # the queued protocol instructions are cleared, so a bare "clear alarms"
        # command isn't enough: stop + clear the queue, clear alarms, then resume.
        self._check_connection(recovering=True)
        self._clear_alarms_locked()
        self._emit("alarm_cleared_by_hand")       # (the Manual tab's Clear Alarms: a person did it)
        if self._held_up is not None:             # an alarm that wouldn't clear: did it now?
            time.sleep(0.1)
            if not alarm_codes(self._read_state()[0]):
                self._held_up = None

    def get_joints(self) -> tuple:
        """J1-J4 as the controller reports them, in degrees (for the Model tab)."""
        self._check_connection(motion=False)
        reading = self._settled_reading()
        if reading is None:
            with self._lock:
                reading = self._pose_reading()
        return tuple(reading[4:8])

    def _get_pose_raw(self) -> Pose:
        self._check_connection(motion=False)
        reading = self._settled_reading()
        if reading is None:
            with self._lock:
                reading = self._pose_reading()
        x, y, z, r, *_ = reading
        return Pose(x=x, y=y, z=z, r=r)

    def _settled_reading(self) -> Optional[tuple]:
        """The last arrival check's reading, while it stands (see SETTLED_FOR_S); else None: ask the Dobot."""
        settled = self._settled
        if settled is None or self._estopped or time.monotonic() - settled[0] > SETTLED_FOR_S:
            return None
        return settled[1]

    def _pose_reading(self) -> tuple:
        """pydobot's pose(): where the arm is and its joints. No answer (asked twice by the link) is said as one,
        not as pydobot's "'NoneType' object has no attribute 'params'", which nothing above knew to expect."""
        try:
            return self._device.pose()
        except (AttributeError, TypeError) as exc:
            raise RuntimeError("The Dobot didn't answer a position request (no reply).") from exc

    def _move_to_raw(self, pose: Pose, speed: Optional[float] = None) -> None:
        self._check_connection()
        safe_pose = self._clamp_to_bounds(pose)
        self._refuse_unreachable(safe_pose)
        if self.legacy_wait:
            with self._lock:
                self._device.move_to(safe_pose.x, safe_pose.y, safe_pose.z, safe_pose.r, wait=True)
            return
        with self._motion_lock:   # one move at a time; reading the pose and E-STOP never wait on this
            self._check_connection()
            settled, self._settled = self._settled_reading(), None     # (the arm is about to move)
            here = self._clear_stale_reach_alarm(settled)
            straight = not passes_near_base(here, safe_pose)
            if not straight:
                logger.info("Swinging round the base from (%.0f, %.0f) to (%.0f, %.0f) instead of cutting across",
                            here.x, here.y, safe_pose.x, safe_pose.y)
            expected = self._queue_move(safe_pose, straight)
            self._wait_for_index(expected, safe_pose)
            self._check_arrived(safe_pose)

    def _refuse_unreachable(self, pose: Pose) -> None:
        """A target the controller would refuse is not sent: refused there, the controller can stay in alarm and refuse
        every move after it until the Dobot is switched off and on (study 2, S-06_Run1: the approach above a cube 160
        mm from the base, at z 42, needed the rear arm 6 degrees past upright -- alarm 0x12). Judged by the
        controller's own arm (dobot_arm); the arm hasn't moved, so another target can be sent straight away."""
        problem = dobot_arm.reach_problem(pose.x, pose.y, pose.z)
        if problem is None:
            return
        logger.warning("Not sent, the controller would refuse it: %s", problem)
        self._emit("unreachable", target=_pose_dict(pose), why=problem)
        raise OutOfReach(f"The arm can't reach ({pose.x:.0f}, {pose.y:.0f}, {pose.z:.0f}): {problem}. Not sent; the "
                         "arm hasn't moved. Near the base it can't reach high: go lower there, or further out.")

    def _queue_move(self, pose: Pose, straight: bool) -> int:
        """Queue the move; if the robot doesn't answer, look at its state and send it once more -- and if it still
        doesn't, start its command queue afresh (stop, clear, start: nothing of ours is waiting in it, every move
        being waited for) with the speed set again, and send it a last time. (Seen at the lab, 22 times in five days:
        the same move unanswered again and again -- the jog's too -- with no alarm, while the robot answered every
        status request; Clear Alarms, which starts the queue afresh too, put it right. A queue that stopped or filled
        takes no more.) Sending the same target again is harmless: every try ends at the same place."""
        for attempt in (1, 2, 3):
            try:
                with self._lock:
                    return dobot_protocol.queue_move(self._device, pose.x, pose.y, pose.z, pose.r, straight=straight)
            except RuntimeError as exc:
                if "acknowledge" not in str(exc):
                    raise
                frame = getattr(exc, "frame", "")
                if attempt == 3:
                    logger.error("No answer to the move to (%.0f, %.0f, %.0f, r %.0f) three times, the last after "
                                 "clearing the queue and the alarms%s (sent: %s)", pose.x, pose.y, pose.z, pose.r,
                                 self._joints_text(), frame)
                    raise RuntimeError(
                        f"{exc} It answers everything else: the Dobot's controller is holding back moves. Press Clear "
                        "Alarms on the Manual tab and try again; if it keeps happening, switch the Dobot off and on "
                        "and press Home.") from exc
                logger.warning("No answer to the move to (%.0f, %.0f, %.0f, r %.0f)%s (%s; sent: %s); %s",
                               pose.x, pose.y, pose.z, pose.r, self._joints_text(), exc, frame,
                               "sending it once more" if attempt == 1 else
                               "clearing the robot's command queue and alarms, as Clear Alarms does, and sending it "
                               "again")
                self._emit("no_answer", target=_pose_dict(pose), attempt=attempt + 1)   # (for the watcher's record)
                time.sleep(0.3)
                if attempt == 2:
                    self._restart_queue()
                self._clear_stale_reach_alarm()     # (an alarm that won't clear is reported, not moved through)
        raise AssertionError("unreachable")

    def _restart_queue(self) -> None:
        """The robot's command queue stopped and cleared, its alarms cleared, and the queue started again -- what the
        Clear Alarms button does, which put it right at the lab (stopping and starting the queue alone didn't, the
        lab, 2026-10-21: the move to touch point 6 went unanswered three times, no alarm showing, while the Dobot
        answered everything else). The speed and pace set again over it (they are queued commands too, and may have
        been cleared with it)."""
        self._clear_alarms_locked()
        self._apply_speed()
        pace = getattr(self, "_pace_now", None)
        if pace is not None:
            with self._lock:
                dobot_protocol.set_ptp_common_params(self._device, *pace)

    def _read_state(self) -> tuple[list[int], Pose]:
        flags, reading = self._read_state_raw()
        x, y, z, r, *_ = reading
        return flags, Pose(x=x, y=y, z=z, r=r)

    def _read_state_raw(self) -> tuple[list[int], tuple]:
        with self._lock:
            flags = dobot_protocol.get_alarms(self._device)
            reading = tuple(self._pose_reading())
        self._joints = tuple(reading[4:8])
        return flags, reading

    def _joints_text(self) -> str:
        joints = getattr(self, "_joints", ())
        if len(joints) < 4:
            return ""
        return " Joint angles now: " + ", ".join(f"J{i + 1} {a:.1f}" for i, a in enumerate(joints)) + " degrees."

    def _stuck(self, codes: list[int]) -> RobotAlarm:
        """The controller refuses everything, the alarm straight back after clearing (study 2, S-06_Run1: 0x12 at the
        park pose, until a power cycle): every move is refused from now on (needs_person), not tried one after
        another, until Clear Alarms clears it or the arm is homed. Its state is logged whole, to find why."""
        logger.error("Controller stuck in alarm %s.%s", [hex(c) for c in codes], self._joints_text())
        self._log_controller_state()
        why = (f"The robot's controller is stuck in alarm ({', '.join(hex(c) for c in codes)}: 'a joint would go past "
               "its limit') and refuses every move, even to where it already is. Clearing it doesn't help. "
               "Switch the Dobot off, wait 5 seconds, switch it on, press Reconnect Robot, then Home here with the "
               "area clear. If it comes back straight after homing, check the arm isn't pushed against something."
               + self._joints_text())
        self._held_up = why
        self._emit("needs_person", why=why)
        return RobotNeedsPerson(why)

    def _log_controller_state(self) -> None:
        """Everything the controller will say about itself, in the log (an alarm that wouldn't clear: why?)."""
        device = self._device
        if device is None:
            return
        try:
            with self._lock:
                flags = dobot_protocol.get_alarms(device)
                reading = tuple(self._pose_reading())
                index = dobot_protocol.current_queue_index(device)
                pace = dobot_protocol.get_ptp_common_params(device)
            logger.error("Controller state: alarm bytes %s, pose and joints %s, queue index %s, speed/acceleration "
                         "percent %s", list(flags), [round(float(v), 2) for v in reading], index, pace)
        except Exception as exc:  # noqa: BLE001 - only a record: the alarm is reported either way
            logger.error("Controller state: couldn't read it all (%s)", exc)

    def _clear_stale_reach_alarm(self, settled: Optional[tuple] = None) -> Pose:
        """`settled`: the reading of the last move's arrival check, which found no alarm, taken moments ago with
        nothing sent to move the arm or clear anything since -- there is nothing left over to look for.

        A "can't reach" alarm left over from before (say, from DobotStudio, or a move that ran with
        legacy_wait) makes the controller drop new moves the moment they start, which looks like the arm
        just ignoring the buttons. It is harmless to clear -- if it clears. If it is straight back, the
        controller itself is stuck: say so, rather than send moves it will refuse one after another.
        Any other alarm is reported, not moved through."""
        if settled is not None:
            x, y, z, r, *_ = settled
            return Pose(x=x, y=y, z=z, r=r)
        flags, here = self._read_state()
        codes = alarm_codes(flags)
        if codes and set(codes) <= REACH_ALARMS:
            logger.warning("Clearing a leftover 'can't reach' alarm %s before moving", [hex(c) for c in codes])
            self._clear_alarms_locked()
            time.sleep(0.1)
            flags, here = self._read_state()
            stuck = bool(alarm_codes(flags))
            self._emit_alarm(codes, leftover=True, auto_cleared=not stuck, at=here)
            if stuck:
                raise self._stuck(alarm_codes(flags))
        elif codes:
            self._emit_alarm(codes, leftover=True, auto_cleared=False, at=here)
            raise RobotAlarm(f"The robot is in alarm (codes {', '.join(hex(c) for c in codes)}; raw: {flags}), "
                             "so it won't move. Use Clear Alarms on the Manual tab; if it comes back, "
                             "power-cycle the arm.")
        return here

    def _clear_alarms_locked(self) -> None:
        self._settled = None
        with self._lock:
            dobot_protocol.stop_queued_motion(self._device)
            dobot_protocol.clear_alarms(self._device)
            dobot_protocol.resume_queued_motion(self._device)

    def _raise_for_alarms(self, flags: list[int], target: Optional[Pose], at: Optional[Pose]) -> None:
        codes = alarm_codes(flags)
        if not codes:
            return
        if target is not None and at is not None and set(codes) <= REACH_ALARMS:
            # Where it stopped is somewhere it can be, so clear the alarm now: otherwise every following
            # move is dropped at once and the arm seems dead until someone finds the Clear Alarms button.
            joints = getattr(self, "_joints", ())        # (as the alarm fired: the read below replaces them)
            self._clear_alarms_locked()
            time.sleep(0.1)
            again = alarm_codes(self._read_state()[0])
            self._emit_alarm(codes, target=target, at=at, auto_cleared=not again, joints=joints)
            if again:
                # Straight back: not this target, the controller refuses everything (seen after an interrupted
                # homing). Say so, instead of each caller going on to try the next place.
                raise self._stuck(again)
            raise OutOfReach(
                f"The arm can't reach ({target.x:.0f}, {target.y:.0f}, {target.z:.0f}): a joint would go past its "
                f"limit, so it stopped at ({at.x:.0f}, {at.y:.0f}, {at.z:.0f}), "
                f"{math.hypot(at.x, at.y):.0f} mm out from the base. Near the base it can't reach down (or up) "
                "as far: move further out first. (Alarm cleared; the arm can move again.)" + self._joints_text())
        self._emit_alarm(codes, target=target, at=at, auto_cleared=False)
        raise RobotAlarm(f"The robot raised an alarm and stopped (codes {', '.join(hex(c) for c in codes)}; "
                         f"raw: {list(flags)}). Use Clear Alarms on the Manual tab; if it comes back, "
                         "power-cycle the arm.")

    def _emit_alarm(self, codes: list[int], target: Optional[Pose] = None, at: Optional[Pose] = None,
                    auto_cleared: bool = False, leftover: bool = False, joints: tuple = ()) -> None:
        """Tells the watcher about a controller alarm: its codes, when it fired (planning a move, during one, a joint
        limit), the joint angles, where the arm was going and where it stopped, and whether the app cleared it by
        itself or it needs a person."""
        def phase(code: int) -> str:
            return ("planning" if 0x10 <= code <= 0x12 else "moving" if 0x20 <= code <= 0x22
                    else "joint_limit" if 0x40 <= code <= 0x49 else "other")
        joints = tuple(joints or getattr(self, "_joints", ()))
        self._emit("alarm", codes=[hex(c) for c in codes], phases=sorted({phase(c) for c in codes}),
                   joints=[round(float(a), 1) for a in joints[:4]], target=_pose_dict(target), at=_pose_dict(at),
                   auto_cleared=auto_cleared, leftover=leftover)

    def _check_arrived(self, target: Pose) -> None:
        """The controller counts a move as finished when it gives up on it too (a joint limit on the way):
        the queue moves on and nothing else says so. So look at the alarms and where the arm really is."""
        flags, reading = self._read_state_raw()
        at = Pose(*reading[:4])
        self._raise_for_alarms(flags, target, at)
        off = math.dist((at.x, at.y, at.z), (target.x, target.y, target.z))
        if off > ARRIVED_WITHIN_MM:
            raise RobotAlarm(f"The arm stopped at ({at.x:.0f}, {at.y:.0f}, {at.z:.0f}), {off:.0f} mm short of "
                             f"({target.x:.0f}, {target.y:.0f}, {target.z:.0f}), without saying why.")
        if not self._estopped:
            self._settled = (time.monotonic(), reading)

    def _wait_for_index(self, expected: int, target: Optional[Pose] = None) -> None:
        """Wait until the robot reports command `expected` finished. Unlike pydobot's own wait
        (which polls forever, holding the robot's lock), this gives up after MOVE_TIMEOUT_S, and
        notices an E-STOP at once -- after which the finished-index would never be reached."""
        started = time.monotonic()
        deadline = started + MOVE_TIMEOUT_S
        failures = 0
        last_alarm_check = started
        while True:
            if self._estopped:
                raise RobotStopped("Robot was E-stopped during the move.")
            device = self._device
            if device is None:
                raise RuntimeError("Robot disconnected during the move.")
            try:
                with self._lock:
                    current = dobot_protocol.current_queue_index(device)
                failures = 0
                if current >= expected:
                    return
            except Exception as exc:  # noqa: BLE001 - one lost reply shouldn't abort a move that is fine
                failures += 1
                self._emit("status_lost", failures=failures, error=str(exc)[:120])   # (for the watcher's record)
                if failures >= MAX_POLL_FAILURES:
                    raise RuntimeError(f"Lost contact with the robot during a move: {exc}") from exc
            now = time.monotonic()
            if now - started > ALARM_CHECK_AFTER_S and now - last_alarm_check >= ALARM_CHECK_EVERY_S:
                # A controller alarm (say, a target it can't reach) stops the arm for good: the move
                # would otherwise sit here until the timeout, looking like a hang.
                last_alarm_check = now
                try:
                    flags, at = self._read_state()
                except Exception:  # noqa: BLE001 - a lost reply is not an alarm
                    flags, at = [], None
                self._raise_for_alarms(flags, target, at)
            if now > deadline:
                raise TimeoutError(f"The robot did not finish the move within {MOVE_TIMEOUT_S:.0f} s.")
            time.sleep(INDEX_POLL_S)
    def jog(self, dx: float, dy: float, dz: float) -> None:
        current = self.get_pose()
        target = Pose(x=current.x + dx, y=current.y + dy, z=current.z + dz, r=current.r)
        self.move_to(target)

    def open_gripper(self) -> None:
        self._set_gripper(False)

    def close_gripper(self) -> None:
        self._set_gripper(True)

    def _set_gripper(self, closed: bool) -> None:
        """Sent outside the motion queue (see dobot_protocol.set_end_effector), so it acts at once, also
        with a move in progress. Opening is allowed after an E-STOP: letting go is not motion. Then
        waits `gripper_settle_s` -- the command is acknowledged straight away but the air takes a moment
        to build up or drain, and lifting an object before that drops it. Closed, the pump keeps running (the
        air holds the object); opened, it is then switched off -- it used to run on for good once the gripper
        had been closed once."""
        self._check_connection(motion=closed)
        started = time.monotonic()
        with self._lock:
            for attempt in (1, 2):                 # one lost reply is not worth failing a pick over
                try:
                    dobot_protocol.set_end_effector(self._device, self.gripper_type == "suction", closed)
                    break
                except RuntimeError:
                    if attempt == 2:
                        raise
        sent = time.monotonic() - started
        changed = self._gripper_closed != closed          # unknown (None) counts as changed
        self._gripper_closed = closed
        deadline = time.monotonic() + (self.gripper_settle_s if changed else 0.0)   # already like that: nothing to wait for
        while time.monotonic() < deadline:
            if closed and self._estopped:
                raise RobotStopped("Robot was E-stopped while the gripper closed.")
            time.sleep(0.05)
        if not closed:
            self._pump_off()
        logger.info("Gripper %s: command %.2f s, settle %.2f s", "closed" if closed else "opened", sent,
                    self.gripper_settle_s)
        self._emit("gripper", closed=closed)

    def _pump_off(self) -> None:
        """The air pump off, once the gripper has opened (or the cup let go): as Dobot's own examples do."""
        device = self._device
        if device is None:
            return
        try:
            with self._stop_lock:
                dobot_protocol.set_end_effector(device, self.gripper_type == "suction", False, pump=False)
        except Exception:  # noqa: BLE001 - it's open already: a pump left running is noise, not danger
            logger.warning("Couldn't switch the air pump off (the gripper is open)", exc_info=True)
    def stop(self) -> None:
        logger.critical("E-STOP triggered on Dobot")
        self._estopped, self._settled = True, None
        self._emit("estop")
        device = self._device
        if device is None:
            return
        # Deliberately not under self._lock or self._motion_lock: a move in progress holds the
        # latter for its whole duration, and the stop must not wait for it. pydobot keeps each
        # serial message whole, so this can go out between the move's status requests.
        with self._stop_lock:
            try:
                dobot_protocol.stop_queued_motion(device)
            except Exception:  # noqa: BLE001 - still try to release the gripper
                logger.exception("Failed to send the stop command during E-stop")
            try:
                dobot_protocol.set_end_effector(device, self.gripper_type == "suction", False)
                self._gripper_closed = False
            except Exception:  # noqa: BLE001 - best-effort release during E-stop
                logger.exception("Failed to release gripper during E-stop")
                return
        # and the pump off once the air has opened it (not waited for here: the stop must return at once)
        threading.Timer(self.gripper_settle_s, self._pump_off).start()

    def reset_estop(self) -> None:
        self._estopped, self._settled = False, None
        if self._device is not None:
            with self._lock:
                dobot_protocol.resume_queued_motion(self._device)
                # a slow move's or a calibration's "speed back as it was", queued just before the stop, was wiped
                # with the queue: the usual pace, not 20% from then on
                usual = getattr(self, "_usual_pace", None)
                if usual is not None:
                    try:
                        dobot_protocol.set_ptp_common_params(self._device, *usual)
                    except Exception:  # noqa: BLE001 - the pace is a nicety; the reset itself has happened
                        logger.warning("Couldn't put the moves' speed back after the E-STOP")

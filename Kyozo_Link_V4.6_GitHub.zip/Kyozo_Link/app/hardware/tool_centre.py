"""Poses of the gripper's middle, not of the controller's tool point.

The controller reports and moves a tool point it was set up with. The middle between the fingers can sit a few mm
(at the lab, about 13) off it, in the tool's own turning frame: then every turn of the wrist puts a gripped object
somewhere else than the pose says. The cube calibration measures that offset (`tool_centre_mm`); with it set, every
pose this robot reports, and every pose it is sent, is of the gripper's middle -- for the app, the tools and jogging
alike. (0, 0): the controller's own tool point, as before.

A driver mixes this in, and implements `_get_pose_raw`, `_move_to_raw` and `_clamp_raw` in its controller's terms.
"""
from __future__ import annotations

import math
from typing import Optional

from app.hardware.interfaces import Pose


def turned(dx: float, dy: float, r_deg: float) -> tuple[float, float]:
    """(dx, dy), given in the tool's frame, in the robot's frame with the tool turned r degrees."""
    t = math.radians(r_deg)
    return dx * math.cos(t) - dy * math.sin(t), dx * math.sin(t) + dy * math.cos(t)


class ToolCentre:
    tool_centre_mm: tuple[float, float] = (0.0, 0.0)

    def _shift(self, pose: Pose, sign: float) -> Pose:
        dx, dy = self.tool_centre_mm
        if not dx and not dy:
            return pose
        ox, oy = turned(dx, dy, pose.r)
        return Pose(pose.x + sign * ox, pose.y + sign * oy, pose.z, pose.r)

    def get_pose(self) -> Pose:
        return self._shift(self._get_pose_raw(), +1.0)

    def move_to(self, pose: Pose, speed: Optional[float] = None) -> None:
        target = {"x": round(pose.x, 2), "y": round(pose.y, 2), "z": round(pose.z, 2), "r": round(pose.r, 2)}
        try:
            out = self._move_to_raw(self._shift(pose, -1.0), speed)
        except Exception as exc:
            self._emit("move", target=target, ok=False, error=f"{type(exc).__name__}: {exc}")
            raise
        self._emit("move", target=target, ok=True)
        return out

    def _emit(self, kind: str, **details) -> None:   # (Robot's; here for drivers that mix this in first)
        emit = getattr(super(), "_emit", None)
        if emit is not None:
            emit(kind, **details)

    def clamp_pose(self, pose: Pose) -> Pose:
        return self._shift(self._clamp_raw(self._shift(pose, -1.0)), +1.0)

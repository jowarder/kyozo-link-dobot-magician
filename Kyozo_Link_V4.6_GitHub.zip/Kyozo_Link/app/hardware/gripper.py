"""The two-finger gripper's geometry: what fits between the fingers, which way to turn them, how deep to grip.

Shared by the robot tools (which decide) and the demo twin (which lets an object be held only if a real gripper
could hold it), so demo mode tests the same rules the real arm is run by.

Angles are in degrees in the robot's frame, seen from above (0 = the robot's +x, straight out from the base).
The Dobot's pose r is the end effector's own turn in that frame: r = J1 + J4, so with r fixed the fingers keep
their direction on the table while the base turns (the controller turns J4 to make up for J1).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Callable, Optional

SQUARE_MM = 3.0            # sides this close count as square: it can be gripped across either pair of sides
# The gripper's shape, measured from the Magician gripper's model (app/twin/meshes: what the 3D view draws), from the
# fingertips up. It was 6 x 12 mm fingers and nothing above them: the drawn fingers, twice as thick, and the body
# above them went into things the checks said they cleared.
FINGER_THICKNESS_MM = 14.0 # each finger, along the way it closes: open, their outsides are 28 mm from the middle
FINGER_WIDTH_MM = 14.0     # each finger, across the way it closes
BODY_ABOVE_MM = 25.0       # the gripper's body starts this far above the fingertips (below it: just the fingers)
BODY_TOP_MM = 60.0         # and goes up to here; above it, the stem up to the wrist
BODY_ALONG_MM = (-33.0, 69.5)    # the body's extent along the way the fingers close (one side is the air cylinder)
BODY_ACROSS_MM = (-37.6, 7.0)    # and across it (+ = the way the fingers close, turned 90 degrees clockwise)
STEM_MM = 18.0             # the stem above the body, square
STEM_TOP_MM = 95.0
CLOSED_GAP_MM = 1.8        # between the fingers when closed on nothing
TABLE_CLEARANCE_MM = 2.0   # the fingertips stop at least this far above whatever the object stands on
MIN_GRIP_MM = 5.0          # the fingers need at least this much of the object's side to hold it


@dataclass(frozen=True)
class ToolShape:
    """A two-finger gripper's shape as blocks, from the fingertips (the tool point) up: the fingers alone, then
    the part joining them (nothing fits between the fingers above the grip depth), the body, the stem to the wrist.
    The defaults are the Magician gripper's (the constants above)."""
    finger_thickness_mm: float = FINGER_THICKNESS_MM   # each finger, along the way it closes
    finger_width_mm: float = FINGER_WIDTH_MM           # each finger, across it
    bridge_out_mm: float = FINGER_THICKNESS_MM         # the joining part reaches this far beyond each finger's inside
    bridge_width_mm: float = FINGER_WIDTH_MM
    bridge_top_mm: float = BODY_ABOVE_MM
    body_above_mm: float = BODY_ABOVE_MM
    body_top_mm: float = BODY_TOP_MM
    body_along_mm: tuple[float, float] = BODY_ALONG_MM
    body_across_mm: tuple[float, float] = BODY_ACROSS_MM
    stem_mm: float = STEM_MM
    stem_top_mm: float = STEM_TOP_MM
    closed_gap_mm: float = CLOSED_GAP_MM


@dataclass
class GripperSpec:
    kind: str = "gripper"            # "gripper" (two fingers) or "suction" (a cup on the top)
    opening_mm: float = 27.5         # fully open, inside edge to inside edge
    margin_mm: float = 1.5           # the widest object picked is this much narrower than the opening
    finger_depth_mm: float = 15.0    # how far down an object's sides the fingers can reach
    jaw_axis_deg: float = 90.0       # the direction the fingers close along when r = 0
    j4_limits_deg: tuple[float, float] = (-90.0, 90.0)   # as JOINT_LIMITS_DEG in twin/kinematics.py
    wrist_relative: bool = True      # the wrist's angle is r - J1 (the Dobot's J4); False: r itself (the xArm's J6)
    wrist_name: str = "J4"
    shape: ToolShape = field(default_factory=ToolShape)
    # the wrist angle the robot is really told for a planned one (the fingers angle check's correction): set by the
    # robot tools; None: as planned
    told_wrist: Optional[Callable[[float], float]] = field(default=None, repr=False, compare=False)

    @classmethod
    def from_config(cls, robot_config: dict, defaults: Optional["GripperSpec"] = None) -> "GripperSpec":
        """From config.yaml's robot settings, over `defaults` (the robot's own gripper: its profile's)."""
        kind = str(robot_config.get("gripper_type", "gripper")).lower()
        own = robot_config.get("gripper") or {}
        spec = replace(defaults or cls(), kind="suction" if kind == "suction" else "gripper")
        for name in ("opening_mm", "margin_mm", "finger_depth_mm", "jaw_axis_deg"):
            if own.get(name) is not None:
                setattr(spec, name, float(own[name]))
        return spec

    @property
    def fingers(self) -> bool:
        return self.kind == "gripper"

    @property
    def widest_mm(self) -> float:
        """The widest object it will try to pick."""
        return self.opening_mm - self.margin_mm

    def closing_direction(self, r: float) -> float:
        return self.jaw_axis_deg + r

    def wrist_turn(self, r: float, x: float, y: float) -> float:
        """The wrist joint's angle for the end effector's turn r at (x, y) (what j4_limits_deg limits)."""
        if not self.wrist_relative:
            return r
        return r - (math.degrees(math.atan2(y, x)) if math.hypot(x, y) > 1e-6 else 0.0)

    def wrist_fits(self, r: float, x: float, y: float, margin: float = 2.0) -> bool:
        """Whether the wrist can turn to r at (x, y): as planned, and as it is told after the correction (else the
        correction would be cut short at the limit and the fingers end up off their angle)."""
        low, high = self.j4_limits_deg
        wrist = self.wrist_turn(r, x, y)
        if not low + margin <= wrist <= high - margin:
            return False
        if self.told_wrist is not None:
            told = self.told_wrist(wrist)
            inside = min(margin, 1.0)          # (WRIST_LIMIT_MARGIN_DEG)
            return low + inside <= told <= high - inside
        return True


@dataclass
class ToolPart:
    """One block of the tool seen from above, (width, length, angle of the long side) round `centre`, from
    `low` up to `high` (mm)."""
    name: str
    centre: tuple[float, float]
    size: tuple[float, float, float]
    low: float
    high: float


def tool_parts(spec: GripperSpec, x: float, y: float, z: float, r: float,
               opening: Optional[float] = None) -> list[ToolPart]:
    """The tool as blocks, its tip (the fingertips) at (x, y, z) and turned by r. `opening`: the gap between the
    fingers (default: fully open; the object's width when holding one, CLOSED_GAP_MM when closed on nothing)."""
    if not spec.fingers:
        return [ToolPart("the suction tip", (x, y), (10.0, 10.0, 0.0), z, z + 40.0)]
    shape = spec.shape
    direction = spec.closing_direction(r)
    ux, uy = math.cos(math.radians(direction)), math.sin(math.radians(direction))
    vx, vy = uy, -ux                                   # across: the closing direction turned 90 degrees clockwise
    gap = spec.opening_mm if opening is None else opening
    reach = gap / 2.0 + shape.finger_thickness_mm / 2.0
    bridge_top = max(shape.bridge_top_mm, spec.finger_depth_mm)
    parts = [ToolPart("a finger", (x + side * reach * ux, y + side * reach * uy),
                      (shape.finger_thickness_mm, shape.finger_width_mm, direction + 90.0), z, z + bridge_top)
             for side in (-1.0, 1.0)]
    # above the finger depth nothing fits between them (the grip never goes deeper): one block across
    parts.append(ToolPart("the gripper", (x, y), (shape.bridge_width_mm, gap + 2 * shape.bridge_out_mm, direction),
                          z + spec.finger_depth_mm, z + bridge_top))
    along_mm, across_mm = shape.body_along_mm, shape.body_across_mm
    along = (along_mm[0] + along_mm[1]) / 2.0
    side = (across_mm[0] + across_mm[1]) / 2.0
    parts.append(ToolPart("the gripper's body", (x + along * ux + side * vx, y + along * uy + side * vy),
                          (across_mm[1] - across_mm[0], along_mm[1] - along_mm[0], direction),
                          z + shape.body_above_mm, z + shape.body_top_mm))
    parts.append(ToolPart("the gripper", (x, y), (shape.stem_mm, shape.stem_mm, direction), z + shape.body_top_mm,
                          z + shape.stem_top_mm))
    return parts


def across(width: float, length: float, angle_deg: float, direction_deg: float) -> float:
    """How wide an object is along `direction_deg`: its footprint (width x length, long side pointing along
    `angle_deg`) seen edge-on from that direction."""
    turn = math.radians(direction_deg - angle_deg)
    return abs(length * math.cos(turn)) + abs(width * math.sin(turn))


def wrap(angle: float) -> float:
    """Into -180..180."""
    return (angle + 180.0) % 360.0 - 180.0


@dataclass
class GripPlan:
    r: float                 # the end effector's turn for the grip
    j4: float                # the wrist joint that gives it here
    across_mm: float         # the object's width between the fingers
    spare_mm: float          # opening minus that
    depth_mm: float          # how far below the top the fingertips close
    note: str                # in words, for the Model tab


def plan_grip(spec: GripperSpec, x: float, y: float, top_z: float, height: Optional[float],
              footprint: Optional[tuple[float, float, float]],
              blocked: Callable[..., Optional[str]] = lambda direction, depth=None: None) -> GripPlan:
    """How to take hold of an object whose top centre is at (x, y, top_z): which way to turn the fingers and
    how deep to go. `footprint` is (width, length, angle of the long side) as the camera measured it, or None;
    `height` its measured height, or None. `blocked(direction, depth)` names a neighbour the open gripper would
    hit when closing along `direction` with the fingertips `depth` below the top, if any. Where every way is
    blocked at the usual depth, a shallower grip (no less than MIN_GRIP_MM) that keeps the fingers above what is
    in the way: packed in a tray, a cube had the wall on one side and its neighbour on the other, halfway down,
    and couldn't be picked out again. Raises ValueError, in words for the model, if it can't be done."""
    j1 = math.degrees(math.atan2(y, x)) if math.hypot(x, y) > 1e-6 else 0.0
    if footprint is None:
        # the camera gave no outline: grip square to the arm, as for a standard cube, and say so
        choices, width, length, angle = [j1], None, None, None
    else:
        width, length, angle = footprint
        # the fingers close across the narrow side; a square object across either pair of sides
        base = angle + 90.0 - spec.jaw_axis_deg
        period = 90.0 if length - width <= SQUARE_MM else 180.0
        choices = [base + k * period for k in range(-4, 5)]
    # the smallest wrist turn from where the base points, within the wrist's range
    choices = sorted((r for r in choices if spec.wrist_fits(r, x, y)), key=lambda r: abs(r - j1))
    if not choices:
        raise ValueError("The wrist can't turn far enough to line the fingers up with it here. Tell the user.")
    if width is not None and width > spec.widest_mm:
        raise ValueError(f"It is {width:.0f} mm across its narrowest side, and the gripper opens only "
                         f"{spec.opening_mm:.1f} mm ({spec.widest_mm:.1f} mm with the safety margin), so it can't "
                         "be picked up. Tell the user.")
    import inspect
    takes_depth = len(inspect.signature(blocked).parameters) >= 2
    usual = grip_depth(spec, height)
    depths = [usual] + ([d for d in range(int(usual) - 1, int(MIN_GRIP_MM) - 1, -1)] if takes_depth else [])
    reasons = []
    for depth in depths:
        for r in choices:
            direction = spec.closing_direction(r)
            hit = blocked(direction, depth) if takes_depth else blocked(direction)
            if hit:
                if depth == usual:
                    reasons.append(hit)
                continue
            return _grip_plan(spec, r, spec.wrist_turn(r, x, y), direction, width, length, angle, float(depth),
                              "" if depth == usual else f", held higher up to keep the fingers above the {reasons[0]}")
    raise ValueError(f"The open gripper would hit the {reasons[0]} beside it. Move that one first, or tell the user.")


def _grip_plan(spec: GripperSpec, r: float, j4: float, direction: float, width, length, angle, depth: float,
               why_depth: str) -> GripPlan:
    wide = across(width, length, angle, direction) if width is not None else None
    if wide is None:
        note = (f"no outline from the camera: fingers square to the arm ({spec.wrist_name} {j4:+.0f}°), "
                f"closing {depth:.0f} mm below the top{why_depth}")
        return GripPlan(round(r, 1), round(j4, 1), 0.0, 0.0, depth, note)
    spare = spec.opening_mm - wide
    note = (f"fingers turned to {wrap(direction):.0f}° ({spec.wrist_name} {j4:+.0f}°) to close across the {wide:.0f} mm side, "
            f"{spare:.1f} mm to spare in the {spec.opening_mm:.1f} mm opening; closing {depth:.0f} mm below the "
            f"top{why_depth}")
    return GripPlan(round(r, 1), round(j4, 1), round(wide, 1), round(spare, 1), depth, note)


def grip_depth(spec: GripperSpec, height: Optional[float]) -> float:
    """How far below the top the fingertips close: halfway down, no deeper than the fingers reach, and never
    down to what it stands on. Height unknown (no table height yet): a shallow grip, to stay clear of the table."""
    if not spec.fingers:
        return 0.0
    if height is None:
        return MIN_GRIP_MM + 3.0
    if height - TABLE_CLEARANCE_MM < MIN_GRIP_MM:
        raise ValueError(f"It is only {height:.0f} mm tall: too flat for the fingers to hold. Tell the user.")
    return round(min(height / 2.0, spec.finger_depth_mm, height - TABLE_CLEARANCE_MM), 1)


def turn_for_place(spec: GripperSpec, r_held: float, x: float, y: float, square: bool) -> float:
    """The end effector's turn to put the held object down at (x, y): as held (so it isn't turned), unless the
    wrist can't reach that there -- then a half turn (or a quarter for a square one), which looks the same; and
    if none of those fits either, as near as the wrist goes (the object ends up turned a little)."""
    j1 = math.degrees(math.atan2(y, x)) if math.hypot(x, y) > 1e-6 else 0.0
    low, high = spec.j4_limits_deg
    period = 90.0 if square else 180.0
    options = sorted((r_held + k * period for k in range(-4, 5)), key=lambda r: (abs(r - r_held), abs(r - j1)))
    for r in options:
        if spec.wrist_fits(r, x, y):
            return r
    offset = r_held - spec.wrist_turn(r_held, x, y)      # J1, or 0 where the wrist doesn't turn against the base
    return offset + min(max(spec.wrist_turn(r_held, x, y), low + 2.0), high - 2.0)

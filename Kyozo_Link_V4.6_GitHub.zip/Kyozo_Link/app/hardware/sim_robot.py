"""Kinematic PyBullet-backed simulated Dobot Magician (demo mode).

Uses a simplified 2-link planar arm + vertical lift model, which is close
enough for visualization and kinematic-only pick/place logic. Exact Dobot
Magician parallel-linkage kinematics are not modeled -- the demo twin only
needs to look plausible and report accurate XYZ for the gripper tip, not
match the real arm's joint angles.
"""
from __future__ import annotations

import logging
import math
import tempfile
import time
from pathlib import Path
from typing import Optional

from app import robots
from app.hardware.gripper import GripperSpec, across, tool_parts
from app.hardware.interfaces import OutOfReach, Pose, Robot, RobotStopped
from app.hardware.tool_centre import ToolCentre
from app.hardware.motion import passes_near_base, path_points, swing_point
from app.twin.kinematics import ArmGeometry
from app.twin.world import TRAY_FLOOR_MM, TRAY_WALL_MM, pybullet_lock

logger = logging.getLogger(__name__)

try:
    import pybullet as p
except ImportError:  # pragma: no cover
    p = None

DEFAULT_MAX_REACH_MM = 300.0   # the Magician's official max reach from the base column; matches dobot.py
NOZZLE_OPEN = (0.29, 0.85, 0.8)     # teal
NOZZLE_CLOSED = (0.98, 0.55, 0.15)  # orange while gripping
GRIP_PICK_TOLERANCE_MM = 5.0
GRASP_RADIUS_MM = 35.0   # closing the gripper this close to an object picks it up
HELD_DROP_MM = 12.0      # a carried object's centre below the suction tip, when its height isn't known
FINGER_CENTRE_MM = 10.0  # the fingers close on an object only with its centre about between them
PATH_STEP_MM = 2.0       # a move's path is checked for contact this finely
TOUCH_MM = 1.0           # parts this far into each other count as touching, not as a collision
JAW_STEP_MM = 0.5        # closing on nothing, the jaws are checked this finely for what they close onto
JAW_STOP_MARGIN_MM = 2.0 # ...and stop this much wider than where they touch it (the drawn right jaw sits ~1 mm in)


SQUARE_UP_DEG = 20.0   # an object this far turned against the closing fingers is squeezed square to them

class Collision(RuntimeError):
    """A move stopped where the gripper (or the suction tip, or what it carries) touched an object, a tray or the
    table. The demo used to pass straight through: the real arm would press on it, or push it over."""
MARKER_CARD_MM = 1.5              # thickness of the marker's card
# the card's top surface sits this far above the tool's corner (the J4 axis at wrist height): on top
# of the real tool head, which is 45.4 mm above it (magicianLink4 mesh), plus the card itself
MARKER_ABOVE_CORNER_MM = 47.0
MARKER_PATTERN_LIFT_MM = 0.0     # the black pattern's own mesh is already 0.3 mm above the card's top face

_MESH_SEGMENTS = 32


def _cylinder_mesh() -> str:
    """Path to an OBJ of a unit cylinder (radius 1, length 1, along z, smooth side normals),
    written once and reused; scaled per link with meshScale."""
    path = Path(tempfile.gettempdir()) / "dobot_twin_cylinder.obj"
    if not path.exists():
        lines = []
        for i in range(_MESH_SEGMENTS):
            angle = 2 * math.pi * i / _MESH_SEGMENTS
            lines.append(f"v {math.cos(angle):.5f} {math.sin(angle):.5f} -0.5")
            lines.append(f"v {math.cos(angle):.5f} {math.sin(angle):.5f} 0.5")
            lines.append(f"vn {math.cos(angle):.5f} {math.sin(angle):.5f} 0")
        lines += ["v 0 0 -0.5", "v 0 0 0.5", "vn 0 0 -1", "vn 0 0 1"]
        n = _MESH_SEGMENTS
        bottom_centre, top_centre = 2 * n + 1, 2 * n + 2
        down, up = n + 1, n + 2   # indices of the cap normals
        for i in range(n):
            j = (i + 1) % n
            b0, t0, b1, t1 = 2 * i + 1, 2 * i + 2, 2 * j + 1, 2 * j + 2
            lines.append(f"f {b0}//{i + 1} {b1}//{j + 1} {t1}//{j + 1}")
            lines.append(f"f {b0}//{i + 1} {t1}//{j + 1} {t0}//{i + 1}")
            lines.append(f"f {bottom_centre}//{down} {b1}//{down} {b0}//{down}")
            lines.append(f"f {top_centre}//{up} {t0}//{up} {t1}//{up}")
        path.write_text("\n".join(lines) + "\n")
    return str(path)


def _overlap(a_centre, a_size, b_centre, b_size) -> float:
    """How far two shapes seen from above are into each other (0 or less: apart). A size is (width, length, angle of
    the long side) for a rectangle, or (diameter, diameter, None) for something round: as squares, a finger closing
    past a cylinder at an angle "hit" the square's corner, well outside the cylinder."""
    from app.llm.packing import overlap_depth
    a_round, b_round = a_size[2] is None, b_size[2] is None
    if not a_round and not b_round:
        return overlap_depth(a_centre, a_size, b_centre, b_size)
    if a_round and b_round:
        return (a_size[0] + b_size[0]) / 2.0 - math.dist(a_centre, b_centre)
    (circle, radius), (centre, (width, length, angle)) = (
        ((a_centre, a_size[0] / 2.0), (b_centre, b_size)) if a_round else ((b_centre, b_size[0] / 2.0), (a_centre, a_size)))
    c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
    dx, dy = circle[0] - centre[0], circle[1] - centre[1]
    along, across = abs(dx * c + dy * s), abs(-dx * s + dy * c)       # in the rectangle's own frame
    out_along, out_across = along - length / 2.0, across - width / 2.0
    if out_along > 0.0 or out_across > 0.0:
        return radius - math.hypot(max(out_along, 0.0), max(out_across, 0.0))
    return radius - max(out_along, out_across)                       # its middle inside the rectangle


class SimRobot(ToolCentre, Robot):
    def __init__(self, physics_client: int, workspace_bounds: dict, max_speed: float = 200.0,
                 max_reach_mm: float = DEFAULT_MAX_REACH_MM, world=None,
                 marker_size_mm: Optional[float] = 30.0, marker_offset_mm=(0.0, 0.0),
                 gripper: Optional[GripperSpec] = None):
        """marker_size_mm: a printed calibration marker on top of the tool (None for no marker);
        marker_offset_mm: how far off the tool's axis it was stuck, in the tool's own frame
        (it turns with the wrist) -- the calibration has to cope with that. `gripper`: the end effector
        (default: a suction cup, which holds whatever it touches); a two-finger gripper holds an object only
        if its fingers go down round it and it fits between them, as the real one."""
        if p is None:
            raise RuntimeError("pybullet is not installed. Run `pip install pybullet`.")
        self.world = world  # TwinWorld; lets the gripper pick up and put down its objects
        self._held: Optional[str] = None
        self.gripper = gripper or GripperSpec(kind="suction")
        self._held_grip: Optional[tuple[float, float, float]] = None   # (centre below the tip, yaw, r) when taken
        # the real fingers centre what they hold across them only: along them it stays where it was when they closed
        # (on: the held object keeps that place; off, as before: it is drawn to the fingers' middle)
        self.keeps_place_along_fingers = False
        self._held_along = 0.0        # ...that place: mm along the fingers from their middle
        self.last_grip_problem = ""   # why the fingers last closed on nothing (for the log and the tests)
        self.jaw_stop_mm: Optional[float] = None   # closed, not holding: the jaws stopped this far apart, against it
        self.client = physics_client
        self.bounds = workspace_bounds
        self.max_speed = max_speed
        self.max_reach_mm = max_reach_mm
        self._pose = Pose(x=200.0, y=0.0, z=50.0, r=0.0)
        self._gripper_closed = False
        self.motion: Optional[tuple[Pose, Pose]] = None   # (from, to) while a move is under way
        self._estopped = False
        self._body_id: Optional[int] = None   # set once the visual body exists
        self._static: list[int] = []          # base parts
        self._links: dict[str, int] = {}      # rear arm, forearm, wrist, tip
        self._joints: dict[str, int] = {}     # the spheres at the joints
        self.marker_size_mm = marker_size_mm
        self.marker_offset_mm = tuple(marker_offset_mm)
        self._marker_bodies: list[int] = []   # the card and its black pattern (not outlined: keep it clean)
        # where the middle between the fingers is from the tool point, in the tool's own (turning) frame: a real
        # gripper's is never exactly on the wrist's axis (0, 0: it is; set by tests of the cube calibration)
        self.tool_offset_mm: tuple[float, float] = (0.0, 0.0)
        # a real wrist's faults, for rehearsing the fingers angle check (see hardware/wrist.py): the gripper mounted
        # turned on the wrist, the wrist turning this many times what it is told, and slack in its gears. The pose
        # (get_pose) stays what it was told, as a real controller reports; the fingers point by real_r().
        self.fingers_turned_deg = 0.0
        self.wrist_gain = 1.0
        self.wrist_backlash_deg = 0.0
        self._wrist_real: Optional[float] = None       # the wrist's real angle, after its slack

    # ---- lifecycle ----------------------------------------------------
    def connect(self) -> None:
        self._build_visual_body()
        self._apply_pose_to_visual()

    def disconnect(self) -> None:
        with pybullet_lock:
            for body in [*self._all_bodies(), *self._marker_bodies]:
                p.removeBody(body, physicsClientId=self.client)
            self._marker_bodies = []
            self._links = {}
            self._joints = {}
            self._static = []
            self._body_id = None

    def body_ids(self) -> list[int]:
        """The PyBullet bodies that make up the arm and its base."""
        return self._all_bodies()

    def _all_bodies(self) -> list[int]:
        return [*self._static, *self._links.values(), *self._joints.values()]

    def _make_cylinder(self, radius: float, length: float, rgba: list[float]) -> int:
        # PyBullet's built-in cylinder renders with blotchy shading, so use a smooth-normal mesh
        visual = p.createVisualShape(p.GEOM_MESH, fileName=_cylinder_mesh(), meshScale=[radius, radius, length],
                                      rgbaColor=rgba, physicsClientId=self.client)
        return p.createMultiBody(baseMass=0, baseCollisionShapeIndex=-1, baseVisualShapeIndex=visual,
                                  basePosition=[0, 0, 0.5], physicsClientId=self.client)

    def _make_sphere(self, radius: float, rgba: list[float]) -> int:
        visual = p.createVisualShape(p.GEOM_SPHERE, radius=radius, rgbaColor=rgba, physicsClientId=self.client)
        return p.createMultiBody(baseMass=0, baseCollisionShapeIndex=-1, baseVisualShapeIndex=visual,
                                  basePosition=[0, 0, 0.5], physicsClientId=self.client)

    def _make_box(self, half_extents: list[float], position: list[float], rgba: list[float]) -> int:
        visual = p.createVisualShape(p.GEOM_BOX, halfExtents=half_extents, rgbaColor=rgba,
                                      physicsClientId=self.client)
        return p.createMultiBody(baseMass=0, baseCollisionShapeIndex=-1, baseVisualShapeIndex=visual,
                                  basePosition=position, physicsClientId=self.client)

    def _set_link(self, body: int, a: tuple, b: tuple) -> None:
        """Lay a cylinder between two points (its length was fixed when it was made: the
        arm's links never change length)."""
        direction = [b[k] - a[k] for k in range(3)]
        length = math.sqrt(sum(v * v for v in direction))
        middle = [(a[k] + b[k]) / 2 for k in range(3)]
        if length < 1e-9:
            p.resetBasePositionAndOrientation(body, middle, [0, 0, 0, 1], physicsClientId=self.client)
            return
        d = [v / length for v in direction]
        axis = [-d[1], d[0], 0.0]                     # z-axis x direction
        sine = math.hypot(axis[0], axis[1])
        if sine < 1e-9:
            orientation = [0, 0, 0, 1] if d[2] > 0 else [1, 0, 0, 0]
        else:
            orientation = p.getQuaternionFromAxisAngle([axis[0] / sine, axis[1] / sine, 0.0],
                                                        math.atan2(sine, d[2]))
        p.resetBasePositionAndOrientation(body, middle, orientation, physicsClientId=self.client)

    def _build_visual_body(self) -> None:
        """What the simulated camera sees of the arm: simple shapes along the real Magician's joint
        geometry (the 3D views draw its real meshes, see magician_model.py). The base block is the real
        158 x 158 x 52 mm footprint. Light greys and teal only: saturated colours would trip the colour
        detector that looks for cubes."""
        steel, pale, teal = [0.80, 0.88, 0.95, 1], [0.90, 0.94, 0.98, 1], [0.29, 0.72, 0.68, 1]
        robot = robots.active()
        reference = robot.geometry(200.0, 0.0, 50.0)
        length = lambda a, b: math.dist(a, b) / 1000.0  # noqa: E731
        k = robot.sim_body_scale       # a bigger arm (the xArm), thicker parts
        with pybullet_lock:
            plate = self._make_box([0.079, 0.079, 0.026], [0, 0, 0.026], [0.62, 0.7, 0.75, 1])
            lower = self._make_cylinder(0.05, 0.03, [0.78, 0.85, 0.9, 1])
            p.resetBasePositionAndOrientation(lower, [0, 0, 0.067], [0, 0, 0, 1], physicsClientId=self.client)
            column_top = (robot.base_height_mm - 14.0) / 1000.0
            upper = self._make_cylinder(0.04 * min(k, 1.6), column_top - 0.082, pale)
            p.resetBasePositionAndOrientation(upper, [0, 0, (0.082 + column_top) / 2], [0, 0, 0, 1],
                                              physicsClientId=self.client)
            self._static = [plate, lower, upper]
            self._body_id = plate
            self._links = {
                "rear": self._make_cylinder(0.015 * k, length(reference.shoulder, reference.elbow), steel),
                "fore": self._make_cylinder(0.0125 * k, length(reference.elbow, reference.wrist), steel),
                "wrist": self._make_cylinder(0.0075 * k, length(reference.wrist, reference.tool_corner), steel),
                "tip": self._make_cylinder(0.006 * k, length(reference.tool_corner, reference.tcp),
                                           list(NOZZLE_OPEN) + [1]),
            }
            self._joints = {
                "shoulder": self._make_sphere(0.019 * k, teal),
                "elbow": self._make_sphere(0.0165 * k, teal),
                "wrist": self._make_sphere(0.0135 * k, teal),
                "corner": self._make_sphere(0.008 * k, steel),
            }
            if self.marker_size_mm:
                self._build_marker()

    def _recolor_tip(self) -> None:
        rgba = list(NOZZLE_CLOSED if self._gripper_closed else NOZZLE_OPEN) + [1]
        if "tip" in self._links:
            p.changeVisualShape(self._links["tip"], -1, rgbaColor=rgba, physicsClientId=self.client)

    # ---- kinematics -----------------------------------------------------
    def arm_state(self) -> tuple[ArmGeometry, bool]:
        """Where each part of the arm is, plus whether the gripper is closed. Used by the
        3D view; the same geometry drives the simulated camera's picture of the arm."""
        return robots.active().geometry(self._pose.x, self._pose.y, self._pose.z, self._pose.r), self._gripper_closed

    @property
    def held_object(self) -> Optional[str]:
        """Id of the object the gripper is carrying, if any."""
        return self._held

    def _grip_point(self, pose: Optional[Pose] = None) -> tuple[float, float]:
        """Where the middle between the fingers is, seen from above (the tool point, moved by tool_offset_mm)."""
        pose = pose or self._pose
        dx, dy = self.tool_offset_mm
        turn = math.radians(pose.r)
        return (pose.x + dx * math.cos(turn) - dy * math.sin(turn), pose.y + dx * math.sin(turn) + dy * math.cos(turn))

    def _held_point(self) -> tuple[float, float]:
        """Where the held object's middle is, seen from above: the fingers' middle, or along them from it (see
        keeps_place_along_fingers)."""
        gx, gy = self._grip_point()
        if not self._held_along:
            return gx, gy
        direction = math.radians(self.gripper.closing_direction(self.real_r()))
        return gx - self._held_along * math.sin(direction), gy + self._held_along * math.cos(direction)

    def held_info(self) -> Optional[dict]:
        """What it carries, as the robot tools need to know it when it was taken by hand (the Manual tab): its label,
        size (width, depth, height), turn now, and how far below its top the fingertips hold it. None if nothing."""
        if self._held is None or self.world is None:
            return None
        meta = self.world.object_meta[self._held]
        below, yaw = self._held_hang()
        height = meta["size"][2]
        return {"label": meta["label"], "size": tuple(meta["size"]), "yaw": yaw, "shape": meta.get("shape"),
                "grip_depth": max(0.0, height / 2.0 - below), "r": self._pose.r,
                "xyz": (*self._held_point(), self._pose.z - below + height / 2.0)}

    def _apply_pose_to_visual(self) -> None:
        if self._body_id is None:
            return
        geometry = robots.active().geometry(self._pose.x, self._pose.y, self._pose.z, self._pose.r)
        mm = lambda point: tuple(v / 1000.0 for v in point)  # noqa: E731 - pybullet works in metres
        shoulder, elbow, wrist = mm(geometry.shoulder), mm(geometry.elbow), mm(geometry.wrist)
        corner, tcp = mm(geometry.tool_corner), mm(geometry.tcp)

        with pybullet_lock:
            self._set_link(self._links["rear"], shoulder, elbow)
            self._set_link(self._links["fore"], elbow, wrist)
            self._set_link(self._links["wrist"], wrist, corner)
            self._set_link(self._links["tip"], corner, tcp)
            for name, point in (("shoulder", shoulder), ("elbow", elbow), ("wrist", wrist), ("corner", corner)):
                p.resetBasePositionAndOrientation(self._joints[name], point, [0, 0, 0, 1],
                                                  physicsClientId=self.client)
            if self._held is not None:
                # carried object hangs just under the suction tip (or where the fingers took it), but never lower
                # than where it would naturally rest at this x, y -- otherwise jogging the tip down by hand (rather
                # than through pick/place) could drive it visibly through the tray floor or another cube.
                below, yaw = self._held_hang()
                natural = self._pose.z - below
                gx, gy = self._held_point()
                resting = self.world.resting_height_mm(self._held, gx, gy)
                self._place_object(self._held, gx, gy, max(natural, resting), yaw)
            if self._marker_bodies:
                centre, yaw = self._marker_frame()
                orientation = p.getQuaternionFromEuler([0.0, 0.0, yaw])
                for body, lift_mm in zip(self._marker_bodies, (-MARKER_CARD_MM / 2, MARKER_PATTERN_LIFT_MM)):
                    p.resetBasePositionAndOrientation(body, [centre[0] / 1000, centre[1] / 1000, (centre[2] + lift_mm) / 1000],
                                                      orientation, physicsClientId=self.client)

    # ---- the calibration marker ---------------------------------------------------
    def _marker_frame(self) -> tuple[tuple[float, float, float], float]:
        """(centre of the marker's top surface in mm, its turn about the vertical in radians)."""
        geometry = robots.active().geometry(self._pose.x, self._pose.y, self._pose.z, self._pose.r)
        turn = math.radians(self._pose.r)
        ox, oy = self.marker_offset_mm
        x = geometry.tool_corner[0] + ox * math.cos(turn) - oy * math.sin(turn)
        y = geometry.tool_corner[1] + ox * math.sin(turn) + oy * math.cos(turn)
        return (x, y, geometry.tool_corner[2] + MARKER_ABOVE_CORNER_MM), turn

    def _build_marker(self) -> None:
        from app.calibration.marker import QUIET_ZONE_MM, marker_cells
        from app.twin.world import _strip, _write_flat_mesh
        side = self.marker_size_mm + 2 * QUIET_ZONE_MM
        card = p.createVisualShape(p.GEOM_BOX, halfExtents=[side / 2000, side / 2000, MARKER_CARD_MM / 2000],
                                   rgbaColor=[0.97, 0.97, 0.97, 1], physicsClientId=self.client)
        cell = self.marker_size_mm / 6.0
        quads = []
        for row, line in enumerate(marker_cells()):
            for col, value in enumerate(line):
                if value == 0:   # black; rows run down the page, so +y runs up it
                    x0, y1 = (col - 3) * cell, (3 - row) * cell
                    quads.append([(x0, y1 - cell), (x0 + cell, y1 - cell), (x0 + cell, y1), (x0, y1)])
        pattern = p.createVisualShape(p.GEOM_MESH, fileName=_write_flat_mesh("marker", quads),
                                      rgbaColor=[0.02, 0.02, 0.02, 1], physicsClientId=self.client)
        self._marker_bodies = [p.createMultiBody(baseMass=0, baseVisualShapeIndex=card, basePosition=[0, 0, 0.5],
                                                 physicsClientId=self.client),
                               p.createMultiBody(baseMass=0, baseVisualShapeIndex=pattern, basePosition=[0, 0, 0.5],
                                                 physicsClientId=self.client)]

    def marker_polygons(self) -> list:
        """The marker as flat polygons [(corner points in mm, grey level)], for the 3D view to draw."""
        if not self.marker_size_mm:
            return []
        from app.calibration.marker import QUIET_ZONE_MM, marker_cells
        (cx, cy, cz), yaw = self._marker_frame()
        cos, sin = math.cos(yaw), math.sin(yaw)
        place = lambda x, y, lift: (cx + x * cos - y * sin, cy + x * sin + y * cos, cz + lift)  # noqa: E731
        half = self.marker_size_mm / 2 + QUIET_ZONE_MM
        polygons = [([place(-half, -half, 0.0), place(half, -half, 0.0), place(half, half, 0.0), place(-half, half, 0.0)], 0.96)]
        cell = self.marker_size_mm / 6.0
        for row, line in enumerate(marker_cells()):
            for col, value in enumerate(line):
                if value == 0:
                    x0, y1 = (col - 3) * cell, (3 - row) * cell
                    polygons.append(([place(x0, y1 - cell, 0.4), place(x0 + cell, y1 - cell, 0.4),
                                      place(x0 + cell, y1, 0.4), place(x0, y1, 0.4)], 0.03))
        return polygons

    # ---- Robot interface --------------------------------------------------
    def home(self) -> None:
        self.move_to(Pose(x=200.0, y=0.0, z=50.0, r=0.0))

    def _get_pose_raw(self) -> Pose:
        return self._pose

    def _clamp_to_bounds(self, pose: Pose) -> Pose:
        x_min, x_max = self.bounds["x"]
        y_min, y_max = self.bounds["y"]
        z_min, z_max = self.bounds["z"]
        x = min(max(pose.x, x_min), x_max)
        y = min(max(pose.y, y_min), y_max)
        z = min(max(pose.z, z_min), z_max)

        # Nearer the base than this the (simplified) 2-link solve can go past vertical and fold the
        # arm back on itself instead of just refusing -- push sideways/close clicks out to a sane ring
        # instead, the same distance a real arm would also refuse to come down at (see MIN_RADIUS_MM).
        # Box bounds alone don't stop a diagonal target like (238, 233) -- individually inside x and y,
        # but ~333 mm out, well past what the arm can physically stretch to. DobotRobot has always
        # capped this for the real arm; the sim never did, so it could be driven straight through the
        # outer reach arc while box bounds still allowed it.
        radius = math.hypot(x, y)
        min_radius = robots.active().min_radius_mm
        if radius <= 1e-6:
            x, y = min_radius, 0.0
        elif radius < min_radius:
            scale = min_radius / radius
            x, y = x * scale, y * scale
        elif radius > self.max_reach_mm:
            scale = self.max_reach_mm / radius
            x, y = x * scale, y * scale

        return Pose(x=x, y=y, z=z, r=pose.r)

    def _clamp_raw(self, pose: Pose) -> Pose:
        return self._clamp_to_bounds(pose)

    def _jaw_gap(self) -> Optional[float]:
        """The gap between the fingers now (None: fully open)."""
        if not self._gripper_closed:
            return None
        if self._held is not None:
            return min(self.world.object_meta[self._held]["size"][:2])   # (as the 3D view draws them round it)
        return self.jaw_stop_mm if self.jaw_stop_mm is not None else self.gripper.shape.closed_gap_mm

    def _obstacles(self) -> list[tuple[str, str, tuple, tuple, float, float]]:
        """Everything on the table as blocks seen from above: (key, in words, centre, (width, length, angle of the
        long side; the angle None for something round), bottom, top). Not the object being carried: see _contacts."""
        blocks = []
        for object_id, meta in list(self.world.object_meta.items()):
            if object_id == self._held:
                continue
            ox, oy, oz = self.world.get_object_position_mm(object_id)
            width, depth, height = meta["size"]
            label = meta["label"]
            yaw = self.world.get_object_yaw_deg(object_id)
            if meta.get("shape") == "tray":
                # its position is its floor's middle; the walls stand on the floor's edges, from the floor's middle up
                table = oz - TRAY_FLOOR_MM / 2.0
                c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
                blocks.append((object_id + ":floor", f"the {label}", (ox, oy), (depth, width, yaw), table,
                               table + TRAY_FLOOR_MM))
                for n, (along, sideways, size) in enumerate(((0.0, depth / 2, (TRAY_WALL_MM, width, yaw)),
                                                             (0.0, -depth / 2, (TRAY_WALL_MM, width, yaw)),
                                                             (width / 2, 0.0, (TRAY_WALL_MM, depth, yaw + 90.0)),
                                                             (-width / 2, 0.0, (TRAY_WALL_MM, depth, yaw + 90.0)))):
                    centre = (ox + along * c - sideways * s, oy + along * s + sideways * c)
                    blocks.append((f"{object_id}:wall{n}", f"the {label}'s wall", centre, size, oz, oz + height))
                continue
            if meta.get("shape") in ("ball", "cylinder"):
                footprint = (width, width, None)     # round (a ball taken as the cylinder round it)
            else:                                    # (its width is along its own x)
                footprint = (min(width, depth), max(width, depth), yaw + (90.0 if depth > width else 0.0))
            blocks.append((object_id, f"the {label}", (ox, oy), footprint, oz - height / 2.0, oz + height / 2.0))
        return blocks

    def _contacts(self, pose: Pose) -> dict[str, tuple[float, str]]:
        """How far the tool, and what it carries, would be into each thing at `pose`: {key: (mm, in words)}, only
        what it is more than touching. The table counts too."""
        parts = [(part.name, part.centre, part.size, part.low, part.high)
                 for part in tool_parts(self.gripper, pose.x, pose.y, pose.z, self._real_r_at(pose), self._jaw_gap())]
        if self._held is not None:
            meta = self.world.object_meta[self._held]
            below, yaw = self._held_hang()
            width, depth, height = meta["size"]
            footprint = ((width, width, None) if meta.get("shape") in ("ball", "cylinder")
                         else (min(width, depth), max(width, depth), yaw + (90.0 if depth > width else 0.0)))
            centre_z = pose.z - below
            parts.append((f"the {meta['label']} it carries", self._grip_point(pose), footprint,
                          centre_z - height / 2.0, centre_z + height / 2.0))
        found: dict[str, tuple[float, str]] = {}

        def note(key: str, depth: float, words: str) -> None:
            if depth > TOUCH_MM and depth > found.get(key, (0.0, ""))[0]:
                found[key] = (depth, words)
        for name, centre, size, low, high in parts:
            note("table", -low, f"{name} touched the table")
        for key, what, centre_b, size_b, bottom, top in self._obstacles():
            for name, centre, size, low, high in parts:
                up_down = min(high, top) - max(low, bottom)
                if up_down > TOUCH_MM:
                    note(key, min(up_down, _overlap(centre, size, centre_b, size_b)), f"{name} touched {what}")
        return found

    def _touches(self, pose: Pose) -> Optional[str]:
        """What the tool (or what it carries) would be in at `pose`, in words, if anything."""
        if self.world is None:
            return None
        found = self._contacts(pose)
        return max(found.values())[1] if found else None

    def _stop_before_contact(self, start: Pose, target: Pose, swing: bool) -> tuple[Pose, Optional[str]]:
        """Where a move from `start` to `target` has to stop: `target`, or the last point before the tool would go
        into something on the way (with what it touched). Already touching something (an object that settled
        against the fingers, say), it may move out of it or along it, but not further in."""
        if self.world is None:
            return target, None
        already = {key: depth for key, (depth, _) in self._contacts(start).items()}
        length = math.dist((start.x, start.y, start.z), (target.x, target.y, target.z))
        steps = max(1, int(max(length, abs(target.r - start.r)) / PATH_STEP_MM))
        previous = start
        for i in range(1, steps + 1):
            t = i / steps
            here = swing_point(start, target, t) if swing else Pose(
                x=start.x + (target.x - start.x) * t, y=start.y + (target.y - start.y) * t,
                z=start.z + (target.z - start.z) * t, r=start.r + (target.r - start.r) * t)
            for key, (depth, words) in self._contacts(here).items():
                if depth > already.get(key, 0.0) + 0.2:
                    return previous, words
            previous = here
        return target, None

    def _move_to_raw(self, pose: Pose, speed: Optional[float] = None) -> None:
        if self._estopped:
            raise RobotStopped("Robot is E-stopped.")
        wanted = self._clamp_to_bounds(pose)
        # the wrist's own limit, as the real controller keeps it (it stops with a limit alarm): the twin let any turn
        # through, so a move the real arm refuses passed here
        profile = robots.active()
        turn = profile.tool_turn(wanted.x, wanted.y, wanted.r)
        low, high = profile.tool_turn_limits_deg
        if not low - 0.5 <= turn <= high + 0.5:
            raise OutOfReach(f"The wrist would have to turn to {turn:+.0f}° for r {wanted.r:.0f}° at ({wanted.x:.0f}, "
                             f"{wanted.y:.0f}), past its limit ({low:.0f} to {high:.0f}°): the real arm would stop "
                             "with a limit alarm.")
        target, touched = self._stop_before_contact(self._pose, wanted, passes_near_base(self._pose, wanted))
        self._move(target, speed)
        if touched:
            raise Collision(f"Stopped at ({target.x:.0f}, {target.y:.0f}, {target.z:.0f}): {touched}. "
                            "The real arm would have pressed on it.")

    def _move(self, target: Pose, speed: Optional[float] = None) -> None:
        speed = speed or self.max_speed  # mm/s
        start = self._pose
        # Same route as the real driver: a straight line, or a swing round the base when a straight line
        # would cut across in front of it (the real arm can't reach that close to its base).
        swing = passes_near_base(start, target)
        dist = math.dist((start.x, start.y, start.z), (target.x, target.y, target.z))
        if swing:
            route = path_points(start, target, 24)
            dist = sum(math.dist((a.x, a.y, a.z), (b.x, b.y, b.z)) for a, b in zip(route, route[1:]))
        steps = max(1, int(dist / max(speed, 1.0) * 30))  # ~30 steps/sec
        self.motion = (start, target)       # read by the 3D view: where it is going, and by which route
        try:
            for i in range(1, steps + 1):
                if self._estopped:
                    raise RobotStopped("Robot was E-stopped during the move.")
                t = i / steps
                self._pose = swing_point(start, target, t) if swing else Pose(
                    x=start.x + (target.x - start.x) * t,
                    y=start.y + (target.y - start.y) * t,
                    z=start.z + (target.z - start.z) * t,
                    r=start.r + (target.r - start.r) * t,
                )
                self._track_wrist()
                self._apply_pose_to_visual()
                time.sleep(1.0 / 60.0)
            self._pose = target
            self._track_wrist()
        finally:
            self.motion = None

    def _track_wrist(self) -> None:
        """Follow the told wrist angle as a real one would: `wrist_gain` times it, lagging by up to half the slack."""
        told = self.gripper.wrist_turn(self._pose.r, self._pose.x, self._pose.y)
        want, half = self.wrist_gain * told, self.wrist_backlash_deg / 2.0
        if self._wrist_real is None:
            self._wrist_real = want
        elif want > self._wrist_real + half:
            self._wrist_real = want - half
        elif want < self._wrist_real - half:
            self._wrist_real = want + half

    def real_r(self) -> float:
        """Which way the fingers really point (as r), with the wrist's faults; exactly the pose's r without them."""
        if not (self.fingers_turned_deg or self.wrist_gain != 1.0 or self.wrist_backlash_deg):
            return self._pose.r
        if self._wrist_real is None:
            self._track_wrist()
        base = self._pose.r - self.gripper.wrist_turn(self._pose.r, self._pose.x, self._pose.y)
        return base + self._wrist_real + self.fingers_turned_deg

    def _real_r_at(self, pose: Pose) -> float:
        """Which way the fingers would really point at `pose` on the way there (the wrist's faults, its slack taken
        up from where it is now); exactly the pose's r without them. The fingers touch things where they really are:
        with the fingers turned 20 degrees and the app allowing for it, the told r is 18 degrees off the cube and the
        real fingers straight on it -- the touch check had them at the told r, and every grip "touched" the cube."""
        if not (self.fingers_turned_deg or self.wrist_gain != 1.0 or self.wrist_backlash_deg):
            return pose.r
        told = self.gripper.wrist_turn(pose.r, pose.x, pose.y)
        want, half = self.wrist_gain * told, self.wrist_backlash_deg / 2.0
        real = want if self._wrist_real is None else min(max(self._wrist_real, want - half), want + half)
        return pose.r - told + real + self.fingers_turned_deg

    def jog(self, dx: float, dy: float, dz: float) -> None:
        current = self._pose
        self.move_to(Pose(x=current.x + dx, y=current.y + dy, z=current.z + dz, r=current.r))

    def _nearest_graspable(self) -> Optional[str]:
        best, best_dist = None, GRASP_RADIUS_MM
        for object_id, meta in list(self.world.object_meta.items()):
            if meta.get("shape") == "tray":     # trays and bins stay put; only the objects can be picked up
                continue
            dist = math.dist(self.world.get_object_position_mm(object_id),
                              (self._pose.x, self._pose.y, self._pose.z))
            if dist <= best_dist:
                best, best_dist = object_id, dist
        return best

    def _held_hang(self) -> tuple[float, float]:
        """(how far the held object's centre is below the tip, its turn now): it turns with the gripper."""
        if self._held_grip is None:
            return self._suction_hang(), 0.0
        below, yaw, r = self._held_grip
        return below, yaw + (self.real_r() - r)

    def _suction_hang(self) -> float:
        """The suction cup holds an object by its top: its centre is half its height below the tip (it was 12 mm
        whatever the object, right only for a 25 mm cube: a 20 mm one hung 2 mm into what it was put down on)."""
        meta = self.world.object_meta.get(self._held) if self.world is not None and self._held else None
        return meta["size"][2] / 2.0 if meta else HELD_DROP_MM

    def _between_fingers(self) -> Optional[str]:
        """The object the two fingers close round, if they can: its centre about between them, the fingertips
        down its sides (below its top, not below its bottom) and its width along the way they close no more
        than they open. Otherwise None, with the reason in `last_grip_problem`."""
        spec = self.gripper
        direction = math.radians(spec.closing_direction(self.real_r()))
        ux, uy = math.cos(direction), math.sin(direction)
        self.last_grip_problem = "nothing between the fingers"
        for object_id, meta in list(self.world.object_meta.items()):
            if meta.get("shape") == "tray":
                continue
            ox, oy, oz = self.world.get_object_position_mm(object_id)
            gx, gy = self._grip_point()
            dx, dy = ox - gx, oy - gy
            along, sideways = dx * ux + dy * uy, -dx * uy + dy * ux
            if abs(along) > FINGER_CENTRE_MM or abs(sideways) > FINGER_CENTRE_MM:
                continue
            width, depth, height = meta["size"]
            top, bottom = oz + height / 2.0, oz - height / 2.0
            label = meta["label"]
            if self._pose.z > top - 1.0:
                self.last_grip_problem = f"the fingertips are above the {label} (at {self._pose.z:.0f}, top {top:.0f})"
                continue
            if self._pose.z < bottom - 1.0:
                continue
            yaw = self.world.get_object_yaw_deg(object_id)
            short, long_, long_angle = (width, depth, yaw + 90.0) if depth > width else (depth, width, yaw)
            wide = (width if meta.get("shape") in ("ball", "cylinder")        # round: its diameter, from any side
                    else across(short, long_, long_angle, math.degrees(direction)))
            if wide / 2.0 + abs(along) > spec.opening_mm / 2.0:
                if wide <= spec.opening_mm:     # it fits between them: they came down off its middle, onto its edge
                    self.last_grip_problem = (f"the fingers came down {abs(along):.1f} mm off the {label}'s middle, "
                                              f"onto its edge ({wide:.0f} mm across them, which open "
                                              f"{spec.opening_mm:.1f} mm)")
                else:
                    self.last_grip_problem = (f"the {label} is {wide:.0f} mm across the fingers, "
                                              f"which open {spec.opening_mm:.1f} mm")
                return None
            if meta.get("shape") not in ("ball", "cylinder"):
                # the fingers squeeze it square to them, as real ones do (a few degrees off, it turns till its sides
                # lie flat against them): a block with its narrow side across them, a cube either way
                closing = math.degrees(direction)
                if abs(width - depth) < 1.0:
                    off = (yaw - closing + 45.0) % 90.0 - 45.0
                else:
                    off = (long_angle - closing - 90.0 + 90.0) % 180.0 - 90.0
                if 0.05 < abs(off) <= SQUARE_UP_DEG:
                    yaw -= off
                    self._place_object(object_id, ox, oy, oz, yaw)
            self._held_grip = (self._pose.z - oz, yaw, self.real_r())
            self._held_along = sideways if self.keeps_place_along_fingers else 0.0
            self.last_grip_problem = ""
            return object_id
        return None

    def _place_object(self, object_id: str, x_mm: float, y_mm: float, z_mm: float, yaw_deg: float = 0.0) -> None:
        with pybullet_lock:
            p.resetBasePositionAndOrientation(
                self.world.object_ids[object_id], [x_mm / 1000.0, y_mm / 1000.0, z_mm / 1000.0],
                p.getQuaternionFromEuler([0, 0, math.radians(yaw_deg)]), physicsClientId=self.client)

    def open_gripper(self) -> None:
        self._gripper_closed = False
        self._emit("gripper", closed=False)
        self.jaw_stop_mm = None
        if self._held is not None and self.world is not None:
            # settle on the table, or on top of whatever is underneath (a cube, the tray floor)
            _, yaw = self._held_hang()
            x, y, rest_z = self.world.settle(self._held, *self._held_point())
            self._place_object(self._held, x, y, rest_z, yaw)
            self._held = None
            self._held_grip = None
            self._held_along = 0.0
        with pybullet_lock:
            self._recolor_tip()
        self._apply_pose_to_visual()

    def close_gripper(self) -> None:
        self._gripper_closed = True
        self._emit("gripper", closed=True)
        if self.world is not None and self._held is None:
            if self.gripper.fingers:
                self._held = self._between_fingers()
                if self._held is None:
                    self.jaw_stop_mm = self._jaws_stop_at()
                    if self.jaw_stop_mm is not None:
                        self.last_grip_problem += f"; the fingers stopped {self.jaw_stop_mm:.0f} mm apart, against it"
                    logger.info("Sim gripper closed on nothing: %s", self.last_grip_problem)
            else:
                self._held = self._nearest_graspable()
                if self._held is not None:
                    self._held_grip = (self._suction_hang(), self.world.get_object_yaw_deg(self._held),
                                       self.real_r())
        with pybullet_lock:
            self._recolor_tip()
        self._apply_pose_to_visual()

    def _jaws_stop_at(self) -> Optional[float]:
        """Closed without taking hold: where the fingers stop against what is in their way (an object too wide, or
        off to one side), or None if nothing is and they close all the way. They don't close through it."""
        gap = self.gripper.opening_mm
        try:
            while gap > self.gripper.shape.closed_gap_mm:
                self.jaw_stop_mm = max(self.gripper.shape.closed_gap_mm, gap - JAW_STEP_MM)
                if self._touches(self._pose) is not None:
                    return min(self.gripper.opening_mm, gap + JAW_STOP_MARGIN_MM)
                gap = self.jaw_stop_mm
            return None
        finally:
            self.jaw_stop_mm = None

    def stop(self) -> None:
        logger.warning("Sim E-STOP triggered")
        self._estopped = True
        self._emit("estop")
        self.open_gripper()

    def reset_estop(self) -> None:
        self._estopped = False

    def is_near(self, target_xyz: tuple[float, float, float], tol_mm: float = GRIP_PICK_TOLERANCE_MM) -> bool:
        here = self.get_pose()
        return math.dist((here.x, here.y, here.z), target_xyz) <= tol_mm

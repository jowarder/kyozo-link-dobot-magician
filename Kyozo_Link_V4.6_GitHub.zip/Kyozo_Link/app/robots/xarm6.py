"""The UFACTORY xArm 6 with the xArm Gripper: its profile, from UFACTORY's own description (twin/xarm6/model.py).

Its tool always points straight down, as the Dobot's does: the app's poses are x, y, z and the turn r, the same for
both robots. The arm is far bigger (267 mm to the shoulder, 700 mm reach), so its demo table and safety box are too.
"""
from __future__ import annotations

import math
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from app.robots.base import RobotProfile
from app.twin.kinematics import ArmGeometry
from app.twin.xarm6 import model

# the gap between the fingertips (mm) for the gripper's drive (rad), measured on UFACTORY's meshes (open: 86 mm in
# its manual; the mesh's 89 is its fingertips' rounded edges)
_DRIVE = (0.0, 0.17, 0.34, 0.51, 0.68, 0.85)
_GAP_MM = (88.9, 73.7, 56.8, 38.9, 20.3, 1.6)
OPEN_GAP_MM = 86.0
WORKING_OPEN_MM = 40.0  # how far it opens to pick and let go: up to 37 mm objects, and the fingers fit in a 72 mm tray
CLOSED_GAP_MM = 1.6


def drive_for_gap(gap_mm: float) -> float:
    """The gripper's drive (rad) for a gap between its fingertips (mm)."""
    return float(np.interp(gap_mm, _GAP_MM[::-1], _DRIVE[::-1]))


@dataclass
class XArmGeometry(ArmGeometry):
    joints: tuple = field(default=())   # J1-J6, radians


class XArm6Profile(RobotProfile):
    key = "xarm6"
    name = "UFACTORY xArm 6"
    short_name = "xArm"
    config_section = "xarm6"
    file_suffix = "_xarm6"
    joint_names = ("J1", "J2", "J3", "J4", "J5", "J6")
    joint_labels = {"J1": "Base", "J2": "Shoulder", "J3": "Elbow", "J4": "Forearm turn", "J5": "Wrist tilt",
                    "J6": "Tool turn"}
    joint_limits_deg = {f"J{i + 1}": (math.degrees(low), math.degrees(high))
                        for i, (low, high) in enumerate(model.LIMITS)}
    near_limit_deg = 5.0
    max_reach_mm = 650.0          # 700 mm is its reach to the flange in every direction; pointing down, about 700
    min_radius_mm = 200.0         # nearer the base, the gripper would come down onto the arm's own base
    base_height_mm = model.SHOULDER_MM
    table_x = (-200.0, 760.0)
    table_y = (-560.0, 560.0)
    tool_turn_limits_deg = (-180.0, 180.0)
    tool_turn_relative = False     # J6 turns the tool all the way round: r itself, not against the base
    demo_look_pose = (120.0, 380.0, 300.0)    # out of the camera's view: it looks from the front right
    demo_bounds = {"x": [-500.0, 650.0], "y": [-550.0, 550.0], "z": [0.0, 550.0]}
    default_max_speed = 150.0
    sim_body_scale = 3.0
    view_scale = 2.0
    scene_offset_mm = (120.0, 0.0)    # the scenes are laid out for the Dobot, mostly nearer than the xArm can reach
    # to the right of its working area, 560 mm up, some 60 degrees above the table: sees all of x 200-500, y -270-270
    # mm (the demo scenes), the sides of a stack too. (The Dobot's camera, moved 120 mm out, saw only 80% of it: a row
    # of cubes lined up to y -230 went out of its picture, and the red one was "not there". From 35 degrees up, a can's
    # round top looked oblong: "a grey block".)
    demo_camera = ((360.0, -340.0, 560.0), (350.0, 0.0, 0.0))
    demo_camera_fov_deg = 55.0    # the Orbbec Gemini 335's (its colour camera's: 55 x 86; its depth sees 65 x 90)
    detect_reach_mm = (130.0, 700.0)
    arm_clearance_mm = 60.0       # its links are some 90 mm round
    gripper_body_mm = 80.0

    def __init__(self) -> None:
        self._last: Optional[np.ndarray] = None      # the arm's last pose: the next one is the solution nearest it
        self.open_gap_mm = WORKING_OPEN_MM           # how far apart the fingers are drawn open (the gripper setting)
        self._cache: OrderedDict = OrderedDict()

    def _solve(self, x: float, y: float, z: float, r: float) -> tuple[np.ndarray, bool]:
        key = (round(x, 2), round(y, 2), round(z, 2), round(r, 2))
        hit = self._cache.get(key)
        if hit is not None:
            self._cache.move_to_end(key)
            return hit
        q, ok = model.reach(x, y, z, r, seed=self._last)
        self._cache[key] = (q, ok)
        if len(self._cache) > 4096:
            self._cache.popitem(last=False)
        return q, ok

    def geometry(self, x, y, z, r=0.0, table_z=0.0):
        q, ok = self._solve(x, y, z - table_z, r)
        self._last = q
        frames = model.link_transforms(q)
        up = lambda m: (float(m[0, 3]), float(m[1, 3]), float(m[2, 3]) + table_z)  # noqa: E731
        tool = frames["link6"] @ model._move(0.0, 0.0, model.TCP_MM)
        return XArmGeometry(shoulder=up(frames["link2"]), elbow=up(frames["link3"]), wrist=up(frames["link5"]),
                            tool_corner=up(frames["link6"]), tcp=up(tool), reachable=ok,
                            joints=tuple(float(v) for v in q))

    def joints(self, geometry, r=0.0):
        q = getattr(geometry, "joints", ()) or tuple(self._solve(*geometry.tcp, r)[0])
        return {name: math.degrees(v) for name, v in zip(self.joint_names, q)}

    def within_limits(self, x, y, z, r=0.0):
        if math.hypot(x, y) < self.min_radius_mm:
            return False
        return model.solve(x, y, z, r) is not None

    def reach_band(self, z):
        band = [d for d in range(int(self.min_radius_mm), int(self.max_reach_mm) + 1, 5)
                if model.solve(float(d), 0.0, z, 0.0) is not None]
        return (float(band[0]), float(band[-1])) if band else None

    def posed_mesh(self, geometry, r, gripper_closed, held_width_mm=None, jaw_stop_mm=None):
        q = getattr(geometry, "joints", ()) or tuple(self._solve(*geometry.tcp, r)[0])
        if not gripper_closed:
            gap = self.open_gap_mm
        elif held_width_mm:
            gap = held_width_mm
        else:
            gap = jaw_stop_mm if jaw_stop_mm else CLOSED_GAP_MM
        mesh = model.posed_triangles(np.asarray(q, float), drive_for_gap(gap))
        if mesh is None:
            return None
        triangles, colours, tool, normals = mesh
        lift = geometry.tcp[2] - float(model.tool_frame(np.asarray(q, float))[2, 3])   # table_z, if any
        if abs(lift) > 1e-9:
            triangles = triangles + np.array([0.0, 0.0, lift])
        return triangles, colours, tool, normals

    def part_slices(self):
        parts = model.load_parts()
        if parts is None:
            return []
        slices, start = [], 0
        for vertices, faces, *_ in parts.values():
            slices.append(slice(start, start + len(faces)))
            start += len(faces)
        return slices

    def gripper_defaults(self):
        """The xArm Gripper (manual v1.6.1: 0-86 mm stroke), measured on UFACTORY's meshes from the fingertips up:
        14 mm thick, 32 mm wide fingers; the linkage beside them from the grip depth to the body, reaching out up to
        46 mm past each finger's inside (its knuckles); the 70 x 100 mm body from 69 to 181 mm up; the arm's last
        link (78 mm round) above it. It closes across its own y: along the robot's y when r = 0. J6 turns it all
        the way round, on its own, so the turn r is the wrist's angle itself."""
        from app.hardware.gripper import GripperSpec, ToolShape
        shape = ToolShape(finger_thickness_mm=14.0, finger_width_mm=32.0, bridge_out_mm=46.0, bridge_width_mm=32.0,
                          bridge_top_mm=69.0, body_above_mm=69.0, body_top_mm=181.0, body_along_mm=(-50.3, 50.3),
                          body_across_mm=(-35.1, 35.1), stem_mm=78.0, stem_top_mm=215.0, closed_gap_mm=CLOSED_GAP_MM)
        return GripperSpec(kind="gripper", opening_mm=WORKING_OPEN_MM, margin_mm=3.0, finger_depth_mm=20.0,
                           jaw_axis_deg=90.0, j4_limits_deg=(-360.0, 360.0), wrist_relative=False, wrist_name="J6",
                           shape=shape)

"""What the app needs to know about a robot arm: the questions each robot's profile answers for its own arm."""
from __future__ import annotations

from typing import Optional

import numpy as np

from app.twin.kinematics import ArmGeometry


class RobotProfile:
    key: str = ""
    name: str = ""
    short_name: str = ""                # "the Dobot", "the xArm" in messages
    config_section: str = "robot"     # its settings in config.yaml
    file_suffix: str = ""             # its calibration and poses files: calibration{suffix}.json, poses{suffix}/
    joint_names: tuple[str, ...] = ()
    joint_labels: dict[str, str] = {}  # what each joint moves, for the gauges
    joint_limits_deg: dict[str, tuple[float, float]] = {}
    near_limit_deg = 5.0
    max_reach_mm = 300.0               # the furthest the app asks it to reach from its base
    min_radius_mm = 160.0              # nearer the base than this it can't reach down to the table
    base_height_mm = 131.3             # its first moving joint above the table
    table_x = (-80.0, 380.0)           # the demo's table
    table_y = (-320.0, 320.0)
    tool_turn_limits_deg = (-90.0, 90.0)   # the pose's r the wrist allows (relative: see tool_turn)
    tool_turn_relative = True          # r limited relative to the base's turn (the Dobot: J4 = r - J1)
    demo_look_pose = (120.0, -160.0, 90.0)
    demo_bounds = {"x": [-300.0, 307.0], "y": [-300.0, 300.0], "z": [0.0, 300.0]}
    default_max_speed = 200.0
    sim_body_scale = 1.0               # the simulated camera's stand-in arm: thicker parts for a bigger arm
    view_scale = 1.0                   # the 3D view's preset views, further out for a bigger arm
    scene_offset_mm = (0.0, 0.0)       # the demo's scenes (and camera) moved out from the base by this
    # the demo's camera: (where it is, where it looks), mm; None: as on the Dobot's bench, moved by scene_offset_mm
    demo_camera: Optional[tuple] = None
    # ...and its field of view, top to bottom. The Dobot's bench camera stays as it was set up and tested: with the
    # real Gemini 335's 55 degrees from the same place, each object was a third smaller in the picture, a 24 mm can
    # measured 21.8, and the calibration found 7 of its 8 marker points
    demo_camera_fov_deg = 38.0
    # the depth camera's object finder (vision/depth_detector.py): where objects can be, and how near the arm a point
    # is taken for the arm
    detect_reach_mm = (110.0, 330.0)
    arm_clearance_mm = 32.0
    gripper_body_mm = 75.0

    def geometry(self, x: float, y: float, z: float, r: float = 0.0, table_z: float = 0.0) -> ArmGeometry:
        """Where its parts are with the tool point at (x, y, z) turned by r: shoulder, elbow, wrist, tool corner
        (the tool's mount), the tool point, and whether it gets there. `table_z`: the table's height in the frame
        of x, y, z (the model's heights are from the table its base stands on)."""
        raise NotImplementedError

    def joints(self, geometry: ArmGeometry, r: float = 0.0) -> dict[str, float]:
        """Each joint's angle in degrees, in the robot's own conventions (see joint_limits_deg)."""
        raise NotImplementedError

    def joint_status(self, name: str, angle: float) -> str:
        """"ok", "near" (within near_limit_deg of a limit) or "over" (past one)."""
        low, high = self.joint_limits_deg[name]
        if angle < low or angle > high:
            return "over"
        if angle < low + self.near_limit_deg or angle > high - self.near_limit_deg:
            return "near"
        return "ok"

    def within_limits(self, x: float, y: float, z: float, r: float = 0.0) -> bool:
        """Whether the tool point can be at (x, y, z), heights from the table, with its joints within their limits."""
        raise NotImplementedError

    def reach_band(self, z: float) -> Optional[tuple[float, float]]:
        """(nearest, farthest) distance from the base the tool point can be at height `z`, or None if nowhere."""
        raise NotImplementedError

    def tool_turn(self, x: float, y: float, r: float) -> float:
        """The wrist joint's angle for the pose's r at (x, y), which tool_turn_limits_deg limits."""
        if not self.tool_turn_relative:
            return r
        import math
        j1 = math.degrees(math.atan2(y, x)) if math.hypot(x, y) > 1e-6 else 0.0
        return r - j1

    def posed_mesh(self, geometry: ArmGeometry, r: float, gripper_closed: bool,
                   held_width_mm: Optional[float] = None,
                   jaw_stop_mm: Optional[float] = None) -> Optional[tuple[np.ndarray, np.ndarray, np.ndarray]]:
        """(triangles (N,3,3) mm, colours (N,3), is_tool (N,) bool[, shading normals (N,3)]) for the whole arm, or None
        without its meshes. The optional fourth: each triangle's smoothed normal for the light (else its own)."""
        return None

    def part_slices(self) -> list[slice]:
        """Which of posed_mesh's triangles belong to each part (one shadow each)."""
        return []

    open_gap_mm: Optional[float] = None    # how far apart the fingers are drawn open (None: the model's own)

    def gripper_defaults(self):
        """Its own two-finger gripper (GripperSpec), before config.yaml's settings."""
        from app.hardware.gripper import GripperSpec
        return GripperSpec()

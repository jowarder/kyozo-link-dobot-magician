"""The robots the app can drive, and which one this run drives.

Each robot has a profile (dobot.py, xarm6.py) that answers the same questions for its own arm: where its parts are
with the tool point at a spot, its joints' angles and limits, where it can reach, its 3D shape. The rest of the app
asks `active()` and so works with either. The robot is chosen at start-up (config.yaml's `robot_model`, the
toolbar's Robot list) and stays for the run: changing it restarts the app, as changing the mode does.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.robots.base import RobotProfile

ROBOT_NAMES = {"dobot_magician": "Dobot Magician", "xarm6": "UFACTORY xArm 6"}
DEFAULT_ROBOT = "dobot_magician"

_active: "RobotProfile | None" = None


def profile(key: str) -> "RobotProfile":
    if key == "xarm6":
        from app.robots.xarm6 import XArm6Profile
        return XArm6Profile()
    if key == "dobot_magician":
        from app.robots.dobot import DobotProfile
        return DobotProfile()
    raise ValueError(f"No robot called {key!r}; the robots are {', '.join(ROBOT_NAMES)}")


def set_active(key: str) -> "RobotProfile":
    global _active
    _active = profile(key)
    return _active


def active() -> "RobotProfile":
    """The robot this run drives (the Dobot until set_active says otherwise)."""
    global _active
    if _active is None:
        _active = profile(DEFAULT_ROBOT)
    return _active


def robot_key(config: dict) -> str:
    key = config.get("robot_model", DEFAULT_ROBOT)
    return key if key in ROBOT_NAMES else DEFAULT_ROBOT

"""The Dobot Magician: its profile, from the app's own model of it (twin/kinematics.py, twin/magician_model.py)."""
from __future__ import annotations

from typing import Optional

from app.robots.base import RobotProfile
from app.twin import kinematics, magician_model


class DobotProfile(RobotProfile):
    key = "dobot_magician"
    name = "Dobot Magician"
    short_name = "Dobot"
    config_section = "robot"
    file_suffix = ""
    joint_names = ("J1", "J2", "J3", "J4")
    joint_labels = {"J1": "Base", "J2": "Rear arm", "J3": "Forearm", "J4": "Tool"}
    joint_limits_deg = kinematics.JOINT_LIMITS_DEG
    near_limit_deg = kinematics.NEAR_LIMIT_DEG
    max_reach_mm = 300.0
    min_radius_mm = 160.0
    base_height_mm = kinematics.SHOULDER_H
    tool_turn_limits_deg = kinematics.JOINT_LIMITS_DEG["J4"]
    tool_turn_relative = True

    def geometry(self, x, y, z, r=0.0, table_z=0.0):
        return kinematics.arm_geometry(x, y, z, table_z=table_z)

    def joints(self, geometry, r=0.0):
        return kinematics.dobot_joints(geometry, r)

    def within_limits(self, x, y, z, r=0.0):
        return kinematics.within_limits(x, y, z)

    def reach_band(self, z):
        return kinematics.reach_band(z)

    def posed_mesh(self, geometry, r, gripper_closed, held_width_mm=None, jaw_stop_mm=None):
        return magician_model.posed_triangles(
            geometry, r, magician_model.jaw_opening(gripper_closed, held_width_mm if held_width_mm else jaw_stop_mm))

    def part_slices(self):
        return magician_model.part_slices()

"""How much memory this program and the whole PC are using -- to tell "the app is big" from "the
language model is big" when the computer feels full. Windows only; elsewhere the answers are None."""
from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes
from typing import Optional

NORMAL_APP_MB = 400.0     # the app itself normally stays around 100-300 MB; the model is what is big
ALARM_APP_MB = 3000.0     # far beyond normal: something is wrong in the app


class _ProcessMemory(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


class _SystemMemory(ctypes.Structure):
    _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def app_memory_mb() -> Optional[float]:
    """Memory this program is using right now (its working set), in MB."""
    if sys.platform != "win32":
        return None
    try:
        kernel, psapi = ctypes.windll.kernel32, ctypes.windll.psapi
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(_ProcessMemory), wintypes.DWORD]
        counters = _ProcessMemory()
        counters.cb = ctypes.sizeof(counters)
        if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
            return None
        return counters.WorkingSetSize / 1e6
    except (OSError, AttributeError):
        return None


def system_memory_gb() -> Optional[tuple[float, float]]:
    """(total, available) memory of the whole PC, in GB."""
    if sys.platform != "win32":
        return None
    try:
        status = _SystemMemory()
        status.dwLength = ctypes.sizeof(status)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return None
        return status.ullTotalPhys / 1e9, status.ullAvailPhys / 1e9
    except (OSError, AttributeError):
        return None

"""Writing files so that a crash or power cut can never leave a half-written one.

The new content goes to a temporary file next to the real one, and only when it is complete is it
swapped into place (an atomic operation on Windows and Linux). So the file on disk is always either
entirely the old version or entirely the new one.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path


def atomic_write_bytes(path: str | Path, data: bytes) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(dir=target.parent, prefix=target.name + ".", suffix=".tmp")
    try:
        with os.fdopen(handle, "wb") as temp:
            temp.write(data)
            temp.flush()
            os.fsync(temp.fileno())
        os.replace(temp_name, target)
    except BaseException:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def atomic_write_text(path: str | Path, text: str, encoding: str = "utf-8") -> None:
    atomic_write_bytes(path, text.encode(encoding))


def set_aside_damaged(path: str | Path) -> Path | None:
    """Move an unreadable file out of the way (to `<name>.bad`) so it isn't tripped over on every start
    but is still there to look at. Returns the new path, or None if it couldn't be moved."""
    source = Path(path)
    target = source.with_name(source.name + ".bad")
    try:
        os.replace(source, target)
        return target
    except OSError:
        return None

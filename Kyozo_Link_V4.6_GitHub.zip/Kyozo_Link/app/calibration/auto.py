"""Automatic calibration with the printed marker on the tool.

The robot carries the marker through a spread of positions; at each, the camera finds it
(where the camera sees it) and the robot reports where it is. Those pairs go to the same
solver as the by-hand method.

Two things the marker can't tell us by itself, and how they are handled:

* It is not at the tip. Straight above the tip is fine (that is only a height, which the
  table-touch step removes). But if it is stuck a little to one side, every position is off
  by that much sideways. So the wrist is turned at one spot: an off-centre marker swings in a
  circle round the tool's axis, and the size and direction of that swing give the sideways
  offset, which is then taken out. Nothing is measured by hand.
* The robot's wrist rotation might be the opposite way round from what we assume, so both
  directions are tried and the one that fits is used.
"""
from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from app.calibration.boardless import BoardlessCalibrator, SolveResult
from app.calibration.guidance import build_cells
from app.calibration.marker import detect_marker
from app.hardware.interfaces import OutOfReach, Pose
from app.vision.locator import camera_point_to_robot, pixel_to_camera_point

logger = logging.getLogger(__name__)

MIN_FOUND = 6                   # fewer marker sightings than this can't give a trustworthy calibration
MAX_REFUSED_IN_A_ROW = 2        # sweep positions the arm can't reach, one after another, before giving up
HEIGHT_STEP_MM = 30.0           # the sweep alternates between the start height and this much above it
REACH_FRACTION = 0.95           # the sweep stays a little inside the reach limit: reach shrinks as the arm goes higher
WRIST_CANDIDATES = (-60.0, -40.0, -20.0, 20.0, 40.0, 60.0)
WRIST_LIMIT_DEG = 80.0          # the wrist is never asked to turn beyond this (the real one runs out at about 90)
FLUSH_FRAMES = 3                # a real camera queues pictures: skip the oldest so the one used is after the move
MAX_PLAUSIBLE_OFFSET_MM = 80.0
MAX_WRIST_RESIDUAL_MM = 3.0


@dataclass
class Sighting:
    robot_xyz: tuple[float, float, float]
    centre_uv: tuple[float, float]
    depth_mm: float
    rgb: Optional[np.ndarray] = None      # the picture it was found in (for the session record)
    depth: Optional[np.ndarray] = None


@dataclass
class WristResult:
    offset_xy_mm: tuple[float, float]     # how far the marker sits from the tool's axis, in robot axes at the start angle
    direction: int                        # +1 if positive wrist angles turn counter-clockwise from above, else -1
    residual_mm: float                    # how well the swing fits a circle (small is good)
    angles: list[float]

    @property
    def distance_mm(self) -> float:
        return math.hypot(*self.offset_xy_mm)


@dataclass
class AutoOutcome:
    sightings: list[Sighting] = field(default_factory=list)
    poses_tried: int = 0
    solve: Optional[SolveResult] = None
    wrist: Optional[WristResult] = None
    wrist_note: str = ""
    transform: Optional[np.ndarray] = None    # after the wrist correction; the table-height step is still to do
    cancelled: bool = False

    @property
    def skipped(self) -> int:
        return self.poses_tried - len(self.sightings)


# ---- planning ---------------------------------------------------------------------------------------------
def plan_sweep(bounds: dict, reach_mm: float, start: Pose, max_poses: int = 14) -> list[Pose]:
    """Where to carry the marker: the middle of each reachable part of the workspace, visited in
    a short route, alternating between two heights. Never below the height it starts at, so a
    tip parked safely above the table stays safely above it."""
    cells = [c.centre for c in build_cells(bounds, reach_mm)
             if c.usable and math.hypot(*c.centre) <= REACH_FRACTION * reach_mm]
    route, here = [], (start.x, start.y)
    while cells and len(route) < max_poses:
        nearest = min(cells, key=lambda c: math.dist(c, here))
        cells.remove(nearest)
        route.append(nearest)
        here = nearest
    z_top = bounds["z"][1]
    poses = [Pose(x, y, min(start.z + (HEIGHT_STEP_MM if i % 2 else 0.0), z_top), start.r)
             for i, (x, y) in enumerate(route)]
    return [Pose(start.x, start.y, start.z, start.r)] + poses


# ---- seeing the marker ----------------------------------------------------------------------------------------
def observe_marker(camera, marker_mm: float, frames: int = 3) -> Optional[Sighting]:
    """Find the marker in a few consecutive pictures; the median position, if found in most of them."""
    for _ in range(FLUSH_FRAMES):
        camera.get_frame()
    seen, last = [], None
    for _ in range(frames):
        frame = camera.get_frame()
        last = frame
        found = detect_marker(frame.rgb, frame.depth, frame.intrinsics, marker_mm)
        if found is not None:
            seen.append(found)
    if len(seen) * 2 < frames or last is None:
        return None
    u = float(np.median([d.centre_uv[0] for d in seen]))
    v = float(np.median([d.centre_uv[1] for d in seen]))
    depth = float(np.median([d.depth_mm for d in seen]))
    # copies: a real camera's picture memory can be reused once the next picture arrives
    return Sighting((0.0, 0.0, 0.0), (u, v), depth, last.rgb.copy(),
                    None if last.depth is None else last.depth.copy())


def sweep(robot, camera, poses: list[Pose], marker_mm: float, settle_s: float = 0.5,
          on_progress: Optional[Callable[[str], None]] = None,
          cancel: Optional[Callable[[], bool]] = None) -> tuple[list[Sighting], int]:
    """Visit each pose and record where the marker is seen. Returns (sightings, poses tried)."""
    say = on_progress or (lambda message: None)
    sightings, tried, refused_in_a_row = [], 0, 0
    for index, pose in enumerate(poses):
        if cancel is not None and cancel():
            break
        say(f"Sweeping: position {index + 1} of {len(poses)} ({len(sightings)} sightings so far)...")
        try:
            robot.move_to(pose)
        except OutOfReach as exc:
            # The arm stopped short somewhere it can be (alarm already cleared): a picture from there would be
            # recorded against the wrong target, so skip this spot and go on to the next. Two in a row means
            # something is wrong with the setup, not with one spot: stop rather than try every other one.
            refused_in_a_row += 1
            logger.warning("Skipping (%.0f, %.0f, %.0f): %s", pose.x, pose.y, pose.z, exc)
            if refused_in_a_row >= MAX_REFUSED_IN_A_ROW:
                raise RuntimeError(f"the arm couldn't reach {refused_in_a_row} positions in a row, so the sweep was "
                                   f"stopped. Last: {exc}") from exc
            continue
        refused_in_a_row = 0
        time.sleep(settle_s)
        tried += 1
        sighting = observe_marker(camera, marker_mm)
        if sighting is None:
            logger.info("Marker not found at (%.0f, %.0f, %.0f)", pose.x, pose.y, pose.z)
            continue
        actual = robot.get_pose()
        sighting.robot_xyz = (actual.x, actual.y, actual.z)
        sightings.append(sighting)
    return sightings, tried


# ---- the sideways offset, from turning the wrist -------------------------------------------------------------------
def solve_wrist_offset(rotations_deg: list[float], swings_xy: list[tuple[float, float]]) -> Optional[WristResult]:
    """`swings_xy[i]` is where the marker appears (through the calibration made with the wrist
    at its start angle), relative to the tip, after turning the wrist by `rotations_deg[i]`.
    Turning by an angle carries an offset `d` to `R(angle) d`, so the swing is `(R(angle) - I) d`:
    linear in `d`. Try both turning directions; keep the one that fits."""
    best: Optional[WristResult] = None
    for direction in (1, -1):
        rows, values = [], []
        for angle, (sx, sy) in zip(rotations_deg, swings_xy):
            a = math.radians(direction * angle)
            c, s = math.cos(a) - 1.0, math.sin(a)
            rows += [[c, -s], [s, c]]
            values += [sx, sy]
        if not rows:
            return None
        solution, *_ = np.linalg.lstsq(np.array(rows), np.array(values), rcond=None)
        fitted = np.array(rows) @ solution
        residual = float(np.sqrt(np.mean((fitted - np.array(values)) ** 2)))
        candidate = WristResult((float(solution[0]), float(solution[1])), direction, residual, list(rotations_deg))
        if best is None or candidate.residual_mm < best.residual_mm:
            best = candidate
    return best


def wrist_angles_for(start_angle: float) -> tuple[float, ...]:
    """Turn amounts to try from `start_angle`, all keeping the wrist within its safe range."""
    return tuple(a for a in WRIST_CANDIDATES if -WRIST_LIMIT_DEG <= start_angle + a <= WRIST_LIMIT_DEG)


def measure_wrist_offset(robot, camera, transform: np.ndarray, marker_mm: float, at: Pose,
                         angles: Optional[tuple[float, ...]] = None, settle_s: float = 0.5,
                         on_progress: Optional[Callable[[str], None]] = None) -> tuple[Optional[WristResult], str]:
    """Turn the wrist through `angles` at one spot. `transform` was made with the wrist at
    `at.r`. Returns (offset, note); the offset is None (with the reason in the note) if it
    couldn't be worked out."""
    say = on_progress or (lambda message: None)
    angles = angles if angles is not None else wrist_angles_for(at.r)
    rotations, swings = [], []
    for angle in angles:
        say(f"Turning the wrist to find how far off-centre the marker is ({angle:+.0f} degrees)...")
        try:
            robot.move_to(Pose(at.x, at.y, at.z, at.r + angle))
        except OutOfReach as exc:
            logger.warning("Wrist turn %+.0f skipped: %s", angle, exc)
            continue
        time.sleep(settle_s)
        sighting = observe_marker(camera, marker_mm)
        if sighting is None:
            continue
        tip = robot.get_pose()
        cam = pixel_to_camera_point(sighting.centre_uv[0], sighting.centre_uv[1], sighting.depth_mm,
                                    camera.get_intrinsics())
        seen = camera_point_to_robot(cam, transform)
        rotations.append(angle)
        swings.append((seen[0] - tip.x, seen[1] - tip.y))
    robot.move_to(at)
    if len(rotations) < 3:
        return None, f"the marker was found at only {len(rotations)} of {len(angles)} wrist angles"
    result = solve_wrist_offset(rotations, swings)
    if result is None:
        return None, "the wrist test gave no usable readings"
    if result.residual_mm > MAX_WRIST_RESIDUAL_MM:
        return None, (f"the marker's swing didn't fit a circle ({result.residual_mm:.1f} mm off); "
                      "is the marker stuck firmly and flat?")
    if result.distance_mm > MAX_PLAUSIBLE_OFFSET_MM:
        return None, f"the marker seems {result.distance_mm:.0f} mm from the tool's axis, which is implausible"
    return result, ""


def apply_wrist_offset(transform: np.ndarray, wrist: WristResult) -> np.ndarray:
    """The calibration was made with the marker's offset baked in; put it back where it belongs."""
    corrected = transform.copy()
    corrected[0, 3] += wrist.offset_xy_mm[0]
    corrected[1, 3] += wrist.offset_xy_mm[1]
    return corrected


# ---- the whole thing -----------------------------------------------------------------------------------------------
def run_auto_calibration(robot, camera, bounds: dict, reach_mm: float, marker_mm: float = 30.0,
                         on_progress: Optional[Callable[[str], None]] = None,
                         cancel: Optional[Callable[[], bool]] = None) -> AutoOutcome:
    """Sweep, solve, then find and remove the marker's sideways offset. Moves the robot: call
    from a worker thread. The tip should be parked safely above the table first; the sweep never
    goes below that height."""
    say = on_progress or (lambda message: None)
    start = robot.get_pose()
    outcome = AutoOutcome()
    poses = plan_sweep(bounds, reach_mm, start)
    outcome.sightings, outcome.poses_tried = sweep(robot, camera, poses, marker_mm, on_progress=say, cancel=cancel)
    if cancel is not None and cancel():
        outcome.cancelled = True
        return outcome
    if len(outcome.sightings) < MIN_FOUND:
        return outcome   # the caller explains: the marker was found too rarely

    say("Solving...")
    calibrator = BoardlessCalibrator(intrinsics=camera.get_intrinsics())
    for s in outcome.sightings:
        calibrator.add_sample(s.robot_xyz, s.centre_uv, s.depth_mm)
    outcome.solve = calibrator.solve_detailed()
    outcome.transform = outcome.solve.transform

    middle = Pose(start.x, start.y, start.z, start.r)
    outcome.wrist, outcome.wrist_note = measure_wrist_offset(robot, camera, outcome.transform, marker_mm, middle,
                                                             on_progress=say)
    if outcome.wrist is not None:
        outcome.transform = apply_wrist_offset(outcome.transform, outcome.wrist)
    robot.move_to(start)
    return outcome

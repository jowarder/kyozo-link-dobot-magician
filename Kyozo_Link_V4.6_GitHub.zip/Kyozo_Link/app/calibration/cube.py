"""Calibration with a cube: the robot puts a cube it holds at spots across the table, and the depth camera finds it.

No marker and no clicking. The user lowers the open gripper round a cube until the fingertips touch the table, presses
"Fingertips on the table" (the table's height, by contact; the arm then rises 1 mm), closes the gripper and starts.

Phase 1, on the table (`run_cube_calibration`):

1. the wrist is put in its middle (the gripper along the arm) and stays there; a squeeze in place centres the cube
   across the fingers;
2. it is put down at 10-20 spots spread over the part of the table the camera sees, the wrist turned a different way
   at each (so a tool whose fingers' middle is off the wrist's axis shows up). At each, the arm moves out of the way
   and the camera finds the cube by comparing the depth picture with one taken before it was there (no calibration
   needed for that); the robot takes it back where it put it, by its own coordinates, so it can't lose it;
3. it is put back at the first spot once more: if the camera then sees it somewhere else, it slipped in the gripper
   (or the camera moved), and nothing is kept;
4. the solve, in two parts: the table's surface, fitted to thousands of depth points round the spots, gives the
   camera's tilt and height (the robot stands on the table, so the table is z = the height touched); the cube's
   positions give where it is sideways and its turn. Several ways are worked out from the same pictures -- the depth
   picture lined up with the colour camera or the depth sensor's own, with or without a scale for the camera's
   distances -- and the one that predicts each spot best from the others is kept. In "Precise" mode a gentle correction over the table (correction.py) is added when that
   predicts clearly better still.

Phase 2, the heights (`run_cube_stacks`), with 1 or 2 more cubes the user puts on the table: the cubes are stacked
2 or 3 high at a few spots, one level at a time, each level checked by the camera before the next goes on. The tower
moves from spot to spot top first; only the new cubes' first places come from the camera.

The cube's size is only used here (for the stacks' heights); nothing about it is kept for picking other objects.
"""
from __future__ import annotations

import functools
import logging
import math
import os
import pickle
import time
from contextlib import contextmanager
import dataclasses
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np

from app.calibration.correction import XYCorrection
from app.calibration.guidance import min_radius_mm, workspace_region
from app.calibration.solver import solve_rigid_transform
from app.hardware.interfaces import Intrinsics, Pose, RobotNeedsPerson, RobotStopped
from app.hardware.tool_centre import turned
from app.vision.locator import measure_footprint
from app.vision.table import median_depth, median_of

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CubeMode:
    spots: int
    angles: tuple            # the wrist's turns (degrees from how the cube was gripped), shared out over the spots
    pass_mm: float           # kept only if a spot is typically predicted this well from the others
    correction: bool         # try the correction over the table


# The wrist stays in its middle (the gripper along the arm) at every spot: turned +-40 degrees at the lab, a gripper
# whose middle is ~13 mm off the wrist's axis put the cube ~9 mm from where the robot thought. The tool still turns
# from spot to spot as the arm swings round its base (-60 to +60 degrees), and that is enough to measure the offset.
# The pass limit: 2.0 mm in every mode (the user's choice, 2026-10-12: up to 2 mm is fine for the tasks; it was
# 1.0 / 1.5 / 1.5, and the real Dobot's own repeatability -- a cube put back at one spot landed 1.0-1.8 mm apart --
# left little room under 1.5)
MODES = {
    "precise": CubeMode(spots=20, angles=(0.0,), pass_mm=2.0, correction=True),
    "quick": CubeMode(spots=10, angles=(0.0,), pass_mm=2.0, correction=False),
    "fast": CubeMode(spots=6, angles=(0.0,), pass_mm=2.0, correction=False),   # the fewest that measure something
}
OFFSET_SPREAD_DEG = 30.0    # the tool's turns must spread this much for the gripper's offset to be measured
SPOTS = MODES["quick"].spots
PASS_MM = MODES["quick"].pass_mm
MIN_SPOTS = 6               # fewer found than this: no calibration (one fewer when only 6 are tried: Fast)
FEWEST_SPOTS = 5            # never fewer than this
CORRECTION_MIN_SPOTS = 14   # the correction's 12 numbers need at least this many spots
CORRECTION_GAIN = 0.85      # ...and must bring the typical error to this share of what it was, or better
SAVE_ANYWAY_MAX_MM = 3.0    # a run over its mode's limit only by its typical error may still be saved, up to this

GRIP_ABOVE_TABLE_MM = 1.0   # the user's grip: the fingertips this far above the table (after touching it)
REPICK_UP_MM = 1.0          # taken back from the table this much higher than the first grip (an uneven table)
GAP_MM = 0.5                # let go this high above the table (where it is there: see TableHeights). (At 1 mm,
                            # and the Dobot standing 2-3 mm higher stretched out, the cube dropped and turned)
STACK_GAP_MM = 2.5          # ...and this high above the cube it goes on (its size is only known to a mm or so)
STACK_REPICK_MM = 3.0       # a stacked cube is taken with the fingertips this far above the cube under it

LIFT_MM = 45.0              # carried this high above where it is put down
AWAY_UP_MM = 110.0          # the arm waits this high above the grip, out of the camera's way, while it looks
FRAMES = 20                 # depth pictures per look (their median): noise falls with more
SETTLE_S = 0.6              # wait this long after the arm stops before looking (it shakes a little)

NEAR_BASE_MARGIN_MM = 30.0  # spots no nearer the base than its inner limit plus this (the real Dobot refused
                            # moves to (150, 80) and (100, 155), 170-185 mm out, that its model allows)
WRIST_MARGIN_DEG = 12.0     # the wrist's turns kept this far inside its range (the same refusals: J4 near -90)
NEW_MM = 5.0                # nearer than before by this much: something new there
MIN_CUBE_PX = 60
TOP_BAND_MM = 3.0           # a cube's top: what is this near its highest part
RING_PX = (4, 18)           # the table round it: this many pixels out from its edge (inner, outer)
TILT_MAX_DEG = 30.0         # a cube whose top leans more than this landed crooked: that spot is left out... (flat
                            # cubes read 4-20 degrees on the real camera: the height check catches a crooked one)
TILT_FIT_MM = 0.8           # ...when the top's points lie this close to a plane (a real camera's noise on a 20 mm
TILT_POINTS = 40            # top made 6-59 degrees of "lean" out of flat cubes: every spot was left out)
HEIGHT_TOL_MM = 4.0         # a cube seen this much taller or shorter than the others landed on something
WIDTH_TOL_MM = 1.5          # (xArm) gripped this much wider or narrower than usual: off-centre, left out
SLIP_MM = 1.5               # put back at the first spot, seen this far from where it was the first time: said...
SLIP_FAIL_MM = 3.0          # ...and this far: no calibration (the cube moved in the fingers, or the arm lost its place)
TURN_FIX_MIN_DEG = 3.0      # the cube turned this much as it was let go: the wrist turns to match to take it back
TURN_FIX_MAX_DEG = 15.0     # (at most this: the Dobot's fingers open 27.5 mm, a 25 mm cube turned 6 degrees is wider)
CHECK_EVERY = 5             # back at the first spot after every this many: has the arm kept its place? (found out
                            # then, not after 20 spots)
STILL_THERE_MM = 6.0        # taken back, the cube's top still seen this near where it was: it wasn't picked up
WORST_MM = 3.0              # a spot left out missed by more than this... (the walk-through's "worst: under about 3")
WORST_SHARE = 0.2           # ...at more of the spots used than this (and at least 2): no calibration, however typical
                            # the rest (the median alone passed 6 spots at 1 mm with 4 at 4-5 mm; one bad spot is
                            # _drop_worst's and the camera's noise, a group of them is a fault)
SEEN_WHOLE_MM = 2.5         # a cube's top measured within this of its size both ways: seen whole (a check at a spot,
                            # and the cube's turn, go only by such sightings; the lab's first spot read 15.5 x 30.1 mm
                            # for a 25 mm cube, and a "slip" of 4.3 mm against it was the camera, not the arm)
JAW_SPREAD_MAX_DEG = 6.0    # the fingers' angle (see fingers_angle) is trusted when the spots agree on it this well
JAW_MIN_SPOTS = 5           # ...from at least this many
CALIBRATION_PACE = 50.0     # percent of their speed the moves go at while calibrating (the Dobot)
TURN_NOISE_DEG = 2.0        # how far off the cube's turn, as the camera reads it, can be
TAKE_BACK_SLOW_MM = 15.0    # taking the cube back: the last this-many mm down slowly...
TAKE_BACK_SPEED_MM_S = 20.0  # ...at this speed (as picks do)
RELEASE_SLOW_MM = 10.0      # let go: the open fingers rise the first this-many mm slowly, past the cube's sides...
RELEASE_SPEED_MM_S = 15.0   # ...at this speed (the lab, 2026-10-26: let go, the cube moved 1-2 mm and once tipped:
                            # a finger that opens late drags it as the gripper lifts at full speed)
EARLY_SHIFT_MIN_MM = 1.0    # before the run's own fit (MIN_FIT_SPOTS), the calibration in use says the cube moved
                            # across the fingers at least this much as it was let go: the fingers go there (its own
                            # error, against the run's spots so far, is about this: less is taken for that error)
EARLY_SPREAD_MAX_MM = 1.0   # ...and only if its errors at those spots agree this well (they don't: the gripper's
                            # middle off the tool point, turned from spot to spot, or a calibration that is off)
RETAKE_MAX_MM = 8.0         # a grip that came up empty: the cube seen this near where it was is gripped once more
                            # where it is now; further (knocked away), the user takes over
VIEW_TILT_MAX_DEG = 35.0    # spots the camera sees no more slanted than this (its ray against straight down), by the
                            # calibration in use: the lab's spots seen at 36-42 degrees (near the base, to the sides)
                            # read 23 x 29 mm for a 25 mm cube and paused three runs; at 25-31 degrees, they read true
VIEW_TILT_SPREAD_DEG = 10.0  # ...or, a camera that sees no spot that well (one off to the side), within this of the
                            # best-seen place (35 there clustered every spot on the camera's side: worse calibrations)
VIEW_SPARE = 2              # ...unless that leaves fewer than this many places per spot: then the best-seen ones
EARLY_MIN_SPOTS = 2         # the early re-centre (EARLY_SHIFT_MIN_MM) needs this many spots so far: from one, the
                            # calibration in use's own error there can't be told from the cube's move (a 1.5 degree
                            # turn in it is 2.6 mm 100 mm away); a miss at spot 2 is looked at again instead (_retake)
MIN_FIT_SPOTS = 5           # where the cube moved as it was let go is told by the fit of this many spots so far (3
                            # for a day: the lab, 2026-10-21, paused at spot 4 "3.5 mm from where it was let go" when the
                            # run's 7 looks put it 1.1 mm from there -- 3 spots (and a scale) can't tell 3 mm)
FIT_SCALE_SPOTS = 8         # ...a scale fitted with it only from this many
TRACK_AIM_SPOTS = 8         # ...the tracking (solve_chain) aims and judges a knock only from this many (at 5, one of
                            # them just gripped by hand, it read 3.4 mm where the looks said 1.0)
KNOCK_MIN_SPOTS = 6         # ...and a cube "bounced or knocked" pauses the run only from this many
SHIFT_MAX_MM = 3.0          # the cube seen further than this from where it was let go: the user takes over
CHAIN_MIN_SPOTS = 5         # the cube's place along the fingers tracked by the camera (see solve_chain): from this many
                            # (with 4, a spot left out leaves as many numbers to find as readings)
GRIP_CHANGE_MM = 1.0        # ...and taken as tracked only if the place changed this much, or a grip was pushed (on
                            # a clean run the tracking's own noise "changed" it by a few tenths)
BROKEN_EVERY = 6            # ...and up to one grip in this many left out as pushed (at least 1; 2 from 10 spots)
REPEAT_WARN_MM = 0.5        # the first spot looked at twice: the cube seen this far apart: the camera is unsteady
FIT_TRUSTED_MM = 1.5        # ...seen so by the fit of the spots so far, trusted when it predicts them this well
CAMERA_MOVED_MM = 2.0       # carrying on after a pause: the empty table seen this much differently: the camera moved
HOME_ADVICE = ("Clear any alarm and press Home (Manual tab), grip the cube again and press 'Manually gripped - "
               "continue'. If it happens again straight after Home, press 'Start over'")
FAR_REACH = 0.92            # spots no further out than this much of the arm's reach (closer in, at 0.85, the spots
                            # spread less and the demo's result was 1 mm off at the table's far side)
STACK_MM = 4.0              # a stack is right if its top is this near k cube-heights up...
STACK_XY_MM = 6.0           # ...and this near where the robot put it, seen from above
CAMERA_WARM_S = 15 * 60.0   # a stereo camera's distances drift for this long after it is switched on


# ---- finding the cube by "what is new" -------------------------------------------------------------------------------
@dataclass
class CubeSighting:
    cam_xyz: np.ndarray            # the middle of its top's outline, camera coordinates (mm)
    height_mm: float               # its top above the table round it
    footprint_mm: tuple            # (narrow side, long side) of its top, mm
    pixel: tuple                   # (u, v) of the middle of its top
    depth_mm: float
    tilt_deg: float = 0.0          # its top against the table round it (0 when the top's depth is too noisy to say)
    tilt_fit_mm: float = 0.0       # how far the top's points are from their plane, typically
    top_points: int = 0
    turn_deg: float = 0.0          # how its sides are turned, on the table's plane (0-90: a square's look the same)
    side_dir: Optional[np.ndarray] = None        # one side's direction, camera coordinates (unit; for the fingers' angle)
    table_points: Optional[np.ndarray] = None    # some of the table round it (camera coordinates), for the plane
    faces: list = field(default_factory=list)    # visible sides: (axis 0/1, outward unit vector, distance from cam_xyz)

    def model_xyz(self, side_mm: float) -> np.ndarray:
        """The middle of its top found from its sides too: each side seen puts the middle half a side in from it (a
        side is a whole face of points, seen from an angle; the top's outline is only its edge)."""
        shift = np.zeros(3)
        by_axis: dict[int, list] = {}
        for axis, outward, distance in self.faces:
            by_axis.setdefault(axis, []).append((distance - side_mm / 2.0) * np.asarray(outward, float))
        for moves in by_axis.values():
            shift += np.mean(moves, axis=0)
        return np.asarray(self.cam_xyz, float) + shift


def _points(depth: np.ndarray, mask: np.ndarray, k: Intrinsics) -> np.ndarray:
    v, u = np.nonzero(mask)
    z = depth[v, u].astype(np.float64)
    return np.stack([(u - k.cx) * z / k.fx, (v - k.cy) * z / k.fy, z], axis=1)


def _plane(points: np.ndarray, min_points: int = 30) -> Optional[tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """(a point on it, its normal towards the camera, which points lie on it) of a plane fitted with stray points
    left out."""
    if len(points) < min_points:
        return None
    keep = np.ones(len(points), bool)
    centre, normal = points.mean(axis=0), np.array([0.0, 0.0, -1.0])
    for _ in range(4):
        centre = points[keep].mean(axis=0)
        _, _, vt = np.linalg.svd(points[keep] - centre, full_matrices=False)
        normal = vt[2]
        if np.dot(normal, -centre) < 0:          # towards the camera (at the origin)
            normal = -normal
        distance = np.abs((points - centre) @ normal)
        keep = distance < max(1.5, 2.5 * float(np.median(distance[keep])))
        if keep.sum() < min_points:
            return None
    return centre, normal, keep


def _sighting(region: np.ndarray, after: np.ndarray, before: np.ndarray, k: Intrinsics,
              table: Optional["TablePlane"] = None) -> Optional[CubeSighting]:
    if table is None:            # the table round it
        inner = cv2.dilate(region.astype(np.uint8), np.ones((2 * RING_PX[0] + 1,) * 2, np.uint8)) > 0
        outer = cv2.dilate(region.astype(np.uint8), np.ones((2 * RING_PX[1] + 1,) * 2, np.uint8)) > 0
        ring = outer & ~inner & (before > 0)
        ring_points = _points(before, ring, k)
        fitted = _plane(ring_points)
        if fitted is None:
            return None
        origin, normal, on_table = fitted
    else:                        # the whole table's, already known (a stack: round it are the cubes under it)
        normal = np.asarray(table.normal, float)
        origin, ring_points, on_table = normal * table.offset, np.zeros((0, 3)), np.zeros(0, bool)
    pts = _points(after, region & (after > 0), k)
    heights = (pts - origin) @ normal
    peak = float(np.percentile(heights, 97))
    top = heights >= peak - TOP_BAND_MM
    if top.sum() < 20:
        return None
    top_pts = pts[top]
    mean = top_pts.mean(axis=0)
    # laid out on the table's plane: the middle of the top's outline (where 98% of its points lie, as
    # `measure_footprint`), not their average -- from an angled camera the top few mm of the near side count as
    # "top" too, and pulled the average ~1.3 mm towards the camera (a side, seen from above, is only an edge)
    axis_a = np.cross(normal, [1.0, 0.0, 0.0])
    if np.linalg.norm(axis_a) < 1e-6:
        axis_a = np.cross(normal, [0.0, 1.0, 0.0])
    axis_a /= np.linalg.norm(axis_a)
    axis_b = np.cross(normal, axis_a)
    flat = np.stack([(top_pts - mean) @ axis_a, (top_pts - mean) @ axis_b], axis=1)
    size, (ca, cb) = measure_footprint(flat)
    if size is None:
        return None
    w, l, angle = size[0], size[1], size[2]
    # its height from the middle of its top only (the near side's top edge, in the band too, read ~0.6 mm low)
    middle = np.hypot(flat[:, 0] - ca, flat[:, 1] - cb) <= 0.3 * min(w, l)
    core = top_pts[middle] if middle.sum() >= 10 else top_pts
    peak_height = float(np.median(heights[top][middle] if middle.sum() >= 10 else heights[top]))
    centre = mean + ca * axis_a + cb * axis_b
    centre = centre + (peak_height - float((centre - origin) @ normal)) * normal   # on the top's own level
    # how its top leans against the table: a cube that landed on an edge, or on something
    tilt, fit = 0.0, 0.0
    # (every point over the middle of the top, whatever its height: on a cube that leans, the top band is only a
    # strip of its top)
    seen_flat = np.stack([(pts - mean) @ axis_a - ca, (pts - mean) @ axis_b - cb], axis=1)
    over_middle = pts[np.hypot(seen_flat[:, 0], seen_flat[:, 1]) <= 0.3 * min(w, l)]
    top_plane = _plane(over_middle, min_points=10) if len(over_middle) >= 10 else None   # (stray readings out)
    if top_plane is not None:
        plane_centre, plane_normal, kept = top_plane
        fit = float(np.median(np.abs((over_middle[kept] - plane_centre) @ plane_normal)))
        if kept.sum() >= TILT_POINTS and fit <= TILT_FIT_MM:      # only a clean fit says how it leans
            tilt = math.degrees(math.acos(min(1.0, abs(float(np.dot(plane_normal, normal))))))
    # its visible sides, for the middle found from its whole shape
    faces = _faces(pts, heights, peak_height, mean, axis_a, axis_b, (ca, cb), w, l, angle)
    u = k.fx * centre[0] / centre[2] + k.cx
    v = k.fy * centre[1] / centre[2] + k.cy
    sample = ring_points[on_table]
    if len(sample) > 400:
        sample = sample[np.linspace(0, len(sample) - 1, 400).astype(int)]
    return CubeSighting(cam_xyz=centre, height_mm=peak_height,
                        footprint_mm=(round(float(min(w, l)), 1), round(float(max(w, l)), 1)),
                        pixel=(float(u), float(v)), depth_mm=float(centre[2]), tilt_deg=tilt, tilt_fit_mm=fit,
                        top_points=int(len(over_middle)), turn_deg=float(angle) % 90.0,
                        side_dir=math.cos(math.radians(angle)) * axis_a + math.sin(math.radians(angle)) * axis_b,
                        table_points=sample, faces=faces)


def _faces(pts, heights, top_height, mean, axis_a, axis_b, middle, w, l, angle) -> list:
    """The sides seen: (axis 0 or 1, outward unit vector in camera coordinates, distance of the side from the top's
    middle), each from the median of its points between 20% and 80% of the way up (clear of the table and of the top's
    edge, where depth readings mix the two)."""
    band = (heights > 0.2 * top_height) & (heights < 0.8 * top_height)
    if band.sum() < 40:
        return []
    side = pts[band] - mean
    flat = np.stack([side @ axis_a - middle[0], side @ axis_b - middle[1]], axis=1)
    turn = math.radians(angle)
    along = np.array([math.cos(turn), math.sin(turn)])          # the top's long side
    across = np.array([-math.sin(turn), math.cos(turn)])
    halves = (l / 2.0, w / 2.0)
    c = np.stack([flat @ along, flat @ across], axis=1)
    which = np.where(np.abs(c[:, 0]) / halves[0] >= np.abs(c[:, 1]) / halves[1], 0, 1)
    out = []
    for axis, direction in ((0, along), (1, across)):
        for sign in (1.0, -1.0):
            mine = (which == axis) & (np.sign(c[:, axis]) == sign)
            if mine.sum() < 40:
                continue
            distance = float(np.median(np.abs(c[mine, axis])))
            if abs(distance - halves[axis]) > 3.0:      # not a side where the top says one is: stray depth
                continue
            outward = sign * (direction[0] * axis_a + direction[1] * axis_b)
            out.append((axis, outward, distance))
    return out


def _new_regions(after: np.ndarray, before: np.ndarray) -> list[np.ndarray]:
    both = (after > 0) & (before > 0)
    new = (both & ((before - after) > NEW_MM)).astype(np.uint8)
    new = cv2.morphologyEx(new, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    count, parts, stats, _ = cv2.connectedComponentsWithStats(new, connectivity=8)
    order = sorted(range(1, count), key=lambda i: -stats[i, cv2.CC_STAT_AREA])
    return [parts == i for i in order if stats[i, cv2.CC_STAT_AREA] >= MIN_CUBE_PX]


CANDIDATES = 6              # new things in a picture looked at to find the cube among them


def cube_like(seen: CubeSighting, size_mm: Optional[float] = None, on_table: bool = True) -> bool:
    """Whether a new thing looks like the cube: a square top of a cube's size (and, standing on the table, about a
    cube's height). The gripper waiting at the side, in the camera's view, is new too when it is open and was closed
    on the cube before: it was bigger than the cube, and was measured instead of it (42 mm long, "88 degrees")."""
    narrow, long_ = seen.footprint_mm
    low, high = (0.6 * size_mm, 1.5 * size_mm) if size_mm else (6.0, 45.0)
    if not (low <= narrow and long_ <= high and long_ <= 1.3 * narrow):
        return False
    return not on_table or ((0.6 * size_mm <= seen.height_mm <= 1.4 * size_mm) if size_mm
                            else 6.0 <= seen.height_mm <= 45.0)


def find_new_object(after: np.ndarray, before: np.ndarray, k: Intrinsics,
                    table: Optional["TablePlane"] = None, expect_px: Optional[tuple] = None,
                    size_mm: Optional[float] = None) -> Optional[CubeSighting]:
    """The cube that is in `after` and wasn't in `before` (depth pictures, the arm away in both): the middle of its
    top, how tall it stands above the table round it (or above `table`, the whole table's plane), its top's size and
    its sides. Needs no calibration. Of the new things, the one that looks like a cube (see cube_like), nearest
    `expect_px` (where the cube should be in the picture) if given, else the biggest; if none looks like a cube, the
    biggest new thing (so it is left out as crooked or hidden). None if nothing new (or only specks) is seen."""
    seen = [s for s in (_sighting(region, after, before, k, table)
                        for region in _new_regions(after, before)[:CANDIDATES]) if s is not None]
    if not seen:
        return None
    cubes = [s for s in seen if cube_like(s, size_mm, on_table=table is None)]
    if not cubes:
        return seen[0]
    if expect_px is not None:
        return min(cubes, key=lambda s: math.hypot(s.pixel[0] - expect_px[0], s.pixel[1] - expect_px[1]))
    return cubes[0]


def find_new_objects(after: np.ndarray, before: np.ndarray, k: Intrinsics, count: int,
                     size_mm: Optional[float] = None) -> list[CubeSighting]:
    """Up to `count` new cubes, the biggest first (other new things, the waiting gripper, left out)."""
    seen = [s for s in (_sighting(region, after, before, k)
                        for region in _new_regions(after, before)[:CANDIDATES + count]) if s is not None]
    return [s for s in seen if cube_like(s, size_mm)][:count]


def project(transform: Optional[np.ndarray], k: Intrinsics, xyz) -> Optional[tuple[float, float]]:
    """Where a robot point is in the picture, by a calibration (even a rough one); None without one."""
    if transform is None:
        return None
    q = np.linalg.inv(np.asarray(transform, float)) @ np.append(np.asarray(xyz, float), 1.0)
    if q[2] <= 1.0:
        return None
    return float(k.fx * q[0] / q[2] + k.cx), float(k.fy * q[1] / q[2] + k.cy)


# ---- where ------------------------------------------------------------------------------------------------------------
GRID_MM = 25.0              # spots are chosen from a grid this fine
NEAR_START_MM = 130.0       # with no calibration to tell what the camera sees: spots this near where the cube was
VIEW_MARGIN_PX = 80.0       # ...with one: spots this far inside the picture's edges (at the lab, a cube 76 px from
                            # the edge was seen 2 mm short and leaning 16 degrees; 100 px left too little table)


def in_view_check(transform: Optional[np.ndarray], k: Intrinsics, z: float) -> Optional[Callable[[float, float], bool]]:
    """Whether the camera sees a spot on the table (by a calibration it has, even a rough one), or None if there is
    none to go by. (The xArm reaches far further than the camera sees: spots over all its reach, 6 of 10 were out
    of the picture.)"""
    if transform is None or np.allclose(np.asarray(transform, float), np.eye(4)):
        return None                 # (none: the app's stand-in until it is calibrated is "no transform at all")
    to_camera = np.linalg.inv(np.asarray(transform, float))

    def seen(x: float, y: float) -> bool:
        q = to_camera @ np.array([x, y, z, 1.0])
        if q[2] <= 1.0:
            return False
        u, v = k.fx * q[0] / q[2] + k.cx, k.fy * q[1] / q[2] + k.cy
        return (VIEW_MARGIN_PX <= u <= k.width - VIEW_MARGIN_PX) and (VIEW_MARGIN_PX <= v <= k.height - VIEW_MARGIN_PX)
    return seen


def view_tilt_check(transform: Optional[np.ndarray], z: float) -> Optional[Callable[[float, float], float]]:
    """How slanted (degrees from straight down) the camera sees a spot on the table at height z, by a calibration it
    has; None if there is none. (Seen slanted, a cube shows a side as well as its top, and its top's outline reads
    long one way.)"""
    if transform is None or np.allclose(np.asarray(transform, float), np.eye(4)):
        return None
    eye = np.asarray(transform, float)[:3, 3]

    def tilt(x: float, y: float) -> float:
        ray = np.array([x, y, z]) - eye
        return float(math.degrees(math.acos(min(1.0, abs(ray[2]) / max(1e-9, float(np.linalg.norm(ray)))))))
    return tilt


def plan_spots(bounds: dict, reach_mm: float, start_xy: tuple, count: int = SPOTS,
               seen: Optional[Callable[[float, float], bool]] = None, angles: tuple = (0.0,),
               fits: Optional[Callable[[float, float, float], bool]] = None,
               allowed: Optional[Callable[[float, float], bool]] = None,
               tilt: Optional[Callable[[float, float], float]] = None) -> list[tuple[float, float, float]]:
    """(x, y, wrist turn) for spots spread over the reachable part of the table the camera sees (`seen`; without it,
    near where the cube started), each next one as far as it can be from those chosen, then visited in a short route
    from the start. The turns are dealt out in the order the spots were chosen, so each covers the whole table;
    `fits(turn, x, y)` says whether the wrist can turn that way there (otherwise the nearest turn that can).
    `allowed(x, y)`: only there too -- where the table was touched (TableHeights.covers), so every spot's height is
    measured, not guessed (the lab: a spot 120 mm past the touches, at the edge of the view, landed crooked and the
    fingers came down on it); with it and no `seen`, the touched area stands in for "near where the cube started".
    `tilt(x, y)` (see view_tilt_check): only where the camera sees no more slanted than VIEW_TILT_MAX_DEG (or within
    VIEW_TILT_SPREAD_DEG of the best-seen place), unless that leaves fewer than VIEW_SPARE places per spot (then the
    best-seen that many).
    The first spot is where the cube was gripped, when it can be one (the first put-down goes back where it was)."""
    x0, x1, y0, y1 = workspace_region(bounds, reach_mm)
    near, far = min_radius_mm() + NEAR_BASE_MARGIN_MM, FAR_REACH * reach_mm

    def usable(p) -> bool:
        if not (near <= math.hypot(*p) <= far and abs(math.degrees(math.atan2(p[1], p[0]))) <= MAX_SPOT_AZIMUTH_DEG):
            return False
        if allowed is not None and not allowed(*p):
            return False
        if seen is not None:
            return seen(*p)
        # (no calibration to say what the camera sees: near where the cube was, touched or not -- touches that don't
        # spread sideways limit nothing sideways, and spots over the whole reach were half out of the picture)
        return math.dist(p, start_xy) <= NEAR_START_MM
    centres = [(float(x), float(y)) for x in np.arange(x0, x1 + 1.0, GRID_MM) for y in np.arange(y0, y1 + 1.0, GRID_MM)
               if usable((float(x), float(y)))]
    start = (float(start_xy[0]), float(start_xy[1]))
    if start not in centres and x0 <= start[0] <= x1 and y0 <= start[1] <= y1 and usable(start):
        centres = [start] + [p for p in centres if math.dist(p, start) >= GRID_MM / 2]
    if tilt is not None and centres:
        slant = {p: tilt(*p) for p in centres}
        limit = max(VIEW_TILT_MAX_DEG, min(slant.values()) + VIEW_TILT_SPREAD_DEG)
        well = [p for p in centres if slant[p] <= limit]
        if len(well) < VIEW_SPARE * count:
            best = set(sorted(centres, key=lambda p: slant[p])[:VIEW_SPARE * count])
            well = [p for p in centres if p in best]
        centres = well
    if not centres:
        return []
    chosen = [min(centres, key=lambda p: math.dist(p, start_xy))]
    while len(chosen) < min(count, len(centres)):
        chosen.append(max((p for p in centres if p not in chosen), key=lambda p: min(math.dist(p, q) for q in chosen)))
    turned = []
    for index, (x, y) in enumerate(chosen):
        wanted = angles[index % len(angles)]
        for turn in sorted(angles, key=lambda a: abs(a - wanted)) + [0.0]:
            if fits is None or fits(turn, x, y):
                turned.append((x, y, float(turn)))
                break
    route, here = [], start_xy
    while turned:
        nearest = min(turned, key=lambda p: math.dist(p[:2], here))
        turned.remove(nearest)
        route.append((float(nearest[0]), float(nearest[1]), nearest[2]))
        here = nearest[:2]
    return route


MAX_SPOT_AZIMUTH_DEG = 60.0 # spots no further round than this from straight ahead (a swing from one at -68 degrees
                            # to the far waiting place, the wrist kept turned, locked the Dobot: alarm 0x12)


def middle_turn(x: float, y: float) -> float:
    """The tool's turn r with the wrist in its middle at (x, y): the gripper along the arm (the Dobot's J4 at 0)."""
    return math.degrees(math.atan2(y, x))


def away_poses_for(bounds: dict, reach_mm: float, z: float) -> list[Pose]:
    """Where the arm waits while the camera looks: high, at either side, the wrist turned straight (its joint in
    the middle of its range: kept at a spot's turn, a swing to the far side took it near its limit)."""
    y = min(0.75 * reach_mm, bounds["y"][1] - 5.0)
    x = max(bounds["x"][0], 110.0)
    z = min(z, bounds["z"][1])
    side = math.degrees(math.atan2(y, x))
    return [Pose(x, -y, z, -side), Pose(x, y, z, side)]


# ---- solving ------------------------------------------------------------------------------------------------------------
@dataclass
class CubePair:
    xy: tuple                      # where the robot put it: its tool (the cube's middle, once centred on it)
    r: float                       # the wrist's turn then
    sighting: CubeSighting         # by the depth picture lined up with the colour camera's (what the app uses)
    raw: Optional[CubeSighting] = None   # by the depth sensor's own picture, if the camera gives one
    level: int = 1                 # 1 on the table; 2 or 3 on top of other cubes
    gap_mm: Optional[float] = None       # (xArm) how far apart the fingers closed on it
    centred: bool = False                # xy is already the gripper's middle (the robot was told the offset)
    check: bool = False                  # a look back at the first spot (the slip check), not a spot of its own
    # the cube's place in the fingers, tracked (see solve_chain): the spot it was carried here from, by the take-back
    # after it; where this spot's take-back gripped it (the tool point, and its turn); and, once solved so, where its
    # middle was here
    prev: Optional["CubePair"] = field(default=None, repr=False, compare=False)
    taken_xy: Optional[tuple] = None
    taken_r: Optional[float] = None
    held_at: Optional[tuple] = None

    def centre_xy(self, offset=None) -> tuple[float, float]:
        """Where the cube's middle was: the tool point, moved by the gripper's offset (turned with the tool) -- or
        where the fit that tracked the cube in the fingers put it."""
        if self.held_at is not None:
            return float(self.held_at[0]), float(self.held_at[1])
        if offset is None or self.centred:
            return float(self.xy[0]), float(self.xy[1])
        ox, oy = turned(float(offset[0]), float(offset[1]), self.r)
        return float(self.xy[0]) + ox, float(self.xy[1]) + oy

    def robot_xyz(self, table_z: float, cube_h: float, offset=None) -> tuple[float, float, float]:
        """The middle of its top, robot coordinates."""
        x, y = self.centre_xy(offset)
        return (x, y, float(table_z + self.level * cube_h))


def _turn_up(normal: np.ndarray) -> np.ndarray:
    """The rotation taking `normal` to +z (by the shortest way)."""
    z = np.array([0.0, 0.0, 1.0])
    n = np.asarray(normal, float) / np.linalg.norm(normal)
    v = np.cross(n, z)
    s, c = float(np.linalg.norm(v)), float(np.dot(n, z))
    if s < 1e-12:
        return np.eye(3) if c > 0 else np.diag([1.0, -1.0, -1.0])
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * ((1.0 - c) / s ** 2)


def _fit_2d(a: np.ndarray, b: np.ndarray, with_scale: bool) -> tuple[float, np.ndarray, np.ndarray]:
    """(scale, 2x2 turn, shift) with b ~ scale * turn @ a + shift (Kabsch/Umeyama in the plane)."""
    ca, cb = a.mean(axis=0), b.mean(axis=0)
    h = (a - ca).T @ (b - cb)
    u, singular, vt = np.linalg.svd(h)
    d = np.diag([1.0, np.sign(np.linalg.det(vt.T @ u.T)) or 1.0])
    turn = vt.T @ d @ u.T
    spread = float(((a - ca) ** 2).sum())
    scale = float((singular * np.diag(d)).sum()) / spread if with_scale and spread > 0 else 1.0
    return scale, turn, cb - scale * turn @ ca


def _rot(degrees: np.ndarray) -> np.ndarray:
    t = np.radians(np.asarray(degrees, float))
    c, s = np.cos(t), np.sin(t)
    return np.stack([np.stack([c, -s], -1), np.stack([s, c], -1)], -2)       # (N, 2, 2)


@dataclass
class TablePlane:
    normal: np.ndarray       # towards the camera, camera coordinates
    offset: float            # normal . p for points on it (mm)
    rms_mm: float            # how far the table's points are from it, typically
    points: int


def fit_table(sightings: list[CubeSighting]) -> Optional[TablePlane]:
    """The table's plane, from the table round every spot the cube was found at: thousands of points spread over
    the working area."""
    points = [s.table_points for s in sightings if s.table_points is not None and len(s.table_points)]
    if not points:
        return None
    fit = _plane(np.concatenate(points), min_points=100)
    if fit is None:
        return None
    centre, normal, keep = fit
    all_points = np.concatenate(points)
    distance = (all_points[keep] - centre) @ normal
    return TablePlane(normal=normal, offset=float(np.dot(normal, centre)),
                      rms_mm=float(np.sqrt(np.mean(distance ** 2))), points=int(keep.sum()))


@dataclass
class Fit:
    name: str                      # how it was made, in words
    transform: np.ndarray          # camera -> robot (mm), heights included
    scale: float
    used: list                     # indices into the pairs given
    loo: np.ndarray                # each used spot left out: truth minus prediction, robot x and y (N x 2)
    correction: Optional[XYCorrection] = None
    offset: Optional[np.ndarray] = None  # the gripper's middle from the tool point (tool frame), if fitted
    tracked: bool = False                # the cube's place along the fingers tracked from grip to grip (solve_chain)
    centres: Optional[np.ndarray] = None  # ...then: each spot, where the cube's middle was (robot x, y; N x 2)
    along: Optional[np.ndarray] = None   # ...and how far along the fingers from the tool point it was held there
    broken: Optional[list] = None        # ...and the spots whose grip was left out as pushed

    @property
    def errors_mm(self) -> list[float]:
        return [float(v) for v in np.hypot(self.loo[:, 0], self.loo[:, 1])]

    @property
    def typical_mm(self) -> float:
        return float(np.median(self.errors_mm))


def _plane_transform(plane: TablePlane, table_z: float, scale: float, turn2: np.ndarray, shift2: np.ndarray,
                     tilt: np.ndarray) -> np.ndarray:
    turn3 = np.eye(3)
    turn3[:2, :2] = turn2
    out = np.eye(4)
    out[:3, :3] = scale * turn3 @ tilt
    out[:2, 3] = shift2
    out[2, 3] = table_z - scale * plane.offset
    return out


def _fit_flat(flat: np.ndarray, robot_xy: np.ndarray, with_scale: bool, r_deg: Optional[np.ndarray] = None):
    """(scale, turn, shift, offset): the fit in the table's plane; with `r_deg`, the gripper's offset d with it
    (the cube's middle at robot_xy + Rz(r) d), by turns: the fit for a d, then the d for the fit."""
    d = np.zeros(2)
    if r_deg is None:
        return (*_fit_2d(flat, robot_xy, with_scale), d)
    turns = _rot(r_deg)
    for _ in range(60):
        s, t2, sh = _fit_2d(flat, robot_xy + np.einsum("nij,j->ni", turns, d), with_scale)
        pred = flat @ (s * t2).T + sh
        d_new = np.einsum("nji,nj->ni", turns, pred - robot_xy).mean(axis=0)
        done = np.linalg.norm(d_new - d) < 1e-4
        d = d_new
        if done:
            break
    return (*_fit_2d(flat, robot_xy + np.einsum("nij,j->ni", turns, d), with_scale), d)


def solve_on_plane_offset(cam: np.ndarray, robot_xy: np.ndarray, plane: TablePlane, table_z: float,
                          with_scale: bool = False, r_deg: Optional[np.ndarray] = None):
    """(transform, each point left out: truth minus prediction, the gripper's offset or zeros). The table's plane
    fixes the tilt and the height (it is z = table_z in robot coordinates); the points fix the rest: the turn about
    the vertical, the sideways shift (and a scale, and the gripper's offset, if wanted)."""
    tilt = _turn_up(plane.normal)
    flat = (cam @ tilt.T)[:, :2]
    scale, turn2, shift2, d = _fit_flat(flat, robot_xy, with_scale, r_deg)
    transform = _plane_transform(plane, table_z, scale, turn2, shift2, tilt)
    loo = np.zeros_like(robot_xy)
    for i in range(len(cam)):
        keep = np.arange(len(cam)) != i
        s, t2, sh, d_i = _fit_flat(flat[keep], robot_xy[keep], with_scale,
                                   None if r_deg is None else np.asarray(r_deg)[keep])
        truth = robot_xy[i] + (np.array(turned(d_i[0], d_i[1], float(r_deg[i]))) if r_deg is not None else 0.0)
        loo[i] = truth - (s * t2 @ flat[i] + sh)
    return transform, loo, d


def solve_on_plane(cam: np.ndarray, robot_xy: np.ndarray, plane: TablePlane, table_z: float,
                   with_scale: bool = False) -> tuple[np.ndarray, np.ndarray]:
    """(camera->robot transform, each point left out: truth minus prediction in x and y), without an offset."""
    transform, loo, _ = solve_on_plane_offset(cam, robot_xy, plane, table_z, with_scale)
    return transform, loo


def tool_offset(cam: np.ndarray, robot_xy: np.ndarray, r_deg: np.ndarray, plane: TablePlane,
                table_z: float) -> tuple[np.ndarray, float, float]:
    """(d, typical error without it, with it): where the cube's middle sits from the tool point, in the tool's own
    turning frame -- the fingers' middle off the wrist's axis -- found from the wrist's different turns. The errors
    are each spot left out (so a d that only follows noise doesn't look better)."""
    tilt = _turn_up(plane.normal)
    flat = (cam @ tilt.T)[:, :2]
    turns = _rot(r_deg)

    def solve(index: np.ndarray) -> tuple[np.ndarray, tuple]:
        d = np.zeros(2)
        fit = _fit_2d(flat[index], robot_xy[index], False)
        for _ in range(40):
            targets = robot_xy[index] + np.einsum("nij,j->ni", turns[index], d)
            fit = _fit_2d(flat[index], targets, False)
            s, t2, sh = fit
            pred = flat[index] @ (s * t2).T + sh
            d_new = np.einsum("nji,nj->ni", turns[index], pred - robot_xy[index]).mean(axis=0)
            if np.linalg.norm(d_new - d) < 1e-4:
                d = d_new
                break
            d = d_new
        return d, fit

    every = np.arange(len(cam))
    d, _ = solve(every)
    if len(np.unique(np.round(r_deg))) < 2:
        return np.zeros(2), 0.0, 0.0
    without, with_d = [], []
    for i in every:
        keep = every[every != i]
        s, t2, sh = _fit_2d(flat[keep], robot_xy[keep], False)
        without.append(float(np.linalg.norm(robot_xy[i] - (s * t2 @ flat[i] + sh))))
        d_i, (s, t2, sh) = solve(keep)
        with_d.append(float(np.linalg.norm(robot_xy[i] + turns[i] @ d_i - (s * t2 @ flat[i] + sh))))
    return d, float(np.median(without)), float(np.median(with_d))


def _unit(degrees: float) -> np.ndarray:
    t = math.radians(degrees)
    return np.array([math.cos(t), math.sin(t)])


@dataclass
class ChainFit:
    """A fit that tracks where the cube sits along the fingers, grip by grip (see solve_chain)."""
    transform: np.ndarray        # camera -> robot: the cube's middle
    scale: float
    loo: np.ndarray              # each spot left out: where the robot put it minus where the camera saw it (N x 2)
    offset: np.ndarray           # where the fingers hold the cube from the tool point (tool frame): across them,
                                 # their middle (fitted, or 0); along them, where the hand gripped it at the start
                                 # (centred, as the guide says): the grips before the first change
    centres: np.ndarray          # each spot: where the cube's middle was, by the robot and the grips (N x 2)
    along: np.ndarray            # each spot: how far along the fingers it was held as it was let go there (N)
    broken: list                 # spots whose grip couldn't be told from the one before (a push as it was taken)
    jaw_axis_deg: float
    across_mm: Optional[float] = None    # the fingers' middle across them from the tool point, if fitted

    @property
    def typical_mm(self) -> float:
        return float(np.median(np.hypot(self.loo[:, 0], self.loo[:, 1])))

    @property
    def changed(self) -> bool:
        """The cube's place along the fingers really changed during the run (see GRIP_CHANGE_MM)."""
        return bool(self.broken) or float(np.ptp(self.along)) >= GRIP_CHANGE_MM

    def seen(self, cam_xyz) -> np.ndarray:
        """The cube's middle, robot x and y, for a camera point."""
        return (np.asarray(self.transform, float) @ np.append(np.asarray(cam_xyz, float), 1.0))[:2]

    def landing(self, put_xy, put_r: float, carried: CubePair) -> np.ndarray:
        """Where the cube's middle lands, let go with the tool at `put_xy` turned `put_r`, carried from `carried`'s
        spot (by its take-back)."""
        along_dir = _unit(self.jaw_axis_deg + 90.0)
        u = float(_unit(self.jaw_axis_deg + 90.0 + float(carried.taken_r))
                  @ (self.seen(carried.sighting.cam_xyz) - np.asarray(carried.taken_xy, float)))
        c = (self.across_mm or 0.0) * _unit(self.jaw_axis_deg)
        return np.asarray(put_xy, float) + _rot(np.array([put_r]))[0] @ (c + u * along_dir)


def _chain_solve(flat: np.ndarray, put_xy: np.ndarray, put_r: np.ndarray, taken_xy: np.ndarray,
                 taken_r: np.ndarray, prev: list, targets: list, jaw_deg: float, with_scale: bool,
                 with_offset: bool) -> Optional[tuple]:
    """(scale, 2x2 turn, shift, c, {start: u}), or None if the spots can't tell them apart. Each target j's cube lands
    at put_xy[j] + R(put_r[j]) (c e_across + u e_along), u where it sat along the fingers: from the camera, where it
    was before the take-back that carried it (spot prev[j]) against where that take-back gripped; or a number of its
    own (a start: gripped by hand, or after a spot the camera didn't see). All of it is linear in the unknowns."""
    e_c, e_a = _unit(jaw_deg), _unit(jaw_deg + 90.0)
    starts = [j for j in targets if prev[j] is None]
    columns = 4 + int(with_offset) + len(starts)
    rows, rhs = [], []
    for j in targets:
        turn = _rot(np.array([put_r[j]]))[0]
        w, f = turn @ e_a, flat[j]
        a_col, b_col, t_cols = f.copy(), np.array([-f[1], f[0]]), np.eye(2)
        right = np.asarray(put_xy[j], float).copy()
        u_cols = np.zeros((2, len(starts)))
        i = prev[j]
        if i is None:
            u_cols[:, starts.index(j)] = -w
        else:
            v, g = _rot(np.array([taken_r[i]]))[0] @ e_a, flat[i]
            a_col = a_col - w * float(v @ g)
            b_col = b_col - w * float(v @ np.array([-g[1], g[0]]))
            t_cols = t_cols - np.outer(w, v)
            right = right - w * float(v @ taken_xy[i])
        block = [a_col[:, None], b_col[:, None], t_cols]
        if with_offset:
            block.append(-(turn @ e_c)[:, None])
        block.append(u_cols)
        rows.append(np.hstack(block))
        rhs.append(right)
    a_mat, b_vec = np.vstack(rows), np.concatenate(rhs)
    if len(b_vec) <= columns or np.linalg.matrix_rank(a_mat) < columns:
        return None
    x = np.linalg.lstsq(a_mat, b_vec, rcond=None)[0]
    scale = float(math.hypot(x[0], x[1]))
    if scale < 1e-9:
        return None
    if not with_scale:
        ab = x[:2] / scale
        rest = np.linalg.lstsq(a_mat[:, 2:], b_vec - a_mat[:, :2] @ ab, rcond=None)[0]
        x, scale = np.concatenate([ab, rest]), 1.0
    a, b = x[0] / scale, x[1] / scale
    turn2 = np.array([[a, -b], [b, a]])
    c = float(x[4]) if with_offset else 0.0
    us = {j: float(x[4 + int(with_offset) + n]) for n, j in enumerate(starts)}
    return scale, turn2, x[2:4].copy(), c, us


def _chain_spots(flat, put_xy, put_r, taken_xy, taken_r, prev, targets, jaw_deg, solved):
    """(where each spot's cube landed by the robot and the grips, the u it was carried with, where the camera saw
    it): N x 2, N, N x 2. A start's u: its own; one left out of the fit, the grips' median."""
    scale, turn2, shift, c, us = solved
    e_c, e_a = _unit(jaw_deg), _unit(jaw_deg + 90.0)
    seen = flat @ (scale * turn2).T + shift

    def carried(j):
        i = prev[j]
        return float((_rot(np.array([taken_r[i]]))[0] @ e_a) @ (seen[i] - taken_xy[i]))
    grips = [carried(j) for j in targets if prev[j] is not None] + list(us.values())
    usual = float(np.median(grips)) if grips else 0.0
    landed, along = np.zeros((len(flat), 2)), np.zeros(len(flat))
    for j in range(len(flat)):
        u = carried(j) if prev[j] is not None else us.get(j, usual)
        along[j] = u
        landed[j] = put_xy[j] + _rot(np.array([put_r[j]]))[0] @ (c * e_c + u * e_a)
    return landed, along, seen


def solve_chain(cam: np.ndarray, put_xy: np.ndarray, put_r: np.ndarray, taken_xy: np.ndarray, taken_r: np.ndarray,
                prev: list, plane: TablePlane, table_z: float, jaw_axis_deg: float, with_scale: bool = False,
                with_offset: bool = False) -> Optional[ChainFit]:
    """The fit that doesn't take the cube to sit in the same place in the fingers at every spot. The fingers centre
    it across them as they close, but not along them: at the lab a 25 mm cube in the Dobot's 27.5 mm fingers, knocked
    once, sat 1.8 mm further along from then on, and every spot after it disagreed with the ones before. The camera
    sees where the cube is before each take-back, and the take-back's place is known: so where it then sits along
    the fingers is known, and so where it lands at the next spot. `prev[i]`: the index of the spot the cube was
    carried from to spot i, or None (gripped by hand, or after a spot it wasn't seen at). A spot it was pushed at as it
    was taken (a finger came down on it) disagrees: that grip is then taken as unknown (`broken`), one, or two from 10
    spots up. None if the spots can't tell the numbers apart (too few, or the wrist's turns too alike)."""
    cam, put_xy, put_r = np.asarray(cam, float), np.asarray(put_xy, float), np.asarray(put_r, float)
    taken_xy, taken_r = np.asarray(taken_xy, float), np.asarray(taken_r, float)
    n = len(cam)
    if n < CHAIN_MIN_SPOTS:
        return None
    tilt = _turn_up(plane.normal)
    flat = (cam @ tilt.T)[:, :2]
    prev = [None if i is None or not np.all(np.isfinite(taken_xy[i])) else int(i) for i in prev]
    if all(i is None for i in prev):
        return None
    every = list(range(n))

    def left_out(links: list) -> Optional[np.ndarray]:
        loo = np.zeros((n, 2))
        for j in every:
            keep = [k for k in every if k != j]
            links_j = [None if (i is None or i == j) else i for i in links]
            solved = _chain_solve(flat, put_xy, put_r, taken_xy, taken_r, links_j, keep, jaw_axis_deg, with_scale,
                                  with_offset)
            if solved is None:
                return None
            landed, _, seen = _chain_spots(flat, put_xy, put_r, taken_xy, taken_r, links_j, keep, jaw_axis_deg,
                                           solved)
            loo[j] = landed[j] - seen[j]
            if links[j] is None:
                # (gripped by hand, or after a spot not seen: where it sat along the fingers can't be foretold, only
                # across them)
                along = _rot(np.array([put_r[j]]))[0] @ _unit(jaw_axis_deg + 90.0)
                loo[j] = loo[j] - float(loo[j] @ along) * along
        return loo

    links, broken = list(prev), []
    loo = left_out(links)
    if loo is None:
        return None
    for _ in range(max(2 if n >= 10 else 1, n // BROKEN_EVERY)):     # (see BROKEN_EVERY)
        errors = np.hypot(loo[:, 0], loo[:, 1])
        linked = [j for j in every if links[j] is not None]
        if not linked:
            break
        worst = max(linked, key=lambda j: errors[j])
        if errors[worst] <= max(1.5, 3.0 * float(np.median(errors))):
            break
        trial = list(links)
        trial[worst] = None
        got = left_out(trial)
        if got is None or float(np.median(np.hypot(got[:, 0], got[:, 1]))) > float(np.median(errors)):
            break
        links, loo = trial, got
        broken.append(worst)
    solved = _chain_solve(flat, put_xy, put_r, taken_xy, taken_r, links, every, jaw_axis_deg, with_scale,
                          with_offset)
    if solved is None:
        return None
    scale, turn2, shift, c, _ = solved
    landed, along, _ = _chain_spots(flat, put_xy, put_r, taken_xy, taken_r, links, every, jaw_axis_deg, solved)
    transform = _plane_transform(plane, table_z, scale, turn2, shift, tilt)
    # (the robot then moves by it, as by the plain fit's offset: picks hold things where the hand gripped the cube.
    # Not the grips' median: knocked early, most grips sit where it was knocked to -- and an arm that lost its reach
    # reads as grips moved along the fingers, its median as well)
    start = [float(along[0])]
    for j in range(1, n):
        if links[j] is None or abs(float(along[j] - along[j - 1])) > GRIP_CHANGE_MM:
            break
        start.append(float(along[j]))
    offset = c * _unit(jaw_axis_deg) + float(np.median(start)) * _unit(jaw_axis_deg + 90.0)
    return ChainFit(transform, scale, loo, offset, landed, along, broken, float(jaw_axis_deg),
                    c if with_offset else None)


def chain_of(pairs: list) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, list]:
    """The arrays solve_chain takes, for these pairs (in the order measured): where each was put (x, y; turn), where
    its take-back gripped (NaN if none), and which of them the cube was carried from to each (by identity)."""
    put_xy = np.array([p.xy for p in pairs], float)
    put_r = np.array([p.r for p in pairs], float)
    taken_xy = np.array([p.taken_xy if p.taken_xy is not None else (np.nan, np.nan) for p in pairs], float)
    taken_r = np.array([p.taken_r if p.taken_r is not None else np.nan for p in pairs], float)
    where = {id(p): i for i, p in enumerate(pairs)}
    prev = [where.get(id(p.prev)) if p.prev is not None else None for p in pairs]
    return put_xy, put_r, taken_xy, taken_r, prev


def _chain_now(pairs: list, plane: Optional[TablePlane], table_z: float, jaw_axis_deg: Optional[float]
               ) -> Optional[ChainFit]:
    """During a run: the tracking fit of the spots so far that predicts them best (with the fingers' offset across
    them, or not; no scale), or None."""
    if jaw_axis_deg is None or plane is None or len(pairs) < CHAIN_MIN_SPOTS:
        return None
    cam = np.array([p.sighting.cam_xyz for p in pairs], float)
    put_xy, put_r, taken_xy, taken_r, prev = chain_of(pairs)
    fits = [solve_chain(cam, put_xy, put_r, taken_xy, taken_r, prev, plane, table_z, jaw_axis_deg,
                        with_offset=with_offset) for with_offset in (False, True)]
    fits = [f for f in fits if f is not None]
    return min(fits, key=lambda f: f.typical_mm) if fits else None


def _jaw_of(gripper) -> Optional[float]:
    """The fingers' closing direction at r = 0, for a gripper whose cube's place in the fingers is tracked (see
    solve_chain); None otherwise. Only the Dobot's for now (its wrist turns against the base; the xArm's gripper,
    which says how far it closed, isn't tried yet)."""
    if gripper is None or not getattr(gripper, "fingers", False) or not getattr(gripper, "wrist_relative", False):
        return None
    jaw = getattr(gripper, "jaw_axis_deg", None)
    return None if jaw is None else float(jaw)


def fingers_angle(pairs: list, transform: np.ndarray, jaw_axis_deg: float,
                  skip: tuple = ()) -> Optional[tuple[float, float, int]]:
    """How far the fingers really point from where the app thinks (jaw_axis_deg): (offset, how much the spots
    scatter round it, how many spots), degrees, or None if too few spots say. At each spot the cube was let go
    straight from the fingers (squeezed square in them), so its sides lie along the fingers: the camera sees which way
    (the calibration turns that into the robot's frame), and the app knows the wrist's turn r -- the sides should be
    at r + jaw_axis_deg (a square: give or take a quarter turn). A gripper mounted a few degrees turned on the wrist
    shows up as the same offset at every spot; the camera's reading and the cube turning as it dropped, as scatter.
    `skip`: spots where the camera saw the cube turn as it dropped (left out)."""
    turn = np.asarray(transform, float)[:3, :3]
    offsets = []
    for index, pair in enumerate(pairs):
        side = getattr(pair.sighting, "side_dir", None)
        if side is None or getattr(pair, "check", False) or index in skip:
            continue
        d = turn @ np.asarray(side, float)
        offsets.append(_wrap90(math.degrees(math.atan2(d[1], d[0])) - (pair.r + jaw_axis_deg)))
    if len(offsets) < JAW_MIN_SPOTS:
        return None
    angles = np.radians(4.0 * np.asarray(offsets))
    usual = math.degrees(math.atan2(np.sin(angles).mean(), np.cos(angles).mean())) / 4.0
    usual += float(np.median([_wrap90(a - usual) for a in offsets]))
    spread = float(np.median([abs(_wrap90(a - usual)) for a in offsets]))
    return float(_wrap90(usual)), spread, len(offsets)


def _drop_worst(cam: np.ndarray, robot_xy: np.ndarray, plane: TablePlane, table_z: float, with_scale: bool,
                index: np.ndarray, r_deg: Optional[np.ndarray] = None):
    """(transform, left-out misses, indices used, offset): a spot that disagrees with the rest (its left-out miss
    three times the typical, and over 1.5 mm: the cube slipped, a bad look) is left out; one, or two from 10 spots
    up, never leaving fewer than FEWEST_SPOTS. (At the lab, 6 spots, one 6.6 mm off and the rest ~1.5: it was kept.)"""
    def solve(idx):
        return solve_on_plane_offset(cam[idx], robot_xy[idx], plane, table_z, with_scale,
                                     None if r_deg is None else np.asarray(r_deg)[idx])
    transform, loo, d = solve(index)
    for _ in range(2 if len(index) >= 10 else 1):
        errors = np.hypot(loo[:, 0], loo[:, 1])
        worst = int(np.argmax(errors))
        if len(index) <= FEWEST_SPOTS or errors[worst] <= max(1.5, 3.0 * float(np.median(errors))):
            break
        index = np.delete(index, worst)
        transform, loo, d = solve(index)
    return transform, loo, index, d


def correction_for(cam: np.ndarray, robot_xy: np.ndarray, plane: TablePlane, table_z: float, with_scale: bool,
                   offset: Optional[np.ndarray] = None, r_deg: Optional[np.ndarray] = None,
                   ) -> tuple[Optional[XYCorrection], np.ndarray]:
    """(the correction over the table, each spot left out with it: truth minus prediction). Left out means left
    out of both the rigid fit and the correction. With `offset`, the truth is the cube's middle (the tool point
    moved by it, turned by `r_deg`)."""
    if offset is not None:
        robot_xy = robot_xy + np.einsum("nij,j->ni", _rot(r_deg), np.asarray(offset, float))
    tilt = _turn_up(plane.normal)
    flat = (cam @ tilt.T)[:, :2]
    loo = np.zeros_like(robot_xy)
    for i in range(len(cam)):
        keep = np.arange(len(cam)) != i
        s, t2, sh = _fit_2d(flat[keep], robot_xy[keep], with_scale)
        pred = flat @ (s * t2).T + sh
        corr = XYCorrection.fit(pred[keep], robot_xy[keep] - pred[keep])
        loo[i] = robot_xy[i] - np.array(corr.apply(*pred[i]))
    s, t2, sh = _fit_2d(flat, robot_xy, with_scale)
    pred = flat @ (s * t2).T + sh
    return XYCorrection.fit(pred, robot_xy - pred), loo


def to_colour_frame(transform: np.ndarray, depth_to_colour: np.ndarray) -> np.ndarray:
    """A transform made from the depth sensor's own picture, for points in the colour camera's frame (the app's)."""
    return np.asarray(transform, float) @ np.linalg.inv(np.asarray(depth_to_colour, float))


def sides_offset(sightings: list[CubeSighting], transform: np.ndarray) -> Optional[tuple[float, float]]:
    """How far (robot x, y; median over the spots) the cube's middle found from its sides is from the middle of its
    top's outline: a cross-check of the cube finding. Near 0 is good; a few tenths of a mm is the angle it is seen
    at."""
    with_faces = [s for s in sightings if s.faces]
    if len(with_faces) < 3:
        return None
    side = float(np.median([s.footprint_mm[0] for s in with_faces]))
    turn = np.asarray(transform, float)[:3, :3]
    moves = np.array([(turn @ (s.model_xyz(side) - s.cam_xyz))[:2] for s in with_faces])
    return float(np.median(moves[:, 0])), float(np.median(moves[:, 1]))


def solve_cube(pairs: list[CubePair], table_z: float, cube_h: float, depth_to_colour: Optional[np.ndarray] = None,
               try_correction: bool = False, jaw_axis_deg: Optional[float] = None,
               ) -> tuple[Optional[Fit], list[Fit], Optional[TablePlane]]:
    """(the best fit, every one tried, the table's plane) for the table-level pairs. Tried: the colour-lined-up depth
    or the depth sensor's own (if every pair has it); without or with a scale; with fingers (`jaw_axis_deg`), also
    tracking the cube's place along them (solve_chain). The simplest one is kept unless another predicts the spots
    left out better."""
    tried: list[Fit] = []
    plane_used = None
    robot_xy = np.array([p.xy for p in pairs], float)
    r_deg = np.array([p.r for p in pairs], float)
    # the gripper's offset is tried when the tool turned enough between spots to tell it from a shift
    offsets = (False, True) if (len(pairs) >= 5 and np.ptp(r_deg) >= OFFSET_SPREAD_DEG) else (False,)
    views = [("colour-aligned depth", [p.sighting for p in pairs], None)]
    if depth_to_colour is not None and all(p.raw is not None for p in pairs):
        views.append(("the depth sensor's own picture", [p.raw for p in pairs], depth_to_colour))
    for view_name, sightings, extrinsic in views:
        plane = fit_table(sightings)
        if plane is None:
            continue
        if plane_used is None:
            plane_used = plane
        # (the middle of the top's outline, as the app finds objects. The middle from the top and the sides
        # scattered less in the demo but sat 0.4 mm further off: an offset the same everywhere, which no spot left
        # out can show -- so it is only reported, see sides_offset)
        cam = np.array([s.cam_xyz for s in sightings], float)
        for with_offset in offsets:
            for with_scale in (False, True):
                transform, loo, used, d = _drop_worst(cam, robot_xy, plane, table_z, with_scale,
                                                      np.arange(len(pairs)), r_deg if with_offset else None)
                scale = float(np.cbrt(np.linalg.det(transform[:3, :3])))
                if extrinsic is not None:
                    transform = to_colour_frame(transform, extrinsic)
                name = (f"top, {view_name}" + (f", scale {scale:.4f}" if with_scale else "")
                        + (f", the gripper's middle {d[0]:+.1f}, {d[1]:+.1f} mm off" if with_offset else ""))
                tried.append(Fit(name, transform, scale, [int(i) for i in used], loo,
                                 offset=d if with_offset else None))
        if jaw_axis_deg is not None and len(pairs) >= CHAIN_MIN_SPOTS:
            put_xy, put_r, taken_xy, taken_r, prev = chain_of(pairs)
            for with_offset in offsets:
                for with_scale in (False, True):
                    chain = solve_chain(cam, put_xy, put_r, taken_xy, taken_r, prev, plane, table_z, jaw_axis_deg,
                                        with_scale, with_offset)
                    if chain is None:
                        continue
                    transform = chain.transform
                    if extrinsic is not None:
                        transform = to_colour_frame(transform, extrinsic)
                    o = chain.offset
                    name = (f"top, {view_name}" + (f", scale {chain.scale:.4f}" if with_scale else "")
                            + (", the fingers' middle measured across" if with_offset else "")
                            + f", the cube tracked in the fingers (held {o[0]:+.1f}, {o[1]:+.1f} mm off)")
                    tried.append(Fit(name, transform, chain.scale, list(range(len(pairs))), chain.loo,
                                     offset=chain.offset, tracked=True, centres=chain.centres, along=chain.along,
                                     broken=list(chain.broken)))
    if not tried:
        return None, tried, plane_used
    best = choose_fit(tried)
    if try_correction and len(best.used) >= CORRECTION_MIN_SPOTS:
        sightings = views[0 if "colour" in best.name else 1][1]
        cam = np.array([s.cam_xyz for s in sightings], float)[best.used]
        if best.tracked:        # (the truth: where the tracking put each cube's middle)
            correction, loo = correction_for(cam, np.asarray(best.centres, float)[best.used], fit_table(sightings),
                                             table_z, "scale" in best.name)
        else:
            correction, loo = correction_for(cam, robot_xy[best.used], fit_table(sightings), table_z,
                                             "scale" in best.name, best.offset, r_deg[best.used])
        corrected = float(np.median(np.hypot(loo[:, 0], loo[:, 1])))
        if corrected <= CORRECTION_GAIN * best.typical_mm:
            best = dataclasses.replace(best, name=best.name + ", corrected over the table", loo=loo,
                                       correction=correction)
            tried.append(best)
    return best, tried, plane_used


TRACKED_GAIN_SHARE, TRACKED_GAIN_MM = 0.8, 0.03   # a fit tracking the cube in the fingers: kept when it predicts
                                                  # the spots this share as far off or better, and by this much
EXTRA_GAIN_MM, EXTRA_GAIN_SHARE = 0.15, 0.10   # what each extra kind of number (a scale, the gripper's offset) must
                                                # earn: the spots predicted this much better (the larger), each
MAX_SCALE_OFF = 0.03        # a scale further than this from 1 isn't the camera's: left out
MAX_OFFSET_MM = 15.0        # a gripper's middle further than this from the tool point isn't believable: left out


def _extras(fit: "Fit") -> int:
    if getattr(fit, "tracked", False):         # (its offset along the fingers is the grips' own, not one more number)
        return int("scale" in fit.name) + 1 + int("measured across" in fit.name)
    return int("scale" in fit.name) + int(fit.offset is not None)


def choose_fit(tried: list) -> "Fit":
    """The fit to keep. The simplest that predicts the spots best, unless one with more adjustable numbers (a scale,
    the gripper's offset) predicts them better by a clear margin -- per extra kind, EXTRA_GAIN_MM or EXTRA_GAIN_SHARE
    of the error, the larger. (The lab, 2026-10-12: a scale of 0.98 and the gripper's middle 6.5 mm off won by 0.04 mm,
    1.69 against 1.73; the next calibration measured the offset at +6.9 the other way. With 6-8 spots, two more
    numbers soak up noise rather than measure anything.) Fits with an unbelievable scale or offset are left out."""
    believable = [f for f in tried
                  if abs(f.scale - 1.0) <= MAX_SCALE_OFF
                  and (f.offset is None or float(np.hypot(*np.asarray(f.offset, float)[:2])) <= MAX_OFFSET_MM)]
    pool = believable or tried
    plain = [f for f in pool if not getattr(f, "tracked", False)]
    tracked = [f for f in pool if getattr(f, "tracked", False) and _grip_changed(f)]
    best = _simplest_best(plain or pool)
    if plain and tracked:
        # tracking the cube in the fingers (solve_chain) is a different account of the spots, not a number more: it
        # is kept when it predicts them clearly better, by share (in the twin, a knocked cube's spots were
        # predicted to 0.09 mm by it and 0.14 by the plain fit -- 0.19 and 0.68 mm off the truth)
        chain = _simplest_best(tracked)
        if tracking_wins(chain.typical_mm, best.typical_mm):
            best = chain
    return best


def _grip_changed(fit) -> bool:
    """A tracked fit's grips really changed (see GRIP_CHANGE_MM)."""
    along = getattr(fit, "along", None)
    return bool(getattr(fit, "broken", None)) or (along is not None and float(np.ptp(along)) >= GRIP_CHANGE_MM)


def tracking_wins(chain_mm: float, plain_mm: float) -> bool:
    """A fit tracking the cube in the fingers predicts the spots clearly better than the plain one."""
    return chain_mm <= TRACKED_GAIN_SHARE * plain_mm and chain_mm < plain_mm - TRACKED_GAIN_MM


def _simplest_best(pool: list) -> "Fit":
    """choose_fit's rule within one kind of fit: the simplest, unless more numbers earn their place."""
    best = min((f for f in pool if _extras(f) == min(_extras(g) for g in pool)), key=lambda f: f.typical_mm)
    for fit in sorted(pool, key=_extras):
        more = _extras(fit) - _extras(best)
        if more <= 0:
            if fit is not best and _extras(fit) == _extras(best) and fit.typical_mm < best.typical_mm - 0.02:
                best = fit
            continue
        if fit.typical_mm < best.typical_mm - more * max(EXTRA_GAIN_MM, EXTRA_GAIN_SHARE * best.typical_mm):
            best = fit
    return best


def predict(transform: np.ndarray, correction: Optional[XYCorrection], cam_xyz) -> np.ndarray:
    """Robot coordinates of a camera point, the correction (if any) included."""
    point = (np.asarray(transform, float) @ np.append(np.asarray(cam_xyz, float), 1.0))[:3]
    if correction is not None:
        point[0], point[1] = correction.apply(point[0], point[1])
    return point


def describe_pattern(loo: np.ndarray, robot_xy: np.ndarray, pixels: np.ndarray, k: Intrinsics) -> str:
    """What the misses left look like, in words: a lean (the same way everywhere), growing with the arm's reach,
    growing towards the picture's edges (the lens), or scattered (noise)."""
    if len(loo) < 4:
        return ""
    sizes = np.hypot(loo[:, 0], loo[:, 1])
    typical = float(np.median(sizes))
    mean = loo.mean(axis=0)
    if np.linalg.norm(mean) > max(0.3, 0.6 * typical):
        return (f"they lean one way (on average {np.linalg.norm(mean):.1f} mm towards "
                f"{'+' if mean[0] >= 0 else '-'}x, {'+' if mean[1] >= 0 else '-'}y)")

    def follows(values: np.ndarray) -> bool:
        return float(np.std(values)) > 1e-6 and float(np.corrcoef(values, sizes)[0, 1]) > 0.6
    if follows(np.hypot(robot_xy[:, 0], robot_xy[:, 1])):
        return "they grow with the arm's reach (the arm's own error)"
    if follows(np.hypot(pixels[:, 0] - k.cx, pixels[:, 1] - k.cy)):
        return "they grow towards the picture's edges (the lens)"
    return "they are scattered (noise), with no pattern"


# ---- the arm ------------------------------------------------------------------------------------------------------------
class _Stopped(Exception):
    pass


@dataclass
class Look:
    depth: np.ndarray                    # lined up with the colour camera's picture
    raw: Optional[np.ndarray] = None     # the depth sensor's own
    rgb: Optional[np.ndarray] = None     # the last colour picture


def raw_view(camera) -> Optional[tuple[Intrinsics, np.ndarray]]:
    """(the depth sensor's own intrinsics, its depth->colour transform) if the camera gives its unaligned depth."""
    info = getattr(camera, "raw_depth_info", None)
    if not callable(info):
        return None
    try:
        return info()
    except Exception as exc:  # noqa: BLE001 - an extra, never a reason to stop
        logger.info("No raw depth from the camera: %s", exc)
        return None


# where to touch the table (robot x, y mm), as the Calibration tab offers them: the middle, stretched out, to each side
# and the sheet's near corners -- the reach spread 110 mm and the sides 220 mm apart, so the height is learnt with the
# reach and from side to side, with touches to spare (3 numbers from 6: one a little off is averaged, not taken as it
# is). Rafi, 2026-10-18 (4) and 2026-10-19 (6).
TOUCH_POINTS = (("middle", 225.0, 0.0), ("stretched out", 275.0, 0.0), ("left", 200.0, 110.0),
                ("right", 200.0, -110.0), ("near left", 165.0, 90.0), ("near right", 165.0, -90.0))
# (6, 2026-10-19: the sheet's near corners too, where cubes start in many tasks -- two to spare; none at the far left,
# y 130-230, which the camera sees badly)
TOUCH_SAME_MM = 40.0        # a touch this near an earlier one replaces it
ODD_OFF_MM = 1.0            # a touch this far off the others' fit is the odd one (TableHeights.odd_one)...
ODD_AGREE_MM = 0.5          # ...when without it the others agree to this
# the touches' verdict (TableHeights.verdict): good -- every one within VERDICT_GOOD_MM of the fit and the table sloping
# less than VERDICT_SLOPE mm per 100 mm; redo -- one more than VERDICT_REDO_MM off it, or too steep; else usable
VERDICT_GOOD_MM = 0.5
VERDICT_REDO_MM = 1.5
VERDICT_SLOPE = 3.0
TOUCH_SPREAD_MM = 40.0      # touches this much further out than each other tell how the height changes with the reach
TOUCH_MAX_SLOPE = 0.06      # over 6 mm per 100 mm: a touch that wasn't on the table (or pressed into it)...
TOUCH_MAX_SLOPE_AGREED = 0.12   # ...but 4 or more touches that agree on a plane (to VERDICT_REDO_MM) are believed up
                            # to this (the lab, 2026-10-21: 6 touches within 0.6 mm of a plane 7.0 mm per 100 mm out of
                            # level -- the arm's own heights, more likely than the table -- and every calibration was
                            # refused; the put-downs follow the plane, whatever its slope)


class TableHeights:
    """Where the table is (robot z) at (x, y), from the fingertips touching it at one place or more: (x, y, z) each.
    The Dobot stands a little higher or lower the further it stretches (at the lab, stretched out, it let the cube
    go 2-3 mm higher than near), and a table can slope. One touch: the same height everywhere. Two, one further out
    than the other: the height changes with the reach. Three or more, spread sideways too: also from side to side.
    Never more than the touches show: past them (40 mm on), the height stays as at the edge."""

    def __init__(self, touches):
        self.touches = [tuple(float(v) for v in t[:3]) for t in touches]
        pts = np.array(self.touches, float).reshape(-1, 3)
        reach = np.hypot(pts[:, 0], pts[:, 1])
        self._coef = np.array([float(np.mean(pts[:, 2])) if len(pts) else 0.0])
        self._reach = self._side = None
        if len(pts) >= 2 and np.ptp(reach) >= TOUCH_SPREAD_MM:
            columns = [np.ones(len(pts)), reach]
            if len(pts) >= 3 and np.ptp(pts[:, 1]) >= 2 * TOUCH_SPREAD_MM:
                columns.append(pts[:, 1])
                self._side = (float(pts[:, 1].min()) - TOUCH_SPREAD_MM, float(pts[:, 1].max()) + TOUCH_SPREAD_MM)
            self._coef = np.linalg.lstsq(np.stack(columns, axis=1), pts[:, 2], rcond=None)[0]
            self._reach = (float(reach.min()) - TOUCH_SPREAD_MM, float(reach.max()) + TOUCH_SPREAD_MM)

    def at(self, x: float, y: float) -> float:
        z = float(self._coef[0])
        if self._reach is not None:
            z += float(self._coef[1]) * min(max(math.hypot(x, y), self._reach[0]), self._reach[1])
        if self._side is not None:
            z += float(self._coef[2]) * min(max(y, self._side[0]), self._side[1])
        return z

    def spread_mm(self) -> float:
        """The most any touch is off the fit through all of them (0 with 3 or fewer: they fit exactly)."""
        return max((abs(z - self.at(x, y)) for x, y, z in self.touches), default=0.0)

    def odd_one(self) -> Optional[int]:
        """The touch that is off (pressed into the table, or not quite on it), when it can be told: the one without
        which the others agree (to ODD_AGREE_MM) and from whose fit it is more than ODD_OFF_MM off. Only with 6 or
        more: with 4 or 5 a single bad touch moves the fit through all of them alike -- the one marked as off, by how
        far it was from the fit, was a good one (the middle), and the bad one wasn't marked."""
        if len(self.touches) < 6 or self.spread_mm() <= ODD_OFF_MM / 2:
            return None
        fits = []
        for i, (x, y, z) in enumerate(self.touches):
            others = TableHeights(self.touches[:i] + self.touches[i + 1:])
            fits.append((others.spread_mm(), abs(z - others.at(x, y)), i))
        agree, off, index = min(fits)
        return index if agree <= ODD_AGREE_MM and off > ODD_OFF_MM else None

    @property
    def slope_per_100mm(self) -> float:
        """The steepest the table slopes, out from the base or from side to side, mm per 100 mm (absolute)."""
        side = 100.0 * abs(float(self._coef[2])) if self._side is not None else 0.0
        return max(abs(self.per_100mm), side)

    def verdict(self) -> tuple[str, str]:
        """Whether these touches will do for a calibration, in one line: ("good" | "usable" | "redo", words)."""
        spread, slope, odd = self.spread_mm(), self.slope_per_100mm, self.odd_one()
        off = None
        if odd is not None:
            x, y, z = self.touches[odd]
            off = abs(z - TableHeights(self.touches[:odd] + self.touches[odd + 1:]).at(x, y))
        if self.too_steep or spread > VERDICT_REDO_MM:
            if odd is not None:              # (one is to blame: just that one)
                return "redo", f"Redo T{odd + 1}: it is {off:.1f} mm off the others."
            if self.agreed:                  # (they agree: the plane is the trouble)
                return "redo", (f"The touches agree, but on a plane {slope:.1f} mm per 100 mm out of level: press Home "
                                "and touch again.")
            return "redo", "Redo the touches: they disagree too much to calibrate."
        if odd is not None:
            return "usable", f"Usable. T{odd + 1} is {off:.1f} mm off; redo it for best results."
        if spread > VERDICT_GOOD_MM:
            return "usable", f"Usable. The touches agree to {spread:.1f} mm."
        if slope >= VERDICT_SLOPE:
            return "usable", (f"Usable. The table (or the arm) slopes {slope:.1f} mm per 100 mm: the calibration "
                              "follows it. If the arm wasn't homed, press Home and touch again.")
        return "good", "Good to calibrate."

    def covers(self, x: float, y: float) -> bool:
        """Whether (x, y) is where the touches tell the height (TOUCH_SPREAD_MM past them at most): out from the base
        once they spread with the reach, and side to side once they spread sideways too. Past that, `at` only carries
        the edge's height on -- a guess."""
        if self._reach is not None and not self._reach[0] <= math.hypot(x, y) <= self._reach[1]:
            return False
        return self._side is None or self._side[0] <= y <= self._side[1]

    @property
    def per_100mm(self) -> float:
        """How much higher the table is, 100 mm further out (0 with one touch)."""
        return 100.0 * float(self._coef[1]) if self._reach is not None else 0.0

    @property
    def too_steep(self) -> bool:
        side = 100.0 * abs(float(self._coef[2])) if self._side is not None else 0.0
        slope = max(abs(self.per_100mm), side)
        if self.agreed:
            return slope > 100.0 * TOUCH_MAX_SLOPE_AGREED
        return slope > 100.0 * TOUCH_MAX_SLOPE

    @property
    def agreed(self) -> bool:
        """4 or more touches on one plane (to VERDICT_REDO_MM): its slope is then believed, steep as it is."""
        return len(self.touches) >= 4 and self.spread_mm() <= VERDICT_REDO_MM

    def describe(self) -> str:
        if len(self.touches) == 1:
            return f"z = {self.touches[0][2]:.1f} mm (touched at 1 place)"
        text = f"touched at {len(self.touches)} places, z {min(t[2] for t in self.touches):.1f} to " \
               f"{max(t[2] for t in self.touches):.1f} mm"
        if self._reach is not None:
            text += f"; {self.per_100mm:+.1f} mm per 100 mm further out"
        return text


ARM_SLOPE_WARN = 3.0        # the table reads this much higher or lower per 100 mm further out: the arm's own heights
                            # are suspect (the release follows the touches, but every coordinate is likely off too)
TABLE_MOVED_WARN_MM = 5.0   # the table reads this differently from the last calibration: was the arm homed?


def arm_check(touches: list, last_table_z: Optional[float] = None, homed: bool = True) -> list[str]:
    """What the table touches say about the arm's own idea of where it is, as warnings in words (none: fine).
    The table is flat: a homed arm reads about the same height everywhere on it, and the same as last time."""
    warnings = []
    if not homed:
        warnings.append("the Dobot hasn't been homed since the app connected to it: if it was switched off and on, "
                        "its coordinates can be centimetres out. Press Home (Manual tab), then touch the table again")
    if touches:
        heights = TableHeights(touches)
        if len(touches) >= 2 and abs(heights.per_100mm) > ARM_SLOPE_WARN:
            warnings.append(f"the table reads {heights.per_100mm:+.1f} mm higher per 100 mm further out. The cube "
                            "is let go by it, but that much says the arm's own angles are off: press Home and touch "
                            "again; if it stays, calibrate the Dobot's arm angles (DobotStudio)")
        if last_table_z is not None:
            now = heights.at(*touches[-1][:2])
            if abs(now - last_table_z) > TABLE_MOVED_WARN_MM:
                warnings.append(f"the table reads z = {now:.1f} mm now, but {last_table_z:.1f} at the last "
                                "calibration: the arm's heights changed. Was it homed? Did the robot or the table "
                                "move?")
    return warnings


def with_touch(touches: list, touch: tuple) -> list:
    """The touches with one more (it replaces one within TOUCH_SAME_MM of it)."""
    kept = [t for t in touches if math.dist(t[:2], touch[:2]) > TOUCH_SAME_MM]
    return kept + [tuple(float(v) for v in touch[:3])]


def _wrap90(angle: float) -> float:
    return (angle + 45.0) % 90.0 - 45.0


def cube_turned(history: list, fits_deg: Optional[float] = None) -> float:
    """How far (degrees, anticlockwise from above) the cube turned as it was let go at the last spot: its sides'
    turn against the wrist's there (`history`: one per spot so far, the last this one), against the usual one (the
    fingers square the cube up each time they take it). 0 within turn_threshold (the outline's own noise), and no
    more than TURN_FIX_MAX_DEG either way; 0 at the first spot (it is the usual one the next go by: the cube was
    squeezed square in the fingers there). (From the fourth spot until 2026-10-26: the lab's spot 2 came up empty.)"""
    turned = turn_estimate(history)
    if turned is None or abs(turned) < turn_threshold(history, fits_deg):
        return 0.0
    return float(max(-TURN_FIX_MAX_DEG, min(TURN_FIX_MAX_DEG, turned)))


def turn_threshold(history: list, fits_deg: Optional[float] = None) -> float:
    """A turn read under this is taken for the camera's noise: TURN_FIX_MIN_DEG, or the readings' own scatter
    (turn_noise) if more -- but never past `fits_deg`, the most the cube can be turned and still go between the
    fingers (see fits_turn): a turn read past that is matched however noisy the camera, as left alone the finger
    would land on the cube, while matching a wrong reading costs no more than the noise."""
    limit = max(TURN_FIX_MIN_DEG, turn_noise(history))
    return limit if fits_deg is None else max(TURN_FIX_MIN_DEG, min(limit, fits_deg))


def fits_turn(side: float, opening: float) -> float:
    """The most (degrees) a cube of `side` can be turned against the fingers and still go between them, opened
    `opening` wide, with the camera's own TURN_NOISE_DEG to spare."""
    ratio = opening / (side * math.sqrt(2.0))
    if ratio >= 1.0:
        return 45.0
    return max(0.0, math.degrees(math.asin(ratio)) - 45.0 - TURN_NOISE_DEG)


def turn_noise(history: list) -> float:
    """How far the earlier spots' readings scatter round the usual turn (3 x their typical deviation): a reading
    within this is the camera's noise, not the cube turning. (With a Realistic camera the cube never turned, yet
    readings of +5 and -4 degrees made the wrist turn, leaving 0.13 mm of room each side.)"""
    if len(history) < 5:
        return 0.0
    earlier = np.asarray(history[:-1], float)
    angles = np.radians(4.0 * earlier)
    usual = math.degrees(math.atan2(np.sin(angles).mean(), np.cos(angles).mean())) / 4.0
    deviations = np.abs([_wrap90(a - usual) for a in earlier])
    return float(3.0 * 1.4826 * np.median(deviations))


def turn_estimate(history: list) -> Optional[float]:
    """cube_turned's measure as it is (no noise floor, no limit), or None at the first spot. From two to three spots
    the usual turn is the earlier spots' (too few for a median to leave an odd one out); from four, all of them."""
    if len(history) < 2:
        return None
    if len(history) < 4:
        earlier = np.radians(4.0 * np.asarray(history[:-1], float))
        usual = math.degrees(math.atan2(np.sin(earlier).mean(), np.cos(earlier).mean())) / 4.0
        return float(_wrap90(history[-1] - usual))
    angles = np.radians(4.0 * np.asarray(history, float))
    usual = math.degrees(math.atan2(np.sin(angles).mean(), np.cos(angles).mean())) / 4.0
    usual += float(np.median([_wrap90(a - usual) for a in history]))
    return float(_wrap90(history[-1] - usual))


class _TableDz:
    """How much higher the table is at (x, y) than at `table_z` (the touches'); kept with a run's progress."""

    def __init__(self, heights: TableHeights, table_z: float):
        self.heights, self.table_z = heights, float(table_z)

    def __call__(self, x: float, y: float) -> float:
        return self.heights.at(x, y) - self.table_z


class _Paused(Exception):
    """The run stops where it is so the user can take over (they pressed Pause, or the robot needs a hand)."""

    def __init__(self, why: str, advice: str = "", knocked: bool = False):
        super().__init__(why)
        self.why, self.advice, self.knocked = why, advice, knocked


class _Arm:
    """The moves the routine is made of, with Stop checked between them. `dz(x, y)`: how much higher the table is
    there than where the cube was gripped (every move near it is that much higher)."""

    def __init__(self, robot, camera, settle_s: float, frames: int, say, cancel, raw: bool = False, dz=None,
                 pause=None):
        self.robot, self.camera, self.settle_s, self.frames = robot, camera, settle_s, frames
        self.say, self.cancel, self.raw, self.dz, self.pause = say, cancel, raw, dz, pause
        self.acted = False
        self.closed = False        # (the last down_and's action was closing the gripper on the cube)
        self.acted_at: Optional[tuple] = None      # (x, y) where it was done

    def check(self) -> None:
        if self.cancel is not None and self.cancel():
            raise _Stopped()
        if self.pause is not None and self.pause():
            raise _Paused("you pressed Pause")

    def move(self, x: float, y: float, z: float, r: float) -> None:
        self.check()
        if self.dz is not None:
            z += self.dz(x, y)
        self.robot.move_to(Pose(x=x, y=y, z=z, r=r))

    def move_slow(self, x: float, y: float, z: float, r: float, speed_mm_s: float) -> None:
        """move(), at `speed_mm_s` (the Dobot: by its pace, put back after)."""
        from app.hardware.wrist import slow_move
        self.check()
        if self.dz is not None:
            z += self.dz(x, y)
        slow_move(self.robot, Pose(x=x, y=y, z=z, r=r), speed_mm_s)

    def away(self, pose: Pose) -> None:
        """To a waiting place, in the controller's own terms: the arm then stands exactly where it stood for the
        empty-table picture, whatever offset the robot moves by now (3.6 mm off, the arm itself was "new")."""
        self.check()
        mover = getattr(self.robot, "_move_to_raw", None)
        (mover or self.robot.move_to)(Pose(pose.x, pose.y, pose.z, pose.r))

    def down_and(self, x: float, y: float, z: float, r: float, lift: float, action) -> None:
        """Over (x, y) (turned to r up there), down to z, `action` (open or close), back up. `acted` says, after a
        move fails, whether the action was done (the cube let go of, or taken)."""
        self.acted, self.closed = False, False
        here = self.robot.get_pose()
        if here.z < z + lift - 0.5 + (self.dz(x, y) if self.dz is not None else 0.0):   # up first, then across
            self.move(here.x, here.y, z + lift, here.r)
        self.move(x, y, z + lift, r)
        self.move(x, y, z, r)
        time.sleep(self.settle_s * 0.25)               # (stretched out, the arm sways a moment after it stops)
        self.check()
        action()
        self.acted, self.closed = True, action == self.robot.close_gripper
        self.acted_at = (x, y)
        time.sleep(self.settle_s * 0.5)
        if not self.closed and RELEASE_SLOW_MM > 0.0 and lift > RELEASE_SLOW_MM:
            # let go: up past the cube's sides slowly, so a finger still touching it doesn't drag it along
            self.move_slow(x, y, z + RELEASE_SLOW_MM, r, RELEASE_SPEED_MM_S)
        self.move(x, y, z + lift, r)

    def retried(self, what: str, step) -> None:
        """`step()`, and once more if the robot refused a move (it doesn't always answer the first time): up out of
        the way first, from wherever it stopped."""
        try:
            step()
            return
        except RobotStopped:
            raise
        except (RuntimeError, TimeoutError) as exc:
            logger.warning("%s failed (%s); trying once more", what, exc)
        taken = self.acted and self.closed          # (the cube was taken before it failed: only the lift is left)
        time.sleep(0.5)
        here = self.robot.get_pose()
        try:
            self.move(here.x, here.y, here.z + 20.0, here.r)
        except RobotStopped:
            raise
        except (RuntimeError, TimeoutError):
            pass
        if taken:
            return
        step()

    def look(self) -> Look:
        time.sleep(self.settle_s)
        depth, frame = median_depth(self.camera, self.frames)
        raw = None
        if self.raw:
            try:
                raw = median_of([self.camera.get_raw_depth() for _ in range(self.frames)])
            except Exception as exc:  # noqa: BLE001
                logger.info("Raw depth look failed: %s", exc)
                self.raw = False
        return Look(depth, raw, getattr(frame, "rgb", None))


@dataclass
class _Hand:
    """Heights for the cube in hand: where the fingertips go to take one, and to let one go."""
    table_z: float
    first_grip: float              # the user's grip: fingertips this far above the table
    grip: float                    # the cube held now: the fingertips this far above its foot
    cube_h: float = 20.0
    finger_mm: Optional[float] = None    # how far down a cube's sides the fingers reach (None: no limit known)

    def release_z(self, level: int = 1) -> float:
        foot = self.table_z + (level - 1) * self.cube_h
        return foot + self.grip + (GAP_MM if level == 1 else STACK_GAP_MM)

    def pick_z(self, level: int = 1) -> float:
        foot = self.table_z + (level - 1) * self.cube_h
        if level == 1:
            return foot + self.first_grip + REPICK_UP_MM
        # clear of the cube under it, and no lower than the fingers reach (the gripper's body would sit on the cube:
        # the Dobot's fingers reach 15 mm down a 20 mm cube)
        reach = 0.0 if self.finger_mm is None else self.cube_h - self.finger_mm + 1.0
        return foot + max(STACK_REPICK_MM, reach)

    def taken(self, level: int = 1) -> None:
        self.grip = self.pick_z(level) - (self.table_z + (level - 1) * self.cube_h)


def _gripper_gap(robot) -> Optional[float]:
    """The xArm's gripper says how far it closed (its SDK units): the gap, mm; None for a gripper that can't."""
    opening = getattr(robot, "gripper_opening", None)
    if not callable(opening):
        return None
    try:
        value = opening()
        from app.hardware.xarm import GRIPPER_OPEN, OPEN_STROKE_MM
        return None if value is None else float(value) / GRIPPER_OPEN * OPEN_STROKE_MM
    except Exception:  # noqa: BLE001 - a size reading is a nicety, never a reason to stop
        return None


def _recentre(arm: "_Arm", robot, x: float, y: float, z: float, middle: float) -> None:
    """With the cube held at (x, y), the fingertips at z and the wrist in its middle: open and close again in place
    (the fingers centre it across them), then up. The wrist never turns: turned 45 degrees the fingers close on the
    cube's corners, wider than they open (a 20 mm cube is 28 mm corner to corner; the Dobot's open 27.5), and turned
    90 is the end of the Dobot's wrist. Where the cube sits along the fingers isn't changed: if it changes from spot
    to spot (a knock), the camera tracks it (see solve_chain)."""
    robot.open_gripper()
    robot.close_gripper()
    arm.move(x, y, z + LIFT_MM, middle)


def _quarter_turn(gripper, r: float, x: float, y: float) -> float:
    """The wrist a quarter turn from r at (x, y), whichever way it can go."""
    for turn in (90.0, -90.0):
        if gripper is None or gripper.wrist_fits(r + turn, x, y):
            return r + turn
    return r + 90.0


@dataclass
class CubeOutcome:
    mode: str = "precise"
    pairs: list = field(default_factory=list)          # every spot found (CubePair)
    used: list = field(default_factory=list)           # the ones the fit kept
    spots_tried: int = 0
    skipped: list = field(default_factory=list)        # why spots were left out, in words
    fit: Optional[Fit] = None
    tried: list = field(default_factory=list)          # every fit worked out (Fit)
    plane: Optional[TablePlane] = None
    errors_mm: list = field(default_factory=list)      # each kept spot, left out of the fit: error seen from above
    before_mm: list = field(default_factory=list)      # the same spots through the calibration in use before
    transform: Optional[np.ndarray] = None             # the result, heights included
    correction: Optional[XYCorrection] = None
    tool_offset_mm: Optional[tuple] = None             # the cube's middle from the tool point, in the tool's frame
    offset_used: bool = False                          # ...and the result was made with it (robots move by it)
    base_offset: tuple = (0.0, 0.0)                    # the offset the robot already moved by while measuring
    tool_offset_gain: Optional[tuple] = None           # (typical error without it, with it), mm
    up_check_deg: Optional[float] = None               # the table's "up" against a free 3D fit's
    height_bias_mm: Optional[float] = None             # cube tops' height by the result minus by the cube's size
    slip_mm: Optional[float] = None                    # the latest look back at the first spot (a failed one too)
    slip_worst_mm: Optional[float] = None              # the worst of the looks back the run kept (see _check_first)
    grip_along_mm: list = field(default_factory=list)  # tracked (see solve_chain): each spot, where along the fingers
    notes: list = field(default_factory=list)          # worth knowing, though it passed (in words)
    turn_fixes: list = field(default_factory=list)     # (spot, degrees): the cube turned as it was let go
    sides_mm: Optional[tuple] = None                   # the cube's middle by its sides minus by its top (cross-check)
    fingers: Optional[tuple] = None                    # (offset, scatter, spots): see fingers_angle
    jaw_axis_deg: Optional[float] = None               # the fingers' real angle at r = 0, if measured well enough
    pattern: str = ""
    table_z: Optional[float] = None
    table_from: str = ""                               # "touched ..." or "assumed" (1 mm below the grip)
    table_dz: Optional[Callable] = None                # how much higher the table is at (x, y) than at table_z
    cube_mm: Optional[tuple] = None                    # (narrow side, long side, height), the camera's
    cube_h: Optional[float] = None                     # the height used (typed in, or the camera's)
    gripper_mm: Optional[tuple] = None                 # (side, other side), the gripper's (xArm)
    passed: bool = False
    reason: str = ""
    over_limit: bool = False                           # failed only by its typical error over pass_mm: may be saved
    slipped: bool = False                              # a check at the first spot saw the cube moved over SLIP_MM
    pass_mm: Optional[float] = None                    # the mode's limit
    cancelled: bool = False
    paused: bool = False                               # stopped for the user to take over (reason: why)
    keep_progress: bool = False                        # the run can be carried on (see CubeProgress)
    k: Optional[Intrinsics] = None
    # for what follows (pick test, stacks): where things are left
    hand: Optional[_Hand] = None
    r: float = 0.0
    turns: tuple = (0.0,)
    cube_at: Optional[tuple] = None                    # where cube A is, or None if it is held
    holding: bool = False
    away_index: int = 0
    background: Optional[Look] = None                  # the arm away holding A, nothing new on the table
    spot_log: list = field(default_factory=list)       # every spot: where, and what the camera measured (dicts)
    pictures: list = field(default_factory=list)       # the first few looks: (spot xy, Look), for a failed run's record

    @property
    def typical_mm(self) -> Optional[float]:
        return float(np.median(self.errors_mm)) if self.errors_mm else None

    @property
    def worst_mm(self) -> Optional[float]:
        return float(max(self.errors_mm)) if self.errors_mm else None

    @property
    def grip_z(self) -> float:
        return self.hand.table_z + self.hand.first_grip if self.hand else 0.0

    @property
    def offset(self) -> Optional[np.ndarray]:
        """What the measurements' positions need moving by (the offset found on top of the one moved by)."""
        return np.asarray(self.tool_offset_mm, float) if self.offset_used and self.tool_offset_mm else None

    @property
    def total_offset(self) -> tuple:
        """The gripper's middle from the controller's tool point, all of it: what the robot moves by from now."""
        extra = self.offset if self.offset is not None else np.zeros(2)
        return float(self.base_offset[0] + extra[0]), float(self.base_offset[1] + extra[1])

    def arrows(self, gain: float = 15.0) -> list[dict]:
        """Marks for the camera picture: from each spot, which way (and, `gain` times larger, how far) the result
        missed it when left out."""
        if self.fit is None or self.transform is None or self.k is None:
            return []
        to_camera = np.linalg.inv(self.transform)
        k, h = self.k, self.cube_h or 0.0
        marks = []
        for pair, (dx, dy) in zip(self.used, self.fit.loo):
            x, y, z = pair.robot_xyz(self.table_z, h, self.offset)
            ends = []
            for px, py in ((x, y), (x - gain * dx, y - gain * dy)):
                q = to_camera @ np.array([px, py, z, 1.0])
                ends.append((k.fx * q[0] / q[2] + k.cx, k.fy * q[1] / q[2] + k.cy))
            marks.append({"u": ends[0][0], "v": ends[0][1], "u2": ends[1][0], "v2": ends[1][1], "kind": "arrow",
                          "label": f"{math.hypot(dx, dy):.1f}"})
        return marks


@contextmanager
def _calibration_pace(robot):
    """While calibrating, every move slower (the Dobot: half speed). Its motors skip a step less easily -- a skipped
    step moves every coordinate after it -- and calibrating needs no speed. Put back after."""
    setter = getattr(robot, "set_pace", None)
    before = None
    if callable(setter):
        try:
            before = setter(CALIBRATION_PACE)
        except Exception as exc:  # noqa: BLE001 - slower is a nicety, never a reason not to calibrate
            logger.info("Couldn't slow the moves for calibrating: %s", exc)
    try:
        yield
    finally:
        if before is not None:
            try:
                setter(*before)
            except Exception as exc:  # noqa: BLE001
                logger.warning("Couldn't put the moves' speed back (%s): it stays at %.0f%%", exc, CALIBRATION_PACE)


def _paced(work):
    """`work(robot, ...)` at the calibrating pace (see _calibration_pace)."""
    @functools.wraps(work)
    def run(robot, *args, **kwargs):
        with _calibration_pace(robot):
            return work(robot, *args, **kwargs)
    return run


@dataclass
class CubeProgress:
    """A cube calibration's phase 1 so far, saved after every spot: a run that was paused (by the user, or by the
    robot asking for help), stopped or E-stopped carries on from where it was, the cube gripped again by hand."""
    out: CubeOutcome
    route: list                          # (x, y, turn) for every spot
    backgrounds: list                    # the empty table from each waiting place (Look)
    away: list                           # the waiting places (Pose)
    mode: str
    cube_size_mm: Optional[float]
    old_transform: Optional[np.ndarray]
    base_offset: tuple                   # the gripper's offset the robot moved by while measuring
    next_index: int = 0                  # the spot to do next
    pending: Optional[dict] = None       # the spot under way when it stopped: {"index", "measured", "pair"}
    gaps: list = field(default_factory=list)
    sides: list = field(default_factory=list)      # each spot: the cube's sides' turn against the wrist's
    good_pairs: int = 0                  # how many spots were measured when the arm last kept its place...
    good_index: int = 0                  # ...and the spot after them
    good_sides: int = 0                  # ...and the turns in `sides` then (a failed check drops the rest too)
    since_check: int = 0                 # spots since the cube was last put back at the first spot
    last: Optional[tuple] = None         # (x, y, r) where the cube was last taken from
    why: str = ""                        # why it stopped, in words
    saved_at: float = 0.0                # time.time()
    paper: bool = False                  # "Cube calibration with paper" (the app's): the paper is found when it passes
    count: int = 0                       # how many spots the run was started with (planned again if it stopped first)
    carried_from: Optional[CubePair] = None   # the spot whose take-back holds the cube now (None: gripped by hand,
                                              # or taken where the camera didn't see it: its place in the fingers
                                              # isn't known)

    @property
    def spots_done(self) -> int:
        return self.next_index

    def describe(self) -> str:
        found = sum(1 for p in self.out.pairs if not p.check)
        return (f"{self.out.mode}: {self.next_index} of {len(self.route)} spots done ({found} measured)"
                + (f", stopped {time.strftime('%H:%M', time.localtime(self.saved_at))}" if self.saved_at else ""))


PROGRESS_FORMAT = 2         # (2: the pairs' grips tracked -- taken_xy, prev -- and carried_from, held_at)


def progress_path(calibration_path) -> Path:
    path = Path(calibration_path)
    return path.with_name(path.stem + "_cube_progress.pkl")


def save_progress(path, progress: CubeProgress) -> None:
    """Written whole or not at all (a power cut while saving leaves the last one)."""
    progress.saved_at = time.time()
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(pickle.dumps((PROGRESS_FORMAT, progress), protocol=pickle.HIGHEST_PROTOCOL))
    os.replace(temporary, path)


def load_progress(path) -> Optional[CubeProgress]:
    """The saved progress (the app's own file), or None if there is none or it can't be read."""
    path = Path(path)
    if not path.exists():
        return None
    try:
        version, progress = pickle.loads(path.read_bytes())
        return progress if version == PROGRESS_FORMAT and isinstance(progress, CubeProgress) else None
    except Exception as exc:  # noqa: BLE001 - an old or damaged file: as good as none
        logger.warning("The cube calibration in progress couldn't be read (%s): starting afresh", exc)
        return None


def run_cube_calibration(robot, camera, bounds: dict, reach_mm: float, gripper=None,
                         resume: Optional[CubeProgress] = None, **kwargs) -> CubeOutcome:
    """Phase 1 (see _run_cube_calibration). Measured from no gripper offset at all, found afresh: one an earlier
    calibration measured is never built on (the lab: a shaky 7-spot run's -8.8 mm was carried into every calibration
    after it, and every put-down and pick landed off by it). The robot moves by what was found if the result passed;
    otherwise by the offset it had before. `resume`: carry on with a run that stopped (with the offset it began with)."""
    before = tuple(float(v) for v in getattr(robot, "tool_centre_mm", (0.0, 0.0)))
    base = tuple(float(v) for v in resume.base_offset) if resume is not None else (0.0, 0.0)
    if hasattr(robot, "tool_centre_mm"):
        robot.tool_centre_mm = base
    out = None
    try:
        with _calibration_pace(robot):
            out = _run_cube_calibration(robot, camera, bounds, reach_mm, gripper, resume=resume, **kwargs)
        out.base_offset = base
        return out
    finally:
        # (only a result that passed is saved: paused, stopped or failed -- even paused as it finished solving -- the
        # robot moves by the offset it had before, or it would keep one nothing saved)
        if hasattr(robot, "tool_centre_mm"):
            if out is not None and out.passed and not (out.paused or out.cancelled):
                _use_offset(robot, out)
            else:
                robot.tool_centre_mm = before


def _take_back(arm: "_Arm", robot, x: float, y: float, z: float, middle: float, turned: float = 0.0) -> None:
    """Over the cube at (x, y), down round it, grip it (closing centres it across the fingers), up. `arm.acted`
    once it is held."""
    arm.acted = arm.closed = False
    here = robot.get_pose()
    if here.z < z + LIFT_MM - 0.5:
        arm.move(here.x, here.y, z + LIFT_MM, here.r)
    arm.move(x, y, z + LIFT_MM, middle + turned)      # (turned as the cube turned on the table, if it did)
    # the last few mm slowly, as picks come down: a 25 mm cube in the Dobot's 27.5 mm fingers has 1.25 mm a side, and
    # a finger landing on its edge at speed knocked it along the fingers (the lab, 2026-10-19: held off-centre from
    # there on, every spot after it 1.8 mm off); slowly, it slides off the edge and round the cube
    if TAKE_BACK_SLOW_MM > 0.0:
        arm.move(x, y, z + TAKE_BACK_SLOW_MM, middle + turned)
        arm.move_slow(x, y, z, middle + turned, TAKE_BACK_SPEED_MM_S)
    else:
        arm.move(x, y, z, middle + turned)
    arm.check()
    robot.close_gripper()
    arm.acted = arm.closed = True
    arm.acted_at = (x, y)
    time.sleep(arm.settle_s * 0.5)
    arm.move(x, y, z + LIFT_MM, middle + turned)


def _turn_width(side: float, turn_deg: float) -> float:
    """How wide a square of this side is across the fingers, turned this much against them."""
    a = math.radians(min(45.0, abs(turn_deg)))
    return side * (math.cos(a) + math.sin(a))


def _usable(pairs: list) -> list:
    """The spots so far fit to aim and check by during the run: seen whole and standing as tall as the others (as the
    final fit keeps: one partly hidden is seen off-centre, one taller landed on something)."""
    if len(pairs) < 3:
        return list(pairs)
    side = float(np.median([p.sighting.footprint_mm[0] for p in pairs]))
    tall = float(np.median([p.sighting.height_mm for p in pairs]))
    return [p for p in pairs if _whole(p.sighting, side) and abs(p.sighting.height_mm - tall) <= HEIGHT_TOL_MM]


KNOCKED = float("-inf")      # _room's room for a cube seen to have bounced or been knocked after it was let go


def _room(progress: CubeProgress, gripper, sighting: Optional[CubeSighting], x: float, y: float,
          turn_left: float, others: list, r: Optional[float] = None,
          turned: float = 0.0, put_r: Optional[float] = None) -> tuple[tuple[float, float], Optional[float], str]:
    """Before taking the cube back at (x, y): (where to go instead, by how much -- the cube moved as it was let go;
    the room left between a finger and the cube, mm, or None if not known; why, in words, if there is too little).
    `turn_left`: how far the cube is still turned against the fingers after the wrist matched it (as far as it could).
    Where it moved is known from the spots so far (`others`) once their fit is good enough. With the wrist's turn
    (`r`, put down; `turned`, to take it back), from CHAIN_MIN_SPOTS on, the fit that tracks the cube's place in the
    fingers is tried too: kept if it predicts the spots better (its place changed), it sends the fingers' middle over
    the cube's, which centres it along them again."""
    if gripper is None or sighting is None or not getattr(gripper, "fingers", True):
        return (0.0, 0.0), None, ""
    out = progress.out
    side = _cube_side(progress)
    if not progress.cube_size_mm:
        # measured, not typed: a cube is as wide as it is tall, and its height (the depth of its top above the table)
        # isn't widened by the blurred edges its top's size is (a poor camera reads a 20 mm top as 23 mm)
        heights = [p.sighting.height_mm for p in out.pairs if p.sighting.height_mm > 0]
        if heights:
            side = min(side, float(np.median(heights)))
    shift, unsure = (0.0, 0.0), 0.0
    others = _usable(others)
    # (only a cube seen whole, standing as tall as the others: one partly hidden or crooked is seen off-centre)
    seen_well = (len(others) >= MIN_FIT_SPOTS
                 and _whole(sighting, float(np.median([p.sighting.footprint_mm[0] for p in others]))))
    seen_well = seen_well and abs(sighting.height_mm - float(np.median([p.sighting.height_mm for p in others])))         <= HEIGHT_TOL_MM
    if seen_well:
        plane = fit_table([p.sighting for p in others])
        if plane is not None:
            cam = np.array([p.sighting.cam_xyz for p in others], float)
            robot_xy = np.array([p.xy for p in others], float)
            with_scale = len(others) >= FIT_SCALE_SPOTS
            transform, loo, offset = solve_on_plane_offset(cam, robot_xy, plane, out.table_z, with_scale)
            typical = float(np.median(np.hypot(loo[:, 0], loo[:, 1])))
            landed_r = put_r if put_r is not None else r
            if landed_r is not None:
                # the gripper's middle off the tool point, as the final fit allows for it: without, its turn from spot
                # to spot read as the cube moving (the Dobot's middle is 7.2 mm off; in the twin, (3, -2) mm paused a
                # run "3.7 mm from where it was let go" with nothing knocked)
                turns = np.array([p.r for p in others], float)
                t2, loo2, d2 = solve_on_plane_offset(cam, robot_xy, plane, out.table_z, with_scale, turns)
                typical2 = float(np.median(np.hypot(loo2[:, 0], loo2[:, 1])))
                if typical2 < typical and float(np.hypot(*d2)) <= MAX_OFFSET_MM:
                    transform, offset, typical = t2, d2, typical2
            seen = (transform @ np.append(sighting.cam_xyz, 1.0))[:2]
            if landed_r is not None and np.any(offset):
                seen = seen - _rot(np.array([float(landed_r)]))[0] @ np.asarray(offset, float)   # (as turned() does)
            d = (float(seen[0] - x), float(seen[1] - y))
            moved, how = math.hypot(*d), "from where it was let go"
            chain = (_chain_now(others, plane, out.table_z, _jaw_of(gripper))
                     if r is not None and len(others) >= TRACK_AIM_SPOTS else None)
            if chain is not None and chain.changed and tracking_wins(chain.typical_mm, typical):
                cube_xy = chain.seen(sighting.cam_xyz)
                # (the fingers' middle over the cube's: across them, what counts below)
                aim = cube_xy - _rot(np.array([r + turned]))[0] @ np.asarray(chain.offset, float)
                d, typical = (float(aim[0] - x), float(aim[1] - y)), chain.typical_mm
                landed_r = r if put_r is None else put_r
                carried = getattr(progress, "carried_from", None)
                if carried is not None and carried.taken_xy is not None and any(carried is q for q in others):
                    moved = float(np.hypot(*(cube_xy - chain.landing((x, y), landed_r, carried))))
                    how = "from where it should have landed"
                else:
                    # (gripped by hand since, or taken where it wasn't seen: where it sat along the fingers isn't
                    # known -- only across them, where the fingers centre it)
                    across = _rot(np.array([landed_r]))[0] @ _unit(chain.jaw_axis_deg)
                    middle = (_rot(np.array([landed_r]))[0] @ ((chain.across_mm or 0.0) * _unit(chain.jaw_axis_deg)))
                    moved = abs(float((cube_xy - np.array([x, y]) - middle) @ across))
                    how = "across the fingers from where it was let go"
            if _jaw_of(gripper) is not None:
                # aimed across the fingers only: only there can a finger land on the cube (1.25 mm a side for a 25 mm
                # cube; along them the fingers are long). Along them it is taken where it was let go, as before: aimed
                # there too, an arm that lost its reach (on the Dobot, along the fingers is out from the base) was
                # put right by gripping the cube that much off -- and the look back at the first spot saw nothing
                closing = _unit(float(gripper.closing_direction(r + turned if r is not None else 0.0)))
                d = tuple(float(v) for v in float(np.dot(d, closing)) * closing)
            if typical <= FIT_TRUSTED_MM:
                if moved > SHIFT_MAX_MM and len(others) < KNOCK_MIN_SPOTS:
                    # (too few spots to say it moved that far: taken back where it was let go)
                    logger.info("The fit of %d spots says the cube is %.1f mm %s: too few spots to go by", len(others),
                                moved, how)
                    return (0.0, 0.0), None, ""
                if moved > SHIFT_MAX_MM:
                    return d, KNOCKED, (f"the camera sees the cube {moved:.1f} mm {how}: it bounced or was knocked. "
                                     "On the Manual tab, open the gripper over the cube where it stands, lower it "
                                     "round the cube (centred, about halfway down) and close it; then press "
                                     "'Manually gripped - continue': the spots so far are kept")
                if math.hypot(*d) >= 0.5:
                    if typical < math.hypot(*d):
                        # going where the camera sees it: then the fit's own error is room lost (where it was let
                        # go, it isn't -- and a fit without the gripper's offset, before it is known, reads large)
                        shift = d
                        unsure = typical
                    else:
                        # a move within the camera's own error: where it was let go, the move it may have made
                        # lost (a 25 mm cube in 27.5 mm fingers has 0.8 mm: the whole fit error paused every spot)
                        unsure = math.hypot(*d)
    elif EARLY_MIN_SPOTS <= len(others) < MIN_FIT_SPOTS and _jaw_of(gripper) is not None and _whole(
            sighting, float(np.median([p.sighting.footprint_mm[0] for p in others]))):
        # too few spots for the run's own fit: the calibration in use says where the cube is, against what it says at
        # the spots so far (its own error there taken off) -- the lab, 2026-10-26: let go at spot 2 the cube moved
        # 1-2 mm, the fingers came down where it was let go, and came up empty
        early = _early_shift(progress, sighting, others, x, y)
        if early is not None:
            d, spread = early
            closing = _unit(float(gripper.closing_direction(r + turned if r is not None else 0.0)))
            d = tuple(float(v) for v in float(np.dot(d, closing)) * closing)       # (across the fingers only)
            moved = math.hypot(*d)
            if spread <= EARLY_SPREAD_MAX_MM and EARLY_SHIFT_MIN_MM <= moved <= SHIFT_MAX_MM:
                shift, unsure = d, spread
                logger.info("By the calibration in use (against %d spot(s) so far, within %.1f mm), the cube is "
                            "%.1f mm across the fingers from where it was let go", len(others), spread, moved)
    room =(float(gripper.opening_mm) - _turn_width(side, abs(turn_left) + TURN_NOISE_DEG)) / 2.0 - unsure
    why = ""
    if room < 0.0:
        why = (f"there isn't room to take the cube back: it is turned {turn_left:+.0f} degrees more than the wrist "
               f"can match, and a {side:.0f} mm cube turned that much is wider than the fingers open"
               if abs(turn_left) > TURN_NOISE_DEG else
               f"there isn't room to take the cube back without a finger landing on it: the camera can place the "
               f"cube only to about {unsure:.1f} mm, and a {side:.0f} mm cube leaves {room + unsure:.1f} mm each "
               f"side (the fingers open {gripper.opening_mm:.1f} mm)"
               if room + unsure >= 0.0 else
               f"there isn't room to take the cube back without a finger landing on it ({side:.0f} mm cube, the "
               f"fingers open {gripper.opening_mm:.1f} mm)")
        if not progress.cube_size_mm:
            why += ("; the cube's size was measured by the camera: if you know it, type it in (size) and carry on "
                    "-- or open the fingers wider")
    return shift, room, why


def _in_use(progress: CubeProgress) -> Optional[np.ndarray]:
    """The calibration in use (camera to robot), or None if there is none."""
    transform = getattr(progress, "old_transform", None)
    if transform is None or np.allclose(np.asarray(transform, float), np.eye(4)):
        return None
    return np.asarray(transform, float)


def _early_shift(progress: CubeProgress, sighting: CubeSighting, others: list, x: float,
                 y: float) -> Optional[tuple[tuple[float, float], float]]:
    """Where the camera sees the cube against where it was let go at (x, y), by the calibration in use, less that
    calibration's own error (the middle of its errors at the spots so far): (the move, mm; how far those errors are
    from their middle, mm). None without a calibration in use or spots so far."""
    transform = _in_use(progress)
    if transform is None or len(others) < EARLY_MIN_SPOTS:
        return None

    def at(s: CubeSighting) -> np.ndarray:
        return (transform @ np.append(np.asarray(s.cam_xyz, float), 1.0))[:2]
    errors = np.array([at(p.sighting) - np.asarray(p.xy, float) for p in others])
    bias = np.median(errors, axis=0)
    spread = float(np.max(np.hypot(*(errors - bias).T))) if len(errors) > 1 else 0.0
    d = at(sighting) - np.array([x, y], float) - bias
    return (float(d[0]), float(d[1])), spread


def _retake(arm: "_Arm", robot, progress: CubeProgress, x: float, y: float, r: float, turned: float,
            sighting: CubeSighting, relook: Optional[Callable[[], Optional[CubeSighting]]],
            label: str, away: Optional[Pose] = None) -> Optional[tuple[float, float, float]]:
    """A take-back that came up without the cube: the gripper open, the arm out of the camera's way, a proper look,
    and -- the cube seen within RETAKE_MAX_MM of where it was -- one more grip where it is now. (x, y, turn) of the
    tool as it gripped, or None (it pauses for the user)."""
    transform = _in_use(progress)
    if relook is None or transform is None:
        return None
    robot.open_gripper()
    now = relook()
    if now is None:
        logger.info("%s: came up without the cube, and the camera doesn't find it now", label)
        return None
    d = (transform[:3, :3] @ (np.asarray(now.cam_xyz, float) - np.asarray(sighting.cam_xyz, float)))[:2]
    if math.hypot(*d) > RETAKE_MAX_MM:
        logger.info("%s: came up without the cube, now seen %.1f mm away: not taken again", label, math.hypot(*d))
        return None
    nx, ny = x + float(d[0]), y + float(d[1])
    logger.info("%s: came up without the cube; seen %.1f mm from before, it is taken again there", label,
                math.hypot(*d))
    try:
        arm.retried(f"Taking the cube again at ({nx:.0f}, {ny:.0f})",
                    lambda: _take_back(arm, robot, nx, ny, progress.out.hand.pick_z(), r, turned))
    except RobotStopped:
        raise
    except RuntimeError as exc:
        if not arm.acted:
            raise _Paused(f"the robot refused a move while taking the cube again at ({nx:.0f}, {ny:.0f}): {exc}"
                          + (f". {UNANSWERED_ADVICE}" if unanswered(exc) else ""))
        logger.info("Cube taken again at (%.0f, %.0f), but the arm didn't rise after: %s", nx, ny, exc)
    if arm.camera is not None and _still_there(arm, now, away):
        return None
    return nx, ny, r + turned


def _seen_at(arm: "_Arm", sighting: CubeSighting) -> Optional[bool]:
    """After taking the cube back: is its top still seen where it was (True), or the table there now (False)? None:
    can't tell -- something nearer the camera is in the way (the gripper hovering over it, seen from above: the empty
    fingers read as "gone" otherwise, and a missed pick scored as a perfect one), or no depth there."""
    try:
        time.sleep(arm.settle_s * 0.5)
        depth, _ = median_depth(arm.camera, 3)
    except Exception as exc:  # noqa: BLE001 - a missed look is no reason to stop
        logger.info("The look after taking the cube back failed: %s", exc)
        return None
    u, v = int(round(sighting.pixel[0])), int(round(sighting.pixel[1]))
    patch = depth[max(0, v - 3):v + 4, max(0, u - 3):u + 4]
    values = patch[patch > 0]
    if len(values) < 10:
        return None
    seen = float(np.median(values))
    if abs(seen - sighting.depth_mm) <= STILL_THERE_MM:
        return True
    return False if seen > sighting.depth_mm else None


def _still_there(arm: "_Arm", sighting: CubeSighting, away: Optional[Pose] = None) -> bool:
    """After taking the cube back (the arm just above): is its top still seen where it was? (The Dobot's gripper
    can't tell whether it holds anything.) Lifted, the cube is out of the way of that view, or nearer the camera.
    Where the camera can't tell from there (the gripper, empty or not, in its view of the spot), it looks again from
    `away`, the arm out of the way, as holding_after does: "can't tell" was taken as "taken", and a grip that closed
    on nothing carried on -- the cube left behind then found at the next spot and paired with it (25 mm off)."""
    seen = _seen_at(arm, sighting)
    if seen is None and away is not None:
        arm.away(away)
        seen = _seen_at(arm, sighting)
    return seen is True


def _take_back_checked(arm: "_Arm", robot, progress: CubeProgress, gripper, x: float, y: float, r: float,
                       turned: float, turn_left: float, sighting: Optional[CubeSighting], others: list,
                       label: str, put_r: Optional[float] = None,
                       relook: Optional[Callable[[], Optional[CubeSighting]]] = None,
                       away: Optional[Pose] = None) -> tuple[float, float, float]:
    """Take the cube back at (x, y), after making sure there is room for the fingers (otherwise the arm stops above
    it and the run pauses for the user), and check after that it came up (from `away` if the arm hides the spot) --
    if not, `relook` (the arm out of the way, the camera's look at the cube) finds it and it is taken once more (see
    _retake) before the run pauses. (x, y, turn) of the tool as it gripped."""
    hand = progress.out.hand
    shift, room, why = _room(progress, gripper, sighting, x, y, turn_left, others, r, turned, put_r)
    tx, ty = x + shift[0], y + shift[1]
    if shift != (0.0, 0.0):
        logger.info("%s: the cube is %.1f mm across the fingers from where it was let go; the fingers go there",
                    label, math.hypot(*shift))
    if room is not None and room < 0.0:
        try:
            arm.move(tx, ty, hand.pick_z() + LIFT_MM, r + turned)   # waits above it, the fingers open
        except RobotStopped:
            raise
        except RuntimeError:
            pass
        raise _Paused(why, knocked=room == KNOCKED)
    try:
        arm.retried(f"Taking the cube back at ({x:.0f}, {y:.0f})",
                    lambda: _take_back(arm, robot, tx, ty, hand.pick_z(), r, turned))
    except RobotStopped:
        raise
    except RuntimeError as exc:
        if not arm.acted:
            # (where the cube is, and -- a controller that stopped answering -- what to do about it)
            raise _Paused(f"the robot refused a move while taking the cube back at ({x:.0f}, {y:.0f}): {exc}"
                          + (f". {UNANSWERED_ADVICE}" if unanswered(exc) else ""))
        logger.info("Cube taken at (%.0f, %.0f), but the arm didn't rise after: %s", x, y, exc)
    if sighting is not None and arm.camera is not None and _still_there(arm, sighting, away):
        # (closed on nothing: the cube is on the table. Stopped now, it was taken as in the gripper -- "The cube is
        # still in the gripper", and the gripper put down over the cube standing there -- reviewer 2, 2026-10-27)
        arm.closed = False
        again = _retake(arm, robot, progress, tx, ty, r, turned, sighting, relook, label, away)
        if again is None:
            arm.closed = False
            raise _Paused(f"the gripper came up from ({x:.0f}, {y:.0f}) without the cube: it is still on the table"
                          + (" (looked at again and tried once more)" if relook is not None else ""))
        return again
    return tx, ty, r + turned


def holding_after(arm: "_Arm", robot, sighting: Optional[CubeSighting], away: Optional[Pose] = None) -> bool:
    """After a pick, the arm just above: does the gripper hold the cube? The simulator knows; a gripper that reads its
    gap says; the Dobot's can't tell, so then: is the cube still seen where it was (a miss) or not. Where the camera
    can't tell from there (the gripper in its view), it looks again from `away`, the arm out of the way."""
    if hasattr(robot, "held_object"):
        return robot.held_object is not None
    gap = _gripper_gap(robot)
    if gap is not None:
        return gap > 3.0
    if sighting is not None and getattr(arm, "camera", None) is not None:
        seen = _seen_at(arm, sighting)
        if seen is None and away is not None:
            arm.away(away)
            seen = _seen_at(arm, sighting)
        if seen is None:
            logger.info("Couldn't tell from the camera whether the cube was taken: taken as held")
        return seen is not True
    return True


def _cube_side(progress: CubeProgress) -> float:
    """The cube's side: typed in, or the camera's (the middle of what it measured)."""
    if progress.cube_size_mm:
        return float(progress.cube_size_mm)
    sides = [min(p.sighting.footprint_mm) for p in progress.out.pairs if p.sighting.footprint_mm]
    return float(np.median(sides)) if sides else 20.0


def _seen_whole(sighting: Optional[CubeSighting], side: float) -> bool:
    """The cube's top measured about its size both ways: seen whole, not cut short by the arm or the picture's edge,
    nor merged with something next to it."""
    return (sighting is not None and sighting.tilt_deg <= TILT_MAX_DEG
            and all(abs(v - side) <= SEEN_WHOLE_MM for v in sighting.footprint_mm))


def _reference(progress: CubeProgress) -> Optional[CubePair]:
    """The spot the cube goes back to, to check the arm hasn't lost its place: the first one seen whole."""
    side = _cube_side(progress)
    return next((p for p in progress.out.pairs if not p.check and _seen_whole(p.sighting, side)), None)


def _moved_on_table(a: CubeSighting, b: CubeSighting, sightings: list) -> float:
    """How far apart two sightings of the cube are, along the table (the camera's own coordinates: no calibration
    needed)."""
    return _apart_on_table(a, b, sightings)


def _apart_on_table(a: CubeSighting, b: CubeSighting, sightings: list) -> float:
    d = np.asarray(b.cam_xyz, float) - np.asarray(a.cam_xyz, float)
    plane = fit_table(sightings) if len(sightings) >= 2 else None
    if plane is not None:
        n = np.asarray(plane.normal, float)
        d = d - (d @ n) * n
    return float(np.linalg.norm(d))


def _across_moved(progress: CubeProgress, gripper, first: CubePair, again: CubeSighting) -> Optional[float]:
    """Put back at the first spot after you took over: how far the cube is from where it was the first time across
    the fingers only (robot mm), by the fit of the spots so far -- or None if that can't be told. (Gripped again by
    hand, it sits elsewhere along the fingers: a new place there says nothing about the arm. Across them the squeeze
    centres it as before.)"""
    jaw, pairs = _jaw_of(gripper), _usable(progress.out.pairs)
    if jaw is None or len(pairs) < 3:            # (only the camera's turn against the robot is needed: 3 spots do)
        return None
    plane = fit_table([p.sighting for p in pairs])
    if plane is None:
        return None
    cam = np.array([p.sighting.cam_xyz for p in pairs], float)
    robot_xy = np.array([p.xy for p in pairs], float)
    transform, loo = solve_on_plane(cam, robot_xy, plane, progress.out.table_z, False)
    typical = float(np.median(np.hypot(loo[:, 0], loo[:, 1])))
    # with the gripper's middle off the tool point, as _room allows for it: without, the Dobot's (about -7, 1 mm) left
    # this fit 3.7-4.6 mm typical -- never trusted, so every take-over was judged on the whole shift and paused again
    t2, loo2, d2 = solve_on_plane_offset(cam, robot_xy, plane, progress.out.table_z, False,
                                         np.array([p.r for p in pairs], float))
    typical2 = float(np.median(np.hypot(loo2[:, 0], loo2[:, 1])))
    if typical2 < typical and float(np.hypot(*d2)) <= MAX_OFFSET_MM:
        transform, typical = t2, typical2
    if typical > FIT_TRUSTED_MM:
        return None
    moved = (np.asarray(transform, float)[:3, :3] @ (np.asarray(again.cam_xyz, float)
                                                     - np.asarray(first.sighting.cam_xyz, float)))[:2]
    return abs(float(moved @ _unit(jaw + first.r)))


def summary(out: "CubeOutcome") -> str:
    """The run in one line (for the log): spots, the looks back at the first spot, the fit, the grips tracked."""
    checks = [e for e in out.spot_log if e.get("spot") == "first again" and e.get("found")]
    found = sum(1 for e in out.spot_log if e.get("spot") != "first again" and e.get("found"))
    moved = ", ".join(f"{e['moved_mm']:.1f}" for e in checks if "moved_mm" in e)
    landing = ", ".join(f"{e['off_landing_mm']:.1f}" for e in checks if "off_landing_mm" in e)
    parts = [out.mode, f"{out.spots_tried} spots tried, {found} found, {len(out.used)} used",
             "looks back at the first spot: " + (f"{moved} mm from the first time" if moved else "none")
             + (f" ({landing} mm from where they should have landed)" if landing else "")]
    fit = out.fit
    if fit is not None:
        parts.append(f"fit: {fit.name}, typically {fit.typical_mm:.2f} mm")
        if fit.tracked and fit.along is not None:
            parts.append(f"the place along the fingers changed by up to {float(np.ptp(fit.along)):.1f} mm; "
                         f"{len(fit.broken or [])} grip(s) taken as pushed (measured afresh there)")
    parts.append("passed" if out.passed else f"not passed: {out.reason}")
    return "Cube calibration summary: " + "; ".join(parts)


def _off_landing(progress: CubeProgress, gripper, put: tuple, again: CubeSighting,
                 carried: Optional[CubePair]) -> Optional[float]:
    """Put back at the first spot (let go at `put`: x, y, turn): how far the cube is from where it should have landed
    there, held as the camera saw it taken (see solve_chain) -- or None if that can't be told (the tracking of the
    spots so far not trusted)."""
    out = progress.out
    pairs = _usable(out.pairs)
    if carried is None or carried.taken_xy is None or not any(carried is p for p in pairs):
        return None
    plane = fit_table([p.sighting for p in pairs]) if len(pairs) >= CHAIN_MIN_SPOTS else None
    chain = _chain_now(pairs, plane, out.table_z, _jaw_of(gripper))
    if chain is None or chain.typical_mm > FIT_TRUSTED_MM or not chain.changed:
        return None
    return float(np.hypot(*(chain.seen(again.cam_xyz) - chain.landing(put[:2], put[2], carried))))


def _check_first(arm: "_Arm", robot, progress: CubeProgress, gripper, raw, say, save, what: str) -> None:
    """The cube back at the first spot seen whole (see _reference) and looked at again. Seen where it was the first
    time: the arm has kept its place since (and the cube its place in the fingers), and the look counts as one more
    spot. Not: the spots since the last good check are dropped, to be done again, and the run pauses (out.slip_mm
    says by how much). Not seen whole this time: no verdict either way (said in out.notes)."""
    out, hand, away = progress.out, progress.out.hand, progress.away
    first = _reference(progress)
    if first is None:
        logger.info("No spot seen whole yet to check against (%s): skipped", what)
        return
    say(f"Putting the cube back at the first spot ({what})...")
    carried = getattr(progress, "carried_from", None)
    progress.pending = {"check": True}
    arm.down_and(first.xy[0], first.xy[1], hand.release_z(), first.r, LIFT_MM, robot.open_gripper)
    out.holding, out.cube_at = False, first.xy
    put = robot.get_pose()                       # (where it says it let go, as at every spot)
    which = max(range(len(away)), key=lambda i: math.hypot(away[i].x - first.xy[0], away[i].y - first.xy[1]))
    arm.away(away[which])
    look = arm.look()
    again = find_new_object(look.depth, progress.backgrounds[which].depth, out.k, expect_px=first.sighting.pixel,
                            size_mm=progress.cube_size_mm)
    out.pictures = out.pictures[:3] + [((first.xy[0], first.xy[1]), look)]     # (the latest look back only)
    entry = {"spot": "first again", "xy": [round(first.xy[0], 1), round(first.xy[1], 1)], "found": False,
             "why": what}
    moved, turned, expected = None, 0.0, None
    if again is not None:
        moved = _moved_on_table(first.sighting, again, [p.sighting for p in out.pairs])
        expected = _off_landing(progress, gripper, (put.x, put.y, put.r), again, carried)
        if expected is not None:
            entry["off_landing_mm"] = round(expected, 2)
        entry.update(found=True, height_mm=round(again.height_mm, 2), size_mm=list(again.footprint_mm),
                     lean_deg=round(again.tilt_deg, 1), pixel=[round(v, 1) for v in again.pixel],
                     moved_mm=round(moved, 2))
        turned = _wrap90(again.turn_deg - first.sighting.turn_deg)
        turned = 0.0 if abs(turned) < TURN_FIX_MIN_DEG else max(-TURN_FIX_MAX_DEG, min(TURN_FIX_MAX_DEG, turned))
        if turned and gripper is not None and not gripper.wrist_fits(first.r + turned, first.xy[0], first.xy[1]):
            turned = 0.0
    out.spot_log.append(entry)
    logger.info("Cube spot %s", entry)
    taken = _take_back_checked(arm, robot, progress, gripper, first.xy[0], first.xy[1], first.r, turned, 0.0,
                               again, list(out.pairs), "the first spot", away=away[which])
    hand.taken()
    out.holding, out.cube_at = True, None
    progress.pending, progress.last = None, (first.xy[0], first.xy[1], first.r)
    progress.carried_from = None                 # (unless it counts as a spot, below)
    if again is None:
        save()
        raise _Paused("put back at the first spot, the cube wasn't found there by the camera")
    if not _seen_whole(again, _cube_side(progress)):
        entry["judged"] = False
        out.notes.append(f"the look back at the first spot ({what}) saw the cube only partly "
                         f"({again.footprint_mm[0]:.0f} x {again.footprint_mm[1]:.0f} mm): not judged")
        progress.since_check = 0
        save()
        return
    # (the tracking says only which is likelier, never turns a failed look into a passed one: on the Dobot, along the
    # fingers is out from the base, so an arm that lost its reach reads just as a grip moved along them)
    likely = ""
    if expected is not None and moved > SLIP_MM:
        likely = (f" (where it should have landed by the tracking, held as the camera saw it taken: {expected:.1f} mm "
                  "-- so its place in the fingers more likely changed than the arm's)" if expected <= SLIP_MM else
                  f" (where it should have landed by the tracking: {expected:.1f} mm off as well)")
    out.slip_mm = moved
    # after you took over (the arm had stopped answering, or a move was refused) a smaller shift is enough: the arm
    # may have lost its place as it stopped -- the lab, 2026-10-12: 2.7 mm off after taking over, and the run carried
    # on mixing spots from before and after, to fail at 2.5 mm. Gripped again by hand, though, the cube sits elsewhere
    # along the fingers: across them (where the squeeze centres it) the smaller shift, all of it the usual one
    judged, limit = moved, SLIP_FAIL_MM
    if what == "after taking over":
        across = _across_moved(progress, gripper, first, again)
        if across is None:
            limit = SLIP_MM
        elif across > SLIP_MM:
            judged, limit = across, SLIP_MM
        elif moved > SLIP_MM:
            out.notes.append(f"put back at the first spot after you took over, the cube was {moved:.1f} mm from where "
                             f"it was the first time, {across:.1f} mm of it across the fingers (your grip may hold it "
                             "elsewhere along them)")
    if judged > limit:
        dropped = len(out.pairs) - progress.good_pairs
        out.pairs = out.pairs[:progress.good_pairs]
        progress.sides = progress.sides[:progress.good_sides]   # (the turns seen at the dropped spots: done again)
        if dropped:
            out.skipped.append(f"{dropped} spot(s) measured before a failed check at the first spot: done again")
        progress.next_index, progress.since_check = progress.good_index, 0
        save()
        raise _Paused(f"put back at the first spot, the cube was seen {moved:.1f} mm from where it was the first "
                      + (f"time ({judged:.1f} mm across the fingers){likely}" if judged != moved else f"time{likely}")
                      + ". The arm lost its place (its motors skip a step if it knocks into something), the cube "
                      "moved in the fingers, or the camera moved. The spots since the last good check will be done "
                      "again", advice=HOME_ADVICE)
    if moved > SLIP_MM and what != "after taking over":
        out.notes.append(f"put back at the first spot ({what}), the cube was seen {moved:.1f} mm from where it "
                         f"was the first time{likely or ' (it moved a little in the fingers)'}")
        out.slipped = True
    out.slip_worst_mm = max(out.slip_worst_mm or 0.0, moved)
    # one more spot for the fit -- only if it agrees with the first: one seen over SLIP_MM away (a slip, or a grip by
    # hand that holds the cube elsewhere along the fingers) was added anyway, a pair off by that much in the fit
    if again.tilt_deg <= TILT_MAX_DEG and moved <= SLIP_MM:
        raw_again = None
        if raw is not None and look.raw is not None and progress.backgrounds[which].raw is not None:
            raw_again = find_new_object(look.raw, progress.backgrounds[which].raw, raw[0],
                                        size_mm=progress.cube_size_mm)
        check = CubePair((put.x, put.y), put.r, again, raw_again, 1, _gripper_gap(robot), check=True, prev=carried,
                         taken_xy=taken[:2], taken_r=taken[2])
        out.pairs.append(check)
        progress.carried_from = check
    progress.good_pairs, progress.good_index, progress.since_check = len(out.pairs), progress.next_index, 0
    progress.good_sides = len(progress.sides)
    save()


def _camera_moved(arm: "_Arm", pose: Pose, background: Look) -> Optional[str]:
    """Back to a run that stopped: is the empty table seen as it was (from the same waiting place)? If not, why."""
    arm.away(pose)
    look = arm.look()
    a, b = np.asarray(look.depth, float), np.asarray(background.depth, float)
    both = (a > 0) & (b > 0)
    if both.sum() < 1000:
        return "the camera sees too little of the table now"
    diff = np.abs(a[both] - b[both])
    typical, changed = float(np.median(diff)), float((diff > 10.0).mean())
    logger.info("The empty table against before: typically %.2f mm, %.1f%% changed", typical, 100 * changed)
    if typical > CAMERA_MOVED_MM or changed > 0.05:
        return (f"the camera sees the table differently than when the run started ({100 * changed:.0f}% of it "
                f"changed, typically by {typical:.1f} mm): it moved, or something on the table did")
    return None


def _centre_in_hand(arm: "_Arm", robot, start: Pose, r0: float, gaps: list, regrip: bool) -> None:
    """The cube held at `start`: with `regrip`, the wrist to its middle (r0) first, opening and gripping it again
    there; then a squeeze in place, which centres the cube across the fingers."""
    here = robot.get_pose()
    if regrip and abs((here.r - r0 + 180.0) % 360.0 - 180.0) > 1.0:
        robot.open_gripper()
        arm.move(start.x, start.y, start.z + LIFT_MM, here.r)
        arm.move(start.x, start.y, start.z + LIFT_MM, r0)
        arm.move(start.x, start.y, start.z, r0)
        robot.close_gripper()
    gap = _gripper_gap(robot)
    if gap is not None:
        gaps.append(gap)
    _recentre(arm, robot, start.x, start.y, start.z, here.r if not regrip else r0)
    gap = _gripper_gap(robot)
    if gap is not None:
        gaps.append(gap)


def _run_cube_calibration(robot, camera, bounds: dict, reach_mm: float, gripper=None,
                          old_transform: Optional[np.ndarray] = None, mode: str = "precise",
                          spots: Optional[int] = None, table_z: Optional[float] = None,
                          table_touches: Optional[list] = None,
                          cube_size_mm: Optional[float] = None, settle_s: float = SETTLE_S, frames: int = FRAMES,
                          on_progress: Optional[Callable[[str], None]] = None,
                          cancel: Optional[Callable[[], bool]] = None, resume: Optional[CubeProgress] = None,
                          on_save: Optional[Callable[[CubeProgress], None]] = None,
                          pause: Optional[Callable[[], bool]] = None, use_last: bool = True) -> CubeOutcome:
    """Phase 1. The gripper must be closed on a cube that rests on the table, the fingertips just above the table
    (`table_z`: where they touched it; None: taken as GRIP_ABOVE_TABLE_MM below them). Moves the arm: call from a
    worker thread. Never raises for a spot that can't be done (it is skipped); an E-STOP goes through.

    After every spot the progress goes to `on_save`. When `pause()` is true, or the robot needs help (no room for
    the fingers, the cube not picked up, a move refused, the arm seen to lose its place), the run stops where it is
    (out.paused, out.reason) for the user to take over; `resume` (that progress, the cube gripped again by hand,
    anywhere) carries on. `use_last`: keep the measurement of the spot under way when it stopped."""
    say = on_progress or (lambda message: None)
    raw = raw_view(camera)
    arm = _Arm(robot, camera, settle_s, frames, say, cancel, raw=raw is not None, pause=pause)
    start = robot.get_pose()
    if resume is None:
        settings = MODES[mode]
        count = spots or settings.spots
        k = camera.get_intrinsics()
        out = CubeOutcome(mode=mode, k=k, turns=settings.angles)
        z0 = start.z
        heights = TableHeights(table_touches) if table_touches else None
        if heights is not None and heights.too_steep:
            out.reason = (f"the table touches agree, but on a plane too far out of level ({heights.describe()}): "
                          "press Home and touch the table again" if heights.agreed else
                          f"the table touches disagree ({heights.describe()}): one wasn't on the table, or pressed "
                          "into it. Press 'Forget touches' and touch it again.")
            return out
        if heights is not None and table_z is None:
            table_z = heights.at(start.x, start.y)
        out.table_from = ("assumed" if table_z is None else "touched" if heights is None or len(heights.touches) == 1
                          else heights.describe())
        out.table_z = float(table_z) if table_z is not None else z0 - GRIP_ABOVE_TABLE_MM
        if heights is not None and len(heights.touches) > 1:
            out.table_dz = _TableDz(heights, out.table_z)
        if z0 - out.table_z < -0.5:
            out.reason = (f"the fingertips (z = {z0:.1f}) are below the table height set (z = {out.table_z:.1f}). "
                          "Press 'Fingertips on the table' again.")
            return out
        if table_z is not None and z0 - out.table_z > (cube_size_mm or 20.0) + 5.0:
            # (as a carried-on run checks: started with the cube lifted, every spot dropped it from that height)
            out.reason = (f"the fingertips are {z0 - out.table_z:.0f} mm above the table: grip the cube where it rests "
                          "on the table, then start again.")
            return out
        finger = float(gripper.finger_depth_mm) if gripper is not None and gripper.fingers else None
        out.hand = _Hand(out.table_z, z0 - out.table_z, z0 - out.table_z, cube_size_mm or 20.0, finger)
        out.r = middle_turn(start.x, start.y)          # the wrist's middle where the cube was gripped
        progress = CubeProgress(out=out, route=[], backgrounds=[], away=away_poses_for(bounds, reach_mm,
                                                                                       z0 + AWAY_UP_MM),
                                mode=mode, cube_size_mm=cube_size_mm, old_transform=old_transform,
                                base_offset=tuple(float(v) for v in getattr(robot, "tool_centre_mm", (0.0, 0.0))),
                                count=count)
    else:
        progress, out = resume, resume.out
        settings, k = MODES[out.mode], out.k
        # (stopped before its spots were planned -- the arm not homed, a first move refused, Pause while centring --
        # its empty table and spots are taken afresh below: carrying on read the empty table's first picture, which
        # wasn't there, and every 'continue' failed the same way until 'Start over' -- reviewer 2, 2026-10-27)
        count = spots or getattr(progress, "count", 0) or settings.spots
        heights = getattr(out.table_dz, "heights", None)
        cube_size_mm, old_transform = progress.cube_size_mm, progress.old_transform
        out.reason, out.paused, out.cancelled, out.keep_progress = "", False, False, False
        here_table = out.table_z + (out.table_dz(start.x, start.y) if out.table_dz is not None else 0.0)
        above = start.z - here_table
        if not -0.5 <= above <= out.hand.cube_h + 5.0:
            out.paused = out.keep_progress = True
            out.reason = (f"the fingertips are {above:.0f} mm above the table: grip the cube where it rests on the "
                          "table (as at the start), then press 'Manually gripped - continue' again")
            return out
        out.hand.first_grip = out.hand.grip = above
        pending = progress.pending or {}
        if "index" in pending:
            index = pending["index"]
            if pending.get("measured"):
                if pending.get("pair") and not use_last and out.pairs:
                    out.pairs.pop()
                    out.skipped.append(f"spot {index + 1}: not used (taken over by hand; your choice)")
                progress.next_index, progress.since_check = index + 1, progress.since_check + 1
            else:
                progress.next_index = index
                out.spots_tried = max(0, out.spots_tried - 1)
        progress.pending = None
    arm.dz = out.table_dz
    hand, away = out.hand, progress.away

    def save() -> None:
        if on_save is not None:
            try:
                on_save(progress)
            except Exception as exc:  # noqa: BLE001 - not being able to save is no reason to stop
                logger.warning("The cube calibration's progress couldn't be saved: %s", exc)

    try:
        if resume is None or not progress.route:
            # 1. the wrist to its middle, lifted clear; then a squeeze in place to centre the cube across the fingers
            # (gripped again by hand, carrying on: only the squeeze)
            say("Centring the cube in the gripper...")
            _centre_in_hand(arm, robot, start, out.r, progress.gaps, regrip=resume is None)
            out.holding = True
            progress.carried_from = None
            # 2. the table as it is, with the cube held out of the way (one picture per waiting place)
            progress.backgrounds.clear()             # (a stop between two pictures: both taken again)
            for index, pose in enumerate(away):
                say(f"Looking at the empty table ({index + 1} of {len(away)})...")
                arm.away(pose)        # (as for every look after: the gripper the same)
                progress.backgrounds.append(arm.look())
            backgrounds = progress.backgrounds
            z0 = start.z
            seen = in_view_check(old_transform, k, z0)
            if seen is not None:                     # and where the camera sees table (not past the table's edge)
                to_camera = np.linalg.inv(np.asarray(old_transform, float))
                in_picture = seen

                def seen(x: float, y: float) -> bool:
                    if not in_picture(x, y):
                        return False
                    q = to_camera @ np.array([x, y, z0, 1.0])
                    u, v = int(k.fx * q[0] / q[2] + k.cx), int(k.fy * q[1] / q[2] + k.cy)
                    return all((b.depth[max(0, v - 15):v + 16, max(0, u - 15):u + 16] > 0).mean() > 0.8
                               for b in backgrounds)
            fits = None if gripper is None else (lambda turn, x, y: gripper.wrist_fits(
                middle_turn(x, y) + turn, x, y, margin=WRIST_MARGIN_DEG))
            # only where the table was touched (its height measured there, not guessed), when it was at 2 places or more
            allowed = heights.covers if heights is not None and len(heights.touches) > 1 else None
            # the camera's view and the touched area; failing that, the view alone (the touches don't reach into it);
            # failing that, near where the cube was (the calibration in use can't be right), touched area kept if it
            # leaves any
            tried, warned = set(), False
            for view, area in ((seen, allowed), (seen, None), (None, allowed), (None, None)):
                if progress.route or (view is None, area is None) in tried:
                    continue                       # (done, or the same as a try already made)
                tried.add((view is None, area is None))
                if view is None and seen is not None and not warned:
                    # the calibration in use puts no spot in the camera's view: it can't be right (the lab: none at
                    # all, after it was cleared). Spots near where the cube was gripped instead, as with none.
                    logger.warning("The calibration in use puts no spot in the camera's view: spots near the start "
                                   "instead")
                    say("The calibration in use doesn't match the camera's view: using spots near the cube instead...")
                    warned = True
                # (in the camera's view: only where it sees the table not too slanted, by the calibration in use --
                # the Dobot's, for now: the xArm's spots kept as they were)
                slanted = view_tilt_check(old_transform, z0) if view is not None and _jaw_of(gripper) is not None else None
                progress.route = plan_spots(bounds, reach_mm, (start.x, start.y), count, view, settings.angles, fits,
                                            area, tilt=slanted)
            save()
        else:
            # 1. as the user gripped it (the wrist turned to match the cube, perhaps): only the squeeze in place
            say("Carrying on: centring the cube in the gripper...")
            _centre_in_hand(arm, robot, start, out.r, progress.gaps, regrip=False)
            out.holding = True
            progress.carried_from = None             # (gripped again by hand: its place in the fingers is new)
            # 2. is the camera where it was, and the arm? (otherwise the spots so far don't go with the ones to come)
            say("Checking the camera hasn't moved...")
            moved = _camera_moved(arm, away[0], progress.backgrounds[0])
            if moved is not None:
                out.reason = (f"{moved}. The spots measured so far can't be used with new ones: they are cleared -- "
                              "press 'Calibrate with a cube' to start afresh.")   # (no progress kept: no Start over)
                _put_down(arm, robot, out, (start.x, start.y, robot.get_pose().r))
                return out
            if _reference(progress) is not None:
                _check_first(arm, robot, progress, gripper, raw, say, save, "after taking over")
        route = progress.route
        while progress.next_index < len(route):
            index = progress.next_index
            x, y, turn = route[index]
            arm.check()
            r = middle_turn(x, y) + turn                 # the wrist in its middle (turn: 0 in every mode)
            say(f"Spot {index + 1} of {len(route)}: putting the cube down at ({x:.0f}, {y:.0f})...")
            progress.pending = {"index": index, "measured": False}
            out.spots_tried += 1
            try:
                arm.down_and(x, y, hand.release_z(), r, LIFT_MM, robot.open_gripper)
            except RobotStopped:
                raise
            except RuntimeError as exc:
                if unanswered(exc) or needs_a_person(exc, robot):   # every next spot the same: paused, kept to do
                    raise
                if not arm.acted:                 # out of reach, or in the way: still holding it, try the next
                    logger.info("Cube spot (%.0f, %.0f), turned %+.0f, skipped: %s", x, y, turn, exc)
                    out.skipped.append(f"spot {index + 1}: couldn't go there ({exc})")
                    progress.pending, progress.next_index = None, index + 1
                    save()
                    continue
                logger.info("Cube let go at (%.0f, %.0f), but the arm didn't rise after: %s", x, y, exc)
            out.holding, out.cube_at = False, (x, y)
            put = robot.get_pose()
            which = max(range(len(away)), key=lambda i: math.hypot(away[i].x - x, away[i].y - y))
            arm.away(away[which])
            look = arm.look()
            # the cube's size: typed in, or once two spots are found, theirs (the waiting gripper isn't that size)
            size_now = cube_size_mm or (float(np.median([p.sighting.height_mm for p in out.pairs]))
                                        if len(out.pairs) >= 2 else None)
            top = (put.x, put.y, out.table_z + (size_now or 20.0))
            sighting = find_new_object(look.depth, progress.backgrounds[which].depth, k,
                                       expect_px=project(old_transform, k, top), size_mm=size_now)
            raw_sighting = None
            if raw is not None and look.raw is not None and progress.backgrounds[which].raw is not None:
                raw_sighting = find_new_object(look.raw, progress.backgrounds[which].raw, raw[0],
                                               size_mm=cube_size_mm)
            entry = {"spot": index + 1, "xy": [round(put.x, 1), round(put.y, 1)], "turn": turn, "found": False}
            if sighting is not None:
                entry.update(found=True, height_mm=round(sighting.height_mm, 2), size_mm=list(sighting.footprint_mm),
                             lean_deg=round(sighting.tilt_deg, 1), top_fit_mm=round(sighting.tilt_fit_mm, 2),
                             top_points=sighting.top_points, pixel=[round(v, 1) for v in sighting.pixel],
                             turn_seen_deg=round(_wrap90(sighting.turn_deg - r), 1))   # (its sides against the wrist)
                if index == 0 and not out.pairs:
                    # the camera's own steadiness, before the run builds on it: the same cube, looked at again
                    # (the tracking of the cube in the fingers counts each look twice; light that flickers, sun on
                    # the table or a camera not yet warm spread the looks)
                    second = arm.look()
                    again = find_new_object(second.depth, progress.backgrounds[which].depth, k,
                                            expect_px=sighting.pixel, size_mm=size_now)
                    if again is not None:
                        repeat = _apart_on_table(sighting, again, [sighting, again])
                        entry["repeat_mm"] = round(repeat, 2)
                        if repeat > REPEAT_WARN_MM:
                            out.notes.append(f"looked at twice at spot 1, the camera saw the cube {repeat:.1f} mm "
                                             "apart (it should be under 0.5): is the light steady, no sunlight or "
                                             "lamp on the table, and the camera warmed up?")
                            say(f"Spot 1: the camera's two looks at the cube differ by {repeat:.1f} mm: the light "
                                "or a cold camera? Carrying on.")
            out.spot_log.append(entry)
            logger.info("Cube spot %s", entry)
            if len(out.pictures) < 3:
                if not out.pictures:
                    out.pictures.append(((0.0, 0.0), progress.backgrounds[which]))      # the empty table first
                out.pictures.append(((put.x, put.y), look))
            pair = None
            if sighting is None:
                say(f"Spot {index + 1}: the camera didn't find the cube; skipped.")
                out.skipped.append(f"spot {index + 1}: not found by the camera")
            elif sighting.tilt_deg > TILT_MAX_DEG:
                say(f"Spot {index + 1}: the cube landed crooked ({sighting.tilt_deg:.0f} degrees); skipped.")
                out.skipped.append(f"spot {index + 1}: landed crooked ({sighting.tilt_deg:.0f} degrees)")
            else:
                pair = CubePair((put.x, put.y), put.r, sighting, raw_sighting, 1, None,
                                prev=getattr(progress, "carried_from", None))
                out.pairs.append(pair)
            progress.pending = {"index": index, "measured": True, "pair": pair is not None}
            # did it turn as it was let go? Then the fingers come down turned the same (with 1.25 mm to spare each
            # side, a finger lands on a 25 mm cube turned 6 degrees)
            turned, turn_left = 0.0, 0.0
            if pair is not None and _seen_whole(sighting, _cube_side(progress)):
                progress.sides.append(_wrap90(sighting.turn_deg - r))
                estimate = turn_estimate(progress.sides)
                fits = (fits_turn(_cube_side(progress), float(gripper.opening_mm))
                        if gripper is not None and getattr(gripper, "fingers", True) else None)
                turned = cube_turned(progress.sides, fits)
                if turned and gripper is not None and not gripper.wrist_fits(r + turned, x, y):
                    turned = 0.0
                turn_left = (estimate or 0.0) - turned
                if not turned and abs(turn_left) < turn_threshold(progress.sides, fits):
                    turn_left = 0.0          # (the camera's noise, as cube_turned judged: no turn left to make room for)
                if turned:
                    progress.sides[-1] = _wrap90(progress.sides[-1] - turned)     # (taken back square, as usual)
                    out.turn_fixes.append((index + 1, round(turned, 1)))
                    entry["turned_deg"] = round(turned, 1)
                    say(f"Spot {index + 1}: the cube turned {turned:+.0f} degrees as it was let go; the wrist turns "
                        "to match to take it.")
            save()
            # back for it, by the robot's own coordinates (or where the camera sees it moved to), centred again
            # (where it really let go: a spot past the workspace's edge is clamped to it)
            def relook(which=which, size_now=size_now, sighting=sighting) -> Optional[CubeSighting]:
                """The arm out of the way, the camera's look at the cube (a take-back that came up empty)."""
                arm.away(away[which])
                again = arm.look()
                return find_new_object(again.depth, progress.backgrounds[which].depth, k,
                                       expect_px=sighting.pixel if sighting is not None else None, size_mm=size_now)
            try:
                taken = _take_back_checked(arm, robot, progress, gripper, put.x, put.y, r, turned, turn_left,
                                           sighting, [p for p in out.pairs if p is not pair], f"Spot {index + 1}",
                                           put.r, relook=relook, away=away[which])
            except _Paused as paused:
                if paused.knocked and pair is not None and out.pairs and out.pairs[-1] is pair:
                    # (seen more than SHIFT_MAX_MM from where it was let go: this spot's pair is off by that much.
                    # It was kept, and carrying on's first choice, "use spot N", put it in the fit -- reviewer 2,
                    # 2026-10-27)
                    out.pairs.pop()
                    out.skipped.append(f"spot {index + 1}: the cube bounced or was knocked after it was let go")
                    progress.pending = {**progress.pending, "pair": False}
                raise
            hand.taken()
            if pair is not None:
                pair.taken_xy, pair.taken_r = taken[:2], taken[2]
            progress.carried_from = pair
            out.holding, out.cube_at = True, None
            if pair is not None:
                pair.gap_mm = _gripper_gap(robot)
            progress.pending, progress.last = None, (put.x, put.y, r)
            progress.next_index, progress.since_check = index + 1, progress.since_check + 1
            save()
            # every few spots, back to the first: has the arm kept its place? (found out now, not at the end)
            if progress.since_check >= CHECK_EVERY and progress.next_index < len(route) and _reference(progress):
                _check_first(arm, robot, progress, gripper, raw, say, save, f"a check after spot {index + 1}")
        found = [p for p in out.pairs if not p.check]
        needed = max(FEWEST_SPOTS, min(MIN_SPOTS, len(route) - 1))
        if len(found) < needed:
            out.reason = (f"the camera found the cube at only {len(found)} of {out.spots_tried} spots (at least "
                          f"{needed} are needed). Is the table clear but for the cube, and in the camera's view?")
            _put_down(arm, robot, out, progress.last or (start.x, start.y, out.r))
            return out
        # 3. once more at the first spot: has it slipped? (unless that was just done)
        if (progress.since_check > 0 or out.slip_mm is None) and _reference(progress) is not None:
            _check_first(arm, robot, progress, gripper, raw, say, save, "the slip check")
        if out.slip_mm is None:                    # (said, not passed over: nothing checked the cube stayed put)
            out.notes.append("no look back at the first spot could be judged (the cube was never seen at the size "
                             "typed), so nothing checked it stayed put in the fingers: leave Cube size blank and "
                             "calibrate again, or check this one with Pick test")
        last = progress.last
        gaps = progress.gaps
        # a cube that landed on something, or on an edge, stands taller or shorter than the others
        usual_h = float(np.median([p.sighting.height_mm for p in out.pairs]))
        odd = [p for p in out.pairs if abs(p.sighting.height_mm - usual_h) > HEIGHT_TOL_MM]
        for p in odd:
            out.skipped.append(f"({p.xy[0]:.0f}, {p.xy[1]:.0f}): stood {p.sighting.height_mm:.0f} mm tall, the "
                               f"others {usual_h:.0f}: landed crooked or on something")
        # (by identity: `in` compares the pairs' sightings, arrays and all -- it raised once one was left out)
        out.pairs = [p for p in out.pairs if not any(p is q for q in odd)]
        # a spot where the cube was partly hidden (by the arm, the picture's edge): its top's outline cut short
        usual = float(np.median([p.sighting.footprint_mm[0] for p in out.pairs]))
        hidden = [p for p in out.pairs if not _whole(p.sighting, usual)]
        for p in hidden:
            out.skipped.append(f"({p.xy[0]:.0f}, {p.xy[1]:.0f}): partly hidden from the camera "
                               f"({p.sighting.footprint_mm[0]:.0f} x {p.sighting.footprint_mm[1]:.0f} mm seen)")
        out.pairs = [p for p in out.pairs if not any(p is q for q in hidden)]
        # (xArm) a spot gripped off-centre: the fingers closed wider or narrower than usual
        widths = [p.gap_mm for p in out.pairs if p.gap_mm is not None]
        if len(widths) >= 3:
            usual = float(np.median(widths))
            off = [p for p in out.pairs if p.gap_mm is not None and abs(p.gap_mm - usual) > WIDTH_TOL_MM]
            for p in off:
                out.skipped.append(f"({p.xy[0]:.0f}, {p.xy[1]:.0f}): gripped off-centre "
                                   f"({p.gap_mm:.1f} mm, usually {usual:.1f})")
            out.pairs = [p for p in out.pairs if not any(p is q for q in off)]
        # still enough spots of their own once those are left out? (a look back at the first spot is no spot of its
        # own, nor is the same spot measured twice)
        kept = {(round(p.xy[0], 1), round(p.xy[1], 1)) for p in out.pairs if not p.check}
        if len(kept) < needed:
            out.reason = (f"only {len(kept)} of the {len(found)} spots the camera found can be used (the others are "
                          f"left out, below), and at least {needed} are needed. Is the table clear but for the cube, "
                          "and all of it in the camera's view?")
            _put_down(arm, robot, out, last)
            return out
        # 4. the fit
        say("Solving...")
        heights = [p.sighting.height_mm for p in out.pairs]
        sizes = [p.sighting.footprint_mm for p in out.pairs]
        out.cube_mm = (round(float(np.median([s[0] for s in sizes])), 1),
                       round(float(np.median([s[1] for s in sizes])), 1), round(float(np.median(heights)), 1))
        out.cube_h = hand.cube_h = float(cube_size_mm) if cube_size_mm else out.cube_mm[2]
        if len(gaps) >= 2:
            out.gripper_mm = (round(min(gaps), 1), round(max(gaps), 1))
        fit, out.tried, out.plane = solve_cube(out.pairs, out.table_z, out.cube_h,
                                               None if raw is None else raw[1], settings.correction, _jaw_of(gripper))
        if fit is None:
            out.reason = "the table round the cube couldn't be measured (too few depth readings)."
            _put_down(arm, robot, out, last)
            return out
        out.fit, out.transform, out.correction = fit, fit.transform, fit.correction
        for p in out.pairs:
            p.held_at = None
        if fit.tracked:
            # where each cube's middle was, by the tracking: what follows (the angle check, the pick test) goes there
            for p, centre in zip(out.pairs, fit.centres):
                p.held_at = (float(centre[0]), float(centre[1]))
            out.grip_along_mm = [round(float(v), 2) for v in fit.along]
            out.notes.append(f"the cube's place along the fingers changed by up to "
                             f"{float(np.ptp(fit.along)):.1f} mm from grip to grip; the camera tracked it")
        out.used = [out.pairs[i] for i in fit.used]
        # the looks back at the first spot are spots of the fit, but each has a near twin (the first spot itself): left
        # out, it is still in, so its error is only the repeat's -- the typical error is of the other spots
        out.errors_mm = [e for p, e in zip(out.used, fit.errors_mm) if not p.check] or fit.errors_mm
        cam = np.array([p.sighting.cam_xyz for p in out.used], float)
        robot_xy = np.array([p.xy for p in out.used], float)
        # the gripper's middle from the tool point: used if the best fit was made with it (the robots then move by
        # it); otherwise only reported
        d, without, with_d = tool_offset(cam, robot_xy, np.array([p.r for p in out.used]), out.plane, out.table_z)
        if fit.offset is not None:
            d, out.offset_used = fit.offset, True
        out.tool_offset_mm = (round(float(d[0]), 2), round(float(d[1]), 2))
        out.tool_offset_gain = (round(without, 2), round(with_d, 2))
        # cross-checks: a free 3D fit's "up" against the table's, and the cube tops' height
        tops = np.array([p.robot_xyz(out.table_z, out.cube_h, out.offset) for p in out.used], float)
        free, _ = solve_rigid_transform(cam, tops)
        up = free[2, :3] / np.linalg.norm(free[2, :3])
        out.up_check_deg = math.degrees(math.acos(min(1.0, abs(float(np.dot(up, out.plane.normal))))))
        predicted = np.array([predict(out.transform, None, p.sighting.cam_xyz) for p in out.used])
        out.height_bias_mm = float(np.median(predicted[:, 2] - tops[:, 2]))
        out.sides_mm = sides_offset([p.sighting for p in out.used], out.transform)
        # the fingers' real angle (a gripper turned a few degrees on the wrist misses a 25 mm cube in 27.5 mm)
        if gripper is not None and gripper.fingers:
            # (not the spots where it turned as it dropped, nor ones seen only partly)
            turned = {(entry["xy"][0], entry["xy"][1]) for entry in out.spot_log if entry.get("turned_deg")}
            skip = tuple(i for i, p in enumerate(out.used)
                         if (round(p.xy[0], 1), round(p.xy[1], 1)) in turned or not _seen_whole(p.sighting, out.cube_h))
            out.fingers = fingers_angle(out.used, out.transform, float(gripper.jaw_axis_deg), skip)
            if out.fingers is not None and out.fingers[1] <= JAW_SPREAD_MAX_DEG:
                out.jaw_axis_deg = round(float(gripper.jaw_axis_deg) + out.fingers[0], 2)
        out.pattern = describe_pattern(fit.loo, robot_xy, np.array([p.sighting.pixel for p in out.used]), k)
        if old_transform is not None:
            old = np.asarray(old_transform, float)
            for p in out.used:
                guess = old @ np.append(p.sighting.cam_xyz, 1.0)
                cx, cy = p.centre_xy(out.offset)
                out.before_mm.append(float(math.hypot(guess[0] - cx, guess[1] - cy)))
        typical = out.typical_mm
        out.pass_mm = settings.pass_mm
        far = too_many_far(out.errors_mm)
        if typical <= settings.pass_mm and far:
            out.over_limit = not out.slipped
            out.reason = (f"{len(far)} of the {len(out.errors_mm)} spots miss by more than {WORST_MM:.0f} mm (up to "
                          f"{max(far):.1f}), though typically only {typical:.2f}: part of the run disagrees with the "
                          "rest. Did the cube shift in the gripper, or the arm knock something? Was the arm homed?")
        elif typical > settings.pass_mm:
            # (all else went through: the user may keep it anyway, knowing -- not if the cube or the arm shifted
            # during the run: then the spots disagree because they were measured in two different places)
            out.over_limit = not out.slipped
            out.reason = (f"the spots typically disagree by {typical:.2f} mm (it should be under "
                          f"{settings.pass_mm:.1f}). Is the cube square and firm in the gripper, the camera steady "
                          "and warmed up? Was the arm homed?")
            # (the lab, 2026-10-11: on the High Accuracy preset a 25 mm cube's top read 15-21 mm -- its edges dropped
            # out of the depth, each spot's middle a little off, 2.3 mm -- while the arm went smoothly)
            tall = float(np.median([p.sighting.height_mm for p in out.used])) if out.used else 0.0
            side = float(cube_size_mm or tall)
            seen = float(np.median([min(p.sighting.footprint_mm) for p in out.used])) if out.used else side
            if side > 0 and seen < 0.85 * side:
                preset = getattr(camera, "depth_preset", None)
                out.reason += (f" The camera saw only part of the cube's top: about {seen:.0f} mm of {side:.0f}, so "
                               "where it put each spot's middle was off"
                               + (f" -- the {preset} depth preset drops the cube's edges: try Default"
                                  if preset and preset != "Default" else "") + ".")
        out.passed = not out.reason
        logger.info(summary(out))
        if out.turn_fixes:
            out.notes.append("the cube turned as it was let go at " + ", ".join(
                f"spot {spot} ({deg:+.0f} degrees)" for spot, deg in out.turn_fixes)
                + "; the wrist turned to match to take it back")
        # 5. ready for what follows: holding cube A, the arm away, a picture of the table without anything new
        if out.passed:
            middle = robot_xy.mean(axis=0)
            out.away_index = max(range(len(away)), key=lambda i: math.hypot(away[i].x - middle[0],
                                                                           away[i].y - middle[1]))
            pose = away[out.away_index]
            arm.away(pose)
            out.background = arm.look()
        else:
            _put_down(arm, robot, out, last)
        return out
    except _Paused as paused:
        _holding_now(out, arm)
        out.paused = out.keep_progress = True
        out.passed, out.transform = False, None      # (paused after solving, as it went to wait: nothing is saved)
        out.reason = paused.why + (f". {paused.advice}" if paused.advice else "")
        progress.why = out.reason
        logger.info("Cube calibration paused: %s", out.reason)
        logger.info(summary(out))
        save()
        return out
    except _Stopped:
        out.cancelled = out.keep_progress = True
        out.passed, out.transform = False, None      # (stopped after solving, as it went to wait: nothing is saved)
        _holding_now(out, arm)                       # (stopped as it lifted the cube it had just taken, or let go of)
        save()
        if out.holding:
            try:
                here = robot.get_pose()
                _put_down(arm.__class__(robot, camera, 0.0, 1, say, None, dz=arm.dz), robot, out,
                          (here.x, here.y, here.r))
            except (RuntimeError, TimeoutError):
                pass
        return out
    except RobotStopped:
        save()
        raise
    except (RuntimeError, TimeoutError) as exc:   # a refused move or no answer, anywhere else: pause, say where
        logger.warning("Cube calibration paused: %s", exc)
        _holding_now(out, arm)
        where = ("The cube is still in the gripper." if out.holding else
                 f"The cube is standing at ({out.cube_at[0]:.0f}, {out.cube_at[1]:.0f})." if out.cube_at else "")
        out.reason = f"{refusal_text(exc)} {where}".rstrip()
        out.paused = out.keep_progress = True
        out.transform = None
        out.passed = False
        progress.why = out.reason
        save()
        _safe_up(robot)
        return out


def too_many_far(errors_mm: list) -> list:
    """The spots' left-out misses over WORST_MM, if there are too many of them to pass (more than WORST_SHARE of
    the spots, and at least 2); else []."""
    far = [float(e) for e in errors_mm if e > WORST_MM]
    return far if len(far) >= max(2, math.ceil(WORST_SHARE * len(errors_mm))) else []


def _holding_now(out: CubeOutcome, arm: "_Arm") -> None:
    """After a step stopped part way: whether the cube is in the gripper, by what the step last did (every step sets
    out.holding once it is through, so a stop inside one left it as before: "The cube is still in the gripper" said
    of a cube let go of just before the controller stopped answering, and a cube gripped as Pause was pressed taken
    as on the table)."""
    if not arm.acted:
        return
    if arm.closed and not out.holding:
        out.holding, out.cube_at = True, None
    elif not arm.closed and out.holding:
        out.holding, out.cube_at = False, getattr(arm, "acted_at", None)


def _robot_xy(robot, pair: CubePair, phase1: CubeOutcome) -> tuple[float, float]:
    """Where to send the robot for a spot phase 1 used, now that it moves by all of the gripper's offset."""
    return pair.centre_xy(phase1.offset)


def _use_offset(robot, phase1: CubeOutcome) -> None:
    """After phase 1 the robot moves by all of the gripper's offset found (the app sets it too, on saving)."""
    if hasattr(robot, "tool_centre_mm"):
        robot.tool_centre_mm = phase1.total_offset


UNANSWERED_ADVICE = ("The controller stopped carrying out moves (it still says where it is): switch the Dobot off, "
                     "wait 5 seconds and on again, press 'Reconnect Robot' and Home (Manual tab), then grip the cube "
                     "and press 'Manually gripped - continue'")


def unanswered(exc: Exception) -> bool:
    """A move the controller never answered, sent twice (seen at the lab: then it takes no move until switched off
    and on) -- not a move refused for being out of reach."""
    return "acknowledge" in str(exc).lower()


def needs_a_person(exc: Exception, robot=None) -> bool:
    """A refused move no other spot would get past: the arm to be homed, power-cycled or reconnected, its link lost.
    Taken as "can't go there", it skipped every spot left in seconds (an alarm that wouldn't clear at spot 5 of 10:
    "found the cube at only 4 of 10 spots" after the power cycle, the run's progress gone -- reviewer 2, 2026-10-27)."""
    text, why = str(exc).lower(), getattr(robot, "needs_person", None)     # (the Dobot's: why, in words, or None)
    return (isinstance(exc, RobotNeedsPerson) or (isinstance(why, str) and bool(why))
            or "not connected" in text or "disconnected" in text or "lost contact" in text)


def refusal_text(exc: Exception) -> str:
    """Why a refused move stopped a run, and what to do."""
    if not unanswered(exc):
        return f"the robot refused a move ({exc})."
    # (the driver's own advice -- Clear Alarms -- left out: it was just done by itself, and a run needs the arm
    # homed and the cube gripped again besides)
    said = str(exc).split(" It answers everything else")[0]
    return f"the robot refused a move ({said}). {UNANSWERED_ADVICE}."


def _safe_up(robot) -> None:
    """After a refused move: the arm up out of the way, if it will go."""
    try:
        here = robot.get_pose()
        robot.move_to(Pose(here.x, here.y, here.z + 30.0, here.r))
    except Exception:  # noqa: BLE001 - only a courtesy; the reason is already reported
        pass


def _put_down(arm: _Arm, robot, out: CubeOutcome, at: Optional[tuple]) -> None:
    """Leave the cube on the table (where it last was), the gripper open, the arm up."""
    if not out.holding or at is None:
        return
    arm.down_and(at[0], at[1], out.hand.release_z(), at[2], LIFT_MM, robot.open_gripper)
    out.holding, out.cube_at = False, (at[0], at[1])


@_paced
def put_cube_down(robot, phase1: CubeOutcome, bounds: dict, reach_mm: float, settle_s: float = SETTLE_S) -> None:
    """Nothing more wanted: the cube phase 1 left in the gripper goes back down on the table, where it last stood,
    and the arm back out of the way."""
    if not phase1.holding or not phase1.used:
        return
    arm = _Arm(robot, None, settle_s, 1, lambda message: None, None, dz=phase1.table_dz)
    last = phase1.used[-1]
    x, y = _robot_xy(robot, last, phase1)
    _put_down(arm, robot, phase1, (x, y, last.r))
    away = away_poses_for(bounds, reach_mm, phase1.grip_z + AWAY_UP_MM)[phase1.away_index]
    arm.away(away)


# ---- the pick test -------------------------------------------------------------------------------------------------------
@dataclass
class PickTestOutcome:
    placed_mm: list = field(default_factory=list)     # each round: where the camera + result put it, from the truth
    held: int = 0                                     # picks (by the camera alone) that came up holding it
    rounds: int = 0
    hidden: int = 0                                   # spots where the camera didn't see it whole (tried another)
    reason: str = ""
    cancelled: bool = False

    @property
    def typical_mm(self) -> Optional[float]:
        return float(np.median(self.placed_mm)) if self.placed_mm else None


@_paced
def run_pick_test(robot, camera, phase1: CubeOutcome, bounds: dict, reach_mm: float, gripper=None, rounds: int = 3,
                  settle_s: float = SETTLE_S, frames: int = FRAMES, on_progress=None, cancel=None) -> PickTestOutcome:
    """After phase 1 (cube A held, the arm away): put it down at spots the fit never saw, find it with the new
    calibration alone (the error there is the honest one), then pick it up from where the calibration says it is,
    not from where the robot knows it is -- a real pick. Ends holding it, the arm away."""
    say = on_progress or (lambda message: None)
    arm = _Arm(robot, camera, settle_s, frames, say, cancel, dz=phase1.table_dz)
    k, hand, out = phase1.k, phase1.hand, PickTestOutcome()
    away = away_poses_for(bounds, reach_mm, phase1.grip_z + AWAY_UP_MM)[phase1.away_index]
    seen = in_view_check(phase1.transform, k, hand.table_z + (phase1.cube_h or 20.0))
    _use_offset(robot, phase1)                  # the robot moves by the gripper's offset, as it will for picking
    used = [p.centre_xy(phase1.offset) for p in phase1.pairs]
    x0, x1, y0, y1 = workspace_region(bounds, reach_mm)
    near, far = min_radius_mm() + NEAR_BASE_MARGIN_MM, FAR_REACH * reach_mm
    candidates = [(float(x), float(y)) for x in np.arange(x0, x1 + 1.0, GRID_MM / 2) for y in
                  np.arange(y0, y1 + 1.0, GRID_MM / 2) if near <= math.hypot(x, y) <= far and (seen is None or seen(x, y))
                  and abs(math.degrees(math.atan2(y, x))) <= MAX_SPOT_AZIMUTH_DEG]
    # between the spots the fit used: never one of them (15 mm clear), but no further out than they went (out there
    # the arm, waiting, can stand between the camera and the cube)
    candidates = [p for p in candidates if 15.0 <= min(math.dist(p, q) for q in used) <= 40.0]
    if not candidates:
        out.reason = "no free spot in the camera's view to test at."
        return out
    middle = np.mean(used, axis=0)
    chosen = [min(candidates, key=lambda p: math.dist(p, middle))]       # then each as far from those as it can be
    while len(chosen) < min(rounds + 3, len(candidates)):                # (a few spare, for spots it can't see)
        chosen.append(max((p for p in candidates if p not in chosen),
                          key=lambda p: min(math.dist(p, q) for q in chosen)))
    try:
        for x, y in chosen:
            if out.rounds >= rounds:
                break
            arm.check()
            index = out.rounds
            out.rounds += 1
            r = middle_turn(x, y)
            say(f"Pick test {index + 1} of {rounds}: putting the cube at ({x:.0f}, {y:.0f})...")
            arm.down_and(x, y, hand.release_z(), r, LIFT_MM, robot.open_gripper)
            put = robot.get_pose()
            phase1.holding, phase1.cube_at = False, (x, y)
            arm.away(away)
            sighting = find_new_object(arm.look().depth, phase1.background.depth, k, size_mm=phase1.cube_h,
                                       expect_px=project(phase1.transform, k, (put.x, put.y,
                                                                               hand.table_z + phase1.cube_h)))
            if sighting is None:
                out.reason = f"round {index + 1}: the camera didn't find the cube."
                arm.down_and(x, y, hand.pick_z(), r, LIFT_MM, robot.close_gripper)
                hand.taken()
                phase1.holding, phase1.cube_at = True, None
                break
            if not _whole(sighting, phase1.cube_mm[0]):     # partly hidden there: back by the robot's own coordinates
                out.hidden += 1
                out.rounds -= 1
                arm.down_and(x, y, hand.pick_z(), r, LIFT_MM, robot.close_gripper)
                hand.taken()
                phase1.holding, phase1.cube_at = True, None
                continue
            where = predict(phase1.transform, phase1.correction, sighting.cam_xyz)
            out.placed_mm.append(float(math.hypot(where[0] - put.x, where[1] - put.y)))
            # the real pick: from where the calibration says it is
            say(f"Pick test {index + 1}: picking it up from where the camera says it is...")
            arm.down_and(float(where[0]), float(where[1]), hand.pick_z(), r, LIFT_MM, robot.close_gripper)
            hand.taken()
            holds = holding_after(arm, robot, sighting, away)
            if holds:
                out.held += 1
            phase1.holding, phase1.cube_at = holds, None if holds else (x, y)
            if not holds:
                out.reason = f"round {index + 1}: the gripper came up empty."
                break
            # centre it again (the pick may have taken it a little off-centre, along the fingers)
            arm.down_and(float(where[0]), float(where[1]), hand.release_z(), r, LIFT_MM, robot.open_gripper)
            _take_back(arm, robot, float(where[0]), float(where[1]), hand.pick_z(), r)
            hand.taken()
        arm.away(away)
        return out
    except _Stopped:
        out.cancelled = True
        return out


# ---- phase 2: heights, with 1 or 2 more cubes ------------------------------------------------------------------------------
@dataclass
class HeightsOutcome:
    extra: int = 1                                   # cubes added: 1 (stacks 2 high) or 2 (towers 3 high)
    stacks: list = field(default_factory=list)       # CubePair, level 2 or 3
    tried: int = 0
    transform: Optional[np.ndarray] = None           # the combined result, if it is better; else None
    table_typical_mm: Optional[float] = None         # the table spots, left out, with the combined fit
    stack_before_mm: list = field(default_factory=list)   # the stack points through phase 1's calibration (3D)
    stack_after_mm: list = field(default_factory=list)    # ...through the combined one, each left out (3D)
    level_bias_mm: dict = field(default_factory=dict)     # level: median height error through phase 1's, mm
    hidden: int = 0                                  # levels partly hidden from the camera (not used)
    kept: bool = False
    reason: str = ""
    cancelled: bool = False


def _squeeze_twice(arm: _Arm, robot, gripper, at: tuple, z: float, r: float) -> None:
    """Take a cube standing at `at` (not put there by the robot) so it ends up centred on the tool: see _take_back
    (closing centres it across the fingers). Ends up above it."""
    _take_back(arm, robot, at[0], at[1], z, middle_turn(at[0], at[1]))


def _whole(seen: CubeSighting, side_mm: float) -> bool:
    """Whether the cube's whole top was seen (not cut short by something in front of it, or the picture's edge).
    (The real camera saw a 25 mm cube's top as 19.5-27.5 mm across.)"""
    narrow, long_ = seen.footprint_mm
    return narrow >= 0.7 * side_mm and long_ <= 1.4 * side_mm


def _stacked_ok(seen: Optional[CubeSighting], transform: np.ndarray, at: tuple, height: float) -> bool:
    if seen is None:
        return False
    xyz = transform @ np.append(seen.cam_xyz, 1.0)
    return abs(seen.height_mm - height) <= STACK_MM and math.hypot(xyz[0] - at[0], xyz[1] - at[1]) <= STACK_XY_MM


@_paced
def run_cube_stacks(robot, camera, phase1: CubeOutcome, bounds: dict, reach_mm: float, gripper=None, extra: int = 1,
                    spots: Optional[int] = None, settle_s: float = SETTLE_S, frames: int = FRAMES,
                    on_progress: Optional[Callable[[str], None]] = None,
                    cancel: Optional[Callable[[], bool]] = None) -> HeightsOutcome:
    """Phase 2: cube A is held (phase 1 left it so, the arm away) and `extra` more cubes (1 or 2) have just been put
    on the table. At each spot a tower of all the cubes is built, one level at a time, each checked by the camera
    before the next goes on; then it is moved to the next spot top first (so it is rebuilt upside down there). Only
    the new cubes' first places come from the camera; each is centred across the fingers when first taken."""
    say = on_progress or (lambda message: None)
    arm = _Arm(robot, camera, settle_s, frames, say, cancel, dz=phase1.table_dz)
    k, hand = phase1.k, phase1.hand
    out = HeightsOutcome(extra=extra)
    levels = 1 + extra
    count = spots or (5 if extra == 1 else 4)
    T, h = phase1.transform, phase1.cube_h
    _use_offset(robot, phase1)                  # the robot moves by the gripper's offset found in phase 1
    top_z = hand.table_z + (levels - 1) * h + STACK_REPICK_MM + LIFT_MM
    if top_z > bounds["z"][1]:
        out.reason = (f"a tower {levels} cubes high needs the arm up to z = {top_z:.0f} mm, above its limit "
                      f"({bounds['z'][1]:.0f}).")
        return out
    base_away = away_poses_for(bounds, reach_mm, phase1.grip_z + AWAY_UP_MM)[phase1.away_index]
    away = Pose(base_away.x, base_away.y, min(bounds["z"][1], max(base_away.z, top_z + 20.0)), base_away.r)
    seen_top = in_view_check(T, k, hand.table_z + levels * h)
    try:
        say(f"Looking for the {'second cube' if extra == 1 else 'two more cubes'}...")
        arm.away(away)
        picture = arm.look()
        found = find_new_objects(picture.depth, phase1.background.depth, k, extra, size_mm=phase1.cube_h)
        if len(found) < extra:
            out.reason = (f"the camera found {len(found)} of the {extra} new cube{'s' if extra > 1 else ''}. "
                          "Are they on the table, apart, in the camera's view?")
            return out
        new = [tuple(float(v) for v in predict(T, phase1.correction, s.cam_xyz)[:2]) for s in found]
        before = picture
        # the spots: the first new cube's place, then some of phase 1's own (on table the camera sees whole)
        middle = np.mean([p.centre_xy(phase1.offset) for p in phase1.used], axis=0)
        used = sorted((p.centre_xy(phase1.offset) for p in phase1.used), key=lambda q: math.dist(q, middle))
        candidates = [q for q in used if all(math.dist(q, c) > 70.0 for c in new)
                      and (seen_top is None or seen_top(*q))
                      and math.dist(q, (away.x, away.y)) > 140.0]   # (the arm waiting beside a tower hid its top)
        tower_spots = [new[0]]
        while len(tower_spots) < count and candidates:
            pick = max(candidates, key=lambda p: min(math.dist(p, q) for q in tower_spots))
            candidates.remove(pick)
            tower_spots.append(pick)
        # where each cube is: [spot, level, centred on the tool when last put down]
        cubes = {"B": [new[0], 1, False]}
        if extra == 2:
            cubes["C"] = [new[1], 1, False]
        held = "A"

        def look_at_level(level: int, spot: tuple, put: Pose) -> bool:
            nonlocal before
            arm.away(away)
            after = arm.look()
            seen = find_new_object(after.depth, before.depth, k, phase1.plane, size_mm=phase1.cube_h,
                                   expect_px=project(T, k, (put.x, put.y, hand.table_z + level * h)))
            before = after
            if seen is None or not _whole(seen, phase1.cube_mm[0]):
                out.hidden += 1              # not seen, or only a sliver of it: not measured, but nothing says wrong
                logger.info("Tower level %d at (%.0f, %.0f) not seen whole: %s", level, spot[0], spot[1],
                            None if seen is None else (seen.footprint_mm, round(seen.height_mm, 1)))
                return True
            if not _stacked_ok(seen, T, spot, level * h):
                out.reason = (f"the tower at ({spot[0]:.0f}, {spot[1]:.0f}) didn't come out right at level {level} "
                              f"(the camera sees its top {seen.height_mm:.0f} mm up, {level * h:.0f} expected, or not "
                              "where it was put). The height step was stopped there: please take that tower apart "
                              "by hand.")
                return False
            if _whole(seen, phase1.cube_mm[0]):          # (partly hidden: right, but not measured well)
                out.stacks.append(CubePair((put.x, put.y), put.r, seen, None, level, centred=True))
            else:
                out.hidden += 1
            return True

        def take(name: str) -> None:
            nonlocal held
            spot, level, centred = cubes.pop(name)
            if centred:
                arm.down_and(spot[0], spot[1], hand.pick_z(level), middle_turn(*spot), LIFT_MM,
                             robot.close_gripper)
            else:
                _squeeze_twice(arm, robot, gripper, spot, hand.pick_z(level), middle_turn(*spot))
            hand.taken(level)
            held = name

        def put_on(spot: tuple, level: int) -> Pose:
            nonlocal held
            arm.down_and(spot[0], spot[1], hand.release_z(level), middle_turn(*spot), LIFT_MM, robot.open_gripper)
            put = robot.get_pose()
            cubes[held] = [spot, level, True]
            held = None
            return put

        phase1.holding = True
        order = ["B", "A"] + (["C"] if extra == 2 else [])        # bottom to top, at the first spot
        for index, spot in enumerate(tower_spots):
            arm.check()
            out.tried += 1
            say(f"Tower {index + 1} of {len(tower_spots)} at ({spot[0]:.0f}, {spot[1]:.0f})...")
            if index == 0:
                # A (held) on B, then (two more cubes) C on A
                put = put_on(spot, 2)
                phase1.holding = False
                if not look_at_level(2, spot, put):
                    break
                if extra == 2:
                    take("C")
                    put = put_on(spot, 3)
                    if not look_at_level(3, spot, put):
                        break
                continue
            # the tower moves here top first: its top cube is the new bottom
            previous = order
            order = list(reversed(previous))
            for level, name in enumerate(order, start=1):
                take(name)
                put = put_on(spot, level)
                if level == 1:
                    arm.away(away)
                    before = arm.look()
                elif not look_at_level(level, spot, put):
                    break
            if out.reason:
                break
        else:
            # take the last tower down: its top cubes back on the table, at spots now empty
            free = [s for s in reversed(tower_spots[:-1])] + [q for q in candidates]
            for name in reversed(order[1:]):
                if not free:
                    break
                take(name)
                put_on(free.pop(0), 1)
            arm.away(away)
        if held is not None and not out.reason:
            put_on(tower_spots[0], 1)
        phase1.holding = False
        if not out.stacks:
            return out
        # the heights through phase 1's result, by level
        truth = {id(p): np.array(p.robot_xyz(hand.table_z, h, phase1.offset)) for p in out.stacks}
        for p in out.stacks:
            out.stack_before_mm.append(float(np.linalg.norm(predict(T, phase1.correction, p.sighting.cam_xyz)
                                                            - truth[id(p)])))
        for level in sorted({p.level for p in out.stacks}):
            errors = [float(predict(T, phase1.correction, p.sighting.cam_xyz)[2] - truth[id(p)][2])
                      for p in out.stacks if p.level == level]
            out.level_bias_mm[level] = float(np.median(errors))
        # the combined fit (table and stacks, free in 3D, with a scale), kept only if it is at least as good on the
        # table and better up high
        say("Solving with the stacks...")
        pairs = list(phase1.used) + out.stacks
        cam = np.array([p.sighting.cam_xyz for p in pairs], float)
        rob = np.array([p.robot_xyz(hand.table_z, h, phase1.offset) for p in pairs], float)
        combined, _ = solve_rigid_transform(cam, rob, with_scale=True)
        table_errors = []
        for i, p in enumerate(pairs):
            keep = [j for j in range(len(pairs)) if j != i]
            without, _ = solve_rigid_transform(cam[keep], rob[keep], with_scale=True)
            guess = (without @ np.append(cam[i], 1.0))[:3]
            if p.level == 1:
                table_errors.append(float(math.hypot(guess[0] - rob[i][0], guess[1] - rob[i][1])))
            else:
                out.stack_after_mm.append(float(np.linalg.norm(guess - rob[i])))
        out.table_typical_mm = float(np.median(table_errors))
        better_up = float(np.median(out.stack_after_mm)) < float(np.median(out.stack_before_mm))
        as_good = phase1.typical_mm is not None and out.table_typical_mm <= phase1.typical_mm + 0.1
        if better_up and as_good:
            out.transform, out.kept = combined, True
        elif not out.reason:
            out.reason = "the stacks didn't improve on the table calibration, so that is kept."
        return out
    except _Stopped:
        out.cancelled = True
        return out


def run_cube_heights(robot, camera, phase1: CubeOutcome, bounds: dict, reach_mm: float, gripper=None,
                     stacks: int = 5, **kwargs) -> HeightsOutcome:
    """Phase 2 with one more cube: stacks two high."""
    return run_cube_stacks(robot, camera, phase1, bounds, reach_mm, gripper, extra=1, spots=stacks, **kwargs)


def camera_warm(camera) -> Optional[float]:
    """Seconds the camera has been on, if it says (the real one does)."""
    since = getattr(camera, "connected_at", None)
    return None if since is None else time.monotonic() - since

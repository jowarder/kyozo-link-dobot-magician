"""Continuous calibration: the camera->robot calibration kept right while the app works (Dr. Curry's "cruise control").

A calibration is true for the camera where it was. Bumped, shaken or warmed, the camera ends up a little elsewhere and
everything it reports is quietly off. Instead of waiting for someone to notice and calibrate again, this keeps checking
and makes small corrections:

1. **A fixed target always in view**: the study's A4 sheet, taped to the table. Where its four corners are in the
   robot's coordinates is remembered when this starts (through the calibration then in use, the cube calibration's).
   The camera finds the corners itself, in its own coordinates, without the calibration (app/vision/paper.py).
2. **Check quietly**: every few seconds, while the arm is idle, one picture: the sheet's corners through the
   calibration in use, against where they belong. And the still background (the robot's base, the table's edge,
   cables; not the sheet) matched across frames with the picture taken at the start (app/vision/drift.py): if the
   camera moved, the background moved with the sheet in the picture; if only the sheet moved, the background didn't.
3. **A running score**: one look never decides. The last WINDOW looks are kept; something is done only when at least
   MIN_AGREE of them agree, steadily (a hand in the way, a blurred picture, a featureless view: that look is skipped).
4. **Small corrections**: the camera moved steadily -> the rigid turn and shift carrying the corners as measured onto
   where they belong, applied to the calibration (T_new = D . T): at most STEP_MM / STEP_DEG at a time.
5. **Only improvements kept**: after a correction, VERIFY_CHECKS fresh looks must find the corners closer than before;
   if not, it goes back to the last good calibration.
6. **Limits**: in all more than TOTAL_MM / TOTAL_DEG from the calibration it started from is a knock, not a drift: it
   stops and asks for a calibration with the cube. The sheet moved alone: it says so and corrects nothing.

Everything here is plain logic on numbers and pictures (no Qt, no robot): app/ui/continuous_monitor.py runs it.
The camera's own depth (its left/right images) is the camera's: Orbbec offers no way to recalibrate it from here.
"""
from __future__ import annotations

import io
import itertools
import json
import math
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np

from app.calibration.solver import solve_rigid_transform
from app.fileutil import atomic_write_bytes, set_aside_damaged
from app.vision.drift import REFERENCE_WIDTH, _shrunk_gray, picture_affine

CHECK_EVERY_S = 10.0       # a look this often, while the arm is idle
WINDOW = 6                 # the looks the running score keeps
MIN_AGREE = 4              # ...and how many of them must agree before anything is done
NOISE_MM = 0.7             # the sheet's corners this close to where they belong: nothing to correct
NOISE_DEG = 0.15
SPREAD_MM = 1.2            # the looks agreeing on a move: each corner within this of their average
STEP_MM = 2.0              # one correction moves the corners at most this far...
STEP_DEG = 0.3             # ...and turns at most this much
TOTAL_MM = 10.0            # further than this from the calibration it started from: a knock -- calibrate again
TOTAL_DEG = 3.0
VERIFY_CHECKS = 3          # fresh looks after a correction, to keep it or go back
IMPROVED_MM = 0.1          # ...closer than before by at least this (or within NOISE_MM) to keep it
MAX_REVERTS = 2            # corrections in a row that didn't help: it stops (the same one would be tried again)
CAMERA_AGREES_PX = 1.5     # the sheet where the background's move says, within this (full-size pixels): the camera
STILL_PX = 1.0             # moved less than this in the picture: still
SHEET_MARGIN_PX = 12       # (REFERENCE_WIDTH pixels) round the sheet left out of the background


def reference_file(calibration_file) -> Path:
    path = Path(calibration_file)
    return path.with_name(path.stem + ".continuous.npz")


def state_file(calibration_file) -> Path:
    path = Path(calibration_file)
    return path.with_name(path.stem + "_continuous.json")


def log_file(calibration_file) -> Path:
    path = Path(calibration_file)
    return path.with_name(path.stem + "_continuous_log.jsonl")


# ---- geometry ----------------------------------------------------------------------------------------------------
def apply(transform: np.ndarray, points: np.ndarray) -> np.ndarray:
    points = np.asarray(points, float)
    return (np.asarray(transform, float) @ np.hstack([points, np.ones((len(points), 1))]).T).T[:, :3]


def project(points_cam: np.ndarray, intrinsics) -> np.ndarray:
    """Camera points (mm) as full-size picture pixels."""
    p = np.asarray(points_cam, float)
    return np.stack([intrinsics.fx * p[:, 0] / p[:, 2] + intrinsics.cx,
                     intrinsics.fy * p[:, 1] / p[:, 2] + intrinsics.cy], axis=1)


def turn_deg(rotation: np.ndarray) -> float:
    """How far a 3 x 3 turn turns (any scale taken out), in degrees."""
    r = np.asarray(rotation, float)
    r = r / np.cbrt(abs(np.linalg.det(r))) if abs(np.linalg.det(r)) > 1e-12 else r
    return math.degrees(math.acos(max(-1.0, min(1.0, (np.trace(r) - 1.0) / 2.0))))


def _rectangle_orders():
    """The 8 ways the same 4 corners of a rectangle can be listed (any start, either way round)."""
    for start in range(4):
        yield [(start + k) % 4 for k in range(4)]
        yield [(start - k) % 4 for k in range(4)]


def match_corners(measured: np.ndarray, wanted: np.ndarray) -> np.ndarray:
    """`measured`'s rows put in the order of `wanted`'s (each corner to its own): the listing nearest overall."""
    best = min(_rectangle_orders(), key=lambda order: float(np.linalg.norm(measured[order] - wanted, axis=1).sum()))
    return np.asarray(best)


def limited(d: np.ndarray, points: np.ndarray, step_mm: float = STEP_MM, step_deg: float = STEP_DEG) -> np.ndarray:
    """Part of the rigid correction `d`: the same turn and shift, scaled down so the points move at most `step_mm` and
    it turns at most `step_deg` (all of it if it is that small already). About the points' middle."""
    points = np.asarray(points, float)
    moved = float(np.linalg.norm(apply(d, points) - points, axis=1).max())
    angle = turn_deg(d[:3, :3])
    share = min(1.0, step_mm / moved if moved > 1e-9 else 1.0, step_deg / angle if angle > 1e-9 else 1.0)
    if share >= 1.0:
        return np.asarray(d, float)
    rvec, _ = cv2.Rodrigues(np.asarray(d[:3, :3], float))
    rotation, _ = cv2.Rodrigues(rvec * share)
    centre = points.mean(axis=0)
    shift = apply(d, centre[None])[0] - centre
    out = np.eye(4)
    out[:3, :3] = rotation
    out[:3, 3] = centre + share * shift - rotation @ centre
    return out


def change(new: np.ndarray, old: np.ndarray, points_cam: np.ndarray) -> tuple[float, float]:
    """How far two calibrations disagree: the most any of the camera points lands apart (mm), and the turn between
    them (degrees)."""
    gap = float(np.linalg.norm(apply(new, points_cam) - apply(old, points_cam), axis=1).max())
    a, b = np.asarray(new, float)[:3, :3], np.asarray(old, float)[:3, :3]
    sa, sb = np.cbrt(abs(np.linalg.det(a))), np.cbrt(abs(np.linalg.det(b)))
    return gap, turn_deg((a / sa) @ (b / sb).T)


# ---- the reference: how the sheet and the background looked when it started -------------------------------------
@dataclass
class Reference:
    corners_cam: np.ndarray            # 4 x 3: the sheet's corners in the camera's coordinates, at the start
    corners_robot: np.ndarray          # 4 x 3: ...where they belong: through the calibration it started from
    gray: np.ndarray                   # the picture, REFERENCE_WIDTH wide (for the background)
    mask: np.ndarray                   # where in it the background is (not the sheet): 255
    start_transform: np.ndarray        # the calibration it started from
    created: str

    def save(self, path) -> None:
        buffer = io.BytesIO()
        np.savez_compressed(buffer, corners_cam=self.corners_cam, corners_robot=self.corners_robot, gray=self.gray,
                            mask=self.mask, start_transform=self.start_transform, created=self.created)
        atomic_write_bytes(path, buffer.getvalue())

    @staticmethod
    def load(path) -> Optional["Reference"]:
        file = Path(path)
        if not file.exists():
            return None
        try:
            with open(file, "rb") as handle, np.load(handle, allow_pickle=False) as data:
                return Reference(np.array(data["corners_cam"], float), np.array(data["corners_robot"], float),
                                 np.array(data["gray"]), np.array(data["mask"]),
                                 np.array(data["start_transform"], float), str(data["created"]))
        except Exception:  # noqa: BLE001 - damaged: set aside, start again
            set_aside_damaged(file)
            return None


def make_reference(rgb: np.ndarray, corners_cam: np.ndarray, intrinsics, transform: np.ndarray) -> Reference:
    """The start: the sheet's corners as seen now, where they belong (through `transform`, the calibration in use),
    and the picture's background (everything but the sheet and a margin round it)."""
    gray = _shrunk_gray(rgb)
    factor = REFERENCE_WIDTH / rgb.shape[1]
    mask = np.full(gray.shape, 255, np.uint8)
    hull = cv2.convexHull((project(corners_cam, intrinsics) * factor).astype(np.int32))
    cv2.fillConvexPoly(mask, hull, 0)
    mask = cv2.erode(mask, np.ones((2 * SHEET_MARGIN_PX + 1, 2 * SHEET_MARGIN_PX + 1), np.uint8))
    corners_cam = np.asarray(corners_cam, float)
    return Reference(corners_cam, apply(transform, corners_cam), gray, mask, np.asarray(transform, float),
                     time.strftime("%Y-%m-%d %H:%M:%S"))


# ---- one look --------------------------------------------------------------------------------------------------
@dataclass
class Check:
    status: str                        # "ok", "camera_moved", "sheet_moved", "mixed" or "unknown"
    why: str = ""
    misfit_mm: Optional[float] = None  # the corners, through the calibration in use, from where they belong (mean)
    move_mm: Optional[float] = None    # how far the correction this look asks for moves them (the most)
    turn_deg: Optional[float] = None   # ...and turns
    background_px: Optional[float] = None   # how far the background moved at the sheet, in the picture
    sheet_px: Optional[float] = None        # how far the sheet moved in the picture
    off_px: Optional[float] = None          # the sheet from where the background's move puts it
    matches: int = 0
    measured_robot: Optional[np.ndarray] = None   # 4 x 3: the corners through the calibration in use
    when: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))

    def record(self) -> dict:
        out = {k: (round(v, 3) if isinstance(v, float) else v) for k, v in asdict(self).items()
               if k != "measured_robot"}
        return out


def measure(rgb: np.ndarray, corners_cam: Optional[np.ndarray], intrinsics, transform: np.ndarray,
            reference: Reference, not_found: str = "the sheet isn't seen whole") -> Check:
    """One look: the sheet's corners now (camera coordinates, from the picture; None if not found) through the
    calibration in use, against where they belong; and, when they are off, which moved: the camera or the sheet."""
    if corners_cam is None:
        return Check("unknown", not_found)
    cam = np.asarray(corners_cam, float)
    cam = cam[match_corners(apply(transform, cam), reference.corners_robot)]
    measured = apply(transform, cam)
    misfit = float(np.linalg.norm(measured - reference.corners_robot, axis=1).mean())
    d, _ = solve_rigid_transform(measured, reference.corners_robot)
    move = float(np.linalg.norm(apply(d, measured) - measured, axis=1).max())
    turn = turn_deg(d[:3, :3])
    check = Check("ok", misfit_mm=misfit, move_mm=move, turn_deg=turn, measured_robot=measured)
    if misfit < NOISE_MM and turn < NOISE_DEG:
        check.why = "the sheet is where it belongs"
        return check
    found = picture_affine(reference.gray, _shrunk_gray(rgb), reference.mask)
    if found is None:
        check.status, check.why = "unknown", "the background has too few features to tell a moved camera from a moved sheet"
        return check
    matrix, check.matches = found
    factor = REFERENCE_WIDTH / rgb.shape[1]
    before = project(reference.corners_cam, intrinsics) * factor
    now = project(cam, intrinsics) * factor
    where_background_says = (matrix @ np.hstack([before, np.ones((4, 1))]).T).T
    check.background_px = float(np.linalg.norm(where_background_says - before, axis=1).mean() / factor)
    check.sheet_px = float(np.linalg.norm(now - before, axis=1).mean() / factor)
    check.off_px = float(np.linalg.norm(now - where_background_says, axis=1).mean() / factor)
    if check.sheet_px < STILL_PX and check.background_px < STILL_PX:
        if misfit < 2.0 * NOISE_MM:            # (a corner's depth is a little noisy: nothing slid, nothing to do)
            check.status, check.why = "ok", "the picture is still; the sheet within the noise"
            return check
        # nothing slid in the picture, yet the corners measure elsewhere: the camera's distances (its depth) drifted
        check.status, check.why = "camera_moved", "the picture is still but the sheet measures elsewhere (the depth)"
    elif check.off_px <= max(CAMERA_AGREES_PX, 0.35 * check.sheet_px):
        check.status, check.why = "camera_moved", "the background moved with the sheet: the camera moved"
    elif check.background_px < STILL_PX:
        check.status, check.why = "sheet_moved", "the sheet moved, the background didn't"
    else:
        check.status, check.why = "mixed", "the background and the sheet moved differently"
    return check


# ---- the running score and the corrections ------------------------------------------------------------------------
@dataclass
class Decision:
    action: str                        # "wait", "ok", "warn", "correct", "keep", "revert", "stop"
    text: str
    transform: Optional[np.ndarray] = None   # correct / revert: the calibration to use now
    record: dict = field(default_factory=dict)


class Tracker:
    """The running score over the looks, and the corrections it makes. `transform`: the calibration in use (which may
    already carry corrections: after a restart of the app)."""

    def __init__(self, reference: Reference, transform: np.ndarray):
        self.reference = reference
        self.transform = np.asarray(transform, float)
        self.last_good = self.transform.copy()
        self.window: list[Check] = []
        self.pending: Optional[dict] = None
        self.corrections = 0
        self.reverted = 0
        self.reverts_in_row = 0
        self.stopped: Optional[str] = None
        self.last: Optional[Check] = None

    def total(self, transform: Optional[np.ndarray] = None) -> tuple[float, float]:
        """How far the calibration in use (or `transform`) is from the one it started from: (mm, degrees)."""
        return change(self.transform if transform is None else transform, self.reference.start_transform,
                      self.reference.corners_cam)

    def add(self, check: Check) -> Decision:
        self.last = check
        if self.stopped:
            return Decision("wait", self.stopped)
        if check.status == "unknown":
            return Decision("wait", f"waiting for a clear view: {check.why}")
        if self.pending is not None:
            return self._verify(check)
        self.window = (self.window + [check])[-WINDOW:]
        if len(self.window) < MIN_AGREE:
            return Decision("wait", f"looking ({len(self.window)} of {MIN_AGREE} looks)")
        counts = {s: sum(1 for c in self.window if c.status == s) for s in ("ok", "camera_moved", "sheet_moved", "mixed")}
        misfit = float(np.median([c.misfit_mm for c in self.window]))
        if counts["ok"] >= MIN_AGREE:
            return Decision("ok", f"right: the sheet within {misfit:.1f} mm of where it belongs")
        if counts["sheet_moved"] >= MIN_AGREE:
            return Decision("warn", f"the sheet has moved ({misfit:.1f} mm), the camera hasn't: put the sheet back where "
                                    "it was, or press the watcher's Find the paper (between sessions). Nothing corrected.")
        if counts["camera_moved"] >= MIN_AGREE:
            return self._correct([c for c in self.window if c.status == "camera_moved"])
        if counts["mixed"] >= MIN_AGREE:
            return Decision("warn", "the sheet and the background moved differently: check the sheet is where it was "
                                    "and the camera is tight. Nothing corrected.")
        return Decision("wait", f"looking (the looks don't agree yet; the sheet {misfit:.1f} mm off)")

    def _correct(self, moved: list[Check]) -> Decision:
        stack = np.stack([c.measured_robot for c in moved])
        spread = float(np.linalg.norm(stack - stack.mean(axis=0), axis=2).max())
        if spread > SPREAD_MM:
            return Decision("wait", f"the camera seems to be moving still (looks {spread:.1f} mm apart): waiting until "
                                    "it settles")
        measured = stack.mean(axis=0)
        d, _ = solve_rigid_transform(measured, self.reference.corners_robot)
        step = limited(d, measured)
        new = step @ self.transform
        total_mm, total_deg = self.total(new)
        if total_mm > TOTAL_MM or total_deg > TOTAL_DEG:
            self.stopped = (f"stopped: the camera has moved {total_mm:.1f} mm / {total_deg:.1f}° from where it was "
                            "calibrated -- that's a knock, not a drift. Calibrate again with the cube.")
            return Decision("stop", self.stopped)
        before = float(np.median([c.misfit_mm for c in moved]))
        moved_mm = float(np.linalg.norm(apply(step, measured) - measured, axis=1).max())
        self.pending = {"before": before, "previous": self.transform.copy(), "misfits": []}
        self.transform = new
        self.window = []
        self.corrections += 1
        return Decision("correct", f"the camera moved: corrected by {moved_mm:.1f} mm / {turn_deg(step[:3, :3]):.2f}° "
                                   f"(the sheet was {before:.1f} mm off; {total_mm:.1f} mm from the start in all). "
                                   "Checking it...", new.copy(),
                        {"before_mm": round(before, 3), "step_mm": round(moved_mm, 3),
                         "step_deg": round(turn_deg(step[:3, :3]), 4), "total_mm": round(total_mm, 3),
                         "total_deg": round(total_deg, 4)})

    def _verify(self, check: Check) -> Decision:
        pending = self.pending
        pending["misfits"].append(check.misfit_mm)
        if len(pending["misfits"]) < VERIFY_CHECKS:
            return Decision("wait", f"checking the correction ({len(pending['misfits'])} of {VERIFY_CHECKS} looks)")
        after = float(np.median(pending["misfits"]))
        self.pending = None
        if after < NOISE_MM or after <= pending["before"] - IMPROVED_MM:
            self.last_good = self.transform.copy()
            self.reverts_in_row = 0
            return Decision("keep", f"kept the correction: the sheet now {after:.1f} mm off (was {pending['before']:.1f})",
                            record={"before_mm": round(pending["before"], 3), "after_mm": round(after, 3)})
        self.transform = self.last_good.copy()
        self.reverted += 1
        self.reverts_in_row += 1
        self.corrections = max(0, self.corrections - 1)
        text = (f"went back to the last good calibration: the correction didn't help (the sheet {after:.1f} mm off "
                f"after it, {pending['before']:.1f} before)")
        if self.reverts_in_row >= MAX_REVERTS:
            # (the same correction would only be tried and undone again and again: what moved, a turn and shift of
            # the camera can't put right)
            self.stopped = (f"stopped: {self.reverts_in_row} corrections in a row didn't help -- what changed isn't a "
                            "small move of the camera. Calibrate again with the cube.")
            text += ". " + self.stopped
        return Decision("revert", text, self.transform.copy(),
                        {"before_mm": round(pending["before"], 3), "after_mm": round(after, 3)})


# ---- where the sheet's corners come from ---------------------------------------------------------------------------
def real_corners(frame, intrinsics, transform: np.ndarray) -> tuple[Optional[np.ndarray], str]:
    """The real camera: the sheet found in the picture (paper.find_paper; its A4 check uses the calibration only for
    the size, which a small move doesn't change). (corners in camera coordinates or None, why not)."""
    from app.vision.paper import find_paper
    found = find_paper(frame.rgb, frame.depth, intrinsics, transform)
    if found.pose is None or found.corners_cam is None:
        return None, f"the sheet isn't found ({found.reason})"
    return found.corners_cam, ""


def twin_corners(camera, table_z: float = 0.0, noise_mm: float = 0.2,
                 rng: Optional[np.random.Generator] = None) -> tuple[Optional[np.ndarray], str]:
    """The demo: the twin draws the sheet in the 3D view but not in its camera's pictures, so its corners are worked
    out from where the simulated camera really is (it knows, even bumped), with a little noise as a real look has."""
    from app.vision.paper import DESIGNED
    exact = getattr(camera, "camera_to_robot_transform", None)
    if exact is None:
        return None, "this camera can't say where the sheet is"
    robot = np.array([[x, y, table_z] for x, y in DESIGNED.corners()], float)
    cam = apply(np.linalg.inv(exact()), robot)
    rng = rng or np.random.default_rng()
    return cam + rng.normal(0.0, noise_mm, cam.shape), ""


# ---- state kept between runs of the app ----------------------------------------------------------------------------
def load_state(calibration_file) -> dict:
    try:
        return json.loads(state_file(calibration_file).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_state(calibration_file, state: dict) -> None:
    from app.fileutil import atomic_write_text
    atomic_write_text(state_file(calibration_file), json.dumps(state, indent=1))


def append_log(calibration_file, entry: dict) -> None:
    try:
        with open(log_file(calibration_file), "a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry) + "\n")
    except OSError:
        pass


REFERENCE_LOOKS = 5        # the start: the sheet's corners averaged over this many pictures (one picture's noise
                           # would otherwise stay in every look after)


def start_reference(camera, transform: np.ndarray,
                    corners: Callable[[object, object, np.ndarray], tuple[Optional[np.ndarray], str]],
                    looks: int = REFERENCE_LOOKS) -> Reference:
    """The reference from a few pictures (for a worker thread): the corners averaged, each matched to the first's."""
    intrinsics = camera.get_intrinsics()
    first_rgb, found, why = None, [], ""
    for _ in range(max(1, looks)):
        frame = camera.get_frame()
        cam, why = corners(frame, intrinsics, transform)
        if cam is None:
            continue
        cam = np.asarray(cam, float)
        if found:
            cam = cam[match_corners(cam, found[0])]
        else:
            first_rgb = frame.rgb
        found.append(cam)
    if len(found) < max(1, (looks + 1) // 2):
        raise RuntimeError(why or "the sheet isn't seen whole")
    return make_reference(first_rgb, np.mean(found, axis=0), intrinsics, transform)


def run_check(camera, transform: np.ndarray, reference: Reference,
              corners: Callable[[object, object, np.ndarray], tuple[Optional[np.ndarray], str]]) -> Check:
    """One look with the camera (for a worker thread): a picture, the sheet's corners in it, measured."""
    frame = camera.get_frame()
    intrinsics = camera.get_intrinsics()
    found, why = corners(frame, intrinsics, transform)
    return measure(frame.rgb, found, intrinsics, transform, reference, not_found=why or "the sheet isn't seen whole")

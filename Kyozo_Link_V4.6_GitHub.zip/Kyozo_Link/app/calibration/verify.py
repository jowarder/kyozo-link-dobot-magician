"""Checking a calibration by sending the tool tip somewhere and seeing where the camera says it is.

For each of a few spots the arm moves there, and the camera finds the tool tip by itself: it
compares a picture with the arm at the spot against one with the arm out of the way, and the
lowest point of what changed (and is nearer the camera) is the tip. The calibration also
predicts where the tip should appear. The gap between the two, turned into millimetres across
the camera's view, is the calibration's real error -- measured, not estimated.

It checks sideways error and, through the tip's height, whether the table-height step was done
(if it wasn't, the predicted tip lands well away from the real one).
"""
from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import cv2
import numpy as np

from app.calibration.guidance import build_cells
from app.hardware.interfaces import Intrinsics, Pose
from app.vision.table import median_depth

logger = logging.getLogger(__name__)

NEARER_MM = 15.0            # a pixel belongs to the arm if it is this much nearer than with the arm away
MIN_ARM_PIXELS = 150
DEFAULT_TOOL_RADIUS_MM = 6.0
TIP_CLEARANCE_MM = 45.0     # how far above the table the tip is held: clear of it, and easy to see
AWAY_CLEARANCE_MM = 120.0
GOOD_MM, USABLE_MM = 1.5, 3.0   # typical error: a 20 mm cube in a gripper opening ~27 mm has ~3 mm to spare a side
LEAN_MM = 0.8               # misses that lean one way by this much on average: the calibration is shifted


@dataclass
class PointCheck:
    target: tuple[float, float, float]
    predicted_px: tuple[float, float]
    found_px: Optional[tuple[float, float]] = None
    error_px: Optional[float] = None
    error_mm: Optional[float] = None
    offset_mm: Optional[tuple[float, float]] = None   # where the camera found it minus where it should be (robot x, y)
    note: str = ""


@dataclass
class VerifyResult:
    points: list[PointCheck] = field(default_factory=list)

    @property
    def errors_mm(self) -> list[float]:
        return [p.error_mm for p in self.points if p.error_mm is not None]

    @property
    def typical_mm(self) -> Optional[float]:
        return float(np.median(self.errors_mm)) if self.errors_mm else None

    @property
    def worst_mm(self) -> Optional[float]:
        return float(max(self.errors_mm)) if self.errors_mm else None

    @property
    def lean_mm(self) -> Optional[tuple[float, float]]:
        """The average miss (robot x, y): the same everywhere means the calibration is shifted (or tilted, on a
        sloping table), rather than just noisy."""
        offsets = [p.offset_mm for p in self.points if p.offset_mm is not None]
        if len(offsets) < 3:
            return None
        return tuple(float(v) for v in np.mean(offsets, axis=0))

    @property
    def scatter_mm(self) -> Optional[float]:
        """How far the misses typically are from the average miss: the noise, with the lean taken out."""
        lean = self.lean_mm
        if lean is None:
            return None
        return float(np.median([math.dist(p.offset_mm, lean) for p in self.points if p.offset_mm is not None]))

    @property
    def lean_text(self) -> str:
        lean = self.lean_mm
        if lean is None or math.hypot(*lean) < LEAN_MM:
            return ""
        dx, dy = lean
        return (f"The misses lean one way: on average {abs(dx):.1f} mm towards {'+' if dx >= 0 else '-'}x and "
                f"{abs(dy):.1f} mm towards {'+' if dy >= 0 else '-'}y (scatter around that {self.scatter_mm:.1f} mm). "
                "A lean is a shifted or tilted calibration, not noise: calibrating with a cube removes it.")

    @property
    def verdict(self) -> str:
        typical = self.typical_mm
        if typical is None:
            return "Could not find the tool tip in the pictures, so nothing could be checked."
        if len(self.errors_mm) < max(2, len(self.points) // 2):
            return "The tool tip was found at too few spots to judge the calibration."
        if typical < GOOD_MM:
            return "Good: the camera and the robot agree."
        if typical < USABLE_MM:
            return "Usable, but a fresh calibration with more points would be better."
        return "Poor: the camera and the robot disagree. Recalibrate (and do the table-height step)."

    def as_dict(self) -> dict:
        return {"typical_mm": self.typical_mm, "worst_mm": self.worst_mm, "verdict": self.verdict,
                "lean_mm": self.lean_mm, "scatter_mm": self.scatter_mm,
                "points": [{"target": list(p.target), "predicted_px": list(p.predicted_px),
                            "found_px": None if p.found_px is None else list(p.found_px),
                            "error_px": p.error_px, "error_mm": p.error_mm,
                            "offset_mm": None if p.offset_mm is None else list(p.offset_mm), "note": p.note}
                           for p in self.points]}


# ---- geometry ------------------------------------------------------------------------------------------
def predicted_tip_pixel(transform: np.ndarray, tip_xyz, intrinsics: Intrinsics,
                        tool_radius_mm: float = DEFAULT_TOOL_RADIUS_MM) -> tuple[float, float]:
    """Where the lowest edge of the tool's flat end should appear in the picture, according to
    the calibration. (The lowest point of the silhouette is what can be found in a picture.)"""
    inverse = np.linalg.inv(transform)
    lowest = None
    for angle in np.linspace(0, 2 * math.pi, 36, endpoint=False):
        point = np.array([tip_xyz[0] + tool_radius_mm * math.cos(angle),
                          tip_xyz[1] + tool_radius_mm * math.sin(angle), tip_xyz[2], 1.0])
        q = inverse @ point
        u = intrinsics.fx * q[0] / q[2] + intrinsics.cx
        v = intrinsics.fy * q[1] / q[2] + intrinsics.cy
        if lowest is None or v > lowest[1]:
            lowest = (u, v)
    return lowest


def find_tip(depth_here: np.ndarray, depth_away: np.ndarray) -> Optional[tuple[float, float, float]]:
    """(u, v, depth) of the tool tip: the lowest point of what is nearer with the arm here than
    with it away. None if the arm can't be made out."""
    both = (depth_here > 0) & (depth_away > 0)
    arm = (both & ((depth_away - depth_here) > NEARER_MM)).astype(np.uint8)
    arm = cv2.morphologyEx(arm, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    arm = cv2.morphologyEx(arm, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(arm)
    if count < 2:
        return None
    biggest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    if stats[biggest, cv2.CC_STAT_AREA] < MIN_ARM_PIXELS:
        return None
    rows, cols = np.nonzero(labels == biggest)
    bottom = rows.max()
    near_bottom = rows >= bottom - 2
    u, v = float(cols[near_bottom].mean()), float(bottom)
    patch = depth_here[max(0, int(v) - 6):int(v) - 1, max(0, int(u) - 3):int(u) + 4]
    valid = patch[patch > 0]
    return u, v, float(np.median(valid)) if valid.size else float(depth_here[int(v), int(u)])


# ---- choosing where to look --------------------------------------------------------------------------------
def choose_targets(bounds: dict, reach_mm: float, table_z: float, count: int = 5) -> list[tuple[float, float, float]]:
    """Spots spread over the reachable workspace, the tip held clear above the table."""
    usable = [c for c in build_cells(bounds, reach_mm) if c.usable]
    if not usable:
        return []
    centres = [c.centre for c in usable]
    chosen = [min(centres, key=lambda p: math.hypot(p[0] - 200, p[1]))]   # start near the middle
    while len(chosen) < min(count, len(centres)):   # then keep adding the spot farthest from those chosen
        chosen.append(max((p for p in centres if p not in chosen),
                          key=lambda p: min(math.dist(p, q) for q in chosen)))
    z_lo, z_hi = bounds["z"]
    z = min(max(table_z + TIP_CLEARANCE_MM, z_lo + 1.0), z_hi)
    return [(x, y, z) for x, y in chosen]


def away_poses(bounds: dict, reach_mm: float, table_z: float) -> list[Pose]:
    """Two places to park the arm out of the way: high, at either side of the workspace."""
    z = min(table_z + AWAY_CLEARANCE_MM, bounds["z"][1])
    y = min(0.75 * reach_mm, bounds["y"][1] - 5.0)
    x = max(bounds["x"][0], 110.0)
    return [Pose(x, -y, z), Pose(x, y, z)]


# ---- running it ----------------------------------------------------------------------------------------------
def run_verification(robot, camera, transform: np.ndarray, targets: list[tuple[float, float, float]],
                     away: list[Pose], tool_radius_mm: float = DEFAULT_TOOL_RADIUS_MM, settle_s: float = 0.4,
                     frames: int = 3, on_progress: Optional[Callable[[str], None]] = None,
                     cancel: Optional[Callable[[], bool]] = None) -> VerifyResult:
    """Moves the arm. Call from a worker thread."""
    say = on_progress or (lambda message: None)
    intrinsics = camera.get_intrinsics()
    result = VerifyResult()

    def settled_depth() -> np.ndarray:
        time.sleep(settle_s)
        return median_depth(camera, frames)[0]

    backgrounds = []
    for index, pose in enumerate(away):
        say(f"Looking at the empty workspace ({index + 1} of {len(away)})...")
        robot.move_to(pose)
        backgrounds.append(settled_depth())
    for index, target in enumerate(targets):
        if cancel is not None and cancel():
            break
        say(f"Checking spot {index + 1} of {len(targets)}...")
        far = max(range(len(away)), key=lambda i: math.hypot(away[i].x - target[0], away[i].y - target[1]))
        robot.move_to(Pose(x=target[0], y=target[1], z=target[2]))
        here = settled_depth()
        pose = robot.get_pose()
        tip = (pose.x, pose.y, pose.z)
        predicted = predicted_tip_pixel(transform, tip, intrinsics, tool_radius_mm)
        check = PointCheck(target=tip, predicted_px=predicted)
        found = find_tip(here, backgrounds[far])
        if found is None:
            check.note = "the tool tip could not be found in the picture"
        else:
            u, v, depth = found
            check.found_px = (u, v)
            check.error_px = math.hypot(u - predicted[0], v - predicted[1])
            check.error_mm = check.error_px * depth / intrinsics.fx
            # the same miss in the robot's directions (the camera's sideways step, turned as the calibration has it)
            step = np.array([(u - predicted[0]) * depth / intrinsics.fx, (v - predicted[1]) * depth / intrinsics.fy, 0.0])
            turned = np.asarray(transform, float)[:3, :3] @ step
            check.offset_mm = (float(turned[0]), float(turned[1]))
        result.points.append(check)
    robot.move_to(away[0])
    return result

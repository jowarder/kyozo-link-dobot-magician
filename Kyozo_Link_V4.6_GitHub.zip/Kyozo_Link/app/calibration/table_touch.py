"""Removing the tool-offset height error from a calibration, using the table itself.

A calibration made by clicking (or by a marker) on a spot above the tool tip learns where
that spot is, not where the tip is: every height the camera reports comes out too low by the
distance from the tip to the spot. With the tip touching the table, the robot's own z is the
true table height; the difference from where the camera puts the table is that distance.
"""
from __future__ import annotations

import numpy as np

# More than this is not a tool offset: the tip is probably not at the table. The largest real one
# is a marker on top of the tool head with the gripper fitted: the head's top is 45 mm above the wrist
# and the fingertips 105 mm below it, about 150 mm apart (it was 120 here, which wrongly refused that).
MAX_HEIGHT_CORRECTION_MM = 180.0


class TableTouchRefused(RuntimeError):
    """The numbers don't look like a tip touching the table; nothing was changed."""


def apply_table_touch(transform: np.ndarray, z_touch: float, camera_table_z: float) -> tuple[np.ndarray, float]:
    """Returns (corrected transform, correction in mm). `z_touch` is the robot's z with the tip
    on the table; `camera_table_z` is where the camera, through `transform`, puts the table."""
    correction = z_touch - camera_table_z
    if abs(correction) > MAX_HEIGHT_CORRECTION_MM:
        raise TableTouchRefused(
            f"the tip is at z = {z_touch:.0f} mm but the camera puts the table at z = {camera_table_z:.0f} mm, "
            f"a gap of {abs(correction):.0f} mm -- too big to be just the spot you clicked on the tool")
    corrected = transform.copy()
    corrected[2, 3] += correction
    return corrected, correction

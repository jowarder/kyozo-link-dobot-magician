"""Where the calibration points are, and what to do next.

Simulation showed the *sideways spread* of the points and their number matter for accuracy,
and the height they were taken at barely does. So guidance is a top-down grid over the
workspace: a cell with no point in it is somewhere the calibration hasn't been taught.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from app.calibration.boardless import MIN_POINTS, RECOMMENDED_POINTS

ROWS, COLS = 3, 4   # rows run away from the robot (x), columns run across (y)
MIN_X_MM = 100.0    # closer than this to the base the arm barely fits, so don't ask for points there
MIN_RADIUS_MM = 160.0  # nearer the base than this the arm can't reach down to the table (alarm 0x22 territory)


def min_radius_mm() -> float:
    """MIN_RADIUS_MM for the robot this run drives (the Dobot's is MIN_RADIUS_MM)."""
    from app import robots
    return robots.active().min_radius_mm


@dataclass
class Cell:
    row: int
    col: int
    x0: float
    x1: float
    y0: float
    y1: float
    usable: bool   # inside the safe bounds and within reach

    def contains(self, x: float, y: float) -> bool:
        return self.x0 <= x < self.x1 and self.y0 <= y < self.y1

    @property
    def centre(self) -> tuple[float, float]:
        return (self.x0 + self.x1) / 2, (self.y0 + self.y1) / 2


def workspace_region(bounds: dict, reach_mm: float) -> tuple[float, float, float, float]:
    x0 = max(bounds["x"][0], MIN_X_MM)
    x1 = min(bounds["x"][1], reach_mm)
    y_limit = reach_mm * 0.9
    y0 = max(bounds["y"][0], -y_limit)
    y1 = min(bounds["y"][1], y_limit)
    return x0, x1, y0, y1


def build_cells(bounds: dict, reach_mm: float) -> list[Cell]:
    x0, x1, y0, y1 = workspace_region(bounds, reach_mm)
    if x1 <= x0 or y1 <= y0:
        return []
    cells = []
    for row in range(ROWS):
        for col in range(COLS):
            cx0 = x0 + (x1 - x0) * row / ROWS
            cx1 = x0 + (x1 - x0) * (row + 1) / ROWS
            cy0 = y0 + (y1 - y0) * col / COLS
            cy1 = y0 + (y1 - y0) * (col + 1) / COLS
            centre_x, centre_y = (cx0 + cx1) / 2, (cy0 + cy1) / 2
            cells.append(Cell(row, col, cx0, cx1, cy0, cy1, usable=min_radius_mm() <= math.hypot(centre_x, centre_y) <= reach_mm))
    return cells


def covered_cells(cells: list[Cell], points_xy: list[tuple[float, float]]) -> set[tuple[int, int]]:
    return {(c.row, c.col) for c in cells if any(c.contains(x, y) for x, y in points_xy)}


def advice(n_points: int, cells: list[Cell], points_xy: list[tuple[float, float]],
           suspects: list[int] | None = None) -> str:
    usable = [c for c in cells if c.usable]
    covered = covered_cells(usable, points_xy)
    if n_points < MIN_POINTS:
        return f"Add {MIN_POINTS - n_points} more point(s): {MIN_POINTS} is the minimum."
    if suspects:
        listed = ", ".join(f"#{i + 1}" for i in suspects)
        return (f"Point {listed} disagrees with the others and may be a mis-click. "
                "Use 'Remove worst point', then Solve again.")
    if usable and len(covered) < max(3, len(usable) // 2):
        return ("The points are bunched together. Teach some in the empty (amber) areas -- "
                "sideways spread matters most; the height barely does.")
    if n_points < RECOMMENDED_POINTS:
        return (f"Good spread. Add {RECOMMENDED_POINTS - n_points} more for a reliable result "
                f"({RECOMMENDED_POINTS} to 12 is the sweet spot).")
    return "Enough well-spread points. Press Solve."

"""A gentle correction over the table, for what one rigid camera->robot transform can't follow.

After the best rigid fit, the misses that are left often follow a pattern rather than scatter: the arm's own error
grows towards the edge of its reach (the Dobot's especially), and a lens bends the picture's corners. A quadratic in
x and y (six numbers for each of x and y) follows such a bow without being able to chase single points; it is kept
only when each spot, predicted from the others, comes out clearly better with it (see cube.py).

Applied where camera points become robot points for objects (SceneBuilder) and for a click (main window): x and y
move by the correction at that spot; z is left alone.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

SCALE_MM = 100.0      # x and y are measured from the middle of the spots in this unit, so the numbers stay small
MAX_SHIFT_MM = 3.0    # never moves a point further than this (outside the spots' area a quadratic can run away)


def _terms(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    return np.stack([np.ones_like(x), x, y, x * x, x * y, y * y], axis=1)


@dataclass
class XYCorrection:
    centre: tuple[float, float]
    cx: tuple[float, ...]          # six numbers each: 1, x, y, x^2, xy, y^2 (x, y in SCALE_MM from the centre)
    cy: tuple[float, ...]

    @classmethod
    def fit(cls, xy: np.ndarray, residuals: np.ndarray) -> "XYCorrection":
        """The quadratic through `residuals` (truth minus prediction, N x 2) at robot points `xy` (N x 2)."""
        xy = np.asarray(xy, float)
        centre = xy.mean(axis=0)
        a = _terms((xy[:, 0] - centre[0]) / SCALE_MM, (xy[:, 1] - centre[1]) / SCALE_MM)
        # a little ridge: with ~20 points, six numbers each is well determined, but keep the high terms tame
        ridge = np.diag([0.0, 1e-3, 1e-3, 1e-2, 1e-2, 1e-2])
        lhs = a.T @ a + ridge * len(xy)
        coeffs = np.linalg.solve(lhs, a.T @ np.asarray(residuals, float))
        return cls(centre=(float(centre[0]), float(centre[1])), cx=tuple(float(v) for v in coeffs[:, 0]),
                   cy=tuple(float(v) for v in coeffs[:, 1]))

    def shift(self, x, y) -> tuple[np.ndarray, np.ndarray]:
        x, y = np.asarray(x, float), np.asarray(y, float)
        t = _terms(np.atleast_1d((x - self.centre[0]) / SCALE_MM), np.atleast_1d((y - self.centre[1]) / SCALE_MM))
        dx, dy = t @ np.array(self.cx), t @ np.array(self.cy)
        length = np.hypot(dx, dy)
        cap = np.where(length > MAX_SHIFT_MM, MAX_SHIFT_MM / np.maximum(length, 1e-9), 1.0)
        return (dx * cap).reshape(np.shape(x)), (dy * cap).reshape(np.shape(y))

    def apply(self, x: float, y: float) -> tuple[float, float]:
        dx, dy = self.shift(x, y)
        return float(x + dx), float(y + dy)

    def as_dict(self) -> dict:
        return {"centre": list(self.centre), "cx": list(self.cx), "cy": list(self.cy)}

    @classmethod
    def from_dict(cls, data: Optional[dict]) -> Optional["XYCorrection"]:
        if not data:
            return None
        try:
            return cls(centre=tuple(float(v) for v in data["centre"]), cx=tuple(float(v) for v in data["cx"]),
                       cy=tuple(float(v) for v in data["cy"]))
        except (KeyError, TypeError, ValueError):
            return None

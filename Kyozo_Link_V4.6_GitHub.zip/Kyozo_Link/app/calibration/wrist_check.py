"""After a cube calibration, with its cube still held: how the wrist really turns (the fingers angle check), and how
well picks line the fingers up with a cube (the rotation pick test).

The fingers angle check puts the held cube down with the wrist turned -40, -20, 0, +20 and +40 degrees from its
middle, at 2 or 3 places, coming to each angle once from below and once from above. The fingers squeeze the cube
square to them as they hold it, so as it is let go its sides lie along the fingers: the camera sees which way, and
that is where the wrist really was. hardware/wrist.py fits offset, gain, backlash and scatter to it.

The rotation pick test puts the cube down turned at random, finds it with the camera, picks it the way the robot
tools do (with the wrist correction, or without it to compare), then lets it go again without turning: how far the
cube turned between the two looks is how far the fingers were off when they closed on it.
"""
from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from app.calibration.cube import (AWAY_UP_MM, FRAMES, LIFT_MM, SETTLE_S, CubeOutcome, _Arm, _gripper_gap, _paced,
                                  _safe_up, _Stopped, _take_back, _use_offset, _whole, _wrap90, away_poses_for,
                                  holding_after, find_new_object, predict, project, refusal_text)
from app.hardware.interfaces import Pose, RobotStopped
from app.hardware.wrist import WristCorrected, WristModel, approach_from_side, fit_wrist, slow_move

logger = logging.getLogger(__name__)

TURNS_DEG = (-40.0, -20.0, 0.0, 20.0, 40.0)   # the wrist's angle from its middle at each put-down
APPROACH_DEG = 12.0          # each angle is come to from this far below it, or above
SPOTS = 2                    # places on the table (each gets every angle, from both sides)
TEST_ROUNDS = 6
TEST_TURN_DEG = 40.0         # the rotation pick test turns the cube up to this far either way
OVERSHOOT_DEG = 4.0          # picks: the wrist comes to its angle from this far below
SLOW_LAST_MM = 15.0          # picks: the last this-many mm down to the cube...
SLOW_SPEED_MM_S = 20.0       # ...at this speed


@dataclass
class FingersCheckOutcome:
    points: list = field(default_factory=list)       # (wrist told, side, wrist real), degrees
    model: Optional[WristModel] = None
    spots: list = field(default_factory=list)        # the places used (x, y)
    skipped: list = field(default_factory=list)      # put-downs left out, in words
    reason: str = ""
    cancelled: bool = False


@dataclass
class RotationTestOutcome:
    corrected: bool = True
    errors_deg: list = field(default_factory=list)   # each round: how far the fingers were off the cube's sides
    sides: list = field(default_factory=list)        # ...and which way the wrist came to its angle (-1 below, +1 above)
    rounds: int = 0
    held: int = 0
    missed: int = 0
    reason: str = ""
    cancelled: bool = False

    @property
    def mean_deg(self) -> Optional[float]:
        return float(np.mean(np.abs(self.errors_deg))) if self.errors_deg else None

    @property
    def worst_deg(self) -> Optional[float]:
        return float(np.max(np.abs(self.errors_deg))) if self.errors_deg else None

    @property
    def spread_deg(self) -> Optional[float]:
        return float(np.std(self.errors_deg)) if len(self.errors_deg) > 1 else None

    def by_side(self) -> dict:
        """{side: mean error (signed), degrees} for each side the wrist came from."""
        out = {}
        for side in (-1, 1):
            errs = [e for e, s in zip(self.errors_deg, self.sides) if s == side]
            if errs:
                out[side] = float(np.mean(errs))
        return out

    def describe(self) -> str:
        if not self.errors_deg:
            return f"Rotation pick test ({'correction on' if self.corrected else 'correction off'}): " + (
                self.reason or "nothing measured.")
        sides = self.by_side()
        side_text = ", ".join(f"from {'below' if s < 0 else 'above'} {v:+.1f}°" for s, v in sorted(sides.items()))
        return (f"Rotation pick test ({'correction on' if self.corrected else 'correction off'}), {self.rounds} "
                f"rounds: the fingers were {self.mean_deg:.1f}° off the cube's sides on average, worst "
                f"{self.worst_deg:.1f}°" + (f", spread {self.spread_deg:.1f}°" if self.spread_deg is not None else "")
                + f"; held {self.held} of {self.rounds}" + (f", {self.missed} missed" if self.missed else "")
                + (f" ({side_text})" if side_text else "") + (f". {self.reason}" if self.reason else "."))


def jaw_in_use(phase1: CubeOutcome, gripper) -> float:
    """The fingers' angle at r = 0 the app plans with: the calibration's measurement, if it made one."""
    return float(phase1.jaw_axis_deg) if phase1.jaw_axis_deg is not None else float(gripper.jaw_axis_deg)


def _base(gripper, x: float, y: float) -> float:
    """r minus the wrist's own angle at (x, y): J1 for the Dobot, 0 for the xArm."""
    return 0.0 - gripper.wrist_turn(0.0, x, y)


def _cube_angle(phase1: CubeOutcome, sighting) -> Optional[float]:
    """Which way the cube's sides point, robot frame, degrees (a square: give or take a quarter turn)."""
    side = getattr(sighting, "side_dir", None)
    if side is None:
        return None
    d = np.asarray(phase1.transform, float)[:3, :3] @ np.asarray(side, float)
    return math.degrees(math.atan2(d[1], d[0]))


def _spots(phase1: CubeOutcome, gripper, count: int, turns, approach: float) -> list[tuple[float, float]]:
    """Places the calibration already used (in the camera's view, reachable) where the wrist can turn through every
    angle from both sides: the middlemost, then each as far from those as it can be."""
    used = [p.centre_xy(phase1.offset) for p in phase1.used]

    def fits(xy):
        base = _base(gripper, *xy)
        return all(gripper.wrist_fits(base + t + s * approach, *xy) for t in turns for s in (-1.0, 1.0))
    usable = [xy for xy in used if fits(xy)]
    if not usable:
        return []
    middle = np.mean(used, axis=0)
    chosen = [min(usable, key=lambda p: math.dist(p, middle))]
    while len(chosen) < min(count, len(usable)):
        chosen.append(max((p for p in usable if p not in chosen), key=lambda p: min(math.dist(p, q) for q in chosen)))
    return chosen


def _look_for_cube(arm: _Arm, phase1: CubeOutcome, x: float, y: float):
    hand = phase1.hand
    return find_new_object(arm.look().depth, phase1.background.depth, phase1.k, size_mm=phase1.cube_h,
                           expect_px=project(phase1.transform, phase1.k, (x, y, hand.table_z + phase1.cube_h)))


@_paced
def run_fingers_check(robot, camera, phase1: CubeOutcome, bounds: dict, reach_mm: float, gripper,
                      spots: int = SPOTS, turns=TURNS_DEG, approach_deg: float = APPROACH_DEG,
                      settle_s: float = SETTLE_S, frames: int = FRAMES,
                      on_progress: Optional[Callable[[str], None]] = None,
                      cancel: Optional[Callable[[], bool]] = None) -> FingersCheckOutcome:
    """After phase 1 (the cube held, the arm away): see the module's docstring. Ends holding the cube, the arm away."""
    say = on_progress or (lambda message: None)
    out = FingersCheckOutcome()
    if not phase1.holding or phase1.background is None or phase1.transform is None:
        out.reason = "the cube calibration has to have just finished, the cube still held."
        return out
    arm = _Arm(robot, camera, settle_s, frames, say, cancel, dz=phase1.table_dz)
    hand, jaw = phase1.hand, jaw_in_use(phase1, gripper)
    away = away_poses_for(bounds, reach_mm, phase1.grip_z + AWAY_UP_MM)[phase1.away_index]
    _use_offset(robot, phase1)
    out.spots = _spots(phase1, gripper, spots, turns, approach_deg)
    if not out.spots:
        out.reason = "no place the calibration used lets the wrist turn 40° both ways."
        return out
    total = len(out.spots) * len(turns) * 2
    done = 0
    spot = None
    try:
        for x, y in out.spots:
            base = _base(gripper, x, y)
            for told in turns:
                for side in (-1, 1):
                    arm.check()
                    done += 1
                    r = base + told
                    spot = (x, y)
                    say(f"Fingers angle check {done} of {total}: the wrist at {told:+.0f}°, coming from "
                        f"{'below' if side < 0 else 'above'}, at ({x:.0f}, {y:.0f})...")
                    here = robot.get_pose()
                    if here.z < hand.release_z() + LIFT_MM - 0.5:
                        arm.move(here.x, here.y, hand.release_z() + LIFT_MM, here.r)
                    arm.move(x, y, hand.release_z() + LIFT_MM, r + side * approach_deg)
                    arm.down_and(x, y, hand.release_z(), r, LIFT_MM, robot.open_gripper)   # (turns to r up there)
                    let_go = robot.get_pose()
                    phase1.holding, phase1.cube_at = False, (x, y)
                    arm.away(away)
                    sighting = _look_for_cube(arm, phase1, x, y)
                    angle = _cube_angle(phase1, sighting) if sighting is not None else None
                    # (each look in the log: what scatters -- the camera's reading of the cube's turn, how whole it
                    # was seen, or the wrist -- can then be told from a real run's numbers)
                    logger.info("Fingers angle check %d of %d: %s", done, total, {
                        "told": told, "side": "below" if side < 0 else "above", "xy": [round(x, 1), round(y, 1)],
                        "r_told": round(r, 2), "r_said": round(let_go.r, 2),
                        "cube_deg": None if angle is None else round(angle, 2),
                        "real": None if angle is None else round(told + _wrap90(angle - jaw - base - told), 2),
                        "size_mm": None if sighting is None else list(sighting.footprint_mm),
                        "lean_deg": None if sighting is None else round(sighting.tilt_deg, 1),
                        "top_points": None if sighting is None else sighting.top_points})
                    if sighting is None or angle is None or not _whole(sighting, phase1.cube_mm[0]):
                        out.skipped.append(f"{told:+.0f}° from {'below' if side < 0 else 'above'} at "
                                           f"({x:.0f}, {y:.0f}): the camera didn't see the cube whole")
                    else:
                        real = told + _wrap90(angle - jaw - base - told)
                        out.points.append((float(told), side, float(real)))
                    _take_back_from(arm, robot, gripper, x, y, hand.pick_z(), r, side, approach_deg)
                    hand.taken()
                    if not _holding(robot, arm, sighting, away):
                        out.reason = f"the cube wasn't taken back at ({x:.0f}, {y:.0f})."
                        phase1.holding, phase1.cube_at = False, (x, y)
                        arm.away(away)
                        break
                    phase1.holding, phase1.cube_at = True, None
                if out.reason:
                    break
            if out.reason:
                break
        arm.away(away)
    except _Stopped:
        out.cancelled = True
        return out
    except RobotStopped:
        raise
    except (RuntimeError, TimeoutError) as exc:      # a refused move or no answer: stop here, say where
        _refused(out, exc, arm, robot, phase1, spot)
        return out
    out.model = fit_wrist(out.points)
    m = out.model
    logger.info("Fingers angle check: %d looks, %d skipped; offset %+.2f deg, gain %.3f, backlash %.2f deg, scatter "
                "%.2f deg%s", len(out.points), len(out.skipped), m.offset_deg, m.gain, m.backlash_deg, m.scatter_deg,
                "" if m.trusted else " (not trusted: " + "; ".join(m.problems) + ")")
    out.model.cube_mm = float(phase1.cube_h) if phase1.cube_h else None
    out.model.depth_preset = getattr(camera, "depth_preset", None)
    out.model.jaw_axis_deg = jaw
    return out


def _take_back_from(arm: _Arm, robot, gripper, x: float, y: float, z: float, r: float, side: int,
                    overshoot_deg: float) -> None:
    """_take_back, the wrist coming to r from `side` as it did when the cube was let go: the gears' slack then lies
    the same way and the fingers come down where they let go. (Straight from the waiting place, half the time from
    the other side: a backlash's worth off, and a 25 mm cube in 27.5 mm fingers fits only about 4 degrees.)"""
    here = robot.get_pose()
    if here.z < z + LIFT_MM - 0.5:
        arm.move(here.x, here.y, z + LIFT_MM, here.r)
    before = r + side * overshoot_deg
    if overshoot_deg > 0.0 and gripper is not None and gripper.wrist_fits(before, x, y):
        arm.move(x, y, z + LIFT_MM, before)
    _take_back(arm, robot, x, y, z, r)


def _refused(out, exc: Exception, arm: _Arm, robot, phase1: CubeOutcome, spot) -> None:
    """A move refused (an alarm, out of reach, no answer) part-way: the reason said, the cube's whereabouts kept
    right -- held if the last thing done was closing on it -- and the arm up out of the way."""
    out.reason = refusal_text(exc)
    if arm.acted:
        phase1.holding = bool(arm.closed)
        phase1.cube_at = None if arm.closed else spot
    _safe_up(robot)


def _holding(robot, arm=None, sighting=None, away=None) -> bool:
    """Does the gripper hold the cube? On the real Dobot (no sensor) by looking: the cube still where it was is a miss
    (it used to count as held whatever happened, so a missed pick scored as a perfect one); where the gripper hides
    it, looked at again from `away`."""
    return holding_after(arm, robot, sighting, away) if arm is not None else (
        robot.held_object is not None if hasattr(robot, "held_object") else
        (_gripper_gap(robot) is None or _gripper_gap(robot) > 3.0))


@_paced
def run_rotation_test(robot, camera, phase1: CubeOutcome, bounds: dict, reach_mm: float, gripper,
                      model: Optional[WristModel] = None, corrected: bool = True, rounds: int = TEST_ROUNDS,
                      seed: Optional[int] = None, overshoot_deg: float = OVERSHOOT_DEG,
                      slow_last_mm: float = SLOW_LAST_MM, slow_speed: float = SLOW_SPEED_MM_S,
                      side: int = WristModel.APPROACH_SIDE, settle_s: float = SETTLE_S, frames: int = FRAMES,
                      on_progress: Optional[Callable[[str], None]] = None,
                      cancel: Optional[Callable[[], bool]] = None) -> RotationTestOutcome:
    """See the module's docstring. `corrected`: pick as the robot tools do now (the wrist model, coming to the angle
    from `side`, the last mm slowly); False: as before (the wrist straight to its angle, as it comes). Ends holding
    the cube, the arm away."""
    say = on_progress or (lambda message: None)
    out = RotationTestOutcome(corrected=corrected)
    if not phase1.holding or phase1.background is None or phase1.transform is None:
        out.reason = "the cube calibration has to have just finished, the cube still held."
        return out
    rng = random.Random(seed)
    arm = _Arm(robot, camera, settle_s, frames, say, cancel, dz=phase1.table_dz)
    hand, jaw = phase1.hand, jaw_in_use(phase1, gripper)
    away = away_poses_for(bounds, reach_mm, phase1.grip_z + AWAY_UP_MM)[phase1.away_index]
    _use_offset(robot, phase1)
    places = _spots(phase1, gripper, 4, (-45.0, 45.0), overshoot_deg)    # (a pick turns the wrist up to 45 degrees)
    if not places:
        out.reason = "no place the calibration used lets the wrist turn far enough."
        return out
    wrist = WristCorrected(robot, gripper, model if corrected else None, side=side)
    spot = None
    try:
        for index in range(rounds):
            arm.check()
            x, y = places[index % len(places)]
            spot = (x, y)
            base = _base(gripper, x, y)
            told = rng.uniform(-TEST_TURN_DEG, TEST_TURN_DEG)
            say(f"Rotation pick test {index + 1} of {rounds} ({'correction on' if corrected else 'correction off'}): "
                f"the cube down turned {told:+.0f}° at ({x:.0f}, {y:.0f})...")
            arm.down_and(x, y, hand.release_z(), base + told, LIFT_MM, robot.open_gripper)
            phase1.holding, phase1.cube_at = False, (x, y)
            arm.away(away)
            before = _look_for_cube(arm, phase1, x, y)
            a0 = _cube_angle(phase1, before) if before is not None else None
            if a0 is None or not _whole(before, phase1.cube_mm[0]):
                out.reason = f"round {index + 1}: the camera didn't see the cube whole."
                _take_back(arm, robot, x, y, hand.pick_z(), base + told)
                hand.taken()
                phase1.holding, phase1.cube_at = _holding(robot, arm, before, away), None
                break
            out.rounds += 1
            where = predict(phase1.transform, phase1.correction, before.cam_xyz)
            cx, cy = float(where[0]), float(where[1])
            spot = (cx, cy)
            # the fingers along the cube's sides, the wrist nearest its middle
            want = a0 - jaw
            want = base + _wrap90(want - base)
            say(f"Rotation pick test {index + 1}: picking it up turned to match it...")
            side = _pick(arm, robot, wrist, gripper, cx, cy, hand.pick_z(), want, corrected, overshoot_deg,
                         slow_last_mm, slow_speed)
            hand.taken()
            if not _holding(robot, arm, before, away):
                out.missed += 1
                say(f"Rotation pick test {index + 1}: the fingers missed it; taking it back...")
                robot.open_gripper()
                # again just as the pick came (corrected, from its side): straight to the uncorrected angle the
                # fingers were the mounting's and the slack's worth off -- past the ~4 degrees a 25 mm cube fits
                _pick(arm, robot, wrist, gripper, cx, cy, hand.pick_z(), want, corrected, overshoot_deg,
                      slow_last_mm, slow_speed)
                hand.taken()
                if not _holding(robot, arm, before, away):
                    out.reason = f"round {index + 1}: the cube couldn't be taken back; it is on the table."
                    phase1.holding, phase1.cube_at = False, (cx, cy)
                    arm.away(away)
                    return out
                phase1.holding, phase1.cube_at = True, None
                continue
            out.held += 1
            # let it go again where it was, the wrist not turned: it lies along the fingers now
            r_now = robot.get_pose().r
            arm.down_and(cx, cy, hand.release_z(), r_now, LIFT_MM, robot.open_gripper)
            phase1.holding, phase1.cube_at = False, (cx, cy)
            arm.away(away)
            after = _look_for_cube(arm, phase1, cx, cy)
            a1 = _cube_angle(phase1, after) if after is not None else None
            if a1 is not None:
                out.errors_deg.append(float(_wrap90(a1 - a0)))
                out.sides.append(side)
            _take_back_from(arm, robot, gripper, cx, cy, hand.pick_z(), r_now, side, overshoot_deg)
            hand.taken()
            if not _holding(robot, arm, after, away):
                out.reason = f"round {index + 1}: the cube wasn't taken back; it is on the table."
                phase1.holding, phase1.cube_at = False, (cx, cy)
                arm.away(away)
                return out
            phase1.holding, phase1.cube_at = True, None
        arm.away(away)
        return out
    except _Stopped:
        out.cancelled = True
        return out
    except RobotStopped:
        raise
    except (RuntimeError, TimeoutError) as exc:      # a refused move or no answer: stop here, say where
        _refused(out, exc, arm, robot, phase1, spot)
        return out


def _pick(arm: _Arm, robot, wrist: WristCorrected, gripper, x: float, y: float, z: float, r: float,
          corrected: bool, overshoot_deg: float, slow_last_mm: float, slow_speed: float) -> int:
    """Down round the cube at (x, y) with the fingers along r (ideal terms) and close: as the robot tools pick
    (`corrected`), or the wrist straight to its angle as before. Returns which side the wrist came to its angle
    from (-1 below, +1 above)."""
    dz = arm.dz(x, y) if arm.dz is not None else 0.0
    arm.acted = arm.closed = False
    here = robot.get_pose()
    if here.z < z + LIFT_MM + dz - 0.5:
        arm.move(here.x, here.y, z + LIFT_MM, here.r)
        here = robot.get_pose()
    arm.check()
    above = Pose(x, y, z + LIFT_MM + dz, r)
    if corrected:
        approach_from_side(wrist, above, gripper, overshoot_deg, wrist.side)
        side = wrist.side
        wrist.move_to(Pose(x, y, z + dz + slow_last_mm, r))
        arm.check()
        slow_move(wrist, Pose(x, y, z + dz, r), slow_speed)
    else:
        side = -1 if gripper.wrist_turn(r, x, y) > gripper.wrist_turn(here.r, here.x, here.y) else 1
        robot.move_to(above)
        robot.move_to(Pose(x, y, z + dz, r))
    arm.check()
    robot.close_gripper()
    arm.acted = arm.closed = True
    arm.move(x, y, z + LIFT_MM, robot.get_pose().r)
    return side

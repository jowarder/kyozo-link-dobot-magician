"""The printed marker used for automatic calibration: making it, and finding it in a picture.

An ArUco marker is a black-and-white square pattern that software can find and identify very
reliably, and locate to a fraction of a pixel. Stuck on the tool, it lets the robot calibrate
itself: it moves the marker around, the camera finds it each time, and the pairs of
(where the robot says it is, where the camera sees it) are what the solver needs.
"""
from __future__ import annotations

import math
import struct
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from app.hardware.interfaces import Intrinsics

DICTIONARY = cv2.aruco.DICT_4X4_50
MARKER_ID = 7
MARKER_SIZES_MM = (30.0, 40.0)   # the two sizes on the print sheet: pick by how far the camera is
QUIET_ZONE_MM = 5.0              # white border the detector needs around the black square
CELLS = 6                        # 4 x 4 data cells plus a black border cell all round
SHEET_DPI = 300

_MAX_SIZE_ERROR = (0.5, 1.8)     # a real marker's apparent size is within this factor of what depth predicts


def _dictionary():
    return cv2.aruco.getPredefinedDictionary(DICTIONARY)


def marker_cells(marker_id: int = MARKER_ID) -> np.ndarray:
    """The pattern as a 6 x 6 array of 0 (black) and 1 (white), top row first."""
    return (cv2.aruco.generateImageMarker(_dictionary(), marker_id, CELLS) > 0).astype(np.uint8)


# ---- the print sheet -------------------------------------------------------------------------------
def _png_with_dpi(png: bytes, dpi: int) -> bytes:
    """Add the physical-size chunk (pHYs) so print dialogs and image viewers know the true size."""
    per_metre = int(round(dpi / 0.0254))
    body = b"pHYs" + struct.pack(">IIB", per_metre, per_metre, 1)
    chunk = struct.pack(">I", 9) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)
    header_end = 8 + 4 + 4 + 13 + 4   # signature + length + "IHDR" + data + crc
    return png[:header_end] + chunk + png[header_end:]


def make_marker_sheet(path: str | Path) -> Path:
    """Write an A4 page (300 dpi) with the marker at 30 mm and 40 mm, cut lines, and a ruler bar
    to check the printer didn't resize the page."""
    mm = SHEET_DPI / 25.4
    width, height = int(210 * mm), int(297 * mm)
    page = np.full((height, width, 3), 255, np.uint8)
    black, grey = (0, 0, 0), (110, 110, 110)

    def text(message: str, x_mm: float, y_mm: float, scale: float = 1.4, thickness: int = 2, colour=black):
        cv2.putText(page, message, (int(x_mm * mm), int(y_mm * mm)), cv2.FONT_HERSHEY_SIMPLEX, scale, colour,
                    thickness, cv2.LINE_AA)

    text("Dobot calibration marker", 15, 22, 2.0, 3)
    text("PRINT AT 100% / ACTUAL SIZE. Do not choose 'fit to page'.", 15, 33, 1.15, 2)
    text("Check: the bar below must measure exactly 100 mm with a ruler.", 15, 41, 1.0, 2, grey)

    y = 60.0
    for size_mm in MARKER_SIZES_MM:
        side = CELLS * int(round(size_mm * mm / CELLS))   # whole pixels per cell, so the edges are sharp
        card = int(round(QUIET_ZONE_MM * mm))
        marker = cv2.resize(cv2.aruco.generateImageMarker(_dictionary(), MARKER_ID, side, 1), (side, side),
                            interpolation=cv2.INTER_NEAREST)
        x0, y0 = int(15 * mm), int(y * mm)
        page[y0 + card:y0 + card + side, x0 + card:x0 + card + side] = marker[:, :, None]
        outer = side + 2 * card
        for offset in range(0, outer, 24):   # dashed cut line around the card
            cv2.line(page, (x0 + offset, y0), (x0 + min(offset + 12, outer), y0), grey, 2)
            cv2.line(page, (x0 + offset, y0 + outer), (x0 + min(offset + 12, outer), y0 + outer), grey, 2)
            cv2.line(page, (x0, y0 + offset), (x0, y0 + min(offset + 12, outer)), grey, 2)
            cv2.line(page, (x0 + outer, y0 + offset), (x0 + outer, y0 + min(offset + 12, outer)), grey, 2)
        text(f"{size_mm:.0f} mm marker  (cut out along the dashed line, keep the white border)",
             15 + outer / mm + 8, y + outer / mm / 2, 1.0, 2)
        y += outer / mm + 18

    text("Which size: 30 mm if the camera is within about 0.5 m of the arm, 40 mm if farther.", 15, y + 4, 1.0, 2)
    text("Stick it flat on a stiff card, centred over the tool, facing the camera. No glossy paper.", 15, y + 12,
         1.0, 2)
    bar_y = int((y + 30) * mm)
    x_left = int(15 * mm)
    cv2.line(page, (x_left, bar_y), (x_left + int(100 * mm), bar_y), black, 4)
    for tick in range(0, 101, 10):
        x = x_left + int(tick * mm)
        cv2.line(page, (x, bar_y - int((6 if tick % 50 == 0 else 3) * mm)), (x, bar_y + int(3 * mm)), black, 3)
    text("100 mm", 15 + 104, y + 31, 1.2, 2)

    ok, encoded = cv2.imencode(".png", page)
    if not ok:
        raise RuntimeError("could not encode the marker sheet")
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(_png_with_dpi(encoded.tobytes(), SHEET_DPI))
    return target


# ---- finding it -----------------------------------------------------------------------------------------
@dataclass
class MarkerDetection:
    centre_uv: tuple[float, float]       # picture position of the marker's centre, to a fraction of a pixel
    depth_mm: float                      # camera distance to the marker's surface
    side_px: float                       # apparent size, for sanity checks
    corners: np.ndarray                  # 4 x 2


def _diagonals_meet(corners: np.ndarray) -> tuple[float, float]:
    """Where the two diagonals cross: the centre of the square as the camera sees it, right even
    when the square is seen at an angle."""
    (x1, y1), (x2, y2), (x3, y3), (x4, y4) = corners
    denominator = (x1 - x3) * (y2 - y4) - (y1 - y3) * (x2 - x4)
    if abs(denominator) < 1e-9:
        return float(corners[:, 0].mean()), float(corners[:, 1].mean())
    a, b = x1 * y3 - y1 * x3, x2 * y4 - y2 * x4
    return ((a * (x2 - x4) - (x1 - x3) * b) / denominator, (a * (y2 - y4) - (y1 - y3) * b) / denominator)


_DETECTOR = None


def _detector():
    global _DETECTOR
    if _DETECTOR is None:
        parameters = cv2.aruco.DetectorParameters()
        parameters.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
        parameters.minMarkerPerimeterRate = 0.01   # small markers: a 30 mm one far away is tiny in the picture
        _DETECTOR = cv2.aruco.ArucoDetector(_dictionary(), parameters)
    return _DETECTOR


def detect_marker(rgb: np.ndarray, depth: Optional[np.ndarray], intrinsics: Intrinsics,
                  marker_mm: float = 30.0, marker_id: int = MARKER_ID) -> Optional[MarkerDetection]:
    """Find the marker and its distance, or None. Needs the depth picture: the distance is read
    from the camera's depth over the flat marker (median, so noise and holes don't matter)."""
    if depth is None:
        return None
    grey = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    corners, ids, _ = _detector().detectMarkers(grey)
    if ids is None:
        return None
    for quad, found in zip(corners, ids.flatten()):
        if int(found) != marker_id:
            continue
        quad = quad.reshape(4, 2).astype(np.float64)
        centre = _diagonals_meet(quad)
        # depth: the median over the inside of the marker (shrunk, so it stays clear of the edges)
        inside = np.zeros(depth.shape, np.uint8)
        shrunk = centre + 0.6 * (quad - centre)
        cv2.fillConvexPoly(inside, np.round(shrunk).astype(np.int32), 1)
        readings = depth[(inside > 0) & (depth > 0)]
        if readings.size < 20:
            continue
        distance = float(np.median(readings))
        side = float(np.mean([np.linalg.norm(quad[i] - quad[(i + 1) % 4]) for i in range(4)]))
        expected = marker_mm * intrinsics.fx / distance
        if not (_MAX_SIZE_ERROR[0] * expected <= side <= _MAX_SIZE_ERROR[1] * expected):
            continue   # the wrong size for its distance: a look-alike, or the wrong marker size was chosen
        return MarkerDetection(centre_uv=centre, depth_mm=distance, side_px=side, corners=quad)
    return None

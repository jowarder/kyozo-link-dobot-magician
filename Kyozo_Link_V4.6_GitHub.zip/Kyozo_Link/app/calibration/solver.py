"""Transform solvers (Kabsch/SVD, and Umeyama's with a scale) shared by all calibration modes."""
from __future__ import annotations

import numpy as np


def solve_rigid_transform(points_camera: np.ndarray, points_robot: np.ndarray,
                          with_scale: bool = False) -> tuple[np.ndarray, float]:
    """Solves for the 4x4 transform T such that T @ points_camera ~= points_robot.

    points_camera, points_robot: Nx3 arrays of corresponding 3D points (mm), N >= 3.
    with_scale: also one scale for the camera's points (Umeyama): a real depth camera's distances came out about 10%
    too long (or its lens's focal length that much short), and no turn and shift alone could fit that -- every
    calibration was 15-19 mm off, and about 6 mm with the scale. T's top-left 3x3 is then the turn times the scale.
    Returns (T_4x4, mean_reprojection_error_mm).
    """
    if points_camera.shape != points_robot.shape or points_camera.shape[1] != 3:
        raise ValueError("points_camera and points_robot must both be Nx3 arrays")
    if points_camera.shape[0] < 3:
        raise ValueError("Need at least 3 point correspondences to solve a rigid transform")

    centroid_cam = points_camera.mean(axis=0)
    centroid_robot = points_robot.mean(axis=0)
    cam_centered = points_camera - centroid_cam
    robot_centered = points_robot - centroid_robot

    H = cam_centered.T @ robot_centered
    U, _, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    correction = np.diag([1, 1, d])
    R = Vt.T @ correction @ U.T
    if with_scale:
        _, singular, _ = np.linalg.svd(H)
        spread = float((cam_centered ** 2).sum())
        scale = float((singular * np.diag(correction)).sum()) / spread if spread > 0 else 1.0
        R = R * scale
    t = centroid_robot - R @ centroid_cam

    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = t

    points_cam_h = np.hstack([points_camera, np.ones((points_camera.shape[0], 1))])
    predicted = (T @ points_cam_h.T).T[:, :3]
    errors = np.linalg.norm(predicted - points_robot, axis=1)
    mean_error_mm = float(np.mean(errors))

    return T, mean_error_mm

"""Save/load calibration results to disk."""
from __future__ import annotations

import json
import logging
import shutil
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from app.fileutil import atomic_write_bytes, atomic_write_text, set_aside_damaged
from app.hardware.interfaces import Intrinsics

logger = logging.getLogger(__name__)

HISTORY_KEPT = 10           # earlier calibrations kept (per calibration file), to go back to


@dataclass
class Calibration:
    t_cam_to_robot: list  # 4x4 nested list
    intrinsics: dict
    method: str
    reprojection_error_mm: float
    num_samples: int
    # what else the calibration found (cube calibration): "xy_correction" (correction.XYCorrection.as_dict()),
    # "tool_offset_mm", "undistorted" (whether the pictures were straightened for the lens when it was made)
    extras: dict = field(default_factory=dict)

    def transform_matrix(self) -> np.ndarray:
        return np.array(self.t_cam_to_robot)

    def correction(self):
        from app.calibration.correction import XYCorrection
        return XYCorrection.from_dict((self.extras or {}).get("xy_correction"))


def save_calibration(path: str | Path, t_cam_to_robot: np.ndarray, intrinsics: Intrinsics,
                      method: str, reprojection_error_mm: float, num_samples: int,
                      extras: dict | None = None, archive: bool = True) -> None:
    """`archive`: keep a copy of the one replaced in the history -- not when only its extras grow (a fingers check, a
    rotation test), where copies of the same calibration pushed real earlier ones out of the HISTORY_KEPT."""
    calib = Calibration(
        t_cam_to_robot=t_cam_to_robot.tolist(),
        intrinsics=asdict(intrinsics),
        method=method,
        reprojection_error_mm=reprojection_error_mm,
        num_samples=num_samples,
        extras=dict(extras or {}),
    )
    if archive:
        archive_calibration(path)
    atomic_write_text(path, json.dumps(asdict(calib), indent=2))


def history_dir(path: str | Path) -> Path:
    return Path(path).parent / "calibration_history"


def archive_calibration(path: str | Path) -> Path | None:
    """A copy of the calibration in `path` (if there is one) into the history, before it is replaced or cleared;
    only the newest HISTORY_KEPT are kept. Returns the copy -- or the copy already there, when it is one gone back to
    (restored, it is dated anew: not a calibration of its own)."""
    file_path = Path(path)
    if not file_path.exists():
        return None
    folder = history_dir(file_path)
    try:
        data = file_path.read_bytes()
        for kept in _history_files(file_path):
            if kept.read_bytes() == data:
                return kept
        folder.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(file_path.stat().st_mtime))
        copy = folder / f"{file_path.stem}_{stamp}.json"
        n = 1
        while copy.exists() and copy.read_bytes() != data:
            n += 1
            copy = folder / f"{file_path.stem}_{stamp}_{n}.json"
        shutil.copy2(file_path, copy)
        for old in _history_files(file_path)[HISTORY_KEPT:]:
            old.unlink(missing_ok=True)
        return copy
    except OSError as exc:
        logger.warning("Couldn't keep a copy of the calibration %s: %s", file_path, exc)
        return None


def _history_files(path: Path) -> list[Path]:
    folder = history_dir(path)
    if not folder.is_dir():
        return []
    files = [f for f in folder.glob(f"{path.stem}_*.json") if f.stem[len(path.stem) + 1:][:1].isdigit()]
    return sorted(files, key=lambda f: f.stat().st_mtime, reverse=True)


def calibration_history(path: str | Path) -> list[tuple[Path, Calibration, float]]:
    """The earlier calibrations kept for `path`, newest first: (file, calibration, when it was made: a time.time())."""
    out = []
    for f in _history_files(Path(path)):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            out.append((f, Calibration(**data), f.stat().st_mtime))
        except (OSError, ValueError, TypeError):
            continue
    return out


def restore_calibration(path: str | Path, earlier: str | Path) -> Calibration | None:
    """Make an earlier calibration (a history file) the one in use; the one in use goes into the history first.
    A history file that can't be read is refused (None) and the one in use left as it was. Written whole or not at
    all, and dated now: in use from now (its copy in the history stays, dated when it was made)."""
    try:
        data = Path(earlier).read_bytes()
        _parse(data.decode("utf-8"))
    except (OSError, ValueError, TypeError, KeyError) as exc:     # (a UnicodeDecodeError is a ValueError)
        logger.error("The earlier calibration %s can't be read (%s): the one in use is kept.", earlier, exc)
        return None
    archive_calibration(path)
    atomic_write_bytes(path, data)
    return load_calibration(path)


def clear_calibration(path: str | Path) -> None:
    """No calibration in use (the one there was goes into the history)."""
    archive_calibration(path)
    Path(path).unlink(missing_ok=True)


def load_calibration(path: str | Path) -> Calibration | None:
    """The saved calibration, or None if there isn't one -- or if the file is damaged (a power cut
    while saving, say). A damaged one is set aside as `<name>.bad` and the app starts uncalibrated,
    which is safe, instead of refusing to start at all."""
    file_path = Path(path)
    if not file_path.exists():
        return None
    try:
        return _parse(file_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError, KeyError) as exc:   # JSONDecodeError is a ValueError
        moved = set_aside_damaged(file_path)
        logger.error("The calibration file %s is damaged (%s). %s Starting without a calibration: recalibrate.",
                     file_path, exc, f"Kept as {moved.name}." if moved else "")
        return None


def _parse(text: str) -> Calibration:
    """A calibration file's text as a Calibration; raises if it isn't one (ValueError, TypeError, KeyError)."""
    calibration = Calibration(**json.loads(text))
    matrix = np.array(calibration.t_cam_to_robot, dtype=float)
    if matrix.shape != (4, 4) or not np.isfinite(matrix).all():
        raise ValueError(f"the transform is not a 4x4 matrix of numbers (shape {matrix.shape})")
    return calibration

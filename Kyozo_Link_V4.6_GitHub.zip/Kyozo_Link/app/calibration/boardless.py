"""Calibration Mode B: boardless manual point-teach.

The user jogs the robot to N known points and clicks the corresponding pixel
in the live camera view at each one. This module accumulates the point pairs
and calls the shared solver.

The error a fit reports about itself is misleading: it *rises* as points are added while
the real accuracy improves (a Monte Carlo study of this solver with realistic click and
depth noise: 3 points -> reported 2.1 mm but real 5.7 mm typical and 17.6 mm in the worst
10% of cases; 8 points -> reported 3.6 mm, real 2.2 mm). So `solve_detailed` also does a
leave-one-out check -- predict each point from all the others -- which is an honest
estimate, and flags points that look like mis-clicks.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from app.calibration.solver import solve_rigid_transform
from app.hardware.interfaces import Intrinsics
from app.vision.locator import pixel_to_camera_point

MIN_POINTS = 3          # smallest number that fixes a rigid transform
RECOMMENDED_POINTS = 8  # about 2 mm real error in simulation; fewer gives a heavy bad-luck tail
MIN_SPREAD_MM = 20.0    # points must span at least this far in a second direction (not a line)

# With 3 points nothing is left over to check against, so the real error can't be measured.
# Simulation gave a typical 6 mm and about 18 mm in the worst 10% of runs, so assume at least this.
UNMEASURABLE_ERROR_MM = 10.0
SUSPECT_MIN_POINTS = 5   # need enough points for "this one disagrees with the rest" to mean something
SUSPECT_FACTOR = 3.0     # a point is suspect if its leave-one-out error is this many times the typical one...
SUSPECT_FLOOR_MM = 8.0   # ...and at least this large
SCALE_MIN_POINTS = 6     # the camera's distance scale is measured too, with at least this many points...
SCALE_RANGE = (0.8, 1.25)  # ...when it comes out within this...
SCALE_GAIN = 0.8         # ...and makes the error at most this much of the plain fit's (else it's just noise fitted)


def _is_collinear(points: np.ndarray) -> bool:
    centered = points - points.mean(axis=0)
    singular_values = np.linalg.svd(centered, compute_uv=False)
    return len(singular_values) < 2 or singular_values[1] < MIN_SPREAD_MM


@dataclass
class SolveResult:
    transform: np.ndarray
    fit_error_mm: float                        # mean residual with all points in the fit (flattering)
    residuals_mm: list[float]                  # per point, with that point in the fit
    loo_errors_mm: Optional[list[float]]       # per point, predicted from the others (None if too few points)
    suspects: list[int] = field(default_factory=list)  # indices that look like mis-clicks
    scale: float = 1.0                         # the camera's distances times this are the arm's (1.0: not measured)
    unscaled_error_mm: Optional[float] = None  # the honest error without the scale, when one is used

    @property
    def honest_error_mm(self) -> float:
        """Typical error when placing a point. Includes the click noise of the point being
        predicted, so it errs on the high side -- deliberately."""
        if self.loo_errors_mm:
            finite = [e for e in self.loo_errors_mm if np.isfinite(e)]
            if finite:
                return float(np.median(finite))
        return max(self.fit_error_mm, UNMEASURABLE_ERROR_MM)

    @property
    def measurable(self) -> bool:
        return bool(self.loo_errors_mm) and any(np.isfinite(e) for e in self.loo_errors_mm)

    @property
    def worst_index(self) -> int:
        scores = self.loo_errors_mm if self.measurable else self.residuals_mm
        return int(np.nanargmax(scores))


@dataclass
class BoardlessCalibrator:
    intrinsics: Intrinsics
    samples_robot: list = field(default_factory=list)
    samples_camera: list = field(default_factory=list)
    samples_pixel: list = field(default_factory=list)  # (u, v, depth_mm) as clicked, for display

    def add_sample(self, robot_xyz: tuple[float, float, float], pixel_uv: tuple[int, int],
                    depth_mm: float) -> None:
        point_cam = pixel_to_camera_point(pixel_uv[0], pixel_uv[1], depth_mm, self.intrinsics)
        self.samples_camera.append(tuple(point_cam[:3]))
        self.samples_robot.append(robot_xyz)
        self.samples_pixel.append((pixel_uv[0], pixel_uv[1], depth_mm))

    def remove_sample(self, index: int) -> None:
        del self.samples_camera[index], self.samples_robot[index], self.samples_pixel[index]

    def num_samples(self) -> int:
        return len(self.samples_robot)

    def ready(self) -> bool:
        return self.num_samples() >= MIN_POINTS

    def reset(self) -> None:
        self.samples_robot.clear()
        self.samples_camera.clear()
        self.samples_pixel.clear()

    def solve(self) -> tuple[np.ndarray, float]:
        result = self.solve_detailed()
        return result.transform, result.fit_error_mm

    def solve_detailed(self) -> SolveResult:
        if not self.ready():
            raise RuntimeError(f"Need at least {MIN_POINTS} samples, have {self.num_samples()}")
        cam = np.array(self.samples_camera)
        robot = np.array(self.samples_robot)
        if _is_collinear(robot) or _is_collinear(cam):
            raise RuntimeError(
                "The points lie (nearly) on a straight line, which can't fix the camera's "
                "orientation. Add points that are spread out sideways, not just along one line."
            )
        plain = self._fit(cam, robot, with_scale=False)
        result = plain
        if len(cam) >= SCALE_MIN_POINTS:
            scaled = self._fit(cam, robot, with_scale=True)
            scale = float(np.cbrt(np.linalg.det(scaled.transform[:3, :3])))
            if (SCALE_RANGE[0] <= scale <= SCALE_RANGE[1]
                    and scaled.honest_error_mm <= SCALE_GAIN * plain.honest_error_mm):
                scaled.scale, scaled.unscaled_error_mm = scale, plain.honest_error_mm
                result = scaled
        loo = result.loo_errors_mm
        suspects: list[int] = []
        if loo and len(cam) >= SUSPECT_MIN_POINTS:
            finite = [e for e in loo if np.isfinite(e)]
            if finite:
                threshold = max(SUSPECT_FACTOR * float(np.median(finite)), SUSPECT_FLOOR_MM)
                suspects = [i for i, e in enumerate(loo) if np.isfinite(e) and e > threshold]
        result.suspects = suspects
        return result

    @staticmethod
    def _fit(cam: np.ndarray, robot: np.ndarray, with_scale: bool) -> SolveResult:
        """The fit, its residuals, and each point as predicted from the others."""
        transform, fit_error = solve_rigid_transform(cam, robot, with_scale=with_scale)
        predicted = (transform @ np.column_stack([cam, np.ones(len(cam))]).T).T[:, :3]
        residuals = np.linalg.norm(predicted - robot, axis=1)
        loo: Optional[list[float]] = None
        if len(cam) >= MIN_POINTS + 1:
            loo = []
            for i in range(len(cam)):
                keep = [j for j in range(len(cam)) if j != i]
                if _is_collinear(robot[keep]) or _is_collinear(cam[keep]):
                    loo.append(float("nan"))  # the others can't define a transform without this one
                    continue
                without, _ = solve_rigid_transform(cam[keep], robot[keep], with_scale=with_scale)
                guess = (without @ np.append(cam[i], 1.0))[:3]
                loo.append(float(np.linalg.norm(guess - robot[i])))
        return SolveResult(transform, float(fit_error), [float(r) for r in residuals], loo)

"""Re-solve a saved calibration session, with no robot or camera.

    python -m app.calibration.replay sessions/20260918_143012
    python -m app.calibration.replay sessions/20260918_143012 --redepth
    python -m app.calibration.replay sessions/20260918_143012 --drop 3 --drop 5

`--redepth` reads the depth again from the saved depth pictures instead of using the
number recorded at the time (to test a different way of reading depth). `--drop N` leaves out
point N (as numbered in the list) to see what the result would have been without it.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from app.calibration.boardless import BoardlessCalibrator
from app.calibration.session import load_session
from app.vision.locator import foreground_depth


def resolve(folder: str | Path, redepth: bool = False, drop: tuple[int, ...] = ()) -> dict:
    """Re-solve a session; returns the numbers (and the transform)."""
    session = load_session(folder)
    calibrator = BoardlessCalibrator(intrinsics=session.intrinsics)
    kept = []
    for index, sample in enumerate(session.samples):
        if (index + 1) in drop:
            continue
        u, v = sample["pixel_uv"]
        depth = sample["depth_mm"]
        if redepth:
            image = session.depth_image(index)
            if image is None:
                raise RuntimeError(f"point {index + 1} has no saved depth picture to re-read")
            depth = foreground_depth(image, int(round(u)), int(round(v)))
        calibrator.add_sample(tuple(sample["robot_xyz"]), (int(round(u)), int(round(v))), depth)
        kept.append(index + 1)
    result = calibrator.solve_detailed()
    transform = result.transform.copy()
    correction = 0.0
    touch = session.document.get("table_touch")
    auto = session.document.get("auto") or {}
    if touch and touch.get("correction_mm") is not None:
        correction = float(touch["correction_mm"])
    elif auto.get("method") == "cube" and auto.get("z_offset_mm") is not None:
        correction = float(auto["z_offset_mm"])    # the cube's top above the fingertips (cube.with_height)
    transform[2, 3] += correction
    return {"points": kept, "honest_error_mm": result.honest_error_mm, "fit_error_mm": result.fit_error_mm,
            "loo_errors_mm": result.loo_errors_mm, "suspects": [kept[i] for i in result.suspects],
            "height_correction_mm": correction, "transform": transform,
            "recorded": session.document.get("result")}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("folder")
    parser.add_argument("--redepth", action="store_true")
    parser.add_argument("--drop", type=int, action="append", default=[])
    args = parser.parse_args(argv)
    try:
        out = resolve(args.folder, redepth=args.redepth, drop=tuple(args.drop))
    except (OSError, RuntimeError, KeyError) as exc:
        print(f"Could not replay {args.folder}: {exc}")
        return 1
    print(f"Points used: {out['points']}")
    print(f"Typical error (leave-one-out): {out['honest_error_mm']:.1f} mm   (fit's own: {out['fit_error_mm']:.1f} mm)")
    if out["loo_errors_mm"]:
        print("Per point (left out): " + ", ".join(f"#{p}: {e:.1f}" for p, e in zip(out["points"], out["loo_errors_mm"])))
    if out["suspects"]:
        print(f"Looks like mis-clicks: points {out['suspects']}")
    if out["height_correction_mm"]:
        print(f"Table-height correction applied: {out['height_correction_mm']:.1f} mm")
    recorded = out["recorded"]
    if recorded and recorded.get("honest_error_mm") is not None:
        print(f"At the time the app reported: {recorded['honest_error_mm']:.1f} mm")
    np.set_printoptions(precision=3, suppress=True)
    print("Camera -> robot transform:")
    print(out["transform"])
    return 0


if __name__ == "__main__":
    sys.exit(main())

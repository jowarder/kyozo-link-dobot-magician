"""Saving calibration sessions, so a problem at the lab can be debugged at home.

Everything needed to redo a calibration without the robot or the camera goes into one folder:
each point's robot position, clicked pixel and depth, plus the camera picture (colour and
depth) at the moment of the click, the result, the table-height step and any verification.

    sessions/20260918_143012/
        session.json        the numbers
        frame_01.png        colour picture at point 1
        depth_01.npz        depth at point 1 (millimetres, 16-bit)
        ...

`python -m app.calibration.replay <folder>` re-solves it and prints what happened.
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from app.fileutil import atomic_write_text
from app.hardware.interfaces import Intrinsics

logger = logging.getLogger(__name__)
FORMAT_VERSION = 1


@dataclass
class SampleRecord:
    robot_xyz: tuple[float, float, float]
    pixel_uv: tuple[float, float]
    depth_mm: float
    source: str = "manual"             # "manual" click or "marker" detection
    rgb: Optional[np.ndarray] = None   # kept only until the frame is written to disk
    depth: Optional[np.ndarray] = None
    files: Optional[dict] = None       # {"rgb": ..., "depth": ...} once written
    note: str = ""


@dataclass
class SessionRecorder:
    root: Path
    intrinsics: Intrinsics
    context: dict = field(default_factory=dict)   # e.g. {"mode": "demo"}
    samples: list[SampleRecord] = field(default_factory=list)
    removed: list[dict] = field(default_factory=list)
    result: Optional[dict] = None
    table_touch: Optional[dict] = None
    verification: Optional[dict] = None
    auto: Optional[dict] = None
    folder: Optional[Path] = None

    # ---- what happened ----------------------------------------------------------------------
    def add(self, record: SampleRecord) -> None:
        self.samples.append(record)

    def remove(self, index: int, reason: str = "removed by the user") -> None:
        record = self.samples.pop(index)
        self.removed.append({**_describe(record), "reason": reason})
        # a removed point is kept on disk if its picture was already saved, dropped from memory otherwise
        record.rgb = record.depth = None

    def clear(self) -> None:
        """Start a new session: the next save goes to a new folder."""
        self.samples.clear()
        self.removed.clear()
        self.result = self.table_touch = self.verification = self.auto = None
        self.folder = None

    def set_result(self, **values) -> None:
        self.result = {k: _plain(v) for k, v in values.items()}

    def set_table_touch(self, **values) -> None:
        self.table_touch = {k: _plain(v) for k, v in values.items()}

    def set_verification(self, values: dict) -> None:
        self.verification = _plain(values)

    def set_auto(self, values: dict) -> None:
        self.auto = _plain(values)

    # ---- writing --------------------------------------------------------------------------------
    def save(self) -> Optional[Path]:
        """Write (or update) the session folder. Never raises: a failed save must not stop calibrating."""
        try:
            if self.folder is None:
                stamp = time.strftime("%Y%m%d_%H%M%S")
                self.folder = self.root / stamp
                counter = 1
                while self.folder.exists():
                    counter += 1
                    self.folder = self.root / f"{stamp}_{counter}"
                self.folder.mkdir(parents=True, exist_ok=True)
            for index, record in enumerate(self.samples, start=1):
                if record.files is None and record.rgb is not None:
                    tag = f"{index:02d}"
                    while (self.folder / f"frame_{tag}.png").exists():
                        tag += "b"   # points get renumbered when one is removed; never overwrite a saved picture
                    cv2.imwrite(str(self.folder / f"frame_{tag}.png"), cv2.cvtColor(record.rgb, cv2.COLOR_RGB2BGR))
                    files = {"rgb": f"frame_{tag}.png"}
                    if record.depth is not None:
                        np.savez_compressed(self.folder / f"depth_{tag}.npz",
                                            depth=np.clip(record.depth, 0, 65535).astype(np.uint16))
                        files["depth"] = f"depth_{tag}.npz"
                    record.files = files
                    record.rgb = record.depth = None
            document = {
                "format": FORMAT_VERSION,
                "saved": time.strftime("%Y-%m-%d %H:%M:%S"),
                "context": self.context,
                "intrinsics": {"fx": self.intrinsics.fx, "fy": self.intrinsics.fy, "cx": self.intrinsics.cx,
                               "cy": self.intrinsics.cy, "width": self.intrinsics.width,
                               "height": self.intrinsics.height},
                "samples": [_describe(record) for record in self.samples],
                "removed": self.removed,
                "result": self.result,
                "auto": self.auto,
                "table_touch": self.table_touch,
                "verification": self.verification,
            }
            atomic_write_text(self.folder / "session.json", json.dumps(document, indent=2))
            return self.folder
        except Exception:  # noqa: BLE001 - see docstring
            logger.warning("Could not save the calibration session", exc_info=True)
            return None


def _describe(record: SampleRecord) -> dict:
    return {"robot_xyz": [float(v) for v in record.robot_xyz], "pixel_uv": [float(v) for v in record.pixel_uv],
            "depth_mm": float(record.depth_mm), "source": record.source, "files": record.files, "note": record.note}


def _plain(value):
    """Turn numpy values (and containers of them) into plain JSON types."""
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, float):
        return None if not np.isfinite(value) else value
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, dict):
        return {k: _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    return value


# ---- reading it back --------------------------------------------------------------------------
@dataclass
class LoadedSession:
    folder: Path
    document: dict

    @property
    def intrinsics(self) -> Intrinsics:
        return Intrinsics(**self.document["intrinsics"])

    @property
    def samples(self) -> list[dict]:
        return self.document["samples"]

    def depth_image(self, index: int) -> Optional[np.ndarray]:
        name = (self.samples[index].get("files") or {}).get("depth")
        if not name or not (self.folder / name).exists():
            return None
        with np.load(self.folder / name) as data:          # (closed: on Windows an open file can't be replaced)
            return data["depth"].astype(np.float32)


def load_session(folder: str | Path) -> LoadedSession:
    folder = Path(folder)
    return LoadedSession(folder, json.loads((folder / "session.json").read_text(encoding="utf-8")))

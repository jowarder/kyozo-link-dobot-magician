"""Entry point for the Kyozo Link app."""
from __future__ import annotations

import argparse
import logging
import sys

from pathlib import Path

import yaml
from PyQt6.QtWidgets import QApplication

from app import APP_NAME, __version__, crash_reporting, robots
from app.config import DEFAULT_CONFIG_PATH as CONFIG_PATH, load_config
from app.fileutil import atomic_write_text
from app.ui.main_window import MainWindow, default_robot_settings
from app.ui.robot_chooser import RobotChooser
from app.ui.theme import apply_dark_theme

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


def remember_choice(config: dict, robot: str, mode: str) -> None:
    """The start-up window's choice, for this run and (in config.yaml) to be picked next time."""
    config["robot_model"], config["mode"] = robot, mode
    try:
        raw = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
        if raw.get("robot_model", "dobot_magician") == robot and raw.get("mode") == mode:
            return
        raw["robot_model"], raw["mode"] = robot, mode
        section = robots.profile(robot).config_section
        if section not in raw:
            raw[section] = default_robot_settings(robot)
        atomic_write_text(CONFIG_PATH, yaml.safe_dump(raw, sort_keys=False))
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        logging.getLogger(__name__).warning("Could not remember the robot and mode in config.yaml: %s", exc)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["demo", "live"],
                        help="the mode picked in the start-up window (or, with --skip-chooser, this run's mode)")
    parser.add_argument("--skip-chooser", action="store_true",
                        help="start straight away as config.yaml says (a restart after switching in the toolbar)")
    args, qt_args = parser.parse_known_args()
    config = load_config()
    crash_reporting.install(Path(__file__).resolve().parent.parent)
    app = QApplication([sys.argv[0], *qt_args])
    app.setApplicationName(APP_NAME)
    apply_dark_theme(app)
    if args.skip_chooser:
        if args.mode:
            config["mode"] = args.mode
    else:
        # which robot, demo or live: picked before anything connects (the last choice already picked)
        chooser = RobotChooser(config, mode=args.mode)
        if chooser.exec() != RobotChooser.DialogCode.Accepted:
            return 0
        robot, mode = chooser.choice()
        remember_choice(config, robot, mode)
    logging.getLogger(__name__).info("%s V%s starting (%s, %s mode)", APP_NAME, __version__,
                                     config.get("robot_model", "dobot_magician"), config.get("mode", "demo"))
    window = MainWindow(config)
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())

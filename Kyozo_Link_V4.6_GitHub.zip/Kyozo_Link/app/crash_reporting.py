"""Make a failure visible instead of the app just disappearing.

PyQt6 ends the whole program when a button handler raises an error nobody caught, with no
message if the app was started from a shortcut. Three things here:

* an error hook: the error is logged (to the log window and to `app.log`), shown in a message
  box, and the app carries on;
* `app.log`: everything the app logs, kept between runs;
* `crash.log`: if the program dies in native code (no Python error to catch), the
  interpreter writes what every thread was doing there.
"""
from __future__ import annotations

import faulthandler
import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

logger = logging.getLogger(__name__)
_showing = False
_crash_file = None   # kept open for the life of the program: faulthandler writes to it at the moment of a crash


def install(project_root: Path) -> None:
    global _crash_file
    handler = RotatingFileHandler(project_root / "app.log", maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    logging.getLogger().addHandler(handler)
    try:
        _crash_file = open(project_root / "crash.log", "a", buffering=1, encoding="utf-8")
        faulthandler.enable(file=_crash_file, all_threads=True)
    except OSError:
        logger.warning("Could not open crash.log", exc_info=True)
    sys.excepthook = report_error


def report_error(exc_type, exc, traceback) -> None:
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc, traceback)
        return
    logger.critical("Unhandled error", exc_info=(exc_type, exc, traceback))
    global _showing
    if _showing:   # an error inside the error box, or a burst of errors: log them, don't stack boxes
        return
    _showing = True
    try:
        from PyQt6.QtWidgets import QApplication, QMessageBox
        if QApplication.instance() is not None:
            QMessageBox.critical(
                None, "Something went wrong",
                f"{exc_type.__name__}: {exc}\n\nThe details are in app.log next to the program. The app is still "
                "running, but if things look odd, restart it.")
    except Exception:  # noqa: BLE001 - reporting must never make things worse
        pass
    finally:
        _showing = False

"""Kyozo Link (formerly Dobot Vision Task). The version number lives in the VERSION file at the project root."""
from pathlib import Path

APP_NAME = "Kyozo Link"   # the window titles and the log; one place to change it


def _read_version() -> str:
    try:
        return (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "unknown"


__version__ = _read_version()

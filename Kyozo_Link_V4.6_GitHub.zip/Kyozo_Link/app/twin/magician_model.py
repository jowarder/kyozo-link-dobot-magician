"""The Dobot Magician's real shape, posed like the real arm.

The meshes are from the MIT-licensed jkaniuka/magician_ros2 package (see meshes/LICENSE), each stored
here in its URDF link frame in millimetres, simplified so it can be drawn every frame. The joint chain
below is that package's URDF, which uses the Magician's published dimensions (DT-MG-4R005-02E):

    base            shoulder (J2) axis 131.305 mm above the bottom of the base
    link 1 (J1)     turns about the vertical axis
    link 2 (J2)     rear arm, 135 mm; J2 = 0 is straight up, positive leans it forward
    link 3 (J3)     forearm, 147 mm; its angle below horizontal is J2 + J3
    link 4          the wrist piece, kept level by the parallelogram
    gripper (J4)    60 mm in front of the wrist, turns about the vertical axis
    jaws            slide sideways, up to 13.5 mm each

`posed_triangles` takes the arm geometry the rest of the app already computes (kinematics.arm_geometry)
and returns world-space triangles to draw.
"""
from __future__ import annotations

import math
from functools import lru_cache
from pathlib import Path
from typing import Optional

import numpy as np

MESH_DIR = Path(__file__).resolve().parent / "meshes"
BASE_HEIGHT_MM = 131.305
REAR_ARM_MM = 135.0
FOREARM_MM = 147.0
TOOL_OFFSET_MM = 60.0
JAW_TRAVEL_MM = 13.5

PARTS = ("magicianBase", "magicianLink1", "magicianLink2", "magicianLink3", "magicianLink4",
         "gripper_core", "jaw_left", "jaw_right")


@lru_cache(maxsize=1)
def load_parts() -> Optional[dict]:
    """{name: (vertices (V,3) mm, faces (F,3), colours (F,3))}, or None if the mesh files are missing."""
    parts = {}
    for name in PARTS:
        path = MESH_DIR / f"{name}.npz"
        if not path.exists():
            return None
        with np.load(path) as data:
            parts[name] = (data["vertices"].astype(np.float64), data["faces"].astype(np.int64),
                           data["colors"].astype(np.float64))
    return parts


def _rot_z(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    m = np.eye(4)
    m[:2, :2] = [[c, -s], [s, c]]
    return m


def _rot_y(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    m = np.eye(4)
    m[0, 0], m[0, 2], m[2, 0], m[2, 2] = c, s, -s, c
    return m


def _move(x: float, y: float, z: float) -> np.ndarray:
    m = np.eye(4)
    m[:3, 3] = (x, y, z)
    return m


def joint_values(geometry) -> tuple[float, float, float]:
    """(J1, J2, J3) in radians, URDF convention, from the arm's shoulder/elbow/wrist points."""
    tx, ty = geometry.tcp[0], geometry.tcp[1]
    q1 = math.atan2(ty, tx) if math.hypot(tx, ty) > 1e-6 else 0.0
    ux, uy = math.cos(q1), math.sin(q1)

    def planar(p):
        return p[0] * ux + p[1] * uy, p[2]

    sr, sz = planar(geometry.shoulder)
    er, ez = planar(geometry.elbow)
    wr, wz = planar(geometry.wrist)
    q2 = math.atan2(er - sr, ez - sz)                 # rear arm, from vertical, forward positive
    below_horizontal = math.atan2(-(wz - ez), wr - er)
    return q1, q2, below_horizontal - q2


def link_transforms(q1: float, q2: float, q3: float, q4: float, jaw_mm: float) -> dict[str, np.ndarray]:
    """World transform (table frame, mm) of every part's link frame."""
    base = _move(0.0, 0.0, BASE_HEIGHT_MM)
    link1 = base @ _rot_z(q1)
    link2 = link1 @ _rot_y(q2)
    link3 = link2 @ _move(0.0, 0.0, REAR_ARM_MM) @ _rot_y(q3)
    link4 = link3 @ _move(FOREARM_MM, 0.0, 0.0) @ _rot_y(-q2) @ _rot_y(-q3)
    gripper = link4 @ _move(TOOL_OFFSET_MM, 0.0, 0.0) @ _rot_z(q4)
    return {
        "magicianBase": base, "magicianLink1": link1, "magicianLink2": link2, "magicianLink3": link3,
        "magicianLink4": link4, "gripper_core": gripper,
        "jaw_left": gripper @ _move(0.0, jaw_mm, 0.0), "jaw_right": gripper @ _move(0.0, -jaw_mm, 0.0),
    }


JAW_GAP_CLOSED_MM = 0.9   # half the gap between the fingers when fully closed


def jaw_opening(gripper_closed: bool, held_width_mm: Optional[float] = None) -> float:
    """How far each jaw slides out: all the way when open, to the object's sides when holding one,
    fully in when closed on nothing."""
    if not gripper_closed:
        return JAW_TRAVEL_MM
    if held_width_mm:
        return min(JAW_TRAVEL_MM, max(0.0, held_width_mm / 2.0 - JAW_GAP_CLOSED_MM))
    return 0.0


TOOL_PARTS = ("gripper_core", "jaw_left", "jaw_right")


def part_slices() -> list[slice]:
    """Which of posed_triangles' triangles belong to each part, in order (base, links, gripper)."""
    parts = load_parts()
    if parts is None:
        return []
    slices, start = [], 0
    for vertices, faces, colours in parts.values():
        slices.append(slice(start, start + len(faces)))
        start += len(faces)
    return slices


def posed_triangles(geometry, tool_rotation_deg: float,
                    jaw_mm: float) -> Optional[tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """(triangles (N,3,3) in world mm, colours (N,3), is_tool (N,) bool: the gripper's own triangles)
    for the whole arm, or None without mesh files."""
    parts = load_parts()
    if parts is None:
        return None
    q1, q2, q3 = joint_values(geometry)
    # the pose's r is the gripper's turn on the table (J1 + J4): J4 itself is what is left after the base
    transforms = link_transforms(q1, q2, q3, math.radians(tool_rotation_deg) - q1, jaw_mm)
    triangles, colours, tool = [], [], []
    for name, (vertices, faces, part_colours) in parts.items():
        m = transforms[name]
        world = vertices @ m[:3, :3].T + m[:3, 3]
        triangles.append(world[faces])
        colours.append(part_colours)
        tool.append(np.full(len(faces), name in TOOL_PARTS))
    return np.concatenate(triangles), np.concatenate(colours), np.concatenate(tool)

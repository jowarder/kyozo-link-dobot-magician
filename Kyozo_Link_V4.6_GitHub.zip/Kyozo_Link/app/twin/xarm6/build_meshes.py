"""Turns UFACTORY's xArm 6 (1305) and xArm Gripper meshes (assets/, from xArm-Developer/xarm_ros2) into the small
.npz files the 3D view draws (meshes/), as was done for the Dobot (app/twin/meshes/NOTICE.txt).

    python -m app.twin.xarm6.build_meshes

Each COLLADA file is read with its materials' colours, put in millimetres (its link frame: the URDF's visual origins
are all zero), its corners joined into one surface, and reduced by quadric edge collapse to a few hundred triangles
each, so the whole arm can be drawn every frame. Each .npz: vertices (V,3) float32 mm, faces (F,3) int32, colors
(F,3) float32, corner_normals (F,3,3) float32 (each triangle's smoothed corner normals, for the light: see
shading_normals).
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ASSETS = HERE / "assets"
OUT = HERE / "meshes"
NS = {"c": "http://www.collada.org/2005/11/COLLADASchema"}
PARTS = {   # name: (file, how many triangles to keep: more for the big round links, fewer for the small parts)
    "link_base": ("arm/link_base.dae", 800), "link1": ("arm/link1.dae", 1600), "link2": ("arm/link2.dae", 2000),
    "link3": ("arm/link3.dae", 1600), "link4": ("arm/link4.dae", 1400), "link5": ("arm/link5.dae", 1200),
    "link6": ("arm/link6.dae", 900), "gripper_base": ("gripper/base_link.dae", 1800),
    "left_outer_knuckle": ("gripper/left_outer_knuckle.dae", 150),
    "left_inner_knuckle": ("gripper/left_inner_knuckle.dae", 250),
    "left_finger": ("gripper/left_finger.dae", 300),
    "right_outer_knuckle": ("gripper/right_outer_knuckle.dae", 150),
    "right_inner_knuckle": ("gripper/right_inner_knuckle.dae", 250),
    "right_finger": ("gripper/right_finger.dae", 300),
}
BLACK_LIFT = 0.12   # pure black reads as a hole on the dark background: lifted a little


def _floats(text: str) -> np.ndarray:
    return np.array(text.split(), dtype=np.float64)


def read_dae(path: Path) -> tuple[np.ndarray, np.ndarray]:
    """(triangles (N,3,3) in the file's units, colours (N,3)) from a COLLADA file: every <triangles> of every
    geometry, each with its material's diffuse colour, placed by the scene's node transforms."""
    root = ET.parse(path).getroot()
    effects = {}
    for effect in root.iterfind(".//c:library_effects/c:effect", NS):
        colour = effect.find(".//c:diffuse/c:color", NS)
        effects[effect.get("id")] = _floats(colour.text)[:3] if colour is not None else np.array([0.7, 0.7, 0.7])
    materials = {}
    for material in root.iterfind(".//c:library_materials/c:material", NS):
        url = material.find("c:instance_effect", NS).get("url").lstrip("#")
        materials[material.get("id")] = effects.get(url, np.array([0.7, 0.7, 0.7]))
    geometries = {}
    for geometry in root.iterfind(".//c:library_geometries/c:geometry", NS):
        mesh = geometry.find("c:mesh", NS)
        sources = {s.get("id"): _floats(s.find("c:float_array", NS).text).reshape(-1, 3)
                   for s in mesh.iterfind("c:source", NS) if s.find("c:float_array", NS) is not None}
        vertices = {v.get("id"): sources[v.find("c:input[@semantic='POSITION']", NS).get("source").lstrip("#")]
                    for v in mesh.iterfind("c:vertices", NS)}
        parts = []
        for tris in mesh.iterfind("c:triangles", NS):
            inputs = tris.findall("c:input", NS)
            stride = max(int(i.get("offset")) for i in inputs) + 1
            vertex_input = next(i for i in inputs if i.get("semantic") == "VERTEX")
            positions = vertices[vertex_input.get("source").lstrip("#")]
            index = np.array(tris.find("c:p", NS).text.split(), dtype=np.int64).reshape(-1, stride)
            corners = positions[index[:, int(vertex_input.get("offset"))]].reshape(-1, 3, 3)
            parts.append((corners, tris.get("material")))
        geometries[geometry.get("id")] = parts
    triangles, colours = [], []

    def visit(node, parent: np.ndarray) -> None:
        """A node and the nodes inside it, each placed by its own transform after its parents' (the gripper's
        files turn their part a quarter turn in a parent node: without it the fingers came out lying down)."""
        matrix = node.find("c:matrix", NS)
        transform = parent @ (_floats(matrix.text).reshape(4, 4) if matrix is not None else np.eye(4))
        for instance in node.iterfind("c:instance_geometry", NS):
            binds = {b.get("symbol"): b.get("target").lstrip("#")
                     for b in instance.iterfind(".//c:instance_material", NS)}
            for corners, symbol in geometries.get(instance.get("url").lstrip("#"), []):
                flat = corners.reshape(-1, 3) @ transform[:3, :3].T + transform[:3, 3]
                triangles.append(flat.reshape(-1, 3, 3))
                colour = materials.get(binds.get(symbol, symbol), np.array([0.7, 0.7, 0.7]))
                colours.append(np.repeat(colour[None, :], len(corners), axis=0))
        for child in node.iterfind("c:node", NS):
            visit(child, transform)

    for scene in root.iterfind(".//c:library_visual_scenes/c:visual_scene", NS):
        for node in scene.iterfind("c:node", NS):
            visit(node, np.eye(4))
    return np.concatenate(triangles), np.concatenate(colours)


def weld(triangles: np.ndarray, colours: np.ndarray, tolerance_mm: float = 0.01):
    """(vertices, faces, colours): the triangle soup's corners joined where they meet, so it is one surface (the
    files repeat each corner for every triangle). Collapsed and repeated triangles dropped."""
    corners = triangles.reshape(-1, 3)
    keys = np.round(corners / tolerance_mm).astype(np.int64)
    _, index, counts = np.unique(keys, axis=0, return_inverse=True, return_counts=True)
    index = index.ravel()
    vertices = np.zeros((counts.size, 3))
    np.add.at(vertices, index, corners)
    vertices /= counts[:, None]
    faces = index.reshape(-1, 3)
    keep = (faces[:, 0] != faces[:, 1]) & (faces[:, 1] != faces[:, 2]) & (faces[:, 0] != faces[:, 2])
    faces, colours = faces[keep], colours[keep]
    _, first = np.unique(np.sort(faces, axis=1), axis=0, return_index=True)
    first.sort()
    return vertices, faces[first], colours[first]


def _plane_quadric(normal: np.ndarray, point: np.ndarray, weight: float) -> np.ndarray:
    plane = np.append(normal, -float(normal @ point))
    return weight * np.outer(plane, plane)


def decimate(vertices: np.ndarray, faces: np.ndarray, colours: np.ndarray, target: int):
    """Quadric edge collapse (Garland & Heckbert): the edge whose collapse moves the surface least goes first, to the
    point nearest all its triangles' planes, until `target` triangles are left. Round links stay round (the grid
    clustering it replaced left them lumpy), the edges between colours (the grey bands) and open edges stay put,
    and no collapse is allowed to turn a triangle over."""
    import heapq
    V = vertices.astype(np.float64).copy()
    F = faces.astype(np.int64).copy()
    alive = np.ones(len(F), bool)
    gone = np.zeros(len(V), bool)
    version = np.zeros(len(V), np.int64)
    a, b, c = V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]
    cross = np.cross(b - a, c - a)
    area = np.linalg.norm(cross, axis=1)
    normals = cross / np.maximum(area, 1e-12)[:, None]
    Q = np.zeros((len(V), 4, 4))
    for f in range(len(F)):
        quadric = _plane_quadric(normals[f], a[f], area[f] / 2.0)
        for v in F[f]:
            Q[v] += quadric
    # open edges and the edges between two colours: held by planes standing on them, heavily weighted
    edge_faces: dict = {}
    for f, (i, j, k) in enumerate(F):
        for u, w in ((i, j), (j, k), (k, i)):
            edge_faces.setdefault((min(u, w), max(u, w)), []).append(f)
    for (u, w), around in edge_faces.items():
        seam = len(around) == 1 or (len(around) == 2 and not np.allclose(colours[around[0]], colours[around[1]]))
        if not seam:
            continue
        direction = V[w] - V[u]
        length = np.linalg.norm(direction)
        for f in around:
            side = np.cross(direction, normals[f])
            if np.linalg.norm(side) < 1e-12:
                continue
            quadric = _plane_quadric(side / np.linalg.norm(side), V[u], 1000.0 * length * length)
            Q[u] += quadric
            Q[w] += quadric
    vertex_faces = [set() for _ in range(len(V))]
    for f, tri in enumerate(F):
        for v in tri:
            vertex_faces[v].add(f)

    def neighbours(v: int) -> set:
        out = set()
        for f in vertex_faces[v]:
            out.update(int(x) for x in F[f])
        out.discard(v)
        return out

    def best(u: int, w: int):
        q = Q[u] + Q[w]
        candidates = [V[u], V[w], (V[u] + V[w]) / 2.0]
        try:
            if abs(np.linalg.det(q[:3, :3])) > 1e-9:
                point = np.linalg.solve(q[:3, :3], -q[:3, 3])
                if np.linalg.norm(point - candidates[2]) < 2.0 * np.linalg.norm(V[u] - V[w]) + 1e-6:
                    candidates.append(point)
        except np.linalg.LinAlgError:
            pass
        errors = [float(np.append(p, 1.0) @ q @ np.append(p, 1.0)) for p in candidates]
        k = int(np.argmin(errors))
        return errors[k], candidates[k]

    heap = []

    def push(u: int, w: int) -> None:
        u, w = min(u, w), max(u, w)
        error, point = best(u, w)
        heapq.heappush(heap, (error, u, w, int(version[u]), int(version[w]), tuple(point)))

    for (u, w) in edge_faces:
        push(u, w)
    count = int(alive.sum())
    while count > target and heap:
        error, u, w, vu, vw, point = heapq.heappop(heap)
        if gone[u] or gone[w] or version[u] != vu or version[w] != vw:
            continue
        shared = vertex_faces[u] & vertex_faces[w]
        if not shared or len(neighbours(u) & neighbours(w)) > 2:     # not an edge any more / would pinch the surface
            continue
        point = np.array(point)
        flips = False
        for f in (vertex_faces[u] | vertex_faces[w]) - shared:
            tri = [point if v in (u, w) else V[v] for v in F[f]]
            n = np.cross(tri[1] - tri[0], tri[2] - tri[0])
            length = np.linalg.norm(n)
            if length < 1e-9 or (n / length) @ normals[f] < 0.2:
                flips = True
                break
        if flips:
            continue
        V[u] = point
        Q[u] += Q[w]
        gone[w] = True
        version[u] += 1
        for f in shared:
            alive[f] = False
            count -= 1
            for v in F[f]:
                vertex_faces[v].discard(f)
        for f in list(vertex_faces[w]):
            F[f][F[f] == w] = u
            vertex_faces[u].add(f)
            tri = V[F[f]]
            n = np.cross(tri[1] - tri[0], tri[2] - tri[0])
            normals[f] = n / max(np.linalg.norm(n), 1e-12)
        vertex_faces[w] = set()
        for f in vertex_faces[u]:
            tri = V[F[f]]
            n = np.cross(tri[1] - tri[0], tri[2] - tri[0])
            normals[f] = n / max(np.linalg.norm(n), 1e-12)
        for v in neighbours(u):
            push(u, v)
    F, colours = F[alive], colours[alive]
    used = np.unique(F)
    remap = np.full(len(V), -1, np.int64)
    remap[used] = np.arange(used.size)
    return V[used], remap[F], colours


CREASE_DEG = 40.0   # smooth shading across edges gentler than this; sharper ones (a link's end face) stay sharp


def shading_normals(vertices: np.ndarray, faces: np.ndarray) -> np.ndarray:
    """Each triangle's corner normals (F,3,3) for the light: at each corner, the mean of the triangles round it on
    the same side of a crease (meeting this one at less than CREASE_DEG). The 3D view blends them across the
    triangle, pixel by pixel, so a round link looks round; a crease (a link's end face) stays sharp."""
    a, b, c = vertices[faces[:, 0]], vertices[faces[:, 1]], vertices[faces[:, 2]]
    cross = np.cross(b - a, c - a)
    flat = cross / np.maximum(np.linalg.norm(cross, axis=1), 1e-12)[:, None]
    around = [[] for _ in range(len(vertices))]
    for f, tri in enumerate(faces):
        for v in tri:
            around[v].append(f)
    limit = np.cos(np.radians(CREASE_DEG))
    out = np.zeros((len(faces), 3, 3))
    for f, tri in enumerate(faces):
        for k, v in enumerate(tri):
            near = np.array(around[v])
            same_side = near[flat[near] @ flat[f] > limit]
            corner = cross[same_side].sum(axis=0)        # area-weighted
            out[f, k] = corner / max(np.linalg.norm(corner), 1e-12)
    return out


def main() -> None:
    OUT.mkdir(exist_ok=True)
    total = 0
    for name, (file, target) in PARTS.items():
        triangles, colours = read_dae(ASSETS / file)
        triangles = triangles * 1000.0                         # metres -> mm
        colours = np.where(colours.sum(axis=1, keepdims=True) < 0.05, BLACK_LIFT, colours)
        vertices, faces, colours = weld(triangles, colours)
        vertices, faces, colours = decimate(vertices, faces, colours, target)
        normals = shading_normals(vertices, faces)
        np.savez_compressed(OUT / f"{name}.npz", vertices=vertices.astype(np.float32), faces=faces.astype(np.int32),
                            colors=colours.astype(np.float32), corner_normals=normals.astype(np.float32))
        total += len(faces)
        print(f"{name:20s} {len(triangles):6d} -> {len(faces):5d} triangles", flush=True)
    print("in all:", total)


if __name__ == "__main__":
    main()

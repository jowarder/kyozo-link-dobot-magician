"""The UFACTORY xArm 6 (1305) with the xArm Gripper: where every part is for given joint angles, and the joint angles
that put the gripper's tool point at a spot, pointing straight down at the table (as the Dobot's tool always is).

From UFACTORY's own description (assets/, xArm-Developer/xarm_ros2, BSD licence): the joints' offsets and turns
(xarm6_default_kinematics.yaml), their limits (xarm6.urdf.xacro), and the gripper's linkage and tool point
(xarm_gripper.urdf.xacro). Millimetres and radians; the robot's frame as the Dobot's: x out from the base, z up,
the base standing on the table at z = 0.
"""
from __future__ import annotations

import math
from functools import lru_cache
from pathlib import Path
from typing import Optional

import numpy as np

HERE = Path(__file__).resolve().parent
MESH_DIR = HERE / "meshes"

# joint i: from the previous link's frame, move by xyz then turn by rpy; it then turns about its own z.
# (xarm6_default_kinematics.yaml, metres there)
JOINTS = (
    ((0.0, 0.0, 267.0), (0.0, 0.0, 0.0)),
    ((0.0, 0.0, 0.0), (-1.5708, 0.0, 0.0)),
    ((53.5, -284.5, 0.0), (0.0, 0.0, 0.0)),
    ((77.5, 342.5, 0.0), (-1.5708, 0.0, 0.0)),
    ((0.0, 0.0, 0.0), (1.5708, 0.0, 0.0)),
    ((76.0, 97.0, 0.0), (-1.5708, 0.0, 0.0)),
)
LIMITS = ((-2 * math.pi, 2 * math.pi), (-2.059, 2.0944), (-3.927, 0.19198),
          (-2 * math.pi, 2 * math.pi), (-1.69297, math.pi), (-2 * math.pi, 2 * math.pi))
TCP_MM = 172.0           # the gripper's tool point below its mount (link6), along the tool's axis
GRIPPER_OPEN, GRIPPER_CLOSED = 0.0, 0.85     # the gripper's drive joint (rad); see jaw_gap_mm for the gap
LINKS = ("link_base", "link1", "link2", "link3", "link4", "link5", "link6")
GRIPPER_PARTS = ("gripper_base", "left_outer_knuckle", "left_inner_knuckle", "left_finger",
                 "right_outer_knuckle", "right_inner_knuckle", "right_finger")
# the gripper's linkage (xarm_gripper.urdf.xacro): (part, parent, xyz in mm, axis sign about x)
_GRIPPER_JOINTS = (
    ("left_outer_knuckle", "gripper_base", (0.0, 35.0, 59.098), 1.0),
    ("left_finger", "left_outer_knuckle", (0.0, 35.465, 42.039), -1.0),
    ("left_inner_knuckle", "gripper_base", (0.0, 20.0, 74.098), 1.0),
    ("right_outer_knuckle", "gripper_base", (0.0, -35.0, 59.098), -1.0),
    ("right_finger", "right_outer_knuckle", (0.0, -35.465, 42.039), 1.0),
    ("right_inner_knuckle", "gripper_base", (0.0, -20.0, 74.098), -1.0),
)


def _rot_x(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1.0]])


def _rot_y(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1.0]])


def _rot_z(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1.0]])


def _move(x: float, y: float, z: float) -> np.ndarray:
    m = np.eye(4)
    m[:3, 3] = (x, y, z)
    return m


_FIXED = [_move(*xyz) @ _rot_z(rpy[2]) @ _rot_y(rpy[1]) @ _rot_x(rpy[0]) for xyz, rpy in JOINTS]


def link_transforms(q) -> dict[str, np.ndarray]:
    """Each link's frame in the robot's frame (4x4, mm) for joint angles q (6, radians)."""
    frames = {"link_base": np.eye(4)}
    m = np.eye(4)
    for i in range(6):
        m = m @ _FIXED[i] @ _rot_z(float(q[i]))
        frames[f"link{i + 1}"] = m
    return frames


def tool_frame(q) -> np.ndarray:
    """The gripper's tool point (between the fingertips) and its axes, 4x4: its z axis points out of the gripper."""
    return link_transforms(q)["link6"] @ _move(0.0, 0.0, TCP_MM)


def gripper_transforms(link6: np.ndarray, drive: float) -> dict[str, np.ndarray]:
    frames = {"gripper_base": link6}
    for part, parent, xyz, sign in _GRIPPER_JOINTS:
        frames[part] = frames[parent] @ _move(*xyz) @ _rot_x(sign * drive)
    return frames


# ---- inverse kinematics: the tool pointing straight down -------------------------------------------------------------
# With J4 at zero the arm works in one vertical plane (its offsets are all in that plane), and the tool points straight
# down when J5 = -(J2 + J3). In that plane (u out from the base, v up), as complex numbers u + iv, from the shoulder
# (J2, at SHOULDER_MM up): the upper arm is UPPER e^(-i J2), the forearm FORE e^(-i (J2 + J3)), and the wrist to the
# tool point WRIST_TO_TCP (pointing down, it doesn't turn). So the tool point fixes where the wrist is, and the upper
# arm and forearm are a two-link arm to it: a closed form, a few microseconds (the planner asks thousands of times).
SHOULDER_MM = JOINTS[0][0][2]
UPPER = complex(JOINTS[2][0][0], -JOINTS[2][0][1])            # 53.5 + 284.5i
FORE = complex(JOINTS[3][0][0], -JOINTS[3][0][1])             # 77.5 - 342.5i
WRIST_TO_TCP = complex(JOINTS[5][0][0], -(JOINTS[5][0][1] + TCP_MM))   # 76 - 269i
_ALPHA = math.atan2((UPPER * FORE.conjugate()).imag, (UPPER * FORE.conjugate()).real)


def _down(yaw: float) -> np.ndarray:
    """The tool's axes when pointing straight down, turned by `yaw` about the vertical: x along yaw, z down."""
    c, s = math.cos(yaw), math.sin(yaw)
    return np.array([[c, s, 0.0], [s, -c, 0.0], [0.0, 0.0, -1.0]])


def solve(x: float, y: float, z: float, yaw_deg: float, seed=None) -> Optional[np.ndarray]:
    """Joint angles (6, radians) that put the tool point at (x, y, z) mm pointing straight down, turned by yaw
    (degrees, about the vertical, as the Dobot's r), within the joint limits; None if it can't."""
    q, ok = reach(x, y, z, yaw_deg, seed)
    return q if ok else None


def reach(x: float, y: float, z: float, yaw_deg: float, seed=None) -> tuple[np.ndarray, bool]:
    """(joint angles, whether they get there): as solve, but out of reach the arm stretched toward the spot (as the
    Dobot's twin draws an unreachable target), its joints kept within their limits. Elbow up; the one nearer `seed`
    when both are. J6 the turn nearest the seed's."""
    radius = math.hypot(x, y)
    base = math.atan2(y, x) if radius > 1e-6 else (float(seed[0]) if seed is not None else 0.0)
    wrist = complex(radius, z - SHOULDER_MM) - WRIST_TO_TCP
    distance = abs(wrist)
    a, b = abs(UPPER), abs(FORE)
    cosine = (distance ** 2 - a * a - b * b) / (2 * a * b)
    ok = -1.0 <= cosine <= 1.0
    cosine = max(-1.0, min(1.0, cosine))
    if distance < 1e-6:
        wrist, distance = complex(1e-6, 0.0), 1e-6
    candidates = []
    for bend in (math.acos(cosine), -math.acos(cosine)):
        q3 = _wrap(bend - _ALPHA)
        arm = UPPER + FORE * complex(math.cos(-q3), math.sin(-q3))
        q2 = _wrap(math.atan2(arm.imag, arm.real) - math.atan2(wrist.imag, wrist.real))
        q = np.array([base, q2, q3, 0.0, -(q2 + q3), 0.0])
        q[5] = _tool_turn(q, math.radians(yaw_deg), None if seed is None else float(seed[5]))
        candidates.append(q)
    fits = [q for q in candidates if within_limits(q)]
    if fits:
        if seed is not None and len(fits) > 1:
            fits.sort(key=lambda q: float(np.abs(q - np.asarray(seed, float)).sum()))
        else:
            fits.sort(key=lambda q: -q[2])     # elbow up: the forearm less folded back
        return fits[0], ok
    q = candidates[0]
    return np.array([min(max(float(v), low), high) for v, (low, high) in zip(q, LIMITS)]), False


def _tool_turn(q: np.ndarray, yaw: float, near: Optional[float]) -> float:
    """J6 that turns the tool (pointing down) to `yaw`: pointing down, J6 turns it the other way round from J1."""
    turn = _wrap(q[0] - yaw)
    if near is not None:
        turn += 2 * math.pi * round((near - turn) / (2 * math.pi))
        low, high = LIMITS[5]
        while turn > high:
            turn -= 2 * math.pi
        while turn < low:
            turn += 2 * math.pi
    return turn


def _wrap(a: float) -> float:
    return (a + math.pi) % (2 * math.pi) - math.pi


def within_limits(q) -> bool:
    return all(low <= float(v) <= high for v, (low, high) in zip(q, LIMITS))


# ---- drawing ----------------------------------------------------------------------------------------------------------
@lru_cache(maxsize=1)
def load_parts() -> Optional[dict]:
    parts = {}
    for name in LINKS + GRIPPER_PARTS:
        path = MESH_DIR / f"{name}.npz"
        if not path.exists():
            return None
        with np.load(path) as data:
            faces = data["faces"].astype(np.int64)
            normals = data["corner_normals"].astype(np.float64) if "corner_normals" in data else None   # (F,3,3)
            parts[name] = (data["vertices"].astype(np.float64), faces, data["colors"].astype(np.float64), normals)
    return parts


def posed_triangles(q, drive: float = GRIPPER_OPEN) -> Optional[tuple]:
    """(triangles (N,3,3) mm, colours (N,3), is_tool (N,) bool, corner normals (N,3,3) or None) for the arm at joints
    q, the gripper at `drive`. The corner normals are each triangle's smoothed corner normals (build_meshes.shading_normals),
    turned with its part: the 3D view blends them across each triangle, so round links look round, not faceted."""
    parts = load_parts()
    if parts is None:
        return None
    frames = link_transforms(q)
    frames.update(gripper_transforms(frames["link6"], drive))
    triangles, colours, tool, shading = [], [], [], []
    for name, (vertices, faces, part_colours, normals) in parts.items():
        m = frames[name]
        world = vertices @ m[:3, :3].T + m[:3, 3]
        triangles.append(world[faces])
        colours.append(part_colours)
        tool.append(np.full(len(faces), name in GRIPPER_PARTS))
        shading.append(normals @ m[:3, :3].T if normals is not None else None)       # (F,3,3): turned with the part
    normals = None if any(n is None for n in shading) else np.concatenate(shading)
    return np.concatenate(triangles), np.concatenate(colours), np.concatenate(tool), normals

"""PyBullet world setup for demo mode: physics client, ground plane, and scenario objects."""
from __future__ import annotations

import json
import logging
import math
import tempfile
import threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

try:
    import pybullet as p
    import pybullet_data
except ImportError:  # pragma: no cover
    p = None

SCENARIOS_DIR = Path(__file__).parent / "scenarios"

# PyBullet's client API isn't thread-safe. Robot moves run on worker threads while the
# camera feed and the twin view render on the UI thread, so all of them take this lock.
pybullet_lock = threading.RLock()

TRAY_FLOOR_MM = 4.0
TRAY_WALL_MM = 4.0
# The demo's own safety box: config.yaml's workspace_bounds are the real arm's (set for its table, its camera mount),
# and taken for the demo too, an X max of 268 there put the demo's tray "out of reach"
DEMO_WORKSPACE_BOUNDS = {"x": [-300.0, 307.0], "y": [-300.0, 300.0], "z": [0.0, 300.0]}


def demo_workspace_bounds() -> dict:
    return {axis: list(limits) for axis, limits in DEMO_WORKSPACE_BOUNDS.items()}
TABLE_SIDE_RGBA = [0.04, 0.09, 0.10, 1]
REACH_MM = 300.0  # the dashed reach arc on the table; matches max_reach_mm in config.yaml
TABLE_TOP_RGBA = [0.08, 0.17, 0.18, 1]
GRID_MINOR_RGBA = [0.17, 0.33, 0.35, 1]
GRID_MAJOR_RGBA = [0.32, 0.58, 0.61, 1]
GRID_ARC_RGBA = [0.62, 0.78, 0.80, 1]
MINOR_WIDTH_MM, MAJOR_WIDTH_MM = 1.6, 3.0
GRID_HEIGHT_M = 0.0003   # just above the table top so the strips never fight it for the pixel


def _strip(a: tuple[float, float], b: tuple[float, float], width_mm: float) -> list[tuple[float, float]]:
    """Corners (mm, counter-clockwise from above) of a flat strip from a to b."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / length * width_mm / 2, dx / length * width_mm / 2
    return [(a[0] + nx, a[1] + ny), (a[0] - nx, a[1] - ny), (b[0] - nx, b[1] - ny), (b[0] + nx, b[1] + ny)]


def _write_flat_mesh(name: str, quads: list[list[tuple[float, float]]]) -> str:
    """An OBJ of flat quads facing up (coordinates in mm, written in metres)."""
    lines = ["vn 0 0 1"]
    for i, quad in enumerate(quads):
        lines += [f"v {x / 1000:.6f} {y / 1000:.6f} {GRID_HEIGHT_M}" for x, y in quad]
        base = 4 * i + 1
        lines += [f"f {base}//1 {base + 1}//1 {base + 2}//1", f"f {base}//1 {base + 2}//1 {base + 3}//1"]
    path = Path(tempfile.gettempdir()) / f"dobot_twin_grid_{name}.obj"
    path.write_text("\n".join(lines) + "\n")
    return str(path)


class TwinWorld:
    def __init__(self, gui: bool = False):
        if p is None:
            raise RuntimeError("pybullet is not installed. Run `pip install pybullet`.")
        self.gui = gui
        self.client: Optional[int] = None
        self.object_ids: dict[str, int] = {}
        self.object_meta: dict[str, dict] = {}  # label + resting height per object id
        self.scenario: dict = {}                 # the scene now loaded (name, description, objects, places)

    def start(self) -> int:
        self.client = p.connect(p.GUI if self.gui else p.DIRECT)
        p.setAdditionalSearchPath(pybullet_data.getDataPath(), physicsClientId=self.client)
        p.setGravity(0, 0, -9.8, physicsClientId=self.client)
        # No floor plane: nothing is ever stepped by the physics engine (objects are placed
        # directly), so the table is purely visual -- a gridded top over a dark slab, the same
        # footprint as the 3D view's table (x -80..380, y -320..320 mm, top at z = 0).
        mat_w, mat_d = 0.46, 0.64  # metres (x, y)
        mat_thickness, slab_thickness = 0.0012, 0.014
        centre_x = 0.15
        mat_shape = p.createVisualShape(p.GEOM_BOX, halfExtents=[mat_w / 2, mat_d / 2, mat_thickness / 2],
                                        rgbaColor=TABLE_TOP_RGBA, physicsClientId=self.client)
        mat = p.createMultiBody(baseMass=0, baseVisualShapeIndex=mat_shape,
                                basePosition=[centre_x, 0.0, -mat_thickness / 2], physicsClientId=self.client)
        slab_shape = p.createVisualShape(p.GEOM_BOX, halfExtents=[mat_w / 2, mat_d / 2, slab_thickness / 2],
                                         rgbaColor=TABLE_SIDE_RGBA, physicsClientId=self.client)
        p.createMultiBody(baseMass=0, baseVisualShapeIndex=slab_shape,
                          basePosition=[centre_x, 0.0, -mat_thickness - slab_thickness / 2],
                          physicsClientId=self.client)
        self._add_grid_lines()
        if self.gui:
            # Frame the workbench (robot sits at the origin, objects are ~200-300mm out
            # in +X) instead of pybullet's default zoomed-out/off-center view.
            p.resetDebugVisualizerCamera(
                cameraDistance=0.6, cameraYaw=45, cameraPitch=-40,
                cameraTargetPosition=[0.2, 0, 0.05], physicsClientId=self.client,
            )
        return self.client

    def _add_grid_lines(self) -> None:
        """The table's grid, as thin flat strips: a line every 20 mm, a brighter one every
        100 mm, and a dashed arc for the arm's reach. Geometry rather than a texture because
        the renderer resamples textures coarsely and loses fine lines. The hue is kept between
        the detector's green and blue ranges so the table is never mistaken for a cube."""
        x0, x1, y0, y1 = -80.0, 380.0, -320.0, 320.0
        minor, major, arc = [], [], []
        for x in range(int(x0), int(x1) + 1, 20):
            (major if x % 100 == 0 else minor).append(_strip((x, y0), (x, y1), MINOR_WIDTH_MM if x % 100 else MAJOR_WIDTH_MM))
        for y in range(int(y0), int(y1) + 1, 20):
            (major if y % 100 == 0 else minor).append(_strip((x0, y), (x1, y), MINOR_WIDTH_MM if y % 100 else MAJOR_WIDTH_MM))
        for start in range(-100, 100, 6):  # dashes of 3.5 degrees about the robot base
            points = [(REACH_MM * math.cos(math.radians(start + 3.5 * k / 3)),
                       REACH_MM * math.sin(math.radians(start + 3.5 * k / 3))) for k in range(4)]
            arc.extend(_strip(a, b, MAJOR_WIDTH_MM) for a, b in zip(points, points[1:]))
        for name, quads, colour in (("minor", minor, GRID_MINOR_RGBA), ("major", major, GRID_MAJOR_RGBA),
                                    ("arc", arc, GRID_ARC_RGBA)):
            path = _write_flat_mesh(name, quads)
            visual = p.createVisualShape(p.GEOM_MESH, fileName=path, rgbaColor=colour, physicsClientId=self.client)
            p.createMultiBody(baseMass=0, baseVisualShapeIndex=visual, basePosition=[0, 0, 0],
                              physicsClientId=self.client)

    def stop(self) -> None:
        if self.client is not None:
            p.disconnect(physicsClientId=self.client)
            self.client = None

    def load_scenario(self, name: str) -> dict:
        path = SCENARIOS_DIR / f"{name}.json"
        with open(path, "r", encoding="utf-8") as f:
            scenario = json.load(f)
        return self.load_scenario_data(scenario, name)

    def load_scenario_data(self, scenario: dict, name: str = "custom") -> dict:
        """A scene given as a dict (the scene-file format), not read from a file: e.g. the calibration walk-through's,
        with the cube size chosen."""
        scenario = _moved_out(scenario)
        with pybullet_lock:
            for obj in scenario.get("objects", []):
                self._spawn_object(obj)
        self.scenario = dict(scenario, name=scenario.get("name", name))
        return scenario

    def switch_scenario(self, name: str, data: Optional[dict] = None) -> dict:
        """Take every object off the table and set out another scene (or the same one again, as it
        started); `data`: the scene itself, rather than the file `name`. The robot keeps its place; whoever calls this
        makes sure it isn't holding anything."""
        with pybullet_lock:
            for body in self.object_ids.values():
                p.removeBody(body, physicsClientId=self.client)
            self.object_ids.clear()
            self.object_meta.clear()
            return self.load_scenario_data(data, name) if data is not None else self.load_scenario(name)

    def add_object(self, obj: dict) -> None:
        """Put one more object on the table (scene-file format, robot coordinates): taken away again with the scene."""
        with pybullet_lock:
            self._spawn_object(obj)

    def set_object_position_mm(self, object_id: str, x_mm: float, y_mm: float, z_mm: float,
                               yaw_deg: float = 0.0) -> None:
        """Put an object straight at (x, y, z centre), standing on the table turned `yaw_deg` (a shuffle)."""
        with pybullet_lock:
            p.resetBasePositionAndOrientation(self.object_ids[object_id], [x_mm / 1000.0, y_mm / 1000.0, z_mm / 1000.0],
                                              p.getQuaternionFromEuler([0, 0, math.radians(yaw_deg)]),
                                              physicsClientId=self.client)

    def get_object_yaw_deg(self, object_id: str) -> float:
        """How far the object is turned about the vertical, in degrees."""
        with pybullet_lock:
            _, orientation = p.getBasePositionAndOrientation(self.object_ids[object_id], physicsClientId=self.client)
        return math.degrees(p.getEulerFromQuaternion(orientation)[2])

    def places(self) -> dict[str, tuple[float, float, float]]:
        """The scene's named drop-off places (a tray, bins...): name -> (x, y, z) mm, z being the surface there (a
        tray's floor, the table): the tools let go with the held object's bottom just above it."""
        return {str(name).lower(): tuple(float(v) for v in xyz) for name, xyz in self.scenario.get("places", {}).items()}

    def _spawn_object(self, obj: dict) -> None:
        size = obj.get("size_mm", 25)
        width, depth, height = (size, size, size) if isinstance(size, (int, float)) else size
        pos_mm = obj["position_mm"]
        pos_m = [pos_mm[0] / 1000.0, pos_mm[1] / 1000.0, pos_mm[2] / 1000.0]
        color = obj.get("color_rgba", [1, 0, 0, 1])

        if obj.get("shape") == "tray":
            body_id = self._spawn_tray(pos_m, width / 1000.0, depth / 1000.0, height / 1000.0, color)
            # the tray body's position is the middle of its 4 mm floor, so the floor's top
            # (where a dropped cube rests) is half the floor thickness above it
            meta = {"label": obj.get("label", ""), "size": (width, depth, height),
                    "top_from_pos_mm": TRAY_FLOOR_MM / 2.0}
        else:
            shape = obj.get("shape", "cube")
            if shape == "ball":                    # size_mm: its diameter
                radius = width / 2000.0
                col = p.createCollisionShape(p.GEOM_SPHERE, radius=radius, physicsClientId=self.client)
                vis = p.createVisualShape(p.GEOM_SPHERE, radius=radius, rgbaColor=color, physicsClientId=self.client)
            elif shape == "cylinder":              # size_mm: [diameter, diameter, height], standing up
                radius, length = width / 2000.0, height / 1000.0
                col = p.createCollisionShape(p.GEOM_CYLINDER, radius=radius, height=length, physicsClientId=self.client)
                vis = p.createVisualShape(p.GEOM_CYLINDER, radius=radius, length=length, rgbaColor=color,
                                          physicsClientId=self.client)
            else:
                half = [width / 2000.0, depth / 2000.0, height / 2000.0]
                col = p.createCollisionShape(p.GEOM_BOX, halfExtents=half, physicsClientId=self.client)
                vis = p.createVisualShape(p.GEOM_BOX, halfExtents=half, rgbaColor=color,
                                           physicsClientId=self.client)
            body_id = p.createMultiBody(
                baseMass=0.01, baseCollisionShapeIndex=col, baseVisualShapeIndex=vis, basePosition=pos_m,
                baseOrientation=p.getQuaternionFromEuler([0, 0, math.radians(float(obj.get("yaw_deg", 0.0)))]),
                physicsClientId=self.client,
            )
            # cube positions are their centres, so the top is half a height above
            meta = {"label": obj.get("label", ""), "size": (width, depth, height),
                    "top_from_pos_mm": height / 2.0}
        meta["color"] = tuple(color[:3])
        meta["shape"] = obj.get("shape", "cube")
        self.object_ids[obj["id"]] = body_id
        self.object_meta[obj["id"]] = meta
        logger.info("Spawned %s (%s) at %s mm", obj["id"], obj.get("label"), pos_mm)

    def _spawn_tray(self, pos_m: list[float], w: float, d: float, h: float, color: list[float]) -> int:
        """A flat floor with four low walls, built as one body (walls are fixed links)."""
        floor_h = TRAY_FLOOR_MM / 1000.0
        wall_t = TRAY_WALL_MM / 1000.0
        floor_vis = p.createVisualShape(p.GEOM_BOX, halfExtents=[w / 2, d / 2, floor_h / 2],
                                         rgbaColor=color, physicsClientId=self.client)
        dark = [c * 0.8 for c in color[:3]] + [1]
        long_wall = p.createVisualShape(p.GEOM_BOX, halfExtents=[w / 2, wall_t / 2, h / 2],
                                         rgbaColor=dark, physicsClientId=self.client)
        short_wall = p.createVisualShape(p.GEOM_BOX, halfExtents=[wall_t / 2, d / 2, h / 2],
                                          rgbaColor=dark, physicsClientId=self.client)
        wall_z = (h - floor_h) / 2 + floor_h / 2
        return p.createMultiBody(
            baseMass=0, baseVisualShapeIndex=floor_vis,
            basePosition=[pos_m[0], pos_m[1], pos_m[2] + floor_h / 2],
            linkMasses=[0] * 4, linkCollisionShapeIndices=[-1] * 4,
            linkVisualShapeIndices=[long_wall, long_wall, short_wall, short_wall],
            linkPositions=[[0, d / 2, wall_z], [0, -d / 2, wall_z], [w / 2, 0, wall_z], [-w / 2, 0, wall_z]],
            linkOrientations=[[0, 0, 0, 1]] * 4, linkInertialFramePositions=[[0, 0, 0]] * 4,
            linkInertialFrameOrientations=[[0, 0, 0, 1]] * 4, linkParentIndices=[0] * 4,
            linkJointTypes=[p.JOINT_FIXED] * 4, linkJointAxis=[[0, 0, 1]] * 4,
            physicsClientId=self.client,
        )

    def snapshot(self) -> list[dict]:
        """Everything the 3D view needs to draw the objects, in one consistent read (nothing, once the world is shut
        down: a window still open after the main one closed draws an empty table, not an error a few times a second)."""
        items = []
        # (under the lock the scene is changed under: the watcher sets the cubes out on a thread of its own while
        # this window draws them -- "dictionary changed size during iteration")
        with pybullet_lock:
            if self.client is None:
                return items
            for object_id, meta in list(self.object_meta.items()):
                x, y, z = self.get_object_position_mm(object_id)
                items.append({"id": object_id, "label": meta["label"], "pos": (x, y, z),
                              "size": meta["size"], "color": meta["color"], "shape": meta["shape"],
                              "yaw": round(self.get_object_yaw_deg(object_id), 2) if meta["shape"] != "tray" else 0.0})
        return items

    def resting_height_mm(self, object_id: str, x_mm: float, y_mm: float) -> float:
        """Centre height an object settles at if released at (x, y): on the floor, or on top of what holds it up --
        something under its middle (another cube, the tray's floor). Only touching one by its edge used to count
        too: let go 3 mm over a cube's edge, a cube "rested" on it, hanging almost wholly in the air beside it (a
        real one tips off). See settle() for where it ends up then."""
        width, depth, height = self._spread(object_id)
        rest = height / 2.0
        # a bridge: nothing under its middle, but held up at both ends (a bar laid across two cubes with a gap
        # between): what is under it on both sides of its middle, along its long side
        long_x = width >= depth
        before, after = [], []
        for other_id, other in list(self.object_meta.items()):
            if other_id == object_id:
                continue
            ox, oy, oz = self.get_object_position_mm(other_id)
            other_w, other_d, _ = self._spread(other_id)
            top = oz + other["top_from_pos_mm"]
            under_its_middle = abs(x_mm - ox) <= other_w / 2 and abs(y_mm - oy) <= other_d / 2
            if under_its_middle:
                rest = max(rest, top + height / 2.0)
                continue
            if other["shape"] == "tray":
                continue
            under_it = (abs(x_mm - ox) < (width + other_w) / 2 - 1.0 and abs(y_mm - oy) < (depth + other_d) / 2 - 1.0)
            if under_it:
                (before if (ox < x_mm if long_x else oy < y_mm) else after).append(top)
        if before and after:
            rest = max(rest, min(max(before), max(after)) + height / 2.0)
        return rest

    def settle(self, object_id: str, x_mm: float, y_mm: float) -> tuple[float, float, float]:
        """Where an object let go over (x, y) ends up: on what holds it up (resting_height_mm), and if it would then
        be partly inside something beside it (let go over an edge), tipped off to the side, clear of it."""
        width, depth, height = self._spread(object_id)
        for _ in range(4):
            z = self.resting_height_mm(object_id, x_mm, y_mm)
            moved = False
            for other_id, other in list(self.object_meta.items()):
                if other_id == object_id or other["shape"] == "tray":
                    continue
                ox, oy, oz = self.get_object_position_mm(other_id)
                other_w, other_d, other_h = self._spread(other_id)
                if oz + other_h / 2 <= z - height / 2 + 0.5 or oz - other_h / 2 >= z + height / 2 - 0.5:
                    continue                       # below it (what it stands on) or above it
                over_x = (width + other_w) / 2 - abs(x_mm - ox)
                over_y = (depth + other_d) / 2 - abs(y_mm - oy)
                if over_x <= 0 or over_y <= 0:
                    continue
                if over_x < over_y:
                    x_mm += (over_x + 1.0) * (1.0 if x_mm >= ox else -1.0)
                else:
                    y_mm += (over_y + 1.0) * (1.0 if y_mm >= oy else -1.0)
                moved = True
            if not moved:
                return x_mm, y_mm, z
        return x_mm, y_mm, self.resting_height_mm(object_id, x_mm, y_mm)

    def place_areas(self) -> dict[str, tuple[float, float, float]]:
        """For each place that is a tray or bin: its inside, (width, depth, height of the walls' top), mm -- where
        things can be put down side by side. A place on the bare table (a tower spot) has none."""
        areas = {}
        for name, (x, y, _) in self.places().items():
            for object_id, meta in list(self.object_meta.items()):
                if meta["shape"] != "tray":
                    continue
                ox, oy, oz = self.get_object_position_mm(object_id)
                if math.hypot(ox - x, oy - y) <= 20.0:
                    width, depth, height = meta["size"]
                    areas[name] = (width - 2 * TRAY_WALL_MM, depth - 2 * TRAY_WALL_MM, height + TRAY_FLOOR_MM / 2)
        return areas

    def _spread(self, object_id: str) -> tuple[float, float, float]:
        """The object's extent along x and y as it is turned now (a cube turned 45 degrees spreads wider), and
        its height."""
        width, depth, height = self.object_meta[object_id]["size"]
        if self.object_meta[object_id]["shape"] in ("tray", "ball", "cylinder"):
            return width, depth, height          # (round: as wide whichever way it's turned)
        turn = math.radians(self.get_object_yaw_deg(object_id))
        c, s = abs(math.cos(turn)), abs(math.sin(turn))
        return width * c + depth * s, width * s + depth * c, height

    def get_object_position_mm(self, object_id: str) -> tuple[float, float, float]:
        body_id = self.object_ids[object_id]
        with pybullet_lock:
            pos, _ = p.getBasePositionAndOrientation(body_id, physicsClientId=self.client)
        return tuple(v * 1000.0 for v in pos)


def _moved_out(scenario: dict) -> dict:
    """The scene as set out for the robot this run drives: moved out from its base by its scene_offset_mm. The
    scenes are laid out for the Dobot (145-330 mm out); nearer than 200 mm the xArm's wrist would come down onto its
    own base, so for it the whole scene (and the camera, see SimCamera) is 120 mm further out."""
    from app import robots
    dx, dy = robots.active().scene_offset_mm
    if not dx and not dy:
        return scenario
    moved = dict(scenario)
    moved["objects"] = [dict(o, position_mm=[o["position_mm"][0] + dx, o["position_mm"][1] + dy,
                                             *o["position_mm"][2:]]) for o in scenario.get("objects", [])]
    moved["places"] = {name: [xyz[0] + dx, xyz[1] + dy, *xyz[2:]] for name, xyz in scenario.get("places", {}).items()}
    return moved


def list_scenarios() -> list[dict]:
    """Every scene in the scenarios folder: [{"name", "title", "description"}], in a stable order."""
    scenes = []
    for path in sorted(SCENARIOS_DIR.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("Ignoring the scene %s: %s", path.name, exc)
            continue
        scenes.append({"name": path.stem, "title": data.get("title", path.stem.replace("_", " ").capitalize()),
                       "description": data.get("description", "")})
    return scenes

"""Shuffle: the demo scene's objects set out somewhere new, at random, but always somewhere the robot can
work with them -- in reach, apart, clear of the bins, in the camera's view and not under the arm.

A layout is a number (the random seed): the same number always gives the same layout, so a layout that
made the model stumble can be brought back after a fix. Trays and bins stay where they are.
"""
from __future__ import annotations

import math
import random
from typing import Callable, Optional

from app import robots
from app.calibration.guidance import MIN_RADIUS_MM

INNER_MM = MIN_RADIUS_MM + 10.0   # a little clear of the no-go zone by the base
OUTER_MM = 270.0                  # a little inside the 300 mm reach limit
# (the Dobot's; a bigger arm sets them out further, see _ring: still only where the camera sees them)
MAX_TURN_DEG = 80.0               # the base turns about +-90 degrees: stay a little inside that
GAP_MM = 20.0                     # clear table between two objects: room for the gripper's fingers to open
TRAY_GAP_MM = 15.0                # clear table between an object and a tray or bin
PLACE_CLEARANCE_MM = 45.0         # from a named place's centre (a tower spot on bare table)
ARM_CLEARANCE_MM = 45.0           # from the point under the gripper
APPROACH_MM = 50.0                # picking comes down from this far above the top: that must be reachable too
TRIES_PER_OBJECT = 300
LAYOUT_ATTEMPTS = 25


def _footprint(obj: dict) -> tuple[float, float]:
    width, depth, _ = obj["size"]
    return width, depth


def _reachable(x: float, y: float, height: float) -> bool:
    robot = robots.active()
    return robot.within_limits(x, y, height) and robot.within_limits(x, y, height + APPROACH_MM)


def _ring() -> tuple[float, float]:
    """(nearest, farthest) from the base an object is set out, for this robot."""
    robot = robots.active()
    return max(INNER_MM, robot.min_radius_mm + 10.0), max(OUTER_MM, robot.max_reach_mm * 0.9 - 30.0)


MAX_OBJECT_TURN_DEG = 45.0        # objects are set down turned up to this much either way (a square looks the
                                  # same a quarter turn on, so this covers every way a cube can lie)


def shuffle_turns(object_ids, seed: int) -> dict[str, float]:
    """How far each object is turned in layout `seed`, degrees. Drawn from its own sequence, so adding the turns
    left every layout's positions as they were."""
    rng = random.Random(f"turns-{seed}")
    return {object_id: round(rng.uniform(-MAX_OBJECT_TURN_DEG, MAX_OBJECT_TURN_DEG), 1) for object_id in sorted(object_ids)}


def shuffle_layout(objects: list[dict], seed: int, places: dict, arm_xy: tuple[float, float],
                   visible: Callable[[float, float, float], bool]) -> Optional[dict[str, tuple[float, float, float]]]:
    """New positions {object id: (x, y, z centre)} for every object that isn't a tray, or None if no layout
    keeping every rule was found. `objects` as TwinWorld.snapshot() gives them, `places` as TwinWorld.places(),
    `visible(x, y, size)`: whether a cube of that size standing at (x, y) is fully in the camera's picture."""
    rng = random.Random(seed)
    trays = [o for o in objects if o["shape"] == "tray"]
    movable = sorted((o for o in objects if o["shape"] != "tray"), key=lambda o: -max(_footprint(o)))  # big first

    def fits(x: float, y: float, obj: dict, placed: list[tuple[float, float, dict]]) -> bool:
        width, depth = _footprint(obj)
        height = obj["size"][2]
        if not _reachable(x, y, height):
            return False
        if math.hypot(x - arm_xy[0], y - arm_xy[1]) < ARM_CLEARANCE_MM:
            return False
        for tray in trays:
            tx, ty, _ = tray["pos"]
            tw, td = _footprint(tray)
            if abs(x - tx) < (width + tw) / 2 + TRAY_GAP_MM and abs(y - ty) < (depth + td) / 2 + TRAY_GAP_MM:
                return False
        if any(math.hypot(x - px, y - py) < PLACE_CLEARANCE_MM for px, py, _ in places.values()):
            return False
        for ox, oy, other in placed:          # square objects: clear on at least one axis, by GAP_MM
            ow, od = _footprint(other)
            if abs(x - ox) < (width + ow) / 2 + GAP_MM and abs(y - oy) < (depth + od) / 2 + GAP_MM:
                return False
        return visible(x, y, max(width, depth))

    for _ in range(LAYOUT_ATTEMPTS):
        placed: list[tuple[float, float, dict]] = []
        for obj in movable:
            for _ in range(TRIES_PER_OBJECT):
                radius = rng.uniform(*_ring())
                angle = math.radians(rng.uniform(-MAX_TURN_DEG, MAX_TURN_DEG))
                x, y = round(radius * math.cos(angle), 1), round(radius * math.sin(angle), 1)   # checked as stored
                if fits(x, y, obj, placed):
                    placed.append((x, y, obj))
                    break
            else:
                break                          # this object found no room: start the whole layout again
        if len(placed) == len(movable):
            return {obj["id"]: (x, y, obj["size"][2] / 2.0) for x, y, obj in placed}
    return None

"""Arm geometry for the simulated Dobot Magician (DT-MG-4R005-02E).

Given the tool tip (TCP) position, works out where the shoulder, elbow, wrist and tool
are, so the 3D view and the simulated camera draw the same arm. The dimensions are the
Magician's own (the URDF in jkaniuka/magician_ros2, see magician_model.py); joint limits
are not modelled -- treat "reachable" as a rough guide, not the real robot's limits.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

Point = tuple[float, float, float]

SHOULDER_H = 131.305  # the shoulder (J2) axis above the bottom of the base = the table (mm)
L1 = 135.0            # rear arm
L2 = 147.0            # forearm
TOOL_FORWARD = 60.0   # wrist -> tool (J4) axis, horizontally outward
# wrist -> the tool point (TCP), straight down: the fingertips, 104.8 mm below the wrist. The pose's z is where
# the fingertips are, as the gripper's planning takes it (a grip at z = top - depth has them that far down the
# sides) and as calibration measures it (the tip touching the table). It was 89.8, 15 mm above the fingertips:
# the demo then drew the fingers 15 mm lower than they were taken to be -- into the cubes and the table.
TOOL_DROP = 104.8


@dataclass
class ArmGeometry:
    shoulder: Point
    elbow: Point
    wrist: Point
    tool_corner: Point   # end of the horizontal part of the tool, above the nozzle
    tcp: Point           # nozzle tip
    reachable: bool      # False if the requested position is beyond the arm's envelope


@dataclass
class JointAngles:
    """The Magician's four degrees of freedom, in degrees. The gripper/suction cup is an
    end effector, not a joint, and a parallelogram linkage keeps the tool pointing down, so
    there is no separate wrist joint."""
    base: float       # J1: rotation about the vertical axis (0 = straight ahead along +X)
    shoulder: float   # J2: rear arm, from straight up (0) to horizontal (90)
    elbow: float      # J3: the bend between rear arm and forearm
    tool: float       # J4: rotation of the end effector


def joint_angles(geometry: ArmGeometry, tool_rotation: float = 0.0) -> JointAngles:
    tx, ty, _ = geometry.tcp
    azimuth = math.atan2(ty, tx) if math.hypot(tx, ty) > 1e-6 else 0.0
    ux, uy = math.cos(azimuth), math.sin(azimuth)

    def in_plane(p: Point) -> tuple[float, float]:
        return p[0] * ux + p[1] * uy, p[2]

    sr, sz = in_plane(geometry.shoulder)
    er, ez = in_plane(geometry.elbow)
    wr, wz = in_plane(geometry.wrist)
    shoulder = math.degrees(math.atan2(er - sr, ez - sz))
    rear, fore = (sr - er, sz - ez), (wr - er, wz - ez)
    norms = math.hypot(*rear) * math.hypot(*fore)
    cos_elbow = (rear[0] * fore[0] + rear[1] * fore[1]) / norms if norms > 1e-9 else 1.0
    elbow = math.degrees(math.acos(max(-1.0, min(1.0, cos_elbow))))
    return JointAngles(base=math.degrees(azimuth), shoulder=shoulder, elbow=elbow,
                       tool=wrist_turn(math.degrees(azimuth), tool_rotation))


def arm_geometry(x: float, y: float, z: float, table_z: float = 0.0) -> ArmGeometry:
    """Where each part of the arm is with its tool point at (x, y, z). The model's heights are from the table its
    base stands on; `table_z`: the table's height in the frame of x, y, z (the real Dobot's zero is some 35 mm above
    the table), and the parts are given in that frame too."""
    if table_z:
        g = arm_geometry(x, y, z - table_z)
        up = lambda p: (p[0], p[1], p[2] + table_z)  # noqa: E731
        return ArmGeometry(shoulder=up(g.shoulder), elbow=up(g.elbow), wrist=up(g.wrist),
                           tool_corner=up(g.tool_corner), tcp=up(g.tcp), reachable=g.reachable)
    radius = math.hypot(x, y)
    azimuth = math.atan2(y, x) if radius > 1e-6 else 0.0
    ux, uy = math.cos(azimuth), math.sin(azimuth)

    # wrist target in the vertical plane through the arm: tool hangs off the wrist
    reach = radius - TOOL_FORWARD
    height = (z + TOOL_DROP) - SHOULDER_H
    dist = math.hypot(reach, height)
    lo, hi = abs(L1 - L2) + 1e-6, L1 + L2 - 1e-6
    reachable = lo < dist < hi
    d = min(max(dist, lo), hi)

    # two-link solution with the elbow up
    cos_gamma = max(-1.0, min(1.0, (L1 ** 2 + d ** 2 - L2 ** 2) / (2 * L1 * d)))
    shoulder_angle = math.atan2(height, reach) + math.acos(cos_gamma)
    elbow_r = L1 * math.cos(shoulder_angle)
    elbow_z = SHOULDER_H + L1 * math.sin(shoulder_angle)

    aim = math.atan2(height, reach)  # if unreachable the arm stretches toward the target
    wrist_r = d * math.cos(aim)
    wrist_z = SHOULDER_H + d * math.sin(aim)

    def at(r: float, zz: float) -> Point:
        return (r * ux, r * uy, zz)

    corner_r = wrist_r + TOOL_FORWARD
    return ArmGeometry(
        shoulder=(0.0, 0.0, SHOULDER_H),
        elbow=at(elbow_r, elbow_z),
        wrist=at(wrist_r, wrist_z),
        tool_corner=at(corner_r, wrist_z),
        tcp=at(corner_r, wrist_z - TOOL_DROP),
        reachable=reachable,
    )


# ---- the Dobot's own joint angles and limits --------------------------------------------------------------
# Published ranges for the Magician (spec sheet), in the Dobot's own conventions -- J2: rear arm from
# straight up, J3: forearm below horizontal (not the bend between the two), J4: the end effector's turn.
# A guide, not the controller's exact soft limits: they explain what the real arm did (it stopped near
# the base when high up, where J2 would have had to lean back past vertical), but check before relying
# on a single degree.
JOINT_LIMITS_DEG = {"J1": (-90.0, 90.0), "J2": (0.0, 85.0), "J3": (-10.0, 90.0), "J4": (-90.0, 90.0)}
NEAR_LIMIT_DEG = 5.0   # within this of a limit: warn


def wrist_turn(j1: float, r: float) -> float:
    """J4 from the pose's r. The Dobot's r is the end effector's turn on the table, J1 + J4: with r held,
    the controller turns J4 against J1 so the gripper keeps its direction while the base turns."""
    return r - j1


def dobot_joints(geometry: ArmGeometry, tool_rotation: float = 0.0) -> dict[str, float]:
    """J1-J4 in the Dobot's own conventions (see JOINT_LIMITS_DEG), from the arm's geometry and the
    pose's r (`tool_rotation`, the end effector's turn on the table)."""
    tx, ty, _ = geometry.tcp
    azimuth = math.atan2(ty, tx) if math.hypot(tx, ty) > 1e-6 else 0.0
    ux, uy = math.cos(azimuth), math.sin(azimuth)

    def out(p: Point) -> float:
        return p[0] * ux + p[1] * uy
    rear = math.degrees(math.atan2(out(geometry.elbow) - out(geometry.shoulder), geometry.elbow[2] - geometry.shoulder[2]))
    fore = math.degrees(math.atan2(geometry.elbow[2] - geometry.wrist[2], out(geometry.wrist) - out(geometry.elbow)))
    return {"J1": math.degrees(azimuth), "J2": rear, "J3": fore, "J4": wrist_turn(math.degrees(azimuth), tool_rotation)}


def joint_status(name: str, angle: float) -> str:
    """"ok", "near" (within NEAR_LIMIT_DEG of a limit) or "over" (past one)."""
    low, high = JOINT_LIMITS_DEG[name]
    if angle < low or angle > high:
        return "over"
    if angle < low + NEAR_LIMIT_DEG or angle > high - NEAR_LIMIT_DEG:
        return "near"
    return "ok"


def within_limits(x: float, y: float, z: float) -> bool:
    geometry = arm_geometry(x, y, z)
    if not geometry.reachable:
        return False
    joints = dobot_joints(geometry)
    return all(joint_status(name, joints[name]) != "over" for name in ("J2", "J3"))


def reach_band(z: float, step_mm: float = 2.0, limit_mm: float = 360.0) -> Optional[tuple[float, float]]:
    """(nearest, farthest) distance from the base the tip can be at height `z`, within the joint limits,
    or None if nowhere. Straight out along +X; the same all the way round (J1 only turns it)."""
    band = [r for r in _frange(step_mm, limit_mm, step_mm) if within_limits(r, 0.0, z)]
    return (band[0], band[-1]) if band else None


def _frange(start: float, stop: float, step: float):
    value = start
    while value <= stop:
        yield value
        value += step

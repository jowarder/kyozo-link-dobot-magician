"""A checklist of everything that has to be right before the robot does anything useful.

Each check says what it found, and when something is wrong says plainly what to do about it.
Run from the "System check" button; also runs against the app's stand-ins when hardware is
missing, so it can be tried without any.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from app.calibration.storage import load_calibration
from app.hardware.unavailable import UnavailableCamera, UnavailableRobot
from app.memory import ALARM_APP_MB, NORMAL_APP_MB, app_memory_mb, system_memory_gb
from app.vision.table import measure_table

OK, WARN, FAIL, INFO = "ok", "warn", "fail", "info"
MIN_Z_RANGE_MM = 20.0


@dataclass
class CheckResult:
    area: str
    status: str
    message: str
    fix: str = ""


@dataclass
class CheckContext:
    mode: str
    config: dict
    robot: object
    camera: object
    detector: Optional[object]
    get_transform: Callable[[], np.ndarray]
    calibrated: bool
    calibration_error_mm: Optional[float]
    calibration_file: Optional[Path]
    drift_check: Optional[Callable[[], object]] = None   # returns a DriftReport, or None
    ollama: Optional[object] = None
    model: str = ""


def run_checks(context: CheckContext, on_progress: Optional[Callable[[str], None]] = None) -> list[CheckResult]:
    """All the checks, in order. Never raises: a check that blows up is reported as a failure."""
    say = on_progress or (lambda message: None)
    results: list[CheckResult] = []
    for name, check in (("robot", _robot), ("camera", _camera), ("calibration", _calibration), ("table", _table),
                        ("camera position", _stability), ("objects", _objects), ("language model", _llm),
                        ("memory", _memory)):
        say(f"Checking the {name}...")
        try:
            results += check(context)
        except Exception as exc:  # noqa: BLE001 - a broken check must not hide the others
            results.append(CheckResult(name, FAIL, f"The check itself failed: {exc}"))
    return results


def summary(results: list[CheckResult]) -> str:
    fails = sum(r.status == FAIL for r in results)
    warns = sum(r.status == WARN for r in results)
    if fails:
        return f"{fails} problem(s) to fix before using the robot" + (f", {warns} warning(s)" if warns else "")
    if warns:
        return f"Usable, with {warns} warning(s)"
    return "Everything checks out"


def as_text(results: list[CheckResult]) -> str:
    marks = {OK: "[ OK ]", WARN: "[WARN]", FAIL: "[FAIL]", INFO: "[info]"}
    lines = [summary(results), ""]
    for r in results:
        lines.append(f"{marks[r.status]} {r.area}: {r.message}")
        if r.fix:
            lines.append(f"         -> {r.fix}")
    return "\n".join(lines)


# ---- robot ---------------------------------------------------------------------------------------------
def _robot_fix() -> str:
    from app import robots
    if robots.active().key == "xarm6":
        return ("Switch the xArm's control box on, check its network cable, set xarm6: ip: in config.yaml to its "
                "address (as in UFACTORY Studio), then press 'Reconnect Robot'.")
    return "Plug in the Dobot's USB cable and its DC power, switch it on, then press 'Reconnect Robot'."


def _robot(c: CheckContext) -> list[CheckResult]:
    robot = c.robot
    if isinstance(robot, UnavailableRobot):
        return [CheckResult("robot", FAIL, f"Not connected: {robot.reason}",
                            _robot_fix())]
    results = []
    try:
        pose = robot.get_pose()
    except Exception as exc:  # noqa: BLE001
        return [CheckResult("robot", FAIL, f"Could not read the robot's position: {exc}",
                            "Check the USB cable and that the arm has DC power, then press 'Reconnect Robot'.")]
    results.append(CheckResult("robot", OK, f"Connected. Tool tip at x={pose.x:.0f}, y={pose.y:.0f}, z={pose.z:.0f} mm."))
    if hasattr(robot, "get_alarms"):
        alarms = robot.get_alarms()
        if any(code != 0 for code in alarms):   # a healthy robot answers with a row of zeros
            results.append(CheckResult("robot alarms", FAIL, f"The robot reports alarm code(s) {alarms}.",
                                       "Press 'Clear Alarms' on the Manual tab. If it returns, power-cycle the arm, "
                                       "and jog it by hand away from its limits first."))
        else:
            results.append(CheckResult("robot alarms", OK, "No alarms."))
    bounds = getattr(robot, "bounds", None)
    if bounds:
        z_lo, z_hi = bounds["z"]
        if z_hi - z_lo < MIN_Z_RANGE_MM:
            results.append(CheckResult("safety bounds", FAIL, f"The height limit is only {z_hi - z_lo:.0f} mm wide "
                                       f"(z {z_lo:.0f} to {z_hi:.0f}); the arm will seem stuck.",
                                       "Widen it on the Manual tab, or use 'Detect table height'."))
        else:
            results.append(CheckResult("safety bounds", OK, f"x {bounds['x'][0]:.0f} to {bounds['x'][1]:.0f}, "
                                       f"y {bounds['y'][0]:.0f} to {bounds['y'][1]:.0f}, z {z_lo:.0f} to {z_hi:.0f} mm."))
    return results


# ---- camera --------------------------------------------------------------------------------------------
def _camera(c: CheckContext) -> list[CheckResult]:
    camera = c.camera
    if isinstance(camera, UnavailableCamera):
        return [CheckResult("camera", FAIL, f"Not connected: {camera.reason}",
                            "Plug the Orbbec camera into a USB 3 port (blue connector) with its own short cable, "
                            "then restart the app.")]
    results = []
    started = time.time()
    frames = [camera.get_frame() for _ in range(5)]
    seconds = max(time.time() - started, 1e-6)
    frame = frames[-1]
    describe = getattr(camera, "describe", None)
    info = describe() if describe is not None else {}
    simulated = str(info.get("connection", "")) == "simulated"
    results.append(CheckResult("camera", OK, f"Working: {frame.rgb.shape[1]}x{frame.rgb.shape[0]}" + (" (simulated)." if simulated else
                                                                                               f", about {len(frames) / seconds:.0f} pictures per second.")))
    if describe is not None:
        connection = str(info.get("connection", "")).upper()
        if connection.startswith("USB2") or connection == "USB 2":
            results.append(CheckResult("camera cable", FAIL, "The camera is on a USB 2 connection.",
                                       "Use a USB 3 port (blue) and a USB 3 cable; USB 2 can't carry depth and colour together."))
        elif connection:
            results.append(CheckResult("camera cable", OK, f"Connection: {info.get('connection')}."))
        results.append(CheckResult("camera", INFO, ", ".join(f"{k}: {v}" for k, v in info.items() if v)))
    brightness = float(frame.rgb.mean())
    if brightness < 25:
        results.append(CheckResult("picture", WARN, f"The picture is very dark (average brightness {brightness:.0f} of 255).",
                                   "Turn on more light, or check the lens cap and exposure."))
    elif brightness > 230:
        results.append(CheckResult("picture", WARN, f"The picture is washed out (average brightness {brightness:.0f} of 255).",
                                   "Reduce glare and direct light on the workspace."))
    else:
        results.append(CheckResult("picture", OK, f"Brightness looks fine ({brightness:.0f} of 255)."))
    if frame.depth is None:
        results.append(CheckResult("depth", FAIL, "The camera gives no depth picture.",
                                   "Check the camera is a depth model, on USB 3, and restart the app."))
        return results
    if simulated:   # a perfect simulated depth picture has no holes, and its empty sky has no depth by design
        results.append(CheckResult("depth", OK, "Simulated depth: perfect."))
        return results
    h, w = frame.depth.shape
    middle = frame.depth[h // 4:3 * h // 4, w // 4:3 * w // 4]
    valid = float((middle > 0).mean())
    if valid < 0.5:
        results.append(CheckResult("depth", FAIL, f"Only {valid:.0%} of the middle of the picture has depth.",
                                   "The surface may be too shiny, dark or too close (the Gemini 335 needs about 0.25 m or more). "
                                   "Try a matte surface and move the camera back."))
    elif valid < 0.7:
        results.append(CheckResult("depth", WARN, f"{valid:.0%} of the middle of the picture has depth (holes are normal, "
                                                  "but this is a lot).", "A matte, evenly lit surface works best."))
    else:
        results.append(CheckResult("depth", OK, f"{valid:.0%} of the middle of the picture has depth."))
    readings = middle[middle > 0]
    if readings.size:
        distance = float(np.median(readings))
        if distance < 250 or distance > 1500:
            results.append(CheckResult("camera distance", WARN, f"The scene is about {distance:.0f} mm from the camera.",
                                       "The Gemini 335 works best between about 300 mm and 1500 mm."))
        else:
            results.append(CheckResult("camera distance", OK, f"The scene is about {distance:.0f} mm from the camera."))
    return results


# ---- calibration ---------------------------------------------------------------------------------------
def _calibration(c: CheckContext) -> list[CheckResult]:
    if not c.calibrated:
        return [CheckResult("calibration", FAIL, "The camera is not calibrated.",
                            "Open the Calibration tab: automatic with the marker, or by hand. Then do step 5.")]
    results = []
    error = c.calibration_error_mm
    if c.mode == "demo" and (c.calibration_file is None or not c.calibration_file.exists()):
        results.append(CheckResult("calibration", INFO, "Demo mode: using the simulator's exact built-in calibration."))
        return results
    if error is None:
        results.append(CheckResult("calibration", INFO, "Calibrated (its accuracy wasn't recorded)."))
    elif error < 6.0:
        results.append(CheckResult("calibration", OK, f"Calibrated; typical error {error:.1f} mm."))
    elif error < 10.0:
        results.append(CheckResult("calibration", WARN, f"Calibrated, but the typical error is {error:.1f} mm.",
                                   "Add more points, or use the automatic calibration."))
    else:
        results.append(CheckResult("calibration", FAIL, f"The calibration is poor (typical error {error:.1f} mm).",
                                   "Recalibrate with more, well-spread points, or use the automatic calibration."))
    saved = load_calibration(c.calibration_file) if c.calibration_file is not None else None
    if saved is not None:
        if saved.method.endswith("+table"):
            results.append(CheckResult("table-height step", OK, "The table-height step was done."))
        else:
            results.append(CheckResult("table-height step", WARN,
                                       "The table-height step (step 5) was never done for this calibration.",
                                       "Heights will be off by how far above the tip you clicked. Lower the tip until it "
                                       "touches the table, then press 'Set table height' on the Calibration tab."))
    return results


# ---- the table -------------------------------------------------------------------------------------------
def _table(c: CheckContext) -> list[CheckResult]:
    if not c.calibrated or isinstance(c.camera, UnavailableCamera):
        return []
    plane = measure_table(c.camera, c.get_transform())
    if plane is None:
        return [CheckResult("table", WARN, "The camera didn't find a large, flat, level surface in the workspace.",
                            "Make sure the table is in view and mostly clear; a wrong calibration can also hide it.")]
    results = []
    if plane.tilt_deg > 3.0:
        results.append(CheckResult("table", WARN, f"The table measures z = {plane.z_mm:.0f} mm but looks tilted by "
                                                  f"{plane.tilt_deg:.1f} degrees.",
                                   "A real table is level, so the calibration is probably inaccurate. Recalibrate."))
    else:
        results.append(CheckResult("table", OK, f"Table found at z = {plane.z_mm:.0f} mm, level to {plane.tilt_deg:.1f} degrees "
                                                f"({plane.inlier_fraction:.0%} of the workspace)."))
    bounds = getattr(c.robot, "bounds", None)
    if bounds:
        floor = bounds["z"][0]
        if floor < plane.z_mm - 3.0:
            results.append(CheckResult("height floor", WARN, f"The lowest height allowed (z = {floor:.0f} mm) is "
                                       f"{plane.z_mm - floor:.0f} mm below the table (z = {plane.z_mm:.0f} mm).",
                                       "The arm could be sent into the table. Do step 5 or press 'Detect table height'."))
        else:
            results.append(CheckResult("height floor", OK, f"The lowest height allowed is {floor - plane.z_mm:.0f} mm above the table."))
    return results


def _stability(c: CheckContext) -> list[CheckResult]:
    if c.drift_check is None:
        return []
    report = c.drift_check()
    if report is None:
        return []
    status = {"ok": OK, "moved": FAIL, "unknown": INFO}.get(report.status, INFO)
    fix = "Recalibrate: the saved calibration no longer matches where the camera is." if status == FAIL else ""
    return [CheckResult("camera position", status, report.message, fix)]


def _objects(c: CheckContext) -> list[CheckResult]:
    if c.detector is None or isinstance(c.camera, UnavailableCamera):
        return []
    frame = c.camera.get_frame()
    if getattr(c.detector, "needs_depth", False):
        found = c.detector.detect(frame.rgb, frame.depth, frame.intrinsics)
    else:
        found = c.detector.detect(frame.rgb)
    if not found:
        what = ("Nothing is standing on the table in reach right now." if getattr(c.detector, "needs_depth", False)
                else "No coloured objects are in view right now.")
        return [CheckResult("objects", INFO, what,
                            "Fine if the table is empty; put an object in view to test detection.")]
    return [CheckResult("objects", OK, "Sees: " + ", ".join(sorted(d.label for d in found)) + ".")]


def _llm(c: CheckContext) -> list[CheckResult]:
    if c.ollama is None:
        return []
    if not c.ollama.is_reachable():
        return [CheckResult("language model", WARN, "The Ollama server isn't running.",
                            "Start Ollama (the app tries to start it itself). Prompts won't work until it's up.")]
    models = c.ollama.list_models()
    if c.model and not any(m == c.model or m.startswith(c.model + ":") for m in models):
        return [CheckResult("language model", WARN, f"Ollama is running but '{c.model}' isn't downloaded.",
                            f"Run:  ollama pull {c.model}")]
    return [CheckResult("language model", OK, f"Ollama is running with '{c.model}'.")]

def _memory(c: CheckContext) -> list[CheckResult]:
    """Who is using the memory: this app, or the language model. Usually it is the model."""
    app_mb, system = app_memory_mb(), system_memory_gb()
    if app_mb is None or system is None:
        return []
    loaded = []
    if c.ollama is not None and hasattr(c.ollama, "loaded_models"):
        loaded = c.ollama.loaded_models()
    total, free = system
    parts = [f"this app is using {app_mb:.0f} MB"]
    if loaded:
        parts.append("Ollama has " + ", ".join(f"{m['name']} in memory ({m['size_gb']:.1f} GB)" for m in loaded))
    parts.append(f"the PC has {free:.1f} GB free of {total:.1f} GB")
    sentence = "; ".join(parts)
    message = sentence[0].upper() + sentence[1:] + "."   # (str.capitalize() would also lowercase "MB" and "GB")
    if app_mb > ALARM_APP_MB:
        return [CheckResult("memory", FAIL, message,
                            f"The app itself normally stays under about {NORMAL_APP_MB:.0f} MB, so it is leaking. "
                            "Restart it and send app.log.")]
    if free < 2.0:
        fix = ("Close other programs (browser tabs use a lot). ")
        if loaded:
            fix += ("Ollama keeps the model in memory for 5 minutes after its last use: set `keep_alive: 30s` under "
                    "`llm:` in config.yaml to free it sooner, or pick a Quick model (qwen3:4b-instruct) in the Model list.")
        return [CheckResult("memory", WARN, message, fix)]
    return [CheckResult("memory", OK, message)]
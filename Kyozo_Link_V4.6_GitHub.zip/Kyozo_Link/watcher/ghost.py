"""Ghost outlines: where each cube of a task's layout goes, and the zones, drawn on the camera picture at their true
size -- the table positions turned into camera pixels with the calibration -- so setting a layout out is putting each
cube on its outline until it turns green."""
from __future__ import annotations

import math
from typing import Optional

import numpy as np

from watcher.tasks import Cube, Zone

COLOURS = {"red": (255, 107, 107), "blue": (107, 168, 255), "green": (107, 220, 139)}
PLACED = (120, 255, 160)          # an outline whose cube is in place
START = (150, 162, 178)           # where a cube stood before the run (for the verdict)
ZONE = (255, 209, 102)
SPOT = (205, 214, 224)            # a printed spot of the A4 sheet
PAPER = (240, 240, 235)           # the sheet itself


def zone_corners(zone: Zone, cube_size: float = 25.0) -> list[tuple[float, float]]:
    """A zone's square; a spot of the A4 sheet as printed: a cube's outline, turned as the spot is."""
    if zone.spot is not None:
        return square(zone.cx, zone.cy, cube_size, cube_size, zone.yaw)
    return square(zone.cx, zone.cy, zone.width, zone.depth)


def zone_colour(zone: Zone) -> tuple:
    return SPOT if zone.spot is not None else ZONE


def paper_outline(paper, table_z: float) -> list[dict]:
    """The A4 sheet, faintly filled, for the 3D view (app.vision.paper.PaperPose; None: nothing)."""
    if paper is None:
        return []
    return [{"points": [(x, y, table_z + 0.2) for x, y in paper.corners()], "colour": PAPER, "width": 1.0,
             "label": "", "fill": 40}]


def to_pixel(t_cam_to_robot: np.ndarray, intrinsics, x: float, y: float, z: float) -> Optional[tuple[float, float]]:
    """The camera pixel (u, v) a point of the table (robot frame, mm) is seen at, or None if behind the camera."""
    cam = np.linalg.inv(np.asarray(t_cam_to_robot, float)) @ np.array([x, y, z, 1.0])
    if cam[2] <= 1e-6:
        return None
    return (intrinsics.fx * cam[0] / cam[2] + intrinsics.cx, intrinsics.fy * cam[1] / cam[2] + intrinsics.cy)


def square(cx: float, cy: float, width: float, depth: float, yaw_deg: float = 0.0) -> list[tuple[float, float]]:
    """The four corners of a rectangle centred at (cx, cy), turned yaw_deg counter-clockwise seen from above."""
    t = math.radians(yaw_deg)
    c, s = math.cos(t), math.sin(t)
    return [(cx + dx * c - dy * s, cy + dx * s + dy * c)
            for dx, dy in ((-width / 2, -depth / 2), (width / 2, -depth / 2), (width / 2, depth / 2),
                           (-width / 2, depth / 2))]


def outline(t, intrinsics, corners: list[tuple[float, float]], z: float) -> Optional[list[tuple[float, float]]]:
    pixels = [to_pixel(t, intrinsics, x, y, z) for x, y in corners]
    return None if any(p is None for p in pixels) else pixels


def ghost_marks(layout: list[Cube], placed: list[bool], zones: dict[str, Zone], t_cam_to_robot, intrinsics,
                table_z: float, cube_size: float) -> list[dict]:
    """The marks for VideoWidget.set_marks: the zones, then each cube's outline (its top face, in its colour; light
    green once it is in place)."""
    marks = []
    for name, zone in zones.items():
        pixels = outline(t_cam_to_robot, intrinsics, zone_corners(zone, cube_size), table_z)
        if pixels:
            marks.append({"kind": "poly", "points": pixels, "colour": zone_colour(zone), "width": 1,
                          "label": zone.label})
    for cube, ok in zip(layout, placed):
        pixels = outline(t_cam_to_robot, intrinsics, square(cube.x, cube.y, cube_size, cube_size, cube.yaw),
                         table_z + cube_size)
        if pixels:
            marks.append({"kind": "poly", "points": pixels, "colour": PLACED if ok else COLOURS.get(cube.color,
                                                                                                    (235, 240, 245)),
                          "width": 2, "label": "" if ok else cube.color})
    return marks


def ghost_outlines_3d(layout: list[Cube], placed: list[bool], zones: dict[str, Zone], table_z: float,
                      cube_size: float, paper=None) -> list[dict]:
    """The same outlines in table coordinates, for the 3D view (TwinView.overlay_provider): no calibration needed.
    `paper` (app.vision.paper.PaperPose): the A4 sheet drawn under them."""
    out = paper_outline(paper, table_z)
    for name, zone in zones.items():
        out.append({"points": [(x, y, table_z + 0.5) for x, y in zone_corners(zone, cube_size)],
                    "colour": zone_colour(zone), "width": 1.5, "label": zone.label})
    for cube, ok in zip(layout, placed):
        out.append({"points": [(x, y, table_z + cube_size + 0.5)
                               for x, y in square(cube.x, cube.y, cube_size, cube_size, cube.yaw)],
                    "colour": PLACED if ok else COLOURS.get(cube.color, (235, 240, 245)), "width": 2.5,
                    "label": "" if ok else cube.color})
    return out


MET, NOT_MET = (120, 255, 160), (255, 107, 107)


def target_marks(targets: list[dict], tolerance_mm: float, table_z: float, cube_size: float, t_cam_to_robot=None,
                 intrinsics=None) -> list[dict]:
    """For the marked end picture: each target's wanted place (a circle the size of the pass rule, green if met, red
    if not) and a line from it to where the cube ended -- for the 3D view, or (given the calibration) as camera
    picture marks. `targets`: the score's target results (with wanted_xy / ended_xy)."""
    shapes = []
    for t in targets:
        wanted = t.get("wanted_xy")
        if not wanted:
            continue
        colour = MET if t.get("ok") else NOT_MET
        circle = [(wanted[0] + tolerance_mm * math.cos(a), wanted[1] + tolerance_mm * math.sin(a))
                  for a in (2 * math.pi * i / 24 for i in range(24))]
        shapes.append((circle, colour, 2.0, f"{str(t.get('cube', '')).replace(' cube', '')} goes here", 0))
        if t.get("ended_xy"):
            shapes.append(([tuple(wanted), tuple(t["ended_xy"])], colour, 2.0, "", 0))
    z = table_z + cube_size
    if t_cam_to_robot is None:
        return [{"points": [(x, y, z + 0.5) for x, y in pts], "colour": colour, "width": width, "label": label,
                 "fill": fill} for pts, colour, width, label, fill in shapes]
    marks = []
    for pts, colour, width, label, fill in shapes:
        pixels = outline(t_cam_to_robot, intrinsics, pts, z)
        if pixels:
            marks.append({"kind": "poly" if len(pts) > 2 else "line", "points": pixels, "colour": colour,
                          "width": int(width), "label": label, "fill": fill})
    return marks


def draw_marks(image_path, marks: list[dict], out_path) -> bool:
    """Draws camera-picture marks (polygons, lines, labels) on a saved picture and writes it out. False if it
    couldn't (no picture, no OpenCV)."""
    try:
        import cv2
        image = cv2.imread(str(image_path))
        if image is None:
            return False
        for m in marks:
            pts = np.array([[int(round(u)), int(round(v))] for u, v in m["points"]], np.int32)
            bgr = tuple(int(c) for c in reversed(m.get("colour", (255, 255, 255))))
            cv2.polylines(image, [pts], m.get("kind") != "line", bgr, max(1, int(m.get("width", 1))), cv2.LINE_AA)
            if m.get("label"):
                u, v = pts.min(axis=0)
                cv2.putText(image, str(m["label"]), (int(u), int(v) - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.45, bgr, 1,
                            cv2.LINE_AA)
        return bool(cv2.imwrite(str(out_path), image))
    except Exception:  # noqa: BLE001 - a missing picture is noted, not the end of the run
        return False


def task_zones(targets: list[dict]) -> dict[str, str]:
    """The zones a task is about, each with what it asks of it in a few words (plain letters: the camera picture's
    font has no arrows): {"zone_a": "zone A: red cube goes here"}."""
    wants: dict[str, list[str]] = {}
    for target in targets:
        (kind, spec), = target.items()
        if kind == "in_zone":
            wants.setdefault(spec["zone"], []).append(spec["cube"].replace(" cube", ""))
        elif kind == "all_in_zone":
            wants.setdefault(spec["zone"], []).append(f"all {spec['color']}")
        elif kind == "zone_empty":
            wants.setdefault(spec["zone"], []).append("")
    out = {}
    for key, what in wants.items():
        name = f"spot {key.split('_')[-1]}" if key.startswith("spot_") else f"zone {key.split('_')[-1].upper()}"
        what = [w for w in what if w]
        several = len(what) > 1 or (what and what[0].startswith("all"))
        out[key] = (f"{name}: {', '.join(what)} cube{'s go' if several else ' goes'} here" if what
                    else f"{name}: must end empty")
    return out


def start_outlines(layout: list[Cube], zones: dict[str, Zone], table_z: float, cube_size: float, t_cam_to_robot=None,
                   intrinsics=None, highlight: Optional[dict[str, str]] = None, paper=None) -> list[dict]:
    """For the verdict: the zones, and where each cube stood before the run (grey, flat on the table) -- for the 3D
    view, or (given the calibration) as camera picture marks. `highlight` (see task_zones): the task's own zones,
    filled and thicker, saying what goes there."""
    highlight = highlight or {}
    shapes = [(zone_corners(zone, cube_size), ZONE if name in highlight else zone_colour(zone),
               3.0 if name in highlight else 1.0, highlight.get(name, zone.label), 60 if name in highlight else 0)
              for name, zone in zones.items()]
    shapes += [(square(cube.x, cube.y, cube_size, cube_size, cube.yaw), START, 2.0, f"{cube.color} start", 0)
               for cube in layout]
    if t_cam_to_robot is None:
        return paper_outline(paper, table_z) + [
            {"points": [(x, y, table_z + 0.5) for x, y in corners], "colour": colour, "width": width,
             "label": label, "fill": fill} for corners, colour, width, label, fill in shapes]
    marks = []
    for corners, colour, width, label, fill in shapes:
        pixels = outline(t_cam_to_robot, intrinsics, corners, table_z)
        if pixels:
            marks.append({"kind": "poly", "points": pixels, "colour": colour, "width": max(1, int(width) - 1),
                          "label": label, "fill": fill})
    return marks

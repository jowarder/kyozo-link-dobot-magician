"""The watcher's own cube finder -- the measuring instrument, kept apart from the app's detector (which the study's
rounds may change): red, green and blue 25 mm cubes found by colour in the camera picture, each one's top face measured
in 3D from the depth picture and the calibration, giving its position and angle on the table.

By colour, cubes of different colours never run together even when they touch (the app's detector took three cubes
packed in a zone for a "blue block" and a "purple bar"); only things of a cube's size and height count, so the arm,
shadows and gaps between cubes don't; two cubes of one colour touching are told apart by their size.
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np

from watcher.tasks import Cube

# hue ranges in OpenCV's 0-180 scale, with the least saturation and brightness a cube's face has
COLOURS = {
    "red": [((0, 90, 50), (10, 255, 255)), ((170, 90, 50), (180, 255, 255))],
    "green": [((40, 70, 40), (85, 255, 255))],
    "blue": [((95, 90, 40), (130, 255, 255))],
}
MIN_PIXELS = 40            # fewer than this: a speck, not a cube
TOP_BAND_MM = 4.0          # the top face: points within this of the highest
HEIGHT_RANGE = (0.5, 3.4)  # a cube's top above the table, in cube sizes (up to the top of a tower of three)
SIZE_RANGE = (0.6, 1.5)    # a cube's top face, each side, in cube sizes


def find_cubes(rgb: np.ndarray, depth: np.ndarray, intrinsics, t_cam_to_robot: np.ndarray, table_z: float = 0.0,
               cube_mm: float = 25.0, colours: Optional[dict] = None) -> list[Cube]:
    """The cubes in one picture: label ("red cube"), x, y on the table (robot frame, mm) and angle (0-90)."""
    import cv2
    if rgb is None or depth is None:
        return []
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    t = np.asarray(t_cam_to_robot, float)
    found: list[Cube] = []
    for name, ranges in (colours or COLOURS).items():
        mask = np.zeros(hsv.shape[:2], np.uint8)
        for low, high in ranges:
            mask |= cv2.inRange(hsv, np.array(low, np.uint8), np.array(high, np.uint8))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        count, labels = cv2.connectedComponents(mask)
        for i in range(1, count):
            vs, us = np.nonzero(labels == i)
            if len(us) < MIN_PIXELS:
                continue
            found.extend(_cubes_in_blob(name, us, vs, depth, intrinsics, t, table_z, cube_mm))
    return found


def _cubes_in_blob(name, us, vs, depth, intr, t, table_z, cube_mm) -> list[Cube]:
    import cv2
    d = depth[vs, us].astype(float)
    ok = np.isfinite(d) & (d > 0)
    if ok.sum() < MIN_PIXELS:
        return []
    us, vs, d = us[ok], vs[ok], d[ok]
    cam = np.stack([(us - intr.cx) * d / intr.fx, (vs - intr.cy) * d / intr.fy, d, np.ones_like(d)])
    robot = (t @ cam)[:3].T                                      # (N, 3) in the robot frame, mm
    top_z = float(np.percentile(robot[:, 2], 90))
    height = top_z - table_z
    if not HEIGHT_RANGE[0] * cube_mm <= height <= HEIGHT_RANGE[1] * cube_mm:
        return []
    top = robot[robot[:, 2] >= top_z - TOP_BAND_MM][:, :2].astype(np.float32)
    if len(top) < MIN_PIXELS // 2:
        return []
    (cx, cy), (w, h), angle = cv2.minAreaRect(top)
    # how many cubes: the area the top faces really cover (2 mm cells), not the box round them (an L of two
    # touching cubes fills only half its box)
    cell = 2.0
    cells = {(int(x // cell), int(y // cell)) for x, y in top}
    pieces = max(1, round(len(cells) * cell * cell / (cube_mm * cube_mm)))
    if pieces > 1 and max(w, h) > SIZE_RANGE[1] * cube_mm:          # two (or three) of one colour touching
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.5)
        _, assign, _ = cv2.kmeans(top, min(pieces, 3), None, criteria, 3, cv2.KMEANS_PP_CENTERS)
        out = []
        for k in range(min(pieces, 3)):
            part = top[assign.ravel() == k]
            if len(part) >= 5:
                out.extend(_one(name, part, cube_mm, height))
        return out
    return _one(name, top, cube_mm, height)


def level_of(height: float, cube_mm: float) -> int:
    """How many cubes up a top face this high is: 1 on the table, 2 on another cube, 3 on two."""
    return max(1, int(round(height / cube_mm)))


def _one(name, top, cube_mm, height: float = 0.0) -> list[Cube]:
    import cv2
    (cx, cy), (w, h), angle = cv2.minAreaRect(top)
    if not (SIZE_RANGE[0] * cube_mm <= max(w, h) <= SIZE_RANGE[1] * cube_mm
            and min(w, h) >= SIZE_RANGE[0] * cube_mm):
        return []
    return [Cube(f"{name} cube", round(float(cx), 1), round(float(cy), 1), round(float(angle) % 90.0, 1),
                 level_of(height, cube_mm))]


def median_angle(angles: list[float], period: float = 90.0) -> float:
    ref = angles[0]
    unwrapped = [ref + (((a - ref) + period / 2) % period - period / 2) for a in angles]
    return float(np.median(unwrapped)) % period


def merge_looks(looks: list[list[Cube]]) -> list[Cube]:
    """Several looks into one: the look that saw the most cubes, each cube's position and angle the median of the
    looks that saw it (a real camera's depth noise differs from picture to picture). A cube at least half the looks
    didn't see is left out (a reflection or a flicker in one picture, not a cube)."""
    from watcher.tasks import match
    if not looks:
        return []
    base = max(looks, key=len)
    out = []
    for cube in base:
        xs, ys, yaws, levels = [cube.x], [cube.y], [cube.yaw], [cube.level]
        for other in looks:
            if other is base:
                continue
            got = match([cube], other)[0]
            if got is not None and math.hypot(got.x - cube.x, got.y - cube.y) < 15.0:
                xs.append(got.x)
                ys.append(got.y)
                yaws.append(got.yaw)
                levels.append(got.level)
        if 2 * len(xs) < len(looks):
            continue
        out.append(Cube(cube.label, round(float(np.median(xs)), 1), round(float(np.median(ys)), 1),
                        round(median_angle(yaws), 1), max(set(levels), key=levels.count)))
    return out

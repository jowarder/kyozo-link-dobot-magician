"""The run's measurements, worked out from the model's record of it (trace.json: every arm move and gripper action
the tools made, with where the arm started and ended, the joint angles before and after, how long it took and the
speed asked for), for the full report, the workbook and the session's .csv files:

    motion_detail(traces)   every move (distance along its real path, time, speed, joints and their speeds, how far
                            it ended from its target), every gripper action, how long each cube was held, and totals
    model_turns(traces)     every model turn: tokens read and written, seconds (load, read, write), what it did
    which_way(score)        each target's error as a direction (away from / towards the robot, left / right)

Nothing here changes a score: it describes the run.
"""
from __future__ import annotations

import math
from typing import Optional

JOINT_WORDS = {"J1": "base", "J2": "rear arm", "J3": "forearm", "J4": "wrist"}


def _actions(traces: list[dict]) -> list[tuple[int, str, dict]]:
    """(prompt number, tool, action) for every arm move and gripper action, in order."""
    out = []
    for n, trace in enumerate(traces or [], start=1):
        for turn in trace.get("turns", []):
            for call in turn.get("calls", []):
                for action in (call.get("app") or {}).get("moves") or []:
                    out.append((n, call.get("name", ""), action))
    return out


def _path_mm(start: list, end: list, route: Optional[str]) -> float:
    """The distance the gripper's tip went: along the swing round the base when it took one, else straight."""
    straight = math.dist(start[:3], end[:3])
    if not route or route == "straight":
        return straight
    try:
        from app.hardware import motion
        from app.hardware.interfaces import Pose
        points = motion.path_points(Pose(*start[:4]), Pose(*end[:4]), 40)
        return sum(math.dist((a.x, a.y, a.z), (b.x, b.y, b.z)) for a, b in zip(points, points[1:]))
    except Exception:  # noqa: BLE001 - the straight distance, then
        return straight


def motion_detail(traces: list[dict]) -> dict:
    """{"moves": [...], "gripper": [...], "holds": [...], "totals": {...}} for a run's prompts."""
    moves, gripper = [], []
    for prompt, tool, a in _actions(traces):
        kind, seconds = a.get("kind", ""), float(a.get("seconds") or 0.0)
        if kind in ("move", "home"):          # (homing is an arm move too, with no target of its own)
            start, end, target = a.get("from"), a.get("to") or a.get("target"), a.get("target")
            path = _path_mm(start, end, a.get("route")) if start and end else None
            before, after = a.get("joints_before") or {}, a.get("joints_after") or {}
            changes = {j: round(after[j] - before[j], 1) for j in before if j in after}
            row = {"n": len(moves) + 1, "prompt": prompt, "tool": tool,
                   "route": a.get("route") or ("homing" if kind == "home" else None),
                   "from": start, "to": end, "target": target,
                   "distance_mm": round(path, 1) if path is not None else None,
                   "straight_mm": round(math.dist(start[:3], end[:3]), 1) if start and end else None,
                   "seconds": round(seconds, 2),
                   "speed_mm_s": round(path / seconds, 1) if path is not None and seconds > 0.005 else None,
                   "speed_set_mm_s": a.get("speed_mm_s"), "speed_from": a.get("speed_from"),
                   "missed_by_mm": round(math.dist(end[:3], target[:3]), 1) if end and target else None,
                   "joints_before": before or None, "joints_after": after or None, "joint_changes": changes or None,
                   "fastest_joint": None, "at": a.get("at"), "error": a.get("error")}
            if changes and seconds > 0.005:
                joint, change = max(changes.items(), key=lambda kv: abs(kv[1]))
                row["fastest_joint"] = {"joint": joint, "name": JOINT_WORDS.get(joint, joint),
                                        "deg_per_s": round(abs(change) / seconds, 1)}
            if a.get("tightest_on_path"):
                row["closest_to_a_limit"] = a["tightest_on_path"]
            moves.append(row)
        elif "gripper" in kind:
            gripper.append({"n": len(gripper) + 1, "prompt": prompt, "tool": tool, "action": kind,
                            "seconds": round(seconds, 2), "at": a.get("at"), "where": a.get("to") or a.get("from"),
                            "error": a.get("error")})
    holds = []
    closed = None
    for g in gripper:
        if g["action"] == "close gripper":
            closed = g
        elif g["action"] == "open gripper" and closed is not None:
            if closed.get("at") is not None and g.get("at") is not None:
                holds.append({"closed_at_step": closed["n"], "opened_at_step": g["n"], "tool": closed["tool"],
                              "held_s": round(g["at"] - closed["at"] - closed["seconds"], 2)})
            closed = None
    timed = [m for m in moves if m["speed_mm_s"] is not None]
    joint_turn: dict = {}
    for m in moves:
        for j, c in (m["joint_changes"] or {}).items():
            joint_turn[j] = round(joint_turn.get(j, 0.0) + abs(c), 1)
    moving_s = sum(m["seconds"] for m in moves)
    path = sum(m["distance_mm"] or 0.0 for m in moves)
    totals = {
        "moves": len(moves), "gripper_actions": len(gripper),
        "distance_mm": round(path, 1),
        "straight_mm": round(sum(m["straight_mm"] or 0.0 for m in moves), 1),
        "time_moving_s": round(moving_s, 1), "gripper_s": round(sum(g["seconds"] for g in gripper), 1),
        "mean_speed_mm_s": round(path / moving_s, 1) if moving_s > 0.005 else None,
        "top_speed_mm_s": max((m["speed_mm_s"] for m in timed), default=None),
        "slowest_speed_mm_s": min((m["speed_mm_s"] for m in timed), default=None),
        "slow_moves": sum(1 for m in moves if m["speed_from"] == "asked for this move"),
        "joint_turning_deg": {f"{j} {JOINT_WORDS.get(j, '')}".strip(): v for j, v in sorted(joint_turn.items())},
        "moves_off_by_over_2mm": sum(1 for m in moves if (m["missed_by_mm"] or 0) > 2.0),
        "failed_moves": sum(1 for m in moves if m["error"]),
        "longest_move_mm": max((m["distance_mm"] or 0.0 for m in moves), default=None),
        "held_s": [h["held_s"] for h in holds],
    }
    return {"moves": moves, "gripper": gripper, "holds": holds, "totals": totals}


def model_turns(traces: list[dict]) -> dict:
    """{"turns": [...], "totals": {...}}: every model turn of a run's prompts."""
    turns = []
    for n, trace in enumerate(traces or [], start=1):
        for turn in trace.get("turns", []):
            stats = turn.get("stats") or {}
            calls = turn.get("calls") or []
            turns.append({
                "prompt": n, "prompt_text": trace.get("prompt"), "turn": turn.get("number"), "time": turn.get("time"),
                "decided_s": turn.get("decided_s"), "load_s": _r(stats.get("load_s")), "read_s": _r(stats.get("read_s")),
                "write_s": _r(stats.get("write_s")), "tokens_read": stats.get("tokens_read"),
                "tokens_written": stats.get("tokens_written"), "stop_reason": stats.get("stop_reason"),
                "did": ", ".join(f"{c.get('name')}({_short(c.get('args'))})" for c in calls) or "replied",
                "refused": [((c.get("app") or {}).get("reason") or "")[:160] for c in calls
                            if (c.get("app") or {}).get("refused")],
                "reply": (turn.get("reply") or "")[:600] or None,
                "reasoning": (turn.get("reasoning") or "")[:2000] or None})
    totals = {"turns": len(turns),
              "decided_s": round(sum(t["decided_s"] or 0 for t in turns), 1),
              "tokens_read": sum(t["tokens_read"] or 0 for t in turns),
              "tokens_written": sum(t["tokens_written"] or 0 for t in turns),
              "slowest_turn_s": max((t["decided_s"] or 0 for t in turns), default=None),
              "not_finished": [t["turn"] for t in turns if t["stop_reason"] not in (None, "stop")]}
    return {"turns": turns, "totals": totals}


def app_views(traces: list[dict]) -> list[dict]:
    """What the app saw, each time the model looked at the table (every list_objects reply): one row per object --
    the look's number, the model turn, the id the app gave it, its colour and kind, where the app put it (x, y, z mm),
    its footprint and height, the words for where it is, how sure the camera was -- and what was held then."""
    import ast
    rows: list[dict] = []
    look = 0
    for n, trace in enumerate(traces or [], start=1):
        for turn in trace.get("turns", []):
            for call in turn.get("calls", []):
                if call.get("name") != "list_objects":
                    continue
                reply = (call.get("app") or {}).get("result") or ""
                try:
                    seen = ast.literal_eval(reply) if reply.strip().startswith("{") else None
                except (ValueError, SyntaxError):
                    seen = None
                if not isinstance(seen, dict):
                    continue
                look += 1
                for obj in seen.get("objects") or []:
                    xyz = list(obj.get("xyz_mm") or [None, None, None]) + [None] * 3
                    rows.append({"look": look, "prompt": n, "turn": turn.get("number"), "id": obj.get("id"),
                                 "label": obj.get("label"), "x": xyz[0], "y": xyz[1], "z": xyz[2],
                                 "footprint_mm": obj.get("footprint_mm"), "height_mm": obj.get("height_mm"),
                                 "where": obj.get("where"), "confidence": obj.get("confidence"),
                                 "holding": seen.get("holding")})
    return rows


def watcher_views(run: dict) -> list[dict]:
    """Where each cube was by the watcher's own look (the twin: exactly): set out, seen at the start, seen at the end,
    and how far it moved between."""
    def by_label(cubes):
        return {c.get("label"): c for c in cubes or []}
    set_out = by_label(run.get("layout_start") or run.get("start"))
    start = by_label(run.get("start_seen"))
    end = by_label(run.get("end_seen") or run.get("end"))
    rows = []
    for label in list(dict.fromkeys([*set_out, *start, *end])):
        s, e = start.get(label) or set_out.get(label), end.get(label)
        moved = (round(math.hypot(e["x"] - s["x"], e["y"] - s["y"]), 1)
                 if s is not None and e is not None and s.get("x") is not None and e.get("x") is not None else None)
        rows.append({"cube": label,
                     "set_out": _xyyaw(set_out.get(label)), "seen_at_start": _xyyaw(start.get(label)),
                     "seen_at_end": _xyyaw(end.get(label)), "moved_mm": moved})
    return rows


def _xyyaw(c: Optional[dict]) -> Optional[str]:
    if not c or c.get("x") is None:
        return None
    return f"({c['x']:.1f}, {c['y']:.1f}) {c.get('yaw', 0):.1f}°"


def which_way(score: dict) -> dict:
    """The run's placement errors as directions, and their average (a bias shows as the same direction every run)."""
    rows = [t for t in (score or {}).get("targets") or [] if t.get("dx_mm") is not None]
    out = {"targets": [{"kind": t.get("kind"), "cube": t.get("cube"), "wanted_xy": t.get("wanted_xy"),
                        "ended_xy": t.get("ended_xy"), "dx_mm": t.get("dx_mm"), "dy_mm": t.get("dy_mm"),
                        "radial_mm": t.get("radial_mm"), "around_mm": t.get("around_mm")} for t in rows],
           "angles": [{"cube": t.get("cube"), "signed_deg": t.get("angle_signed_deg")}
                      for t in (score or {}).get("targets") or [] if t.get("angle_signed_deg") is not None]}
    if rows:
        out["mean_dx_mm"] = round(sum(t["dx_mm"] for t in rows) / len(rows), 1)
        out["mean_dy_mm"] = round(sum(t["dy_mm"] for t in rows) / len(rows), 1)
    return out


MOVE_COLUMNS = ["move", "prompt", "tool", "route", "from_x", "from_y", "from_z", "from_r", "to_x", "to_y", "to_z",
                "to_r", "target_x", "target_y", "target_z", "target_r", "distance_mm", "straight_mm", "seconds",
                "speed_mm_s", "speed_set_mm_s", "speed_from", "missed_target_by_mm", "J1_before", "J2_before",
                "J3_before", "J4_before", "J1_after", "J2_after", "J3_after", "J4_after", "fastest_joint",
                "fastest_joint_deg_s", "error"]
GRIPPER_COLUMNS = ["action_no", "prompt", "tool", "action", "seconds", "x", "y", "z", "r", "error"]


def move_rows(motion: dict) -> list[list]:
    """motion_detail's moves as table rows (MOVE_COLUMNS)."""
    def four(v):
        return list(v[:4]) if v else [None] * 4

    def joints(j):
        return [(j or {}).get(k) for k in ("J1", "J2", "J3", "J4")]
    rows = []
    for m in motion.get("moves") or []:
        fast = m.get("fastest_joint") or {}
        rows.append([m["n"], m["prompt"], m["tool"], m["route"], *four(m["from"]), *four(m["to"]), *four(m["target"]),
                     m["distance_mm"], m["straight_mm"], m["seconds"], m["speed_mm_s"], m["speed_set_mm_s"],
                     m["speed_from"], m["missed_by_mm"], *joints(m["joints_before"]), *joints(m["joints_after"]),
                     fast.get("name"), fast.get("deg_per_s"), m["error"] or ""])
    return rows


def gripper_rows(motion: dict) -> list[list]:
    return [[g["n"], g["prompt"], g["tool"], g["action"], g["seconds"], *((g["where"] or [None] * 4)[:4]),
             g["error"] or ""] for g in motion.get("gripper") or []]


def words_for_direction(dx: Optional[float], dy: Optional[float]) -> str:
    """'4.1 mm further out (x), 5.9 mm to the robot's right (y)': the robot's own x and y, as the prompts use them."""
    if dx is None or dy is None:
        return "-"
    return (f"{abs(dx):.1f} mm {'further out from the base' if dx >= 0 else 'nearer the base'} (x), "
            f"{abs(dy):.1f} mm to the robot's {'left' if dy >= 0 else 'right'} (y)")


def _r(value) -> Optional[float]:
    return round(float(value), 2) if value is not None else None


def _short(args) -> str:
    text = ", ".join(f"{k}={v}" for k, v in (args or {}).items()) if isinstance(args, dict) else str(args or "")
    return text if len(text) <= 80 else text[:79] + "…"

"""Where the cubes start, for a task on the A4 sheet: a seeded random arrangement that suits the task.

A sheet task gives a start rule instead of a fixed layout (`start: {cubes, pin, free}`): which cubes are on the sheet,
which must be on a given spot ("move the red cube from spot 1 ..." pins red to spot 1), which spots must be empty. The
arrangement puts each cube on one of the four corner spots, turned as the spot's outline is printed (so the wrist in
its middle grips it squarely), obeying the rule -- drawn at random, but seeded by (set, task, repeat): the same task and
repeat always start the same way, in the twin, on the Dobot and in every round, so their results can be compared run
for run. Only an arrangement the task can be done from is kept: every target worked out from it lands on the sheet,
within the arm's reach, clear of the other cubes, and something is really asked (a cube to move further than a few mm,
or turn more than a few degrees).

A paper-free set (`area:`, V4.1) has no spots: the cubes go anywhere in the area by hand. The twin's are put at seeded
random places in it (in reach, START_GAP_MM apart, randomly turned) -- again only where the task can be done from; on
the Dobot the camera sees where the hand put them, and check_start says whether the task can be done from there.
"""
from __future__ import annotations

import itertools
import math
import random
from typing import Optional

from watcher.tasks import (Cube, Task, TaskSet, angle_difference, beside_point, from_spot_point, position_targets,
                           stacked, with_hidden)

EDGE_MARGIN_MM = 3.0           # a cube's outline this far inside the sheet's edge at least
MIN_REACH_MM, MAX_REACH_MM = 160.0, 290.0
CLEAR_MM = 10.0                # cubes' outlines this far apart at least (their middles one cube size more): a turned
                               # cube reaches 17.7 mm from its middle, and the tools want 3 mm round it
MIN_MOVE_MM, MIN_TURN_DEG = 15.0, 10.0
START_GAP_MM = 40.0            # a paper-free start: this much space between the cubes (asked of the hand; the twin's)
SEEN_GAP_MM = 30.0             # ... and the least the camera's look at the hand's start accepts
END_SLACK_MM = 20.0            # a paper-free task's cubes may end this far outside the area (still in reach)
RANDOM_TRIES = 3000            # random starts tried for a paper-free task before saying none suits it
COUNT_SAMPLES = 200            # random starts the task checker tries (how many of them suit the task)
BETWEEN_ROOM_MM = 15.0         # "between": this much space on each side of the cube put there (the open fingers)


def arranged(task: Task, tasks: TaskSet, set_name: str, repeat: int) -> Task:
    """The task with this run's start arrangement (a sheet task), or as it is (a fixed layout)."""
    if task.start_rule is None:
        return task
    from dataclasses import replace
    cubes, info = arrange(task, tasks, set_name, repeat)
    return replace(task, start=cubes, arrangement=info)


def colour_of(name: str) -> str:
    return str(name).replace(" cube", "").strip()


def designed_sheet(tasks: TaskSet) -> TaskSet:
    """The set with its spots where the sheet was designed to lie. Each arrangement is chosen on it, so the choice
    depends only on (set, task, repeat) -- not on a few mm of difference in where the camera found the paper -- and is
    the same in the twin, on the Dobot and in every round; the cubes then go on those spots where the paper really is."""
    if tasks.sheet is None:
        return tasks
    from dataclasses import replace
    from app.vision.paper import DESIGNED
    from watcher.tasks import sheet_spots
    return replace(tasks, zones={**tasks.zones, **sheet_spots()}, paper=DESIGNED)


def _on(zones: dict, colours: list[str], where: dict) -> list[Cube]:
    return [Cube(f"{c} cube", zones[where[c]].cx, zones[where[c]].cy, zones[where[c]].yaw) for c in colours]


def arrange(task: Task, tasks: TaskSet, set_name: str, repeat: int) -> tuple[list[Cube], dict]:
    """(the cubes as they start, {"seed", "spots": {colour: spot number}}) for one run of a sheet task -- or, for a
    paper-free one, {"seed", "xy": {colour: [x, y, yaw]}}. Raises ValueError, saying why, if no arrangement suits it."""
    if tasks.area is not None:
        return _arrange_random(task, tasks, f"{set_name}|{task.id}|{repeat}")
    rule = task.start_rule or {}
    colours = [colour_of(c) for c in rule.get("cubes", [])]
    pin = {colour_of(c): str(s) for c, s in (rule.get("pin") or {}).items()}
    free = {str(s) for s in rule.get("free") or []}
    spots = sorted(name for name in tasks.zones if name.startswith("spot_"))
    unknown = [s for s in list(pin.values()) + list(free) if s not in spots]
    if unknown or set(pin) - set(colours):
        raise ValueError(f"{task.id}: start rule names " + (f"unknown spots {unknown}" if unknown else
                                                              f"cubes not on the sheet {sorted(set(pin) - set(colours))}"))
    seed = f"{set_name}|{task.id}|{repeat}"
    rng = random.Random(seed)
    loose = [c for c in colours if c not in pin]
    open_spots = [s for s in spots if s not in free and s not in pin.values()]
    choices = list(itertools.permutations(open_spots, len(loose)))
    rng.shuffle(choices)
    why = "no free spots for the cubes"
    designed = designed_sheet(tasks)
    for choice in choices:
        where = dict(pin)
        where.update(zip(loose, choice))
        problem = check_arrangement(task, designed, _on(designed.zones, colours, where))
        if problem is None:
            return (_on(tasks.zones, colours, where),
                    {"seed": seed, "spots": {c: int(where[c].split("_")[1]) for c in colours}})
        why = problem
    raise ValueError(f"{task.id}: no arrangement of {', '.join(colours)} on the sheet suits it ({why})")


def count_arrangements(task: Task, tasks: TaskSet) -> int:
    """How many different arrangements suit the task (for the task checker). A paper-free task: how many of
    COUNT_SAMPLES random starts (in reach, apart) suit it."""
    if tasks.area is not None:
        rng = random.Random(f"count|{task.id}")
        colours = [colour_of(c) for c in (task.start_rule or {}).get("cubes", [])]
        good = 0
        for _ in range(COUNT_SAMPLES):
            cubes = _random_start(rng, tasks, colours)
            good += cubes is not None and check_arrangement(task, tasks, cubes) is None
        return good
    rule = task.start_rule or {}
    colours = [colour_of(c) for c in rule.get("cubes", [])]
    pin = {colour_of(c): str(s) for c, s in (rule.get("pin") or {}).items()}
    free = {str(s) for s in rule.get("free") or []}
    spots = sorted(name for name in tasks.zones if name.startswith("spot_"))
    loose = [c for c in colours if c not in pin]
    open_spots = [s for s in spots if s not in free and s not in pin.values()]
    good = 0
    designed = designed_sheet(tasks)
    for choice in itertools.permutations(open_spots, len(loose)):
        where = dict(pin)
        where.update(zip(loose, choice))
        good += check_arrangement(task, designed, _on(designed.zones, colours, where)) is None
    return good


def predicted_end(task: Task, tasks: TaskSet, cubes: list[Cube]) -> tuple[dict, dict, set, Optional[str]]:
    """Where each cube should end if the task is done, worked out target by target in order (a later step uses where
    an earlier one put a cube): (start {label: Cube}, end {label: Cube}, the cubes acted on, a problem or None)."""
    start = {c.label: c for c in cubes}
    end = {c.label: Cube(c.label, c.x, c.y, c.yaw, c.level) for c in cubes}
    acted: set[str] = set(task.oracle)
    size = tasks.cube_size_mm

    def need(*labels):
        missing = [label for label in labels if label not in end]
        return f"names {', '.join(missing)}, not on the sheet" if missing else None

    for target in task.targets:
        (kind, spec), = target.items()
        if kind == "in_zone":
            problem = need(spec["cube"])
            if problem:
                return start, end, acted, problem
            zone = tasks.zones[spec["zone"]]
            c = end[spec["cube"]]
            end[spec["cube"]] = Cube(c.label, zone.cx, zone.cy, c.yaw)
            acted.add(spec["cube"])
        elif kind == "moved":
            problem = need(spec["cube"])
            if problem:
                return start, end, acted, problem
            c = end[spec["cube"]]
            if "radial" in spec:
                r = math.hypot(c.x, c.y)
                k = (r + float(spec["radial"])) / r
                end[c.label] = Cube(c.label, c.x * k, c.y * k, c.yaw)
            else:
                end[c.label] = Cube(c.label, c.x + float(spec.get("dx", 0)), c.y + float(spec.get("dy", 0)), c.yaw)
            via = spec.get("via") or {}
            if via:                                # (an out-and-on move: its first leg must be in reach too)
                vx, vy = c.x + float(via.get("dx", 0)), c.y + float(via.get("dy", 0))
                if not MIN_REACH_MM <= math.hypot(vx, vy) <= MAX_REACH_MM:
                    return start, end, acted, (f"the {c.label}'s first leg would end {math.hypot(vx, vy):.0f} mm from "
                                               "the base")
            acted.add(c.label)
        elif kind == "beside":
            problem = need(spec["cube"], spec["of"])
            if problem:
                return start, end, acted, problem
            of, c = end[spec["of"]], end[spec["cube"]]
            x, y = beside_point(of, spec["side"], size, float(spec["gap"]))
            end[c.label] = Cube(c.label, x, y, c.yaw)
            acted.add(c.label)
        elif kind == "between":
            problem = need(spec["cube"], spec["a"], spec["b"])
            if problem:
                return start, end, acted, problem
            a, b, c = end[spec["a"]], end[spec["b"]], end[spec["cube"]]
            if math.hypot(a.x - b.x, a.y - b.y) < 2 * (size + BETWEEN_ROOM_MM):
                return start, end, acted, (f"the {a.label} and the {b.label} are too close for a cube between them "
                                           f"(at least {2 * (size + BETWEEN_ROOM_MM) - size:.0f} mm of space)")
            end[c.label] = Cube(c.label, (a.x + b.x) / 2, (a.y + b.y) / 2, c.yaw)
            acted.add(c.label)
        elif kind == "from_spot":
            problem = need(spec["cube"])
            if problem:
                return start, end, acted, problem
            x, y = from_spot_point(tasks.zones[spec["spot"]], spec["side"], float(spec["distance"]))
            c = end[spec["cube"]]
            end[c.label] = Cube(c.label, x, y, c.yaw)
            acted.add(c.label)
        elif kind == "swapped":
            problem = need(spec["a"], spec["b"])
            if problem:
                return start, end, acted, problem
            a, b = end[spec["a"]], end[spec["b"]]
            end[a.label], end[b.label] = Cube(a.label, b.x, b.y, a.yaw), Cube(b.label, a.x, a.y, b.yaw)
            acted.update((a.label, b.label))
        elif kind == "yaw":
            problem = need(spec["cube"])
            if problem:
                return start, end, acted, problem
            c = end[spec["cube"]]
            if angle_difference(c.yaw, float(spec["deg"])) <= MIN_TURN_DEG:
                return start, end, acted, f"the {c.label} would already be within {MIN_TURN_DEG:.0f}° of {spec['deg']}°"
            end[c.label] = Cube(c.label, c.x, c.y, float(spec["deg"]))
            acted.add(c.label)
        elif kind == "turned":
            problem = need(spec["cube"])
            if problem:
                return start, end, acted, problem
            c = end[spec["cube"]]
            if angle_difference(0.0, float(spec["deg"])) <= MIN_TURN_DEG:
                return start, end, acted, f"turning the {c.label} {spec['deg']}° leaves it looking the same"
            end[c.label] = Cube(c.label, c.x, c.y, c.yaw + float(spec["deg"]))
            acted.add(c.label)
        elif kind == "row":
            problem = need(*spec["cubes"])
            if problem:
                return start, end, acted, problem
            acted.update(spec["cubes"])           # (where the row goes is the robot's choice)
        elif kind == "tower":                     # bottom first: each on the one before, where the bottom one is
            problem = need(*spec["cubes"])
            if problem:
                return start, end, acted, problem
            bottom = end[spec["cubes"][0]]
            for j, label in enumerate(spec["cubes"]):
                end[label] = Cube(label, bottom.x, bottom.y, end[label].yaw, j + 1)
            acted.update(spec["cubes"])
        elif kind in ("all_in_zone", "zone_empty", "at_start"):
            continue
    return start, end, acted, None


def check_arrangement(task: Task, tasks: TaskSet, cubes: list[Cube]) -> Optional[str]:
    """Why the task can't be done from this arrangement, or None if it can."""
    twice = sorted(label for label, n in position_targets(task).items() if n > 1)
    if twice:                     # (each target is checked against the cube's final place: both can't hold)
        return f"{', '.join(twice)} has two targets saying where it ends; no run can meet both"
    start, end, acted, problem = predicted_end(task, tasks, cubes)
    if problem:
        return problem
    size = tasks.cube_size_mm
    for label, c in end.items():
        if label in acted and tasks.area is None and not on_sheet(tasks, c.x, c.y, size / 2 + EDGE_MARGIN_MM):
            return f"the {label} would end off the sheet, at ({c.x:.0f}, {c.y:.0f})"
        if label in acted and tasks.area is not None and not in_area(tasks, c.x, c.y, -END_SLACK_MM):
            return f"the {label} would end outside the area the cubes are used in, at ({c.x:.0f}, {c.y:.0f})"
        r = math.hypot(c.x, c.y)
        if label in acted and not MIN_REACH_MM <= r <= MAX_REACH_MM:
            return f"the {label} would end {r:.0f} mm from the base (the arm works {MIN_REACH_MM:.0f}-{MAX_REACH_MM:.0f})"
    turned_only = {t_spec["cube"] for t in task.targets for t_kind, t_spec in t.items() if t_kind in ("yaw", "turned")}
    positioned = {lbl for t in task.targets for t_kind, t_spec in t.items() if t_kind not in ("yaw", "turned")
                  for lbl in ([t_spec["cube"]] if "cube" in t_spec and isinstance(t_spec.get("cube"), str) else [])}
    for label in positioned:
        if label in end and label in start:
            s, e = start[label], end[label]
            if math.hypot(e.x - s.x, e.y - s.y) < MIN_MOVE_MM and label not in turned_only:
                return f"the {label} would already be where it's asked to go"
    labels = list(end)
    for i, a in enumerate(labels):
        for b in labels[i + 1:]:
            if stacked(end[a], end[b]):            # (one on the other: a tower, as asked or as it started)
                continue
            gap = math.hypot(end[a].x - end[b].x, end[a].y - end[b].y)
            if gap < size + CLEAR_MM:
                return f"the {a} and the {b} would end {gap:.0f} mm apart (too close)"
    return None


def in_area(tasks: TaskSet, x: float, y: float, inset: float) -> bool:
    """(x, y) at least `inset` inside a paper-free set's area (a negative inset: that far outside it at most)."""
    (x0, x1), (y0, y1) = tasks.area["x"], tasks.area["y"]
    return x0 + inset <= x <= x1 - inset and y0 + inset <= y <= y1 - inset


def _random_start(rng: random.Random, tasks: TaskSet, colours: list[str]) -> Optional[list[Cube]]:
    """One random start for a paper-free task: each cube somewhere in the area, in reach, START_GAP_MM from the others,
    randomly turned (None if the cubes didn't fit after a few tries)."""
    (x0, x1), (y0, y1) = tasks.area["x"], tasks.area["y"]
    size = tasks.cube_size_mm
    cubes: list[Cube] = []
    for colour in colours:
        for _ in range(50):
            x, y = rng.uniform(x0, x1), rng.uniform(y0, y1)
            if (MIN_REACH_MM <= math.hypot(x, y) <= MAX_REACH_MM
                    and all(math.hypot(x - c.x, y - c.y) >= size + START_GAP_MM for c in cubes)):
                cubes.append(Cube(f"{colour} cube", round(x, 1), round(y, 1), round(rng.uniform(-45.0, 45.0), 1)))
                break
        else:
            return None
    return cubes


def _arrange_random(task: Task, tasks: TaskSet, seed: str) -> tuple[list[Cube], dict]:
    colours = [colour_of(c) for c in (task.start_rule or {}).get("cubes", [])]
    rng = random.Random(seed)
    why = "the cubes don't fit in the area"
    for _ in range(RANDOM_TRIES):
        cubes = _random_start(rng, tasks, colours)
        if cubes is None:
            continue
        problem = check_arrangement(task, tasks, cubes)
        if problem is None:
            return cubes, {"seed": seed, "xy": {colour_of(c.label): [c.x, c.y, c.yaw] for c in cubes}}
        why = problem
    raise ValueError(f"{task.id}: no random start of {', '.join(colours)} suits it ({why})")


def chain_start(tasks: TaskSet, task_id: str) -> list[Cube]:
    """A chained set (Simple 20): where the cubes are at the start of `task_id` if every task before it was done as
    asked, from the set's starting layout -- every cube, the ones a tower hides too (each with its level). The twin
    sets this out when a session starts part-way (a group, or one task, run on its own)."""
    from watcher.tasks import layout_cubes
    cubes = layout_cubes(tasks)
    for task in tasks.tasks:
        if task.id == task_id:
            break
        _, end, _, problem = predicted_end(task, tasks, cubes)
        if problem is None:
            cubes = list(end.values())
    return cubes


def check_start(task: Task, tasks: TaskSet, seen: list[Cube]) -> Optional[str]:
    """A paper-free task's start as the camera sees it: what to change before the run (a short line for the person
    at the table), or None when it's ready -- the task's cubes there and no others, each in the area and the arm's
    reach, apart, and the task doable from where they are. A task that starts from a tower (start: {tower: [...]}):
    its top cube seen that many cubes up, the ones under it taken to be there (the camera can't see them)."""
    wanted = {f"{colour_of(c)} cube" for c in (task.start_rule or {}).get("cubes", [])}
    if task.tower:
        seen = with_hidden(list(seen), [task.tower], tasks.cube_size_mm)
        top = next((c for c in seen if c.label == task.tower[-1]), None)
        if top is None or top.level != len(task.tower):
            return (f"This task starts from a tower: {', then '.join(task.tower)} on top (bottom first). The camera "
                    "doesn't see it like that.")
    else:
        high = next((c for c in seen if c.level > 1), None)
        if high is not None:
            return f"The {high.label} is on top of another cube: put it on the table."
    labels = [c.label for c in seen]
    missing = sorted(wanted - set(labels))
    if missing:
        return "Put " + " and ".join(f"the {m}" for m in missing) + " on the grey sheet."
    extra = sorted(set(labels) - wanted)
    if extra:
        return "Take " + " and ".join(f"the {e}" for e in extra) + " off the table."
    twice = sorted({lbl for lbl in labels if labels.count(lbl) > 1})
    if twice:
        return f"The camera sees two of the {twice[0]}; leave one."
    for c in seen:
        r = math.hypot(c.x, c.y)
        if r < MIN_REACH_MM:
            return f"Move the {c.label} further from the robot."
        if r > MAX_REACH_MM or c.x > tasks.area["x"][1]:
            return f"Move the {c.label} nearer the robot."
        if c.x < tasks.area["x"][0]:
            return f"Move the {c.label} further from the robot."
        if c.y > tasks.area["y"][1]:
            return f"Move the {c.label} towards the middle (it's too far to the robot's left)."
        if c.y < tasks.area["y"][0]:
            return f"Move the {c.label} towards the middle (it's too far to the robot's right)."
    size = tasks.cube_size_mm
    for i, a in enumerate(seen):
        for b in seen[i + 1:]:
            if a.label in task.tower and b.label in task.tower and stacked(a, b):
                continue                          # (the start's own tower)
            if math.hypot(a.x - b.x, a.y - b.y) - size < SEEN_GAP_MM:
                return (f"Move the {a.label} and the {b.label} further apart (at least {START_GAP_MM / 10:.0f} cm of "
                        "space between them).")
    problem = check_arrangement(task, tasks, seen)
    if problem:
        return f"The task can't be done from here: {problem}. Move the cubes and it looks again."
    return None


# ---- a chained set's scene, before each task (V4.2): whatever the task before left, nothing sorted -------------------
# Every task starts from the table as it is: the watcher looks (the arm parked; again from a second pose if a cube is
# missing), works out the cubes a tower hides, and says what the scene is like -- it never waits for a layout. A task
# starts if any of its own cubes is there; the parts that need a cube that can't be seen are recorded as impossible.
CUBE_KEYS = ("cube", "of", "a", "b")


def task_cubes(task: Task) -> list[str]:
    """The cubes a task's targets name (and its oracle's), in order: "its own cubes"."""
    out: list[str] = []
    for target in task.targets:
        (_, spec), = target.items()
        for key in CUBE_KEYS:
            if isinstance(spec.get(key), str) and spec[key].endswith("cube"):
                out.append(spec[key])
        out += [c for c in spec.get("cubes") or [] if isinstance(c, str)]
    out += list(task.oracle)
    return list(dict.fromkeys(out))


def target_cubes(spec: dict) -> list[str]:
    """The cubes one target names."""
    out = [spec[k] for k in CUBE_KEYS if isinstance(spec.get(k), str) and spec[k].endswith("cube")]
    return out + [c for c in spec.get("cubes") or [] if isinstance(c, str)]


def infer_hidden(seen: list[Cube], known: dict[str, Cube], size: float = 25.0) -> tuple[list[Cube], dict[str, str]]:
    """The cubes seen, and those a tower hides wherever it stands: a cube seen k levels up has k-1 cubes under it --
    the cubes not seen now that were last seen there (`known`: each cube where it was last seen), lowest first.
    Returns (the cubes, {hidden cube: the cube on top of it})."""
    out = list(seen)
    labels = {c.label for c in out}
    hidden: dict[str, str] = {}
    for top in sorted((c for c in seen if c.level > 1), key=lambda c: -c.level):
        under = [c for c in out if c is not top and stacked(c, top) and c.level < top.level]
        need = top.level - 1 - len(under)
        if need <= 0:
            continue
        pool = sorted((k for label, k in known.items() if label not in labels
                       and math.hypot(k.x - top.x, k.y - top.y) <= size),
                      key=lambda k: (k.level, math.hypot(k.x - top.x, k.y - top.y)))
        taken = {c.level for c in under}
        free = [lv for lv in range(1, top.level) if lv not in taken]
        for level, k in zip(free, pool[:need]):
            out.append(Cube(k.label, top.x, top.y, k.yaw, level))
            labels.add(k.label)
            hidden[k.label] = top.label
    return out, hidden


def merge_scene(first: list[Cube], second: list[Cube]) -> list[Cube]:
    """Two looks from two arm positions: the first's cubes, and any the second saw that the first didn't."""
    have = {c.label for c in first}
    return list(first) + [c for c in second if c.label not in have]


def scene_report(task: Task, tasks: TaskSet, cubes: list[Cube], expected: list[str],
                 hidden: Optional[dict[str, str]] = None) -> dict:
    """What the scene is like for this task (the cubes as seen, the hidden ones included): which of the session's
    cubes can't be seen, the start condition, each target's part -- possible, or impossible and why -- and whether the
    task can start at all (any of its own cubes there) or the table is empty."""
    hidden = hidden or {}
    present = {c.label for c in cubes}
    missing = [label for label in expected if label not in present]
    size = tasks.cube_size_mm
    condition = []
    if any(c.level > 1 for c in cubes) or hidden:
        condition.append("tower to take down")
    if tasks.area is not None and any(not in_area(tasks, c.x, c.y, 0.0) or
                                      not MIN_REACH_MM <= math.hypot(c.x, c.y) <= MAX_REACH_MM for c in cubes):
        condition.append("cube out of the tray")
    if any(not stacked(a, b) and math.hypot(a.x - b.x, a.y - b.y) - size < SEEN_GAP_MM
           for i, a in enumerate(cubes) for b in cubes[i + 1:]):
        condition.append("cubes close together")
    if missing:
        condition.append("cube not seen")
    parts = []
    for i, target in enumerate(task.targets):
        (kind, spec), = target.items()
        gone = [label for label in target_cubes(spec) if label not in present]
        parts.append({"part": i + 1, "kind": kind, "cubes": target_cubes(spec), "possible": not gone,
                      "why": f"the {' and the '.join(gone)} can't be seen" if gone else ""})
    own = task_cubes(task)
    return {"cubes": [c.__dict__ for c in cubes], "hidden": hidden, "missing": missing,
            "condition": condition or ["clean"], "parts": parts, "empty": not cubes,
            "can_start": any(label in present for label in own), "own_cubes": own}


def moved_by(task: Task) -> set[str]:
    """The cubes a task moves or turns (picks up) -- not the ones it only measures from ("of", "a", "b")."""
    out: set[str] = set(task.oracle)
    for target in task.targets:
        (kind, spec), = target.items()
        if kind == "swapped":
            out.update((spec["a"], spec["b"]))
        elif kind in ("tower", "row"):
            out.update(spec["cubes"])
        elif isinstance(spec.get("cube"), str):
            out.add(spec["cube"])
    return out


def blocking_cubes(task: Task, tasks: TaskSet, cubes: list[Cube]) -> dict[str, str]:
    """The cubes the task doesn't name that are in its way at the start -- on top of one of its cubes, or where one
    of its cubes is to go: {label: why}. Moving them out of the way is allowed (they must end on the table, not
    stacked, inside the tray) -- the "allowed preparation" rule."""
    own = set(task_cubes(task))
    moving = moved_by(task)
    size = tasks.cube_size_mm
    try:
        _, end, _, _ = predicted_end(task, tasks, cubes)
    except (KeyError, ValueError):
        end = {}
    out: dict[str, str] = {}
    for c in cubes:
        if c.label in own:
            continue
        if any(o.label in own and stacked(c, o) and o.level > c.level for o in cubes):
            continue                               # (one of the task's own cubes is on it: it stays)
        under = next((o for o in cubes if o.label in moving and stacked(c, o) and c.level > o.level), None)
        if under is not None:
            out[c.label] = f"on top of the {under.label}"
            continue
        goes = next((label for label in own if label in end and label != c.label
                     and math.hypot(end[label].x - c.x, end[label].y - c.y) < size + CLEAR_MM), None)
        if goes is not None:
            out[c.label] = f"where the {goes} is to go"
    return out


def on_sheet(tasks: TaskSet, x: float, y: float, inset: float) -> bool:
    """(x, y) at least `inset` inside the sheet's edges, where the sheet lies (tasks.paper). The edges are the design's
    A4 sheet's whatever paper it is printed on: the starts and targets are part of the study's design -- seeded by
    set, task and repeat, the same in every study -- and on US Letter's narrower sheet (2026-10-19) 2 training tasks
    lost a third of their starts and others changed, and a test set checked on A4 could have had none left. (A target
    at the edge may then reach a few mm past a Letter sheet's: onto the mat, which is fine -- nothing is scored by the
    paper.)"""
    from app.vision.paper import DESIGNED, PAPERS
    PAPER_MM = PAPERS["a4"][1]
    pose = tasks.paper or DESIGNED
    t = math.radians(pose.turn_deg)
    dx, dy = x - pose.x, y - pose.y
    along_x = dx * math.cos(t) + dy * math.sin(t)
    along_y = -dx * math.sin(t) + dy * math.cos(t)
    return abs(along_x) <= PAPER_MM[1] / 2 - inset and abs(along_y) <= PAPER_MM[0] / 2 - inset

"""The Kyozo Watcher window: runs the study's tasks on the robot with nobody typing, one after another, and saves
everything about each run as it happens (see study/RUNBOOK.md, section 6).

For each run: the table check (the camera compares the cubes with the task's layout and says what to move; Start run
lights up when every cube is within 5 mm and 5 degrees) -> the run (the task's fixed prompt, sent by the watcher) ->
the arm parks -> the end pictures -> the observer's verdict (saved before the score is shown) -> the watcher's score
-> saved -> next.

Practice or real: the Real test switch. During a test session nothing is written to app.log (the project's log,
which Claude can read): every log line goes to the session's own folder instead.
"""
from __future__ import annotations

import html
import json
import logging
import math
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from PyQt6.QtCore import QRect, QSize, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFontMetrics
from PyQt6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QGridLayout,
                             QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMenu, QMessageBox, QPlainTextEdit,
                             QPushButton, QSpinBox, QStyledItemDelegate, QStyleOptionViewItem, QTabWidget,
                             QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from app.cube_size import cube_mm, describe as describe_cube
from watcher import details, extract, model_log, observe, report, results
from watcher.arrange import arranged
from watcher.taxonomy import RunFacts, classify, count_refusals, motion_efficiency, object_labels_from
from watcher.arrange import infer_hidden
from watcher.tasks import (Cube, Task, TaskSet, angle_difference, difficulty, how_to_judge, load_task_set,
                           match, moved_cubes, outcome, partial_credit, score)

logger = logging.getLogger(__name__)


class WrapDelegate(QStyledItemDelegate):
    """A column's text in full, wrapped to the column's width: each row as tall as its text needs, never cut short
    with "..." (study 2's lab notes: the prompts in the plan were cut off)."""

    def __init__(self, tree: QTreeWidget):
        super().__init__(tree)
        self.tree = tree

    def initStyleOption(self, option, index) -> None:  # noqa: N802 (Qt)
        super().initStyleOption(option, index)
        option.features |= QStyleOptionViewItem.ViewItemFeature.WrapText
        option.textElideMode = Qt.TextElideMode.ElideNone

    def sizeHint(self, option, index) -> QSize:  # noqa: N802 (Qt)
        hint = super().sizeHint(option, index)
        text = str(index.data(Qt.ItemDataRole.DisplayRole) or "")
        font = index.data(Qt.ItemDataRole.FontRole) or option.font
        width = max(40, self.tree.columnWidth(index.column()) - 10)
        needed = QFontMetrics(font).boundingRect(QRect(0, 0, width, 1 << 20), Qt.TextFlag.TextWordWrap, text)
        return QSize(hint.width(), max(hint.height(), needed.height() + 6))

TRAIN_FILE = observe.PROJECT_ROOT / "study" / "tasks" / "train.yaml"
SIMPLE_FILE = observe.PROJECT_ROOT / "study" / "tasks" / "simple.yaml"     # Simple 20: the hands-off V4.1 test
SETUP_MM, SETUP_DEG = 5.0, 5.0            # a cube is set up when it is this close to its place in the layout
START_LOOKS, END_LOOKS = 5, 5             # pictures in the start's and the end's look (each cube: the median)
START_MOVED_MM = 5.0                       # no paper: moved more than this since READY (a hand at it): not started
CHECK_EVERY_MS = 1500
# study n runs the app after n - 1 updates (study 1: the baseline); up to results.MAX_STUDIES studies
VERSIONS = {n: "base" if n == 1 else f"v{n - 1}" for n in results.STUDIES}
ROUND_NAMES = {n: "Study 1 · baseline (v0)" if n == 1 else f"Study {n} · after update {n - 1} (v{n - 1})"
               for n in results.STUDIES}
# the four kinds of session in every round: (set, where, the menu's words). The twin ones run in Demo mode, the Dobot
# ones in Live mode.
SESSION_KINDS = (("train", "twin", "Task for Twin"), ("train", "dobot", "Task for Dobot"),
                 ("test", "twin", "Test Twin with unseen tasks"), ("test", "dobot", "Test Real Dobot with unseen tasks"),
                 ("simple", "twin", "20 Tasks for Twin (by itself)"),
                 ("simple", "dobot", "20 Tasks for Dobot (by itself)"))
# the Session menu shows these sets only (Rafi, 2026-10-22: the unseen test and Simple 20 -- the training sessions
# are kept in the code, out of the menu), and opens on DEFAULT_SET
MENU_SETS = ("test", "simple")
DEFAULT_SET = "simple"
TEST_REPEATS = {"dobot": 2, "twin": 1}     # each unseen test task's runs per round (Rafi, 2026-10-12)
VERDICTS = ("pass", "fail", "dropped", "helped", "skipped")
# the difficulty levels' words in the session plan (the study's task file gives each task "level: 1" .. "level: 4")
LEVEL_WORDS = {1: "one cube, one step", 2: "one cube, two steps or directions", 3: "two cubes", 4: "three cubes"}
LEVEL_CHIPS = {n: f"Level {n}" for n in range(1, 5)}      # (what each level is: LEVEL_WORDS, in its tooltip)
STATUS_COLOURS = {"Pass": "#7fe0b0", "Fail": "#ff8a8a", "Now": "#4bb8ad", "Discarded": "#8fa8ba",
                  "Skipped": "#e0a030", "Some parts": "#f0d070"}
GROUP_LETTERS = "ABCD"     # Simple 20's levels 1-4 are its groups A-D
SCENE_LOOKS = 3            # a chained set's scene before each task: pictures from each arm position (V4.2)
EMPTY_TASKS_END = 3        # ... no cube seen at all for this many tasks in a row: the session ends
SECOND_POSE_MM = 25.0      # the arm's park counts as reached within this of where it was sent
SWING_MM, SWING_LIFT_MM = 80.0, 60.0   # a park this far away: the arm lifted this much first (not low over the tray)
CHAINED_TIME_LIMIT_S = 600.0  # a chained set's task (Simple 20, the unseen test) when its file gives no limit (V4.2:
                             # 10 min, simple.yaml's own; the test's file says 5, as PREREG 3 does -- it was raised to 10)
RAN_WORDS = ("Pass", "Fail", "Some parts")   # a plan line's status once its run is scored ("Some parts": not a pass)
SIMPLE_COUNTDOWN_S = 5     # Simple 20 on the Dobot: READY, then this long before the run starts by itself (E-STOP)
SIMPLE_READY_S = 20.0      # Simple 20: the table not READY this long -> that task is skipped (logged) and the next one
INFRA_RETRIES = 2          # an infrastructure failure is run again at the end of the session, at most this often
AUTO_READY_S = 60.0        # Run by itself: the table not READY this long -> it pauses for you
AUTO_INFRA_IN_ROW = 2      # Run by itself: this many infrastructure failures in a row -> it pauses for you
AUTO_NOTE = "ran by itself (no person watching)"
HIDDEN_DETAILS = "(where each cube ended: hidden for a test task, as its prompt is)"


@dataclass
class WatcherContext:
    """What the watcher needs from the app: the robot, camera and tools it already runs with."""
    robot: object
    camera: object
    scene_builder: object
    executor: object
    agent: object
    config: dict
    mode: str                                     # "demo" or "live"
    estop: Callable[[], None]
    poses_dir: Path
    calibration_file: Optional[Path] = None
    twin_world: object = None                     # demo: the simulated world (the watcher sets the cubes out itself)
    on_session_active: Callable[[bool], None] = lambda active: None
    park_pose: Optional[tuple] = None             # where the arm waits out of the camera's way (default: look pose)
    # (read when the context is made, so a test can point results.RESULTS_ROOT at a temporary folder)
    results_root: Path = field(default_factory=lambda: results.RESULTS_ROOT)
    make_3d_view: Optional[Callable[[], object]] = None   # demo: the app's 3D view (the real Magician model)
    held: Callable[[], Optional[str]] = lambda: None      # why the app holds the camera and arm now (Camera setup)
    # which calibration is in use, and what the continuous calibration has done (each run records it)
    calibration_state: Callable[[], dict] = lambda: {}


COMPACT_BUTTON = "QPushButton { min-width: 0px; padding: 4px 12px; }"   # (the Session plan's small buttons)
# (short, so the Session plan's rows fit on one line; their tooltips say more)
ORDERS = {"rounds": "In rounds", "together": "Back to back"}
STARTS = {"new": "New start", "same": "Same start"}


def default_times(set_name: str, where: str) -> int:
    """Each task's runs in a session as planned: training (and Simple 20) once; the unseen test TEST_REPEATS[where]
    times."""
    return TEST_REPEATS.get(where, 1) if set_name == "test" else 1


def plan_runs(tasks: TaskSet, set_name: str, where: str, picked: Optional[list[str]] = None,
              times: Optional[int] = None, order: str = "rounds", start: str = "new") -> list[tuple[Task, int]]:
    """The runs of a session, in order: (task, repeat). As planned (nothing given): training every task once; the
    unseen test every task TEST_REPEATS[where] times (on the Dobot twice, repeat 2 after all of repeat 1; in the twin
    once), the same in every round. `picked`: only these tasks (in the task file's order); `times`: each task's runs;
    `order`: "rounds" (all once, then again) or "together" (each task's runs back to back); `start`: "new" (each
    repeat its own arrangement) or "same" (every repeat starts as repeat 1). A task on the A4 sheet gets its run's
    start arrangement (watcher/arrange.py: seeded by the set, task and repeat, so the same in the twin, on the Dobot and
    in every round)."""
    repeats = times if times is not None else default_times(set_name, where)
    chosen = [t for t in tasks.tasks if picked is None or t.id in set(picked)]
    if order == "together":
        runs = [(t, r) for t in chosen for r in range(1, repeats + 1)]
    else:
        runs = [(t, r) for r in range(1, repeats + 1) for t in chosen]
    return [(arranged(t, tasks, set_name, 1 if start == "same" else r), r) for t, r in runs]


def paper_pose_for(ctx) -> tuple[object, str]:
    """(the A4 sheet's pose the spots follow, where it came from in words). The twin: exactly where designed. Live: as
    the camera found it (calibration_paper.json next to the calibration, written by "Cube calibration with paper" or the
    watcher's Find the paper); not found yet: as designed, said."""
    from app.vision.paper import DESIGNED, PaperPose, load_paper, paper_path
    if ctx.twin_world is not None:
        return PaperPose(found="twin"), "the twin: the paper is exactly where designed"
    pose = load_paper(paper_path(ctx.calibration_file)) if ctx.calibration_file else None
    if pose is None:
        return DESIGNED, ("the paper hasn't been found by the camera yet (run \"Cube calibration with paper\", or "
                          "press Find the paper): taken as designed")
    return pose, f"the paper as found {pose.when}: {pose.describe()}"


def setup_status(wanted: list[Cube], seen: list[Cube]) -> list[dict]:
    """For each cube of the layout: where it should be, where the camera sees it, and what to do."""
    out = []
    for want, got in zip(wanted, match(wanted, seen)):
        if got is None:
            out.append({"cube": want.label, "ok": False, "say": f"{want.label}: not seen -- put it on its outline"})
            continue
        dx, dy = want.x - got.x, want.y - got.y
        off = math.hypot(dx, dy)
        turn = angle_difference(got.yaw, want.yaw)
        ok = off <= SETUP_MM and turn <= SETUP_DEG
        say = f"{want.label}: OK" if ok else f"{want.label}: " + ", ".join(filter(None, [
            f"{abs(dx):.0f} mm {'away from' if dx > 0 else 'towards'} the robot" if abs(dx) >= 2 else "",
            f"{abs(dy):.0f} mm to the robot's {'left' if dy > 0 else 'right'}" if abs(dy) >= 2 else "",
            f"turn {turn:.0f} deg" if turn > SETUP_DEG else ""]))
        out.append({"cube": want.label, "ok": ok, "off_mm": round(off, 1), "turn_deg": round(turn, 1), "say": say})
    return out


class _LogDiversion(logging.Handler):
    """During a test session: every log line goes to the session's app_log.txt, and none to app.log."""

    def __init__(self, path: Path):
        super().__init__(logging.INFO)
        self.path = path
        self.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        self._muted: list[logging.Handler] = []
        self._filter = lambda record: False

    def emit(self, record: logging.LogRecord) -> None:
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(self.format(record) + "\n")
        except OSError:
            pass

    def __enter__(self):
        root = logging.getLogger()
        for h in root.handlers:
            if isinstance(h, logging.FileHandler) and Path(h.baseFilename).name in ("app.log",):
                h.addFilter(self._filter)
                self._muted.append(h)
        root.addHandler(self)
        return self

    def __exit__(self, *exc):
        root = logging.getLogger()
        root.removeHandler(self)
        for h in self._muted:
            h.removeFilter(self._filter)
        self._muted.clear()


class SegmentedSwitch(QWidget):
    """Two choices side by side in one rounded control -- Practice | Real test -- the chosen one filled (Real test in
    red). Acts like a checkbox for the window: isChecked() is "the second one", toggled(bool) when it changes."""
    toggled = pyqtSignal(bool)
    OFF_STYLE = "background: transparent; color: #8fa8ba;"
    PRACTICE_STYLE = "background: #e9ecef; color: #212529;"
    REAL_STYLE = "background: #e24b4a; color: white;"
    LOCKED = {"background: #e9ecef; color: #212529;": "background: #9aa3ab; color: #1c2329;",
              "background: #e24b4a; color: white;": "background: #8f3434; color: #f1d5d5;"}

    def __init__(self, first: str, second: str, parent=None):
        super().__init__(parent)
        self._on = False
        row = QHBoxLayout(self)
        row.setContentsMargins(3, 3, 3, 3)
        row.setSpacing(2)
        self.first, self.second = QPushButton(first), QPushButton(second)
        for button, value in ((self.first, False), (self.second, True)):
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setMinimumWidth(96)
            button.clicked.connect(lambda _=False, v=value: self.setChecked(v))
            row.addWidget(button)
        self.setObjectName("segmented")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)   # (else the rounded border isn't drawn)
        self._restyle()

    def isChecked(self) -> bool:          # noqa: N802 (Qt's naming)
        return self._on

    def setChecked(self, on: bool) -> None:   # noqa: N802
        on = bool(on)
        if on == self._on:
            return
        self._on = on
        self._restyle()
        self.toggled.emit(on)

    def changeEvent(self, event) -> None:  # noqa: N802 (greyed out while a session runs)
        super().changeEvent(event)
        from PyQt6.QtCore import QEvent
        if event.type() == QEvent.Type.EnabledChange:    # (not StyleChange: restyling would call this again)
            self._restyle()

    def _restyle(self) -> None:
        # while a session runs (disabled) the chosen side stays filled, so it is clear which kind of session it is
        enabled = self.isEnabled()
        border = "#3a5568" if enabled else "#26394a"
        self.setStyleSheet(f"#segmented {{ border: 1px solid {border}; border-radius: 18px; }}")
        # (a border, even a clear one, is what makes Qt round a button's background)
        shape = "border: 1px solid transparent; border-radius: 14px; padding: 6px 16px; font-weight: bold;"
        for button, style in ((self.first, self.OFF_STYLE if self._on else self.PRACTICE_STYLE),
                              (self.second, self.REAL_STYLE if self._on else self.OFF_STYLE)):
            button.setStyleSheet(shape + (style if enabled else self.LOCKED.get(style, style)))


class PracticeToggle(QWidget):
    """The "Practice session" toggle. ON (the default): every result goes to Practice_Session -- safe to delete,
    never counted. OFF: to the real study (study_N), after a question. isChecked() / setChecked() / toggled speak of
    the REAL side (True: real results), as the switch this replaced did, so the rest of the window reads the same."""
    toggled = pyqtSignal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        from app.ui.settings_panel import ToggleSwitch
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        self.switch = ToggleSwitch()
        self.switch.setChecked(True)
        self.label = QLabel()
        row.addWidget(self.switch)
        row.addWidget(self.label)
        row.addStretch(1)
        self.switch.toggled.connect(self._changed)
        self._show()

    def isChecked(self) -> bool:          # noqa: N802 (Qt's naming) -- True: REAL results
        return not self.switch.isChecked()

    def setChecked(self, real: bool) -> None:   # noqa: N802
        if self.isChecked() != bool(real):
            self.switch.setChecked(not real)

    def _changed(self, practice: bool) -> None:
        self._show()
        if not self.signalsBlocked():
            self.toggled.emit(not practice)

    def _show(self) -> None:
        if self.switch.isChecked():
            self.label.setText("Practice session: ON (saved in Practice_Session, safe to delete)")
            self.label.setStyleSheet("color: #8fa8ba;")
        else:
            self.label.setText("Practice session: OFF - REAL: counts for the paper (study_N)")
            self.label.setStyleSheet("color: #ff8a8a; font-weight: bold;")


class WatcherWindow(QWidget):
    """The window; one per app. Its own E-STOP, the app's toolbar one works too."""
    _done = pyqtSignal(object)         # a background job finished: (kind, result)

    def __init__(self, ctx: WatcherContext, parent=None):
        super().__init__(parent, Qt.WindowType.Window)
        self.ctx = ctx
        self.setWindowTitle("Kyozo Watcher")
        self.resize(980, 720)
        self.session: Optional[results.Session] = None
        self.tasks: Optional[TaskSet] = None
        self.plan: list[tuple[Task, int]] = []
        self.index = -1
        self.events: list[dict] = []              # what the robot reported during the current run
        self.steps: list = []                      # the model's steps during the current run
        self.run: dict = {}                        # the current run's record, filled as it goes
        self.run_folder: Optional[Path] = None
        self._jobs = 0                             # background jobs running (a table check, setting out, the run...)
        self._token = 0                            # changes with every session start and end: a stale job is ignored
        self._stop = threading.Event()             # E-STOP during a run: no further prompt of it is sent
        self._broken = False                       # this run couldn't be scored or saved: Discard only
        self._divert: Optional[_LogDiversion] = None
        self._lock = threading.Lock()
        self._build()
        self._done.connect(self._on_done)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._status_timer = QTimer(self)          # the status strip, once a second (its times; the running dot)
        self._status_timer.timeout.connect(self._refresh_status)
        self._status_timer.start(1000)
        self._set_state("idle")
        self.round_box.currentIndexChanged.connect(lambda _=0: self._preview_plan())
        self.cubes_box.currentIndexChanged.connect(lambda _=0: self._preview_plan())
        self.real.toggled.connect(lambda _=False: self._preview_plan())     # (the runs already saved: practice or real)
        self._preview_plan()

    # ---- the window ------------------------------------------------------------------------------------------------
    def _build(self) -> None:
        v = QVBoxLayout(self)
        from watcher.tour import WatcherTour
        self.tour = WatcherTour(self)              # the walk-through, hidden until "How to use the watcher"
        self.tour.hide()
        v.addWidget(self.tour)
        from watcher.status_strip import StatusStrip
        self.status = StatusStrip()                # what the watcher is doing now: running, waiting for you, done
        self._status_kind, self._ended, self._activity_at = "ready", None, time.monotonic()
        self._pause_why = ""
        v.addWidget(self.status)

        top = QGridLayout()
        self.real = PracticeToggle()                   # (ON: practice; isChecked() is True for REAL results)
        self.real.toggled.connect(self._on_real_toggled)
        # the session: one of the four kinds (the twin's in Demo mode, the Dobot's in Live mode; the others greyed)
        self.session_box = QComboBox()
        here = self._where()
        for set_name, where, words in SESSION_KINDS:
            if set_name not in MENU_SETS:
                continue
            self.session_box.addItem(words, f"{set_name}_{where}")
            item = self.session_box.model().item(self.session_box.count() - 1)
            if where != here:
                item.setEnabled(False)
                item.setToolTip("Needs Live mode (the real Dobot)" if where == "dobot" else
                                "Needs Demo mode (the twin)")
        self.session_box.setToolTip("Test: the unseen tasks, never shown to Claude. Simple 20: three cubes put down "
                                    "once, 20 tasks run by themselves, every run saved.")
        # (the set alone, kept in step with the session menu; hidden)
        self.set_box = QComboBox()
        self.set_box.addItem("Training", "train")      # (first: practice starts on the tasks Claude may see)
        self.set_box.addItem("Test", "test")
        self.set_box.addItem("Simple 20", "simple")
        self.set_box.hide()
        self.session_box.currentIndexChanged.connect(self._session_kind_chosen)
        self.session_box.currentIndexChanged.connect(lambda _=0: self._preview_plan())
        self.set_box.currentIndexChanged.connect(self._set_chosen)
        self.set_box.setCurrentIndex(self.set_box.findData(DEFAULT_SET))
        self.session_box.setCurrentIndex(self.session_box.findData(f"{DEFAULT_SET}_{here}"))
        self.round_box = QComboBox()
        for n, name in ROUND_NAMES.items():
            self.round_box.addItem(name, n)
        self.cubes_box = QComboBox()
        self.cubes_box.addItem("3 cubes (1 R, 1 B, 1 G)", 3)
        self.cubes_box.addItem("6 cubes (2 of each)", 6)
        for col, (label, widget) in enumerate((("Saving to", self.real), ("Session", self.session_box),
                                               ("Study", self.round_box), ("Cubes", self.cubes_box))):
            if label:
                top.addWidget(QLabel(label), 0, col)
            top.addWidget(widget, 1, col)
        v.addLayout(top)

        buttons = QHBoxLayout()
        self.start_btn = QPushButton("Start session")
        self.start_btn.clicked.connect(self.start_session)
        self.end_btn = QPushButton("End session")
        self.end_btn.clicked.connect(lambda: self.end_session("ended by the operator"))
        self.delete_btn = QPushButton("Delete results…")
        self.delete_btn.clicked.connect(self._delete_dialog)
        self.paper_btn = QPushButton("Find the paper")
        self.paper_btn.setToolTip("The camera finds the A4 sheet (white on the cloth) and saves where it is: the spots "
                                  "follow it. Needs a calibration; the arm out of the way; between sessions.")
        self.paper_btn.clicked.connect(self._find_paper)
        self.rebuild_btn = QPushButton("Rebuild reports…")
        self.rebuild_btn.setToolTip("Makes a session's reports again from its saved runs (each run's run_report.txt, the "
                                    "session's workbook): for sessions saved before the reports existed")
        self.rebuild_btn.clicked.connect(self._rebuild_reports)
        self.folder_btn = QPushButton("Open results folder")
        self.folder_btn.clicked.connect(self._open_results)
        self.claude_btn = QPushButton("Claude's input…")
        self.claude_btn.setToolTip("Makes (again) the study's package of the 20 tasks' results for the next "
                                   "improvement, in Kyozo_Link_Results\\For_Claude\\study_N (it is also made by itself "
                                   "after each 20 Tasks session). Never the unseen test's")
        self.claude_btn.clicked.connect(self._make_claude_input)
        # the unseen test set: made from your secret seed (study/make_test_tasks.py), or opened for you to read
        self.tests_btn = QPushButton("Test tasks…")
        self.tests_btn.setToolTip("Make the unseen test set from your secret seed (20 tasks mirroring Simple 20, "
                                  "checked in the twin), or open it to read. Only for you: never shown to Claude")
        tests_menu = QMenu(self.tests_btn)
        tests_menu.addAction("Make test tasks…", self._make_test_tasks)
        tests_menu.addAction("Open the test tasks (to read)", self._open_test_tasks)
        self.tests_btn.setMenu(tests_menu)
        self._testgen = None                        # the generator's process while it runs
        self.guide_btn = QPushButton("How to use the watcher")
        self.guide_btn.setToolTip("A walk-through: watch each step done (demo), or do them yourself with each one "
                                  "checked")
        self.guide_btn.clicked.connect(lambda: self.tour.start())
        estop = QPushButton("E-STOP")
        estop.setStyleSheet("background-color: #c0392b; color: white; font-weight: bold; padding: 6px 16px;")
        estop.clicked.connect(self._estop)
        for b in (self.start_btn, self.end_btn, self.delete_btn, self.paper_btn, self.rebuild_btn, self.folder_btn,
                  self.claude_btn, self.tests_btn, self.guide_btn):
            buttons.addWidget(b)
        buttons.addStretch(1)
        buttons.addWidget(estop)
        v.addLayout(buttons)

        self.task_label = QLabel("No session running.")
        self.task_label.setWordWrap(True)
        self.task_label.setStyleSheet("font-size: 15px; padding: 6px;")
        v.addWidget(self.task_label)

        # left: the table check and the run log; right: the camera, with the ghost outlines while setting up
        middle = QHBoxLayout()
        left = QVBoxLayout()
        middle.addLayout(left, 1)
        from app.ui.video_widget import VideoWidget
        self.video = VideoWidget(self.ctx.camera, fps=10)
        self.video.setMinimumSize(480, 270)
        self._outlines_3d: list[dict] = []
        self.view3d = self.ctx.make_3d_view() if self.ctx.make_3d_view is not None else None
        right = QVBoxLayout()
        if self.view3d is not None:
            # demo: the 3D model only -- the real Magician's shape, with the outlines. The simulated camera's own
            # picture (an arm of plain shapes) is neither shown nor saved; the camera widget stays, hidden, for the
            # outlines' marks (hidden, it doesn't render).
            self.view3d.overlay_provider = lambda: self._outlines_3d
            self.video.hide()
            right.addWidget(self.view3d, 1)
        else:
            right.addWidget(self.video, 1)
        middle.addLayout(right, 1)
        v.addLayout(middle, 1)
        self.setup_text = QPlainTextEdit()
        self.setup_text.setReadOnly(True)
        self.setup_text.setMaximumHeight(105)            # (five lines: the Session plan below needs the room)
        left.addWidget(QLabel("Table check (put each cube on its outline in the picture):"))
        left.addWidget(self.setup_text)
        run_row = QHBoxLayout()
        self.place_btn = QPushButton("Set the cubes out (demo)")
        self.place_btn.clicked.connect(self._place_clicked)
        self.run_btn = QPushButton("Start run")
        self.run_btn.clicked.connect(self._start_run)
        self.override = QCheckBox("Start without the table check (practice only)")
        self.override.setToolTip("Practice: lets Start run work although the cubes aren't all on their outlines (the "
                                 "run is marked as started that way). Real tests always need the table check.")
        run_row.addWidget(self.place_btn)
        run_row.addWidget(self.override)
        # the twin only: every run started, scored (Skip: the twin scores itself) and saved with no one clicking
        self.auto_run = QCheckBox("Run by itself")
        self.auto_run.setToolTip("The twin (and Simple 20, twin or Dobot): each run starts when the table is READY "
                                 f"(on the Dobot after a {SIMPLE_COUNTDOWN_S} s countdown), is scored by the watcher "
                                 "with no verdict asked (Skip) and saved under the next free number, then the next run. "
                                 "Simple 20 saves every run, whatever happened, and skips (logged) a task whose table "
                                 f"isn't READY within {SIMPLE_READY_S:.0f} s; otherwise it pauses for you if a run can't "
                                 f"be scored, the table isn't ready in time, or Ollama / the PC fails {AUTO_INFRA_IN_ROW} "
                                 "runs in a row. E-STOP pauses it. Untick it to take over (and give verdicts) at any "
                                 "point. Each run is marked 'ran by itself'")
        self.auto_run.toggled.connect(self._auto_toggled)
        self.auto_run.setVisible(self._where() == "twin")     # (and for Simple 20 on the Dobot: _set_state)
        self._auto_infra = 0                      # infrastructure failures in a row while running by itself
        run_row.addWidget(self.auto_run)
        run_row.addStretch(1)
        run_row.addWidget(self.run_btn)
        left.addLayout(run_row)

        self.run_text = QPlainTextEdit()
        self.run_text.setReadOnly(True)
        # the run log, and the session's plan: every run, grouped by difficulty level, with its status
        self.left_tabs = QTabWidget()
        self.left_tabs.addTab(self.run_text, "Run log (the model's steps, moves, alarms)")
        plan_page = QWidget()
        plan_box = QVBoxLayout(plan_page)
        plan_box.setContentsMargins(4, 4, 4, 4)
        self.plan_summary = QLabel("")
        self.plan_summary.setWordWrap(True)
        self.plan_summary.setStyleSheet("padding: 2px 2px 4px 2px;")
        plan_box.addWidget(self.plan_summary)
        self.testgen_panel = self._build_testgen_panel()
        plan_box.addWidget(self.testgen_panel)
        from app.ui.flow_layout import FlowLayout
        # which tasks, how often, in what order, from what start (before Start session; tick the tasks in the list)
        picks_row = QWidget()
        picks = FlowLayout(picks_row)
        self.pick_all_btn = QPushButton("Tick all")
        self.pick_all_btn.clicked.connect(lambda: self._tick_all(True))
        self.pick_none_btn = QPushButton("Untick all")
        self.pick_none_btn.clicked.connect(lambda: self._tick_all(False))
        self.times_box = QSpinBox()
        self.times_box.setRange(1, 10)
        self.times_box.setPrefix("Times: ")
        self.times_box.setToolTip("How many runs each ticked task gets in this session")
        self.order_box = QComboBox()
        for key, words in ORDERS.items():
            self.order_box.addItem(words, key)
        self.order_box.setToolTip("In rounds: every ticked task once, then all again. Back to back: a task's runs one "
                                  "after another (TR-05, TR-05, then TR-06...)")
        self.start_box = QComboBox()
        for key, words in STARTS.items():
            self.start_box.addItem(words, key)
        self.start_box.setToolTip("Where the cubes start on a repeat. New: each repeat its own arrangement (does the "
                                  "pass hold?). Same: every repeat exactly as the first (did a fix work?). Also for "
                                  "'Run again' during a session")
        self.times_box.setMaximumWidth(120)
        for b in (self.pick_all_btn, self.pick_none_btn):     # (as narrow as their words: one line, not two)
            b.setStyleSheet(COMPACT_BUTTON)
        for w in (self.pick_all_btn, self.pick_none_btn, self.times_box, self.order_box, self.start_box):
            picks.addWidget(w)
        # Simple 20: each group a session of its own (its own folder, summary and report), or all 20 -- each started
        # from the cubes put down anywhere (the arm sets them out first), run by itself, every run saved; one task:
        # its own ▶ Run in the list
        self.simple_row = QWidget()
        simple = FlowLayout(self.simple_row)
        run_label = QLabel("<b>Run:</b>")
        simple.addWidget(run_label)
        self.simple_btns: list[QPushButton] = []
        for key, text in [(n, f"▶ Run Group {GROUP_LETTERS[n - 1]}") for n in range(1, 5)] + [(None, "▶ Run all 20")]:
            b = QPushButton(text)
            b.setStyleSheet(COMPACT_BUTTON)
            b.setToolTip("All 20 tasks, A to D, in one session" if key is None else
                         f"Group {GROUP_LETTERS[key - 1]}'s five tasks, in a session of their own")
            b.clicked.connect(lambda _=False, k=key: self._run_simple(level=k))
            simple.addWidget(b)
            self.simple_btns.append(b)
        self.simple_btns = self.simple_btns[-1:] + self.simple_btns[:-1]     # ([0]: all 20, [1..4]: groups A-D)
        self.simple_row.setToolTip("Put the three cubes anywhere on the grey sheet, then press one: the arm sets "
                                   "them out where that group starts, and the tasks run by themselves, each saved "
                                   "whatever happens. End the session to start another")
        self.simple_row.hide()
        for w in (self.times_box, self.order_box, self.start_box):
            signal = w.valueChanged if isinstance(w, QSpinBox) else w.currentIndexChanged
            signal.connect(lambda _=0: self._refresh_plan() if self.session is None and not self.plan else None)
        plan_box.addWidget(self.simple_row)
        plan_box.addWidget(picks_row)
        self._picks_row = picks_row
        # a test session's prompts: hidden unless you show them (so a screenshot of the window can't give the unseen
        # test away); off again every time the window is closed
        self.show_prompts = QCheckBox("Show test prompts")
        self.show_prompts.setToolTip("Shows the unseen test's prompts: in this list, the task line, the judge box "
                                     "(what to judge on the Dobot), where each cube ended and the run log's steps. "
                                     "Off, none of them shows. Only for you: don't share a screenshot of this window "
                                     "while it is on (it is off again when the window closes)")
        self.show_prompts.toggled.connect(lambda _=False: (self._refresh_plan(), self._refresh_secret_texts()))
        self.prompts_warning = QLabel("Test prompts visible: don't share screenshots of this window.")
        self.prompts_warning.setStyleSheet("color: #ff8a8a; font-weight: bold;")
        # (the test set made here too, not only from the Test tasks… button: the list fills when it is done)
        self.make_tests_here = QPushButton("Make test tasks…")
        self.make_tests_here.setToolTip("Make the unseen test set from your secret seed (20 tasks mirroring Simple "
                                        "20, checked in the twin). They appear in this list when done")
        self.make_tests_here.clicked.connect(lambda: self._make_test_tasks())
        prompts_row = QHBoxLayout()
        prompts_row.addWidget(self.make_tests_here)
        prompts_row.addWidget(self.show_prompts)
        prompts_row.addWidget(self.prompts_warning, 1)
        plan_box.addLayout(prompts_row)
        self._unticked: dict[str, set] = {}        # per set ("train" / "test"): the tasks left out of the next session
        self._preview_tasks: list[Task] = []       # the chosen set's tasks, to tick before Start session
        self._preview_error = ""
        chips_row = QWidget()
        chips = FlowLayout(chips_row)
        self.show_label = QLabel("Show:")              # (filters for the list below: they run nothing)
        chips.addWidget(self.show_label)
        self.level_group = QButtonGroup(self)
        self.level_group.setExclusive(True)
        self.level_chips: dict = {}
        for key, text in [("all", "All levels")] + list(LEVEL_CHIPS.items()) + [(0, "No level")]:
            chip = QPushButton(text)
            chip.setCheckable(True)
            chip.setChecked(key == "all")
            chip.setToolTip(f"Show only level {key}: {LEVEL_WORDS.get(key, 'no level given')} (the runs still go "
                            "in order, easy to hard)" if key != "all" else "Show every run")
            self.level_group.addButton(chip)
            chip.clicked.connect(lambda _=False: self._filter_plan())
            chip.setStyleSheet(COMPACT_BUTTON)
            chips.addWidget(chip)
            self.level_chips[key] = chip
        plan_box.addWidget(chips_row)
        self.plan_tree = QTreeWidget()
        self.plan_tree.setHeaderLabels(["Task", "Prompt", "Status"])
        from PyQt6.QtWidgets import QHeaderView
        head = self.plan_tree.header()
        head.setStretchLastSection(False)                 # (the prompt takes the room; the status always shows)
        head.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        head.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        head.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.plan_tree.setWordWrap(True)
        self.plan_tree.setTextElideMode(Qt.TextElideMode.ElideNone)
        self.plan_tree.setItemDelegateForColumn(1, WrapDelegate(self.plan_tree))     # (the whole prompt, wrapped)
        self._relayout = QTimer(self)                     # ...and the rows' heights again when the column is resized
        self._relayout.setSingleShot(True)
        self._relayout.setInterval(50)
        self._relayout.timeout.connect(self.plan_tree.doItemsLayout)
        head.sectionResized.connect(lambda column, _old, _new: column == 1 and self._relayout.start())
        self.plan_tree.setRootIsDecorated(True)
        self.plan_tree.itemChanged.connect(self._tick_changed)
        self.plan_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.plan_tree.customContextMenuRequested.connect(self._plan_menu)
        self.plan_tree.itemDoubleClicked.connect(self._load_task)
        self._loaded: Optional[str] = None          # the task double-clicked in the plan, to run now
        self.loaded_bar = self._build_loaded_bar()
        plan_box.addWidget(self.loaded_bar)
        plan_box.addWidget(self.plan_tree, 1)
        # the tab scrolls rather than squash its rows (a short screen): each row keeps its height, the list its room
        from PyQt6.QtWidgets import QFrame, QScrollArea
        self.plan_tree.setMinimumHeight(220)
        self._flow_rows = [picks_row, chips_row, self.simple_row]
        plan_page.installEventFilter(self)
        plan_scroll = QScrollArea()
        plan_scroll.setWidgetResizable(True)
        plan_scroll.setFrameShape(QFrame.Shape.NoFrame)
        plan_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        plan_scroll.setWidget(plan_page)
        self._plan_page, self._plan_scroll = plan_page, plan_scroll
        self.left_tabs.addTab(plan_scroll, "Session plan (by difficulty level)")
        left.addWidget(self.left_tabs, 1)
        self._plan_status: list[str] = []

        self.judge = QLabel("")
        self.judge.setWordWrap(True)
        self.judge.setStyleSheet("padding: 6px; background: rgba(255, 209, 102, 0.08); border-radius: 6px;")
        self.judge.setVisible(False)
        left.addWidget(self.judge)
        verdict = QHBoxLayout()
        verdict.addWidget(QLabel("Your verdict first:"))
        self.verdict_btns = {}
        for key, text in (("pass", "Pass"), ("fail", "Fail"), ("dropped", "Dropped"), ("helped", "I had to help"),
                          ("skipped", "Skip (the twin scores itself)")):
            b = QPushButton(text)
            b.clicked.connect(lambda _=False, k=key: self._verdict(k))
            verdict.addWidget(b)
            self.verdict_btns[key] = b
        self.verdict_btns["skipped"].setToolTip("The twin's runs are scored from the simulator's exact positions: "
                                                "your verdict is optional there")
        self.unsure = QCheckBox("Unsure")
        self.unsure.setToolTip("Tick if you couldn't tell for sure (helps the agreement check for the paper)")
        verdict.addWidget(self.unsure)
        self.note = QLineEdit()
        self.note.setPlaceholderText("Note (optional)")
        verdict.addWidget(self.note, 1)
        v.addLayout(verdict)
        self.reveal = QLabel("")
        self.reveal.setWordWrap(True)
        self.reveal.setStyleSheet("padding: 6px;")
        v.addWidget(self.reveal)
        nxt = QHBoxLayout()
        nxt.addStretch(1)
        self.discard_btn = QPushButton("Discard and run again")
        self.discard_btn.setToolTip("Throws this run away (whole, to Recycle_Bin in the results folder; a real one is "
                                    "noted, with a reason, in deletions_log.txt) and runs the same task again, from the "
                                    "same start")
        self.discard_btn.clicked.connect(self._discard_and_again)
        self.again_btn = QPushButton("Run this task again")
        self.again_btn.setToolTip("Adds another run of this task, straight after this one. This run stays: Save it "
                                  "(or Discard it) as usual. The start follows 'Same / New start' in the Session plan "
                                  "tab. Right-click a task in the plan to add one of any task")
        self.again_btn.clicked.connect(lambda: self._add_run(self.index, "next"))
        nxt.addWidget(self.again_btn)
        nxt.addWidget(self.discard_btn)
        self.next_btn = QPushButton("Save ▶ next")
        self.next_btn.setToolTip("Keeps this run and goes on to the next")
        self.next_btn.clicked.connect(self._save_and_next)
        nxt.addWidget(self.next_btn)
        # Simple 20: go on to the next task now, whatever this one is doing -- everything of it saved first
        self.proceed_btn = QPushButton("⏭ Proceed to next task")
        self.proceed_btn.setToolTip("Simple 20: ends this task now and goes on to the next. Running: the prompt is "
                                    "ended, the arm parks, the end is looked at and the run is scored and saved "
                                    "(\"ended by you\" if it didn't pass), refused steps and all. Not started yet: it "
                                    "is skipped, and that is logged. Finished: it is saved. No verdict is asked")
        self.proceed_btn.clicked.connect(self._proceed_next)
        self.proceed_btn.hide()
        nxt.addWidget(self.proceed_btn)
        v.addLayout(nxt)
        self._on_real_toggled(False)

    # ---- double-click a task: run it now ---------------------------------------------------------------------------
    def eventFilter(self, obj, event) -> bool:  # noqa: N802 (Qt)
        """The Session plan tab resized: each row of buttons that wraps reserves the height of all its lines."""
        from PyQt6.QtCore import QEvent
        if obj is getattr(self, "_plan_page", None) and event.type() in (QEvent.Type.Resize, QEvent.Type.Show,
                                                                         QEvent.Type.LayoutRequest):
            QTimer.singleShot(0, self._fit_flow_rows)
        return super().eventFilter(obj, event)

    def _fit_flow_rows(self) -> None:
        for row in getattr(self, "_flow_rows", []):
            needed = row.layout().heightForWidth(max(1, row.width()))
            if needed > 0 and row.minimumHeight() != needed:
                row.setMinimumHeight(needed)

    def _build_loaded_bar(self) -> QWidget:
        """The task double-clicked in the plan: its id and prompt, where it will run, and Run this task now."""
        from PyQt6.QtWidgets import QFrame
        bar = QFrame()
        bar.setObjectName("loaded")
        bar.setStyleSheet("#loaded { border: 1px solid #2a4459; border-radius: 8px; }")
        box = QVBoxLayout(bar)
        box.setContentsMargins(12, 8, 12, 8)
        top = QHBoxLayout()
        self.loaded_id = QLabel()
        self.loaded_prompt = QLabel()
        self.loaded_prompt.setWordWrap(True)
        clear = QPushButton("✕")
        clear.setToolTip("Clear (nothing runs)")
        clear.setFixedWidth(32)
        clear.clicked.connect(self._clear_loaded)
        top.addWidget(self.loaded_id)
        top.addWidget(self.loaded_prompt, 1)
        top.addWidget(clear)
        box.addLayout(top)
        bottom = QHBoxLayout()
        self.loaded_where = QLabel()
        self.loaded_where.setWordWrap(True)
        self.loaded_where.setStyleSheet("color: #8fa8ba;")
        self.run_now_btn = QPushButton("▶ Run this task now")
        self.run_now_btn.clicked.connect(self._run_loaded)
        bottom.addWidget(self.loaded_where, 1)
        bottom.addWidget(self.run_now_btn)
        box.addLayout(bottom)
        bar.hide()
        return bar

    def _load_task(self, item, _column: int = 0) -> None:
        """A task double-clicked in the plan (a task's line, not a level's): loaded in the bar above the list."""
        data = item.data(0, Qt.ItemDataRole.UserRole) if item is not None else None
        if isinstance(data, int) and 0 <= data < len(self.plan):          # (a run of a session's plan)
            task_id = self.plan[data][0].id
        elif isinstance(data, str):                                       # (a task to tick, before a session)
            task_id = data
        else:
            return
        self._loaded = task_id
        self._show_loaded()
        if hasattr(self, "_plan_scroll"):                  # (the bar and its Run button in view)
            QTimer.singleShot(0, lambda: self._plan_scroll.ensureWidgetVisible(self.loaded_bar, 0, 8))

    def _clear_loaded(self) -> None:
        self._loaded = None
        if hasattr(self, "loaded_bar"):
            self.loaded_bar.hide()

    def _loaded_prompt(self) -> str:
        """The loaded task's prompt (a test's hidden unless Show test prompts is on)."""
        if self._hide_prompts():
            return "(unseen test prompt: hidden)"
        tasks = (self.tasks.tasks if self.session is not None and self.tasks is not None else
                 [t for t, _ in self.plan] or self._preview_tasks)
        return next((t.prompt for t in tasks if t.id == self._loaded), "")

    def _show_loaded(self) -> None:
        """The bar as things stand: the task, its prompt, and what Run this task now will do."""
        if self._loaded is None or not hasattr(self, "loaded_bar"):
            return
        self.loaded_id.setText(f"<b>{self._loaded}</b>")
        self.loaded_prompt.setText(self._loaded_prompt())
        in_plan = self._loaded in {t.id for t, _ in self.plan}
        if self.session is not None and not in_plan:
            self.loaded_where.setText(f"{self._loaded} isn't in this session's plan, so it can't run in it. End the "
                                      "session, then Run this task now starts a session of just this task.")
        elif self.session is not None:
            self.loaded_where.setText("A session is running: it runs next, straight after the current run, then the "
                                      "session goes on. Scored and saved like any run.")
        else:
            self.loaded_where.setText(f"It starts a session of just this task ({self.session_box.currentText()}, "
                                      f"{'REAL' if self.real.isChecked() else 'practice'}). Scored and saved like "
                                      "any run.")
        self.run_now_btn.setEnabled(getattr(self, "_testgen", None) is None and (self.session is None or in_plan))
        self.loaded_bar.show()

    def _run_loaded(self) -> None:
        """Run this task now: no session -- a session of just this task, once; a session running -- the task's next
        run, straight after the current one (asked first in a real session, as Run again is)."""
        task_id = self._loaded
        if task_id is None:
            return
        if self.session is None:
            self._only = task_id
            try:
                self.start_session()
            finally:
                self._only = None                      # (a start that stopped early never leaves it set)
            if self.session is not None:
                self._clear_loaded()
            return
        index = next((i for i, (t, _) in enumerate(self.plan) if t.id == task_id), None)
        if index is not None and self._add_run(index, "next"):
            self._clear_loaded()

    def _build_testgen_panel(self) -> QWidget:
        """While the test tasks are being made: a bar that fills as each is ready, the one being checked (by id and
        level only), the time left, and Stop. Hidden otherwise."""
        from PyQt6.QtWidgets import QFrame, QProgressBar
        panel = QFrame()
        panel.setObjectName("testgen")
        panel.setStyleSheet("#testgen { border: 1px solid #2a4459; border-radius: 8px; }")
        box = QVBoxLayout(panel)
        box.setContentsMargins(12, 10, 12, 10)
        top = QHBoxLayout()
        title = QLabel("<b>Making the test tasks</b>")
        self.testgen_count = QLabel("0 of 20 ready")
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(self.testgen_count)
        box.addLayout(top)
        self.testgen_bar = QProgressBar()
        self.testgen_bar.setRange(0, 40)              # (two steps a task: its two starts in the twin)
        self.testgen_bar.setTextVisible(False)
        self.testgen_bar.setFixedHeight(12)
        box.addWidget(self.testgen_bar)
        row = QHBoxLayout()
        self.testgen_now = QLabel("Starting…")
        self.testgen_now.setStyleSheet("color: #8fa8ba;")
        self.testgen_left = QLabel("")
        self.testgen_left.setStyleSheet("color: #8fa8ba;")
        row.addWidget(self.testgen_now, 1)
        row.addWidget(self.testgen_left)
        box.addLayout(row)
        bottom = QHBoxLayout()
        hint = QLabel("Keep the app open. The 20 tasks appear in the list below when all are done.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #8fa8ba;")
        self.testgen_stop = QPushButton("Stop")
        self.testgen_stop.setToolTip("Stops making them. Nothing is written until all 20 are done, so the test set "
                                     "there now (if any) stays as it is")
        self.testgen_stop.clicked.connect(self._stop_testgen)
        bottom.addWidget(hint, 1)
        bottom.addWidget(self.testgen_stop)
        box.addLayout(bottom)
        panel.hide()
        self._testgen_clock = QTimer(self)               # (the time left, once a second)
        self._testgen_clock.timeout.connect(self._show_testgen_progress)
        return panel

    def _show_testgen_progress(self) -> None:
        """The panel as the maker stands: how many are ready, the bar, the one being checked, the time left."""
        ready, step = getattr(self, "_testgen_ready", 0), getattr(self, "_testgen_step", 0)
        self.testgen_count.setText(f"{ready} of 20 ready")
        self.testgen_bar.setValue(min(40, ready * 2 + step))
        started = getattr(self, "_testgen_started", None)
        if started is None:
            return
        elapsed = time.monotonic() - started
        if ready:
            left = elapsed / ready * (20 - ready)
            self.testgen_left.setText(f"about {max(1, round(left / 60))} min left" if left >= 60 else
                                      "less than a minute left")
        else:
            self.testgen_left.setText(f"{int(elapsed // 60)}:{int(elapsed % 60):02d} so far · estimating…")

    def _stop_testgen(self) -> None:
        process = getattr(self, "_testgen", None)
        if process is None:
            return
        self._testgen_stopped = True
        self.testgen_now.setText("Stopping…")
        process.kill()

    def _where(self) -> str:
        """Where this app's sessions run: the twin (Demo mode) or the real Dobot (Live mode)."""
        return "twin" if self.ctx.twin_world is not None or self.ctx.mode != "live" else "dobot"

    def _session_kind_chosen(self, _index: int = 0) -> None:
        kind = self.session_box.currentData()
        set_name = kind.split("_")[0] if kind else None
        if set_name and self.set_box.currentData() != set_name:
            self.set_box.setCurrentIndex(self.set_box.findData(set_name))

    def _set_chosen(self, _index: int = 0) -> None:
        wanted = f"{self.set_box.currentData()}_{self._where()}"
        if self.session_box.currentData() != wanted:
            self.session_box.setCurrentIndex(self.session_box.findData(wanted))

    def _on_real_toggled(self, on: bool) -> None:
        # (the twin is a study place too: its training and test sessions count, Demo mode being the twin)
        if on and QMessageBox.question(self, "Real test",
                                       "Results from now on count for the paper"
                                       + (" (the twin's half of the round)" if self._where() == "twin" else "")
                                       + ". Turn the real test on?") \
                != QMessageBox.StandardButton.Yes:
            self.real.blockSignals(True)
            self.real.setChecked(False)
            self.real.blockSignals(False)
            on = False
        if hasattr(self, "override"):
            self.override.setVisible(not on)
        self.real.setToolTip("Real: saved in study_N, counts for the paper." if on else
                             "Practice: saved in Practice_Session, safe to delete, not used in the paper. Turn "
                             "Practice session off when it counts.")

    def _set_state(self, state: str) -> None:
        """Which buttons work: idle, setup, running, verdict, reveal."""
        self.state = state
        in_session = self.session is not None
        for w in (self.real, self.session_box, self.set_box, self.round_box, self.cubes_box, self.start_btn,
                  self.pick_all_btn, self.pick_none_btn, self.times_box, self.order_box):
            w.setEnabled(not in_session)
        self.delete_btn.setEnabled(not in_session)
        self.rebuild_btn.setEnabled(not in_session)
        self.tests_btn.setEnabled(not in_session and self._testgen is None)
        if self._testgen is not None:                  # (nothing changes under the maker while it works)
            for w in (self.start_btn, self.pick_all_btn, self.pick_none_btn):
                w.setEnabled(False)
        self.paper_btn.setEnabled(not in_session and self.ctx.twin_world is None and self.ctx.calibration_file is not None)
        self.end_btn.setEnabled(in_session and state in ("setup", "reveal"))
        self.place_btn.setVisible(self.ctx.twin_world is not None)
        self.place_btn.setEnabled(state == "setup")
        self.override.setEnabled(state == "setup")
        self.override.setVisible(not self._is_real())   # real tests: every run passes the table check
        self.run_btn.setEnabled(False if state != "setup" else self.run_btn.isEnabled())
        for b in self.verdict_btns.values():
            b.setEnabled(state == "verdict")
        # (the twin scores itself exactly; Simple 20 runs by itself, scored by the watcher alone)
        self.verdict_btns["skipped"].setVisible(self._where() == "twin" or self._simple())
        self.auto_run.setVisible(self._where() == "twin" or self._simple())
        # Simple 20: the Run row always there (greyed while a session runs: end it to start another); the ticking,
        # times, order and start controls aren't Simple 20's
        self.simple_row.setVisible(self._simple())
        for b in self.simple_btns:
            b.setEnabled(not in_session and self._testgen is None)
            b.setToolTip(b.toolTip().split(" (")[0] + (" (end this session first)" if in_session else ""))
        self._picks_row.setVisible(not self._simple())
        self.proceed_btn.setVisible(in_session and self._simple())
        self.proceed_btn.setEnabled(in_session and state in ("setup", "running", "verdict", "reveal")
                                    and not getattr(self, "_push", False))
        self.note.setEnabled(state == "verdict")
        self.unsure.setEnabled(state == "verdict")
        self.next_btn.setEnabled(state == "reveal" and not self._broken)
        self.discard_btn.setEnabled(state == "reveal" and self.run_folder is not None)
        self.again_btn.setEnabled(state == "reveal")
        self.reveal.setVisible(bool(self.reveal.text()))   # (no empty line taking room before there is a score)
        if state in ("verdict", "reveal"):        # (Run by itself: the verdict, then Save and next)
            QTimer.singleShot(0, self._auto_step)
        self._activity_at = time.monotonic()
        self._refresh_status()

    # ---- the status strip (V4.3) -----------------------------------------------------------------------------------
    def _refresh_status(self) -> None:
        """The strip at the top and the window's title: what the watcher is doing now. Needing you, or the session
        over, flashes the taskbar; the session over also gives a short sound."""
        from watcher.status_strip import clock
        kind, head, sub, right, progress = self._status_now(clock)
        right = self._cube_words() + ("<br>" + right if right else "")
        self.status.show_status(kind, head, sub, right, progress)
        self.status.blink()
        short = {"ready": "", "setup": "setting up", "running": "running", "waiting": "your turn",
                 "done": "all done", "ended": "ended early"}[kind]
        place = f" {self.index + 1}/{len(self.plan)}" if self.session is not None and self.plan else ""
        self.setWindowTitle("Kyozo Watcher" + (f" · {short}{place}" if short else ""))
        if kind != self._status_kind:
            self._status_kind = kind
            quiet = bool(self._ended and self._ended.get("quiet"))
            if kind in ("waiting", "done", "ended") and not quiet and self.isVisible():
                QApplication.alert(self)
                if kind != "waiting":
                    QApplication.beep()

    def _cube_words(self) -> str:
        """The cube size the session goes by (Settings > Cubes), seen before a session starts -- and, if the app's camera
        found the cubes on the table measuring another size, that too (the app won't move them until it matches)."""
        words = f"Cubes: <b>{describe_cube(self._cube_size())}</b>"
        mismatch = getattr(self.ctx.executor, "cube_mismatch", None)
        if isinstance(mismatch, tuple) and len(mismatch) == 3:
            words += f"<br><b>The cubes measure about {mismatch[0]:.0f} mm</b>"
        return words

    def _arm_needs_person(self) -> Optional[str]:
        """Why the arm needs a person now (a held alarm, its homing lost, its USB link lost: DobotRobot.needs_person),
        or None. Until then nothing starts by itself."""
        why = getattr(self.ctx.robot, "needs_person", None)
        return why if isinstance(why, str) and why else None

    def _status_now(self, clock) -> tuple:
        """(kind, head, sub, right, progress 0-100 or None) for the strip -- see watcher/status_strip.py."""
        now = time.monotonic()
        if self.session is None:
            end = self._ended
            if end is None:
                return ("ready", "Ready", "No session running. Choose the session and the study, then press Start "
                        "session.", "", None)
            counts = f"{end['passed']} passed · {end['failed']} failed"
            took = f"took {clock(end['seconds'])}<br>ended {end['at']}"
            if end["all"]:
                return ("done", f"All {end['planned']} tasks done", f"{counts} · saved in {end['folder']}", took,
                        100.0)
            share = 100.0 * end["ran"] / end["planned"] if end["planned"] else None
            return ("ended", f"Ended early after {end['ran']} of {end['planned']}",
                    f"Why: {end['why']} · {end['saved']} run{'s' if end['saved'] != 1 else ''} saved in {end['folder']}", took, share)
        total = len(self.plan)
        if not 0 <= self.index < total:
            return "setup", "Starting the session", "", "", 0.0
        task = self.plan[self.index][0]
        where = f"task {self.index + 1} of {total} · {task.id}"
        progress = 100.0 * self.index / total
        this = now - getattr(self, "_task_shown", now)
        times = [f"this task {clock(this)}", f"session {clock(now - getattr(self, '_session_started', now))}"]
        if self.index >= 1:                        # (from the tasks done so far)
            each = (getattr(self, "_task_shown", now) - getattr(self, "_session_started", now)) / self.index
            times.append(f"about {max(1, round((each * (total - self.index) - this) / 60))} min left")
        right = "<br>".join(times)
        person = self._arm_needs_person()
        if person and self.state != "running":
            return ("waiting", f"Waiting for you · the arm needs a person · {where}",
                    f"{person} Then carry on: the session waits for you.", right, progress)
        auto = self._auto_on()
        if self.auto_run.isChecked():
            self._pause_why = ""
        paused = f"Run by itself paused: {self._pause_why}. " if self._pause_why else ""
        if self.state == "running":
            with self._lock:
                steps = len(self.steps)
                last = self.steps[-1].tool_name if self.steps else ""
            doing = (f"{steps} step{'s' if steps != 1 else ''} so far, the last {last}" if steps else
                     "the model is reading the task")
            return ("running", f"Running {where}", f"{doing} · last activity {int(now - self._activity_at)} s ago",
                    right, progress)
        if self.state == "setup":
            if auto:
                countdown = getattr(self, "_countdown", None)
                sub = (f"Starting in {countdown} s" if countdown is not None else
                       "Looking at the table…" if self._busy else "Getting the task ready")
                return "setup", f"Setting up {where}", sub, right, progress
            sub = ("The table is READY: press Start run" if self.run_btn.isEnabled() else
                   "Set the table out as shown; Start run lights up when it is READY")
            return "waiting", f"Waiting for you · {where}", paused + sub, right, progress
        if auto:                                   # (verdict, reveal: Run by itself scores and saves)
            return "setup", f"Scoring and saving {where}", "", right, progress
        if self.state == "verdict":
            sub = "Give your verdict: Pass, Fail, Dropped or I had to help"
        else:
            sub = "Save ▶ next, Discard and run again, or Run this task again"
        return "waiting", f"Waiting for you · {where}", paused + sub, right, progress

    def _short_folder(self, folder: Path) -> str:
        """The kind's folder from the results' root (study_2 / 20_Tasks_for_Dobot), or its own name."""
        try:
            return " / ".join(Path(folder).relative_to(self.ctx.results_root).parts)
        except (ValueError, TypeError):
            return Path(folder).name

    def _is_real(self) -> bool:
        return self.session.real if self.session is not None else self.real.isChecked()

    def _simple(self) -> bool:
        """Run as Simple 20 is -- the cubes put down once, each task from where the last left them, by itself, every
        run saved, by group: Simple 20 itself, and the unseen test built on it (a chained test set, Dr. Curry,
        2026-10-23). The session's set (or, before one, the chosen set)."""
        if self.session is not None:
            return self.session.info.get("set") == "simple" or bool(getattr(self.tasks, "chained", False))
        chosen = self.set_box.currentData() if getattr(self, "set_box", None) is not None else None
        return chosen == "simple" or (chosen == "test" and getattr(self, "_preview_chained", False))

    def _task_file(self, set_name: str) -> Path:
        if set_name == "simple":
            return SIMPLE_FILE
        return TRAIN_FILE if set_name == "train" else results.test_set_file(self.ctx.results_root)

    def _level_title(self, key) -> str:
        """A level's heading in the Session plan: "Level 2" -- Simple 20's are its groups, "Group B"."""
        if not key:
            return "No level"
        return f"Group {GROUP_LETTERS[key - 1]}" if self._simple() and 1 <= key <= 4 else f"Level {key}"

    def _level_words(self, key) -> str:
        words = getattr(self.tasks, "level_words", None) if self.session is not None else \
            getattr(self, "_preview_words", None)
        return (words or LEVEL_WORDS).get(key, "")

    def _run_simple(self, level: Optional[int] = None, task_id: Optional[str] = None) -> None:
        """Simple 20's buttons: a session of all 20 tasks, one group's, or one task's -- started now, by itself."""
        if self.session is not None or not self._simple():
            return
        ids = [t.id for t in self._preview_tasks
               if (level is None or t.level == level) and (task_id is None or t.id == task_id)]
        if not ids:
            return
        self._run_ids = ids
        try:
            self.start_session()
        finally:
            self._run_ids = None

    def _override_on(self) -> bool:
        """Starting without the table check: practice only."""
        return self.override.isChecked() and not self._is_real()

    def _log(self, text: str) -> None:
        self.run_text.appendPlainText(text)
        self._activity_at = time.monotonic()

    # ---- the session -----------------------------------------------------------------------------------------------
    def start_session(self) -> None:
        if getattr(self, "_testgen", None) is not None:
            QMessageBox.information(self, "Watcher", "The test tasks are being made: start the session when that "
                                    "has finished (or press Stop in the Session plan tab).")
            return
        set_name = self.set_box.currentData()
        round_no = self.round_box.currentData()
        real = self.real.isChecked()
        where = self._where()
        if self._busy:                             # (Find the paper, say: its result would land in the session)
            QMessageBox.information(self, "Watcher", "A moment: the camera is busy. Start the session again when it "
                                    "has finished.")
            return
        held = self.ctx.held()
        if held:
            QMessageBox.information(self, "Watcher", f"Not started: {held}.")
            return
        try:
            self.tasks = load_task_set(self._task_file(set_name), self.cubes_box.currentData(), self._cube_size())
        except FileNotFoundError as exc:
            QMessageBox.warning(self, "Watcher", str(exc))
            return
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Watcher", f"Couldn't read the task file:\n{exc}")
            return
        paper_words = ""
        if self.tasks.sheet is not None:
            pose, paper_words = paper_pose_for(self.ctx)
            self.tasks = self.tasks.on_paper(pose)
        only, self._only = getattr(self, "_only", None), None     # (Run this task now: that task, once)
        if only is not None and only not in [t.id for t in self.tasks.tasks]:
            QMessageBox.warning(self, "Watcher", f"{only} isn't in this session's task set.")
            return
        run_ids = getattr(self, "_run_ids", None)       # (Simple 20's Run all / Group / ▶: these tasks, once each)
        picked = [only] if only is not None else list(run_ids) if run_ids else self._picked(self.tasks, set_name)
        if picked is not None and len(picked) == len(self.tasks.tasks):
            picked = None
        once = only is not None or bool(run_ids) or self.tasks.chained   # (a chain: each task once, in order)
        choice = {"tasks": picked or [t.id for t in self.tasks.tasks],
                  "left_out": [t.id for t in self.tasks.tasks if picked is not None and t.id not in picked],
                  "times_each": 1 if once else self.times_box.value(),
                  "order": "rounds" if once else self.order_box.currentData(),
                  "start": "new" if once else self.start_box.currentData(),
                  **({"run_now": only} if only is not None else {})}
        choice["as_planned"] = (not choice["left_out"] and choice["times_each"] == default_times(set_name, where)
                                and choice["order"] == "rounds" and choice["start"] == "new")
        try:
            plan = plan_runs(self.tasks, set_name, where, picked, choice["times_each"], choice["order"],
                             choice["start"])
        except ValueError as exc:                 # (a task no arrangement suits: say which and why)
            QMessageBox.warning(self, "Watcher", str(exc))
            return
        if not plan:
            QMessageBox.warning(self, "Watcher", "This session would have no runs: tick at least one task in the "
                                "Session plan tab." if self.tasks.tasks else
                                "This session would have no runs (the task file has no tasks).")
            return
        if real:                                  # a task already saved in this study: said, never stopped
            kind = results.kind_folder(True, set_name, where, round_no, self.ctx.results_root)
            already = []
            for task_id in dict.fromkeys(t.id for t, _ in plan):
                saved = results.saved_runs(kind, task_id)
                if saved:
                    already.append(f"{task_id}: " + ", ".join(f"{r['tag']} ({results.result_word(r)})"
                                                              for r in saved))
            if already and QMessageBox.question(
                    self, "Already run", f"These tasks already have saved REAL runs in {kind.parent.name}\\"
                    f"{kind.name}:\n\n" + "\n".join(already[:20]) + (f"\n... and {len(already) - 20} more"
                                                                     if len(already) > 20 else "")
                    + "\n\nRun them again anyway? (Each new run is saved as a run of its own.)") \
                    != QMessageBox.StandardButton.Yes:
                return
        try:
            table_z = self.ctx.executor.table_z_provider() if self.ctx.executor.table_z_provider else 0.0
        except Exception:  # noqa: BLE001
            table_z = None
        if table_z is None and where == "dobot":   # (the spots would be saved at z = 0 and the finder look there)
            QMessageBox.warning(self, "Watcher", "The table's height isn't known: calibrate the camera (or touch the "
                                "table on the Calibration tab) first.")
            return                                 # (before the plan is set: the tick boxes still work)
        self.plan = plan
        self._plan_status = ["Waiting"] * len(self.plan)
        cfg = self.ctx.config.get("llm", {})
        model = getattr(self.ctx.agent, "model", cfg.get("model"))
        self._zone_backup = observe.zone_files_before(self.tasks, self.ctx.poses_dir)
        zones = observe.save_zone_places(self.tasks, self.ctx.poses_dir, z=float(table_z or 0.0))
        info = {"session_kind": self.session_box.currentText(), "cube_set": self.cubes_box.currentData(),
                "cube_size_mm": self.tasks.cube_size_mm,
                "scoring": ("the twin's exact positions" if where == "twin" else "the watcher's camera look"),
                "app_mode": self.ctx.mode, "model": model,
                "model_digest": observe.model_digest(cfg.get("endpoint", "http://localhost:11434"), model),
                "temperature": cfg.get("temperature"), "seed": cfg.get("seed"),
                "task_file_sha256": self.tasks.sha256, "git_commit": observe.git_commit(),
                "calibration_file": str(self.ctx.calibration_file or ""),
                "calibration_sha256": observe.file_sha256(self.ctx.calibration_file),
                "table_z_mm": table_z, "zones": zones, "planned_runs": len(self.plan), "plan_choice": choice,
                "chained": self.tasks.chained, "time_limit_s": self._time_limit(),
                "paper": (self.tasks.paper.__dict__ if self.tasks.paper is not None else None),
                "model_processor": observe.model_processor(cfg.get("endpoint", "http://localhost:11434"), model),
                "robot_at_start": observe.robot_state(self.ctx.robot),
                "camera_at_start": observe.camera_state(self.ctx.camera),
                "settings": observe.settings_snapshot(self.ctx.config, self.ctx.robot),
                **observe.conditions(self.ctx.camera, self.ctx.scene_builder, self.ctx.calibration_file)}
        self._table_z = float(table_z or 0.0)
        self.session = results.Session.start(real, set_name, where, round_no, VERSIONS[round_no], info,
                                             root=self.ctx.results_root)
        if set_name == "test":                    # (test details stay out of the project's own log)
            self._divert = _LogDiversion(self.session.folder / "app_log.txt").__enter__()
        self.ctx.robot.add_watcher(self._on_robot_event)
        self.ctx.on_session_active(True)
        self._study_cube_sizes(True)
        # (the twin's camera is set to perfect just now: the record says so)
        self.session.info["camera_at_start"] = observe.camera_state(self.ctx.camera)
        results.write_json(self.session.folder / "session.json", self.session.info)
        self._token += 1
        self._runs_since_home = 0
        self._session_started, self._ended, self._pause_why = time.monotonic(), None, ""
        self.index = -1
        self._infra_tries: dict = {}
        self._auto_infra = 0
        self._log(f"Session: {self.session_box.currentText()}, {ROUND_NAMES[round_no]}, "
                  f"{'REAL' if real else 'practice'}: saving in {self.session.kind_folder}")
        self._log("Runs: " + _choice_words(choice))
        if paper_words:
            self._log(f"Paper: {paper_words}")
        try:                                       # (runs an earlier sitting started and never finished: kept, logged)
            crashed = self.session.recover_crashed()
        except Exception as exc:  # noqa: BLE001 - never in the way of the session
            crashed = []
            logger.warning("Couldn't look for unfinished runs: %s", exc)
        if crashed:
            self._log(f"Found {len(crashed)} run(s) an earlier sitting never finished (the app closed or crashed): "
                      "kept in _raw_data as …__crashed, and noted in this session's index.")
        self._set_out_done = True                  # (V4.2: no set-out -- every task starts from the table as it is)
        self._known: dict = {}                     # each cube where it was last seen (the towers' hidden cubes)
        self._empty_in_row, self._empty_ids, self._end_reason = 0, [], None
        if self.tasks.chained:
            self._log("Simple 20: the cubes stay where each task leaves them, nothing is sorted; before each task the "
                      "watcher looks at the table as it is; each task "
                      + (f"has {self._time_limit() / 60:.0f} minutes; " if self._time_limit() else "")
                      + "every run is saved, whatever happens. Untick Run by itself to take over.")
            self.auto_run.setChecked(True)
        self._next()

    def _show_ghosts(self, placed: list[bool]) -> None:
        """The outlines of the current task's layout and the zones over the camera picture (green: in place)."""
        task = self.plan[self.index][0]
        try:
            from watcher.ghost import ghost_marks
            marks = ghost_marks(task.start, placed, self.tasks.zones, self.ctx.scene_builder.t_cam_to_robot,
                                self.ctx.camera.get_intrinsics(), getattr(self, "_table_z", 0.0),
                                self.tasks.cube_size_mm)
        except Exception:  # noqa: BLE001 - no calibration yet: the text check still works
            logger.debug("No ghost outlines", exc_info=True)
            marks = []
        self.video.set_marks(marks)
        from watcher.ghost import ghost_outlines_3d
        self._outlines_3d = ghost_outlines_3d(task.start, placed, self.tasks.zones, getattr(self, "_table_z", 0.0),
                                              self.tasks.cube_size_mm, paper=self.tasks.paper)

    def end_session(self, why: str = "") -> None:
        if self.session is None:
            return
        if self.state in ("running", "verdict"):
            self._log("Can't end the session now: finish this run (and give your verdict) first.")
            return
        if self.state == "reveal" and not self._broken:
            self._keep_run(ask=False)              # (ended with a run shown and not discarded: kept, next tag)
        self._token += 1
        self.video.set_marks([])
        self._outlines_3d = []
        self._timer.stop()
        try:
            self.ctx.robot.remove_watcher(self._on_robot_event)
        except Exception:  # noqa: BLE001
            pass
        finished, folder = self.session, self.session.folder
        saved_runs = 0
        try:
            done = saved_runs = len(self._saved_this_sitting())
            finished.record({"session_end": why, "runs_done": done})
            finished.info["ended_why"] = why       # (session.json says why it ended too)
            self._remake_overview(finished.real, finished.root)
            folder = finished.finish(self._summary())
            if not results.verify_index(folder):
                logger.error("The session's index doesn't check out: %s", folder)
                self._log("WARNING: the session's index (index.jsonl) doesn't check out.")
        except Exception:  # noqa: BLE001 - the session is still closed and the log unmuted
            logger.exception("Finishing the session failed")
        finally:
            if self._divert is not None:
                self._divert.__exit__(None, None, None)
                self._divert = None
            observe.restore_zone_files(getattr(self, "_zone_backup", {}))
            self._zone_backup = {}
            self.session = None
        self._study_cube_sizes(False)
        self.ctx.on_session_active(False)
        note = ""
        if finished.info.get("set") in ("train", "simple"):   # the package for the next improvement, made at once
            try:
                package = self._build_claude_input(finished.info["round"], finished.real)
                note = f"\nClaude's input: {package} (and the .zip next to it)"
            except Exception as exc:  # noqa: BLE001
                note = f"\nClaude's input couldn't be made: {exc}"
        self.task_label.setText(f"Session ended ({why}). Saved in {finished.kind_folder}{note}")
        # nothing of the last run stays on screen (a test task's prompt and pass rule above all)
        self.judge.setText("")
        self.judge.setVisible(False)
        self.reveal.setText("")
        self._plan_status = ["Not run" if st == "Now" else st for st in self._plan_status]
        ran = [st for st in self._plan_status if st.startswith(RAN_WORDS) and "infrastructure" not in st]
        self._ended = {"all": why == "all runs done", "why": why, "planned": len(self.plan), "ran": len(ran),
                       "passed": sum(st.startswith("Pass") for st in ran),
                       "failed": sum(not st.startswith("Pass") for st in ran), "saved": saved_runs,
                       "folder": self._short_folder(finished.kind_folder),
                       "seconds": time.monotonic() - getattr(self, "_session_started", time.monotonic()),
                       "at": time.strftime("%H:%M"), "quiet": why == "window closed"}
        self._set_state("idle")
        # the finished session's plan stays, with its results, until another session or study is chosen
        self._refresh_plan()
        done = [st for st in self._plan_status if st.startswith(RAN_WORDS) and "infrastructure" not in st]
        self.plan_summary.setText(f"Finished: <b>{self.session_box.currentText()}</b> · "
                                  f"{ROUND_NAMES.get(self.round_box.currentData(), '')} · {len(done)} runs · passed "
                                  f"{sum(st.startswith('Pass') for st in done)}, failed "
                                  f"{sum(not st.startswith('Pass') for st in done)} ({why}). Choose a session to see its plan.")

    def _set_plan_status(self, index: int, status: str) -> None:
        while len(self._plan_status) < len(self.plan):
            self._plan_status.append("Waiting")
        if 0 <= index < len(self._plan_status):
            self._plan_status[index] = status
        self._refresh_plan()

    def _refresh_plan(self) -> None:
        """The Session plan tab: every run of the session in order, grouped by difficulty level (a task without one:
        "No level"), each with its status -- waiting, now, pass or fail (and the tag it was saved under), discarded. In a
        TEST session the prompts are hidden (ids and levels only), so a screenshot never shows an unseen task."""
        tree = getattr(self, "plan_tree", None)
        if tree is None:
            return
        test = (self.session.info.get("set") if self.session is not None else self.set_box.currentData()) == "test"
        self.show_prompts.setVisible(test)
        self._show_loaded()                                # (the loaded task's bar: a session started or ended)
        self.make_tests_here.setVisible(test and self.session is None)
        self.make_tests_here.setEnabled(getattr(self, "_testgen", None) is None)
        making = getattr(self, "_testgen", None) is not None
        self.make_tests_here.setText(f"Making… {getattr(self, '_testgen_ready', 0)} of 20 ready" if making else
                                     "Make test tasks…" if getattr(self, "_preview_error", "") else
                                     "Make new test tasks…")
        # (the warning only when prompts are really on screen: none while there is no test set)
        self.prompts_warning.setVisible(test and self.show_prompts.isChecked()
                                        and bool(self.plan or getattr(self, "_preview_tasks", None)))
        if self.session is None and not self.plan:
            self._refresh_picker()
            return
        tree.blockSignals(True)
        tree.clear()
        self._run_column(self._simple())                   # (Simple 20: each run's own ▶ Now)
        tree.blockSignals(False)
        hide = self._hide_prompts()
        groups: dict = {}
        counts: dict = {}
        for i, (task, repeat) in enumerate(self.plan):
            key = task.level if task.level is not None else 0
            status = self._plan_status[i] if i < len(self._plan_status) else "Waiting"
            if key not in groups:
                groups[key] = QTreeWidgetItem([self._level_title(key), self._level_words(key), ""])
                groups[key].setData(0, Qt.ItemDataRole.UserRole + 1, key)
                font = groups[key].font(0)
                font.setBold(True)
                for col in (0, 1, 2):
                    groups[key].setFont(col, font)
            done, passed = counts.get(key, (0, 0))
            if status.startswith(("Pass", "Fail")) and "infrastructure" not in status:
                done, passed = done + 1, passed + status.startswith("Pass")
            counts[key] = (done, passed)
            prompt = "(unseen test prompt: hidden)" if hide else task.prompt
            row = QTreeWidgetItem([task.id + (f" · repeat {repeat}" if repeat > 1 else ""), prompt, status])
            row.setData(0, Qt.ItemDataRole.UserRole, i)          # (its place in the plan: right-click, Run again)
            row.setToolTip(1, prompt)
            colour = next((c for word, c in STATUS_COLOURS.items() if status.startswith(word)), None)
            if colour:
                from PyQt6.QtGui import QBrush, QColor
                row.setForeground(2, QBrush(QColor(colour)))
            if status == "Now":
                font = row.font(1)
                font.setBold(True)
                for col in (0, 1, 2):
                    row.setFont(col, font)
            groups[key].addChild(row)
        done_all = sum(d for d, _ in counts.values())
        passed_all = sum(p for _, p in counts.values())
        study = ROUND_NAMES.get(self.round_box.currentData(), "")
        if self.session is not None:
            now = next((i for i, st in enumerate(self._plan_status) if st == "Now"), None)
            self.plan_summary.setText(
                f"Session: <b>{self.session_box.currentText()}</b> · {study} · "
                + (f"Run {now + 1} of {len(self.plan)}" if now is not None else f"{len(self.plan)} runs")
                + f" · passed {passed_all}, failed {done_all - passed_all}"
                + (" · REAL" if self.session.real else " · practice"))
        else:                                     # (a finished session's plan, kept to look at: end_session says more)
            self.plan_summary.setText(f"<b>{self.session_box.currentText()}</b> · {study} · {len(self.plan)} runs")
        for key in sorted(groups, key=lambda k: (k == 0, k)):
            done, passed = counts.get(key, (0, 0))
            groups[key].setText(2, f"{passed} of {done} passed" if done else "")
            tree.addTopLevelItem(groups[key])
            groups[key].setExpanded(True)
        self._show_chips(groups)
        self._keep_filter_visible()
        self._filter_plan()
        if self._simple() and self.session is not None:   # each run still to come: ▶ Now
            for key in groups:
                for j in range(groups[key].childCount()):
                    row = groups[key].child(j)
                    i = row.data(0, Qt.ItemDataRole.UserRole)
                    status = row.text(2)
                    if not isinstance(i, int) or status == "Now" or not status.startswith("Waiting"):
                        continue
                    now = QPushButton("▶ Now")
                    now.setStyleSheet(COMPACT_BUTTON)
                    now.setToolTip("Runs this prompt now: if the current task hasn't started yet, this one takes its "
                                   "place (the current one runs straight after); if a task is running, straight "
                                   "after it. Saved like every run")
                    now.clicked.connect(lambda _=False, n=i: self._run_now(n))
                    tree.setItemWidget(row, 3, now)
        current = next((groups[k].child(j) for k in groups for j in range(groups[k].childCount())
                        if groups[k].child(j).text(2) == "Now"), None)
        if current is not None:
            tree.scrollToItem(current)

    def _run_column(self, on: bool) -> None:
        """Simple 20: a fourth column in the task list for each prompt's own run button (▶ Run before a session,
        ▶ Now during one); the other sets: three columns."""
        tree = self.plan_tree
        tree.setColumnCount(4 if on else 3)
        tree.setHeaderLabels(["Task", "Prompt", "Status"] + (["Run"] if on else []))
        if on:
            from PyQt6.QtWidgets import QHeaderView
            tree.header().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)

    def _run_now(self, index: int) -> None:
        """▶ Now on a run still waiting (Simple 20): it runs now -- in place of the current task if that hasn't
        started (which then runs straight after it), else straight after the running one. Noted in the index."""
        if self.session is None or not 0 <= index < len(self.plan) or index == self.index:
            return
        task, repeat = self.plan[index]
        if self.state == "setup":                  # (the current one hasn't started: this one goes first)
            del self.plan[index]
            status = self._plan_status.pop(index) if index < len(self._plan_status) else "Waiting"
            at = self.index if index > self.index else self.index - 1
            self.plan.insert(at, (task, repeat))
            self._plan_status.insert(at, status)
            if at + 1 < len(self._plan_status):
                self._plan_status[at + 1] = "Waiting"   # (the one it went in front of: not "Now" any more)
            self.session.record({"run_now": task.id, "instead_of": self.plan[at + 1][0].id})
            self._log(f"{task.id} runs now; {self.plan[at + 1][0].id} straight after it.")
            self._countdown = None
            self.index = at - 1
            self._next()
            return
        self.session.record({"run_now": task.id, "after": self.plan[self.index][0].id})
        if index > self.index + 1:                 # (straight after the running one)
            del self.plan[index]
            status = self._plan_status.pop(index) if index < len(self._plan_status) else "Waiting"
            self.plan.insert(self.index + 1, (task, repeat))
            self._plan_status.insert(self.index + 1, status)
        self._log(f"{task.id} runs straight after {self.plan[self.index][0].id}.")
        self._refresh_plan()

    def _preview_plan(self) -> None:
        """No session running: the chosen set's tasks, to tick before Start session -- each with how often it will run
        and the runs already saved for it. The unseen test's tasks show by id and level only (the prompts hidden)."""
        if self.session is not None or not hasattr(self, "plan_tree"):
            return
        self._clear_loaded()                               # (another set or session kind: not that task)
        set_name = self.set_box.currentData()
        kind = f"{set_name}_{self._where()}"
        if getattr(self, "_preview_kind", None) != kind:      # another kind of session: its planned runs per task
            self._preview_kind = kind
            self.times_box.blockSignals(True)
            self.times_box.setValue(default_times(set_name, self._where()))
            self.times_box.blockSignals(False)
        self.plan, self._plan_status = [], []
        self._preview_tasks, self._preview_error, self._preview_words, self._preview_chained = [], "", {}, False
        try:
            preview = load_task_set(self._task_file(set_name), self.cubes_box.currentData(), self._cube_size())
            self._preview_tasks, self._preview_words = list(preview.tasks), dict(preview.level_words)
            self._preview_chained = preview.chained
        except FileNotFoundError as exc:
            self._preview_error = str(exc)
        except Exception as exc:  # noqa: BLE001 - said again, in full, at Start session
            # (the test file's own words never go in the log: only what kind of trouble it was)
            self._preview_error = f"Couldn't read the task file ({type(exc).__name__}): press Start session to see why."
        self._refresh_plan()
        self.left_tabs.setCurrentIndex(1)
        if hasattr(self, "state"):                         # (Simple 20's Run buttons: shown for its set only)
            self._set_state(self.state)

    def _refresh_picker(self) -> None:
        """Before Start session: the chosen set's tasks by difficulty level, each with a tick box (a level's box ticks
        all of it), how often it will run and the runs already saved for it (in the folder the session would save to)."""
        tree, set_name = self.plan_tree, self.set_box.currentData()
        unticked = self._unticked.setdefault(set_name, set())
        try:
            kind = results.kind_folder(self.real.isChecked(), set_name, self._where(), self.round_box.currentData(),
                                       self.ctx.results_root)
        except ValueError:
            kind = None
        tree.blockSignals(True)
        tree.clear()
        groups: dict = {}
        if getattr(self, "_testgen", None) is not None and set_name == "test":    # (being made: not the old ones)
            tree.addTopLevelItem(QTreeWidgetItem(["", "The test tasks will be listed here when they're ready.", ""]))
            tree.blockSignals(False)
            self._show_ticks()
            return
        simple = self._simple()
        self._run_column(simple)                           # (Simple 20: each task's own ▶ Run, in a fourth column)
        for task in self._preview_tasks:
            key = task.level if task.level is not None else 0
            if key not in groups:
                group = QTreeWidgetItem([self._level_title(key), self._level_words(key), ""])
                group.setData(0, Qt.ItemDataRole.UserRole + 1, key)
                font = group.font(0)
                font.setBold(True)
                for col in (0, 1, 2):
                    group.setFont(col, font)
                group.setFlags(group.flags() | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsAutoTristate)
                groups[key] = group
            row = QTreeWidgetItem([task.id, "(unseen test prompt: hidden)" if self._hide_prompts() else task.prompt,
                                   ""])
            row.setData(0, Qt.ItemDataRole.UserRole, task.id)
            row.setData(2, Qt.ItemDataRole.UserRole, [r["tag"] for r in results.saved_runs(kind, task.id)]
                        if kind is not None else [])
            row.setToolTip(1, row.text(1))
            row.setFlags(row.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            row.setCheckState(0, Qt.CheckState.Unchecked if task.id in unticked else Qt.CheckState.Checked)
            groups[key].addChild(row)
        for key in sorted(groups, key=lambda k: (k == 0, k)):
            tree.addTopLevelItem(groups[key])
            groups[key].setExpanded(True)
        if simple:
            for row in self._picker_rows():
                run = QPushButton("▶ Run")
                run.setStyleSheet(COMPACT_BUTTON)
                run.setToolTip("Runs this task alone, now, by itself (saved whatever happens). The table must be as "
                               "the task starts: the camera says what to change")
                run.clicked.connect(lambda _=False, t=row.data(0, Qt.ItemDataRole.UserRole): self._run_simple(task_id=t))
                tree.setItemWidget(row, 3, run)
        tree.blockSignals(False)
        self._show_ticks()
        self._show_chips(groups)
        self._keep_filter_visible()
        self._filter_plan()

    def _show_chips(self, groups: dict) -> None:
        """Only the levels (Simple 20: groups) there are, each chip named as its heading."""
        for key, chip in self.level_chips.items():
            chip.setVisible(key == "all" or key in groups)
            if key not in ("all", 0):
                chip.setText(self._level_title(key))
                chip.setToolTip(f"Show only {self._level_title(key).lower()}: {self._level_words(key)} (the runs "
                                "still go in order, easy to hard)")

    def _picker_rows(self) -> list:
        tree = self.plan_tree
        return [tree.topLevelItem(i).child(j) for i in range(tree.topLevelItemCount())
                for j in range(tree.topLevelItem(i).childCount())]

    def _show_ticks(self) -> None:
        """Each task's line (how often it runs, what is saved), each level's tick box, and the summary, as ticked."""
        set_name = self.set_box.currentData()
        unticked = self._unticked.setdefault(set_name, set())
        times = self.times_box.value()
        tree = self.plan_tree
        tree.blockSignals(True)
        for row in self._picker_rows():
            saved = row.data(2, Qt.ItemDataRole.UserRole) or []
            row.setText(2, ("not ticked" if row.data(0, Qt.ItemDataRole.UserRole) in unticked else f"× {times}")
                        + (f" · saved: {', '.join(saved)}" if saved else ""))
        for i in range(tree.topLevelItemCount()):
            group = tree.topLevelItem(i)
            if not group.childCount():                 # (a line of words, not a level: no tick box)
                continue
            states = {group.child(j).checkState(0) for j in range(group.childCount())}
            group.setData(0, Qt.ItemDataRole.CheckStateRole,
                          (states.pop() if len(states) == 1 else Qt.CheckState.PartiallyChecked).value)
        tree.blockSignals(False)
        study = ROUND_NAMES.get(self.round_box.currentData(), "")
        if getattr(self, "_testgen", None) is not None and set_name == "test":
            self.plan_summary.setText(f"<b>{self.session_box.currentText()}</b> · {study}")
            return
        if self._preview_error:
            self.plan_summary.setText(f"<b>{self.session_box.currentText()}</b> · {study}: {self._preview_error}")
            return
        ticked = [t for t in self._preview_tasks if t.id not in unticked]
        planned = (not unticked and times == default_times(set_name, self._where())
                   and self.order_box.currentData() == "rounds" and self.start_box.currentData() == "new")
        self.plan_summary.setText(
            f"Next session: <b>{self.session_box.currentText()}</b> · {study} · {len(ticked)} of "
            f"{len(self._preview_tasks)} tasks ticked × {times} = <b>{len(ticked) * times} runs</b>"
            + (", as planned" if planned else f" · {self.order_box.currentText().lower()} · "
               f"{self.start_box.currentText().lower()}")
            + (" · REAL" if self.real.isChecked() else " · practice")
            + ". Tick the tasks to run, then Start session.")

    def _tick_changed(self, item, column: int) -> None:
        """A tick box clicked (a task, or a whole level): the tasks left out of the next session."""
        if self.session is not None or self.plan or column != 0:
            return
        unticked = self._unticked.setdefault(self.set_box.currentData(), set())
        for row in self._picker_rows():
            task_id = row.data(0, Qt.ItemDataRole.UserRole)
            if row.checkState(0) == Qt.CheckState.Checked:
                unticked.discard(task_id)
            else:
                unticked.add(task_id)
        self._show_ticks()

    def _tick_all(self, on: bool) -> None:
        set_name = self.set_box.currentData()
        self._unticked[set_name] = set() if on else {t.id for t in self._preview_tasks}
        if self.session is None and not self.plan:
            self._refresh_plan()
        else:                                      # (a finished session's plan shown: back to ticking)
            self._preview_plan()

    def _picked(self, tasks: TaskSet, set_name: str) -> Optional[list[str]]:
        """The ticked tasks of the set (None: all of them)."""
        unticked = self._unticked.get(set_name, set())
        picked = [t.id for t in tasks.tasks if t.id not in unticked]
        return None if len(picked) == len(tasks.tasks) else picked

    def _plan_menu(self, pos) -> None:
        """Right-click a run in a session's plan: another run of its task, next or at the end."""
        if self.session is None:
            return
        item = self.plan_tree.itemAt(pos)
        index = item.data(0, Qt.ItemDataRole.UserRole) if item is not None else None
        if not isinstance(index, int) or not 0 <= index < len(self.plan):
            return
        task_id = self.plan[index][0].id
        menu = QMenu(self)
        nxt = menu.addAction(f"Run {task_id} again next")
        last = menu.addAction(f"Run {task_id} again at the end")
        chosen = menu.exec(self.plan_tree.viewport().mapToGlobal(pos))
        if chosen is nxt:
            self._add_run(index, "next")
        elif chosen is last:
            self._add_run(index, "end")

    def _confirm_extra(self, task_id: str) -> bool:
        """A real session: another run of a task, asked first (what is already saved for it, said)."""
        if not self.session.real:
            return True
        saved = self.session.saved_runs(task_id)
        already = ", ".join(f"{r['tag']} ({results.result_word(r)})" for r in saved)
        return QMessageBox.question(
            self, "Run again", f"Add another run of {task_id} to this REAL session?"
            + (f"\n\nAlready saved for it here: {already}." if saved else "")
            + "\n\nIt is saved as a run of its own: you choose its number when you save it.") \
            == QMessageBox.StandardButton.Yes

    def _add_run(self, index: int, where: str = "next") -> bool:
        """Another run of the task at plan[index]: straight after the current run ("next") or at the end. Its start:
        the same as that run's, or a new arrangement (its own repeat number), as 'Same / New start' says."""
        if self.session is None or not 0 <= index < len(self.plan):
            return False
        task, _ = self.plan[index]
        repeat = max(r for t, r in self.plan if t.id == task.id) + 1
        start = self.start_box.currentData()
        if start != "same":
            try:
                task = arranged(self.tasks.task(task.id), self.tasks, self.session.info.get("set", "train"), repeat)
            except Exception as exc:  # noqa: BLE001
                self._log(f"Couldn't add another run of {task.id}: {exc}")
                return False
        if not self._confirm_extra(task.id):
            return False
        at = len(self.plan) if where == "end" else min(self.index + 1, len(self.plan))
        while len(self._plan_status) < len(self.plan):
            self._plan_status.append("Waiting")
        self.plan.insert(at, (task, repeat))
        self._plan_status.insert(at, "Waiting (added)")
        self.session.record({"added_run": task.id, "repeat": repeat, "where": where, "start": start,
                             "arrangement": task.arrangement})
        self._log(f"Added: another run of {task.id} (repeat {repeat}, {STARTS[start].lower()}), "
                  + ("next." if where == "next" else "at the end."))
        self._refresh_plan()
        return True

    def _keep_filter_visible(self) -> None:
        """A level chosen whose chip is now hidden (no runs of that level): back to All levels, never a blank plan."""
        chosen = next((key for key, chip in self.level_chips.items() if chip.isChecked()), "all")
        if chosen != "all" and self.level_chips[chosen].isHidden():
            self.level_chips["all"].setChecked(True)

    def _filter_plan(self) -> None:
        chosen = next((key for key, chip in self.level_chips.items() if chip.isChecked()), "all")
        for i in range(self.plan_tree.topLevelItemCount()):
            item = self.plan_tree.topLevelItem(i)
            key = item.data(0, Qt.ItemDataRole.UserRole + 1)
            if key is None:
                continue                               # (a line of words, not a level)
            item.setHidden(chosen != "all" and key != chosen)

    def _saved_this_sitting(self) -> list[dict]:
        """The runs saved in this sitting (in the kind's folder, its other sittings' runs left out)."""
        out = []
        for path in sorted(results.raw_folder(self.session.kind_folder).glob("*/run.json")):
            try:
                row = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if row.get("sitting") == self.session.folder.name:
                out.append(row)
        return out

    def _summary(self) -> str:
        rows = []
        repeated = 0
        skipped_rows = []
        for row in self._saved_this_sitting():
            if row.get("skipped"):                 # a task that never started: saved, counted apart
                skipped_rows.append(row)
                continue
            if row.get("repeated") or row.get("excluded"):   # an infrastructure failure: not counted
                repeated += 1
                continue
            rows.append(row)
        choice = self.session.info.get("plan_choice")
        lines = [f"# Session {self.session.folder.name}", "",
                 f"{'REAL TEST' if self.session.real else 'Practice'} · runs: {len(rows)}"
                 + (f" (and {repeated} infrastructure failure(s), not counted)" if repeated else ""), ""]
        if choice:                                 # planned vs run: which tasks were ticked, which left out
            lines.append(f"Planned: {_choice_words(choice)}  ")
            if choice["left_out"]:
                lines += [f"Ticked: {', '.join(choice['tasks'])}  ", f"Left out: {', '.join(choice['left_out'])}  "]
            lines += [f"Saved runs of: {', '.join(sorted({r.get('task', '?') for r in rows})) or 'none'}  ",
                      f"Ran by itself (no person watching): {sum(bool(r.get('unattended')) for r in rows)} of "
                      f"{len(rows)} runs", ""]
        skipped = [self.plan[i][0].id for i, st in enumerate(self._plan_status)
                   if st.startswith("Skipped") and i < len(self.plan)]
        if skipped:                                # (Simple 20: tasks the table couldn't start, not run)
            lines += [f"Skipped (the table wasn't READY for them): {', '.join(skipped)}  "]
            lines += [f"- {r.get('saved_as') or r.get('task')}: {(r.get('skipped') or {}).get('why')}  "
                      for r in skipped_rows]
            lines += [""]
        if any(r.get("outcome") for r in rows):    # (V4.2: outcomes, and what went badly wrong)
            lines += ["Outcomes: " + ", ".join(f"{w} {sum(r.get('outcome') == w for r in rows)}"
                                                 for w in ("PASS", "SOME PARTS", "FAIL"))
                      + f"; catastrophic: {sum(bool(r.get('catastrophic')) for r in rows)}  "]
            lines += [f"- CATASTROPHIC {r.get('saved_as') or r.get('task')}: {'; '.join(r['catastrophic'])}  "
                      for r in rows if r.get("catastrophic")]
            lines += [""]
        lines += ["| Category | Passed (unassisted) | Runs |", "|---|---|---|"]
        for cat in sorted({r.get("category", "?") for r in rows}):
            mine = [r for r in rows if r.get("category") == cat]
            lines.append(f"| {cat} | {sum(bool(r.get('unassisted_pass')) for r in mine)} | {len(mine)} |")
        failures: dict = {}
        for r in rows:
            if r.get("failure"):
                failures[r["failure"]] = failures.get(r["failure"], 0) + 1
        alarms = sum(len(r.get("alarms", [])) for r in rows)
        refused = {k: sum((r.get("refusals") or {}).get(k, 0) for r in rows) for k in ("wasted", "guard", "robot", "other")}
        moves = sum(r.get("moves", 0) for r in rows)
        interventions = sum(len(r.get("interventions", [])) for r in rows)
        scored = [r for r in rows if (r.get("credit") or {}).get("score") is not None]
        if scored:                                 # partial credit (0-100), next to the strict pass / fail
            levels: dict = {}
            for r in scored:
                levels.setdefault(r.get("level") or 0, []).append(r["credit"]["score"])
            bands = [r["credit"].get("band") for r in scored]
            lines += ["", f"Partial credit (0-100): mean {sum(r['credit']['score'] for r in scored) / len(scored):.0f} "
                          f"over {len(scored)} runs · Full {bands.count('Full')}, Partial {bands.count('Partial')}, "
                          f"Fail {bands.count('Fail')}  ",
                      "By " + ("group" if self._simple() else "level") + ": " + ", ".join(
                          f"{self._level_title(k)} {sum(v) / len(v):.0f}" for k, v in sorted(levels.items()))]
        lines += ["", f"Failures by type: {failures or 'none'}",
                  f"Controller alarms: {alarms} in {moves} moves · interventions: {interventions}",
                  f"Refused steps: {sum(refused.values())} ({refused})",
                  "Motion per run (median): " + _motion_line(rows)]
        return "\n".join(lines) + "\n"

    # ---- one run ---------------------------------------------------------------------------------------------------
    def _next(self) -> None:
        self._push = self._proceeded = False       # (Proceed to next task: the last run's only)
        reason = getattr(self, "_end_reason", None)
        if reason:                                 # (no cube seen for EMPTY_TASKS_END tasks in a row: it ends here)
            self._end_reason = None
            self._log(f"The session ends: {reason}.")
            self.end_session(reason)
            return
        self._scene_asked = self._scene_decided = False
        self._scene_info, self._scene, self._camera_fails = {}, None, 0
        self.index += 1
        self._set_plan_status(self.index, "Now")
        self.left_tabs.setCurrentIndex(1)                  # (the plan while setting the table out)
        if self.index >= len(self.plan):
            self.end_session("all runs done")
            return
        task, repeat = self.plan[self.index]
        self.events, self.steps, self.step_times = [], [], []
        self._seen_start, self._setup_status = [], []
        self.run = {"task": task.id, "category": task.category, "level": task.level, "layout": task.layout,
                    "prompt": task.prompt,
                    "before": task.before, "repeat": repeat, "layout_start": [c.__dict__ for c in task.start],
                    "arrangement": task.arrangement, "sitting": self.session.folder.name,
                    "cube_size_mm": self.tasks.cube_size_mm}
        if self.tasks.area is not None and self.ctx.twin_world is None:
            self.run["arrangement"] = {"by_hand": True}    # (where the hand put them: start_seen, at Start run)
        elif self.ctx.twin_world is not None and self.tasks.chained:
            # (where the task before left the cubes, the chain's start at the first: the plan's seeded draw was never
            # on the table, and the run's "cubes set out" and difficulty were made from it -- reviewer 2, 2026-10-27)
            self.run["arrangement"] = {"chained": True}
        self.run_folder = None
        self._paper_check = None
        self._broken = False
        self.reveal.setText("")
        self.judge.setText("")
        self.judge.setVisible(False)
        self.note.clear()
        self.unsure.setChecked(False)
        self.override.setChecked(False)
        self.run_text.clear()
        self._show_task_line()
        self.run_btn.setEnabled(False)
        self._set_state("setup")
        self._last_check = 0.0
        self._task_shown, self._checks, self._ready_at = time.monotonic(), 0, None
        self._countdown, self._not_ready = None, ""
        self._clear_gripper()
        if self.ctx.twin_world is not None and self.tasks.chained:
            # Simple 20: the table is set out once, as this task starts if every task before it went as asked; then
            # each task starts where the one before left the cubes
            if self.index == 0:
                from watcher.arrange import chain_start
                self._place_demo_cubes(chain_start(self.tasks, task.id), f"simple_{task.id}", self.tasks.cube_size_mm)
        elif self.ctx.twin_world is not None:
            # demo: nobody can put simulated cubes on their outlines, so the watcher sets the task's table out itself
            # (the demo's own starting scene had other cubes on it -- a yellow and a purple one)
            self._place_demo_cubes()
        elif self.tasks.sheet is not None and getattr(self.tasks.paper, "found", "") == "camera":
            self._check_paper_moved()
        self._timer.start(300)

    def _clear_gripper(self) -> None:
        """Before each run: nothing in the gripper, and the tools know nothing of the last run's table (a cube still
        held at the end of a run made every step of the next one "Already holding"). The twin: the gripper opens (the
        table is set out afresh after). The real Dobot: if a cube is still held, you take hold of it first, then the
        gripper opens -- it isn't dropped on the table."""
        executor, robot = self.ctx.executor, self.ctx.robot
        held = getattr(executor, "holding", None) or getattr(robot, "held_object", None)
        if held and self.ctx.twin_world is None:
            QMessageBox.information(self, "The gripper is holding a cube",
                                    f"The gripper still holds the {held} from the last run. Take hold of it, then press "
                                    "OK: the gripper opens. Then set the table out as it says.")
        if held or self.ctx.twin_world is not None:
            try:
                robot.open_gripper()
            except Exception as exc:  # noqa: BLE001 - said; the table check shows what is where
                self._log(f"Couldn't open the gripper: {exc}")
        forget = getattr(executor, "forget_scene", None)
        if forget is not None and self.tasks is not None and self.tasks.chained:
            try:                                   # (Simple 20: the same table carried on -- a cube it stacked on
                forget(keep_piles=True)            # stays known though the camera can't see it)
            except TypeError:
                forget()
        elif forget is not None:
            forget()

    def _check_paper_moved(self) -> None:
        """Live, before each run: the paper looked for again, and said if it slid since it was found."""
        self._paper_warning = None
        self._paper_check = None
        if self._busy:
            return
        from app.vision.paper import find_paper_with

        def look():
            return find_paper_with(self.ctx.camera, self.ctx.scene_builder.t_cam_to_robot, looks=2)
        self._job("paper", look)

    def _tick(self) -> None:
        """While setting up: look at the table now and then. While running: show new steps and robot events."""
        waited = time.monotonic() - getattr(self, "_task_shown", time.monotonic())
        if self.state == "setup" and self.tasks.chained:
            # V4.2: the table as the task before left it -- looked at once (the arm parked; again from a second pose
            # if a cube is missing), then the task starts with the cubes there; by hand, looked at now and then
            if (not self._busy and getattr(self, "_countdown", None) is None
                    and (not getattr(self, "_scene_asked", False) or (not self._auto_on() and time.monotonic()
                                                                       - self._last_check > CHECK_EVERY_MS / 1000))):
                self._scene_asked = True
                self._last_check = time.monotonic()
                self._job("check", self._scene_look)
        elif self.state == "setup" and self._auto_on() and waited > AUTO_READY_S:
            self._auto_pause(f"the table wasn't READY within {AUTO_READY_S:.0f} s")
        if (self.state == "setup" and not self.tasks.chained and not self._busy
                and time.monotonic() - self._last_check > CHECK_EVERY_MS / 1000):
            self._last_check = time.monotonic()
            self._job("check", lambda: self._look(looks=1))
        if self.state == "running":
            self._show_progress()

    def _show_progress(self) -> None:
        """New model steps and robot events of the current run, into the run log."""
        with self._lock:
            new_steps, self.steps_shown = self.steps[getattr(self, "steps_shown", 0):], len(self.steps)
            new_events, self.events_shown = self.events[getattr(self, "events_shown", 0):], len(self.events)
        hide = self._hide_prompts()                # (a test's steps say where its cubes go: names only, then)
        for s in new_steps:
            refused = "REFUSED " if str(s.result).startswith("ERROR") else ""      # (every refusal stands out)
            self._log(f"  {refused}{s.tool_name}(…)" if hide else
                      f"  {refused}{step_line(s.tool_name, s.arguments, s.result)}")
        for e in new_events:
            if e["kind"] == "alarm":
                self._log(f"  ALARM {e['codes']} {e['phases']} joints {e['joints']} "
                          f"{'(cleared by the app)' if e['auto_cleared'] else '(NEEDS YOU: clear it)'}")
            elif e["kind"] in ("estop", "alarm_cleared_by_hand", "clamp"):
                self._log(f"  {e['kind'].upper()}")
            elif e["kind"] == "no_answer":
                self._log("  The Dobot didn't answer a move command: sent again")
            elif e["kind"] == "status_lost":
                self._log(f"  A status reply from the Dobot was lost ({e.get('failures')} in a row)")

    @property
    def _busy(self) -> bool:
        return self._jobs > 0

    def _job(self, kind: str, fn: Callable) -> None:
        """Runs fn off the window's thread; _on_done gets (kind, result or exception)."""
        self._jobs += 1
        token = self._token

        def work():
            try:
                out = fn()
            except Exception as exc:  # noqa: BLE001
                out = exc
            self._done.emit((kind, out, token))
        threading.Thread(target=work, daemon=True, name=f"watcher-{kind}").start()

    def _on_done(self, payload) -> None:
        kind, out, token = payload
        if kind != "estop":                        # (the E-STOP notice isn't a job: counted down, a run read as done)
            self._jobs = max(0, self._jobs - 1)
        if token != self._token and kind in ("check", "paper", "place", "set_out"):
            return                                 # (from a session that has ended since: not this one's)
        if kind == "check":
            self._show_setup(out)
        elif kind == "set_out":
            self._set_out_done_now(out)
        elif kind == "run":
            self._run_finished(out)
        elif kind == "place":
            if isinstance(out, Exception):
                self._log(f"Couldn't set the cubes out: {out}")
        elif kind == "paper":
            if isinstance(out, Exception) or out.pose is None:
                self._paper_warning = ("couldn't see the whole paper to check it (" +
                                       (str(out) if isinstance(out, Exception) else out.reason) + ")")
            else:
                moved = out.pose.moved_from(self.tasks.paper)
                self._paper_warning = (f"{moved}: put it back, or press Find the paper (between sessions)"
                                       if moved else None)
            # (the run's record: the paper as found just before it)
            self._paper_check = ({"seen": False, "why": self._paper_warning} if isinstance(out, Exception) or
                                 out.pose is None else
                                 {"seen": True, "pose": {k: round(v, 1) if isinstance(v, float) else v
                                                         for k, v in out.pose.__dict__.items()},
                                  "moved": out.pose.moved_from(self.tasks.paper)})
            if self._paper_warning:
                self._log(f"Paper: {self._paper_warning}")
        elif kind == "find_paper":
            self._paper_found(out)
        elif kind == "estop":                      # (the main window's E-STOP, or the watcher's own)
            self._auto_pause("E-STOP was pressed")

    def _show_setup(self, seen) -> None:
        try:
            self._show_setup_now(seen)
        finally:                                   # (the status strip: READY or not, at once)
            self._refresh_status()

    def _show_setup_now(self, seen) -> None:
        if self.state != "setup" or self.session is None:
            return
        task = self.plan[self.index][0]
        if isinstance(seen, Exception) and self.tasks.chained:
            self._camera_fails = getattr(self, "_camera_fails", 0) + 1
            self.setup_text.setPlainText(f"The camera couldn't look: {seen}")
            if self._auto_on() and self._camera_fails >= 2:
                self._skip_task(f"the camera couldn't look ({seen})", infrastructure=True)
            else:
                self._scene_asked = False          # (looked at again on the next tick)
            return
        if isinstance(seen, Exception):
            self.setup_text.setPlainText(f"The camera couldn't look: {seen}")
            if self.tasks.area is None:
                self._show_ghosts([False] * len(task.start))
            self.run_btn.setEnabled(self._override_on())
            return
        if self.tasks.area is not None:           # no paper: the cubes anywhere, by hand; the camera says if it'll do
            self._show_hand_setup(task, seen)
            return
        status = setup_status(task.start, seen)
        extra = [c.label for c in seen if c.label not in {s.label for s in task.start}]
        lines = []
        if task.arrangement and "spots" in task.arrangement:
            lines.append("Put: " + ", ".join(f"{colour} on spot {spot}"
                                             for colour, spot in task.arrangement["spots"].items()))
        if getattr(self, "_paper_warning", None):
            lines.append(f"PAPER: {self._paper_warning}")
        lines += [s["say"] for s in status]
        if len(seen) > len(task.start):
            lines.append(f"Take away: {len(seen) - len(task.start)} cube(s) not in this layout ({', '.join(extra)})")
        ready = all(s["ok"] for s in status) and len(seen) == len(task.start)
        stopped = bool(getattr(self.ctx.robot, "_estopped", False))
        if stopped:
            lines.append("E-STOP is on: reset it in the main window (Manual tab, 'Reset E-STOP') first")
        self._checks = getattr(self, "_checks", 0) + 1
        if ready and getattr(self, "_ready_at", None) is None:
            self._ready_at = time.monotonic()
        lines.append("READY: press Start run" if ready and not stopped else "")
        self.setup_text.setPlainText("\n".join(lines))
        self.run_btn.setEnabled((ready or self._override_on()) and not stopped)
        if ready and not stopped:
            QTimer.singleShot(0, self._auto_step)
        self._seen_start = seen
        self._show_ghosts([s["ok"] for s in status])
        self._setup_status = status

    def _show_hand_setup(self, task, seen) -> None:
        """A paper-free task's setting out: which cubes to put down, and READY once the camera sees them where the task
        can be done from (watcher/arrange.py check_start) -- no outlines to put them on."""
        from watcher.arrange import START_GAP_MM, check_start, colour_of
        colours = [colour_of(c) for c in (task.start_rule or {}).get("cubes", [])]
        names = colours[0] if len(colours) == 1 else ", ".join(colours[:-1]) + " and " + colours[-1]
        lines = [f"Put the {names} cube{'s' if len(colours) > 1 else ''} anywhere on the grey sheet"
                 + (f", at least {START_GAP_MM / 10:.0f} cm apart." if len(colours) > 1 else ".")
                 + " Nothing else on the table."]
        if self.tasks.chained:                     # (V4.2: the table as it is -- nothing sorted, nothing waited for)
            self._scene_decide(task, list(seen))
            return
        problem = check_start(task, self.tasks, list(seen))
        self._not_ready = problem or ""
        lines.append(problem or "Seen: " + ", ".join(f"{c.label} ({c.x:.0f}, {c.y:.0f})"
                                                     + (f" {c.level} up" if c.level > 1 else "") for c in seen))
        ready = problem is None
        status = [{"cube": c.label, "ok": ready, "say": f"{c.label}: seen at ({c.x:.0f}, {c.y:.0f})"} for c in seen]
        stopped = bool(getattr(self.ctx.robot, "_estopped", False))
        if stopped:
            lines.append("E-STOP is on: reset it in the main window (Manual tab, 'Reset E-STOP') first")
        self._checks = getattr(self, "_checks", 0) + 1
        if ready and getattr(self, "_ready_at", None) is None:
            self._ready_at = time.monotonic()
        counting = getattr(self, "_countdown", None)
        lines.append(f"READY: starting by itself in {counting} s (E-STOP, or untick Run by itself, to stop it)"
                     if ready and not stopped and counting is not None else
                     "READY: press Start run" if ready and not stopped else "")
        self.setup_text.setPlainText("\n".join(lines))
        self.run_btn.setEnabled((ready or self._override_on()) and not stopped)
        if ready and not stopped:
            QTimer.singleShot(0, self._auto_step)
        self._seen_start = seen
        self.video.set_marks([])
        self._outlines_3d = []
        self._setup_status = status

    def _maybe_set_out(self, task, seen) -> bool:
        """Simple 20 on the Dobot, before the session's first task: the cubes were put down anywhere, in any order --
        the arm sets them out where the task starts (watcher/setout.py), once. True while it does (the table check
        waits)."""
        from watcher.arrange import chain_start
        from watcher.setout import needs_set_out, targets_of, towers_of
        from watcher.tasks import with_hidden
        if (self.ctx.twin_world is not None or getattr(self, "_set_out_done", True) or not self._auto_on()
                or self.state != "setup"):
            return False
        layout = chain_start(self.tasks, task.id)
        filled = with_hidden(list(seen), [task.tower], self.tasks.cube_size_mm) if task.tower else list(seen)
        self._set_out_done = True
        if not needs_set_out(filled, layout):     # (they're there already)
            return False
        targets, on = targets_of(layout), towers_of(layout)
        self.setup_text.setPlainText("Setting the cubes out: the arm puts each one where the first task starts "
                                     "(E-STOP stops it). Not a task: it isn't scored, but every step is logged.")
        self._log("Setting out: the cubes from where you put them to where the first task starts.")
        executor, poses, table_z, size = self.ctx.executor, self.ctx.poses_dir, getattr(self, "_table_z", 0.0), \
            self.tasks.cube_size_mm

        def work():
            from watcher.setout import SetOutError, set_out
            try:
                return {"ok": True, "steps": set_out(executor, poses, table_z, targets, size,
                                                     stop=self._stop.is_set, on=on)}
            except SetOutError as exc:
                return {"ok": False, "why": str(exc), "steps": exc.steps}
        self._stop.clear()
        self._setting_out = True                   # (until _set_out_done_now: a skip meanwhile says so)
        self._job("set_out", work)
        return True

    def _set_out_done_now(self, out) -> None:
        """The set-out has ended: logged (the session's index and set_out.json), said, and the table check goes on --
        or, if it couldn't, Run by itself pauses for you to put them there by hand."""
        from watcher.setout import summary
        self._setting_out = False
        if isinstance(out, Exception):
            out = {"ok": False, "why": f"{type(out).__name__}: {out}", "steps": []}
        if self.session is None:
            return
        results.write_json(self.session.folder / "set_out.json", out)
        self.session.record({"set_out": "done" if out["ok"] else "failed", "why": out.get("why"),
                             "moves": summary(out["steps"]),
                             "refused_steps": [s["result"][:200] for s in out["steps"]
                                               if str(s["result"]).startswith("ERROR")]})
        for s in out["steps"]:
            if str(s["result"]).startswith("ERROR"):
                self._log(f"  REFUSED {s['tool']}: {s['result'][:200]}")
        if out["ok"]:
            self._log(f"Set out ({summary(out['steps'])}): the first task starts when the camera sees them READY.")
        else:
            self._log(f"Couldn't set the cubes out: {out['why']}.")
            self._auto_pause(f"the cubes couldn't be set out ({out['why']}): put them in the starting layout by hand, "
                             "then tick Run by itself again")
        self._task_shown = time.monotonic()             # (the table's 20 s count from now)

    def _place_clicked(self) -> None:
        if self._busy:                             # (a look or a setting-out is under way: its result would mix)
            self._log("A moment: the table is being looked at. Press Set the cubes out again.")
            return
        self._place_demo_cubes()

    def _place_demo_cubes(self, cubes: Optional[list[Cube]] = None, name: str = "", size: float = 0.0,
                          wait: bool = False) -> None:
        """Demo: the watcher sets the cubes out itself, in the simulated world -- the current task's, unless given.
        Only the study's red, blue and green cubes: nothing else is left on the table."""
        if cubes is None:
            task = self.plan[self.index][0]
            cubes, name, size = task.start, f"study_{task.id}", self.tasks.cube_size_mm
        world = self.ctx.twin_world
        colors = {"red": [0.8, 0.1, 0.1, 1], "blue": [0.1, 0.2, 0.8, 1], "green": [0.1, 0.7, 0.2, 1]}
        scene = {"name": name, "places": {},          # (the zones are saved places, see start_session)
                 "objects": [{"id": f"{c.color}_cube_{i}", "label": c.label, "color_rgba": colors[c.color],
                              "size_mm": size, "position_mm": [c.x, c.y, size * (c.level - 1) + size / 2],
                              "yaw_deg": c.yaw}
                             for i, c in enumerate(sorted(cubes, key=lambda c: c.level))]}   # (a tower bottom first)
        if wait:
            world.switch_scenario(scene["name"], scene)
        else:
            self._job("place", lambda: world.switch_scenario(scene["name"], scene))

    def showEvent(self, event) -> None:   # noqa: N802 (Qt)
        """Demo: on opening, the table gets just the study's red, blue and green cubes (the demo's own starting scene
        has others); closing puts the app's scene back."""
        super().showEvent(event)
        world = self.ctx.twin_world
        if world is None or getattr(self, "_scene_before", None) is not None or self.session is not None:
            return
        try:
            self._scene_before = _scene_as_it_is(world)
            tasks = load_task_set(TRAIN_FILE, 3, self._cube_size())
            self._place_demo_cubes(tasks.tasks[0].start, "study_table", tasks.cube_size_mm, wait=True)
            if tasks.sheet is not None:            # (the A4 sheet and its spots, drawn on the table)
                from watcher.ghost import ghost_outlines_3d
                self._outlines_3d = ghost_outlines_3d([], [], tasks.zones, 0.0, tasks.cube_size_mm, paper=tasks.paper)
        except Exception:  # noqa: BLE001 - the demo still works with its own scene
            logger.warning("Couldn't set out the study's cubes in the demo", exc_info=True)

    def _put_back_demo_scene(self) -> None:
        before, self._scene_before = getattr(self, "_scene_before", None), None
        if before is not None and self.ctx.twin_world is not None:
            try:
                self.ctx.twin_world.switch_scenario(before.get("name", "demo"), before)
            except Exception:  # noqa: BLE001
                logger.warning("Couldn't put the demo's scene back", exc_info=True)

    def _calibration_state(self) -> dict:
        """The calibration in use as the run starts (and what the continuous calibration has done): for its record."""
        try:
            return dict(self.ctx.calibration_state() or {})
        except Exception:  # noqa: BLE001 - a record without it, rather than no run
            logger.warning("Couldn't read the calibration's state for the run's record", exc_info=True)
            return {}

    def _start_run(self) -> None:
        if self.session is None or self.state != "setup" or not self.run_btn.isEnabled():
            return                                 # (also a retry below: the table check since may have said no)
        if self._busy:                             # a table check is looking right now: try again in a moment
            QTimer.singleShot(200, self._start_run)
            return
        held = self.ctx.held()
        if held:                                   # (Camera setup is using the camera or the arm)
            self._log(f"Not started: {held}. Press Start run again when it has finished.")
            return
        person = self._arm_needs_person()
        if person:                                 # (study 2, S-08: the next runs went on, on an arm that wasn't homed)
            self._log(f"Not started: the arm needs a person. {person}")
            self._countdown = None
            self._auto_pause("the arm needs a person")
            return
        if self.tasks.area is not None and self.ctx.twin_world is None and not self.tasks.chained:
            # no paper: every target is measured from this start, so it's a fresh look of several pictures (the READY
            # check's was one, and may be seconds old), and nothing may have moved since READY
            try:
                fresh = self._look(looks=START_LOOKS)
            except Exception as exc:  # noqa: BLE001
                self._log(f"Not started: the camera couldn't look ({exc}). Press Start run again.")
                return
            before = list(getattr(self, "_seen_start", []))
            shifted = sorted({c.label for c in fresh} ^ {c.label for c in before}) or [
                a.label for a, b in zip(before, match(before, fresh))
                if b is None or math.hypot(a.x - b.x, a.y - b.y) > START_MOVED_MM]
            if shifted:
                self._log(f"Not started: {', '.join(shifted)} moved since READY. Wait for READY again, then press "
                          "Start run.")
                self.run_btn.setEnabled(False)
                return
            from watcher.arrange import check_start
            problem = check_start(self.plan[self.index][0], self.tasks, fresh)
            if problem:
                self._log(f"Not started: {problem}")
                self.run_btn.setEnabled(False)
                return
            self._seen_start = fresh
        self._timer.stop()
        self._stop.clear()
        self._empty_in_row, self._empty_ids = 0, []   # (a task started: no longer "nothing seen in a row")
        task, repeat = self.plan[self.index]
        self.run_folder = self.session.run_folder(task.id, repeat)
        # noted the moment it starts: should the app close or crash during it, the index still shows it (and the next
        # session keeps what it left, as …__crashed)
        self.session.record({"started": self.run_folder.name, "task": task.id, "repeat": repeat})
        seen = getattr(self, "_seen_start", [])
        if self.tasks.area is not None and (self.ctx.twin_world is None or self.tasks.chained) and seen:
            from dataclasses import replace as _replace          # by hand, or chained: the start is what was seen
            task = _replace(task, start=list(seen))
            self.run["layout_start"] = [c.__dict__ for c in seen]
        # (Discard and run again: back to this start -- the twin's table set out as it is now, the hidden cubes known)
        self._known_at_start = dict(getattr(self, "_known", {}))
        self._scene_at_start = (_scene_as_it_is(self.ctx.twin_world)
                                if self.ctx.twin_world is not None and self.tasks.chained else None)
        now = time.monotonic()
        shown, ready_at = getattr(self, "_task_shown", now), getattr(self, "_ready_at", None)
        homed_at = getattr(self.ctx.robot, "homed_at", None)
        self._runs_since_home = getattr(self, "_runs_since_home", 0) + 1
        self.run.update(setup_effort={"seconds": round(now - shown, 1), "checks": getattr(self, "_checks", 0),
                                      "ready_after_s": round(ready_at - shown, 1) if ready_at else None},
                        since_homing={"minutes": round((now - homed_at) / 60.0, 1) if homed_at else None,
                                      "runs_this_session": self._runs_since_home},
                        difficulty=difficulty(task, self.tasks.cube_size_mm),
                        session_run=self.index + 1)
        self.run.update(started_at=time.strftime("%Y-%m-%d %H:%M:%S"), started_epoch=time.time(),
                        robot_at_start=observe.robot_state(self.ctx.robot),
                        paper_check=getattr(self, "_paper_check", None),
                        calibration=self._calibration_state())
        scene = getattr(self, "_scene", None)
        if self.tasks.chained and scene is not None:   # (V4.2: the scene it started from, and what may move)
            from watcher.arrange import blocking_cubes
            self.run.update(start_condition=scene["condition"], scene=scene, parts=scene["parts"],
                            may_move=blocking_cubes(task, self.tasks, list(seen)))
        self.run.update(start_seen=[c.__dict__ for c in seen], setup=getattr(self, "_setup_status", []),
                        started_anyway=bool(self._override_on() and not (
                            getattr(self, "_setup_status", None) and all(s.get("ok") for s in self._setup_status))))
        with self._lock:                           # (nothing from the setup -- a jog, a Clear Alarms -- is the run's)
            self.events, self.steps, self.step_times = [], [], []
        self.steps_shown = self.events_shown = 0
        self.video.set_marks([])                   # nothing over the picture while the arm works
        self._outlines_3d = []
        self._set_state("running")
        self._timer.start(300)
        self._log("Running…")
        self._save_picture("start")
        agent, prompt, before = self.ctx.agent, task.prompt, list(task.before)
        wanted, live = sorted(c.label for c in (seen or task.start)), self.ctx.twin_world is None
        chained = bool(self.tasks.chained)
        from watcher.arrange import infer_hidden
        known_now = {c.label: c for c in (seen or task.start)}

        def short(cubes) -> bool:
            """Fewer of the start's cubes than wanted (a cube a tower hides counts as there)."""
            cubes = infer_hidden(list(cubes), known_now, self.tasks.cube_size_mm)[0]
            return sorted(c.label for c in cubes if c.label in wanted) != wanted

        def work():
            started = time.monotonic()
            out = {"error": None, "before_traces": []}
            try:
                # every run starts fresh: no "previous request" from the last run (or a typed prompt) in its context,
                # as in the twin, where each run has a new agent
                agent.previous_prompt = ""
                for earlier in before:
                    if self._stop.is_set():
                        raise RuntimeError("RobotStopped: E-STOP was pressed")
                    done = agent.run(earlier, on_step=self._on_step)
                    if getattr(done, "trace", None) is not None:      # (the model log has these first)
                        out["before_traces"].append(done.trace)
                if self._stop.is_set():
                    raise RuntimeError("RobotStopped: E-STOP was pressed")
                run = agent.run(prompt, on_step=self._on_step)
                out.update(final=run.final_message, trace=run.trace)
            except Exception as exc:  # noqa: BLE001
                out["error"] = f"{type(exc).__name__}: {exc}"
            out["seconds"] = round(time.monotonic() - started, 1)
            with self._lock:                       # the run's own events end here: the park move isn't the run's
                out["events_until"] = len(self.events)
            try:                                   # park out of the camera's way, then look
                pose = self.ctx.park_pose or getattr(self.ctx.executor, "look_pose", None)
                if pose is not None:
                    from app.hardware.interfaces import Pose
                    self.ctx.robot.move_to(pose if isinstance(pose, Pose) else Pose(*pose))
            except Exception as exc:  # noqa: BLE001
                out["park_error"] = str(exc)
            out["robot_at_end"] = observe.robot_state(self.ctx.robot)
            out["end_look"] = {}
            try:
                out["end"] = self._look(looks=END_LOOKS, stats=out["end_look"])
                # not the start's cubes (one hidden, or something else of a colour): looked at once more, and said
                if live and short(out["end"]):
                    out["end_relooked"] = sorted(c.label for c in out["end"])
                    time.sleep(1.0)
                    out["end"] = self._look(looks=END_LOOKS, stats=out["end_look"])
                    if short(out["end"]) and chained:
                        out["end_second_pose"] = self._park(second=True)       # (V4.2: from the other side too)
                        from watcher.arrange import merge_scene
                        out["end"] = merge_scene(out["end"], self._look(looks=END_LOOKS))
                    if short(out["end"]):
                        out["end_unclear"] = sorted(c.label for c in out["end"])
            except Exception as exc:  # noqa: BLE001
                out["end"], out["look_error"] = [], str(exc)
            return out
        self._job("run", work)
        self.left_tabs.setCurrentIndex(0)                  # (the run log while the arm works)
        self._timed_out = False
        self._run_serial = getattr(self, "_run_serial", 0) + 1
        limit = self._time_limit()
        if limit:                                  # (Simple 20: each task has so long, then it is stopped)
            serial = self._run_serial
            QTimer.singleShot(int(limit * 1000), lambda: self._time_up(serial))

    def _time_up(self, serial: int) -> None:
        """The task's time limit is up and it is still running: its prompt is ended (as E-STOP ends it, but the arm
        isn't stopped: a move under way finishes, then it parks), and it is scored and saved as it stands."""
        if serial != getattr(self, "_run_serial", 0) or self.state != "running":
            return
        self._timed_out = True
        self._stop.set()
        cancel = getattr(self.ctx.agent, "cancel", None)
        if cancel is not None:
            cancel()
        self._log(f"Time limit ({self._time_limit() / 60:.0f} min) reached: the task is ended and saved as it "
                  "stands.")

    def _look(self, looks: int, stats: Optional[dict] = None) -> list[Cube]:
        """A fresh look at the cubes with the watcher's own finder (the app's detector isn't the instrument). The twin:
        the simulator's exact positions (the ideal-hardware reference is scored without a camera's error). `stats`:
        filled with what the look was like."""
        if self.ctx.twin_world is not None:
            if stats is not None:
                stats["source"] = "the twin's exact positions"
            return observe.exact_cubes(self.ctx.twin_world)
        return observe.look_cubes(self.ctx.camera, self.ctx.scene_builder.t_cam_to_robot,
                                  getattr(self, "_table_z", 0.0), looks=looks,
                                  cube_mm=self.tasks.cube_size_mm if self.tasks else 25.0, stats=stats)

    def _on_step(self, step) -> None:
        with self._lock:
            self.steps.append(step)
            self.step_times.append(time.time())       # (when it finished: its report's timeline)
        self._activity_at = time.monotonic()

    def _on_robot_event(self, event: dict) -> None:
        with self._lock:
            self.events.append(event)
        self._activity_at = time.monotonic()
        if event.get("kind") == "home":
            self._runs_since_home = 0
        if event.get("kind") == "estop":            # (the main window's E-STOP too): the run's prompts end
            self._stop.set()
            cancel = getattr(self.ctx.agent, "cancel", None)
            if cancel is not None and self.state == "running":
                cancel()
            self._done.emit(("estop", None, self._token))  # (Run by itself pauses: on the window's thread)

    def _run_finished(self, out) -> None:
        self._timer.stop()
        self._show_progress()
        if isinstance(out, Exception):
            out = {"error": f"{type(out).__name__}: {out}", "end": []}
        self._save_picture("end")
        self._outcome = out
        self._log("Finished. Your verdict first, then the watcher's score.")
        self._show_judge()
        self._set_state("verdict")

    def _save_marked_picture(self, targets: list[dict]) -> None:
        """end_marked.png: the end picture with each target's wanted place (a circle the size of the pass rule, green
        if met, red if not) and a line to where the cube ended. Live: drawn on the camera's end picture with the
        calibration. Demo: the 3D model again, with the same marks."""
        from watcher.ghost import draw_marks, target_marks
        tol, table_z, size = self.tasks.rule.position_mm, getattr(self, "_table_z", 0.0), self.tasks.cube_size_mm
        try:
            if self.view3d is None:
                marks = target_marks(targets, tol, table_z, size, self.ctx.scene_builder.t_cam_to_robot,
                                     self.ctx.camera.get_intrinsics())
                draw_marks(self.run_folder / "end.png", marks, self.run_folder / "end_marked.png")
            else:
                self._save_picture("end_marked", extra=target_marks(targets, tol, table_z, size), depth=False)
        except Exception as exc:  # noqa: BLE001 - a missing picture is noted, not the end of the run
            logger.warning("Couldn't make the marked end picture: %s", exc)

    def _save_picture(self, name: str, extra: Optional[list] = None, depth: bool = True) -> None:
        """The run's picture (start.png, end.png) and the camera's depth (for re-scoring). Live: the camera's photo.
        Demo: the 3D model, from its usual angle whatever way the view is turned, with the task's zones drawn -- not
        the simulated camera's picture. `extra`: more outlines to draw (the demo's marked end picture); `depth` False:
        no depth file with it."""
        if self.view3d is None:
            observe.capture(self.ctx.camera, self.run_folder, name)
            return
        if depth:
            observe.capture(self.ctx.camera, self.run_folder, name, picture=False)
        view, shown = self.view3d, self._outlines_3d
        turned = (view.yaw, view.pitch, view.dist, list(view.target))
        try:
            from watcher.ghost import start_outlines, task_zones
            task, _ = self.plan[self.index]
            self._outlines_3d = [o for o in start_outlines([], self.tasks.zones, getattr(self, "_table_z", 0.0),
                                                           self.tasks.cube_size_mm,
                                                           highlight=task_zones(task.targets),
                                                           paper=self.tasks.paper)] + list(extra or [])
            view.set_view("3D", redraw=False)
            self.run_folder.mkdir(parents=True, exist_ok=True)
            view.grab().save(str(self.run_folder / f"{name}.png"))
        except Exception as exc:  # noqa: BLE001 - a missing picture is noted, not the end of the run
            logger.warning("Couldn't save the %s picture: %s", name, exc)
        finally:
            view.yaw, view.pitch, view.dist, view.target = turned
            self._outlines_3d = shown

    def _show_judge(self) -> None:
        """After the run, for your verdict: what the task asked, what counts as a pass, and the zones and the cubes'
        start places drawn again (the outlines go while the arm works)."""
        from watcher.ghost import start_outlines, task_zones
        task, _ = self.plan[self.index]
        self.judge.setText(self._judge_text())
        self.judge.setVisible(True)
        start = [Cube(**c) for c in self.run.get("start_seen", [])] or list(task.start)
        table_z = getattr(self, "_table_z", 0.0)
        highlight = task_zones(task.targets)
        self._outlines_3d = start_outlines(start, self.tasks.zones, table_z, self.tasks.cube_size_mm,
                                           highlight=highlight, paper=self.tasks.paper)
        try:
            marks = start_outlines(start, self.tasks.zones, table_z, self.tasks.cube_size_mm,
                                   self.ctx.scene_builder.t_cam_to_robot, self.ctx.camera.get_intrinsics(),
                                   highlight=highlight)
        except Exception:  # noqa: BLE001 - no calibration yet: the words and the 3D view still say it
            logger.debug("No outlines on the picture", exc_info=True)
            marks = []
        self.video.set_marks(marks)

    def _verdict(self, verdict: str) -> None:
        if self.state != "verdict" or self.session is None or self.run_folder is None:
            return
        if verdict == "skipped" and self._where() != "twin" and not self._simple():
            return                                 # (only the twin -- and Simple 20 -- is scored without a person)
        observer ={"verdict": verdict, "confidence": "unsure" if self.unsure.isChecked() else "sure",
                    "note": self.note.text().strip(),
                    "time": time.strftime("%Y-%m-%dT%H:%M:%S")}
        results.write_json(self.run_folder / "observer.json", observer)     # saved before the score is shown
        caliper = None
        if self.session.real and self._where() == "dobot" and self.index % 5 == 2 and verdict != "skipped":
            value, ok = QInputDialog.getText(self, "Caliper check", "Measure the target cube(s) with the caliper "
                                             "or protractor and type what you find (mm / degrees, any notes):")
            caliper = value if ok else None
            if caliper:
                observer["caliper"] = caliper
                results.write_json(self.run_folder / "observer.json", observer)
        try:
            self._score_and_save(observer)
        except Exception as exc:  # noqa: BLE001 - never leave the session stuck waiting for a verdict
            logger.exception("Scoring or saving the run failed")
            self._broken = True
            try:
                results.write_text(self.run_folder / "scoring_error.txt", f"{type(exc).__name__}: {exc}\n")
            except Exception:  # noqa: BLE001
                pass
            if self.tasks.chained and self._keep_unscored(observer, exc):
                return
            self.reveal.setText(f"This run couldn't be scored or saved ({type(exc).__name__}: {exc}). Press Discard "
                                "and run again (it runs again from the same start), or End session.")
            self._set_state("reveal")

    def _keep_unscored(self, observer: dict, exc: Exception) -> bool:
        """Simple 20: a run that couldn't be scored is still kept -- saved as a fail, "not scored", with what it
        has (the run's own record so far, the error) -- and the session goes on. False if even that failed."""
        try:
            out = getattr(self, "_outcome", {}) or {}
            self.run.update(passed=False, unassisted_pass=False, failure="not scored", observer=observer,
                            excluded="not scored",
                            credit={"score": None, "band": "not scored"},
                            scoring_error=f"{type(exc).__name__}: {exc}", error=out.get("error"),
                            reply=out.get("final", ""), seconds=out.get("seconds"),
                            end_seen=[c.__dict__ for c in out.get("end") or []], timed_out=self._timed_out)
            results.write_json(self.run_folder / "run.json", self.run)
            self.session.record({"run": self.run_folder.name, "passed": False, "failure": "not scored",
                                 "error": f"{type(exc).__name__}: {exc}"})
        except Exception:  # noqa: BLE001
            logger.exception("Couldn't keep the unscored run either")
            return False
        self._broken = False
        self.reveal.setText(f"This run couldn't be scored ({type(exc).__name__}: {exc}): it is saved, \"not "
                            "scored\" (the watcher's own failure: not counted), and the session goes on.")
        self._set_plan_status(self.index, "Fail (not scored)")
        self._set_state("reveal")
        return True

    def _score_and_save(self, observer: dict) -> None:
        task, repeat = self.plan[self.index]
        out = self._outcome
        measured = [Cube(**c) for c in self.run.get("start_seen", [])]
        if task.tower:                             # (the cubes under the start's tower: hidden, there all the same)
            from watcher.tasks import with_hidden
            measured = with_hidden(measured, [task.tower], self.tasks.cube_size_mm)
        # where the camera saw each layout cube at the start; one it didn't see keeps its layout place -- but a chained
        # set's start is the scene as it was (V4.2): a cube that couldn't be seen isn't given a made-up place
        if self.tasks.chained and measured:
            seen_start = measured
        else:
            seen_start = [found or want for want, found in zip(task.start, match(task.start, measured))]
        end = out.get("end") or []
        if self.tasks.chained:                     # (a cube under a tower at the end isn't missing)
            from watcher.tasks import task_towers, with_hidden
            end = with_hidden(infer_hidden(list(end), {c.label: c for c in seen_start}, self.tasks.cube_size_mm)[0],
                              task_towers(task), self.tasks.cube_size_mm)
        may_move = self.run.get("may_move") or {}
        area = self.tasks.area if self.tasks.chained else None
        result = score(task, end, self.tasks.zones, self.tasks.rule, self.tasks.cube_size_mm, start=seen_start,
                       may_move=may_move, area=area)
        # (a part already met at the start isn't "done" by the run: doing nothing can't make SOME PARTS)
        at_start = score(task, seen_start, self.tasks.zones, self.tasks.rule, self.tasks.cube_size_mm,
                         start=seen_start, may_move=may_move, area=area)
        verdict_word = (outcome(result, at_start, moved_cubes(seen_start, end)) if self.tasks.chained else
                        "PASS" if result.passed else "FAIL")
        with self._lock:
            events, steps, step_times = list(self.events), list(self.steps), list(getattr(self, 'step_times', []))
        park_events = events[out.get("events_until", len(events)):]
        events = events[:out.get("events_until", len(events))]
        alarms = [e for e in events if e["kind"] == "alarm"]
        moves = [e for e in events if e["kind"] == "move"]
        interventions = [e["kind"] for e in events if e["kind"] in ("estop", "alarm_cleared_by_hand")]
        interventions += [f"alarm needing a person {a['codes']}" for a in alarms if not a.get("auto_cleared")]
        if observer["verdict"] == "helped":
            interventions.append("observer: I had to help")
        if getattr(self, "_proceeded", False):     # (PREREG 6: any action in the app between Start run and the end)
            interventions.append("Proceed to next task pressed")
        infra = out.get("error") if out.get("error") and not any(
            w in out["error"] for w in ("RobotAlarm", "OutOfReach", "RobotStopped")) else None
        if any(e["kind"] == "estop" for e in events) or out.get("park_error"):
            infra = None                           # (E-STOP is an intervention; a failed park is the arm's doing)
        if not infra and not out.get("park_error") and not any(e["kind"] == "estop" for e in events) and (
                out.get("look_error") or (not end and seen_start)):
            # the camera couldn't look at the end: the setup failing, not the robot (re-run, PREREG 5.1)
            infra = f"end look failed: {out.get('look_error') or 'no cubes seen'}"
        trace = out.get("trace")
        facts = RunFacts(infrastructure_error=infra, tool_results=[str(s.result) for s in steps],
                         tool_names=[s.tool_name for s in steps],
                         alarms=[int(c, 16) for a in alarms for c in a["codes"]],
                         final_message=out.get("final", "") or "", app_estimates=extract.app_estimates(trace),
                         tool_args=[s.arguments for s in steps],
                         object_labels=object_labels_from([str(s.result) for s in steps]))
        pick_rows = extract.picks(trace, seen_start)
        failure = classify(task, result, facts, seen_start, end, seen_start=seen_start, zones=self.tasks.zones,
                           may_move=may_move, first_step=bool(self.tasks.chained))
        timed_out = bool(getattr(self, "_timed_out", False))
        if timed_out and not result.passed:        # (Simple 20's time limit: ended by the watcher, not a crash)
            failure = "timeout"
        if getattr(self, "_proceeded", False) and not result.passed:   # (Proceed to next task pressed mid-run)
            failure = "ended by you"
        unassisted = result.passed and not interventions
        credit = partial_credit(result, self.tasks.rule)        # (0-100, next to the strict pass / fail)
        refusals = count_refusals(facts.tool_results)
        # every step the app (or the arm) refused, whole: which tool, what was asked, why, when
        refused_steps = [{"step": n, "tool": s.tool_name, "args": s.arguments, "why": str(s.result)[:600],
                          "t_end": (round(t - self.run["started_epoch"], 1) if t is not None
                                    and self.run.get("started_epoch") else None)}
                         for n, (s, t) in enumerate(zip(steps, step_times + [None] * (len(steps) - len(step_times))),
                                                    start=1)
                         if str(s.result).startswith("ERROR")]
        proceeded = bool(getattr(self, "_proceeded", False))
        # what went badly wrong (V4.2, a flag beside the outcome; the score is unchanged): on the table, and the arm
        catastrophic = list(result.catastrophic) if self.tasks.chained else []
        at_end, at_begin = out.get("robot_at_end") or {}, self.run.get("robot_at_start") or {}
        if self.tasks.chained:
            if out.get("park_error"):
                catastrophic.append(f"the arm couldn't park: {out['park_error']}")
            if at_end.get("holding"):
                catastrophic.append(f"the arm still holds the {at_end['holding']}")
            if at_begin.get("homed") and at_end.get("homed") is False:
                catastrophic.append("the arm lost its homing")
        if self.tasks.chained:                     # (V4.2's judging: a chained set's runs only)
            self.run.update(outcome=verdict_word, catastrophic=catastrophic, prepared=result.prepared)
        self.run.update(
            passed=result.passed, unassisted_pass=unassisted, failure=failure, score=result.as_dict(), refusals=refusals,
            credit=credit,
            motion=motion_efficiency(moves, out.get("seconds")),
            position_errors_mm=result.position_errors, angle_errors_deg=result.angle_errors,
            end_seen=[c.__dict__ for c in end], observer=observer, interventions=interventions,
            alarms=alarms, moves=len(moves), failed_moves=sum(not m.get("ok") for m in moves),
            clamps=sum(e["kind"] == "clamp" for e in events), error=out.get("error"),
            park_error=out.get("park_error"), look_error=out.get("look_error"), seconds=out.get("seconds"),
            end_relooked=out.get("end_relooked"), end_unclear=out.get("end_unclear"),
            park_events=[e["kind"] for e in park_events],
            reply=out.get("final", ""), goal_check=((out.get("trace") or {}).get("end") or {}).get("goal"),
            calls=[{"tool": s.tool_name, "args": s.arguments, "result": str(s.result)[:400],
                    "t_end": (round(t - self.run["started_epoch"], 1) if t is not None and self.run.get("started_epoch")
                              else None)}
                   for s, t in zip(steps, step_times + [None] * (len(steps) - len(step_times)))],
            picks=len(pick_rows), perception_offsets_mm=[r["perception_offset_mm"] for r in pick_rows
                                                         if r["perception_offset_mm"] is not None],
            arrival=extract.arrival(trace), time_split=extract.time_split(trace, out.get("seconds")),
            plan=extract.plan(steps), events_log=report.events_log(events, self.run.get("started_epoch")),
            how_to_judge=how_to_judge(task, self.tasks.rule), timed_out=timed_out,
            time_limit_s=self._time_limit(), refused_steps=refused_steps, proceeded_by_you=proceeded)
        # the measurements: every move's distance, time and speed, the gripper, the model's turns, which way each
        # target was off, the arm and the camera at the end, the link to the robot
        traces = list(out.get("before_traces") or []) + ([out["trace"]] if out.get("trace") is not None else [])
        motion = details.motion_detail(traces)
        self.run.update(motion_detail=motion, model_turns=details.model_turns(traces),
                        which_way=details.which_way(result.as_dict()), robot_at_end=out.get("robot_at_end"),
                        end_look=out.get("end_look"),
                        link={"moves_not_answered": sum(e["kind"] == "no_answer" for e in events),
                              "status_replies_lost": sum(e["kind"] == "status_lost" for e in events)})
        self._save_marked_picture(self.run["score"]["targets"])
        if failure == "infrastructure" and self.tasks.chained:
            # PREREG 5.1 ("excluded and re-run"): a chained set can't run it again -- the next task starts where this
            # one left the cubes -- so it is kept, marked and left out of the counts (it was counted as the robot's
            # fail, in the unseen test's too -- reviewer 2, 2026-10-27)
            self.run["excluded"] = "infrastructure"
        if failure == "infrastructure" and not self.tasks.chained:     # (Simple 20: never run again, just saved)
            # PREREG 5.1: repeated -- this attempt is kept, marked, and left out of the counts
            tries = self._infra_tries.get((task.id, repeat), 0)
            if tries < INFRA_RETRIES:
                self._infra_tries[(task.id, repeat)] = tries + 1
                self.plan.append((task, repeat))
                self._plan_status.append("Waiting")
                self.run["repeated"] = True
        results.write_json(self.run_folder / "run.json", self.run)
        # the model's record -- or, if it failed part-way (Ollama timed out...), the steps it got through
        results.write_json(self.run_folder / "trace.json", out["trace"] if out.get("trace") is not None else
                           {"error": out.get("error"), "partial": True,
                            "steps": [{"tool": s.tool_name, "args": s.arguments, "result": str(s.result)[:400]}
                                      for s in steps]})
        # everything the Model tab shows for this run's prompts, in one file (model_log.html and .txt)
        header =(f"{task.id} · run {self.index + 1} of {len(self.plan)} · repeat {repeat} · "
                  f"{self.session.info.get('session_kind', '')}, round {self.session.info.get('round')}, "
                  f"{'REAL TEST' if self.session.real else 'practice'}\n“{task.prompt}”"
                  + (f"\nFirst: {' → '.join(task.before)}" if task.before else "")
                  + (f"\nStart: " + ", ".join(f"{c} on spot {s}" for c, s in task.arrangement["spots"].items())
                     if task.arrangement and "spots" in task.arrangement else ""))
        model_log.write_model_log(self.run_folder, traces, header=header,
                                  steps=None if out.get("trace") is not None else
                                  [{"tool": s.tool_name, "args": s.arguments, "result": str(s.result)[:400]}
                                   for s in steps])
        if pick_rows:
            _write_csv(self.run_folder / "picks.csv", list(pick_rows[0]), [list(r.values()) for r in pick_rows])
        if motion["moves"]:                       # every move: where, how far, how long, how fast, the joints
            _write_csv(self.run_folder / "moves.csv", details.MOVE_COLUMNS, details.move_rows(motion))
            _write_csv(self.run_folder / "gripper.csv", details.GRIPPER_COLUMNS, details.gripper_rows(motion))
        else:                                     # (no record of the moves: the robot's own reports of them)
            _write_csv(self.run_folder / "moves.csv", ["t", "x", "y", "z", "r", "ok", "error"],
                       [[m["t"], m["target"]["x"], m["target"]["y"], m["target"]["z"], m["target"]["r"], m.get("ok"),
                         m.get("error", "")] for m in moves])
        _write_csv(self.run_folder / "refused_steps.csv", ["step", "t_end", "tool", "args", "why"],
                   [[r["step"], r["t_end"], r["tool"], json.dumps(r["args"]), r["why"]] for r in refused_steps])
        _write_csv(self.run_folder / "alarms.csv", ["t", "codes", "phases", "J1", "J2", "J3", "J4", "target",
                                                    "auto_cleared", "leftover"],
                   [[a["t"], " ".join(a["codes"]), " ".join(a["phases"]), *(list(a["joints"]) + [""] * 4)[:4],
                     json.dumps(a.get("target")), a["auto_cleared"], a.get("leftover")] for a in alarms])
        try:
            self.run["report"] = report.write_run_report(self.run_folder, self.run, self.session.info)
        except Exception as exc:  # noqa: BLE001 - the run itself is saved; a report that fails is said, not fatal
            logger.warning("Couldn't write the run's report: %s", exc, exc_info=True)
            self._log(f"The run is saved, but its report couldn't be written: {exc}")
        self.session.record({"run": self.run_folder.name, "passed": result.passed, "unassisted": unassisted,
                             "outcome": verdict_word, "catastrophic": catastrophic,
                             "failure": failure, "observer": observer["verdict"],
                             "ran_by_itself": bool(self.run.get("unattended")),
                             "score_100": credit["score"], "band": credit["band"],
                             "refused_steps": [f"{r['tool']}: {r['why'][:200]}" for r in refused_steps],
                             "proceeded_by_you": proceeded})
        for r in refused_steps:                    # (the run log too: each refusal, why)
            self._log(f"Refused step {r['step']} ({r['tool']}): {r['why'][:200]}" if not self._hide_prompts() else
                      f"Refused step {r['step']} ({r['tool']})")
        skipped = observer["verdict"] == "skipped"
        agree = skipped or (observer["verdict"] == "pass") == result.passed
        errs =", ".join(f"{e:.1f} mm" for e in result.position_errors) or "-"
        angs = ", ".join(f"{e:.1f}°" for e in result.angle_errors) or "-"
        self._reveal_details = "; ".join(t.detail for t in result.targets)   # (hidden for a test, as the prompt is)
        self.reveal.setText(
            f"Watcher: {verdict_word}{' · CATASTROPHIC: ' + '; '.join(catastrophic) if catastrophic else ''}"
            f"{'' if unassisted or not result.passed else ' (but not unassisted)'} · score {credit['score']}/100 "
            f"({credit['band']}) · errors {errs} · angles {angs}"
            f"{' · failure: ' + failure if failure else ''}"
            f"{' · collateral: ' + '; '.join(result.collateral) if result.collateral else ''}"
            f"{' · missing: ' + ', '.join(result.missing) if result.missing else ''}"
            f"{f' · refused steps: {len(refused_steps)} (refused_steps.csv)' if refused_steps else ''}"
            f"\n{self._shown_details()}"
            f"\n{'No verdict given: the twin scored itself.' if skipped else 'Agrees with you.' if agree else 'DISAGREES with your verdict (flagged for review).'}"
            + ("\nNot the robot's fault (Ollama, the camera or the PC): this run is done again at the end of the "
               "session and this attempt isn't counted." if self.run.get("repeated") else
               "\nNot the robot's fault (Ollama, the camera or the PC): saved, and not counted (a chained set goes on "
               "from where it left the cubes)." if self.run.get("excluded") else ""))
        self._known = getattr(self, "_known", {})
        for c in end:                              # (where each cube ended, a tower's hidden ones too: the next task's)
            self._known[c.label] = c
        self._set_plan_status(self.index, verdict_word.capitalize() + f" · {credit['score']} {credit['band']}"
                              + (" (infrastructure: runs again)" if self.run.get("repeated") else
                                 " (infrastructure: not counted)" if self.run.get("excluded") else ""))
        self._set_state("reveal")

    # ---- after the score: Save or Discard ---------------------------------------------------------------------------
    # ---- Run by itself (the twin only) -----------------------------------------------------------------------------
    def _auto_toggled(self, on: bool) -> None:
        if on:
            self._task_shown = time.monotonic()        # (the time for the table to be READY counts from now)
            self._scene_asked = self._scene_decided = False      # (a chained set: looked at afresh, by itself)
            QTimer.singleShot(0, self._auto_step)

    def _auto_on(self) -> bool:
        """Run by itself is on -- or Proceed to next task was pressed (this run only: saved, then the next)."""
        return (self.auto_run.isChecked() or getattr(self, "_push", False)) and self.session is not None and (
            self._where() == "twin" or self._simple())

    def _proceed_next(self) -> None:
        """Proceed to next task (Simple 20): this task ends now and everything of it is saved, then the next one.
        Not started yet: skipped, and logged. Running: its prompt is ended (as the time limit ends it), the arm parks,
        the end is looked at, and it is scored and saved. Waiting for a verdict or for Save: saved as it is."""
        if self.session is None or not self._simple() or not 0 <= self.index < len(self.plan):
            return
        if self.state == "setup":
            self._countdown = None
            self._skip_task("you pressed Proceed to next task before it started", by="you (Proceed to next task)")
            return
        self._push = True
        self.proceed_btn.setEnabled(False)
        self.session.record({"proceed_pressed": self.plan[self.index][0].id, "state": self.state})
        if self.state == "running":
            self._proceeded = True
            self._stop.set()
            cancel = getattr(self.ctx.agent, "cancel", None)
            if cancel is not None:
                cancel()
            self._log("Proceed to next task: this task is ended; it is scored and saved, then the next one.")
            return                                 # (the run ends -> the verdict -> _auto_step saves and goes on)
        QTimer.singleShot(0, self._auto_step)

    def _countdown_tick(self, token: int) -> None:
        """Simple 20 on the Dobot: a second of the countdown before a run starts by itself; at 0 it starts -- if the
        table is still READY and nobody has stopped it (E-STOP, Run by itself unticked)."""
        if token != self._token or self.state != "setup" or getattr(self, "_countdown", None) is None:
            return
        if not self._auto_on() or not self.run_btn.isEnabled():
            self._countdown = None
            return
        self._countdown -= 1
        if self._countdown > 0:
            QTimer.singleShot(1000, lambda: self._countdown_tick(token))
            return
        self._countdown = None
        self._start_run()

    def _study_cube_sizes(self, on: bool) -> None:
        """The twin, during a session: the app's camera takes a cube measured near the study's size to be that size, as
        it does live (config.yaml vision: known_sizes_mm) -- the twin's camera read a tower's top cube as 28 mm, too
        wide for the gripper, so no tower could be taken apart in the twin (2026-10-24), while the Dobot could. The
        demo's own scene (cubes of its own sizes) gets its setting back after."""
        if self.ctx.twin_world is None:
            return
        builders = {id(b): b for b in (getattr(self.ctx.executor, "scene_builder", None), self.ctx.scene_builder)
                    if b is not None and hasattr(b, "known_sizes")}
        for builder in builders.values():
            if on and not hasattr(builder, "_known_before"):
                builder._known_before = dict(builder.known_sizes)
                builder.known_sizes = {**builder.known_sizes, "cube": float(self.tasks.cube_size_mm)}
            elif hasattr(builder, "_known_before"):
                builder.known_sizes = builder._known_before
                del builder._known_before

    def _park(self, second: bool = False) -> dict:
        """The arm to where it waits out of the camera's way (`second`: the same on the other side, y mirrored, to see
        what the first hid), and whether it got there -- from its own reported position. Off the window's thread."""
        from app.hardware.interfaces import Pose
        pose = self.ctx.park_pose or getattr(self.ctx.executor, "look_pose", None)
        if pose is None:
            return {"pose": None, "reached": None, "why": "no park pose"}
        pose = pose if isinstance(pose, Pose) else Pose(*pose)
        if second:
            pose = Pose(pose.x, -pose.y, pose.z, -pose.r)
        out = {"pose": [round(pose.x, 1), round(pose.y, 1), round(pose.z, 1)], "second": second}
        try:
            now = self.ctx.robot.get_pose()
            if math.hypot(now.x - pose.x, now.y - pose.y) > SWING_MM:   # (a swing across: lifted first, over the tray)
                zmax = float(((self.ctx.config or {}).get("robot", {}).get("workspace_bounds") or {})
                             .get("z", [None, pose.z + SWING_LIFT_MM])[1])
                high = min(max(pose.z, now.z) + SWING_LIFT_MM, zmax)
                self.ctx.robot.move_to(Pose(now.x, now.y, high, now.r))
                self.ctx.robot.move_to(Pose(pose.x, pose.y, high, pose.r))
            self.ctx.robot.move_to(pose)
            now = self.ctx.robot.get_pose()
            off = math.dist((now.x, now.y, now.z), (pose.x, pose.y, pose.z))
            out.update(reached=off <= SECOND_POSE_MM, off_mm=round(off, 1))
        except Exception as exc:  # noqa: BLE001 - said in the record: "couldn't park", not "a cube is missing"
            out.update(reached=False, why=f"{type(exc).__name__}: {exc}")
        return out

    def _scene_look(self) -> list:
        """A chained set's look before a task (off the window's thread): the arm parked, SCENE_LOOKS pictures; if fewer
        cubes are there than the session has (a tower's hidden ones counted), the arm to the second pose and
        SCENE_LOOKS more. The twin: its exact positions. What it was like is kept for _scene_decide."""
        from watcher.arrange import infer_hidden, merge_scene
        info: dict = {"looks": 0, "arm_positions": 1, "parks": []}
        live = self.ctx.twin_world is None
        # the arm moves only when the watcher runs by itself, nothing else holds it and E-STOP isn't on (by hand it
        # only looks: a person may be at the table)
        move = (live and self._auto_on() and not self.ctx.held()
                and not getattr(self.ctx.robot, "_estopped", False))
        if move:
            info["parks"].append(self._park())
        seen = self._look(looks=SCENE_LOOKS)
        info["looks"] = SCENE_LOOKS if live else 1
        expected = self._session_cubes()
        if move and len(infer_hidden(seen, getattr(self, "_known", {}), self.tasks.cube_size_mm)[0]) < len(expected):
            info["parks"].append(self._park(second=True))
            seen = merge_scene(seen, self._look(looks=SCENE_LOOKS))
            info["looks"] += SCENE_LOOKS
            info["arm_positions"] = 2
        self._scene_info = info
        return seen

    def _session_cubes(self) -> list[str]:
        """The session's cubes (Simple 20: its starting layout's), by name."""
        if self.tasks.start_layout:
            return [f"{c} cube" for c in self.tasks.start_layout]
        task = self.plan[self.index][0] if 0 <= self.index < len(self.plan) else None
        return [c.label for c in task.start] if task is not None else []

    def _scene_decide(self, task, seen: list) -> None:
        """A chained set's table before a task (V4.2), as the camera saw it: the cubes a tower hides worked out, the
        start condition and each part's possibility recorded, and -- by itself -- the task started with the cubes there:
        skipped only if none of its own cubes can be seen (no cube at all for EMPTY_TASKS_END tasks in a row ends the
        session). Nothing is sorted and nothing is waited for."""
        from watcher.arrange import infer_hidden, scene_report
        if self._auto_on() and getattr(self, "_scene_decided", False):
            return                                 # (once a task, by itself)
        size = self.tasks.cube_size_mm
        self._known = getattr(self, "_known", {})
        cubes, hidden = infer_hidden(seen, self._known, size)
        report_ = scene_report(task, self.tasks, cubes, self._session_cubes(), hidden)
        info = dict(getattr(self, "_scene_info", {}) or {})
        report_.update(looks=info.get("looks", 1), arm_positions=info.get("arm_positions", 1),
                       parks=info.get("parks", []))
        self._scene = report_
        self._checks = getattr(self, "_checks", 0) + 1
        looked = f"looked {report_['looks']} time(s) from {report_['arm_positions']} arm position(s)"
        for label, top in hidden.items():
            self._known[label] = next(c for c in cubes if c.label == label)
        for c in seen:
            self._known[c.label] = c
        if self._auto_on():
            self._scene_decided = True
            self._seen_start = cubes               # (a skipped task's record: the scene as it was)
            if report_["empty"]:
                self._empty_in_row += 1
                self._empty_ids.append(task.id)
                if self._empty_in_row >= EMPTY_TASKS_END:
                    self._end_reason = (f"no cube seen for {EMPTY_TASKS_END} tasks in a row "
                                        f"({', '.join(self._empty_ids[-EMPTY_TASKS_END:])})")
                self._skip_task(f"no cube can be seen ({looked})")
                return
            self._empty_in_row, self._empty_ids = 0, []
            if not report_["can_start"]:
                self._skip_task(f"none of its cubes ({', '.join(report_['own_cubes'])}) can be seen ({looked})")
                return
        lines = [f"The table as the last task left it: {', '.join(report_['condition'])}."]
        lines += [f"Seen: " + ", ".join(f"{c.label} ({c.x:.0f}, {c.y:.0f})" + (f" {c.level} up" if c.level > 1 else "")
                                        for c in cubes)] if cubes else ["No cube seen."]
        if hidden:
            lines.append("Under a tower: " + ", ".join(f"the {h} under the {t}" for h, t in hidden.items()))
        if report_["missing"]:
            lines.append(f"Can't be seen ({looked}): {', '.join(report_['missing'])}")
        hide = self._hide_prompts()
        lines += [f"Part {p['part']}: impossible from here" + ("" if hide else f" ({p['kind']}), {p['why']}")
                  for p in report_["parts"] if not p["possible"]]
        stopped = bool(getattr(self.ctx.robot, "_estopped", False))
        if stopped:
            lines.append("E-STOP is on: reset it in the main window (Manual tab, 'Reset E-STOP') first")
        ready = report_["can_start"] and not stopped
        if ready and getattr(self, "_ready_at", None) is None:
            self._ready_at = time.monotonic()
        counting = getattr(self, "_countdown", None)
        lines.append(f"READY: starting by itself in {counting} s (E-STOP, or untick Run by itself, to stop it)"
                     if ready and counting is not None else "READY: press Start run" if ready else "")
        self.setup_text.setPlainText("\n".join(lines))
        self._seen_start = cubes
        self._setup_status = [{"cube": c.label, "ok": True, "say": f"{c.label}: seen at ({c.x:.0f}, {c.y:.0f})"}
                              for c in cubes]
        self._not_ready = "" if ready else "none of its cubes can be seen"
        self.video.set_marks([])
        self._outlines_3d = []
        self.run_btn.setEnabled(ready or (self._override_on() and not stopped))
        if ready:
            QTimer.singleShot(0, self._auto_step)

    def _cube_size(self) -> float:
        """The study's cube size now (the app's Settings > Cubes: config.yaml vision: known_sizes_mm: cube)."""
        return cube_mm(self.ctx.config)

    def _time_limit(self) -> Optional[float]:
        """A task's time limit: the task file's (Simple 20's 10 minutes, the unseen test's 5 -- PREREG 3), and for a
        chained set without one CHAINED_TIME_LIMIT_S -- the same for every version, the twin and the Dobot."""
        limit = self.tasks.time_limit_s if self.tasks is not None else None
        if self.tasks is not None and self.tasks.chained:
            return limit or CHAINED_TIME_LIMIT_S
        return limit

    def _skip_task(self, why: str, by: str = "the watcher", infrastructure: bool = False) -> None:
        """Simple 20: this task can't start from the table as it is -- skipped, said, logged (the session's index, its
        plan) and saved as a run of its own (Run<n>, SKIPPED: not a pass or a fail, counted apart), and the next task
        tried."""
        if self.session is None or not 0 <= self.index < len(self.plan):
            return
        task, repeat = self.plan[self.index]
        self.session.record({"skipped": task.id, "repeat": repeat, "why": why,
                             "seen": [c.__dict__ for c in getattr(self, "_seen_start", []) or []]})
        self._log(f"{task.id} skipped: {why}")
        self._set_plan_status(self.index, "Skipped (table not ready)")
        try:
            self._save_skipped(why, by, infrastructure)
        except Exception as exc:  # noqa: BLE001 - the skip is in the index all the same
            logger.warning("Couldn't save the skipped task as a run: %s", exc, exc_info=True)
            self._log(f"The skip is logged, but couldn't be saved as a run: {exc}")
        self._next()

    def _save_skipped(self, why: str, by: str, infrastructure: bool = False) -> None:
        """A skipped task saved like a run, under the next free number: why, who skipped it and after how long, what the
        camera saw (and a picture of the table), the task before it and where it left the cubes, and the session's
        set-out -- so the reports, and Claude, see the tasks that never started and what left the table so."""
        task, repeat = self.plan[self.index]
        seen = list(getattr(self, "_seen_start", []) or [])
        if not seen and not self._busy and not (getattr(self, "_scene", None) or {}).get("empty"):
            # (skipped before the table was looked at: one look now)
            try:
                seen = self._look(looks=1)
            except Exception as exc:  # noqa: BLE001 - saved without it
                logger.warning("Couldn't look at the table for the skipped task: %s", exc)
        waited = round(time.monotonic() - getattr(self, "_task_shown", time.monotonic()), 1)
        self.run_folder = self.session.run_folder(task.id, repeat)
        if self._busy:                             # (a table check or the set-out is using the camera and the arm)
            self.run["picture_skipped"] = "the camera was busy (a table check or the set-out) when it was skipped"
        else:
            try:
                self._save_picture("start", depth=False)
            except Exception as exc:  # noqa: BLE001 - a missing picture is noted, not the end of the skip
                logger.warning("Couldn't save the skipped task's picture: %s", exc)
        set_out = None
        try:
            set_out = self._set_out_record()
        except Exception as exc:  # noqa: BLE001 - saved without it
            logger.warning("Couldn't read the set-out for the skipped task: %s", exc)
        try:
            expected = self._expected_start(task, seen)
        except Exception as exc:  # noqa: BLE001 - the skip is saved without it
            logger.warning("Couldn't work out the task's expected start: %s", exc)
            expected = []
        self.run.update(
            passed=None, unassisted_pass=False, failure="infrastructure" if infrastructure else None,
            outcome="SKIPPED", start_seen=[c.__dict__ for c in seen],
            setup=getattr(self, "_setup_status", []), started_at=time.strftime("%Y-%m-%d %H:%M:%S"),
            session_run=self.index + 1, time_limit_s=self._time_limit(),
            start_condition=(getattr(self, "_scene", None) or {}).get("condition"),
            scene=getattr(self, "_scene", None),
            setup_effort={"seconds": waited, "checks": getattr(self, "_checks", 0), "ready_after_s": None},
            skipped={"why": why, "by": by, "waited_s": waited, "table_checks": getattr(self, "_checks", 0),
                     "seen": [c.__dict__ for c in seen], "expected": expected, "task_before": self._task_before(),
                     "set_out": set_out})
        results.write_json(self.run_folder / "run.json", self.run)
        try:                                       # (saved whatever happens to its report: never left in _pending)
            self.run["report"] = report.write_run_report(self.run_folder, self.run, self.session.info)
        except Exception as exc:  # noqa: BLE001 - Rebuild reports… makes it
            logger.warning("Couldn't write the skipped task's report: %s", exc, exc_info=True)
        self._keep_run(ask=False)

    def _set_out_record(self) -> Optional[dict]:
        """The session's set-out, for a skipped task: done or not, why, what it moved, the steps refused -- every
        step, each with what came back, when it failed. A set-out still under way: said so."""
        if getattr(self, "_setting_out", False):
            return {"ok": None, "why": "still setting the cubes out when the task was skipped"}
        path = self.session.folder / "set_out.json"
        if not path.exists():
            return None
        from watcher.setout import summary as set_out_summary
        done = json.loads(path.read_text(encoding="utf-8"))
        steps = [{"tool": s.get("tool"), "args": s.get("args"), "result": str(s.get("result", ""))[:300]}
                 for s in done.get("steps") or []]
        out = {"ok": done.get("ok"), "why": done.get("why"), "moves": set_out_summary(done.get("steps") or []),
               "refused": [s for s in steps if s["result"].startswith("ERROR")]}
        if not done.get("ok"):                     # (it failed: every step it took, each with what came back)
            out["steps"] = steps
        return out

    def _expected_start(self, task, seen) -> list[dict]:
        """What this task needed vs what was there: each cube where it would be at this task's start had every task
        before gone as asked (Simple 20's chain), where the camera saw it, and how far apart."""
        if not self.tasks.chained:
            return []
        from watcher.arrange import chain_start
        from watcher.tasks import with_hidden
        wanted = chain_start(self.tasks, task.id)
        found = with_hidden(list(seen), [task.tower], self.tasks.cube_size_mm) if task.tower else list(seen)
        return [{"cube": want.label, "wanted": [round(want.x, 1), round(want.y, 1)], "wanted_level": want.level,
                 "seen": [round(got.x, 1), round(got.y, 1)] if got else None, "seen_level": got.level if got else None,
                 "off_mm": round(math.hypot(got.x - want.x, got.y - want.y), 1) if got else None}
                for want, got in zip(wanted, match(wanted, found))]

    def _task_before(self) -> Optional[dict]:
        """The run saved last in this sitting -- the task that left the table as it is: which, how it ended and where
        it left the cubes; if it was skipped too, the last task that did run (the chain back to the cause). None for
        the session's first task."""
        rows = [r for r in self._saved_this_sitting() if r.get("session_run") is not None]
        if not rows:
            return None

        def brief(r: dict) -> dict:
            return {"task": r.get("task"), "run": r.get("saved_as"), "result": report.pass_word(r),
                    "failure": r.get("failure"), "score_100": (r.get("credit") or {}).get("score"),
                    "ended": r.get("end_seen") or (r.get("skipped") or {}).get("seen") or []}
        last = max(rows, key=lambda r: r["session_run"])
        out = brief(last)
        if last.get("skipped"):
            ran = [r for r in rows if not r.get("skipped")]
            out["last_ran"] = brief(max(ran, key=lambda r: r["session_run"])) if ran else None
        return out

    def _auto_pause(self, why: str) -> None:
        """Run by itself stops: you take over from here (tick it again to go on)."""
        if self.auto_run.isChecked():
            self.auto_run.setChecked(False)
            self._pause_why = why
            self._log(f"Run by itself paused: {why}. Carry on by hand, or tick Run by itself again.")

    def _auto_step(self) -> None:
        """Run by itself: the next step of the current run, whatever it is waiting for -- Start run once the table is
        READY, the verdict (Skip: the twin scores itself), then Save under the next free number and the next run."""
        if not self._auto_on():
            return
        if self.state == "setup":
            if not self.run_btn.isEnabled():
                return
            if self.ctx.twin_world is None and self.tasks.chained:       # (the real arm: a countdown first)
                if getattr(self, "_countdown", None) is None:
                    self._countdown = SIMPLE_COUNTDOWN_S
                    token = self._token
                    QTimer.singleShot(1000, lambda: self._countdown_tick(token))
                return
            self._start_run()
        elif self.state == "verdict":
            with self._lock:
                stopped = any(e.get("kind") == "estop" for e in self.events)
            pushed = getattr(self, "_push", False) and not self.auto_run.isChecked()
            if stopped and not getattr(self, "_push", False):   # (someone stepped in: their verdict, not "ran by itself")
                self._auto_pause("E-STOP was pressed during the run: give the verdict yourself")
                return
            if self._arm_needs_person() and not getattr(self, "_push", False):
                self._auto_pause("the arm needs a person: see to it, then give the verdict yourself")
                return
            self.run["unattended"] = not pushed
            self.note.setText("ended with Proceed to next task" if pushed else AUTO_NOTE)
            self.unsure.setChecked(False)
            self._verdict("skipped")
        elif self.state == "reveal":
            if self._broken:
                self._auto_pause("this run couldn't be scored or saved (Discard and run again, or End session)")
                return
            self._auto_infra = self._auto_infra + 1 if self.run.get("failure") == "infrastructure" else 0
            if self._keep_run(ask=False):
                if self._auto_infra >= AUTO_INFRA_IN_ROW and not self.tasks.chained:
                    self._auto_pause(f"{self._auto_infra} runs in a row failed outside the robot (Ollama, the camera "
                                     "or the PC): check them")
                self._next()

    def _save_and_next(self) -> None:
        """Save ▶ next: the run is kept under the tag you give it (TR-07_Run1), then the next run."""
        if self.state != "reveal" or self.session is None:
            return
        if self._keep_run(ask=True):
            self._next()

    def _ask_save(self, task_id: str, suggested: str, saved: list[dict]) -> Optional[dict]:
        """The Save dialog: the task's runs saved so far, the run number (or your own tag), and -- a number already
        saved -- replacing it, with why. {"tag", "replace", "reason"}, or None if cancelled (a test answers itself)."""
        dialog = SaveRunDialog(self, task_id, suggested, saved, self.session.taken, self.session.real)
        return dialog.answer() if dialog.exec() == QDialog.DialogCode.Accepted else None

    def _keep_run(self, ask: bool = True) -> bool:
        """The run kept: under the number (Run<n>) or tag you choose (or, not asked, the next free Run<n>), moved from
        _raw_data\\_pending to _raw_data\\<task>_<tag>, its own .md and HTML page written in User_Saved_<kind>, and
        the kind's reports (FULL_REPORT.md / .html, full_report.json, results.xlsx) remade. A number already saved is
        only used again if you choose to replace that run: the old one goes, whole, to Recycle_Bin (a real one with a
        reason, in deletions_log.txt). False if you cancelled."""
        path = self.run_folder / "run.json" if self.run_folder is not None else None
        if path is None or not path.exists() or self.run.get("saved"):
            return True
        task, _ = self.plan[self.index]
        tag, replace, reason = self.session.next_tag(task.id), False, ""
        while True:
            if ask:
                answer = self._ask_save(task.id, tag, self.session.saved_runs(task.id))
                if answer is None:
                    return False
                tag, replace, reason = answer["tag"], bool(answer.get("replace")), answer.get("reason", "") or ""
            name = results.run_name(task.id, tag)
            if not self.session.taken(name):
                replace = False
                break
            if ask and replace and (reason.strip() or not self.session.real):
                break
            suggested = self.session.next_tag(task.id)
            if ask:
                QMessageBox.information(self, "Save", f"{name} is already saved here. Choose another number (the "
                                        f"next free one is {suggested}), or replace it, saying why.")
            tag = suggested
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = dict(self.run)
        data.update(saved=True, tag=tag, saved_as=name, saved_at=time.strftime("%Y-%m-%d %H:%M:%S"))
        if replace:
            data.update(replaced_earlier={"reason": reason.strip() or "replaced by a new run"})
        results.write_json(path, data)
        try:
            final = self.session.save_run(self.run_folder, task.id, tag, replace=replace, reason=reason)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Save", f"Couldn't save the run: {exc}")
            return False
        self.run.update(saved=True, tag=tag, saved_as=name)
        self.run_folder = final
        words = f"saved {tag}" + (" (replaced the earlier one)" if replace else "")
        self._set_plan_status(self.index, f"{self._plan_status[self.index]} · {words}"
                              if self.index < len(self._plan_status) else words)
        if replace:
            self._log(f"The earlier {name} is in Recycle_Bin now (why.txt says why).")
        try:
            report.write_run_files(self.session.kind_folder, final)
            report.write_session_results(self.session.kind_folder)
        except Exception as exc:  # noqa: BLE001 - the run is saved; its reports can be rebuilt
            logger.warning("Couldn't write the saved run's reports: %s", exc, exc_info=True)
            self._log(f"Saved, but the reports couldn't be written: {exc} (Rebuild reports… makes them)")
        self._remake_overview(self.session.real, self.session.root)
        saved = results.saved_folder(self.session.kind_folder) / f"{name}.md"
        try:
            where = saved.relative_to(self.session.root.parent)          # (Kyozo_Link_Results\...)
        except (ValueError, AttributeError, TypeError):
            where = saved
        self._log(("Saved (PRACTICE: the Practice session switch is on): " if not self.session.real else "Saved: ")
                  + f"{where} (and its HTML page)")
        return True

    def _discard_and_again(self) -> None:
        """Discard and run again: the run goes, whole, to Recycle_Bin (a real one with a reason, in
        deletions_log.txt), the session's files are made again without it, and the same task runs next, from the same
        start."""
        if self.state != "reveal" or self.session is None or self.run_folder is None:
            return
        reason = ""
        if self.session.real:
            reason, ok = QInputDialog.getText(self, "Discard this run",
                                              "Why is it thrown away? (It is kept, whole, in Recycle_Bin; a real "
                                              "run's discard is noted, with this reason, in deletions_log.txt; the "
                                              "paper reports discarded runs.)")
            if not ok:
                return
            if not reason.strip():
                QMessageBox.warning(self, "Discard", "A real run is only discarded with a reason (it goes in "
                                    "deletions_log.txt).")
                return
        task, repeat = self.plan[self.index]
        name = self.run_folder.name
        try:
            where = self.session.discard_run(self.run_folder, reason)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Discard", f"Couldn't discard the run: {exc}")
            return
        if self.run.get("repeated"):               # (its re-run at the end isn't needed: it runs again now)
            key = (task.id, repeat)
            self._infra_tries[key] = max(0, self._infra_tries.get(key, 0) - 1)
            for i in range(len(self.plan) - 1, self.index, -1):
                if self.plan[i][0].id == task.id and self.plan[i][1] == repeat:
                    del self.plan[i]
                    if i < len(self._plan_status):
                        del self._plan_status[i]
                    break
        self._set_plan_status(self.index, "Discarded")
        if self.tasks.chained:                     # (the next task "from the same start": as this one started)
            self._known = dict(getattr(self, "_known_at_start", None) or getattr(self, "_known", {}))
            scene = getattr(self, "_scene_at_start", None)
            if scene is not None and self.ctx.twin_world is not None:
                try:
                    self.ctx.twin_world.switch_scenario(scene["name"], scene)
                except Exception as exc:  # noqa: BLE001
                    self._log(f"Couldn't set the cubes back as the run started: {exc}")
        self.plan.insert(self.index + 1, (task, repeat))
        self._plan_status.insert(self.index + 1, "Waiting")
        self.run_folder = None
        self._log(f"Discarded {name} (kept in {where.relative_to(self.session.root)}): {task.id} runs again.")
        self._next()

    # ---- other buttons ---------------------------------------------------------------------------------------------
    def _build_claude_input(self, round_no: int, real: bool) -> Path:
        from watcher import handoff
        sessions = handoff.study_sessions(round_no, real, root=self.ctx.results_root)
        return handoff.build(sessions, round_no, VERSIONS[round_no], root=self.ctx.results_root)

    # ---- the unseen test set ----------------------------------------------------------------------------------------
    def _make_test_tasks(self) -> None:
        """Make test tasks…: your secret seed (typed hidden, twice), then study/make_test_tasks.py runs in a process
        of its own (the twin check can't disturb the app), the seed passed on its input -- never a command line or a
        log. Its progress (task ids only) goes in the run log."""
        if self.session is not None or self._testgen is not None:
            return
        target = Path(self.ctx.results_root) / results.TEST_TASKS / "test.yaml"
        replace = target.exists()
        if replace and QMessageBox.question(
                self, "Make test tasks", "A test set is there already. Make a new one? The old one is kept beside it "
                "as test_OLD_<date>.yaml.") != QMessageBox.StandardButton.Yes:
            return
        dialog = TestSeedDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        from PyQt6.QtCore import QProcess
        import sys
        process = QProcess(self)
        process.setWorkingDirectory(str(observe.PROJECT_ROOT))
        process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        args = ["-u", str(observe.PROJECT_ROOT / "study" / "make_test_tasks.py"), "--seed-stdin",   # (-u: live)
                "--root", str(self.ctx.results_root)]
        args += ["--replace"] if replace else []
        args += [] if dialog.twin.isChecked() else ["--no-twin-check"]
        process.readyReadStandardOutput.connect(lambda: self._testgen_output(process))
        process.finished.connect(lambda code, _status: self._testgen_done(process, code))
        # (it couldn't even start: said, and the button freed -- "finished" never comes then)
        process.errorOccurred.connect(lambda error: self._testgen_done(process, -1)
                                      if error == QProcess.ProcessError.FailedToStart else None)
        self._testgen_ready, self._testgen_step, self._testgen_stopped = 0, 0, False
        self._testgen_started = time.monotonic()
        self._testgen = process
        self.testgen_now.setText("Starting…")
        self.testgen_left.setText("")
        self.testgen_panel.show()
        self._show_testgen_progress()
        self._testgen_clock.start(1000)
        self._set_state(self.state)
        self._refresh_plan()                               # (its Make button greyed out while it runs)
        self.left_tabs.setCurrentIndex(1)                  # (the progress bar is on the Session plan tab)
        self._log("Making the test tasks" + (", each checked in the twin (this takes a while)" if
                                             dialog.twin.isChecked() else "") + "…")
        process.start(sys.executable, args)
        process.write((dialog.seed() + "\n").encode("utf-8"))
        process.closeWriteChannel()

    def _testgen_output(self, process) -> None:
        text = bytes(process.readAllStandardOutput()).decode("utf-8", "replace")
        for line in text.splitlines():
            if line.strip() and not line.startswith(("pybullet build", "load extensions", "SDK_VERSION")):
                self._log("  " + line.strip())
                task = line.split(":")[0].strip()           # ("T-07 (level 2)": ids and levels only)
                if "checking in the twin, start" in line:     # ("..., start 2 of 2")
                    start = 2 if "start 2" in line else 1
                    self._testgen_step = start - 1
                    self.testgen_now.setText(f"Checking {task} in the twin" + ("" if " of 1" in line else
                                             f", start {start} of 2"))     # (the chained set: once a task)
                elif ": ready" in line:                       # ("T-07 (level 2): ready, ..."): one more done
                    self._testgen_ready = getattr(self, "_testgen_ready", 0) + 1
                    self._testgen_step = 0
                    self.testgen_now.setText(f"{task} ready")
                    self._refresh_plan()
                elif "from T-01" in line:                     # (a chain begun again: none of it ready yet)
                    self._testgen_ready, self._testgen_step = 0, 0
                    self.testgen_now.setText("Drawing the chain again from the start")
                elif "drawn again" in line:
                    self._testgen_step = 0
                    self.testgen_now.setText(f"{task}: the twin couldn't do one start, so it is drawn again")
                self._show_testgen_progress()

    def _testgen_done(self, process, code: int) -> None:
        if self._testgen is not process:              # (already handled: a failed start, then its finish)
            return
        self._testgen_output(process)
        self._testgen = None
        self._testgen_clock.stop()
        self.testgen_panel.hide()
        if code == -1:
            self._log("  The test-task maker couldn't start (Python not found?): " + process.errorString())
        self._set_state(self.state)
        self._preview_plan()
        if code == 0:
            QMessageBox.information(self, "Make test tasks", "The test tasks are made and checked. Read them with "
                                    "Test tasks… > Open the test tasks. Keep your seed somewhere private.")
        elif getattr(self, "_testgen_stopped", False):
            self._log("  Stopped: nothing was written; the test set there before (if any) is as it was.")
            QMessageBox.information(self, "Make test tasks", "Stopped. Nothing was written: the test set there "
                                    "before (if any) is as it was.")
        else:
            QMessageBox.warning(self, "Make test tasks", "The test tasks weren't made: the run log says why.")

    def _open_test_tasks(self) -> None:
        """The test set as a page to read (test_tasks.html), or test.yaml itself if it was written by hand."""
        import os
        folder = Path(self.ctx.results_root) / results.TEST_TASKS
        page = folder / "test_tasks.html"
        path = page if page.exists() else folder / "test.yaml"
        if not path.exists():
            QMessageBox.information(self, "Test tasks", "There is no test set yet: Test tasks… > Make test tasks…")
            return
        try:
            os.startfile(str(path))                                      # noqa: S606 (Windows)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.information(self, "Test tasks", f"It is {path}\n({exc})")

    def _make_claude_input(self) -> None:
        round_no = self.round_box.currentData()
        real = self.real.isChecked()
        if round_no not in results.STUDIES:
            QMessageBox.information(self, "Claude's input", f"Choose a study, 1 to {results.MAX_STUDIES}.")
            return
        try:
            package = self._build_claude_input(round_no, real)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Claude's input", f"Couldn't make it: {exc}")
            return
        QMessageBox.information(self, "Claude's input",
                                f"Made: {package}\n(and {package.name}.zip next to it)\n\nStart a new Claude session "
                                f"and say: Read {package / 'START_HERE.md'} and do study {round_no}.")

    def _estop(self) -> None:
        self._stop.set()                           # (first: the main window's E-STOP waits on a message box)
        self._auto_pause("E-STOP was pressed")
        running = self.state == "running"
        if running:
            # the model's run ends too (the arm already refuses to move): otherwise it goes on asking Qwen, the run
            # stays "running" and the window can't be closed. The stop is recorded as an intervention.
            cancel = getattr(self.ctx.agent, "cancel", None)
            if cancel is not None:
                cancel()
        self.ctx.estop()
        if running:
            self._log("E-STOP pressed: the run ends. Before the next run, reset it in the main window (Manual tab, "
                      "'Reset E-STOP').")
        else:                                      # (nothing running to end: the arm is stopped, that's all)
            self._log("E-STOP pressed: the arm is stopped. Before the next run, reset it in the main window (Manual "
                      "tab, 'Reset E-STOP').")

    def _find_paper(self) -> None:
        if self.session is not None or self._busy:
            return
        from app.vision.paper import find_paper_with
        self._log("Looking for the paper...")
        self._job("find_paper", lambda: find_paper_with(self.ctx.camera, self.ctx.scene_builder.t_cam_to_robot))

    def _paper_found(self, out) -> None:
        from app.vision.paper import paper_path, save_paper
        if isinstance(out, Exception) or out.pose is None:
            QMessageBox.warning(self, "Find the paper", "The paper wasn't found: " +
                                (str(out) if isinstance(out, Exception) else out.reason))
            return
        save_paper(paper_path(self.ctx.calibration_file), out.pose)
        advice = ("" if out.pose.well_placed() else "\n\nThat is far from where the spots were designed: the "
                  "corner outlines' turn no longer matches the arm's angle well. Place the paper again (at the "
                  "calibration's paper centre), then Find the paper.")
        QMessageBox.information(self, "Find the paper", f"Found ({out.size_mm[0]:.0f} x {out.size_mm[1]:.0f} mm): "
                                f"{out.pose.describe()}. Saved; the spots follow it.{advice}")

    def _rebuild_reports(self) -> None:
        """A session's reports made again from its saved runs (watcher/report.py): pick its folder, or a folder of
        sessions to remake them all."""
        root = Path(self.ctx.results_root)
        chosen = QFileDialog.getExistingDirectory(self, "Choose a data folder (e.g. study_1\\20_Tasks_for_Dobot), "
                                                  "or a folder above it to remake them all",
                                                  str(root if root.exists() else Path.home()))
        if not chosen:
            return
        folder = Path(chosen)
        kinds = [folder] if (folder / results.RAW).exists() else sorted(
            p.parent for p in folder.rglob(results.RAW) if p.is_dir())
        kinds += [folder] if (folder / "session.json").exists() and (folder / "runs").exists() else []
        made, failed = 0, []
        for kind in kinds:
            try:
                if (kind / results.RAW).exists():      # each saved run's own files, then the kind's reports
                    for run in report._run_folders(kind):
                        report.write_run_files(kind, run)
                report.write_session_results(kind)
                made += 1
            except Exception as exc:  # noqa: BLE001 - one bad folder doesn't stop the rest
                failed.append(f"{kind.name}: {exc}")
        for real in (True, False):                     # and both cross-study reports (Study_Overview)
            self._remake_overview(real, root)
        QMessageBox.information(self, "Rebuild reports", f"Reports made again for {made} folder(s), and the "
                                "cross-study reports (Private_never_for_Claude\\Study_Overview)."
                                + (("\n\nCouldn't: " + "; ".join(failed)) if failed else "")
                                + ("" if kinds else "\n\nNo saved runs found there."))

    def _remake_overview(self, real: bool, root: Path) -> None:
        """The cross-study report (Private_never_for_Claude\\Study_Overview: study 1 vs 2 vs 3) made again. Never in
        the way of a run: a failure is logged (in words only: it holds the unseen test's results) and Rebuild reports… makes it."""
        try:
            from watcher import overview
            overview.write_overview(real, root)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Couldn't make the cross-study report (%s)", type(exc).__name__)

    def _open_results(self) -> None:
        import os
        results.RESULTS_ROOT.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(results.RESULTS_ROOT))                   # noqa: S606 (Windows)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.information(self, "Results", f"The results are in {results.RESULTS_ROOT}\n({exc})")

    def _delete_dialog(self) -> None:
        DeleteDialog(self, root=self.ctx.results_root).exec()

    def _show_task_line(self) -> None:
        """The task line above: the run, the task and its prompt (a test's hidden unless Show test prompts is on)."""
        if self.session is None or not 0 <= self.index < len(self.plan):
            return
        task, repeat = self.plan[self.index]
        prompt = "(test prompt hidden: turn on Show test prompts in the Session plan tab)" if self._hide_prompts() else f"“{task.prompt}”" + (
            f"\nFirst: {' → '.join(task.before)}" if task.before else "")
        self.task_label.setText(f"Run {self.index + 1} of {len(self.plan)} · {task.id} (category {task.category}, "
                                f"layout {task.layout}, repeat {repeat})\n{prompt}")

    def _judge_text(self) -> str:
        """For your verdict: the task and what counts as a pass (a test's only with Show test prompts on)."""
        task, _ = self.plan[self.index]
        how = ("<b>Fail</b> if not. <b>Dropped</b>: a cube fell or was knocked over. <b>I had to help</b>: you "
               "touched anything, cleared an alarm or pressed E-STOP. Tick <b>Unsure</b> if you can't tell by eye.")
        if self._hide_prompts():
            return ("<b>The task and its pass rule are hidden</b> (an unseen test task): turn on <b>Show test "
                    "prompts</b> in the Session plan tab to see what to judge. " + how)
        return (f"<b>The task:</b> \u201c{html.escape(task.prompt)}\u201d<br><b>Pass</b> if "
                + "; and ".join(how_to_judge(task, self.tasks.rule)) + ".<br>" + how)

    def _shown_details(self) -> str:
        return HIDDEN_DETAILS if self._hide_prompts() else getattr(self, "_reveal_details", "")

    def _refresh_secret_texts(self) -> None:
        """Show test prompts switched: the task line, the judge box and the score's details follow it."""
        if self.session is None:
            return
        self._show_task_line()
        if self.judge.isVisible() and 0 <= self.index < len(self.plan):
            self.judge.setText(self._judge_text())
        details = getattr(self, "_reveal_details", "")
        if self.reveal.text() and details:
            self.reveal.setText(self.reveal.text().replace(HIDDEN_DETAILS, details) if not self._hide_prompts()
                                else self.reveal.text().replace(details, HIDDEN_DETAILS))

    def _hide_prompts(self) -> bool:
        """A test session's (or the chosen test set's) prompts stay hidden unless Show test prompts is on."""
        test = (self.session.info.get("set") if self.session is not None else self.set_box.currentData()) == "test"
        return test and not self.show_prompts.isChecked()

    def closeEvent(self, event) -> None:   # noqa: N802 (Qt)
        if self.session is not None:
            if self.state in ("running", "verdict"):
                QMessageBox.warning(self, "Watcher", _CANT_CLOSE[self.state])
                event.ignore()
                return
            self.end_session("window closed")
        self.show_prompts.setChecked(False)        # (hidden again next time the window opens)
        self._put_back_demo_scene()
        super().closeEvent(event)


_CANT_CLOSE = {
    "running": "A run is going: wait for it to finish, or press E-STOP to end it now. Then give your verdict, and "
               "you can close the window.",
    "verdict": "This run is waiting for your verdict: press Pass, Fail, Dropped or I had to help (the run is saved "
               "then), and you can close the window.",
}


def _scene_as_it_is(world) -> dict:
    """The demo's scene as it stands now -- every object where it is, turned as it is -- to set back out later."""
    from app.twin.world import TRAY_FLOOR_MM
    objects = []
    for item in world.snapshot():
        x, y, z = item["pos"]
        if item["shape"] == "tray":
            z -= TRAY_FLOOR_MM / 2.0            # (a tray's body sits half its floor above where it was put)
        objects.append({"id": item["id"], "label": item["label"], "shape": item["shape"], "size_mm": list(item["size"]),
                        "position_mm": [x, y, z], "yaw_deg": item["yaw"], "color_rgba": [*item["color"], 1]})
    return {"name": world.scenario.get("name", "demo"), "places": dict(world.scenario.get("places", {})),
            "objects": objects}


def _choice_words(choice: dict) -> str:
    """A session's runs as chosen, in words: "5 of 20 tasks × 2 = 10 runs, in rounds, new start each repeat"."""
    n = len(choice["tasks"])
    every = n + len(choice["left_out"])
    if choice.get("run_now"):                       # (double-clicked in the plan: Run this task now)
        return f"{choice['run_now']} only, once (Run this task now)"
    return (f"{n} of {every} tasks × {choice['times_each']} = {n * choice['times_each']} runs, "
            f"{ORDERS[choice['order']].lower()}, {STARTS[choice['start']].lower()} each repeat"
            + (" (as planned)" if choice.get("as_planned") else ""))


def _motion_line(rows: list[dict]) -> str:
    import statistics
    parts = []
    for key, unit in (("moves", ""), ("travel_mm", " mm"), ("wrist_turning_deg", " deg"), ("seconds", " s")):
        values = [r["motion"][key] for r in rows if r.get("motion") and r["motion"].get(key) is not None]
        if values:
            parts.append(f"{key.split('_')[0]} {statistics.median(values):.0f}{unit}")
    return ", ".join(parts) or "-"


def step_line(tool: str, args, result) -> str:
    """One model step for the run log, whole: `tool(a=1, b=2) -> result` (`tool -> result` with none), an object id by
    itself, a refusal's reason without its "ERROR:", and list_objects' answer as the cubes it saw ("3 cubes: red
    (230, 70, 26), ...") -- each cut at 90 / 120 characters until 2026-10-27, a refusal without its reason."""
    def value(v):
        return f"{v:g}" if isinstance(v, float) else v if isinstance(v, str) else json.dumps(v, default=str)
    if isinstance(args, dict):
        shown = ", ".join(str(value(v)) if {"id", "ids"} & set(str(k).split("_")) else f"{k}={value(v)}"
                          for k, v in args.items())
    else:
        shown = "" if args is None else str(args)        # (arguments the model wrote that weren't read: as they came)
    text = str(result)
    if text.startswith("ERROR"):
        text = text[len("ERROR"):].lstrip(": ")
    elif tool == "list_objects":
        text = _objects_words(text)
    return f"{tool}({shown}) → {text}" if shown else f"{tool} → {text}"


def _objects_words(text: str) -> str:
    """list_objects' answer in a line: each object by its colour (or its name) and where it is, then what's held,
    hidden under what, or no longer seen -- or the answer as it is, if it can't be read (never an error: the run log
    is filled while the run goes on)."""
    import ast
    import re
    try:
        seen = ast.literal_eval(re.sub(r"\bnp\.\w+\(([^()]*)\)", r"\1", text))    # (a numpy number: np.float64(0.93))
        objects = seen["objects"]

        def name(label) -> str:
            label = str(label)
            return label[:-len(" cube")] if label.endswith(" cube") else label
        parts = []
        for o in objects:
            xyz = o.get("xyz_mm") or ()
            where = f" ({', '.join(f'{float(c):.0f}' for c in xyz)})" if xyz else ""
            under = f" under the {o['covered_by']}" if o.get("covered_by") else ""
            parts.append(f"{name(o.get('label', '?'))}{where}{under}")
        cubes = all(str(o.get("label", "")).endswith(" cube") for o in objects)
        words = (f"{len(objects)} {'cube' if cubes else 'object'}{'s' if len(objects) != 1 else ''}: "
                 + ", ".join(parts) if objects else "nothing seen")
        if seen.get("holding"):
            words += f"; holding the {seen['holding']}"
        if seen.get("hidden"):              # [{"label", "under"}]: stacked on by the app, out of the camera's sight
            words += "; hidden: " + ", ".join(f"{h['label']} under the {h['under']}" for h in seen["hidden"])
        if seen.get("not_seen_now"):        # [{"label", "last_at_mm", "why"}]
            words += "; not seen now: " + ", ".join(
                f"{g['label']} (last at {', '.join(f'{float(c):.0f}' for c in g['last_at_mm'])}: {g['why']})"
                for g in seen["not_seen_now"])
        if seen.get("cube_size_warning"):
            words += f"; {seen['cube_size_warning']}"
        return words
    except Exception:  # noqa: BLE001 - an answer in another shape is shown as it came
        return text


def _write_csv(path: Path, header: list, rows: list) -> None:
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")     # (write_text makes it \r\n on Windows: csv's own came out \r\r\n)
    w.writerow(header)
    w.writerows(rows)
    results.write_text(path, buf.getvalue())


class TestSeedDialog(QDialog):
    """Your secret seed for the test set: typed hidden, twice (a typo would make a set you can't make again), and
    whether to check each task in the twin."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Make test tasks")
        v = QVBoxLayout(self)
        intro = QLabel("Your secret seed: any word or number. The same seed makes the same 20 tasks, so write it down "
                       "somewhere private. It is never shown, logged or given to Claude.")
        intro.setWordWrap(True)
        v.addWidget(intro)
        self.first, self.second = QLineEdit(), QLineEdit()
        for box, words in ((self.first, "seed"), (self.second, "the seed again")):
            box.setEchoMode(QLineEdit.EchoMode.Password)
            box.setPlaceholderText(words)
            box.textChanged.connect(lambda _=None: self._update())
            v.addWidget(box)
        # (why "Make them" is greyed out, said; and the seed shown on request, to check it before writing it down)
        self.why = QLabel()
        self.why.setStyleSheet("color: #ff8a8a;")
        v.addWidget(self.why)
        self.show_seed = QCheckBox("Show what I typed")
        self.show_seed.toggled.connect(lambda on: [box.setEchoMode(QLineEdit.EchoMode.Normal if on else
                                                                   QLineEdit.EchoMode.Password)
                                                   for box in (self.first, self.second)])
        v.addWidget(self.show_seed)
        self.twin = QCheckBox("Check each task in the twin, from both of its starts (recommended; takes a while)")
        self.twin.setChecked(True)
        v.addWidget(self.twin)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Make them")
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        v.addWidget(self.buttons)
        self._update()

    def seed(self) -> str:
        return self.first.text().strip()

    def _update(self) -> None:
        ok = bool(self.seed()) and self.first.text() == self.second.text()
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(ok)
        self.why.setText("" if ok or not self.second.text() else
                         "The two seeds don't match yet: type the same seed in both boxes.")
        self.why.setVisible(bool(self.why.text()))


class SaveRunDialog(QDialog):
    """Save this run: the task's runs saved so far (in this kind's folder), the run number -- the next free one to
    start with -- or your own tag, and, if that number is already saved, replacing it: the old run moves, whole, to
    Recycle_Bin. Replacing a REAL run needs a reason (it goes in deletions_log.txt)."""

    def __init__(self, parent, task_id: str, suggested: str, saved: list[dict], taken: Callable[[str], bool],
                 real: bool):
        super().__init__(parent)
        self.task_id, self.taken, self.real = task_id, taken, real
        self._saved = {r["name"]: r for r in saved}
        self.setWindowTitle(f"Save this run of {task_id}")
        v = QVBoxLayout(self)
        listing = "<br>".join(f"&nbsp;&nbsp;{r['tag']}: {results.result_word(r)}"
                              + (f" (saved {r['saved_at']})" if r.get("saved_at") else "") for r in saved)
        known = QLabel(f"<b>{task_id}</b>, saved here so far:<br>{listing}" if saved else
                       f"<b>{task_id}</b> has no saved runs here yet.")
        known.setWordWrap(True)
        v.addWidget(known)
        row = QHBoxLayout()
        self.number = QSpinBox()
        self.number.setRange(1, 999)
        self.number.setPrefix("Run ")
        match_ = re.fullmatch(r"Run(\d+)", suggested)
        self.number.setValue(int(match_.group(1)) if match_ else 1)
        self.number.setToolTip("The run's number: the next free one to start with. Choose any, e.g. to save this "
                               "as a new run of the task, or in place of one already saved")
        self.custom = QLineEdit("" if match_ else suggested)
        self.custom.setPlaceholderText("or your own tag (letters, digits, - and _)")
        row.addWidget(QLabel("Save as"))
        row.addWidget(self.number)
        row.addWidget(self.custom, 1)
        v.addLayout(row)
        self.name_label = QLabel()
        v.addWidget(self.name_label)
        self.warning = QLabel()
        self.warning.setWordWrap(True)
        self.warning.setStyleSheet("color: #ff8a8a;")
        v.addWidget(self.warning)
        self.reason = QLineEdit()
        self.reason.setPlaceholderText("Why replace it? (needed for a real run: it goes in deletions_log.txt)"
                                       if real else "Why replace it? (optional for practice)")
        v.addWidget(self.reason)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        v.addWidget(self.buttons)
        for signal in (self.number.valueChanged, self.custom.textChanged, self.reason.textChanged):
            signal.connect(lambda *_: self._update())
        self._update()

    def tag(self) -> str:
        return self.custom.text().strip() or f"Run{self.number.value()}"

    def answer(self) -> dict:
        name = results.run_name(self.task_id, self.tag())
        return {"tag": self.tag(), "replace": self.taken(name), "reason": self.reason.text().strip()}

    def _update(self) -> None:
        self.number.setEnabled(not self.custom.text().strip())
        name = results.run_name(self.task_id, self.tag())
        self.name_label.setText(f"The run will be <b>{name}</b> ({name}.md and its web page).")
        taken = self.taken(name)
        earlier = self._saved.get(name)
        self.warning.setText(
            (f"{name} is already saved" + (f" ({'Pass' if earlier['passed'] else 'Fail'}"
                                            + (f", {earlier['saved_at']}" if earlier.get("saved_at") else "") + ")"
                                            if earlier else "")
             + ". Saving replaces it: the earlier run moves, whole, to Recycle_Bin.") if taken else "")
        self.warning.setVisible(taken)
        self.reason.setVisible(taken)
        save = self.buttons.button(QDialogButtonBox.StandardButton.Save)
        save.setText(f"Replace {self.tag()}" if taken else "Save")
        save.setEnabled(not (taken and self.real and not self.reason.text().strip()))


class DeleteDialog(QDialog):
    """Delete results: all practice in one click, or a chosen folder, or the whole real study (with a reason, and
    typing DELETE for everything real). Everything goes to the Recycle Bin. The test tasks are never deleted here."""

    def __init__(self, parent=None, root: Path = results.RESULTS_ROOT):
        super().__init__(parent)
        self.root = root
        self._trash = results.to_recycle_bin              # (a test puts in its own)
        self.setWindowTitle("Delete results")
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Deleted results go to the Windows Recycle Bin (they can be put back from there).\n"
                           "Deleting real results asks for a reason, written to deletions_log.txt."))
        practice = QPushButton(f"Delete all practice results ({results.count_runs(root / results.PRACTICE)} runs)")
        practice.clicked.connect(self._practice)
        pick = QPushButton("Choose a folder to delete…")
        pick.clicked.connect(self._pick)
        everything = QPushButton(f"Delete ALL real results (study_1 … study_{results.MAX_STUDIES})…")
        everything.clicked.connect(self._all_real)
        for b in (practice, pick, everything):
            v.addWidget(b)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.rejected.connect(self.reject)
        v.addWidget(close)

    def _practice(self) -> None:
        folder = self.root / results.PRACTICE
        if not folder.exists():
            QMessageBox.information(self, "Delete", "There are no practice results.")
            return
        if QMessageBox.question(self, "Delete", f"Send all practice results ({results.count_runs(folder)} runs) to "
                                "the Recycle Bin?") == QMessageBox.StandardButton.Yes:
            self._delete(folder, "")

    def _pick(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Choose what to delete", str(self.root))
        if not folder:
            return
        folder = Path(folder)
        tasks_folder = self.root / results.TEST_TASKS
        if folder.resolve() in (tasks_folder.resolve(), *tasks_folder.resolve().parents) or \
                tasks_folder.resolve() in folder.resolve().parents:
            QMessageBox.warning(self, "Delete", "That folder holds the test tasks (Private_never_for_Claude). Choose a "
                                "study or a kind of data, or use 'Delete ALL real results…' (it keeps the test "
                                "tasks).")
            return
        real = results.is_real_path(folder, self.root)
        reason = ""
        if real:
            reason, ok = QInputDialog.getText(self, "Reason", "Why are these real results being deleted? (It goes "
                                              "in the deletions log.)")
            if not ok or not reason.strip():
                return
        if QMessageBox.question(self, "Delete", f"Send {folder.name} ({results.count_runs(folder)} runs) to the "
                                "Recycle Bin?") == QMessageBox.StandardButton.Yes:
            self._delete(folder, reason)

    def _all_real(self) -> None:
        """Every real result -- each study's folder -- but never the test tasks (Private_never_for_Claude)."""
        parts = [self.root / name for name in results.STUDIES.values() if (self.root / name).exists()]
        if not parts:
            QMessageBox.information(self, "Delete", "There are no real-test results.")
            return
        runs = sum(results.count_runs(p) for p in parts)
        typed, ok = QInputDialog.getText(self, "Delete ALL real results",
                                         f"This sends every real result ({runs} runs, in {len(parts)} study "
                                         "folder(s)) to the Recycle Bin. The test tasks stay. Type DELETE to confirm:")
        if not ok or typed.strip() != "DELETE":
            return
        reason, ok = QInputDialog.getText(self, "Reason", "Why? (It goes in the deletions log.)")
        if not (ok and reason.strip()):
            return
        done, failed = 0, []
        for part in parts:
            try:
                done += results.delete_results(part, reason, root=self.root, trash=self._trash)
            except Exception as exc:  # noqa: BLE001
                failed.append(f"{part.name}: {exc}")
        QMessageBox.information(self, "Delete", f"Sent to the Recycle Bin ({done} runs). The test tasks stay."
                                + ("\n\nCouldn't: " + "; ".join(failed) if failed else ""))

    def _delete(self, folder: Path, reason: str) -> None:
        try:
            n = results.delete_results(folder, reason, root=self.root, trash=self._trash)
            QMessageBox.information(self, "Delete", f"Sent to the Recycle Bin ({n} runs).")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Delete", f"Couldn't delete: {exc}")

"""The watcher's status strip (V4.3, 2026-10-26): one coloured line at the top of the window saying what the watcher is
doing now, so a long model turn on the laptop's CPU isn't taken for a freeze, and the end of a session is plain.

    ready    grey   no session
    setup    amber  getting a task ready by itself (looking at the table, the countdown)
    running  blue   a task is running (the dot blinks); steps so far, and how long since anything happened
    waiting  orange the watcher needs you: set the table out, a verdict, Save, or Run by itself paused
    done     green  every task of the session ran
    ended    red    the session ended before its last task, and why

It only shows: what it says comes from the window (watcher/window.py, _status_now); nothing here scores or saves.
"""
from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QProgressBar, QVBoxLayout

COLOURS = {                         # kind: (background, text, strong: the dot and the bar)
    "ready": ("#eeeeee", "#333333", "#8a8a8a"),
    "setup": ("#fdf0d5", "#6b4a00", "#c88a00"),
    "running": ("#ddeafb", "#0c447c", "#2f7ad8"),
    "waiting": ("#fde3c4", "#7a3d00", "#e07b00"),
    "done": ("#dcefd0", "#24500a", "#4c9a1f"),
    "ended": ("#fbdcdc", "#7a1f1f", "#d33c3c"),
}
KINDS = tuple(COLOURS)


def clock(seconds: float) -> str:
    """12:05, or 1:02:05 past an hour."""
    s = max(0, int(seconds))
    h, m = divmod(s // 60, 60)
    return f"{h}:{m:02d}:{s % 60:02d}" if h else f"{m}:{s % 60:02d}"


class StatusStrip(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("statusStrip")
        self.kind = "ready"
        self._lit = True
        row = QHBoxLayout(self)
        row.setContentsMargins(12, 8, 12, 8)
        row.setSpacing(12)
        self.dot = QLabel()
        self.dot.setFixedSize(12, 12)
        row.addWidget(self.dot, 0, Qt.AlignmentFlag.AlignTop)
        column = QVBoxLayout()
        column.setSpacing(2)
        self.head = QLabel()
        self.sub = QLabel()
        self.sub.setWordWrap(True)
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(6)
        for w in (self.head, self.sub, self.bar):
            column.addWidget(w)
        row.addLayout(column, 1)
        self.right = QLabel()
        self.right.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        row.addWidget(self.right)
        self.show_status("ready", "Ready", "No session running.")

    def show_status(self, kind: str, head: str, sub: str = "", right: str = "",
                    progress: Optional[float] = None) -> None:
        """What the strip says; `progress` 0-100 (None: no bar)."""
        if kind != self.kind:
            self._lit = True
        self.kind = kind
        self.head.setText(head)
        self.sub.setText(sub)
        self.sub.setVisible(bool(sub))
        self.right.setText(right)
        self.bar.setVisible(progress is not None)
        if progress is not None:
            self.bar.setValue(int(round(min(100.0, max(0.0, progress)))))
        self._paint()

    def blink(self) -> None:
        """Running: the dot goes dim and bright, a second each, so the strip is seen to be alive."""
        if self.kind == "running":
            self._lit = not self._lit
            self._paint()

    def _paint(self) -> None:
        back, text, strong = COLOURS.get(self.kind, COLOURS["ready"])
        self.setStyleSheet(f"#statusStrip {{ background: {back}; border-radius: 6px; }}"
                           f"#statusStrip QLabel {{ color: {text}; background: transparent; }}"
                           f"#statusStrip QProgressBar {{ background: rgba(0,0,0,0.08); border: none; "
                           f"border-radius: 3px; }}"
                           f"#statusStrip QProgressBar::chunk {{ background: {strong}; border-radius: 3px; }}")
        self.head.setStyleSheet("font-size: 15px; font-weight: bold;")
        self.sub.setStyleSheet("font-size: 13px;")
        self.right.setStyleSheet("font-size: 13px;")
        self.dot.setStyleSheet(f"background: {strong if self._lit else back}; border: 2px solid {strong}; "
                               "border-radius: 6px;")

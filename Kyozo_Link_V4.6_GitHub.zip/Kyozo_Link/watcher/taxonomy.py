"""The study's failure types, decided by fixed rules in a fixed order (study/PREREG.md, section 5) -- the same for the
twin and the real Dobot, so failures can be counted and compared without anyone's judgement.

    1 infrastructure   Ollama, the camera or the PC failed outside motion (the run is re-run)
    2 plan             the model never acted on the task's cubes, or stopped early; or left a cube in a zone the
                       task never mentions; or its chosen action was refused as misused and never carried out; or
                       it sent one of the task's cubes the other way from the one asked (V4.2: the first wrong step
                       decides -- S-05's swapped directions were "limit_alarm" because the wrong move was out of reach)
      preparation      (V4.2) the first refused step was on a cube only in the task's way (taking a tower down,
                       moving a cube aside)
    3 limit_alarm      a controller reach / joint-limit alarm, or a move refused as out of reach
    4 perception       the app thought a target cube was > 5 mm from where the watcher saw it, or took the wrong one
    5 execution        missed grip, slip, drop, placement or angle error
    6 unclassified
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Optional

from watcher.tasks import Cube, Score, Task, Zone, match

# controller alarms that mean "a joint would pass its limit / the pose can't be reached" (Dobot protocol 0x10-0x12
# planning, 0x20-0x22 moving, 0x40-0x49 joint and parallelogram limits)
LIMIT_ALARMS = set(range(0x10, 0x13)) | set(range(0x20, 0x23)) | set(range(0x40, 0x4A))
REACH_WORDS = ("can't reach", "cannot reach", "out of reach", "outside the robot's safe workspace", "short of",
               "joint would", "past its limit")
PERCEPTION_MM = 5.0
MOVED_MM, TURNED_DEG = 5.0, 3.0

INFRASTRUCTURE, PLAN, LIMIT, PERCEPTION, EXECUTION, UNCLASSIFIED = (
    "infrastructure", "plan", "limit_alarm", "perception", "execution", "unclassified")
PREPARATION = "preparation"
# move_object's directions (app/llm/arrange.py): the robot's own, and along the line from its base
MOVE_DIRECTIONS = {"left": (0.0, 1.0), "right": (0.0, -1.0), "forward": (1.0, 0.0), "front": (1.0, 0.0),
                   "back": (-1.0, 0.0), "behind": (-1.0, 0.0), "backward": (-1.0, 0.0)}
RADIAL_OUT = ("away", "forward_away", "further")
RADIAL_IN = ("towards_base", "closer", "towards_the_robot", "toward_the_robot")


@dataclass
class RunFacts:
    """What a run's logs say, in the shape the rules need."""
    infrastructure_error: Optional[str] = None       # an exception that wasn't the robot moving (Ollama, camera...)
    tool_results: list[str] = field(default_factory=list)
    tool_names: list[str] = field(default_factory=list)     # each step's tool, alongside tool_results
    alarms: list[int] = field(default_factory=list)  # controller alarm codes seen during the run
    final_message: str = ""
    # the app's own idea of where each target cube was just before it gripped it, if logged: label -> (x, y)
    app_estimates: dict[str, tuple[float, float]] = field(default_factory=dict)
    tool_args: list[dict] = field(default_factory=list)      # each step's arguments, alongside tool_names
    object_labels: dict[str, str] = field(default_factory=dict)  # the app's object ids -> "red cube" (its looks)


# Refused steps (a tool call the app answered with "ERROR: ..."), by why -- checked in this order:
#   robot   the arm or gripper itself failed (an alarm, the gripper closed on nothing, lost contact, E-STOP)
#   guard   a safety or feasibility check said no (safe workspace, reach/joint limits, the camera's view, a collision)
#   wasted  the model asked in a way that couldn't work (wrong order, unknown id or place, a missing argument, a spot
#           already taken): fewer of these is a plain improvement
# Fewer guard refusals is only an improvement when the code stops asking for the impossible -- never by weakening
# the check (study/ROUND_PROMPT.md).
REFUSAL_WORDS = {
    "robot": ("gripper closed on nothing", "robotalarm", "raised an alarm", "lost contact", "did not acknowledge",
              "e-stop", "stopped short", "short of", "speed could not", "controller"),
    "guard": ("safe workspace", "reach", "joint", "limit", "camera", "would hit", "can't get from",
              "too small to do reliably", "isn't known", "too big", "is full", "stick out", "too short",
              "no free spot", "no free stretch"),
    "wasted": ("nothing is being held", "already holding", "unknown object_id", "list_objects", "no saved place",
               "unknown tool", "unknown side", "which objects", "which way", "how far", "not a distance",
               "needs an object_id", "give place_name", "on what?", "needs at least two", "is taken by",
               "on top of it", "is on the '", "aren't in a row", "aren't level", "stopped by you"),
}


def refusal_kind(result: str) -> str:
    text = result.lower()
    for kind in ("robot", "guard", "wasted"):
        if any(word in text for word in REFUSAL_WORDS[kind]):
            return kind
    return "other"


def count_refusals(tool_results: list[str]) -> dict:
    """How many steps were refused in a run, by kind, and the reasons (shortened)."""
    out = {"total": 0, "wasted": 0, "guard": 0, "robot": 0, "other": 0, "reasons": []}
    for result in tool_results:
        if not str(result).startswith("ERROR"):
            continue
        kind = refusal_kind(str(result))
        out["total"] += 1
        out[kind] += 1
        out["reasons"].append(f"{kind}: {str(result)[6:].strip()[:140]}")
    return out


def acted_on(task: Task, start: list[Cube], end: list[Cube]) -> bool:
    """Did anything happen to the cubes the task is about: moved more than a few mm or turned a few degrees?"""
    finals = match(start, end)
    for s, f in zip(start, finals):
        if s.label not in task.oracle:
            continue
        if f is None:
            return True                                # gone: something was done to it
        turned = abs(((f.yaw - s.yaw) + 45) % 90 - 45)
        if math.hypot(f.x - s.x, f.y - s.y) > MOVED_MM or turned > TURNED_DEG:
            return True
    return False


def off_task_zone(task: Task, start: list[Cube], end: list[Cube], zones: Optional[dict[str, Zone]]) -> bool:
    """Did a cube end in a zone the task never mentions (in its targets, its prompt or a step before it), having
    started outside it? (A swap that left the red cube in zone A: the model did something else, not a grip that
    missed.)"""
    if not zones:
        return False
    words = " ".join([task.prompt, *task.before]).lower()
    named = {spec.get(field) for target in task.targets for spec in target.values() if isinstance(spec, dict)
             for field in ("zone", "spot")}               # (a sheet task names its spots: in_zone's zone, from_spot's spot)
    # a swap sends each cube to where the other one started: those spots are the task's too
    swapped = {spec.get(k) for target in task.targets for kind, spec in target.items() if kind == "swapped"
               for k in ("a", "b")}
    for key, zone in zones.items():
        if any(s.label in swapped and zone.contains(s) for s in start):
            named.add(key)
    for key, zone in zones.items():
        number = key.split("_")[-1].lower()
        if key in named or f"zone {number}" in words or (key.startswith("spot_") and f"spot {number}" in words):
            continue
        for s, f in zip(start, match(start, end)):
            if f is not None and zone.contains(f) and not zone.contains(s):
                return True
    return False


def abandoned_action(facts: RunFacts) -> bool:
    """Was a step refused because the model used the tool wrongly ("wasted": already holding, wrong order...) and that
    tool never then done? (pick first, then swap: swap refused, the cube put somewhere else.) A misuse put right --
    "call list_objects first", then the pick done -- isn't; nor is a run the person stopped."""
    names, results = facts.tool_names, [str(r) for r in facts.tool_results]
    if len(names) != len(results):
        return False
    for i, (name, result) in enumerate(zip(names, results)):
        if (result.startswith("ERROR") and refusal_kind(result) == "wasted" and "stopped by you" not in result.lower()
                and not any(n == name and not r.startswith("ERROR") for n, r in zip(names[i + 1:], results[i + 1:]))):
            return True
    return False


OBJECT_ID = re.compile(r"""['"]id['"]:\s*['"]([^'"]+)['"],\s*['"]label['"]:\s*['"]([^'"]+)['"]""")


def object_labels_from(texts) -> dict[str, str]:
    """The app's object ids and what they are ("obj_6" -> "red cube"), from what its looks said (list_objects)."""
    out: dict[str, str] = {}
    for text in texts:
        out.update(OBJECT_ID.findall(str(text)))
    return out


def _cube_named(object_id, labels, known: Optional[dict] = None) -> Optional[str]:
    """Which of `labels` ("red cube") a step's object_id means: the cube the app's looks gave that id, or the colour
    word in it."""
    text = str((known or {}).get(str(object_id), object_id) or "").lower()
    return next((label for label in labels if label.split()[0] in text), None)


def wrong_direction(task: Task, facts: RunFacts, start: list[Cube]) -> Optional[str]:
    """A move_object step that sent one of the task's cubes the other way from the one its "moved" target asks (S-05:
    "the red cube 40 mm nearer" sent forward). What it says, or None."""
    where = {c.label: c for c in start}
    wanted: dict[str, tuple[float, float]] = {}
    for target in task.targets:
        (kind, spec), = target.items()
        if kind != "moved":
            continue
        c = where.get(spec["cube"])
        if "radial" in spec and c is not None:
            r = math.hypot(c.x, c.y) or 1.0
            sign = 1.0 if float(spec["radial"]) > 0 else -1.0
            wanted[spec["cube"]] = (sign * c.x / r, sign * c.y / r)
        elif "dx" in spec or "dy" in spec:
            wanted[spec["cube"]] = (float(spec.get("dx", 0)), float(spec.get("dy", 0)))
    first: set[str] = set()
    for name, args in zip(facts.tool_names, facts.tool_args):
        if name != "move_object" or not isinstance(args, dict):
            continue
        label = _cube_named(args.get("object_id"), wanted, facts.object_labels)
        if label is None or label in first:
            continue                               # (a later move of it may be a correction: the first decides)
        first.add(label)
        word = str(args.get("direction") or "").lower().replace(" ", "_")
        c = where.get(label)
        if word in RADIAL_OUT or word in RADIAL_IN:
            if c is None:
                continue
            r = math.hypot(c.x, c.y) or 1.0
            sign = 1.0 if word in RADIAL_OUT else -1.0
            way = (sign * c.x / r, sign * c.y / r)
        elif word in MOVE_DIRECTIONS:
            way = MOVE_DIRECTIONS[word]
        else:
            continue
        try:
            if float(args.get("distance_mm") or 0) < 0:
                way = (-way[0], -way[1])
        except (TypeError, ValueError):
            pass
        w = wanted[label]
        if way[0] * w[0] + way[1] * w[1] < 0:
            return f"moved the {label} '{word}', the other way from the one asked"
    return None


def first_refusal_on(facts: RunFacts, labels) -> Optional[str]:
    """The cube (of `labels`) the first refused step was about, if it was about one of them."""
    for args, result in zip(facts.tool_args, facts.tool_results):
        if str(result).startswith("ERROR"):
            if not isinstance(args, dict):
                return None
            ids = [args.get(k) for k in ("object_id", "object_id_a", "object_id_b")] + list(args.get("object_ids")
                                                                                                or [])
            return next((label for i in ids for label in [_cube_named(i, labels, facts.object_labels)] if label),
                        None)
    return None


def classify(task: Task, score: Score, facts: RunFacts, start: list[Cube], end: list[Cube],
             seen_start: Optional[list[Cube]] = None, zones: Optional[dict[str, Zone]] = None,
             may_move: Optional[dict] = None, first_step: bool = False) -> Optional[str]:
    """The failure type of a run, or None if it passed. `seen_start`: where the watcher saw the cubes at the start
    (for the perception rule; the twin's starts are exact). `zones`: the task set's (for the plan rule's zones).
    `may_move`: the cubes only in the task's way at the start (for the preparation rule). `first_step`: V4.2's rule
    that a cube sent the wrong way is "plan" (a chained set's runs)."""
    if score.passed:                 # (an Ollama error after the arm was done made a pass "infrastructure": run again)
        return None
    if facts.infrastructure_error:
        return INFRASTRUCTURE
    if (not acted_on(task, start, end) or off_task_zone(task, start, end, zones) or abandoned_action(facts)
            or (first_step and wrong_direction(task, facts, start))):
        return PLAN
    if may_move and first_refusal_on(facts, list(may_move)):
        return PREPARATION
    if any(code in LIMIT_ALARMS for code in facts.alarms) or any(
            r.startswith("ERROR") and any(w in r.lower() for w in REACH_WORDS) for r in facts.tool_results):
        return LIMIT
    if facts.app_estimates and seen_start:
        for label, estimate in facts.app_estimates.items():
            nearest = match([Cube(label, *estimate)], seen_start)[0]
            if nearest is not None and math.hypot(estimate[0] - nearest.x, estimate[1] - nearest.y) > PERCEPTION_MM:
                return PERCEPTION
    if score.targets or score.collateral or score.missing:
        return EXECUTION
    return UNCLASSIFIED


def motion_efficiency(moves: list[dict], seconds: Optional[float] = None) -> dict:
    """How much the arm moved in a run, from its move events (watcher order): moves sent, travel between their
    targets (mm), total wrist turning (degrees), and the run's time. Fewer is not better by itself -- the slow last
    15 mm and the approach from below are extra moves on purpose -- so it is reported next to accuracy, never instead."""
    targets = [m["target"] for m in moves if m.get("target")]
    travel = sum(math.dist((a["x"], a["y"], a["z"]), (b["x"], b["y"], b["z"])) for a, b in zip(targets, targets[1:]))
    turning = sum(abs(b.get("r", 0.0) - a.get("r", 0.0)) for a, b in zip(targets, targets[1:]))
    return {"moves": len(targets), "travel_mm": round(travel, 1), "wrist_turning_deg": round(turning, 1),
            "seconds": seconds}

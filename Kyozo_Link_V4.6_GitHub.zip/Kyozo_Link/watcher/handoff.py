"""Claude's input: one package per study for the next version -- the filled-in round prompt, a one-page summary, and
each kind of data's full report and saved runs -- with a zip of it for uploading:

    For_Claude\\study_N\\                         (practice: For_Claude\\Practice_Session\\practice_study_N\\)
        START_HERE.md                            read first
        SUMMARY.md                               Twin vs Dobot, task by task; failures, alarms, motion
        PREVIOUS_SUMMARY.md                      the study before's (from study 2 on)
        20_Tasks_for_Twin\\  20_Tasks_for_Dobot\\  each named as its folder in study_N: FULL_REPORT.md,
                                                 full_report.json, runs\\<run>\\
        skipped_before_v4.2.json                 tasks skipped when a skip was only logged (rebuilt from the logs)
        notes\\                                   the engineer's reports on the study (study\\reports\\study_N\\*.md)
    For_Claude\\study_N.zip

Made only from the 20 tasks by themselves (study_N\\20_Tasks_for_Twin, 20_Tasks_for_Dobot) and the training
(Twin_Training_Data, Dobot_Training_Data): anything of the unseen test is refused (it stays unseen).

The twin's and the Dobot's runs go in together, paired task by task: the summary opens with "Twin vs Dobot", which
sorts each task into hardware (the twin passes, the Dobot fails: compensate), software or plan (both fail: fix), fine,
or noise. From study 2 on, the previous study's summary goes in too, for context.

Every package says where its data came from (the real Dobot, the simulated demo, or the digital twin) and whether it
counts for the paper, in its place (study_N or Practice_Session), START_HERE.md, the summary and each run's record.
"""
from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

from watcher import results

FOR_CLAUDE = results.FOR_CLAUDE
ROUND_PROMPT = Path(__file__).resolve().parent.parent / "study" / "ROUND_PROMPT.md"
APP_VERSION = Path(__file__).resolve().parent.parent / "VERSION"
NOTES = Path(__file__).resolve().parent.parent / "study" / "reports"   # the engineer's reports: study_N\*.md
SKIPS_BEFORE_V42 = "skipped_before_v4.2.json"
SETS = ("simple", "train")                   # the kinds of data that go in, in this order (never "test")
SUMMARY, PREVIOUS_SUMMARY = "SUMMARY.md", "PREVIOUS_SUMMARY.md"
RUN_FILES = ("run.json", "run_report.txt", "model_log.txt", "trace.json", "moves.csv", "gripper.csv", "alarms.csv",
             "observer.json", "picks.csv")
PICTURES = ("start.png", "end.png", "end_marked.png")
SOURCES = {
    "dobot": ("live", "the real Dobot Magician"),
    "demo": ("demo", "the simulated demo (the app's simulated world), NOT the real Dobot"),
    "twin": ("twin", "the digital twin (ideal hardware), NOT the real Dobot"),
}


def _is_test(path: Path) -> bool:
    """Anything of the unseen test (a *with_unseen_tasks or *Test_Data folder, the private folder, the backups) or an old
    layout's test folders: never Claude's."""
    name = Path(path).name.upper()
    return results.is_test_path(path) or "_TEST_" in name or "_DRIFT_" in name or         "REVIEW_FOR_DR_CURRY" in {p.upper() for p in Path(path).parts}


def _info(folder: Path) -> dict:
    from watcher import report
    return report._info_of(folder)


def source_of(folder: Path) -> tuple[str, str, bool]:
    """(short name, description, real) of where a kind folder's data came from."""
    info = _info(folder)
    where = info.get("where", "dobot")
    short, words = SOURCES.get(where, (where, where))
    real = bool(info.get("real"))
    return short, words + (" — counts for the paper" if real else " — practice, not for the paper"), real


def package_folder(round_no: int, real: bool, root: Path = results.RESULTS_ROOT) -> Path:
    """For_Claude\\study_N (real) or For_Claude\\Practice_Session\\practice_study_N (practice)."""
    study = results.STUDIES[round_no]
    return Path(root) / FOR_CLAUDE / (study if real else Path(results.PRACTICE) / f"practice_{study}")


def build(folders: list[Path], round_no: int, version: str, root: Path = results.RESULTS_ROOT,
          pictures: bool = True) -> Path:
    """Makes the package from a study's kind folders (20_Tasks_for_Twin, 20_Tasks_for_Dobot; the training's too);
    returns its folder (a .zip of it is made next to it). Only saved runs go in. Anything of the test is refused."""
    if not folders:
        raise ValueError("no saved runs of the 20 tasks to make Claude's input from")
    for f in folders:
        if _is_test(f):
            raise ValueError(f"refused: {f} is test data -- Claude must never see test results")
        if _info(f).get("set") not in SETS:
            raise ValueError(f"refused: {f} is not the 20 tasks' or the training's data")
    sources = [source_of(f) for f in folders]
    real = sources[0][2]
    if any(src[2] != real for src in sources):
        raise ValueError("refused: practice and real data can't go in one package")
    words = "; ".join(dict.fromkeys(src[1] for src in sources))
    out = package_folder(round_no, real, root)
    label = str(out.relative_to(Path(root) / FOR_CLAUDE))
    if out.exists():
        shutil.rmtree(out)                        # (rebuilt from the same data: the old copy goes)
    out.mkdir(parents=True)

    from watcher import report
    rows, keyed = [], []
    for f, (_, folder_words, _) in zip(folders, sources):
        side = _side(f)
        kind = out / f.name                                  # named as its folder in study_N
        (kind / "runs").mkdir(parents=True)
        try:                                               # (made again now: everything saved so far)
            report.write_session_results(f)
        except Exception:  # noqa: BLE001 - the runs still go in
            pass
        for name in ("FULL_REPORT.md", "full_report.json"):  # the whole kind: as a document, and as data
            if (f / name).exists():
                text = (f / name).read_text(encoding="utf-8")   # (the evidence is in runs\ here: links follow)
                text = text.replace(f"]({results.RAW}/", "](runs/").replace(f'"{results.RAW}/', '"runs/')
                results.write_text(kind / name, text)
        for run in report._run_folders(f):
            dest = kind / "runs" / run.name
            dest.mkdir()
            for name in RUN_FILES:
                if (run / name).exists():
                    shutil.copy2(run / name, dest / name)
            saved_md = results.saved_folder(f) / f"{run.name}.md"
            if saved_md.exists():                            # the run's own file: everything about it
                shutil.copy2(saved_md, dest / "RUN_FULL_REPORT.md")
            record = json.loads((dest / "run.json").read_text(encoding="utf-8"))
            record["data_source"] = folder_words
            results.write_json(dest / "run.json", record)
            if pictures:
                for name in PICTURES:
                    _small_picture(run / name, dest / name)
            rows.append((f"{f.name}/runs/{run.name}", record))
            if not record.get("skipped"):                    # (a task that never started: in its own section)
                keyed.append((side, record))
    previous = _previous_summary(root, round_no, real)
    if previous is not None:
        shutil.copy2(previous, out / PREVIOUS_SUMMARY)
    logged = [s for f in folders for s in logged_skips(f)]
    if logged:
        results.write_json(out / SKIPS_BEFORE_V42, logged)
    notes = sorted((NOTES / results.STUDIES[round_no]).glob("*.md")) if real else []
    for note in notes:                             # (the engineer's own reports on what went wrong, as written)
        (out / "notes").mkdir(exist_ok=True)
        shutil.copy2(note, out / "notes" / note.name)
    summary = _summary(rows, round_no, version, words, pairing=_pairing(keyed), logged=logged)
    results.write_text(out / SUMMARY, summary)
    results.write_text(out / "START_HERE.md", _start_here(round_no, version, words, real, label,
                                                          previous=previous is not None,
                                                          kinds=[f.name for f in folders], notes=bool(notes),
                                                          logged=bool(logged)))
    shutil.make_archive(str(out), "zip", out)
    return out


def _side(folder: Path) -> str:
    """"dobot" or "twin" (the demo's practice counts as the twin's)."""
    return "dobot" if _info(folder).get("where", "dobot") == "dobot" else "twin"


def _previous_summary(root: Path, round_no: int, real: bool) -> Optional[Path]:
    """The previous study's SUMMARY.md (real with real, practice with practice), if it was made."""
    if round_no - 1 not in results.STUDIES:
        return None
    path = package_folder(round_no - 1, real, root) / SUMMARY
    return path if path.exists() else None


def logged_skips(kind: Path) -> list[dict]:
    """The tasks skipped before V4.2, when a skip was only logged (each sitting's index: the task, why, what the camera
    saw), each with the run saved last before it in that sitting -- what Claude needs to find what left the table so.
    Skips saved as runs (V4.2 on) are in the runs themselves, so left out here."""
    from watcher import report
    as_runs = set()
    for run in report._run_folders(kind):
        r = report._read_json(run / "run.json", {})
        if r.get("skipped"):
            as_runs.add((r.get("sitting"), r.get("task"), r.get("repeat")))
    out = []
    for index in sorted((Path(kind) / results.SESSIONS_LOG).glob("*/index.jsonl")):
        sitting, last_saved = index.parent.name, None
        for line in index.read_text(encoding="utf-8").splitlines():
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            if entry.get("saved"):
                last_saved = entry["saved"]
            elif isinstance(entry.get("skipped"), str) and (sitting, entry["skipped"], entry.get("repeat")) not in as_runs:
                before = None
                if last_saved:
                    r = report._read_json(Path(kind) / results.RAW / last_saved / "run.json", {}) or {}
                    before = {"run": last_saved, "result": report.pass_word(r) if r else "?",
                              "failure": r.get("failure"), "ended": r.get("end_seen") or []}
                out.append({"kind": Path(kind).name, "sitting": sitting, "time": entry.get("time"),
                            "task": entry["skipped"], "repeat": entry.get("repeat"), "why": entry.get("why"),
                            "seen": entry.get("seen") or [], "last_saved_before": before})
    return out


def study_sessions(round_no: int, real: bool, root: Path = results.RESULTS_ROOT) -> list[Path]:
    """A study's data for Claude, the twin's and the Dobot's: the kind folders (real or practice) of the 20 tasks
    (and of the training) that hold saved runs. Never the unseen test's."""
    from watcher import report
    out = []
    for set_name in SETS:
        for where in ("twin", "dobot"):
            folder = results.kind_folder(real, set_name, where, round_no, root)
            if folder.exists() and report._run_folders(folder):
                out.append(folder)
    return out


def _pairing(keyed: list[tuple[str, dict]]) -> list[str]:
    """Twin vs Dobot, task by task: what kind of problem each failing task is. Empty with only one side."""
    keyed = [(side, r) for side, r in keyed if not r.get("repeated") and not r.get("excluded")]
    if len({side for side, _ in keyed}) < 2:
        return []
    tasks: dict = {}
    for side, r in keyed:
        ok = bool(r.get("unassisted_pass", r.get("passed")))
        tasks.setdefault(r.get("task", "?"), {}).setdefault(side, []).append(ok)
    lines = ["## Twin vs Dobot, task by task (read this first)", "",
             "The twin is ideal hardware. A task the twin passes and the Dobot fails is a **hardware** problem: "
             "compensate for it in software. One both fail is a **software or plan** problem: fix it. One only the "
             "twin fails is **noise** (look, don't chase).", "",
             "| Task | Twin | Dobot | Kind |", "|---|---|---|---|"]
    counts: dict = {}
    for task in sorted(tasks):
        sides = tasks[task]
        twin, dobot = sides.get("twin"), sides.get("dobot")

        def rate(v):
            return "-" if v is None else f"{sum(v)}/{len(v)}"
        if twin is None or dobot is None:
            kind = f"only the {'Dobot' if twin is None else 'twin'} ran"
        else:
            t, d = sum(twin) * 2 >= len(twin), sum(dobot) * 2 >= len(dobot)
            kind = ("fine" if t and d else "**hardware**: compensate" if t else
                    "**software or plan**: fix" if not d else "noise")
        counts[kind] = counts.get(kind, 0) + 1
        lines.append(f"| {task} | {rate(twin)} | {rate(dobot)} | {kind} |")
    lines += ["", "Totals: " + ", ".join(f"{k.replace('*', '')} {v}" for k, v in sorted(counts.items())), ""]
    return lines


def _small_picture(src: Path, dest: Path, width: int = 640) -> None:
    if not src.exists():
        return
    try:
        import cv2
        image = cv2.imread(str(src))
        if image is None:
            return
        h, w = image.shape[:2]
        if w > width:
            image = cv2.resize(image, (width, int(h * width / w)), interpolation=cv2.INTER_AREA)
        cv2.imwrite(str(dest), image)
    except Exception:  # noqa: BLE001 - a missing picture is not worth failing the package over
        pass


def _summary(rows: list[tuple[str, dict]], round_no: int, version: str, words: str,
             pairing: Optional[list[str]] = None, logged: Optional[list[dict]] = None) -> str:
    from watcher import report
    repeated = sum(1 for _, r in rows if r.get("repeated") or r.get("excluded"))
    skipped = [(name, r) for name, r in rows if r.get("skipped")]
    # (infrastructure failures run again, and tasks that never started: not counted)
    rows = [(name, r) for name, r in rows if not r.get("repeated") and not r.get("excluded") and not r.get("skipped")]
    lines = [f"# Study {round_no} summary (version {version})", "", f"**Data:** {words}.",
             f"Made {datetime.now().isoformat(timespec='minutes')}. Runs: {len(rows)}"
             + (f" (and {repeated} infrastructure failure(s) run again, not counted; their records are in runs\\, "
                "marked repeated)" if repeated else "")
             + (f"; skipped: {len(skipped)} (never started, see below)" if skipped else "")
            + (f"; skipped before V4.2 (logged only): {len(logged)}" if logged else "") + ".", ""]
    bad = [(name, r) for name, r in rows if r.get("catastrophic")]
    if any(r.get("outcome") for _, r in rows):     # (V4.2: each run's outcome, and what went badly wrong)
        counts = {w: sum(r.get("outcome") == w for _, r in rows) for w in ("PASS", "SOME PARTS", "FAIL")}
        lines += ["Outcomes: " + ", ".join(f"{w} {n}" for w, n in counts.items())
                  + f"; catastrophic: {len(bad)}.", ""]
    if bad:
        lines += ["## Catastrophic runs (look at these first)", "",
                  "Something went badly wrong on the table or with the arm (the score is unchanged; this is a flag "
                  "beside it): fix what causes these before anything else.", ""]
        lines += [f"- `{name}` · {r.get('task')} “{r.get('prompt')}” · {r.get('outcome')} · "
                  + "; ".join(r["catastrophic"]) for name, r in bad]
        lines += [""]
    lines += pairing or []
    if skipped:                                    # what never started, why, and the task that left the table so
        lines += ["## Skipped tasks (never started: the table wasn't READY)", "",
                  "Not a pass or a fail, so not in the counts below. A task skipped after another usually means the "
                  "one before left the cubes where this one can't start: look at how it ended.", ""]
        lines += [f"- `{name}` · {r.get('task')} “{r.get('prompt')}” · " + " ".join(report.skipped_lines(r["skipped"]))
                  for name, r in skipped]
        lines += [""]
    if logged:                                     # (before V4.2 a skip was only logged: rebuilt from the logs)
        lines += ["## Skipped before V4.2 (from the sessions' logs)", "",
                  f"Before V4.2 a skipped task was only logged, not saved as a run: these are rebuilt from each "
                  f"sitting's log (no pictures, no expected-vs-seen; the same facts as data: `{SKIPS_BEFORE_V42}`). "
                  "Not a pass or a fail. Skips in a row from one sitting usually share one cause: the run saved last "
                  "before the first of them (look at how it ended), or, if `notes\\` explains them, what it says.", ""]

        def last(b: Optional[dict]) -> str:
            if not b:
                return "none (the sitting's first task)"
            return (f"`{b['run']}`, {b['result']}" + (f" ({b['failure']})" if b.get("failure") else "")
                    + f", which left the cubes at: {report._cubes(b.get('ended'))}")
        lines += [f"- {s['kind']} · sitting {s['sitting']} · **{s['task']}** · {s.get('why') or '?'} · the camera saw: "
                  f"{report._cubes(s.get('seen'))} · the run saved last before it: {last(s.get('last_saved_before'))}"
                  for s in logged]
        lines += [""]
    lines += ["| Category | Passed (unassisted) | Runs |", "|---|---|---|"]
    for cat in sorted({r.get("category", "?") for _, r in rows}):
        mine = [r for _, r in rows if r.get("category") == cat]
        lines.append(f"| {cat} | {sum(bool(r.get('unassisted_pass', r.get('passed'))) for r in mine)} | {len(mine)} |")
    failures: dict = {}
    for _, r in rows:
        if r.get("failure"):
            failures[r["failure"]] = failures.get(r["failure"], 0) + 1
    lines += ["", "## Failures by type", "", ", ".join(f"{k}: {v}" for k, v in sorted(failures.items())) or "none"]
    lines += ["", "## Failed runs", ""]
    for name, r in rows:
        if not r.get("unassisted_pass", r.get("passed")):
            errs = ", ".join(f"{e} mm" for e in r.get("position_errors_mm") or []) or "-"
            d = r.get("difficulty") or {}
            hard = (f" · radius {d.get('max_radius_mm')} mm, reach margin {d.get('min_reach_margin_mm')} mm, "
                    f"turn {d.get('turn_asked_deg')}°, gap {d.get('min_gap_mm')} mm") if d else ""
            lines.append(f"- `{name}` · {r.get('task')} “{r.get('prompt')}” · {r.get('failure') or '?'} · errors "
                         f"{errs}{hard} · {r.get('error') or ''} {('· observer: ' + r['observer']['verdict']) if r.get('observer') else ''}")
    alarms = [(name, a) for name, r in rows for a in r.get("alarms", [])]
    lines += ["", "## Controller alarms", ""]
    for name, a in alarms:
        lines.append(f"- `{name}` · {' '.join(a.get('codes', []))} ({', '.join(a.get('phases', []))}) · joints "
                     f"{a.get('joints')} · target {a.get('target')} · "
                     f"{'cleared by the app' if a.get('auto_cleared') else 'needed a person'}")
    if not alarms:
        lines.append("none")
    refused = {k: sum((r.get("refusals") or {}).get(k, 0) for _, r in rows) for k in ("wasted", "guard", "robot", "other")}
    lines += ["", "## Refused steps", "",
              f"{sum(refused.values())} in {len(rows)} runs: wasted {refused['wasted']} (the model asked in a way "
              f"that couldn't work), guard {refused['guard']} (a safety check said no), robot {refused['robot']} "
              f"(the arm or gripper failed), other {refused['other']}.", "",
              "Reduce them by better choices, never by weakening a check.", ""]
    for name, r in rows:
        for reason in (r.get("refusals") or {}).get("reasons", []):
            lines.append(f"- `{name}` · {reason}")
    lines += ["", "## Motion per run", "", "| Run | Moves | Travel mm | Wrist turning deg | Seconds |", "|---|---|---|---|---|"]
    for name, r in rows:
        m = r.get("motion") or {}
        lines.append(f"| `{name}` | {m.get('moves', '-')} | {m.get('travel_mm', '-')} | "
                     f"{m.get('wrist_turning_deg', '-')} | {m.get('seconds', '-')} |")
    lines += ["", "Less motion is only better at the same or better accuracy (see the errors above)."]
    lines += _diagnostics(rows)
    interventions = [(name, i) for name, r in rows for i in r.get("interventions", [])]
    lines += ["", "## Interventions", ""] + ([f"- `{n}` · {i}" for n, i in interventions] or ["none"])
    moves = sum(r.get("moves", 0) for _, r in rows)
    lines += ["", f"Moves: {moves} · alarms per 100 moves: {100 * len(alarms) / moves:.1f}" if moves else ""]
    return "\n".join(lines) + "\n"


def _start_here(round_no: int, version: str, words: str, real: bool, label: str, previous: bool = False,
                kinds: Optional[list[str]] = None, notes: bool = False, logged: bool = False) -> str:
    prompt = ROUND_PROMPT.read_text(encoding="utf-8") if ROUND_PROMPT.exists() else ""
    prompt = prompt.replace("round N", f"round {round_no}").replace("study N", f"study {round_no}").replace("**<version>**", f"**{version}**")
    prompt = prompt.replace("NARRATION_vN", f"NARRATION_v{round_no}").replace("CHANGES_vN", f"CHANGES_v{round_no}")
    prompt = "\n".join("**Your input:** this package (see above)." if line.startswith("**Your input:**") else line
                       for line in prompt.splitlines())
    try:
        app = APP_VERSION.read_text(encoding="utf-8").strip()
    except OSError:
        app = "?"
    folders = ", ".join(f"`{k}\\`" for k in kinds or []) or "one folder per kind of data"
    head = [f"# Claude's input: {label}", "",
            f"**Data:** {words}.", f"**Made by:** Kyozo Link {app}.", ""]
    if not real:
        head += ["> **PRACTICE PACKAGE.** This is not study data. Use it to practise the improvement round only; "
                 "don't make study changes or write a study narration from it.", ""]
    head += [f"**Your input is this folder:** `{SUMMARY}` first (it opens with Twin vs Dobot, task by task), "
             f"then each kind of data's folder ({folders}; each named as in the results, after the watcher's "
             "Session menu: `…_for_Twin` the digital twin's, `…_for_Dobot` the real Dobot's). In each, "
             "`FULL_REPORT.md` holds the whole session in one file -- every run's result and which way it was off, "
             "its moves with distance, time and speed, the gripper, picks, alarms, the model's turns, and every step "
             "the model took; `full_report.json` holds the same as data to calculate from; `runs\\` has each run "
             "for detail (its `RUN_FULL_REPORT.md`, `run_report.txt`, `model_log.txt` (everything the model did, as "
             "the app's Model tab shows it), `run.json`, `trace.json`, `moves.csv`, `alarms.csv`, `observer.json`, "
             "and small start/end pictures). A run marked SKIPPED never started (the table wasn't READY): its "
             "record says why, what the camera saw, and the task before it and where that left the cubes"
             + (f", and `{PREVIOUS_SUMMARY}` (the study before, for context: what changed since)" if previous
                else "")
            + (f"; the tasks skipped before V4.2 (only logged then) are in `{SUMMARY}` and `{SKIPS_BEFORE_V42}`"
               if logged else "")
            + ("; and `notes\\`: the engineer's own reports on what went wrong, as written -- read them. A cause they "
               "place in the watcher (the measuring instrument) is fixed there and isn't yours to change; one in the "
               "app or the model's plan is" if notes else "")
            + ". Read nothing from any test folder: the test results are never part of your input.",
             "", "---", ""]
    return "\n".join(head) + prompt


def _diagnostics(rows: list[tuple[str, dict]]) -> list[str]:
    """Perception, arrival, where the time went, plans that repeated with different outcomes, time since homing."""
    import statistics
    lines = ["", "## Perception (where the app thought a cube was vs the watcher's own look at the start)", ""]
    offsets = [(name, o) for name, r in rows for o in r.get("perception_offsets_mm") or []]
    if offsets:
        lines.append(f"Median offset {statistics.median(o for _, o in offsets):.1f} mm over {len(offsets)} picks; "
                     "over 5 mm: " + (", ".join(f"`{n}` {o} mm" for n, o in offsets if o > 5.0) or "none"))
    else:
        lines.append("no picks recorded")
    lines += ["", "## Arrival (how far the arm ended from where it was sent, controller's reading)", ""]
    off = [(name, r["arrival"]) for name, r in rows if (r.get("arrival") or {}).get("moves")]
    worst = [f"`{n}` max {a['max_short_mm']} mm ({a.get('over_2mm', 0)} moves > 2 mm)" for n, a in off
             if (a.get("max_short_mm") or 0) > 2.0]
    lines.append("; ".join(worst) or "every move within 2 mm")
    lines += ["", "## Where the time went (median seconds per run)", ""]
    splits = [r["time_split"] for _, r in rows if r.get("time_split")]
    if splits:
        lines.append(", ".join(f"{k.replace('_s', '').replace('_', ' ')} {statistics.median(s.get(k, 0) for s in splits):.0f}"
                               for k in ("model_s", "camera_s", "arm_and_tools_s", "other_s")))
    lines += ["", "## Same plan, different outcome (the machine, not the model)", ""]
    groups: dict = {}
    for name, r in rows:
        key = (r.get("task"), (r.get("plan") or {}).get("full"))
        if key[1]:
            groups.setdefault(key, []).append((name, bool(r.get("unassisted_pass", r.get("passed")))))
    mixed = [f"{task}: " + ", ".join(f"`{n}` {'pass' if ok else 'fail'}" for n, ok in runs)
             for (task, _), runs in groups.items() if len({ok for _, ok in runs}) > 1]
    lines.append("; ".join(mixed) or "none (no task repeated the same plan with different outcomes)")
    homing = [(name, r["since_homing"]["minutes"], r.get("unassisted_pass", r.get("passed"))) for name, r in rows
              if (r.get("since_homing") or {}).get("minutes") is not None]
    if homing:
        lines += ["", "## Time since homing", "",
                  ", ".join(f"`{n}` {m} min {'pass' if ok else 'FAIL'}" for n, m, ok in homing)]
    return lines

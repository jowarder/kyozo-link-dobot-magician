"""Each run's model log: everything the Model tab shows for the run's prompts -- every model turn, its reasoning where
shown, every tool call with what the app did with it (its checks, every arm move and joint), and the checks at the
end -- in one file per run, next to its run.json:

    model_log.html    exactly the Model tab's page (open it in a browser)
    model_log.txt     the same, as plain text (Claude's package carries this one)

A task with "before" prompts gets them first, in order, then the task's own prompt. A run that stopped part-way (the
model timed out...) has no full record: its log lists the steps it got through.
"""
from __future__ import annotations

import logging
import re
from html.parser import HTMLParser
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

HTML_NAME, TEXT_NAME = "model_log.html", "model_log.txt"
_BLOCKS = {"p", "div", "br", "tr", "table", "h1", "h2", "h3", "h4", "li", "hr", "pre"}


class _Text(HTMLParser):
    """The page's words, line by line: a new line at each block, cells of a row joined with " | "."""

    def __init__(self):
        super().__init__()
        self.out: list[str] = []
        self._cell = False

    def handle_starttag(self, tag, attrs):
        if tag in _BLOCKS:
            self.out.append("\n")
            if tag == "hr":
                self.out.append("-" * 100 + "\n")
        elif tag in ("td", "th"):
            if self._cell:
                self.out.append(" | ")
            self._cell = True

    def handle_endtag(self, tag):
        if tag == "tr":
            self._cell = False
            self.out.append("\n")

    def handle_data(self, data):
        self.out.append(data)

    def text(self) -> str:
        raw = "".join(self.out)
        lines = [re.sub(r"[ \t\xa0]+", " ", line).strip() for line in raw.splitlines()]
        out, blank = [], False
        for line in lines:
            if not line:
                if not blank and out:
                    out.append("")
                blank = True
                continue
            out.append(line)
            blank = False
        return "\n".join(out).strip() + "\n"


def html_to_text(page: str) -> str:
    parser = _Text()
    parser.feed(page)
    return parser.text()


def write_model_log(folder: Path, traces: list[dict], header: str = "",
                    steps: Optional[list[dict]] = None) -> Optional[str]:
    """Writes model_log.html and model_log.txt in a run's folder from the Model tab's records of its prompts (the
    "before" prompts first). `steps`: a run without a full record (it stopped part-way) -- what it got through.
    Returns why not, if it couldn't (the run itself is saved either way)."""
    from watcher import results
    try:
        if traces:
            from app.ui.model_tab import render
            page = render(traces, standalone=True)
        else:
            rows = "".join(f"<p><b>{_esc(s.get('tool'))}</b>({_esc(s.get('args'))})<br/>→ {_esc(s.get('result'))}</p>"
                           for s in steps or [])
            page = ("<html><body style='background-color:#0f1c29; color:#d7e6f0; font-family:Segoe UI, sans-serif;'>"
                    "<p>The model's full record wasn't kept (the run stopped part-way). The steps it got through:</p>"
                    f"{rows or '<p>none</p>'}</body></html>")
        if header:
            page = _with_header(page, header)
        results.write_text(Path(folder) / HTML_NAME, page)
        results.write_text(Path(folder) / TEXT_NAME, html_to_text(page))
        return None
    except Exception as exc:  # noqa: BLE001 - a missing log is noted, not the end of the run
        logger.warning("Couldn't write the model log in %s: %s", folder, exc, exc_info=True)
        return str(exc)


def _esc(value) -> str:
    import html
    return html.escape(str(value))


def _with_header(page: str, header: str) -> str:
    """The run's heading (task, prompt, session) at the top of the page."""
    banner = ("<div style='padding:8px; margin-bottom:8px; border:1px solid #2a4459;'>"
              + "<br/>".join(_esc(line) for line in header.strip().splitlines()) + "</div>")
    at = page.find(">", page.find("<body"))
    return page[:at + 1] + banner + page[at + 1:] if at >= 0 else banner + page

"""Each run's whole story in one file, and each session's runs side by side in one workbook.

Per run (in its folder): run.json gets a "report" section, and run_report.txt says the same in words -- the task, the
conditions it ran in, the result (the watcher's and yours), the time and where it went, every event with its time,
and what happened, told from the recorded data by fixed rules (no model writes it: it can't invent anything, and the
same run always gives the same text). Your own note is added as you wrote it.

Per kind of data (study_N/20_Tasks_for_Dobot and the like; see watcher/results.py), remade after every saved run:
FULL_REPORT.md (every saved run in full: its result, which way it was off, its motion -- every move's distance, time,
speed and joints --, the gripper, picks, alarms, the model's turns, its report and every step the model took),
FULL_REPORT.html (the summary as a web page, each run linked), full_report.json (the same as data), results.xlsx and
results_*.csv (runs, moves, gripper, picks, alarms, model turns). And each saved run gets its own file:
User_Saved_<kind>/<task>_<tag>.md, and HTML_version/<task>_<tag>.html with its pictures built in. Without openpyxl
the workbook's sheets are written as .csv files instead; a workbook open in Excel (Windows locks it) is saved under a
new name rather than lost.

    python -m watcher.report <data folder>        remakes the reports (e.g. study_1/20_Tasks_for_Dobot)
"""
from __future__ import annotations

import csv
import json
import logging
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from watcher import results

logger = logging.getLogger(__name__)

REPORT_TXT = "run_report.txt"
FULL_MD = "FULL_REPORT.md"              # the whole session in one file: every run's report, measurements and the
FULL_JSON = "full_report.json"          # model's every step; and the same as data
FULL_HTML = "FULL_REPORT.html"
SESSION_XLSX = "results.xlsx"

# the Dobot Magician's controller alarms, in words (its communication protocol's alarm list)
ALARMS = {
    0x10: "planning: the pose has no solution (a singularity)",
    0x11: "planning: the joint angles couldn't be worked out",
    0x12: "planning: a joint would pass its limit (PLAN_INV_LIMIT)",
    0x20: "moving: a singularity on the way",
    0x21: "moving: the joint angles couldn't be worked out on the way",
    0x22: "moving: a joint would pass its limit on the way (MOVE_INV_LIMIT)",
    0x40: "the base (J1) at its positive limit", 0x41: "the base (J1) at its negative limit",
    0x42: "the rear arm (J2) at its positive limit", 0x43: "the rear arm (J2) at its negative limit",
    0x44: "the forearm (J3) at its positive limit", 0x45: "the forearm (J3) at its negative limit",
    0x46: "the wrist (J4) at its positive limit", 0x47: "the wrist (J4) at its negative limit",
    0x48: "the arms' parallelogram at its positive limit (LIMIT_AXIS23_POS)",
    0x49: "the arms' parallelogram at its negative limit: the forearm too low for the rear arm (LIMIT_AXIS23_NEG)",
}
FAILURE_WORDS = {
    "infrastructure": "infrastructure: Ollama, the camera or the PC failed, not the robot (the run is repeated)",
    "plan": "plan: Qwen chose the wrong cube, action or direction",
    "preparation": "preparation: moving a cube out of the way (a tower taken down, a cube put aside) failed",
    "limit_alarm": "limit alarm: the arm couldn't reach the pose",
    "perception": "perception: the app saw a cube more than 5 mm from where it was",
    "execution": "execution: a missed grip, slip, drop, or a placement or angle error",
    "unclassified": "unclassified",
}
VERDICT_WORDS = {"pass": "Pass", "fail": "Fail", "dropped": "Dropped", "helped": "I had to help",
                 "skipped": "skipped (the twin scored itself)"}
CATEGORIES = {"A": "zone", "B": "relative move", "C": "beside / between", "D": "rotation", "E": "rows",
              "F": "sorting", "G": "swap", "H": "undo / empty"}


def pass_word(run: dict) -> str:
    """The watcher's result in a word: PASS, FAIL -- NO TARGET for a prompt typed with Watcher active (recorded like a
    run, but with nothing to score it against: passed is None) -- or SKIPPED for a 20 Tasks task that never started
    (the table wasn't READY: saved as a run with why, not a pass or a fail, counted apart)."""
    if run.get("skipped"):
        return "SKIPPED"
    if run.get("passed") is None and run.get("no_target"):
        return "NO TARGET"
    if run.get("outcome") in ("PASS", "SOME PARTS", "FAIL"):     # (V4.2: a chained set's runs)
        return run["outcome"]
    return "PASS" if run.get("passed") else "FAIL"


def flag_words(run: dict) -> str:
    """" · CATASTROPHIC" when something went badly wrong (V4.2), else ""."""
    return " · CATASTROPHIC" if run.get("catastrophic") else ""


def scene_lines(run: dict) -> list[str]:
    """The table the run started from, and what went badly wrong, in words (V4.2: a chained set's runs)."""
    out = []
    if run.get("start_condition"):
        out.append("The table as the task before left it: " + ", ".join(run["start_condition"]) + ".")
    scene = run.get("scene") or {}
    if scene.get("hidden"):
        out.append("Under a tower: " + ", ".join(f"the {h} under the {t}" for h, t in scene["hidden"].items()) + ".")
    if scene.get("missing"):
        out.append(f"Couldn't be seen (looked {scene.get('looks', '?')} times from {scene.get('arm_positions', '?')} "
                   f"arm position(s)): {', '.join(scene['missing'])}.")
    for part in run.get("parts") or []:
        if not part.get("possible"):
            out.append(f"Part {part['part']} ({part['kind']}) was impossible from this start: {part['why']}.")
    for what in run.get("prepared") or []:
        out.append(f"Moved out of the way, as allowed: {what}.")
    for what in run.get("catastrophic") or []:
        out.append(f"CATASTROPHIC: {what}.")
    return out


def skipped_lines(skip: dict) -> list[str]:
    """A skipped task in words: why, who skipped it and after how long, what the camera saw, the task before it and
    where it left the cubes, and the set-out -- what Claude needs to find what left the table so."""
    lines = [f"It never started: {skip.get('why') or 'the table was not READY'}."]
    lines.append(f"Skipped by {skip.get('by') or 'the watcher'}"
                 + (f" after {skip['waited_s']:.0f} s" if skip.get("waited_s") is not None else "")
                 + (f" ({skip['table_checks']} looks at the table)" if skip.get("table_checks") else "") + ".")
    lines.append(f"The camera saw: {_cubes(skip.get('seen'))}.")
    if skip.get("expected"):                       # what the task needed vs what was there, cube by cube
        lines.append("Where this task needed them (had every task before gone as asked) vs where they were: " + "; ".join(
            f"{e['cube']} wanted ({e['wanted'][0]:.0f}, {e['wanted'][1]:.0f})"
            + (f" level {e['wanted_level']}" if (e.get("wanted_level") or 1) > 1 else "")
            + (f", seen ({e['seen'][0]:.0f}, {e['seen'][1]:.0f})"
               + (f" level {e['seen_level']}" if (e.get("seen_level") or 1) > 1 else "")
               + f", {e['off_mm']:.0f} mm off" if e.get("seen") else ", NOT SEEN")
            for e in skip["expected"]) + ".")

    def ran(r: dict) -> str:
        return (f"{r.get('run') or r.get('task')}, {r.get('result')}"
                + (f" ({r['failure']})" if r.get("failure") else "")
                + (f", score {r['score_100']}/100" if r.get("score_100") is not None else "")
                + f"; it left the cubes at: {_cubes(r.get('ended'))}")
    before = skip.get("task_before")
    if before:
        lines.append(f"The task before: {ran(before)}.")
        if "last_ran" in before:                   # (skipped too: back to the last task that did run)
            lines.append(f"The last task that ran: {ran(before['last_ran'])}." if before["last_ran"] else
                         "No task ran before it in this sitting.")
    else:
        lines.append("The task before: none in this sitting (the first task of the session).")
    set_out = skip.get("set_out")
    if set_out:
        lines.append("The set-out at the session's start: " + ("done" if set_out.get("ok") else
                                                                f"FAILED ({set_out.get('why')})")
                     + (f", {set_out['moves']}" if set_out.get("moves") else "") + ".")
        for s in set_out.get("refused") or []:
            lines.append(f"Refused in the set-out: {s.get('tool')}({_short_args(s.get('args'))}): {s.get('result')}")
    lines.append("Not a pass or a fail: counted apart from the runs that ran.")
    return lines


def category_words(code) -> str:
    return f"{code}, {CATEGORIES[code]}" if code in CATEGORIES else str(code)


def _quoted(text: str) -> str:
    """Words in quotes, ending a sentence once (not '..."put it here.".')."""
    text = str(text or "").strip()
    return f'"{text}"' + ("" if text[-1:] in ".!?" else ".")


def step_words(tool: str, result: str) -> str:
    """What a step's result says, short: list_objects' table read out ("3 objects: red cube at (200, 60), ..."), any
    other step's first sentence."""
    text = str(result or "")
    if tool == "list_objects" and not text.startswith("ERROR"):
        import ast
        try:
            seen = ast.literal_eval(text)
            objects = seen.get("objects", [])
            held = seen.get("holding")
            return (f"{len(objects)} object{'s' if len(objects) != 1 else ''}"
                    + (": " + ", ".join(f"{o.get('label')} at ({o['xyz_mm'][0]:.0f}, {o['xyz_mm'][1]:.0f})"
                                        for o in objects) if objects else "")
                    + (f"; holding {held}" if held else ""))
        except (ValueError, SyntaxError, TypeError, KeyError, IndexError, AttributeError):
            pass                        # (cut short at 400 characters: read out as it is)
    return _first_sentence(text.replace("ERROR: ", "refused: ", 1))


def alarm_words(code: str) -> str:
    try:
        return f"{code} ({ALARMS.get(int(code, 16), 'controller alarm')})"
    except (TypeError, ValueError):
        return str(code)


def _first_sentence(text: str, limit: int = 220) -> str:
    text = " ".join(str(text or "").split())
    for stop in (". ", "! ", "? "):
        if stop in text[:limit]:
            return text[:text.index(stop, 0, limit) + 1]
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _short_args(args) -> str:
    if not isinstance(args, dict) or not args:
        return ""
    return ", ".join(f"{k}={v}" for k, v in args.items())


def _when(epoch: Optional[float], start: Optional[float]) -> Optional[float]:
    return round(epoch - start, 1) if epoch is not None and start is not None else None


# ---- one run ---------------------------------------------------------------------------------------------------------
def _traced_calls(trace: Optional[dict]) -> list[dict]:
    return [c for turn in (trace or {}).get("turns") or [] for c in (turn.get("calls") or [])]


def full_results(run: dict, trace: Optional[dict]) -> list[str]:
    """Each step's result in full: from the model's record (trace.json) where it lines up with the step, else as
    run.json kept it (its first 400 characters)."""
    traced = _traced_calls(trace)
    out = []
    for i, call in enumerate(run.get("calls") or []):
        full = None
        if i < len(traced) and traced[i].get("name") == call.get("tool"):
            full = (traced[i].get("app") or {}).get("result")
        out.append(str(full) if full is not None else str(call.get("result", "")))
    return out


def timeline(run: dict, trace: Optional[dict]) -> list[dict]:
    """Every event of the run, in time order, as {"t": seconds from the start (or None), "kind", "what"}: each step Qwen
    chose and what the app said to it, and what the robot reported (moves, refusals, clamps, the gripper, alarms,
    E-STOP, a person clearing an alarm)."""
    t0 = run.get("started_epoch")
    out: list[dict] = []
    day = datetime.fromtimestamp(t0).date() if t0 else None
    calls = run.get("calls") or []
    turns = (trace or {}).get("turns") or []
    turn_calls = [(turn, call) for turn in turns for call in (turn.get("calls") or [])]
    traced = [c for _, c in turn_calls]
    results_full = full_results(run, trace)
    for i, call in enumerate(calls):
        t = None
        took = None
        if i < len(traced) and traced[i].get("name") == call.get("tool"):
            took = (traced[i].get("app") or {}).get("seconds")
        if call.get("t_end") is not None:          # when it started: its end, less how long the app took on it
            t = round(float(call["t_end"]) - float(took or 0.0), 1)
        elif i < len(turn_calls) and day is not None and turn_calls[i][0].get("time"):
            try:                                   # (a run saved before steps were timed: the model's clock, to 1 s)
                clock = datetime.strptime(turn_calls[i][0]["time"], "%H:%M:%S").time()
                t = _when(datetime.combine(day, clock).timestamp(), t0)
            except ValueError:
                t = None
        result = results_full[i] if i < len(results_full) else str(call.get("result", ""))
        refused = result.startswith("ERROR")
        out.append({"t": t, "kind": "refused step" if refused else "step",
                    "what": f"Qwen: {call.get('tool')}({_short_args(call.get('args'))}) -> "
                            + step_words(call.get("tool"), result)})
    for e in run.get("events_log") or []:
        out.append({"t": e.get("t"), "kind": e.get("kind"), "what": e.get("what", "")})
    return sorted(out, key=lambda e: (e["t"] is None, e["t"] if e["t"] is not None else 0.0))


def events_log(events: list[dict], started_epoch: Optional[float]) -> list[dict]:
    """The robot's events (as the watcher heard them) made short and timed from the run's start, for run.json."""
    out = []
    for e in events:
        kind, t = e.get("kind"), _when(e.get("t"), started_epoch)
        if kind == "move":
            target = e.get("target") or {}
            where = f"({target.get('x', 0):.0f}, {target.get('y', 0):.0f}, {target.get('z', 0):.0f}, r {target.get('r', 0):.0f})"
            what = f"arm to {where}" + ("" if e.get("ok", True) else f": FAILED ({e.get('error', '')})")
            kind = "move" if e.get("ok", True) else "move failed"
        elif kind == "alarm":
            what = ("controller alarm " + ", ".join(alarm_words(c) for c in e.get("codes", []))
                    + (f"; joints {e.get('joints')}" if e.get("joints") else "")
                    + ("; cleared by the app" if e.get("auto_cleared") else "; needed a person"))
        elif kind == "clamp":
            asked, to = e.get("asked") or {}, e.get("to") or {}
            what = (f"move clamped to the safety box: asked ({asked.get('x', 0):.0f}, {asked.get('y', 0):.0f}, "
                    f"{asked.get('z', 0):.0f}), went to ({to.get('x', 0):.0f}, {to.get('y', 0):.0f}, {to.get('z', 0):.0f})")
        elif kind == "gripper":
            what = "gripper closed" if e.get("closed") else "gripper opened"
        elif kind == "estop":
            what = "E-STOP pressed"
        elif kind == "alarm_cleared_by_hand":
            what = "an alarm cleared by a person (Clear Alarms)"
        elif kind == "home":
            what = "the arm homed"
        else:
            what = kind or "?"
        out.append({"t": t, "kind": kind, "what": what})
    return out


def build_report(run: dict, session: dict, trace: Optional[dict] = None, judge: Optional[list[str]] = None,
                 files: Optional[list[str]] = None) -> dict:
    """The run's report: everything about it in one place (see the module's notes)."""
    observer = run.get("observer") or {}
    score = run.get("score") or {}
    split = run.get("time_split") or {}
    watcher_pass = bool(run.get("passed"))
    verdict = observer.get("verdict")
    agree = None if verdict in (None, "skipped", "skip", "helped") or run.get("no_target") else (
        (verdict == "pass") == watcher_pass)          # ("I had to help" said nothing about the end: it isn't a "fail")
    events = timeline(run, trace)
    report = {
        "task": {"id": run.get("task"), "category": run.get("category"), "level": run.get("level"),
                 "layout": run.get("layout"),
                 "prompt": run.get("prompt"), "said_before": run.get("before") or [], "repeat": run.get("repeat"),
                 "start_layout": run.get("layout_start") or [], "pass_if": judge or []},
        "run": {"session": session.get("folder_name"), "run": run.get("folder_name"),
                "number_in_session": run.get("session_run"), "started": run.get("started_at"),
                "real_test": bool(session.get("real")), "set": session.get("set"), "round": session.get("round"),
                "version": session.get("version"), "where": session.get("where")},
        "result": {"watcher": pass_word(run), "observer": VERDICT_WORDS.get(verdict, verdict),
                   "observer_sure": observer.get("confidence") != "unsure", "agree": agree,
                   "unassisted_pass": bool(run.get("unassisted_pass", run.get("passed"))),   # (the twin script has no helper)
                   # partial credit, next to the strict pass / fail (watcher/tasks.py partial_credit; older runs: none)
                   "score_100": (run.get("credit") or {}).get("score"), "band": (run.get("credit") or {}).get("band"),
                   "failure_type": run.get("failure"), "failure_words": FAILURE_WORDS.get(run.get("failure"), ""),
                   "targets": score.get("targets") or [], "collateral": score.get("collateral") or [],
                   "missing": score.get("missing") or [],
                   "position_errors_mm": run.get("position_errors_mm") or [],
                   "angle_errors_deg": run.get("angle_errors_deg") or [],
                   "interventions": run.get("interventions") or [], "repeated_for_infrastructure":
                       bool(run.get("repeated")), "excluded": run.get("excluded"), "error": run.get("error"), "skipped": run.get("skipped"),
                   "outcome": run.get("outcome"), "catastrophic": run.get("catastrophic") or [],
                   "start_condition": run.get("start_condition") or [], "parts": run.get("parts") or [],
                   "prepared": run.get("prepared") or []},
        "time": {"total_s": run.get("seconds"), "setting_up_s": (run.get("setup_effort") or {}).get("seconds"),
                 "qwen_deciding_s": split.get("model_s"), "camera_looking_s": split.get("camera_s"),
                 "arm_and_tools_s": split.get("arm_and_tools_s"), "other_s": split.get("other_s")},
        "counts": {"steps": len(run.get("calls") or []), "refused_steps": (run.get("refusals") or {}).get("total", 0)
                   if isinstance(run.get("refusals"), dict) else run.get("refusals"),
                   "moves": run.get("moves"), "failed_moves": run.get("failed_moves"), "clamps": run.get("clamps"),
                   "alarms": len(run.get("alarms") or []), "picks": run.get("picks")},
        "events": events,
        "qwen_final_reply": run.get("reply") or "",
        "observer_note": observer.get("note") or "",
        "caliper": observer.get("caliper"),
        "conditions": {k: session.get(k) for k in (
            "app_mode", "model", "model_digest", "temperature", "seed", "git_commit", "calibration_file",
            "calibration_sha256", "calibration", "camera", "detection", "table_z_mm", "cube_set", "cube_size_mm", "mode",
            "task_file_sha256")},
        "files": files or [],
    }
    report["what_happened"] = narrative(report, dict(run, full_results=full_results(run, trace)))
    return report


def narrative(report: dict, run: dict) -> str:
    """What happened, in words, from the recorded data only (fixed rules: the same run always gives the same text)."""
    task, result, timing, counts = report["task"], report["result"], report["time"], report["counts"]
    parts = []
    parts.append(f"Task {task['id']} (category {category_words(task['category'])}, layout {task['layout']}), "
                 f"repeat {task['repeat']}: {_quoted(task['prompt'])}"
                 + (" Said before it: " + "; ".join(f'"{b}"' for b in task['said_before']) + "."
                    if task["said_before"] else ""))
    if task["pass_if"]:
        parts.append("It passes if " + "; and ".join(task["pass_if"]) + ".")
    if result.get("skipped"):                      # (it never started: why, and what left the table so)
        parts.append("SKIPPED. " + " ".join(skipped_lines(result["skipped"])))
        return "\n\n".join(parts)
    scene = scene_lines(run)
    if scene:                                      # (V4.2: the table it started from, what went badly wrong)
        parts.append(" ".join(scene))
    setup = run.get("setup_effort") or {}
    seen = run.get("start_seen") or []
    line = (f"The cubes were set out in {setup.get('seconds', '?')} s; at the start the camera saw "
            f"{len(seen)} cube{'s' if len(seen) != 1 else ''}"
            + (" (" + ", ".join(f"{c.get('label', '?')} at ({c.get('x', 0):.0f}, {c.get('y', 0):.0f})" for c in seen)
               + ")" if seen else "") + ".")
    if run.get("started_anyway"):
        line += " The run was started although not every cube was on its outline."
    parts.append(line)
    calls = run.get("calls") or []
    if calls:
        steps = []
        full = run.get("full_results") or []
        for i, call in enumerate(calls, start=1):
            res = full[i - 1] if i - 1 < len(full) else str(call.get("result", ""))
            verb = "was refused" if res.startswith("ERROR") else "gave"
            said = step_words(call.get("tool"), res).replace("refused: ", "", 1).rstrip(".")
            steps.append(f"({i}) {call.get('tool')}({_short_args(call.get('args'))}) {verb}: {said}")
        parts.append(f"Qwen took {len(calls)} step{'s' if len(calls) != 1 else ''}: " + "; ".join(steps) + ".")
    else:
        parts.append("Qwen took no step.")
    if report["qwen_final_reply"]:
        parts.append(f"Its final reply: {_quoted(_first_sentence(report['qwen_final_reply'], 400))}")
    arm = (f"The arm made {counts.get('moves') or 0} move{'s' if counts.get('moves') != 1 else ''}"
           + (f", {counts['failed_moves']} of them failed" if counts.get("failed_moves") else "")
           + (f", {counts['clamps']} clamped to the safety box" if counts.get("clamps") else "") + ".")
    alarms = run.get("alarms") or []
    if alarms:
        arm += " Controller alarms: " + "; ".join(
            ", ".join(alarm_words(c) for c in a.get("codes", []))
            + (" -- cleared by the app" if a.get("auto_cleared") else " -- needed a person") for a in alarms) + "."
    else:
        arm += " No controller alarm."
    parts.append(arm)
    if result["error"]:
        parts.append(f"It stopped with an error: {result['error']}.")
    if result["interventions"]:
        parts.append("Interventions: " + "; ".join(str(i) for i in result["interventions"]) + ".")
    checks = []
    for target in result["targets"]:
        bits = [target.get("kind", "?"), "met" if target.get("ok") else "NOT met"]
        if target.get("position_error_mm") is not None:
            bits.append(f"{target['position_error_mm']:.1f} mm off")
        if target.get("angle_error_deg") is not None:
            bits.append(f"{target['angle_error_deg']:.1f}° off")
        if target.get("detail"):
            bits.append(str(target["detail"]))
        checks.append(" ".join(bits[:2]) + (f" ({', '.join(bits[2:])})" if len(bits) > 2 else ""))
    end = ("A typed prompt (Watcher active): nothing to score it against, so no pass or fail; what it did is told "
           "above, and where each cube ended is in the run's files." if result["watcher"] == "NO TARGET" else
           f"At the end the watcher scored it {result['watcher']}" + (": " + "; ".join(checks) if checks else "") + ".")
    if result["collateral"]:
        end += " Moved though it shouldn't have: " + ", ".join(result["collateral"]) + "."
    if result["missing"]:
        end += " Not seen at the end: " + ", ".join(result["missing"]) + "."
    if result["failure_type"]:
        end += f" Failure type: {result['failure_words'] or result['failure_type']}."
    if result["watcher"] == "PASS":
        end += " An unassisted pass." if result["unassisted_pass"] else " A pass, but not unassisted."
    elif result["watcher"] == "SOME PARTS":
        end += (f" Some parts done: {sum(bool(t.get('ok')) for t in result['targets'])} of {len(result['targets'])} "
                "targets met.")
    parts.append(end)
    if result["observer"]:
        verdict = (f"Your verdict: {result['observer']}{'' if result['observer_sure'] else ' (unsure)'}"
                   + ("" if result["agree"] is None else
                      ", agreeing with the watcher" if result["agree"] else ", DISAGREEING with the watcher") + ".")
        parts.append(verdict)
    if report["observer_note"]:
        parts.append(f"Your note, as written: {_quoted(report['observer_note'])}")
    if report.get("caliper"):
        parts.append(f"Caliper check: {report['caliper']}")
    if timing["total_s"] is not None:
        split = [f"{label} {timing[key]:.0f} s" for key, label in (
            ("qwen_deciding_s", "Qwen deciding"), ("camera_looking_s", "the camera looking"),
            ("arm_and_tools_s", "the arm and tools"), ("other_s", "the rest")) if timing.get(key) is not None]
        parts.append(f"It took {timing['total_s']:.0f} s" + (f": {', '.join(split)}." if split else "."))
    if result["repeated_for_infrastructure"]:
        parts.append("Because the failure was the infrastructure's, this run is repeated and left out of the counts.")
    return "\n\n".join(parts)


def report_text(report: dict) -> str:
    """run_report.txt: the report in words, top to bottom."""
    task, run, result, timing = report["task"], report["run"], report["result"], report["time"]
    rule = "=" * 78
    lines = [rule, f"RUN REPORT  {run.get('run') or ''}", rule, "",
             "TASK",
             f"  Task:        {task['id']}   category {category_words(task['category'])}, layout {task['layout']}, "
             f"repeat {task['repeat']}",
             f'  Prompt:      "{task["prompt"]}"']
    for before in task["said_before"]:
        lines.append(f'  Said before: "{before}"')
    if task["pass_if"]:
        lines.append("  Pass if:     " + "\n               ".join(task["pass_if"]))
    if task["start_layout"]:
        lines.append("  Start:       " + "; ".join(f"{c.get('label', '?')} at ({c.get('x', 0):.0f}, {c.get('y', 0):.0f})"
                                                   + (f" turned {c.get('yaw', 0):.0f}°" if c.get("yaw") else "")
                                                   for c in task["start_layout"]))
    lines += ["", "RUN",
              f"  {'REAL TEST' if run['real_test'] else 'Practice'} · set {run.get('set')} · round {run.get('round')} · "
              f"version {run.get('version')} · {run.get('where')}",
              f"  Session:     {run.get('session')}   run {run.get('number_in_session')}",
              f"  Started:     {run.get('started')}",
              "", "RESULT",
              f"  Watcher:     {result['watcher']}" + (f"   ({'unassisted' if result['unassisted_pass'] else 'not unassisted'})"
                                                       if result["watcher"] == "PASS" else "")]
    if result.get("skipped"):
        lines.append("  Skipped:")
        for line in skipped_lines(result["skipped"]):
            lines += _wrap(line, 4)
    if result.get("score_100") is not None:
        lines.append(f"  Score:       {result['score_100']}/100 ({result.get('band')}): partial credit, how close it came")
    if result.get("start_condition"):
        lines.append(f"  Start:       {', '.join(result['start_condition'])}")
    for what in result.get("catastrophic") or []:
        lines.append(f"  CATASTROPHIC: {what}")
    for what in result.get("prepared") or []:
        lines.append(f"  Prepared:    {what}")
    lines += [f"  You:       {result['observer'] or '-'}{'' if result['observer_sure'] else ' (unsure)'}"
              + ("" if result["agree"] is None else ("   agree" if result["agree"] else "   DISAGREE"))]
    if result["failure_type"]:
        lines.append(f"  Failure:     {result['failure_words'] or result['failure_type']}")
    for target in result["targets"]:
        bits = [f"{target.get('position_error_mm'):.1f} mm" if target.get("position_error_mm") is not None else "",
                f"{target.get('angle_error_deg'):.1f}°" if target.get("angle_error_deg") is not None else ""]
        lines.append(f"  Target:      {target.get('kind')}: {'met' if target.get('ok') else 'NOT met'}  "
                     + "  ".join(b for b in bits if b) + (f"  {target.get('detail')}" if target.get("detail") else ""))
    if result["collateral"]:
        lines.append("  Knocked:     " + ", ".join(result["collateral"]))
    if result["interventions"]:
        lines.append("  Helped:      " + "; ".join(str(i) for i in result["interventions"]))
    if result["error"]:
        lines.append(f"  Error:       {result['error']}")
    lines += ["", "TIME"]
    for key, label in (("total_s", "Total"), ("setting_up_s", "Setting up"), ("qwen_deciding_s", "Qwen deciding"),
                       ("camera_looking_s", "Camera looking"), ("arm_and_tools_s", "Arm and tools"),
                       ("other_s", "The rest")):
        if timing.get(key) is not None:
            lines.append(f"  {label + ':':<17}{timing[key]:.1f} s")
    lines += ["", "EVENTS"]
    for e in report["events"]:
        when = f"{e['t']:7.1f} s" if e["t"] is not None else "      -  "
        lines.append(f"  {when}  {e['what']}")
    if not report["events"]:
        lines.append("  (none recorded)")
    lines += ["", "WHAT HAPPENED", ""]
    for paragraph in report["what_happened"].split("\n\n"):
        lines += _wrap(paragraph, 2) + [""]
    cond = report["conditions"]
    lines += ["CONDITIONS",
              f"  Qwen:        {cond.get('model')} (digest {str(cond.get('model_digest') or '')[:12]}), temperature "
              f"{cond.get('temperature')}, seed {cond.get('seed')}",
              f"  App:         commit {str(cond.get('git_commit') or '')[:10]}, {cond.get('app_mode')}"]
    if cond.get("calibration_file"):
        lines.append(f"  Calibration: {cond.get('calibration') or ''}  [{cond.get('calibration_file')}, sha256 "
                     f"{str(cond.get('calibration_sha256') or '')[:12]}]")
    else:
        lines.append("  Calibration: none recorded")
    if cond.get("camera"):
        lines.append(f"  Camera:      {json.dumps(cond['camera'], default=str)}")
    if cond.get("detection"):
        lines.append(f"  Detection:   {cond['detection']}")
    lines.append(f"  Table:       z {cond.get('table_z_mm')} mm; cube set {cond.get('cube_set')}; cubes "
                 f"{cube_size_of(report):g} mm; mode {cond.get('mode')}")
    if report["files"]:
        lines += ["", "FILES (in this folder)", "  " + ", ".join(report["files"])]
    return "\n".join(lines) + "\n"


def _wrap(text: str, indent: int, width: int = 100) -> list[str]:
    import textwrap
    return textwrap.wrap(text, width=width, initial_indent=" " * indent, subsequent_indent=" " * indent) or [""]


def write_run_report(run_folder: Path, run: dict, session: dict, judge: Optional[list[str]] = None) -> dict:
    """Builds the run's report from what is saved in its folder, puts it in run.json and writes run_report.txt."""
    trace = None
    try:
        trace = json.loads((run_folder / "trace.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    run = dict(run, folder_name=run_folder.name)
    session = dict(session, folder_name=run_folder.parent.parent.name)
    files = sorted(p.name for p in run_folder.iterdir() if p.is_file() and not p.name.endswith(".part")
                   and p.name not in ("run.json", REPORT_TXT))
    report = build_report(run, session, trace, judge or run.get("how_to_judge"), files)
    stored = dict(run)
    stored.pop("folder_name", None)
    stored["report"] = report
    results.write_json(run_folder / "run.json", stored)
    results.write_text(run_folder / REPORT_TXT, report_text(report))
    return report


# ---- one session ---------------------------------------------------------------------------------------------------
def cube_size_of(report: dict) -> float:
    """The cubes' size a run used, as its session recorded it; 25 mm for runs from before it was recorded (every
    study's cubes were 25 mm until 2026-10-26)."""
    return float((report.get("conditions") or {}).get("cube_size_mm") or 25.0)


RUN_COLUMNS = (
    ("#", lambda r: r.get("n") or r["run"].get("number_in_session")), ("Run folder", lambda r: r["run"].get("run")),
    ("Task", lambda r: r["task"]["id"]), ("Level", lambda r: r["task"].get("level")),
    ("Category", lambda r: r["task"]["category"]),
    ("Layout", lambda r: r["task"]["layout"]), ("Repeat", lambda r: r["task"]["repeat"]),
    ("Cubes (mm)", lambda r: cube_size_of(r)),
    ("Prompt", lambda r: r["task"]["prompt"]), ("Watcher", lambda r: r["result"]["watcher"]),
    ("Catastrophic", lambda r: "; ".join(r["result"].get("catastrophic") or [])),
    ("Start condition", lambda r: ", ".join(r["result"].get("start_condition") or [])),
    ("Score (0-100)", lambda r: r["result"].get("score_100")), ("Band", lambda r: r["result"].get("band")),
    ("Your verdict", lambda r: r["result"]["observer"]),
    ("Agree", lambda r: None if r["result"]["agree"] is None else ("yes" if r["result"]["agree"] else "NO")),
    ("Unassisted pass", lambda r: "yes" if r["result"]["unassisted_pass"] else "no"),
    ("Failure type", lambda r: r["result"]["failure_type"]),
    ("Position errors (mm)", lambda r: ", ".join(f"{e:.1f}" for e in r["result"]["position_errors_mm"])),
    ("Angle errors (°)", lambda r: ", ".join(f"{e:.1f}" for e in r["result"]["angle_errors_deg"])),
    ("Knocked", lambda r: ", ".join(r["result"]["collateral"])),
    ("Time (s)", lambda r: r["time"]["total_s"]), ("Qwen (s)", lambda r: r["time"]["qwen_deciding_s"]),
    ("Arm and tools (s)", lambda r: r["time"]["arm_and_tools_s"]), ("Setting up (s)", lambda r: r["time"]["setting_up_s"]),
    ("Steps", lambda r: r["counts"]["steps"]), ("Refused steps", lambda r: r["counts"]["refused_steps"]),
    ("Moves", lambda r: r["counts"]["moves"]), ("Failed moves", lambda r: r["counts"]["failed_moves"]),
    ("Alarms", lambda r: r["counts"]["alarms"]),
    ("Interventions", lambda r: "; ".join(str(i) for i in r["result"]["interventions"])),
    ("Repeated (infrastructure)", lambda r: "yes" if r["result"]["repeated_for_infrastructure"] else ""),
    ("Started", lambda r: r["run"].get("started")), ("Your note", lambda r: r["observer_note"]),
    ("What happened", lambda r: r["what_happened"]),
)


def session_reports(session_folder: Path) -> list[dict]:
    """Every run's report in a session, in order (made now for a run saved before reports existed)."""
    info = _info_of(session_folder)
    out = []
    for n, path in enumerate([f / "run.json" for f in _run_folders(session_folder)], start=1):
        try:
            run = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("Couldn't read %s: %s", path, exc)
            continue
        report = run.get("report")
        if "passed" in run and (report is None or (report.get("run") or {}).get("run") != path.parent.name):
            report = write_run_report(path.parent, run, info)   # (made in _pending, before Save moved it: again)
        if report is not None:
            # (its place among the folders -- the "#" every sheet of the workbook joins on; the sitting's own number
            # starts at 1 each sitting -- and its folder, for the link to its report)
            out.append(dict(report, n=n, folder=path.parent.relative_to(session_folder).as_posix()))
    return out


def summary(reports: list[dict]) -> dict:
    # (a skipped task never started: saved, but counted apart -- not a pass or a fail)
    skipped = [r for r in reports if r["result"].get("skipped")]
    counted = [r for r in reports if not r["result"]["repeated_for_infrastructure"] and not r["result"].get("excluded")
               and not r["result"].get("skipped")]
    by_level: dict = {}
    for r in counted:
        c = by_level.setdefault(str(r["task"].get("level") or "-"), {"runs": 0, "passed": 0, "unassisted": 0})
        c["runs"] += 1
        c["passed"] += r["result"]["watcher"] == "PASS"
        c["unassisted"] += r["result"]["unassisted_pass"]
    by_category: dict = {}
    for r in counted:
        c = by_category.setdefault(r["task"]["category"], {"runs": 0, "passed": 0, "unassisted": 0})
        c["runs"] += 1
        c["passed"] += r["result"]["watcher"] == "PASS"
        c["unassisted"] += r["result"]["unassisted_pass"]
    failures: dict = {}
    for r in counted:
        if r["result"]["failure_type"]:
            failures[r["result"]["failure_type"]] = failures.get(r["result"]["failure_type"], 0) + 1
    moves = sum(r["counts"]["moves"] or 0 for r in counted)
    alarms = sum(r["counts"]["alarms"] or 0 for r in counted)
    times = [r["time"]["total_s"] for r in counted if r["time"]["total_s"] is not None]
    scored = [r for r in counted if r["result"].get("score_100") is not None]      # (partial credit: newer runs)
    score_by_level: dict = {}
    for r in scored:
        score_by_level.setdefault(str(r["task"].get("level") or "-"), []).append(r["result"]["score_100"])
    credit = {"scored": len(scored),
              "mean_score": round(sum(r["result"]["score_100"] for r in scored) / len(scored), 1) if scored else None,
              "bands": {b: sum(r["result"].get("band") == b for r in scored) for b in ("Full", "Partial", "Fail")},
              "mean_score_by_level": {k: round(sum(v) / len(v), 1) for k, v in sorted(score_by_level.items())}}
    outcomes = {w: sum(r["result"]["watcher"] == w for r in counted) for w in ("PASS", "SOME PARTS", "FAIL")}
    conditions: dict = {}
    for r in counted:
        for c in r["result"].get("start_condition") or []:
            conditions[c] = conditions.get(c, 0) + 1
    return {"runs": len(reports), "counted": len(counted), "skipped": len(skipped), "credit": credit,
            "outcomes": outcomes, "catastrophic": sum(bool(r["result"].get("catastrophic")) for r in reports),
            "start_conditions": conditions,
            "passed": sum(r["result"]["watcher"] == "PASS" for r in counted),
            "unassisted_passes": sum(r["result"]["unassisted_pass"] for r in counted),
            "disagreements": sum(r["result"]["agree"] is False for r in counted),
            "by_category": by_category, "by_level": by_level, "failures": failures, "moves": moves, "alarms": alarms,
            "alarms_per_100_moves": round(100.0 * alarms / moves, 1) if moves else None,
            "mean_time_s": round(sum(times) / len(times), 1) if times else None,
            "interventions": sum(len(r["result"]["interventions"]) for r in counted)}


def write_session_results(session_folder: Path) -> Optional[Path]:
    """The reports of a kind's folder (or an old session's): FULL_REPORT.md / .html, full_report.json, results.xlsx
    and results_*.csv, remade from its saved runs, so it can be called after every Save. The workbook's path (or None
    if only .csv files could be written)."""
    reports = session_reports(session_folder)
    totals = summary(reports)
    write_full_report(session_folder, totals)
    tables = session_tables(session_folder)
    _write_session_csvs(session_folder, tables)
    return _write_workbook(session_folder, reports, totals, tables)


def _cubes(cubes) -> str:
    return "; ".join(f"{c.get('label', '?')} ({c.get('x', 0):.1f}, {c.get('y', 0):.1f}) turned {c.get('yaw', 0):.1f}°"
                     for c in cubes or []) or "-"


def run_details(run: dict, folder: Optional[Path] = None) -> list[str]:
    """Every measurement of a run, in words, for the full report: where the cubes were (as set out, as seen at the
    start and at the end), each target's score, every pick, every alarm with its joints, moves that stopped short,
    refused steps and why, motion, time, homing, difficulty, the model's plan and reply. Best effort: what a run
    doesn't have is left out."""
    out: list[str] = []
    add = out.append
    arrangement = run.get("arrangement") or {}
    if arrangement.get("spots"):
        add(f"Start arrangement: " + ", ".join(f"{c} on spot {s}" for c, s in (arrangement.get("spots") or {}).items())
            + f"   (seed {arrangement.get('seed')})")
    add(f"Cubes set out:      {_cubes(run.get('layout_start') or run.get('start'))}")
    if run.get("start_seen") is not None:
        add(f"Seen at the start:  {_cubes(run.get('start_seen'))}")
    add(f"Seen at the end:    {_cubes(run.get('end_seen') or run.get('end'))}")
    for s in run.get("setup") or []:
        if not s.get("ok"):
            add(f"Table check:        {s.get('say')}")
    if run.get("started_anyway"):
        add("Started without the table check (practice).")
    score = run.get("score") or {}
    for t in score.get("targets") or []:
        add(f"Target {t.get('kind')}: {'met' if t.get('ok') else 'NOT met'} · {t.get('detail', '')}")
    if score.get("collateral"):
        add(f"Moved that shouldn't have: {', '.join(score['collateral'])}")
    if score.get("missing"):
        add(f"Not seen at the end: {', '.join(score['missing'])}")
    plan = run.get("plan") or {}
    if plan:
        add(f"Plan (tools in order): {plan.get('shape')}")
        add(f"Plan (with arguments): {plan.get('full')}")
    if run.get("reply"):
        add(f"The model's reply:  {' '.join(str(run['reply']).split())[:2000]}")
    if run.get("goal_check"):
        add(f"The app's goal check: {run['goal_check']}")
    refusals = run.get("refusals") or {}
    if refusals:
        add(f"Refused steps: wasted {refusals.get('wasted', 0)}, guard {refusals.get('guard', 0)}, robot "
            f"{refusals.get('robot', 0)}, other {refusals.get('other', 0)}")
        for reason in refusals.get("reasons") or []:
            add(f"  refused: {reason}")
    for a in run.get("alarms") or []:
        add(f"Alarm {'; '.join(alarm_words(c) for c in a.get('codes', []))} during "
            f"{', '.join(a.get('phases', []))} · joints {a.get('joints')} · target {a.get('target')} · "
            f"{'cleared by the app' if a.get('auto_cleared') else 'NEEDED A PERSON'}"
            + (f" · left over {a['leftover']}" if a.get("leftover") else ""))
    for key, words in (("moves", "Moves"), ("failed_moves", "Failed moves"), ("clamps", "Moves clamped to the limits")):
        if run.get(key):
            add(f"{words}: {run[key]}")
    if run.get("motion"):
        add(f"Motion: {json.dumps(run['motion'], default=str)}")
    if run.get("arrival"):
        add(f"Arrival (how far moves ended from their targets): {json.dumps(run['arrival'], default=str)}")
    if run.get("perception_offsets_mm"):
        add(f"Perception offsets (the app's cube vs the watcher's look): "
            f"{', '.join(f'{o} mm' for o in run['perception_offsets_mm'])}")
    if run.get("time_split"):
        add(f"Time split: {json.dumps(run['time_split'], default=str)}")
    if run.get("setup_effort"):
        add(f"Setting up: {json.dumps(run['setup_effort'], default=str)}")
    if run.get("since_homing"):
        add(f"Since homing: {json.dumps(run['since_homing'], default=str)}")
    if run.get("difficulty"):
        add(f"Difficulty: {json.dumps(run['difficulty'], default=str)}")
    for key, words in (("error", "Error"), ("park_error", "Parking error"), ("look_error", "End look error")):
        if run.get(key):
            add(f"{words}: {run[key]}")
    if run.get("interventions"):
        add(f"Interventions: {'; '.join(str(i) for i in run['interventions'])}")
    observer = run.get("observer") or {}
    if observer.get("note") or observer.get("caliper"):
        add(f"Observer: {observer.get('note', '')} {('caliper: ' + observer['caliper']) if observer.get('caliper') else ''}")
    if run.get("repeated"):
        add("This attempt failed for an infrastructure reason and was run again (not counted).")
    picks = Path(folder) / "picks.csv" if folder is not None else None
    if picks is not None and picks.exists():
        import csv
        rows = list(csv.DictReader(picks.read_text(encoding="utf-8").splitlines()))
        for i, row in enumerate(rows, start=1):
            add(f"Pick {i}: " + " · ".join(f"{k} {v}" for k, v in row.items() if v not in ("", None)))
    return out


def _read_json(path: Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _run_folders(folder: Path) -> list[Path]:
    """The saved runs of a kind's folder (_raw_data/<task>_<tag>, not the pending ones), by name; or an old
    session's runs."""
    raw = folder / results.RAW
    if raw.exists():
        return sorted(p for p in raw.iterdir() if p.is_dir() and p.name != results.PENDING and (p / "run.json").exists())
    return sorted(p.parent for p in (folder / "runs").glob("*/run.json"))


def _ensure_model_log(folder: Path) -> None:
    """A run saved before the model log existed: made now from its trace."""
    if (folder / "model_log.txt").exists() or not (folder / "trace.json").exists():
        return
    try:
        from watcher import model_log
        trace = _read_json(folder / "trace.json", {})
        if trace.get("partial"):
            model_log.write_model_log(folder, [], steps=trace.get("steps"))
        else:
            model_log.write_model_log(folder, [trace])
    except Exception:  # noqa: BLE001 - said in the report instead
        logger.warning("Couldn't make the model log of %s", folder, exc_info=True)


def _picks(folder: Path) -> list[dict]:
    path = folder / "picks.csv"
    if not path.exists():
        return []
    return list(csv.DictReader(path.read_text(encoding="utf-8").splitlines()))


def _motion_of(run: dict, folder: Path) -> dict:
    """The run's motion detail: as recorded, or worked out now from its trace (a run saved before it existed)."""
    if run.get("motion_detail"):
        return run["motion_detail"]
    from watcher import details
    trace = _read_json(folder / "trace.json")
    return details.motion_detail([trace] if trace and not trace.get("partial") else [])


def _turns_of(run: dict, folder: Path) -> dict:
    if run.get("model_turns"):
        return run["model_turns"]
    from watcher import details
    trace = _read_json(folder / "trace.json")
    return details.model_turns([trace] if trace and not trace.get("partial") else [])


def session_tables(session_folder: Path) -> dict:
    """The session's runs side by side, one row per thing: name -> (header, rows). Runs (their measurements), Moves,
    Gripper, Picks, Alarms, Model turns -- for the session's .csv files and the workbook."""
    from watcher import details
    measure_header = ["#", "Run folder", "Task", "Passed", "Distance mm", "Straight-line mm", "Time moving s",
                      "Mean speed mm/s", "Top speed mm/s", "Moves", "Gripper actions", "Gripper s", "Cube held s",
                      "Base turning deg", "Rear arm deg", "Forearm deg", "Wrist deg", "Moves off target >2 mm",
                      "Mean error x mm", "Mean error y mm", "Model turns", "Model s", "Tokens read",
                      "Tokens written", "Moves not answered", "Status replies lost"]
    tables = {"runs": (measure_header, []),
              "moves": (["#", "Task"] + details.MOVE_COLUMNS, []),
              "gripper": (["#", "Task"] + details.GRIPPER_COLUMNS, []),
              "picks": (["#", "Task"], []),
              "alarms": (["#", "Task", "t", "codes", "meaning", "phases", "J1", "J2", "J3", "J4", "target",
                          "cleared by the app", "left over"], []),
              "model_turns": (["#", "Task", "prompt", "turn", "time", "decided s", "load s", "read s", "write s",
                               "tokens read", "tokens written", "stop", "did", "refused", "reply"], [])}
    pick_header: list = []
    for n, folder in enumerate(_run_folders(session_folder), start=1):
        run = _read_json(folder / "run.json", {})
        task = run.get("task")
        motion, turns = _motion_of(run, folder), _turns_of(run, folder)
        t = motion.get("totals") or {}
        joints = t.get("joint_turning_deg") or {}
        way = run.get("which_way") or details.which_way(run.get("score") or {})
        link = run.get("link") or {}
        tables["runs"][1].append([
            n, folder.name, task, "skipped" if run.get("skipped") else run.get("passed"), t.get("distance_mm"), t.get("straight_mm"), t.get("time_moving_s"),
            t.get("mean_speed_mm_s"), t.get("top_speed_mm_s"), t.get("moves"), t.get("gripper_actions"),
            t.get("gripper_s"), ", ".join(str(h) for h in t.get("held_s") or []),
            *[next((v for k, v in joints.items() if k.startswith(j)), None) for j in ("J1", "J2", "J3", "J4")],
            t.get("moves_off_by_over_2mm"), way.get("mean_dx_mm"), way.get("mean_dy_mm"),
            (turns.get("totals") or {}).get("turns"), (turns.get("totals") or {}).get("decided_s"),
            (turns.get("totals") or {}).get("tokens_read"), (turns.get("totals") or {}).get("tokens_written"),
            link.get("moves_not_answered"), link.get("status_replies_lost")])
        tables["moves"][1].extend([[n, task] + r for r in details.move_rows(motion)])
        tables["gripper"][1].extend([[n, task] + r for r in details.gripper_rows(motion)])
        for p in _picks(folder):
            if not pick_header:
                pick_header = list(p)
            tables["picks"][1].append([n, task] + [p.get(k) for k in pick_header])
        for a in run.get("alarms") or []:
            j = (list(a.get("joints") or []) + [None] * 4)[:4]
            tables["alarms"][1].append([n, task, a.get("t"), " ".join(a.get("codes", [])),
                                        "; ".join(alarm_words(c) for c in a.get("codes", [])),
                                        " ".join(a.get("phases", [])), *j, json.dumps(a.get("target")),
                                        a.get("auto_cleared"), a.get("leftover")])
        for tr in turns.get("turns") or []:
            tables["model_turns"][1].append([n, task, tr["prompt"], tr["turn"], tr["time"], tr["decided_s"],
                                             tr["load_s"], tr["read_s"], tr["write_s"], tr["tokens_read"],
                                             tr["tokens_written"], tr["stop_reason"], tr["did"],
                                             "; ".join(tr["refused"]), tr["reply"] or ""])
    tables["picks"] = (["#", "Task"] + pick_header, tables["picks"][1])
    return tables


def _write_session_csvs(session_folder: Path, tables: dict) -> None:
    """session_<name>.csv for each table: written to a temporary name, then renamed; one open in Excel (Windows locks
    it) is saved under a new name rather than stopping the rest."""
    import io
    import os
    for name, (header, rows) in tables.items():
        buf = io.StringIO()
        writer = csv.writer(buf, lineterminator="\n")   # (write_text makes it \r\n on Windows, not \r\r\n)
        writer.writerow(header)
        writer.writerows([[_clean(v) for v in row] for row in rows])
        target = session_folder / f"results_{name}.csv"
        tmp = session_folder / f"results_{name}.csv.part"
        tmp.write_text(buf.getvalue(), encoding="utf-8-sig")
        try:
            os.replace(tmp, target)
        except PermissionError:
            other = session_folder / f"results_{name}_{time.strftime('%H%M%S')}.csv"
            os.replace(tmp, other)
            logger.warning("%s is open (in Excel?): saved as %s instead", target.name, other.name)


def _clean(value):
    """A value for a spreadsheet cell: no control characters (Excel's files can't hold them; one would stop the
    workbook updating for the rest of the session), objects as JSON."""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, default=str)
    if isinstance(value, str):
        return "".join(ch for ch in value if ch in "\t\n" or ord(ch) >= 32)
    return value


def _cell(value) -> str:
    text = "" if value is None else (json.dumps(value, default=str) if isinstance(value, (dict, list)) else str(value))
    text = "".join(ch if ord(ch) >= 32 else " " for ch in text)      # (newlines, \r, tabs: one table row stays one line)
    return text.replace("|", "\\|")


def md_table(header: list, rows: list) -> list[str]:
    if not rows:
        return ["(none)"]
    return (["| " + " | ".join(_cell(h) for h in header) + " |", "|" + "---|" * len(header)]
            + ["| " + " | ".join(_cell(v) for v in row) + " |" for row in rows])


def _fence(text: str) -> list[str]:
    return ["````text", text.rstrip(), "````"]


def _speeds(info: dict) -> str:
    config = ((info.get("settings") or {}).get("config") or {})
    if not config:
        return "not recorded (a session from before the speeds were recorded)"
    robot = config.get("robot") or {}
    gripper = robot.get("gripper") or {}
    now = (info.get("settings") or {}).get("arm_speed_now_mm_s")
    twin = " (the twin's arm: its times and speeds are the simulator's, not a real arm's)" if info.get("where") == "twin" else ""
    return (f"arm {now if now is not None else robot.get('max_speed', '?')} mm/s{twin} (config.yaml: {robot.get('max_speed', '?')}"
            f"); the last {gripper.get('slow_last_mm', '?')} mm before a grip or a release at "
            f"{gripper.get('slow_speed_mm_s', '?')} mm/s; the gripper settles {robot.get('gripper_settle_s', '?')} s")


def _info_of(folder: Path) -> dict:
    """The record a kind's folder ran with: its newest sitting's session.json (the settings, the model, the
    calibration...), with how many sittings there were and when the first began. An old session folder: its own."""
    if (folder / "session.json").exists():
        return _read_json(folder / "session.json", {})
    sittings = sorted((folder / results.SESSIONS_LOG).glob("*/session.json"))
    if not sittings:
        return {}
    info = dict(_read_json(sittings[-1], {}))
    first = _read_json(sittings[0], {})
    info.update(sittings=len(sittings), first_started=first.get("started"))
    return info


def _discarded_of(folder: Path) -> list[dict]:
    """Every run discarded or replaced in a kind's folder (from every sitting's index), and why."""
    indexes = [folder / "index.jsonl"] + sorted((folder / results.SESSIONS_LOG).glob("*/index.jsonl"))
    out = []
    for index in indexes:
        try:
            for line in index.read_text(encoding="utf-8").splitlines():
                entry = json.loads(line)
                if entry.get("discarded"):
                    out.append({"run": entry["discarded"], "reason": entry.get("reason", ""), "time": entry.get("time")})
                elif entry.get("replaced"):
                    out.append({"run": f"{entry['replaced']} (the earlier one)",
                                "reason": f"replaced by a new run: {entry.get('reason', '')}", "time": entry.get("time")})
        except (OSError, ValueError):
            continue
    return out


def _run_section(n: int, folder: Path, run: dict, motion: dict, turns: dict, pictures_at: str, title: str = "") -> list[str]:
    """One run, everything about it, as Markdown: the heading, the result with each target's error and its direction,
    the motion (every move), the gripper, picks, alarms, the model's turns, the arm, camera, paper and link, the other
    measurements, its report, and everything the model did. `pictures_at`: the path to its folder from the file."""
    from watcher import details
    t = motion.get("totals") or {}
    md = [title or f"## Run {n}: {run.get('task')} · {pass_word(run)}{flag_words(run)} · `{folder.name}`", "",
          f"**Prompt:** “{run.get('prompt')}”", ""]
    if run.get("skipped"):                         # it never started: why, the table as it was, the task before
        md += [f"**Skipped:** {run.get('started_at', '?')} · repeat {run.get('repeat')}"
               + (f" · level {run['level']}" if run.get("level") is not None else "")
               + (f" · tag {run['tag']}" if run.get("tag") else ""), "", "### Why it was skipped", ""]
        md += [f"- {line}" for line in skipped_lines(run["skipped"])]
        for s in run.get("setup") or []:
            if not s.get("ok"):
                md.append(f"- Table check: {s.get('say')}")
        md += ["", "### Report", ""]
        try:
            md += _fence((folder / REPORT_TXT).read_text(encoding="utf-8"))
        except OSError:
            md += [f"({REPORT_TXT} wasn't written for this run)"]
        pictures = [p for p in PICTURE_NAMES if (folder / p).exists()]
        if pictures:
            md += ["", "Pictures (the table when it was skipped): "
                   + ", ".join(f"[{p}]({pictures_at}/{p})" for p in pictures)]
        return md
    if run.get("before"):
        md += [f"**Said first:** {' → '.join(run['before'])}", ""]
    arrangement = run.get("arrangement") or {}
    if arrangement.get("spots"):
        md += [f"**Start:** " + ", ".join(f"{c} on spot {s}" for c, s in (arrangement.get("spots") or {}).items())
               + f" (seed `{arrangement.get('seed')}`)", ""]
    md += [f"**Run:** {run.get('started_at', '?')} · {run.get('seconds', '?')} s · repeat {run.get('repeat')}"
           + (f" · level {run['level']}" if run.get("level") is not None else "")
           + (f" · tag {run['tag']}" if run.get("tag") else ""), "", "### Result", ""]
    md += md_table(["Target", "Cube", "Met", "Wanted (x, y) mm", "Ended (x, y) mm", "Error mm", "Which way",
                    "Angle °", "Signed angle °", "Detail"],
                   [[tg.get("kind"), tg.get("cube"), "yes" if tg.get("ok") else "NO",
                     _xy(tg.get("wanted_xy")), _xy(tg.get("ended_xy")), tg.get("position_error_mm"),
                     details.words_for_direction(tg.get("dx_mm"), tg.get("dy_mm")),
                     tg.get("angle_error_deg"), tg.get("angle_signed_deg"), tg.get("detail")]
                    for tg in (run.get("score") or {}).get("targets") or []])
    if scene_lines(run):                           # (V4.2: the table it started from, what went badly wrong)
        md += ["", "### The table at the start, and anything that went badly wrong", ""]
        md += [f"- {line}" for line in scene_lines(run)]
    md += ["", f"Watcher: **{pass_word(run)}**{flag_words(run)}"
               + (f" · failure: {run.get('failure')}" if run.get("failure") else "")
               + f" · observer: {(run.get('observer') or {}).get('verdict', '-')}"
               + (f" · interventions: {'; '.join(map(str, run['interventions']))}" if run.get("interventions") else "")
               + (" · repeated for an infrastructure failure (not counted)" if run.get("repeated") else "")]
    if (run.get("score") or {}).get("collateral"):
        md += ["", "Moved that shouldn't have: " + "; ".join(run["score"]["collateral"])]
    md += ["", "### Where the cubes were (the watcher's own look" + (": the twin's exact positions"
                                                                     if (run.get("end_look") or {}).get("source")
                                                                     else "") + ")", ""]
    md += md_table(["Cube", "Set out", "Seen at the start", "Seen at the end", "Moved mm"],
                   [[w["cube"], w["set_out"], w["seen_at_start"], w["seen_at_end"], w["moved_mm"]]
                    for w in details.watcher_views(run)])
    views = details.app_views(_traces_of(folder))
    md += ["", "### What the app saw (what Qwen was told, each time it looked at the table)", ""]
    md += md_table(["Look", "Turn", "Id", "Object", "x mm", "y mm", "z mm", "Footprint mm", "Height mm", "Where",
                    "Sure", "Holding"],
                   [[v["look"], v["turn"], v["id"], v["label"], v["x"], v["y"], v["z"], v["footprint_mm"],
                     v["height_mm"], v["where"], v["confidence"], v["holding"]] for v in views])
    md += ["", "### Motion (speed, distance, joints)", ""]
    md += md_table(["Distance mm", "Straight-line mm", "Time moving s", "Mean speed mm/s", "Top speed mm/s",
                    "Slowest mm/s", "Moves", "Slow approaches", "Off target >2 mm", "Gripper actions", "Gripper s",
                    "Cube held s", "Joint turning °"],
                   [[t.get("distance_mm"), t.get("straight_mm"), t.get("time_moving_s"), t.get("mean_speed_mm_s"),
                     t.get("top_speed_mm_s"), t.get("slowest_speed_mm_s"), t.get("moves"), t.get("slow_moves"),
                     t.get("moves_off_by_over_2mm"), t.get("gripper_actions"), t.get("gripper_s"),
                     t.get("held_s"), t.get("joint_turning_deg")]])
    md += ["", "Every move:", ""]
    md += md_table(["#", "Tool", "Route", "From", "To", "Target", "Distance mm", "s", "Speed mm/s",
                    "Set mm/s", "Missed by mm", "Joint changes °", "Fastest joint °/s", "Error"],
                   [[m["n"], m["tool"], m["route"], m["from"], m["to"], m["target"], m["distance_mm"],
                     m["seconds"], m["speed_mm_s"], m["speed_set_mm_s"], m["missed_by_mm"], m["joint_changes"],
                     (f"{m['fastest_joint']['name']} {m['fastest_joint']['deg_per_s']}" if m.get("fastest_joint")
                      else ""), m["error"] or ""] for m in motion.get("moves") or []])
    md += ["", "Gripper:", ""]
    md += md_table(["#", "Tool", "Action", "s", "Where", "Error"],
                   [[g["n"], g["tool"], g["action"], g["seconds"], g["where"], g["error"] or ""]
                    for g in motion.get("gripper") or []])
    picks = _picks(folder)
    if picks:
        md += ["", "### Picks", ""] + md_table(list(picks[0]), [list(p.values()) for p in picks])
    if run.get("alarms"):
        md += ["", "### Controller alarms", ""]
        md += md_table(["t", "Codes", "Phases", "Joints", "Target", "Cleared by the app", "Left over"],
                       [["{:.1f}".format(a["t"] - run["started_epoch"]) if a.get("t") and run.get("started_epoch")
                         else a.get("t"), "; ".join(alarm_words(c) for c in a.get("codes", [])),
                         ", ".join(a.get("phases", [])), a.get("joints"), a.get("target"), a.get("auto_cleared"),
                         a.get("leftover")] for a in run["alarms"]])
    md += ["", "### The model's turns", ""]
    tt = turns.get("totals") or {}
    md += [f"{tt.get('turns', 0)} turns · {tt.get('decided_s', 0)} s deciding · {tt.get('tokens_read', 0)} tokens "
           f"read, {tt.get('tokens_written', 0)} written · slowest turn {tt.get('slowest_turn_s')} s"
           + (f" · not finished normally: turns {tt['not_finished']}" if tt.get("not_finished") else ""), ""]
    md += md_table(["Prompt", "Turn", "Time", "Decided s", "Load s", "Read s", "Write s", "Tokens read",
                    "Tokens written", "Stop", "Did", "Refused"],
                   [[tr["prompt"], tr["turn"], tr["time"], tr["decided_s"], tr["load_s"], tr["read_s"],
                     tr["write_s"], tr["tokens_read"], tr["tokens_written"], tr["stop_reason"], tr["did"],
                     "; ".join(tr["refused"])] for tr in turns.get("turns") or []])
    md += ["", "### The arm, the camera, the paper, the link", ""]
    md += md_table(["", ""], [["Arm at the start", run.get("robot_at_start")], ["Arm at the end", run.get("robot_at_end")],
                              ["End look", run.get("end_look")], ["Paper check before the run", run.get("paper_check")],
                              ["Calibration (and continuous calibration)", run.get("calibration")],
                              ["Link to the robot", run.get("link")], ["Since homing", run.get("since_homing")],
                              ["Setting up", run.get("setup_effort")], ["Difficulty", run.get("difficulty")]])
    md += ["", "### Other measurements", ""] + [f"- {line}" for line in run_details(run, folder)]
    md += ["", "### Report", ""]
    try:
        md += _fence((folder / REPORT_TXT).read_text(encoding="utf-8"))
    except OSError:
        md += [f"({REPORT_TXT} wasn't written for this run)"]
    md += ["", "### What the model did (as the app's Model tab shows it)", ""]
    try:
        md += _fence((folder / "model_log.txt").read_text(encoding="utf-8"))
    except OSError:
        md += ["(model_log.txt wasn't written for this run)"]
    pictures = [p for p in PICTURE_NAMES if (folder / p).exists()]
    if pictures:
        md += ["", "Pictures: " + ", ".join(f"[{p}]({pictures_at}/{p})" for p in pictures)]
    return md


PICTURE_NAMES = ("start.png", "end.png", "end_marked.png")


def _xy(point) -> Optional[str]:
    return f"({point[0]:.1f}, {point[1]:.1f})" if point else None


def _traces_of(folder: Path) -> list[dict]:
    """The model's records of a run's prompts (its trace; a partial one has no looks)."""
    trace = _read_json(folder / "trace.json")
    return [trace] if isinstance(trace, dict) and not trace.get("partial") else []


def _load_run(folder: Path) -> tuple:
    from watcher import details
    _ensure_model_log(folder)
    run = _read_json(folder / "run.json", {})
    motion, turns = _motion_of(run, folder), _turns_of(run, folder)
    way = run.get("which_way") or details.which_way(run.get("score") or {})
    return run, motion, turns, way


def write_run_files(kind_folder: Path, run_folder: Path) -> tuple[Path, Path]:
    """A saved run's own files: User_Saved_<kind>\\<name>.md -- everything about the run -- and
    User_Saved_<kind>\\HTML_version\\<name>.html, the same as one web page with its pictures built in."""
    run, motion, turns, _ = _load_run(run_folder)
    name = run_folder.name
    info = _info_of(kind_folder)
    head = [f"# {name.replace('_', ' · ')}: {pass_word(run)}", "",
            f"*{kind_folder.name} · study {info.get('study', info.get('round'))} · version {info.get('version')} · "
            f"{'REAL (counts for the paper)' if info.get('real') else 'practice'} · saved "
            f"{run.get('saved_at', '')}. The evidence: `_raw_data/{name}`.*", ""]
    md = head + _run_section(0, run_folder, run, motion, turns, f"../{results.RAW}/{name}", title="## The run")
    md_path = results.saved_folder(kind_folder) / f"{name}.md"
    results.write_text(md_path, "\n".join(md) + "\n")
    images = {p: run_folder / p for p in PICTURE_NAMES if (run_folder / p).exists()}
    html_path = results.html_folder(kind_folder) / f"{name}.html"
    results.write_text(html_path, md_to_html("\n".join(md), name, images))
    return md_path, html_path


def write_full_report(session_folder: Path, totals: Optional[dict] = None) -> Path:
    """FULL_REPORT.md, FULL_REPORT.html and full_report.json for a kind's folder (or an old session's), remade after
    every Save.

    FULL_REPORT.md -- for reading (you, Dr. Curry, Claude): the settings, speeds and totals, the bias in where the
    cubes ended, the runs discarded and why; then each saved run in full: the result with each target's error and its
    direction, the motion (every move's distance, time, speed and joints; the gripper; how long each cube was held),
    the picks, the alarms, the model's every turn, the arm, camera, paper and link, its report and everything the model
    did. FULL_REPORT.html -- the summary as a web page, linking each run's own page. full_report.json -- the same
    facts as data."""
    from watcher import details
    info = _info_of(session_folder)
    totals = totals if totals is not None else summary(session_reports(session_folder))
    folders = _run_folders(session_folder)
    discarded = _discarded_of(session_folder)
    runs, bias_rows = [], []
    sum_distance = sum_moving = 0.0
    for folder in folders:
        run, motion, turns, way = _load_run(folder)
        if not run.get("repeated") and not run.get("excluded"):   # (an infrastructure failure isn't counted)
            sum_distance += (motion.get("totals") or {}).get("distance_mm") or 0.0
            sum_moving += sum(m.get("seconds") or 0.0 for m in motion.get("moves") or [])
        # (the bias of placements that roughly worked: a target missed by far -- the wrong place altogether -- would
        # swamp it; only met targets of counted runs)
        met = {(t.get("kind"), t.get("cube")) for t in (run.get("score") or {}).get("targets") or [] if t.get("ok")}
        bias_rows += [dict(t, task=run.get("task")) for t in way.get("targets") or []
                      if t.get("dx_mm") is not None and not run.get("repeated") and not run.get("excluded") and (t.get("kind"), t.get("cube")) in met]
        runs.append((folder, run, motion, turns, way))
    bias = {}
    if bias_rows:
        bias = {"targets": len(bias_rows),
                "mean_radial_mm": round(sum(t["radial_mm"] for t in bias_rows) / len(bias_rows), 1),
                "mean_around_mm": round(sum(t["around_mm"] for t in bias_rows) / len(bias_rows), 1),
                "mean_dx_mm": round(sum(t["dx_mm"] for t in bias_rows) / len(bias_rows), 1),
                "mean_dy_mm": round(sum(t["dy_mm"] for t in bias_rows) / len(bias_rows), 1)}
    motion_totals = {"distance_mm": round(sum_distance, 1), "time_moving_s": round(sum_moving, 1),
                     "mean_speed_mm_s": round(sum_distance / sum_moving, 1) if sum_moving > 0.005 else None}
    kind = (session_folder / results.RAW).exists()
    raw_at = results.RAW if kind else "runs"

    # ---- the summary (the top of FULL_REPORT.md, and FULL_REPORT.html) ----
    real = "REAL (counts for the paper)" if info.get("real") else "practice"
    top = [f"# Full report: {session_folder.name}", "",
           f"*Made {datetime.now().isoformat(timespec='seconds')}; remade after every saved run. The same facts as "
           "data: `full_report.json`.*", "", "## Settings", ""]
    top += md_table(["", ""], [
        ["Data", f"{session_folder.name} · study {info.get('study', info.get('round'))} · version "
                 f"{info.get('version')} · {real}"],
        ["Where, scored by", f"{info.get('where')} · {info.get('scoring', 'the watcher')}"],
        ["Sittings", f"{info.get('sittings', 1)} · first started {info.get('first_started') or info.get('started', '?')}"
                     f" · the last {info.get('started', '?')} to {info.get('ended') or 'still running'}"],
        ["Qwen", f"{info.get('model')} (digest {str(info.get('model_digest', ''))[:19]}) · temperature "
                 f"{info.get('temperature')} · seed {info.get('seed')} · {info.get('model_processor') or 'GPU/CPU ?'}"],
        ["Code", str(info.get("git_commit", ""))[:12]],
        ["Speeds", _speeds(info)],
        ["Calibration", info.get("calibration", "?")],
        ["Camera at the start", info.get("camera_at_start") or info.get("camera")],
        ["Detection", info.get("detection")],
        ["Paper", info.get("paper")],
        ["Arm at the start", info.get("robot_at_start")],
        ["Table height", info.get("table_z_mm")],
        ["Places the robot knows", info.get("zones")]])
    top += ["", "## Totals", ""]
    top += md_table(["Saved runs", "Counted", "Skipped", "Passed", "Some parts", "Catastrophic", "Unassisted",
                     "Disagreements", "Alarms /100 moves", "Mean time s", "Distance mm", "Time moving s",
                     "Mean speed mm/s"],
                    [[totals.get("runs"), totals.get("counted"), totals.get("skipped", 0), totals.get("passed"),
                      (totals.get("outcomes") or {}).get("SOME PARTS", 0), totals.get("catastrophic", 0),
                      totals.get("unassisted_passes"), totals.get("disagreements"), totals.get("alarms_per_100_moves"),
                      totals.get("mean_time_s"), motion_totals["distance_mm"], motion_totals["time_moving_s"],
                      motion_totals["mean_speed_mm_s"]]])
    if any(k != "-" for k in totals.get("by_level") or {}):
        top += ["", "By difficulty level:", ""] + md_table(["Level", "Runs", "Passed", "Unassisted"],
                                                           [[k, v["runs"], v["passed"], v["unassisted"]]
                                                            for k, v in sorted((totals.get("by_level") or {}).items())])
    credit = totals.get("credit") or {}
    if credit.get("scored"):                       # partial credit (0-100), next to the strict pass / fail
        bands = credit.get("bands") or {}
        top += ["", f"Partial credit (0-100, how close each run came): mean **{credit['mean_score']}** over "
                    f"{credit['scored']} runs · Full {bands.get('Full', 0)}, Partial {bands.get('Partial', 0)}, Fail "
                    f"{bands.get('Fail', 0)}", ""]
        top += md_table(["Level", "Mean score"], [[k, v] for k, v in (credit.get("mean_score_by_level") or {}).items()])
    top += ["", "By category:", ""] + md_table(["Category", "Runs", "Passed", "Unassisted"],
                                               [[c, v["runs"], v["passed"], v["unassisted"]]
                                                for c, v in sorted((totals.get("by_category") or {}).items())])
    top += ["", "Failure types: " + (", ".join(f"{k} {v}" for k, v in sorted((totals.get("failures") or {}).items()))
                                      or "none")]
    top += ["", "## Where the cubes ended (bias)", ""]
    if bias:
        top += [f"Over {bias['targets']} placements that met their target, the cube ended on average "
                f"**{details.words_for_direction(bias['mean_dx_mm'], bias['mean_dy_mm'])}** of where it should "
                f"have (robot x {bias['mean_dx_mm']:+.1f} mm, y {bias['mean_dy_mm']:+.1f} mm, +y being the robot's "
                f"left; seen from the base: {bias['mean_radial_mm']:+.1f} mm radial, {bias['mean_around_mm']:+.1f} mm "
                "round it, counter-clockwise). The same direction run after run points at the calibration, the wrist "
                "or the gripper, not the plan.", ""]
        top += md_table(["Task", "Cube", "Wanted", "Ended", "x mm", "y mm (+ left)", "Radial mm", "Around mm"],
                        [[t["task"], t.get("cube"), t.get("wanted_xy"), t.get("ended_xy"), t.get("dx_mm"),
                          t.get("dy_mm"), t.get("radial_mm"), t.get("around_mm")] for t in bias_rows])
    else:
        top += ["No placements measured yet."]
    if totals.get("start_conditions"):
        top += ["", "Start conditions (the table as the task before left it): " + ", ".join(
            f"{k} {v}" for k, v in sorted(totals["start_conditions"].items()))]
    bad = [(f, r) for f, r, *_ in runs if r.get("catastrophic")]
    if bad:                                        # (V4.2: what went badly wrong, first)
        top += ["", "## Catastrophic runs (look at these first)", ""]
        top += md_table(["Run", "Task", "Outcome", "What went badly wrong"],
                        [[f.name, r.get("task"), pass_word(r), "; ".join(r["catastrophic"])] for f, r in bad])
    skipped = [(f, r) for f, r, *_ in runs if r.get("skipped")]
    if skipped:                                    # (tasks that never started: why, and the task that left the table)
        top += ["", "## Skipped tasks (never started; saved, not counted as a pass or a fail)", ""]
        top += md_table(["Run", "Task", "Why", "Skipped by", "Waited s", "Cubes off where needed (mm)",
                         "The task before", "Its result"],
                        [[f.name, r.get("task"), r["skipped"].get("why"), r["skipped"].get("by"),
                          r["skipped"].get("waited_s"),
                          ", ".join(f"{e['cube'].split()[0]} {e['off_mm']:.0f}" if e.get("seen") else
                                    f"{e['cube'].split()[0]} not seen" for e in r["skipped"].get("expected") or [])
                          or "-",
                          (r["skipped"].get("task_before") or {}).get("run") or "-",
                          (r["skipped"].get("task_before") or {}).get("result") or "-"] for f, r in skipped])
    if discarded:
        top += ["", "## Discarded and replaced runs (not counted; each kept whole in Recycle_Bin)", ""]
        top += md_table(["Run", "Why", "When"], [[d["run"], d["reason"], d["time"]] for d in discarded])
    top += ["", "## Saved runs", ""]
    listing = [(n, f, r) for n, (f, r, *_) in enumerate(runs, start=1)]
    if not runs:
        top += ["No saved runs yet."]

    def line(n, f, r, link):
        return (f"{n}. {link} · {r.get('task')} · {pass_word(r)}{flag_words(r)}"
                + (f" · {r.get('failure')}" if r.get("failure") else "")
                + (f" · {r['skipped'].get('why')}" if r.get("skipped") else f" · {r.get('seconds', '?')} s"))

    md = top + [line(n, f, r, f"`{f.name}`") for n, f, r in listing]
    for n, (folder, run, motion, turns, way) in enumerate(runs, start=1):
        md += ["", "---", ""] + _run_section(n, folder, run, motion, turns, f"{raw_at}/{folder.name}")
    out = session_folder / FULL_MD
    results.write_text(out, "\n".join(md) + "\n")
    if kind:                                       # the summary as a web page, each run linked to its own page
        html_runs = top + [line(n, f, r, f"[{f.name}]({results.saved_folder(session_folder).name}/"
                                        f"{results.HTML_VERSION}/{f.name}.html)") for n, f, r in listing]
        results.write_text(session_folder / FULL_HTML, md_to_html("\n".join(html_runs), session_folder.name, {}))

    # ---- full_report.json ----
    data = {"made": datetime.now().isoformat(timespec="seconds"), "settings": info, "totals": totals,
            "motion_totals": motion_totals, "bias": bias, "discarded": discarded,
            "skipped": [dict(r["skipped"], folder=f.name, task=r.get("task")) for f, r in skipped], "runs": []}
    for folder, run, motion, turns, way in runs:
        model_text = ""
        try:
            model_text = (folder / "model_log.txt").read_text(encoding="utf-8")
        except OSError:
            pass
        # (the run's record without its report section -- the same facts again -- and the model's whole record by
        # its file: embedding every trace made each update slower as the folder grew)
        data["runs"].append({"folder": folder.name, "run": {k: v for k, v in run.items() if k != "report"},
                             "report": run.get("report"), "motion_detail": motion, "model_turns": turns,
                             "which_way": way, "picks": _picks(folder),
                             "watcher_views": details.watcher_views(run),
                             "app_views": details.app_views(_traces_of(folder)),
                             "trace_file": f"{raw_at}/{folder.name}/trace.json", "model_log": model_text,
                             "pictures": [p for p in PICTURE_NAMES if (folder / p).exists()]})
    results.write_json(session_folder / FULL_JSON, data)
    for old in ("FULL_REPORT.txt",):                 # (the earlier plain-text version: the .md replaces it)
        if (session_folder / old).exists():
            (session_folder / old).unlink()
    return out


# ---- Markdown to HTML (the report's own Markdown: headings, tables, lists, code blocks, links, bold) ----------------
_HTML_STYLE = """<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:24px auto;max-width:1200px;padding:0 16px;color:#1d2731;background:#fff}
h1{font-size:22px}h2{font-size:18px;margin-top:28px;border-bottom:1px solid #d8dee4;padding-bottom:4px}h3{font-size:15px}
table{border-collapse:collapse;margin:8px 0;font-size:12.5px;display:block;overflow-x:auto}
th,td{border:1px solid #d8dee4;padding:4px 7px;text-align:left;vertical-align:top}th{background:#f2f5f7}
pre{background:#f6f8fa;border:1px solid #d8dee4;padding:10px;font-size:12px;white-space:pre-wrap;word-break:break-word}
code{background:#f2f5f7;padding:1px 4px;border-radius:3px}img{max-width:32%;margin:4px;border:1px solid #d8dee4}
.pics{display:flex;flex-wrap:wrap;gap:8px}.pics figure{margin:0;max-width:32%}.pics img{max-width:100%}
@media (prefers-color-scheme: dark){body{background:#0f1c29;color:#d7e6f0}th{background:#18384d}
th,td,pre,img,h2{border-color:#2a4459}pre,code{background:#152636}}
</style>"""


def _inline(text: str) -> str:
    import html as _html
    import re as _re
    text = _html.escape(text, quote=False)
    text = _re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = _re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    text = _re.sub(r"(?<![\w*])\*([^*]+)\*(?![\w*])", r"<i>\1</i>", text)
    text = _re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", r'<a href="\2">\1</a>', text)
    return text


def md_to_html(md: str, title: str, images: dict) -> str:
    """The report's Markdown as a web page. `images` {name: path}: pictures built into the page (base64), shown at
    the top -- one file that keeps its pictures wherever it is copied."""
    import base64
    import html as _html
    out, lines, i = [], md.splitlines(), 0
    paragraph: list[str] = []

    def flush():
        if paragraph:
            out.append("<p>" + " ".join(_inline(p) for p in paragraph) + "</p>")
            paragraph.clear()
    while i < len(lines):
        line = lines[i]
        if line.startswith("````") or line.startswith("```"):
            flush()
            fence = line[:4] if line.startswith("````") else line[:3]
            block = []
            i += 1
            while i < len(lines) and not lines[i].startswith(fence):
                block.append(lines[i])
                i += 1
            out.append("<pre>" + _html.escape("\n".join(block)) + "</pre>")
        elif line.startswith("#"):
            flush()
            level = len(line) - len(line.lstrip("#"))
            out.append(f"<h{level}>{_inline(line[level:].strip())}</h{level}>")
            if level == 1 and images:          # the pictures, built in, under the title
                figs = []
                for name, path in images.items():
                    try:
                        data = base64.b64encode(Path(path).read_bytes()).decode("ascii")
                    except OSError:
                        continue
                    figs.append(f'<figure><img alt="{name}" src="data:image/png;base64,{data}">'
                                f"<figcaption>{name}</figcaption></figure>")
                if figs:
                    out.append('<div class="pics">' + "".join(figs) + "</div>")
        elif line.startswith("|"):
            flush()
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                rows.append(lines[i])
                i += 1
            i -= 1
            cells = [[c.strip().replace("\\|", "|") for c in __import__("re").split(r"(?<!\\)\|", r)[1:-1]]
                     for r in rows]
            body = [c for c in cells if not all(set(x) <= set("-: ") and x for x in c)]
            if body:
                head, rest = body[0], body[1:]
                out.append("<table><tr>" + "".join(f"<th>{_inline(h)}</th>" for h in head) + "</tr>"
                           + "".join("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in r) + "</tr>" for r in rest)
                           + "</table>")
        elif line.startswith("- "):
            flush()
            items = []
            while i < len(lines) and lines[i].startswith("- "):
                items.append(f"<li>{_inline(lines[i][2:])}</li>")
                i += 1
            i -= 1
            out.append("<ul>" + "".join(items) + "</ul>")
        elif __import__("re").match(r"^\d+\. ", line):
            flush()
            items = []
            while i < len(lines) and __import__("re").match(r"^\d+\. ", lines[i]):
                items.append(f"<li>{_inline(lines[i].split('. ', 1)[1])}</li>")
                i += 1
            i -= 1
            out.append("<ol>" + "".join(items) + "</ol>")
        elif line.strip() == "---":
            flush()
            out.append("<hr>")
        elif not line.strip():
            flush()
        else:
            paragraph.append(line)
        i += 1
    flush()
    return (f"<!doctype html><html><head><meta charset=\"utf-8\"><title>{_html.escape(title)}</title>"
            f"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">{_HTML_STYLE}</head><body>"
            + "\n".join(out) + "</body></html>\n")


def _write_workbook(folder: Path, reports: list[dict], totals: dict, tables: Optional[dict] = None) -> Optional[Path]:
    runs_rows = [[get(r) for _, get in RUN_COLUMNS] for r in reports]
    event_rows = [[r.get("n") or r["run"].get("number_in_session"), r["task"]["id"], e["t"], e["kind"], e["what"]]
                  for r in reports for e in r["events"]]
    summary_rows = [["Runs", totals["runs"]], ["Counted (not repeated, not skipped)", totals["counted"]],
                    ["Skipped (never started)", totals.get("skipped", 0)],
                    ["Passed (watcher)", totals["passed"]], ["Unassisted passes", totals["unassisted_passes"]],
                    ["Disagreements with your verdict", totals["disagreements"]],
                    ["Interventions", totals["interventions"]], ["Moves", totals["moves"]],
                    ["Alarms", totals["alarms"]], ["Alarms per 100 moves", totals["alarms_per_100_moves"]],
                    ["Mean time (s)", totals["mean_time_s"]], [], ["Category", "Runs", "Passed", "Unassisted"]]
    summary_rows += [[c, v["runs"], v["passed"], v["unassisted"]] for c, v in sorted(totals["by_category"].items())]
    summary_rows += [[], ["Failure type", "Runs"]] + [[k, v] for k, v in sorted(totals["failures"].items())]
    credit = totals.get("credit") or {}
    if credit.get("scored"):
        summary_rows += [[], ["Partial credit (0-100)", "Mean score"], ["All runs", credit["mean_score"]]]
        summary_rows += [[f"Level {k}", v] for k, v in (credit.get("mean_score_by_level") or {}).items()]
        summary_rows += [[f"{b} runs", n] for b, n in (credit.get("bands") or {}).items()]
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font
    except ImportError:
        logger.warning("openpyxl isn't installed: the session's results are written as .csv files instead")
        for name, header, rows in (("runs", [c for c, _ in RUN_COLUMNS], runs_rows),
                                   ("events", ["#", "Task", "t (s)", "Kind", "What"], event_rows),
                                   ("summary", [], summary_rows)):
            with open(folder / f"session_results_{name}.csv", "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                if header:
                    writer.writerow(header)
                writer.writerows(rows)
        return None
    book = Workbook()
    sheet = book.active
    sheet.title = "Runs"
    sheet.append([c for c, _ in RUN_COLUMNS])
    for row in runs_rows:
        sheet.append(row)
    for i, report in enumerate(reports, start=2):        # the run folder: a link to its report
        cell = sheet.cell(row=i, column=2)
        cell.hyperlink = f"{report.get('folder') or 'runs/' + str(report['run'].get('run'))}/{REPORT_TXT}"
        cell.font = Font(color="0563C1", underline="single")
    widths = {"Prompt": 40, "What happened": 90, "Your note": 30, "Run folder": 24, "Interventions": 24}
    for col, (name, _) in enumerate(RUN_COLUMNS, start=1):
        sheet.column_dimensions[sheet.cell(row=1, column=col).column_letter].width = widths.get(name, max(10, len(name) + 2))
        sheet.cell(row=1, column=col).font = Font(bold=True)
    for row in sheet.iter_rows(min_row=2):
        row[-1].alignment = Alignment(wrap_text=True, vertical="top")
    sheet.freeze_panes = "D2"
    events = book.create_sheet("Events")
    events.append(["#", "Task", "t (s)", "Kind", "What"])
    for row in event_rows:
        events.append(row)
    for col, width in zip("ABCDE", (5, 10, 9, 14, 110)):
        events.column_dimensions[col].width = width
    for cell in events[1]:
        cell.font = Font(bold=True)
    events.freeze_panes = "A2"
    sums = book.create_sheet("Summary")
    for row in summary_rows:
        sums.append(row)
    sums.column_dimensions["A"].width = 34
    for name, title in (("runs", "Measurements"), ("moves", "Moves"), ("gripper", "Gripper"), ("picks", "Picks"),
                        ("alarms", "Alarms"), ("model_turns", "Model turns")):
        header, rows = (tables or {}).get(name, ([], []))
        if not header:
            continue
        extra = book.create_sheet(title)
        extra.append(header)
        for row in rows:
            extra.append([_clean(v) for v in row])
        for cell in extra[1]:
            cell.font = Font(bold=True)
        extra.freeze_panes = "C2"
    target = folder / SESSION_XLSX
    tmp = folder / (SESSION_XLSX + ".part.xlsx")
    book.save(tmp)
    try:
        tmp.replace(target)
        return target
    except PermissionError:                       # open in Excel (Windows locks it): saved alongside, not lost
        other = folder / f"results_{time.strftime('%H%M%S')}.xlsx"
        tmp.replace(other)
        logger.warning("%s is open (in Excel?): the session's results were saved as %s instead", target.name,
                       other.name)
        return other


def main(argv: list[str]) -> int:
    if len(argv) != 1:
        print(__doc__)
        return 2
    folder = Path(argv[0])
    if (folder / results.RAW).exists():          # a kind's folder: each saved run's own files, then the reports
        for run in _run_folders(folder):
            write_run_files(folder, run)
    elif not (folder / "session.json").exists():
        print(f"Not a data folder (no {results.RAW}) or an old session folder (no session.json): {folder}")
        return 1
    made = write_session_results(folder)
    print(f"Reports remade in {folder}" + (f"; workbook {made.name}" if made else "; .csv files (no openpyxl)"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

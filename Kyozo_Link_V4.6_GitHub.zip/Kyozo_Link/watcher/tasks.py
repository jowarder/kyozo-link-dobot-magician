"""The study's task files (study/tasks/train.yaml, the test set outside the project) and the one checker that scores a
run from where the cubes started and where they ended -- the same for the twin (exact positions) and the real Dobot
(a fresh camera look), so the two scores can be compared.

Coordinates are the robot's, in mm: x straight out in front, +y the robot's left. Angles are in degrees,
counter-clockwise seen from above; a cube looks the same every 90 degrees, so angles are compared modulo 90.

A task file with `sheet: a4` is laid out on the printed A4 sheet (app/vision/paper.py): its "zones" are the sheet's
four corner spots, spot_1 ... spot_4 (a cube is on a spot when its middle is within 10 mm of the spot's), and its
tasks give start rules instead of fixed layouts -- which cubes, which must be on which spot, which spots must be free
(`start: {cubes, pin, free}`) -- each run's arrangement drawn by watcher/arrange.py.

A task file with `area: {x: [low, high], y: [low, high]}` needs no paper at all (V4.1): its cubes are put anywhere on the
table by hand, inside that area (the twin: at seeded random places in it), and every target is relative to the cubes
-- moved by, turned by, beside another, between two, swapped, in a row -- scored from where the camera saw them start.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import yaml


@dataclass
class Cube:
    label: str                 # "red cube", as the detector names it
    x: float
    y: float
    yaw: float = 0.0
    level: int = 1             # 1: on the table; 2: on one other cube; 3: on two (a tower, seen from above)

    @property
    def color(self) -> str:
        return self.label.split()[0]


@dataclass
class Zone:
    name: str
    cx: float
    cy: float
    width: float
    depth: float
    yaw: float = 0.0               # a spot: its printed outline's turn
    spot: Optional[int] = None     # a corner spot of the A4 sheet (its number); None: a zone

    @property
    def label(self) -> str:
        return f"spot {self.spot}" if self.spot is not None else f"zone {self.name.split('_')[-1].upper()}"

    def contains(self, cube: Cube) -> bool:
        if self.spot is not None:      # on a spot: its middle within half the spot's size of the spot's
            return math.hypot(cube.x - self.cx, cube.y - self.cy) <= self.width / 2
        return abs(cube.x - self.cx) <= self.width / 2 and abs(cube.y - self.cy) <= self.depth / 2

    def distance_outside(self, cube: Cube) -> float:
        """0 inside; else how far the cube's centre is from the zone's edge."""
        if self.spot is not None:
            return max(0.0, math.hypot(cube.x - self.cx, cube.y - self.cy) - self.width / 2)
        dx = max(abs(cube.x - self.cx) - self.width / 2, 0.0)
        dy = max(abs(cube.y - self.cy) - self.depth / 2, 0.0)
        return math.hypot(dx, dy)


@dataclass
class PassRule:
    position_mm: float = 10.0
    angle_deg: float = 8.0
    collateral_mm: float = 10.0


@dataclass
class Task:
    id: str
    category: str
    layout: str
    prompt: str
    start: list[Cube]
    targets: list[dict]
    oracle: list[str]
    before: list[str] = field(default_factory=list)
    start_rule: Optional[dict] = None     # a sheet task's {cubes, pin, free}; `start` is then one arrangement of it
    arrangement: Optional[dict] = None    # this run's: {"seed", "spots": {colour: spot number}}
    level: Optional[int] = None           # how hard it is, 1 (easiest) to 5, as the task file says (optional)
    tower: list[str] = field(default_factory=list)   # the start's tower, bottom first (start: {tower: [...]}): the
                                                     # cubes under its top are hidden from the camera


SPOT_SIZE_MM = 20.0                       # a cube is "on" a spot within half this of its middle


@dataclass
class TaskSet:
    name: str                  # "training" or "test"
    cube_set: int
    cube_size_mm: float
    rule: PassRule
    zones: dict[str, Zone]
    tasks: list[Task]
    half_set: list[str]
    sha256: str = ""
    sheet: Optional[str] = None           # "a4": laid out on the printed sheet (spots, start rules)
    paper: object = None                  # the sheet's pose (app.vision.paper.PaperPose) the spots follow
    area: Optional[dict] = None           # no paper: {"x": [low, high], "y": [low, high]} mm, where the cubes go
    # Simple 20 (study/tasks/simple.yaml): the cubes are put down once, in this layout ({colour: [x, y]}), and each
    # task starts where the one before left them ("chained"); each run ends after time_limit_s; level_words name
    # the file's own levels (its groups)
    start_layout: Optional[dict] = None
    chained: bool = False
    time_limit_s: Optional[float] = None
    level_words: dict = field(default_factory=dict)

    def task(self, task_id: str) -> Task:
        return next(t for t in self.tasks if t.id == task_id)

    def on_paper(self, pose) -> "TaskSet":
        """The set with its spots where the sheet really is (`pose`: app.vision.paper.PaperPose), and each task's
        default arrangement redrawn on them."""
        if self.sheet is None:
            return self
        from dataclasses import replace
        zones = dict(self.zones)
        zones.update(sheet_spots(pose))
        moved = replace(self, zones=zones, paper=pose)
        from watcher.arrange import arrange
        tasks = []
        for t in self.tasks:
            if t.start_rule:
                try:
                    t = replace(t, start=arrange(t, moved, "default", 0)[0])
                except ValueError:            # (no arrangement suits it: said when its runs are planned, and by
                    t = replace(t, start=[])  # study/check_tasks.py, which names the task)
            tasks.append(t)
        moved.tasks = tasks
        return moved


def sheet_spots(pose=None) -> dict[str, Zone]:
    """The A4 sheet's corner spots as zones (spot_1 ... spot_4), where the sheet lies (`pose`; default: designed)."""
    from app.vision.paper import DESIGNED, SPOTS
    pose = pose or DESIGNED
    out = {}
    for number in SPOTS:
        x, y, turn = pose.spot(number)
        out[f"spot_{number}"] = Zone(f"spot_{number}", x, y, SPOT_SIZE_MM, SPOT_SIZE_MM, yaw=turn, spot=number)
    return out


def load_task_set(path: Path | str, cube_set: int, cube_size_mm: Optional[float] = None) -> TaskSet:
    """Reads a task file, choosing each layout's and task's variant for the study's cube set (3 or 6). `cube_size_mm`:
    the cubes' size the study uses now (the app's Settings > Cubes, app/cube_size.py), instead of the one the file was
    written for; the layouts (in mm) stand as they are."""
    import hashlib
    raw = Path(path).read_bytes()
    data = yaml.safe_load(raw)
    if cube_set not in data.get("cube_sets", [3, 6]):
        raise ValueError(f"{path}: cube set {cube_set} isn't one of {data.get('cube_sets')}")

    def variant(block: dict) -> dict:
        return block["variants"][cube_set] if "variants" in block else block

    layouts = {name: [Cube(c["label"], float(c["xy"][0]), float(c["xy"][1]), float(c.get("yaw", 0)))
                      for c in variant(block)["cubes"]]
               for name, block in (data.get("layouts") or {}).items()}
    zones = {name: Zone(name, float(z["center"][0]), float(z["center"][1]), float(z["size"][0]), float(z["size"][1]))
             for name, z in (data.get("zones") or {}).items()}
    sheet = data.get("sheet")
    if sheet is not None:
        if sheet != "a4":
            raise ValueError(f"{path}: unknown sheet {sheet!r} (only a4)")
        zones.update(sheet_spots())
    area = data.get("area")
    if area is not None:
        if sheet is not None:
            raise ValueError(f"{path}: a file has a sheet or an area, not both")
        try:
            area = {"x": [float(v) for v in area["x"]], "y": [float(v) for v in area["y"]]}
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"{path}: area must be {{x: [low, high], y: [low, high]}} (mm)") from exc
    rule = PassRule(**{k: float(v) for k, v in (data.get("pass_rule") or {}).items()})
    tasks = []
    for t in data["tasks"]:
        body = variant(t)
        rule_ = t.get("start")
        if rule_ is not None:
            if sheet is None and area is None:
                raise ValueError(f"{path}: task {t['id']} has start rules but the file has no sheet or area")
            start: list[Cube] = []                     # (drawn below, once the set is whole)
            layout = "sheet" if sheet is not None else "random"
        else:
            start = [Cube(c.label, c.x, c.y, c.yaw) for c in layouts[t["layout"]]]
            layout = t["layout"]
        tasks.append(Task(id=t["id"], category=t["category"], layout=layout, prompt=body["prompt"], start=start,
                          targets=list(body["targets"]), oracle=list(body.get("oracle", [])),
                          before=list(t.get("before", [])), start_rule=dict(rule_) if rule_ is not None else None,
                          level=int(t["level"]) if t.get("level") is not None else None,
                          tower=[f"{colour_word(c)} cube" for c in (rule_ or {}).get("tower", [])]))
    layout = data.get("start_layout")
    out = TaskSet(name=data.get("set", Path(path).stem), cube_set=cube_set,
                  cube_size_mm=float(cube_size_mm or data.get("cube_size_mm", 25)), rule=rule, zones=zones, tasks=tasks,
                  half_set=list(data.get("half_set", [])), sha256=hashlib.sha256(raw).hexdigest(), sheet=sheet,
                  area=area, chained=bool(data.get("chained", False)),
                  start_layout={colour_word(c): [float(v) for v in xy] for c, xy in layout.items()} if layout else None,
                  time_limit_s=float(data["time_limit_s"]) if data.get("time_limit_s") else None,
                  level_words={int(k): str(v) for k, v in (data.get("levels") or {}).items()})
    if sheet is not None:
        from app.vision.paper import DESIGNED
        out = out.on_paper(DESIGNED)
    elif area is not None:                         # (each task's default start: one seeded random arrangement)
        from dataclasses import replace
        from watcher.arrange import arrange
        tasks_ = []
        for t in out.tasks:
            if t.start_rule:
                try:
                    t = replace(t, start=arrange(t, out, "default", 0)[0])
                except ValueError:
                    t = replace(t, start=[])
            tasks_.append(t)
        out.tasks = tasks_
    return out


def colour_word(name: str) -> str:
    """"red cube" or "red" -> "red"."""
    return str(name).replace(" cube", "").strip()


def layout_cubes(tasks: "TaskSet") -> list[Cube]:
    """A chained set's starting layout as cubes (the twin sets them out; the person puts them there)."""
    return [Cube(f"{c} cube", xy[0], xy[1], 0.0) for c, xy in (tasks.start_layout or {}).items()]


# ---- towers: what the camera can't see --------------------------------------------------------------------------------
STACKED_MM = 12.0          # two cubes this close (middle to middle, seen from above) at different levels: one on the other


def with_hidden(seen: list[Cube], towers: list[list[str]], size: float = 25.0) -> list[Cube]:
    """The cubes seen, and those a tower hides: for each tower (labels, bottom first) whose cube k is seen at level k+1,
    the cubes below it are under it -- at its x, y, levels 1..k (one of them seen near it at its own level, its side
    face only, is taken to be under it too). The camera looks from above: a cube with another on it isn't seen."""
    out = list(seen)
    for tower in towers:
        for k in range(len(tower) - 1, 0, -1):
            top = next((c for c in out if c.label == tower[k] and c.level == k + 1), None)
            if top is None:
                continue
            for j, label in enumerate(tower[:k]):
                part = next((c for c in out if c.label == label), None)
                if part is not None:
                    if part.level != j + 1 or math.hypot(part.x - top.x, part.y - top.y) > size:
                        continue                     # (somewhere else: not under it)
                    out.remove(part)
                out.append(Cube(label, top.x, top.y, part.yaw if part is not None else top.yaw, j + 1))
            break
    return out


def stacked(a: Cube, b: Cube) -> bool:
    """One of the two on the other (seen from above: the same place, different levels)."""
    return a.level != b.level and math.hypot(a.x - b.x, a.y - b.y) <= STACKED_MM


def task_towers(task: "Task") -> list[list[str]]:
    """The towers a task names: its start's, and each tower target's (bottom first)."""
    out = [list(task.tower)] if task.tower else []
    out += [list(t["tower"]["cubes"]) for t in task.targets if "tower" in t]
    return out


# ---- matching cubes ---------------------------------------------------------------------------------------------------
def angle_difference(a: float, b: float, period: float = 90.0) -> float:
    """The smallest turn between two angles of something that looks the same every `period` degrees."""
    d = (a - b) % period
    return min(d, period - d)


def match(wanted: list[Cube], seen: list[Cube]) -> list[Optional[Cube]]:
    """For each wanted cube, the seen cube of the same colour that is (one of) it: the assignment with the least
    total distance (the Hungarian method), colour by colour. None where fewer were seen than wanted."""
    from scipy.optimize import linear_sum_assignment
    out: list[Optional[Cube]] = [None] * len(wanted)
    for color in {c.color for c in wanted}:
        want_idx = [i for i, c in enumerate(wanted) if c.color == color]
        pool = [c for c in seen if c.color == color]
        if not pool:
            continue
        cost = np.array([[math.hypot(wanted[i].x - s.x, wanted[i].y - s.y) for s in pool] for i in want_idx])
        rows, cols = linear_sum_assignment(cost)          # rectangular is fine: the smaller side is matched in full
        for r, c in zip(rows, cols):
            out[want_idx[r]] = pool[c]
    return out


# ---- scoring ----------------------------------------------------------------------------------------------------------
@dataclass
class TargetResult:
    kind: str
    ok: bool
    position_error_mm: Optional[float] = None
    angle_error_deg: Optional[float] = None
    detail: str = ""
    # which way it was off (for finding a bias, not for scoring): where the cube should have ended and where it did;
    # end minus wanted in the robot's x (+ further out from the base) and y (+ the robot's LEFT, as in the prompts);
    # and the same as radial (+ away from the base, along the line from it) and around (+ counter-clockwise round the
    # base, seen from above); an angle error with its sign (counter-clockwise +)
    cube: str = ""
    wanted_xy: Optional[list] = None
    ended_xy: Optional[list] = None
    dx_mm: Optional[float] = None
    dy_mm: Optional[float] = None
    radial_mm: Optional[float] = None
    around_mm: Optional[float] = None
    angle_signed_deg: Optional[float] = None
    height_ok: Optional[bool] = None       # a tower: its top cube as many cubes up as asked
    on_top: bool = False                   # to go on the table, it ended on top of another cube
    within_mm: Optional[float] = None      # this target's own position tolerance (a cube let drop), if it has one


def _which_way(result: "TargetResult", cube: Optional["Cube"], x: float, y: float, label: str) -> "TargetResult":
    """Adds which way a cube ended from where it should have (x, y) to a target's result."""
    result.cube, result.wanted_xy = label, [round(x, 1), round(y, 1)]
    if cube is None:
        return result
    dx, dy = cube.x - x, cube.y - y
    r = math.hypot(x, y) or 1.0
    result.ended_xy = [round(cube.x, 1), round(cube.y, 1)]
    result.dx_mm, result.dy_mm = round(dx, 1), round(dy, 1)
    result.radial_mm = round((dx * x + dy * y) / r, 1)
    result.around_mm = round((-dx * y + dy * x) / r, 1)
    return result


@dataclass
class Score:
    passed: bool
    targets: list[TargetResult]
    collateral: list[str]            # cubes that moved but shouldn't have
    missing: list[str]               # start cubes not seen at the end (dropped, knocked out of view)
    prepared: list[str] = field(default_factory=list)       # cubes moved out of the way, as allowed (V4.2)
    catastrophic: list[str] = field(default_factory=list)   # what went badly wrong on the table (V4.2), if anything

    @property
    def position_errors(self) -> list[float]:
        return [t.position_error_mm for t in self.targets if t.position_error_mm is not None]

    @property
    def angle_errors(self) -> list[float]:
        return [t.angle_error_deg for t in self.targets if t.angle_error_deg is not None]

    def as_dict(self) -> dict:
        return {"passed": self.passed, "collateral": self.collateral, "missing": self.missing,
                "prepared": self.prepared, "catastrophic": self.catastrophic,
                "targets": [t.__dict__ for t in self.targets]}


# V4.2: a run's outcome, and what counts as going badly wrong
CATASTROPHE_MOVED_MM = 30.0     # a cube the task didn't name (and wasn't in its way) moved this far: badly wrong
EDGE_SLACK_MM = 20.0            # a cube may end this far outside the tray (the slack a task's targets have)
OUTCOMES = ("PASS", "SOME PARTS", "FAIL", "SKIPPED")


def _in_area(area: Optional[dict], c: "Cube", slack: float) -> bool:
    if area is None:
        return True
    return area["x"][0] - slack <= c.x <= area["x"][1] + slack and area["y"][0] - slack <= c.y <= area["y"][1] + slack


def outcome(result: "Score", at_start: Optional["Score"] = None, moved: Optional[set] = None) -> str:
    """PASS (the strict pass, unchanged), SOME PARTS (a part met that wasn't met at the start already, its cube moved
    by the run -- `moved`: the cubes that moved more than MOVED_FOR_A_PART_MM or changed level; doing nothing, or camera
    noise round a tolerance, can't score), or FAIL."""
    if result.passed:
        return "PASS"
    already = [t.ok for t in at_start.targets] if at_start is not None else [False] * len(result.targets)
    for t, was in zip(result.targets, already + [False] * len(result.targets)):
        if t.ok and not was and (moved is None or not t.cube or t.cube in moved):
            return "SOME PARTS"
    return "FAIL"


MOVED_FOR_A_PART_MM = 5.0


def moved_cubes(start: list["Cube"], end: list["Cube"]) -> set:
    """The cubes that moved more than MOVED_FOR_A_PART_MM, or changed level, between the start and the end."""
    out = set()
    for s, f in zip(start, match(start, end)):
        if f is not None and (math.hypot(f.x - s.x, f.y - s.y) > MOVED_FOR_A_PART_MM or f.level != s.level):
            out.add(s.label)
    return out


def score(task: Task, end: list[Cube], zones: dict[str, Zone], rule: PassRule, cube_size_mm: float = 25.0,
          start: Optional[list[Cube]] = None, may_move: Optional[dict] = None, area: Optional[dict] = None) -> Score:
    """Scores a run: `start` the cubes as they really were at the start (the measured layout; default: the task's
    own), `end` the cubes seen at the end. Every target must hold within the pass rule, and no cube the task doesn't
    act on may have moved more than rule.collateral_mm -- except one in its way at the start (`may_move`: {label:
    why}, watcher/arrange.py blocking_cubes), which may be moved out of the way if it ends on the table, not stacked,
    inside the tray (`area`, with EDGE_SLACK_MM). Also says what went badly wrong (Score.catastrophic): a cube not seen
    at the end, one ended past the tray's edge, one the task didn't name moved more than CATASTROPHE_MOVED_MM, or a
    tower the task didn't name brought down."""
    may_move = may_move or {}
    start = start or task.start
    towers = task_towers(task)
    if towers:                                     # (the cubes a tower hides: under the cube seen on top)
        start = with_hidden(start, [list(task.tower)] if task.tower else [], cube_size_mm)
        end = with_hidden(end, towers, cube_size_mm)
    finals = match(start, end)                     # each start cube -> where it ended (None: not seen)
    by_label: dict[str, list[int]] = {}
    for i, c in enumerate(start):
        by_label.setdefault(c.label, []).append(i)

    def one(label: str) -> tuple[Optional[Cube], Optional[Cube]]:
        """(start, end) of the cube with this label (the tasks only name a cube where its colour is unique)."""
        idx = by_label.get(label, [])
        if not idx:
            return None, None
        return start[idx[0]], finals[idx[0]]

    results: list[TargetResult] = []
    acted: set[str] = set(task.oracle)
    for target in task.targets:
        (kind, spec), = target.items()
        # (a "beside" / "between" target's other cubes are named in it: PREREG 4 holds to the 10 mm rule only the
        # cubes named in neither the targets nor the oracle -- a tower base nudged by the lift failed S-12 as moved)
        acted.update(str(spec[key]) for key in (("of",) if kind == "beside" else ("a", "b") if kind == "between"
                                                else ()) if key in spec)
        results.append(_check(kind, spec, one, start, finals, zones, rule, cube_size_mm, acted))
        if "within_mm" in spec:
            results[-1].within_mm = float(spec["within_mm"])

    collateral, prepared, catastrophic = [], [], []
    for s, f in zip(start, finals):
        if s.label in acted:            # (cubes of one colour share a label: acting on "red cube" frees them all)
            continue
        moved = math.hypot(f.x - s.x, f.y - s.y) if f is not None else 0.0
        if s.label in may_move and f is not None and (moved > rule.collateral_mm or f.level != s.level):
            stays = (f.level == 1 and _in_area(area, f, EDGE_SLACK_MM)
                     and not any(o is not None and o is not f and stacked(f, o) for o in finals))
            if stays:                   # (out of the way, as allowed: on the table, not stacked, inside the tray)
                prepared.append(f"{s.label} moved {moved:.0f} mm out of the way ({may_move[s.label]})")
                continue
            collateral.append(f"{s.label} moved out of the way but left " +
                              ("outside the tray" if f.level == 1 and not any(
                                  o is not None and o is not f and stacked(f, o) for o in finals)
                               else "on another cube"))
            continue
        if f is not None and moved > rule.collateral_mm:
            collateral.append(f"{s.label} moved {moved:.0f} mm")
            if moved > CATASTROPHE_MOVED_MM:
                catastrophic.append(f"the {s.label}, not part of the task, moved {moved:.0f} mm")
        if f is not None and s.level > 1 and f.level == 1 and s.label not in may_move:
            catastrophic.append(f"the tower the {s.label} stood on came down")
    # a cube only asked to turn must stay where it was (within the same 10 mm): "turn it" doesn't mean "move it"
    for label in sorted(yaw_only_cubes(task)):
        s, f = one(label)
        if s is not None and f is not None and math.hypot(f.x - s.x, f.y - s.y) > rule.collateral_mm:
            collateral.append(f"{label} moved {math.hypot(f.x - s.x, f.y - s.y):.0f} mm though it was only to be "
                              "turned")
    missing = [s.label for s, f in zip(start, finals) if f is None]
    collateral += [f"{s.label} not seen at the end (knocked off?)" for s, f in zip(start, finals)
                   if f is None and s.label not in acted]
    catastrophic += [f"the {label} can't be seen at the end (knocked off the table?)" for label in missing]
    # (outside the tray: badly wrong unless it was there already and left alone -- or it's one of the task's cubes and
    # every target was met, so it ended where it was asked to go: a swap with a cube left outside earlier)
    catastrophic += [f"the {f.label} ended outside the tray, at ({f.x:.0f}, {f.y:.0f})" for s, f in zip(start, finals)
                     if f is not None and not _in_area(area, f, EDGE_SLACK_MM)
                     and (_in_area(area, s, EDGE_SLACK_MM) or math.hypot(f.x - s.x, f.y - s.y) > rule.collateral_mm)
                     and not (s.label in acted and all(r.ok for r in results))]
    passed = all(r.ok for r in results) and not collateral
    return Score(passed=passed, targets=results, collateral=collateral, missing=missing, prepared=prepared,
                 catastrophic=list(dict.fromkeys(catastrophic)))


# ---- partial credit: how close, not only whether ------------------------------------------------------------------
# Next to the pass rule's strict pass / fail, a 0-100 score (Rafi and Dr. Curry, 2026-10-22): each target earns 0 to 1 --
# full within the pass rule, falling evenly to 0 at ZERO_AT times it (a cube let drop: within its own `within_mm`, 0 at
# that + DROP_ZERO_EXTRA_MM); a tower half for its height, half for where it stands; the task the mean of its targets;
# then KNOCKED_POINTS off for each other cube moved, KNOCKED_OFF_POINTS for one not seen at the end. Bands: Full (>= 90,
# about a pass), Partial (50-89), Fail (< 50). Nothing done, or the wrong cube moved, scores 0 by itself (every target
# is then far off). Refused steps, time and alarms are reported beside it, never mixed in.
ZERO_AT = 3.0
DROP_ZERO_EXTRA_MM = 30.0
KNOCKED_POINTS, KNOCKED_OFF_POINTS = 25, 50
BANDS = ((90, "Full"), (50, "Partial"), (0, "Fail"))


def _ramp(error: Optional[float], full: float, zero: float) -> float:
    """1 within `full`, 0 from `zero` on, evenly between (None: not seen -- 0)."""
    if error is None:
        return 0.0
    if error <= full:
        return 1.0
    return max(0.0, (zero - error) / (zero - full)) if zero > full else 0.0


def target_credit(t: TargetResult, rule: PassRule) -> float:
    """One target's credit, 0 to 1 (see ZERO_AT)."""
    full = t.within_mm if t.within_mm is not None else rule.position_mm
    zero = full + DROP_ZERO_EXTRA_MM if t.within_mm is not None else rule.position_mm * ZERO_AT
    position = 0.0 if t.on_top else _ramp(t.position_error_mm, full, zero)
    if t.kind == "tower":
        return 0.5 * bool(t.height_ok) + 0.5 * position
    if t.kind in ("turned", "yaw"):
        return _ramp(t.angle_error_deg, rule.angle_deg, rule.angle_deg * ZERO_AT)
    if t.position_error_mm is None and t.angle_error_deg is None:
        return 1.0 if t.ok else 0.0               # (a zone emptied, all of a colour in a zone: met or not)
    return 1.0 if t.ok else position


def partial_credit(result: Score, rule: PassRule) -> dict:
    """{"score": 0-100, "band": Full / Partial / Fail, "targets": [each target's 0-1], "knocked_points": ...}."""
    credits = [round(target_credit(t, rule), 3) for t in result.targets]
    knocked = sum(KNOCKED_OFF_POINTS if "not seen at the end" in c else KNOCKED_POINTS for c in result.collateral)
    raw = 100.0 * sum(credits) / len(credits) if credits else 0.0
    points = int(round(max(0.0, raw - knocked)))
    band = next(name for floor, name in BANDS if points >= floor)
    return {"score": points, "band": band, "targets": credits, "knocked_points": knocked,
            "rule": f"each target full within the pass rule, 0 at {ZERO_AT:g}x it (a drop: its own +"
                    f"{DROP_ZERO_EXTRA_MM:.0f} mm); towers half height, half place; -{KNOCKED_POINTS} per other cube "
                    f"moved, -{KNOCKED_OFF_POINTS} if knocked off; Full >= 90, Partial >= 50"}


# beside's sides: the robot's own (left +y, right -y; further from the base +x, nearer -x -- as the app's place_beside
# puts it: front = further, behind = nearer)
BESIDE_SIDES = {"left": (0.0, 1.0), "right": (0.0, -1.0), "further": (1.0, 0.0), "front": (1.0, 0.0),
                "nearer": (-1.0, 0.0), "behind": (-1.0, 0.0)}
SIDE_WORDS = {"left": "to the robot's left of", "right": "to the robot's right of",
              "further": "further from the robot than", "front": "further from the robot than",
              "nearer": "nearer the robot than", "behind": "nearer the robot than"}


def beside_point(of: "Cube", side: str, size: float, gap: float) -> tuple[float, float]:
    """Where a cube goes `gap` mm (edge to edge) to `side` of `of`."""
    if side not in BESIDE_SIDES:
        raise ValueError(f"beside: unknown side {side!r} ({', '.join(BESIDE_SIDES)})")
    ux, uy = BESIDE_SIDES[side]
    return of.x + ux * (size + gap), of.y + uy * (size + gap)


POSITION_KINDS = {"in_zone": ("cube",), "moved": ("cube",), "beside": ("cube",), "between": ("cube",),
                  "from_spot": ("cube",), "at_start": ("cube",), "swapped": ("a", "b"), "row": ("cubes",),
                  "tower": ("cubes",)}


def position_targets(task: Task) -> dict[str, int]:
    """How many targets say where each cube must end (a cube with two can't satisfy both: each is checked against its
    final place)."""
    out: dict[str, int] = {}
    for target in task.targets:
        (kind, spec), = target.items()
        for field in POSITION_KINDS.get(kind, ()):
            names = spec.get(field) if isinstance(spec.get(field), list) else [spec.get(field)]
            for name in names:
                if name:
                    out[name] = out.get(name, 0) + 1
    return out


def yaw_only_cubes(task: Task) -> set[str]:
    """The cubes a task only asks to turn (no target says where they end)."""
    turned = {t["yaw"]["cube"] for t in task.targets if "yaw" in t}
    turned |= {t["turned"]["cube"] for t in task.targets if "turned" in t}
    return turned - set(position_targets(task))


def _check(kind, spec, one, start, finals, zones, rule, size, acted) -> TargetResult:
    tol = float(spec.get("within_mm", rule.position_mm))     # (a cube let drop: its own, looser tolerance)

    def at(cube: Optional[Cube], x: float, y: float, what: str) -> TargetResult:
        if cube is None:
            return _which_way(TargetResult(kind, False, detail=f"{what}: not seen at the end"), None, x, y, what)
        err = math.hypot(cube.x - x, cube.y - y)
        on_top = cube.level > 1 and kind != "tower"          # (on another cube, when it was to be on the table)
        return _which_way(TargetResult(kind, err <= tol and not on_top, position_error_mm=round(err, 1),
                                       detail=f"{what}: {err:.1f} mm from ({x:.0f}, {y:.0f})"
                                              + (" -- but on top of another cube" if on_top else ""), on_top=on_top),
                          cube, x, y, what)

    if kind == "in_zone":
        acted.add(spec["cube"])
        _, f = one(spec["cube"])
        zone = zones[spec["zone"]]
        if f is None:
            return _which_way(TargetResult(kind, False, detail=f"{spec['cube']}: not seen at the end"), None,
                              zone.cx, zone.cy, spec["cube"])
        out = zone.distance_outside(f)
        # (passes when inside; the error reported is how far from the spot's middle -- for a spot -- so it means the
        # same as every other target's error, rather than 0.0 anywhere inside the 10 mm circle)
        error = math.hypot(f.x - zone.cx, f.y - zone.cy) if zone.spot is not None else out
        return _which_way(TargetResult(kind, out == 0.0, position_error_mm=round(error, 1),
                                       detail=f"{spec['cube']} {'in' if out == 0 else f'{out:.1f} mm outside'} "
                                              f"{zone.name}"), f, zone.cx, zone.cy, spec["cube"])
    if kind == "all_in_zone":
        color, zone = spec["color"], zones[spec["zone"]]
        acted.add(f"{color} cube")
        ends = [f for s, f in zip(start, finals) if s.color == color]
        outside = [zone.distance_outside(f) if f is not None else math.inf for f in ends]
        worst = max(outside) if outside else 0.0
        return TargetResult(kind, worst == 0.0, position_error_mm=None if math.isinf(worst) else round(worst, 1),
                            detail=f"{len(ends)} {color} cube(s); worst {worst:.1f} mm outside {zone.name}")
    if kind in ("moved", "at_start") and one(spec["cube"])[0] is None:
        acted.add(spec["cube"])
        return TargetResult(kind, False, detail=f"{spec['cube']}: not in the start layout")
    if kind == "swapped" and (one(spec["a"])[0] is None or one(spec["b"])[0] is None):
        acted.update((spec["a"], spec["b"]))
        return TargetResult(kind, False, detail="a cube of the swap wasn't in the start layout")
    if kind == "moved":
        acted.add(spec["cube"])
        s, f = one(spec["cube"])
        if "radial" in spec:
            r = math.hypot(s.x, s.y)
            k = (r + float(spec["radial"])) / r
            return at(f, s.x * k, s.y * k, spec["cube"])
        return at(f, s.x + float(spec.get("dx", 0)), s.y + float(spec.get("dy", 0)), spec["cube"])
    if kind == "beside":
        acted.add(spec["cube"])
        _, f = one(spec["cube"])
        _, of = one(spec["of"])
        if of is None:
            return TargetResult(kind, False, detail=f"{spec['of']}: not seen at the end")
        x, y = beside_point(of, spec["side"], size, float(spec["gap"]))
        return at(f, x, y, spec["cube"])
    if kind == "between":
        acted.add(spec["cube"])
        _, f = one(spec["cube"])
        (_, a), (_, b) = one(spec["a"]), one(spec["b"])
        if a is None or b is None:
            return TargetResult(kind, False, detail="a reference cube wasn't seen at the end")
        return at(f, (a.x + b.x) / 2, (a.y + b.y) / 2, spec["cube"])
    if kind == "yaw":
        acted.add(spec["cube"])
        _, f = one(spec["cube"])
        if f is None:
            return TargetResult(kind, False, detail=f"{spec['cube']}: not seen at the end")
        err = angle_difference(f.yaw, float(spec["deg"]))
        signed = (f.yaw - float(spec["deg"]) + 45.0) % 90.0 - 45.0
        return TargetResult(kind, err <= rule.angle_deg, angle_error_deg=round(err, 1),
                            detail=f"{spec['cube']} at {f.yaw % 90:.1f} deg, wanted {spec['deg']}",
                            cube=spec["cube"], angle_signed_deg=round(signed, 1))
    if kind == "turned":                            # turned BY deg from where it started (+ anticlockwise)
        acted.add(spec["cube"])
        s, f = one(spec["cube"])
        if s is None or f is None:
            return TargetResult(kind, False, detail=f"{spec['cube']}: not seen " + ("at the start" if s is None else
                                                                                   "at the end"))
        wanted = s.yaw + float(spec["deg"])
        err = angle_difference(f.yaw, wanted)
        signed = (f.yaw - wanted + 45.0) % 90.0 - 45.0
        either = angle_difference(2.0 * float(spec["deg"]), 0.0) <= rule.angle_deg   # (the other way passes too)
        return TargetResult(kind, err <= rule.angle_deg, angle_error_deg=round(err, 1),
                            detail=f"{spec['cube']} turned {float(spec['deg']) + signed:+.1f} deg, wanted "
                                   f"{float(spec['deg']):+.0f} (a cube looks the same every 90"
                                   + ("; turned the other way it ends the same: the way the wrist went is in "
                                      "picks.csv, release_turned)" if either else ")"), cube=spec["cube"],
                            angle_signed_deg=round(signed, 1))
    if kind == "row":
        cubes = [one(label)[1] for label in spec["cubes"]]
        acted.update(spec["cubes"])
        if any(c is None for c in cubes):
            return TargetResult(kind, False, detail="a cube of the row wasn't seen at the end")
        result = _row(kind, cubes, spec.get("gap"), size, tol)
        order = spec.get("order")                   # left to right, the robot's: its left is +y
        if order:
            seen = [c.label for c in sorted(cubes, key=lambda c: -c.y)]
            if max(c.y for c in cubes) - min(c.y for c in cubes) < max(c.x for c in cubes) - min(c.x for c in cubes):
                result.ok = False
                result.detail += "; the row runs away from the robot, not from its left to its right"
            elif seen != list(order):
                result.ok = False
                result.detail += f"; order {', '.join(seen)} from left to right, wanted {', '.join(order)}"
        return result
    if kind == "swapped":
        acted.update((spec["a"], spec["b"]))
        (sa, fa), (sb, fb) = one(spec["a"]), one(spec["b"])
        ra, rb = at(fa, sb.x, sb.y, spec["a"]), at(fb, sa.x, sa.y, spec["b"])
        errs = [e for e in (ra.position_error_mm, rb.position_error_mm) if e is not None]
        # (both, or none: one cube not seen at the end -- knocked off -- left the other's error alone, and a swap with
        # a cube swept off the table scored 100 "Full" -- reviewer 2, 2026-10-27)
        out = TargetResult(kind, ra.ok and rb.ok, position_error_mm=max(errs) if len(errs) == 2 else None,
                           detail=f"{ra.detail}; {rb.detail}")
        worse = rb if (rb.position_error_mm or 0) > (ra.position_error_mm or 0) or ra.ended_xy is None and \
            rb.ended_xy is not None else ra                 # (which way: the cube further off)
        for name in ("cube", "wanted_xy", "ended_xy", "dx_mm", "dy_mm", "radial_mm", "around_mm"):
            setattr(out, name, getattr(worse, name))
        return out
    if kind == "at_start":
        acted.add(spec["cube"])
        s, f = one(spec["cube"])
        return at(f, s.x, s.y, spec["cube"])
    if kind == "zone_empty":
        zone = zones[spec["zone"]]
        inside = [f.label for f in finals if f is not None and zone.contains(f)]
        return TargetResult(kind, not inside, detail=f"{zone.name}: " + (", ".join(inside) or "empty"))
    if kind == "from_spot":
        acted.add(spec["cube"])
        _, f = one(spec["cube"])
        x, y = from_spot_point(zones[spec["spot"]], spec["side"], float(spec["distance"]))
        return at(f, x, y, spec["cube"])
    if kind == "tower":                             # bottom first: the top seen at the tower's height, over the bottom
        cubes = list(spec["cubes"])                 # cube's start (those under it are hidden from the camera)
        acted.update(cubes)
        bottom, _ = one(cubes[0])
        _, top = one(cubes[-1])
        if bottom is None:
            return TargetResult(kind, False, detail=f"{cubes[0]}: not in the start layout")
        result = at(top, bottom.x, bottom.y, cubes[-1])
        result.height_ok = top is not None and top.level == len(cubes)
        if top is not None and top.level != len(cubes):
            result.ok = False
            result.detail += f"; the {cubes[-1]} is {top.level} cube(s) up, wanted {len(cubes)} (a tower of {len(cubes)})"
        elif top is not None and len(cubes) > 2:
            result.detail += "; the middle cube is hidden from the camera (its place: the app's own record)"
        return result
    raise ValueError(f"unknown target kind {kind!r}")


def from_spot_point(spot: Zone, side: str, distance: float) -> tuple[float, float]:
    """The point `distance` mm from a spot's middle: to the robot's left (+y) or right (-y), or towards (-x) or away
    from (+x) the robot, along the sheet's "robot this way" arrow (the way the app's move_object moves)."""
    if side in ("left", "right"):
        return spot.cx, spot.cy + (distance if side == "left" else -distance)
    if side in ("towards", "away"):
        return spot.cx + (distance if side == "away" else -distance), spot.cy
    raise ValueError(f"from_spot: unknown side {side!r} (left, right, towards, away)")


def _zone_name(key: str) -> str:
    return f"spot {key.split('_')[-1]}" if key.startswith("spot_") else f"zone {key.split('_')[-1].upper()}"


def _zone_mark(key: str) -> str:
    return "its printed outline" if key.startswith("spot_") else "the yellow square"


def _direction(dx: float, dy: float) -> str:
    parts = []
    if dy:
        parts.append(f"{abs(dy):.0f} mm to the robot's {'left' if dy > 0 else 'right'}")
    if dx:
        parts.append(f"{abs(dx):.0f} mm {'away from' if dx > 0 else 'towards'} the robot")
    return " and ".join(parts) or "where it was"


def how_to_judge(task: Task, rule: PassRule) -> list[str]:
    """What counts as a pass for this task, in words, for the person giving the verdict: the same checks score()
    makes (a cube's position is its middle; the start is where it stood before the run, drawn grey)."""
    lines = []
    for target in task.targets:
        (kind, spec), = target.items()
        tol = float(spec.get("within_mm", rule.position_mm))      # (a cube let drop: looser, any angle)
        if kind == "in_zone" and spec["zone"].startswith("spot_"):
            lines.append(f"the {spec['cube']} is on {_zone_name(spec['zone'])} ({_zone_mark(spec['zone'])}), its "
                         f"middle within {SPOT_SIZE_MM / 2:.0f} mm of the spot's")
        elif kind == "in_zone":
            lines.append(f"the {spec['cube']}'s middle is inside {_zone_name(spec['zone'])} (the yellow square)")
        elif kind == "all_in_zone":
            lines.append(f"every {spec['color']} cube's middle is inside {_zone_name(spec['zone'])} "
                         "(the yellow square)")
        elif kind == "moved" and "radial" in spec:
            d = float(spec["radial"])
            lines.append(f"the {spec['cube']} is {abs(d):.0f} mm {'further from' if d > 0 else 'nearer to'} the robot "
                         f"than its grey start outline, within {tol:.0f} mm")
        elif kind == "moved":
            lines.append(f"the {spec['cube']} is {_direction(float(spec.get('dx', 0)), float(spec.get('dy', 0)))} "
                         f"from its grey start outline, within {tol:.0f} mm")
        elif kind == "beside":
            lines.append(f"the {spec['cube']} is {SIDE_WORDS.get(spec['side'], spec['side'])} the {spec['of']}, in "
                         f"line with it, a {spec['gap']} mm gap between them, within {tol:.0f} mm")
        elif kind == "turned":
            d = float(spec["deg"])
            lines.append(f"the {spec['cube']} is turned {abs(d):.0f} degrees {'anticlockwise' if d > 0 else 'clockwise'} "
                         f"(seen from above) from how it started, within {rule.angle_deg:.0f} degrees")
        elif kind == "between":
            lines.append(f"the {spec['cube']} is halfway between the {spec['a']} and the {spec['b']}, within "
                         f"{tol:.0f} mm")
        elif kind == "yaw":
            lines.append(f"the {spec['cube']} is turned to {spec['deg']} degrees, within {rule.angle_deg:.0f} degrees "
                         "(it looks the same every 90)")
        elif kind == "row":
            names = ", ".join(spec["cubes"][:-1]) + f" and {spec['cubes'][-1]}"
            lines.append(f"the {names} are in a straight line, each within {tol:.0f} mm of it"
                         + (f", {spec['gap']} mm gaps between neighbours" if spec.get("gap") is not None else "")
                         + (f", {', '.join(spec['order'])} from the robot's left to its right"
                            if spec.get("order") else ""))
        elif kind == "swapped":
            lines.append(f"the {spec['a']} stands where the {spec['b']} started and the {spec['b']} where the "
                         f"{spec['a']} started (the grey start outlines), each within {tol:.0f} mm")
        elif kind == "at_start":
            lines.append(f"the {spec['cube']} is back on its grey start outline, within {tol:.0f} mm")
        elif kind == "zone_empty":
            lines.append(f"no cube's middle is inside {_zone_name(spec['zone'])} ({_zone_mark(spec['zone'])})")
        elif kind == "tower":
            lines.append(f"a tower of {len(spec['cubes'])} cubes where the {spec['cubes'][0]} started: "
                         f"{', then '.join(spec['cubes'])} on top (bottom first), the top one within {tol:.0f} mm of "
                         "the bottom one's start")
        elif kind == "from_spot":
            where = {"left": "to the robot's left of", "right": "to the robot's right of",
                     "towards": "nearer the robot than", "away": "further from the robot than"}[spec["side"]]
            lines.append(f"the {spec['cube']}'s middle is {spec['distance']} mm {where} {_zone_name(spec['spot'])}'s "
                         f"middle, within {tol:.0f} mm")
    lines.append(f"no other cube moved more than {rule.collateral_mm:.0f} mm, and none fell off the table")
    return lines


def _row(kind: str, cubes: list[Cube], gap: Optional[float], size: float, tol: float) -> TargetResult:
    """In a straight line (each centre within tol of the best-fit line); with a gap, the faces of neighbours that far
    apart, each within tol."""
    mx = sum(c.x for c in cubes) / len(cubes)
    my = sum(c.y for c in cubes) / len(cubes)
    sxx = sum((c.x - mx) ** 2 for c in cubes)
    syy = sum((c.y - my) ** 2 for c in cubes)
    sxy = sum((c.x - mx) * (c.y - my) for c in cubes)
    theta = 0.5 * math.atan2(2 * sxy, sxx - syy)               # direction of the best-fit line
    ux, uy = math.cos(theta), math.sin(theta)
    off_line = max(abs(-(c.x - mx) * uy + (c.y - my) * ux) for c in cubes)
    worst = off_line
    detail = f"{off_line:.1f} mm off the line"
    if gap is not None:
        along = sorted((c.x - mx) * ux + (c.y - my) * uy for c in cubes)
        gap_errors = [abs((b - a) - size - float(gap)) for a, b in zip(along, along[1:])]
        worst = max(worst, max(gap_errors))
        detail += "; gaps " + ", ".join(f"{(b - a) - size:.0f}" for a, b in zip(along, along[1:])) + f" mm (want {gap})"
    return TargetResult(kind, worst <= tol, position_error_mm=round(worst, 1), detail=detail)


# ---- how hard a task is (for the map of where the arm fails) ----------------------------------------------------------
def difficulty(task: Task, cube_size_mm: float = 25.0, min_reach_mm: float = 160.0, max_reach_mm: float = 300.0) -> dict:
    """Features of a task from its layout and targets: how far its cubes are from the base and from the edges of
    reach, the turn it asks for, how crowded the table is, and how many cubes it acts on."""
    acted = [c for c in task.start if c.label in task.oracle] or list(task.start)
    radii = [math.hypot(c.x, c.y) for c in acted]
    margins = [min(r - min_reach_mm, max_reach_mm - r) for r in radii]
    turn = 0.0
    for target in task.targets:
        (kind, spec), = target.items()
        if kind == "yaw":
            start = next((c for c in task.start if c.label == spec["cube"]), None)
            if start is not None:
                turn = max(turn, angle_difference(float(spec["deg"]), start.yaw))
        elif kind == "turned":
            turn = max(turn, abs(float(spec["deg"])))
    gaps = [math.hypot(a.x - b.x, a.y - b.y) - cube_size_mm
            for i, a in enumerate(task.start) for b in task.start[i + 1:]]
    return {"category": task.category, "layout": task.layout,
            "max_radius_mm": round(max(radii), 1) if radii else None,
            "min_radius_mm": round(min(radii), 1) if radii else None,
            "min_reach_margin_mm": round(min(margins), 1) if margins else None,
            "turn_asked_deg": round(turn, 1), "min_gap_mm": round(min(gaps), 1) if gaps else None,
            "cubes_acted_on": len(acted), "cubes_on_table": len(task.start)}

"""The watcher: runs the study's fixed tasks on the real Dobot with nobody typing, records everything and scores each
run (see study/RUNBOOK.md). Frozen at the study-v0 tag: the study's rounds must not change it."""

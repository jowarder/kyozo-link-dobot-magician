"""Where every result of the study goes, saved the moment it happens (see study/RUNBOOK.md).

One main folder next to the project, Kyozo_Link_Results, its folders named after the watcher's Session menu:

    study_1\\  study_2\\ ... study_10\\         one folder per study (the watcher's Study box; the app's version: v0, v1, ...)
        Test_Twin_with_unseen_tasks\\        Test Twin with unseen tasks          -- never shown to Claude
        Test_Real_Dobot_with_unseen_tasks\\  Test Real Dobot with unseen tasks    -- never shown to Claude
        20_Tasks_for_Twin\\                  20 Tasks for Twin (by itself)        -- Claude's input
        20_Tasks_for_Dobot\\                 20 Tasks for Dobot (by itself)       -- Claude's input
        (Twin_Training_Data\\, Dobot_Training_Data\\: the training sessions, kept in the code, out of the menu)
    Practice_Session\\practice_study_N\\<the same four>     the same for practice (the watcher's "Practice session"
                                                          toggle on)
    Prompt_Runs\\                           prompts typed in the main window with "Watcher active" on
    For_Claude\\study_N\\                    Claude's input for the next version (practice's in For_Claude\\
                                           Practice_Session\\practice_study_N\\): START_HERE.md, SUMMARY.md, a
                                           folder per kind of data (watcher/handoff.py)
    Private_never_for_Claude\\              everything Claude never reads, in one place:
        Test_Tasks\\test.yaml                the unseen test tasks
        Study_Overview\\                     study 1 vs 2 vs 3 (watcher/overview.py; practice's: Study_Overview_practice\\)
        Recycle_Bin_test\\                   the unseen test's discarded or replaced runs, and their deletions log
    Backup_do_not_edit\\                    a zip of each real kind folder at every session's end
    Recycle_Bin\\                           every run discarded or replaced, whole, with why.txt -- the same path
                                           as its kind's folder (study_1\\20_Tasks_for_Dobot\\...). Never emptied
                                           by the watcher.
    deletions_log.txt
    _earlier_results\\                      what earlier layouts saved, moved aside (nothing deleted)

Inside each kind's folder:

    FULL_REPORT.md, FULL_REPORT.html, full_report.json, results.xlsx, results_*.csv    every saved run, remade
                                                                                       after each Save
    User_Saved_<kind folder>\\S-07_Run1.md ...     one file per saved run (its tag chosen when it is saved)
        HTML_version\\S-07_Run1.html ...          the same run as one web page, its pictures built in
    _raw_data\\S-07_Run1\\                        the evidence: run.json, trace.json, pictures, depth, csv files
    _raw_data\\_pending\\                         a run scored but not saved yet (Discard sends it away)
    _sessions_log\\<date>_<time>\\                each sitting's record: session.json and its hash-chained index

Nothing is overwritten: every file is written whole (to a temporary name, then renamed), a saved run is only replaced
when you say so at Save (the old one moved, whole, to Recycle_Bin), and each sitting keeps an index whose lines are
chained by their hashes, so a changed or missing line shows. A discarded or replaced run goes to Recycle_Bin; deleting
a whole folder (Delete results...) sends it to the Windows Recycle Bin. A real one is noted, with a reason, in
deletions_log.txt.
"""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent
RESULTS_ROOT = PROJECT_ROOT.parent / "Kyozo_Link_Results"

MAX_STUDIES = 10                                   # (3 until 2026-10-26: Dr. Curry agreed to up to 10 studies)
STUDIES = {n: f"study_{n}" for n in range(1, MAX_STUDIES + 1)}
ROUNDS = STUDIES                                   # (the study's rounds: one study folder each)
KINDS = {("train", "twin"): "Twin_Training_Data", ("train", "dobot"): "Dobot_Training_Data",
         # named after the watcher's Session menu (V4.2)
         ("test", "twin"): "Test_Twin_with_unseen_tasks", ("test", "dobot"): "Test_Real_Dobot_with_unseen_tasks",
         # Simple 20 (study/tasks/simple.yaml): the 20 tasks by themselves, kept apart from the training and the test
         ("simple", "twin"): "20_Tasks_for_Twin", ("simple", "dobot"): "20_Tasks_for_Dobot"}
PRACTICE = "Practice_Session"
PROMPT_RUNS = "Prompt_Runs"                        # prompts typed in the main window with "Watcher active" on
FOR_CLAUDE = "For_Claude"
BACKUP = "Backup_do_not_edit"
RECYCLE = "Recycle_Bin"
EARLIER = "_earlier_results"                       # what earlier layouts saved, moved aside
PRIVATE_ROOT = "Private_never_for_Claude"          # everything Claude never reads, in one folder (one deny rule)
TEST_TASKS = Path(PRIVATE_ROOT) / "Test_Tasks"
OVERVIEW = Path(PRIVATE_ROOT) / "Study_Overview"
OVERVIEW_PRACTICE = Path(PRIVATE_ROOT) / "Study_Overview_practice"
RECYCLE_TEST = Path(PRIVATE_ROOT) / "Recycle_Bin_test"     # the unseen test's discarded / replaced runs
DELETIONS_LOG = "deletions_log.txt"
RAW, PENDING, SESSIONS_LOG, HTML_VERSION = "_raw_data", "_pending", "_sessions_log", "HTML_version"
# folders Claude never reads (besides every unseen-test kind folder), the earlier layouts' names too
PRIVATE = (PRIVATE_ROOT, BACKUP, EARLIER, "Test_Tasks_private", "Study_Overview_private", "Test_private")


def test_set_file(root: Path = RESULTS_ROOT) -> Path:
    """Where the test set is: Private_never_for_Claude\\Test_Tasks\\test.yaml, and only there (a set left in the old places -- the
    16-task design's -- is retired, never read). Raises with what to do if it isn't there."""
    path = Path(root) / TEST_TASKS / "test.yaml"
    if path.exists():
        return path
    raise FileNotFoundError(
        f"The test set isn't in place. Make it with Make test tasks... (or study/make_test_tasks.py): it writes "
        f"{Path(root) / TEST_TASKS}\\test.yaml. Until then, practise with the Training set.")


def kind_folder(real: bool, set_name: str, where: str, study_no: int, root: Path = RESULTS_ROOT) -> Path:
    """The folder a kind of session saves into: study_N\\<kind> (real) or Practice_Session\\practice_study_N\\<kind>
    (practice). set_name: "train", "test" or "simple"; where: "twin" or "dobot"."""
    key = (set_name, where)
    if key not in KINDS:
        raise ValueError(f"no folder for {set_name} runs in the {where}")
    if study_no not in STUDIES:
        raise ValueError(f"the study's studies are {', '.join(map(str, STUDIES))} (not {study_no})")
    if real:
        return root / STUDIES[study_no] / KINDS[key]
    return root / PRACTICE / f"practice_{STUDIES[study_no]}" / KINDS[key]


def saved_folder(kind: Path) -> Path:
    """User_Saved_<kind folder>: one .md file per saved run."""
    return Path(kind) / f"User_Saved_{Path(kind).name}"


def html_folder(kind: Path) -> Path:
    """User_Saved_<kind folder>\\HTML_version: one web page per saved run."""
    return saved_folder(kind) / HTML_VERSION


def raw_folder(kind: Path) -> Path:
    return Path(kind) / RAW


def is_test_path(path: Path) -> bool:
    """A path in (or of) the unseen test, its tasks, the overview or the backups: never Claude's to read."""
    parts = [p for p in Path(path).parts]
    return any(p.endswith(("Test_Data", "with_unseen_tasks")) or p in PRIVATE or p.upper() in ("TEST_SET", "1_TEST_TWIN", "2_TEST_DOBOT")
               for p in parts)


def is_real_path(path: Path, root: Path = RESULTS_ROOT) -> bool:
    """A path in the real study (a study_N folder), its backups or its runs in Recycle_Bin: deleting it needs a
    reason."""
    path, root = Path(path).resolve(), Path(root).resolve()
    bases = [base / s for base in (root, root / RECYCLE, root / RECYCLE_TEST) for s in STUDIES.values()]
    bases += [root / BACKUP, root / EARLIER, root / RECYCLE / "Test_private"]
    # inside a real folder -- or a folder that holds one (Recycle_Bin itself, the private folder): deleting
    # it would take real runs with it
    return any(base in (path, *path.parents) or (path in base.parents and base.exists()) for base in bases)


def recycle_folder(kind: Path, root: Path = RESULTS_ROOT) -> Path:
    """Where a kind's discarded and replaced runs go: Recycle_Bin\\<the kind's path in the results> (an unseen-test
    kind's under Private_never_for_Claude\\Recycle_Bin_test, with the other private folders)."""
    kind, root = Path(kind).resolve(), Path(root).resolve()
    rel = kind.relative_to(root)
    base = root / RECYCLE_TEST if is_test_path(rel) else root / RECYCLE
    return base / rel


def saved_runs(kind: Path, task_id: str) -> list[dict]:
    """A task's saved runs in a kind's folder, by name: [{"name", "tag", "passed", "saved_at"}]."""
    raw = raw_folder(kind)
    out = []
    for folder in sorted(raw.glob(f"{task_id}_*")) if raw.exists() else []:
        try:
            data = json.loads((folder / "run.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if folder.is_dir() and data.get("task") == task_id:
            out.append({"name": folder.name, "tag": data.get("tag") or folder.name[len(task_id) + 1:],
                        "passed": data.get("passed"), "skipped": bool(data.get("skipped")),
                        "outcome": data.get("outcome"),
                        "saved_at": data.get("saved_at", "")})
    return sorted(out, key=lambda r: _tag_order(r["tag"]))


def result_word(run: dict) -> str:
    """A saved run's result in a word, for a list of them: Pass, Fail, or Skipped (a task that never started)."""
    if run.get("skipped"):
        return "Skipped"
    if run.get("outcome") == "SOME PARTS":
        return "Some parts"
    return "Pass" if run.get("passed") else "Fail"


def _tag_order(tag: str) -> tuple:
    """Run2 before Run10; other tags after, by name."""
    m = re.fullmatch(r"Run(\d+)", str(tag))
    return (0, int(m.group(1)), "") if m else (1, 0, str(tag))


def run_name(task_id: str, tag: str) -> str:
    """A saved run's name from its task and tag: "TR-07" + "Run 1" -> "TR-07_Run1" (letters, digits, - and _)."""
    tag = re.sub(r"[^A-Za-z0-9_-]+", "", str(tag)) or "Run"
    return f"{task_id}_{tag}"


def write_json(path: Path, data) -> None:
    """Writes the whole file or nothing: to a temporary name first, then renamed over (a crash never leaves half a
    file)."""
    write_text(path, json.dumps(data, indent=1, default=str))


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


@dataclass
class Session:
    """One sitting of runs in one kind's folder, saved as they happen. `folder` is the sitting's record
    (_sessions_log\\<date>_<time>: session.json, index.jsonl); `kind_folder` is where its runs go."""
    folder: Path
    real: bool
    info: dict
    kind_folder: Path = None
    root: Path = RESULTS_ROOT
    _last_hash: str = "0" * 64
    _runs: int = 0
    started: float = field(default_factory=time.time)

    @classmethod
    def start(cls, real: bool, set_name: str, where: str, round_no: int, version: str, info: dict,
              root: Path = RESULTS_ROOT) -> "Session":
        kind = kind_folder(real, set_name, where, round_no, root)
        folder = kind / SESSIONS_LOG / datetime.now().strftime("%Y-%m-%d_%H%M%S")
        while folder.exists():                       # two sittings in one second: never write into another's
            folder = folder.with_name(folder.name + "_b")
        folder.mkdir(parents=True)
        (raw_folder(kind) / PENDING).mkdir(parents=True, exist_ok=True)
        saved_folder(kind).mkdir(parents=True, exist_ok=True)
        session = cls(folder=folder, real=real, kind_folder=kind, root=Path(root),
                      info=dict(info, real=real, set=set_name, where=where, round=round_no, study=round_no,
                                version=version, kind=kind.name, started=datetime.now().isoformat(timespec="seconds")))
        write_json(folder / "session.json", session.info)
        return session

    def run_folder(self, task_id: str, repeat: int) -> Path:
        """A new run's folder, waiting in _raw_data\\_pending until it is saved (or discarded)."""
        self._runs += 1
        folder = raw_folder(self.kind_folder) / PENDING / f"{self.folder.name}_{self._runs:02d}_{task_id}_r{repeat}"
        folder.mkdir(parents=True)
        return folder

    def taken(self, name: str) -> bool:
        return (raw_folder(self.kind_folder) / name).exists() or (saved_folder(self.kind_folder) / f"{name}.md").exists()

    def next_tag(self, task_id: str) -> str:
        """The next free tag for a task in this kind's folder: Run1, Run2, ..."""
        n = 1
        while self.taken(run_name(task_id, f"Run{n}")):
            n += 1
        return f"Run{n}"

    def saved_runs(self, task_id: str) -> list[dict]:
        return saved_runs(self.kind_folder, task_id)

    def save_run(self, pending: Path, task_id: str, tag: str, replace: bool = False, reason: str = "") -> Path:
        """A pending run kept, under its tag: moved to _raw_data\\<task>_<tag>, and noted in the index. Returns its
        folder. A tag already saved is refused -- unless `replace`: then the run saved under it goes first, whole, to
        Recycle_Bin (a real one only with a reason, noted in deletions_log.txt)."""
        name = run_name(task_id, tag)
        replaced = None
        if self.taken(name):
            if not replace:
                raise FileExistsError(f"{name} is already saved here: choose another tag")
            if self.real and not reason.strip():
                raise ValueError(f"replacing the real run {name} needs a reason (it goes in the deletions log)")
            replaced = self._recycle(name, "replaced", reason.strip() or "replaced by a new run",
                                     by=Path(pending).name)
            # noted at once: should the new run's move fail (a file locked), the earlier one's move is still on record
            self.record({"replaced": name, "reason": reason.strip() or "replaced by a new run",
                         "recycled_to": str(replaced.relative_to(self.root))})
        final = raw_folder(self.kind_folder) / name
        os.replace(Path(pending), final)
        self.record({"saved": name, "was": Path(pending).name})
        return final

    def discard_run(self, folder: Path, reason: str = "") -> Path:
        """A run thrown away after it was scored (Save / Discard): its folder, whole, to Recycle_Bin, a "discarded"
        line in the index (the hash chain stays whole) and, for a real session, a line in deletions_log.txt. Returns
        where it went."""
        folder = Path(folder)
        reason = reason.strip() or "discarded after the run (Save / Discard)"
        where = self._recycle(folder.name, "discarded", reason, folder=folder)
        self.record({"discarded": folder.name, "reason": reason, "recycled_to": str(where.relative_to(self.root))})
        return where

    def _recycle(self, name: str, what: str, reason: str, folder: Optional[Path] = None, by: str = "") -> Path:
        """A run moved, whole, to Recycle_Bin\\<kind's path>\\<name>__<what>_<date>_<time>: its evidence folder, and
        a saved run's own .md and web page with it; why.txt says what happened. A real one goes in deletions_log.txt."""
        folder = Path(folder) if folder is not None else raw_folder(self.kind_folder) / name
        bin_folder = recycle_folder(self.kind_folder, self.root)
        target = bin_folder / f"{name}__{what}_{datetime.now().strftime('%Y-%m-%d_%H%M%S')}"
        while target.exists():                       # (twice in one second: never over another)
            target = target.with_name(target.name + "_b")
        target.parent.mkdir(parents=True, exist_ok=True)
        moved = []
        if folder.exists():
            shutil.move(str(folder), str(target))
            moved.append(f"{RAW}\\{name}" if folder.parent == raw_folder(self.kind_folder) else folder.name)
        else:
            target.mkdir(parents=True)
        for page, rel in ((saved_folder(self.kind_folder) / f"{name}.md", "saved_md"),
                          (html_folder(self.kind_folder) / f"{name}.html", "saved_html")):
            if page.exists():
                (target / rel).mkdir(exist_ok=True)
                shutil.move(str(page), str(target / rel / page.name))
                moved.append(page.name)
        write_text(target / "why.txt",
                   f"{what.capitalize()}: {name}\n"
                   f"When: {datetime.now().isoformat(timespec='seconds')}\n"
                   f"From: {Path(self.kind_folder).relative_to(self.root)}\n"
                   + (f"Replaced by: the run {by}, saved under the same name\n" if by else "")
                   + f"Reason: {reason}\n"
                   f"{'REAL (counts for the paper)' if self.real else 'Practice'}\n"
                   f"Moved here: {', '.join(moved) or '-'}\n")
        if self.real:
            log = deletions_log(self.root, self.kind_folder)
            log.parent.mkdir(parents=True, exist_ok=True)
            with open(log, "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().isoformat(timespec='seconds')}\t"
                        f"{(Path(self.kind_folder) / RAW / name).relative_to(self.root)}\t1 run\t{what}: {reason}\t"
                        f"-> {target.relative_to(self.root)}\n")
        return target

    def recover_crashed(self) -> list[str]:
        """Runs an earlier sitting started and never saved (the app closed or crashed mid-run, or as the run waited
        for Save or Discard: a _pending folder left behind): each kept, as it is, in _raw_data\\<folder>__crashed,
        with a "crashed" line in this sitting's index -- nothing a run left is lost. Returns their names."""
        pending = raw_folder(self.kind_folder) / PENDING
        found = []
        for folder in sorted(pending.iterdir()) if pending.exists() else []:
            if not folder.is_dir() or folder.name.startswith(self.folder.name):
                continue
            # (one with its run.json was scored and never saved -- left out until 2026-10-27, lost for good)
            scored = (folder / "run.json").exists()
            target = raw_folder(self.kind_folder) / f"{folder.name}__crashed"
            while target.exists():
                target = target.with_name(target.name + "_b")
            os.replace(folder, target)
            if scored:                             # (kept with the saved runs' folders: shown, not counted)
                try:
                    run = json.loads((target / "run.json").read_text(encoding="utf-8"))
                    write_json(target / "run.json", dict(run, excluded="never saved"))
                except (OSError, ValueError):
                    pass
            write_text(target / "why.txt", (f"Crashed: this run ({folder.name}) was scored but never saved -- the app "
                                            "closed or crashed before Save or Discard. Its record is kept here, not "
                                            "counted.\n" if scored else
                                            f"Crashed: this run was started ({folder.name}) and never finished -- "
                                            "the app closed or crashed during it. What it left is kept here.\n")
                                           + f"Found: {datetime.now().isoformat(timespec='seconds')}\n")
            self.record({"crashed": folder.name, "kept_as": target.name, "scored": scored})
            found.append(folder.name)
        return found

    def record(self, entry: dict) -> None:
        """Adds one line to the sitting's index (a run finished, was saved, discarded...). Each line carries the hash
        of the one before, so a changed or missing line shows."""
        entry = dict(entry, time=datetime.now().isoformat(timespec="seconds"), prev=self._last_hash)
        line = json.dumps(entry, sort_keys=True, default=str)
        with open(self.folder / "index.jsonl", "a", encoding="utf-8") as f:
            f.write(line + "\n")
        self._last_hash = hashlib.sha256(line.encode("utf-8")).hexdigest()     # (only once the line is written)

    def finish(self, summary_md: str = "", backup_root: Optional[Path] = None) -> Path:
        """Closes the sitting: its end time (robot hours), the summary, and -- for a real one -- a zip of the kind's
        folder in the backup folder."""
        lines = (self.folder / "index.jsonl").read_text(encoding="utf-8").splitlines() \
            if (self.folder / "index.jsonl").exists() else []
        self.info.update(ended=datetime.now().isoformat(timespec="seconds"),
                         minutes=round((time.time() - self.started) / 60.0, 1), runs=self._runs,
                         index_lines=len(lines), index_last_hash=self._last_hash)
        write_json(self.folder / "session.json", self.info)
        if summary_md:
            write_text(self.folder / "SESSION_SUMMARY.md", summary_md)
        if self.real:
            root = backup_root or self.root / BACKUP
            root.mkdir(parents=True, exist_ok=True)
            name = f"{self.kind_folder.parent.name}__{self.kind_folder.name}__{self.folder.name}"
            shutil.make_archive(str(root / name), "zip", self.kind_folder)
        return self.folder


def verify_index(folder: Path) -> bool:
    """True if a session's index is whole: every line's "prev" is the hash of the line before."""
    previous = "0" * 64
    path = folder / "index.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    try:
        for line in lines:
            if json.loads(line).get("prev") != previous:
                return False
            previous = hashlib.sha256(line.encode("utf-8")).hexdigest()
    except ValueError:                             # a damaged line
        return False
    try:                                           # a finished session also knows how it ended (no lost tail)
        info = json.loads((folder / "session.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        info = {}
    if "index_lines" in info and (info["index_lines"] != len(lines) or info.get("index_last_hash") != previous):
        return False
    return True


# ---- deleting ---------------------------------------------------------------------------------------------------------
def to_recycle_bin(path: Path) -> None:
    """Moves a file or folder to the Windows Recycle Bin (it can be put back from there)."""
    if os.name != "nt":
        raise OSError("the Recycle Bin is only used on Windows")

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", ctypes.c_void_p), ("wFunc", ctypes.c_uint), ("pFrom", ctypes.c_wchar_p),
                    ("pTo", ctypes.c_wchar_p), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", ctypes.c_int),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", ctypes.c_wchar_p)]

    FO_DELETE, FOF_ALLOWUNDO, FOF_NOCONFIRMATION, FOF_SILENT, FOF_NOERRORUI = 3, 0x40, 0x10, 0x4, 0x400
    FOF_WANTNUKEWARNING = 0x4000               # too big for the Recycle Bin: Windows asks before deleting for good
    op = SHFILEOPSTRUCTW(None, FO_DELETE, str(Path(path).resolve()) + "\0", None,
                         FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI | FOF_WANTNUKEWARNING,
                         0, None, None)
    result = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    if result != 0 or op.fAnyOperationsAborted:
        raise OSError(f"Windows couldn't move {path} to the Recycle Bin (code {result})")


def count_runs(folder: Path) -> int:
    return sum(1 for _ in folder.rglob("run.json")) if folder.exists() else 0


def deletions_log(root: Path, path: Path) -> Path:
    """Where a deletion is noted: deletions_log.txt at the top -- or, for the unseen test's runs, in
    Private_never_for_Claude\\Recycle_Bin_test (the test's lines name its tasks and why its runs were discarded: never
    shown to Claude)."""
    if is_test_path(Path(path)):
        return Path(root) / RECYCLE_TEST / DELETIONS_LOG
    return Path(root) / DELETIONS_LOG


def delete_results(folder: Path, reason: str = "", root: Path = RESULTS_ROOT,
                   trash: Callable[[Path], None] = to_recycle_bin) -> int:
    """Deletes a session, a round or a whole results folder (to the Recycle Bin) and returns how many runs it held.
    Anything under the real-test folder needs a reason, written to deletions_log.txt (the paper reports
    discarded runs); practice needs none. Only folders inside the results folder can be deleted this way."""
    folder, root = Path(folder).resolve(), Path(root).resolve()
    if root not in folder.parents:
        raise ValueError(f"{folder} isn't inside {root}")
    # the real study's results, and the backups of them, need a reason; practice and Claude's packages don't
    real = is_real_path(folder, root)
    if real and not reason.strip():
        raise ValueError("deleting real results needs a reason (it goes in the deletions log)")
    runs = count_runs(folder)
    trash(folder)                          # first: only a deletion that happened goes in the log
    if real:
        log = deletions_log(root, folder)  # at the top: deleting the whole real folder mustn't take its log with it
        log.parent.mkdir(parents=True, exist_ok=True)
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat(timespec='seconds')}\t{folder.relative_to(root)}\t{runs} runs\t"
                    f"{reason.strip()}\n")
    return runs

"""The cross-study report: study 1 vs 2 vs 3 (and on, up to 10), every kind of session side by side, in one folder of its own.

    Kyozo_Link_Results\\Private_never_for_Claude\\Study_Overview\\            the real study
    Kyozo_Link_Results\\Private_never_for_Claude\\Study_Overview_practice\\   the same for practice
        CROSS_STUDY_REPORT.md      in words and tables: the main claim (the Dobot's unseen test, study by study and
                                   task by task, paired), all four kinds per study, the hardware gap (twin - Dobot),
                                   by difficulty level, failure types, every task across the studies, the bookkeeping
        CROSS_STUDY_REPORT.html    the same as a web page
        cross_study.json           the same as data
        cross_study.xlsx           the same as sheets (or cross_study_*.csv without openpyxl)

Built from every saved run's run.json in each study's four data folders; remade after every Save and at every
session's end (or `python -m watcher.overview [--practice] [results folder]`). The measure is the pre-registered one:
an unassisted pass (a pass with no intervention); runs repeated for an infrastructure failure aren't counted.

It holds the unseen test's results, so the folder is private (results.PRIVATE): it is never shown to Claude. The test
tasks appear by id and level only, never their prompts.
"""
from __future__ import annotations

import csv
import json
import logging
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from watcher import report, results

logger = logging.getLogger(__name__)

REPORT_MD, REPORT_HTML = "CROSS_STUDY_REPORT.md", "CROSS_STUDY_REPORT.html"
REPORT_JSON, REPORT_XLSX = "cross_study.json", "cross_study.xlsx"
# the kinds, in the report's order: (set, where, words)
KIND_ORDER = (("train", "twin", "Twin · training"), ("train", "dobot", "Dobot · training"),
              ("test", "twin", "Twin · unseen test"), ("test", "dobot", "Dobot · unseen test"))
STUDY_NOS = tuple(results.STUDIES)


def overview_folder(real: bool, root: Path = results.RESULTS_ROOT) -> Path:
    """Private_never_for_Claude\\Study_Overview (real) or Study_Overview_practice (practice)."""
    return Path(root) / (results.OVERVIEW if real else results.OVERVIEW_PRACTICE)


def _runs_of(kind: Path) -> list[dict]:
    """A kind folder's saved runs (run.json), in name order."""
    out = []
    for folder in report._run_folders(kind) if kind.exists() else []:
        try:
            run = json.loads((folder / "run.json").read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("Couldn't read %s: %s", folder / "run.json", exc)
            continue
        if "passed" in run:
            out.append(dict(run, folder_name=folder.name))
    return out


def _unassisted(run: dict) -> bool:
    return bool(run.get("unassisted_pass", run.get("passed")))     # (the twin script has no helper)


def kind_stats(kind: Path) -> dict:
    """One study's one kind: its counted runs, passes, by level, by task, failure types and bookkeeping."""
    runs = _runs_of(kind)
    skipped = [r for r in runs if r.get("skipped")]       # (never started: saved, counted apart)
    counted = [r for r in runs if not r.get("repeated") and not r.get("excluded") and not r.get("skipped")]
    by_level: dict = {}
    by_task: dict = {}
    failures: dict = {}
    for r in counted:
        level = str(r.get("level") or "-")
        for table, key in ((by_level, level), (by_task, r.get("task", "?"))):
            c = table.setdefault(key, {"runs": 0, "passed": 0, "unassisted": 0})
            c["runs"] += 1
            c["passed"] += bool(r.get("passed"))
            c["unassisted"] += _unassisted(r)
        by_task[r.get("task", "?")]["level"] = r.get("level")
        if r.get("failure"):
            failures[r["failure"]] = failures.get(r["failure"], 0) + 1
    info = report._info_of(kind) if kind.exists() else {}
    return {"folder": str(kind), "exists": kind.exists(), "version": info.get("version"),
            "sittings": info.get("sittings", 0), "runs_saved": len(runs), "counted": len(counted),
            "not_counted_infrastructure": len(runs) - len(counted) - len(skipped), "skipped": len(skipped),
            "passed": sum(bool(r.get("passed")) for r in counted),
            "unassisted": sum(_unassisted(r) for r in counted),
            "rate": round(100.0 * sum(_unassisted(r) for r in counted) / len(counted), 1) if counted else None,
            "ran_by_itself": sum(bool(r.get("unattended")) for r in counted),
            "discarded_or_replaced": len(report._discarded_of(kind)) if kind.exists() else 0,
            "by_level": by_level, "by_task": by_task, "failures": failures}


def collect(real: bool, root: Path = results.RESULTS_ROOT) -> dict:
    """Every study's four kinds: {"real", "built", "kinds": {"train_twin": {"words", "studies": {1: stats, ...}}}}."""
    kinds = {}
    for set_name, where, words in KIND_ORDER:
        kinds[f"{set_name}_{where}"] = {
            "words": words, "set": set_name, "where": where,
            "studies": {n: kind_stats(results.kind_folder(real, set_name, where, n, root)) for n in STUDY_NOS}}
    return {"real": real, "built": datetime.now().isoformat(timespec="seconds"), "root": str(root), "kinds": kinds}


def _cell(stats: Optional[dict], unassisted: Optional[int] = None, runs: Optional[int] = None) -> str:
    """ "12/20 (60%)", or "-" for nothing run."""
    if stats is not None:
        unassisted, runs = stats["unassisted"], stats["counted"]
    if not runs:
        return "-"
    return f"{unassisted}/{runs} ({100.0 * unassisted / runs:.0f}%)"


def _pp(a: Optional[float], b: Optional[float]) -> str:
    return "-" if a is None or b is None else f"{a - b:+.0f} pp"


def _tasks_of(kind: dict) -> list[tuple[str, object]]:
    """Every task seen in any study of a kind, by level then id: [(id, level)]."""
    seen: dict = {}
    for stats in kind["studies"].values():
        for task_id, c in stats["by_task"].items():
            seen.setdefault(task_id, c.get("level"))
    return sorted(seen.items(), key=lambda t: (t[1] is None, t[1] or 0, t[0]))


def _task_rate(stats: dict, task_id: str) -> Optional[float]:
    c = stats["by_task"].get(task_id)
    return c["unassisted"] / c["runs"] if c and c["runs"] else None


def shown_studies(data: dict) -> list[int]:
    """The studies the report shows: 1 to 3 (the prereg's), and on to the last one with anything saved (up to
    results.MAX_STUDIES): the ones not run yet don't fill every table with empty columns."""
    ran = [int(n) for k in data["kinds"].values() for n, s in k["studies"].items() if s["exists"]]
    return [n for n in STUDY_NOS if n <= max([3] + ran)]


def build_markdown(data: dict) -> str:
    kinds = data["kinds"]
    dobot_test = kinds["test_dobot"]
    shown = shown_studies(data)
    heads = [f"Study {n}" for n in shown]
    md = [f"# Cross-study report: study {' vs '.join(str(n) for n in shown)} "
          f"({'REAL' if data['real'] else 'practice'})", "",
          f"*Made {data['built']} from every saved run in {data['root']}. "
          + (f"The real study (study_1..{shown[-1]})." if data["real"] else "Practice (Practice_Session), not counted.")
          + " The measure: an **unassisted pass** (a pass with no intervention); runs repeated for an infrastructure "
          "failure aren't counted. PRIVATE: it holds the unseen test's results -- never give it to Claude.*", ""]

    # 1. the main claim
    md += ["## The main claim: the Dobot's unseen test", ""]
    first = dobot_test["studies"][1]["rate"]
    md += report.md_table(
        ["Study", "Version", "Runs", "Passed (watcher)", "Unassisted passes", "Rate", "vs study 1"],
        [[f"Study {n}", s["version"] or "-", s["counted"], s["passed"], s["unassisted"],
          "-" if s["rate"] is None else f"{s['rate']:.0f}%", "-" if n == 1 else _pp(s["rate"], first)]
         for n, s in dobot_test["studies"].items() if n in shown])
    tasks = _tasks_of(dobot_test)
    if tasks:
        md += ["", "Task by task (each test task's unassisted passes per study; paired study 1 vs study 3):", ""]
        better = same = worse = 0
        rows = []
        for task_id, level in tasks:
            cells = [_cell(None, c["unassisted"], c["runs"]) if (c := dobot_test["studies"][n]["by_task"].get(task_id))
                     else "-" for n in shown]
            r1, r3 = (_task_rate(dobot_test["studies"][n], task_id) for n in (1, 3))
            if r1 is not None and r3 is not None:
                better += r3 > r1
                same += r3 == r1
                worse += r3 < r1
            rows.append([task_id, level or "-", *cells,
                         "-" if r1 is None or r3 is None else f"{100 * (r3 - r1):+.0f} pp"])
        md += report.md_table(["Task", "Level", *heads, "3 vs 1"], rows)
        md += ["", f"Study 3 vs study 1, tasks run in both: **{better} better, {same} the same, {worse} worse**.", ""]

    # 2. every kind, study by study
    md += ["## All four kinds, study by study", "",
           "Unassisted passes / counted runs (rate). The twin is the ideal-hardware reference.", ""]
    md += report.md_table(["Kind", *heads],
                          [[k["words"], *(_cell(k["studies"][n]) for n in shown)] for k in kinds.values()])

    # 3. the hardware gap
    md += ["", "## The hardware gap (twin - Dobot)", "",
           "How much worse the real Dobot does than the ideal twin, on the same tasks (percentage points).", ""]
    md += report.md_table(["Set", *heads],
                          [[words, *(_pp(kinds[f"{s}_twin"]["studies"][n]["rate"],
                                         kinds[f"{s}_dobot"]["studies"][n]["rate"]) for n in shown)]
                           for s, words in (("train", "Training"), ("test", "Unseen test"))])

    # 4. by difficulty level
    md += ["", "## By difficulty level", ""]
    for kind in kinds.values():
        levels = sorted({lv for s in kind["studies"].values() for lv in s["by_level"]},
                        key=lambda v: (v == "-", v))
        if not levels:
            continue
        md += [f"### {kind['words']}", ""]
        md += report.md_table(["Level", *heads],
                              [[lv, *(_cell(None, c["unassisted"], c["runs"]) if (c := kind["studies"][n]["by_level"]
                                                                                      .get(lv)) else "-"
                                      for n in shown)] for lv in levels])
        md.append("")

    # 5. failure types
    md += ["## Failure types", ""]
    any_failures = False
    for kind in kinds.values():
        names = sorted({f for s in kind["studies"].values() for f in s["failures"]})
        if not names:
            continue
        any_failures = True
        md += [f"### {kind['words']}", ""]
        md += report.md_table(["Failure", *heads],
                              [[f"{name} ({report.FAILURE_WORDS.get(name, '')})".replace(" ()", ""),
                                *(kind["studies"][n]["failures"].get(name, 0) for n in shown)] for name in names])
        md.append("")
    if not any_failures:
        md += ["No failures recorded yet.", ""]

    # 6. every task, every kind
    md += ["## Every task across the studies", "", "Unassisted passes / counted runs, per study.", ""]
    for kind in kinds.values():
        tasks = _tasks_of(kind)
        if not tasks:
            continue
        md += [f"### {kind['words']}", ""]
        md += report.md_table(["Task", "Level", *heads],
                              [[task_id, level or "-",
                                *(_cell(None, c["unassisted"], c["runs"]) if (c := kind["studies"][n]["by_task"]
                                                                              .get(task_id)) else "-"
                                  for n in shown)] for task_id, level in tasks])
        md.append("")

    # 7. bookkeeping
    md += ["## Bookkeeping", ""]
    md += report.md_table(["Kind", "Study", "Version", "Sittings", "Runs saved", "Not counted (infrastructure)",
                           "Discarded / replaced", "Ran by itself"],
                          [[k["words"], n, s["version"] or "-", s["sittings"], s["runs_saved"],
                            s["not_counted_infrastructure"], s["discarded_or_replaced"], s["ran_by_itself"]]
                           for k in kinds.values() for n, s in k["studies"].items() if s["exists"]]
                          or [["-", "-", "-", "-", "-", "-", "-", "-"]])
    return "\n".join(md) + "\n"


def _sheets(data: dict) -> dict:
    """The workbook's sheets: {name: (header, rows)}."""
    kinds = data["kinds"]
    shown = shown_studies(data)
    overview = [[k["words"], n, s["version"], s["counted"], s["passed"], s["unassisted"], s["rate"],
                 s["not_counted_infrastructure"], s["discarded_or_replaced"], s["ran_by_itself"]]
                for k in kinds.values() for n, s in k["studies"].items() if n in shown]
    by_level = [[k["words"], n, lv, c["runs"], c["passed"], c["unassisted"]]
                for k in kinds.values() for n, s in k["studies"].items() if n in shown for lv, c in sorted(s["by_level"].items())]
    by_task = [[k["words"], task_id, c.get("level"), n, c["runs"], c["passed"], c["unassisted"]]
               for k in kinds.values() for n, s in k["studies"].items() if n in shown for task_id, c in sorted(s["by_task"].items())]
    failures = [[k["words"], n, name, count]
                for k in kinds.values() for n, s in k["studies"].items() if n in shown for name, count in sorted(s["failures"].items())]
    return {"Overview": (["Kind", "Study", "Version", "Counted runs", "Passed", "Unassisted passes", "Rate %",
                          "Not counted (infrastructure)", "Discarded / replaced", "Ran by itself"], overview),
            "By level": (["Kind", "Study", "Level", "Runs", "Passed", "Unassisted passes"], by_level),
            "By task": (["Kind", "Task", "Level", "Study", "Runs", "Passed", "Unassisted passes"], by_task),
            "Failures": (["Kind", "Study", "Failure", "Runs"], failures)}


def _write_workbook(folder: Path, sheets: dict) -> Optional[Path]:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        for name, (header, rows) in sheets.items():
            with open(folder / f"cross_study_{name.lower().replace(' ', '_')}.csv", "w", newline="",
                      encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow(header)
                writer.writerows(rows)
        return None
    book = Workbook()
    book.remove(book.active)
    for name, (header, rows) in sheets.items():
        sheet = book.create_sheet(name)
        sheet.append(header)
        for row in rows:
            sheet.append(row)
        for col, title in enumerate(header, start=1):
            sheet.cell(row=1, column=col).font = Font(bold=True)
            sheet.column_dimensions[sheet.cell(row=1, column=col).column_letter].width = max(10, len(title) + 2)
        sheet.freeze_panes = "A2"
    target = folder / REPORT_XLSX
    tmp = folder / (REPORT_XLSX + ".part.xlsx")
    book.save(tmp)
    try:
        tmp.replace(target)
        return target
    except PermissionError:                       # open in Excel (Windows locks it): saved alongside, not lost
        other = folder / f"cross_study_{time.strftime('%H%M%S')}.xlsx"
        tmp.replace(other)
        logger.warning("%s is open (in Excel?): saved as %s instead", target.name, other.name)
        return other


def write_overview(real: bool, root: Path = results.RESULTS_ROOT) -> Path:
    """The cross-study report made (again) in Private_never_for_Claude\\Study_Overview; returns its folder."""
    data = collect(real, root)
    folder = overview_folder(real, root)
    folder.mkdir(parents=True, exist_ok=True)
    md = build_markdown(data)
    results.write_text(folder / REPORT_MD, md)
    results.write_text(folder / REPORT_HTML, report.md_to_html(md, "Cross-study report", {}))
    results.write_json(folder / REPORT_JSON, data)
    _write_workbook(folder, _sheets(data))
    return folder


def main(argv: list[str]) -> int:
    """python -m watcher.overview [--practice] [results folder]"""
    practice = "--practice" in argv
    rest = [a for a in argv if a != "--practice"]
    root = Path(rest[0]) if rest else results.RESULTS_ROOT
    folder = write_overview(not practice, root)
    print(f"Cross-study report made in {folder}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

"""Watcher active: a prompt typed in the main window, recorded as the watcher records a run -- the table looked at before
and after (pictures, and where each cube was: the watcher's own finder, or the twin's exact positions), everything the
model and the arm did (the model's record, every step with its time, refused steps, every move and gripper action,
picks, alarms, the time split, the event timeline, the "what happened" story), the arm, camera, calibration and
settings -- whether the prompt was done, refused, failed, stopped or ran out of time.

Kyozo_Link_Results\\Prompt_Runs is laid out as a watcher results folder, and the watcher's own report code writes it:

    _raw_data\\<name>\\                 each run's evidence: run.json, run_report.txt, PROMPT_REPORT.md, trace.json,
                                       model_log, start/end pictures and depth, moves, gripper, picks, alarms and
                                       refused_steps .csv, observer.json
    _raw_data\\_pending\\               a run being recorded, or ended and not named yet
    User_Saved_Prompt_Runs\\<name>.md   each run in full; HTML_version\\<name>.html the same with its pictures built in
    FULL_REPORT.md / .html, full_report.json, results.xlsx, results_*.csv     every recorded prompt, remade at each save
    _sessions_log\\<date>_<time>\\      each sitting of the app: session.json and its hash-chained index.jsonl
    PROMPT_RUNS.md                      the list, newest first

There is no pass or fail worked out (the reports say NO TARGET): a typed prompt has nothing to measure it against. You
give the run its name when it ends (and, if you like, a verdict). A run the app never finished (closed or crashed
during it) is kept as …__crashed the next time one is recorded.

The work runs on the prompt's own thread (begin before the model is asked, finish after it is done); naming and saving
on the window's.
"""
from __future__ import annotations

import json
import logging
import math
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from watcher import details, extract, model_log, observe, report, results
from watcher.tasks import Cube, angle_difference, match

logger = logging.getLogger(__name__)

TIME_LIMIT_S = 300.0          # a recorded prompt is ended after this long (Watcher active)
LOOKS = 3                     # pictures in each look at the table (each cube: the median)
VERDICTS = ("", "pass", "fail", "skip")
LIST_NAME = "PROMPT_RUNS.md"


@dataclass
class PromptRun:
    """One recorded prompt, filled as it goes."""
    prompt: str
    folder: Path
    started: float = field(default_factory=time.time)
    started_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    steps: list = field(default_factory=list)          # the model's steps (AgentStep) and when each ended
    events: list = field(default_factory=list)          # what the robot reported meanwhile
    record: dict = field(default_factory=dict)          # run.json
    stopped_why: str = ""                               # Stop / E-STOP pressed: in words
    timed_out: bool = False
    lock: threading.Lock = field(default_factory=threading.Lock)


class PromptRecorder:
    """Records the main window's prompts while Watcher active is on. `ctx`: the watcher's context
    (watcher.window.WatcherContext: robot, camera, scene builder, tool executor, config, twin...), or a function that
    makes it as things are now (the app's robot and camera change when it connects)."""

    def __init__(self, ctx, root: Optional[Path] = None):
        self._ctx = ctx
        self.results_root = Path(root or results.RESULTS_ROOT)
        self.root = self.results_root / results.PROMPT_RUNS
        self.session: Optional[results.Session] = None      # this sitting of the app (made at the first prompt)

    @property
    def ctx(self):
        return self._ctx() if callable(self._ctx) else self._ctx

    @property
    def raw(self) -> Path:
        return results.raw_folder(self.root)

    # ---- before the model is asked -----------------------------------------------------------------------------------
    def begin(self, prompt: str) -> PromptRun:
        """The table before: a fresh look (pictures, cube positions), the arm, the camera, the calibration, the
        settings. Robot events are collected from now on. Never raises: what couldn't be read is said in the record."""
        self.recover_crashed()
        session = self._sitting()
        folder = self.raw / results.PENDING / datetime.now().strftime("%Y-%m-%d_%H%M%S")
        while folder.exists():
            folder = folder.with_name(folder.name + "_b")
        folder.mkdir(parents=True)
        run = PromptRun(prompt=prompt, folder=folder)
        cfg = (self.ctx.config or {}).get("llm", {})
        model = getattr(getattr(self.ctx, "agent", None), "model", None) or cfg.get("model")
        run.record = {"task": "prompt", "category": "typed prompt", "level": None, "layout": "as found",
                      "prompt": prompt, "before": [], "repeat": 1, "no_target": True, "passed": None,
                      "sitting": session.folder.name, "started_at": run.started_at, "started_epoch": run.started,
                      "mode": self.ctx.mode, "model": model, "temperature": cfg.get("temperature"),
                      "seed": cfg.get("seed"), "git_commit": observe.git_commit(), "time_limit_s": TIME_LIMIT_S,
                      "scoring": "none: a typed prompt has no target (your verdict, if you give one)",
                      "looked_with": ("the twin's exact positions" if self.ctx.twin_world is not None else
                                      "the watcher's camera finder")}
        results.write_json(folder / "run.json", dict(run.record, status="running"))
        session.record({"started": folder.name, "prompt": prompt})
        for name, read in (("robot_at_start", lambda: observe.robot_state(self.ctx.robot)),
                           ("camera_at_start", lambda: observe.camera_state(self.ctx.camera)),
                           ("calibration", self._calibration_state),
                           ("conditions", lambda: observe.conditions(self.ctx.camera, self.ctx.scene_builder,
                                                                     self.ctx.calibration_file)),
                           ("settings", lambda: observe.settings_snapshot(self.ctx.config, self.ctx.robot))):
            try:
                run.record[name] = read()
            except Exception as exc:  # noqa: BLE001 - a record without it, rather than no record
                run.record[name] = {"unread": str(exc)}
        look: dict = {}
        try:
            seen = self._look(look)
        except Exception as exc:  # noqa: BLE001
            seen, look["error"] = [], str(exc)
        run.record.update(start_seen=[c.__dict__ for c in seen], layout_start=[c.__dict__ for c in seen],
                          start_look=look)
        self._picture(folder, "start")
        add = getattr(self.ctx.robot, "add_watcher", None)
        if add is not None:
            run._watch = lambda event, r=run: self._event(r, event)
            add(run._watch)
        return run

    def step(self, run: PromptRun, step) -> None:
        with run.lock:
            run.steps.append((step, time.time()))

    def _event(self, run: PromptRun, event: dict) -> None:
        with run.lock:
            run.events.append(event)

    # ---- after: the table again, and everything written -------------------------------------------------------------
    def finish(self, run: PromptRun, agent_run=None, error: Optional[str] = None) -> Path:
        """The prompt has ended (done, refused, failed, stopped, out of time): the arm parked out of the camera's way,
        the table looked at again, and the whole record written in its _pending folder (the run's report too).
        Returns the folder."""
        from watcher.taxonomy import count_refusals
        seconds = round(time.time() - run.started, 1)
        remove = getattr(self.ctx.robot, "remove_watcher", None)
        if remove is not None and hasattr(run, "_watch"):
            try:
                remove(run._watch)
            except Exception:  # noqa: BLE001
                pass
        with run.lock:                             # (the run's own events end here: the park move isn't the run's)
            steps, events = list(run.steps), list(run.events)
        rec = run.record
        try:                                       # (park first: the arm out of the camera's way)
            pose = getattr(self.ctx, "park_pose", None) or getattr(self.ctx.executor, "look_pose", None)
            if pose is not None and not getattr(self.ctx.robot, "_estopped", False):
                from app.hardware.interfaces import Pose
                self.ctx.robot.move_to(pose if isinstance(pose, Pose) else Pose(*pose))
        except Exception as exc:  # noqa: BLE001
            rec["park_error"] = str(exc)
        try:
            rec["robot_at_end"] = observe.robot_state(self.ctx.robot)
        except Exception as exc:  # noqa: BLE001
            rec["robot_at_end"] = {"unread": str(exc)}
        look: dict = {}
        try:
            end = self._look(look)
        except Exception as exc:  # noqa: BLE001
            end, look["error"] = [], str(exc)
        self._picture(run.folder, "end")
        trace = getattr(agent_run, "trace", None) if agent_run is not None else None
        traces = [trace] if trace else []
        reply = getattr(agent_run, "final_message", "") if agent_run is not None else ""
        start = [Cube(**c) for c in rec.get("start_seen", [])]
        moves = [e for e in events if e.get("kind") == "move"]
        alarms = [e for e in events if e.get("kind") == "alarm"]
        calls = [{"tool": s.tool_name, "args": s.arguments, "result": str(s.result)[:400],
                  "t_end": round(t - run.started, 1)} for s, t in steps]
        refused = [{"step": n, "tool": c["tool"], "args": c["args"], "why": c["result"], "t_end": c["t_end"]}
                   for n, c in enumerate(calls, start=1) if c["result"].startswith("ERROR")]
        pick_rows = extract.picks(trace, start)
        rec.update(
            status="ended", outcome=outcome(error, run.stopped_why, run.timed_out, steps, reply), reply=reply,
            error=error, stopped=run.stopped_why or None, timed_out=run.timed_out, seconds=seconds,
            ended_at=datetime.now().isoformat(timespec="seconds"), end_seen=[c.__dict__ for c in end], end_look=look,
            cubes=cube_changes(start, end), goal_check=((trace or {}).get("end") or {}).get("goal"),
            calls=calls, refused_steps=refused, refusals=count_refusals([c["result"] for c in calls]),
            alarms=alarms, moves=len(moves), failed_moves=sum(not m.get("ok", True) for m in moves),
            clamps=sum(e.get("kind") == "clamp" for e in events),
            interventions=[e["kind"] for e in events if e.get("kind") in ("estop", "alarm_cleared_by_hand")],
            events_log=report.events_log(events, run.started), time_split=extract.time_split(trace, seconds),
            arrival=extract.arrival(trace), plan=extract.plan([s for s, _ in steps]), picks=len(pick_rows),
            perception_offsets_mm=[r["perception_offset_mm"] for r in pick_rows
                                   if r.get("perception_offset_mm") is not None],
            link={"moves_not_answered": sum(e.get("kind") == "no_answer" for e in events),
                  "status_replies_lost": sum(e.get("kind") == "status_lost" for e in events)},
            observer={"verdict": None, "note": ""})
        try:
            motion = details.motion_detail(traces)
            rec.update(motion_detail=motion, model_turns=details.model_turns(traces))
            if motion["moves"]:
                _csv(run.folder / "moves.csv", details.MOVE_COLUMNS, details.move_rows(motion))
                _csv(run.folder / "gripper.csv", details.GRIPPER_COLUMNS, details.gripper_rows(motion))
            else:                                  # (no record of the moves: the robot's own reports of them)
                _csv(run.folder / "moves.csv", ["t", "x", "y", "z", "r", "ok", "error"],
                     [[m.get("t"), *[(m.get("target") or {}).get(k) for k in "xyzr"], m.get("ok"), m.get("error", "")]
                      for m in moves])
        except Exception as exc:  # noqa: BLE001
            rec["motion_error"] = str(exc)
        if pick_rows:
            _csv(run.folder / "picks.csv", list(pick_rows[0]), [list(r.values()) for r in pick_rows])
        _csv(run.folder / "refused_steps.csv", ["step", "t_end", "tool", "args", "why"],
             [[r["step"], r["t_end"], r["tool"], json.dumps(r["args"]), r["why"]] for r in refused])
        _csv(run.folder / "alarms.csv", ["t", "codes", "phases", "J1", "J2", "J3", "J4", "target", "auto_cleared",
                                         "leftover"],
             [[a.get("t"), " ".join(a.get("codes", [])), " ".join(a.get("phases", [])),
               *(list(a.get("joints") or []) + [""] * 4)[:4], json.dumps(a.get("target")), a.get("auto_cleared"),
               a.get("leftover")] for a in alarms])
        results.write_json(run.folder / "trace.json", trace if trace is not None else
                           {"error": error, "partial": True, "steps": calls})
        model_log.write_model_log(run.folder, traces, header=f"Typed prompt (Watcher active) · {run.started_at}\n"
                                                             f"“{run.prompt}”",
                                  steps=None if traces else calls)
        results.write_json(run.folder / "run.json", rec)
        self._reports_of(run.folder, rec)
        if self.session is not None:
            self.session.record({"run": run.folder.name, "outcome": rec["outcome"], "seconds": seconds,
                                 "refused_steps": [f"{r['tool']}: {r['why'][:200]}" for r in refused]})
        return run.folder

    # ---- naming it -------------------------------------------------------------------------------------------------
    def suggested_name(self, prompt: str) -> str:
        """"2026-10-22_red-cube-on-green" -- the date and the prompt's first words, never one already used."""
        words = re.findall(r"[A-Za-z0-9]+", prompt.lower())[:5]
        return self.free_name(f"{datetime.now():%Y-%m-%d}_{'-'.join(words) or 'prompt'}")

    def free_name(self, name: str) -> str:
        base = clean_name(name)
        out, n = base, 2
        while (self.raw / out).exists() or (results.saved_folder(self.root) / f"{out}.md").exists():
            out, n = f"{base}_{n}", n + 1
        return out

    def save(self, folder: Path, name: str, verdict: str = "", note: str = "") -> Path:
        """The run kept under its name (a name already used gets _2, _3...): moved from _pending to _raw_data\\<name>,
        its verdict and note in run.json and observer.json, a line in the sitting's index, its own page (.md and HTML
        with its pictures), and the reports of every recorded prompt (FULL_REPORT, results.xlsx) made again."""
        name = self.free_name(name or Path(folder).name)
        path = Path(folder) / "run.json"
        rec = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        observer = {"verdict": verdict or None, "note": note.strip(), "time": datetime.now().isoformat(timespec="seconds")}
        rec.update(task=name, name=name, observer=observer, saved=True, tag=name, saved_as=name,
                   saved_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        results.write_json(Path(folder) / "observer.json", observer)
        results.write_json(path, rec)
        final = self.raw / name
        final.parent.mkdir(parents=True, exist_ok=True)
        Path(folder).replace(final)
        self._reports_of(final, rec)
        self._sitting().record({"saved": name, "was": Path(folder).name, "outcome": rec.get("outcome"),
                                "verdict": verdict or None, "prompt": rec.get("prompt")})
        self.write_reports(final)
        return final

    def write_reports(self, saved: Optional[Path] = None) -> None:
        """A saved run's own page, every recorded prompt's FULL_REPORT / results.xlsx, and PROMPT_RUNS.md -- each
        failure said in the log, never in the way."""
        try:
            if saved is not None:
                report.write_run_files(self.root, saved)
            report.write_session_results(self.root)
        except Exception as exc:  # noqa: BLE001 - the run is saved; its reports can be made again (Rebuild reports…)
            logger.warning("Couldn't write the recorded prompts' reports: %s", exc, exc_info=True)
        self.write_list()

    def recover_crashed(self) -> list[str]:
        """Recorded prompts the app never finished (no "ended" in run.json, from before this app started): kept as
        _raw_data\\<folder>__crashed, noted in the index. Ended but never named: saved under their own folder's name.
        (Runs saved before Prompt_Runs was laid out as a watcher folder -- Prompt_Runs\\<name>\\ -- are moved in.)"""
        found = []
        old = [d for d in (self.root.iterdir() if self.root.exists() else [])
               if d.is_dir() and (d / "run.json").exists() and not d.name.startswith(("_", "User_Saved"))]
        for folder in old + [self.root / "_pending"]:
            if folder.name == "_pending":           # (the first layout's waiting room)
                for inner in sorted(folder.iterdir()) if folder.exists() else []:
                    target = self.raw / results.PENDING / inner.name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    inner.replace(target)
                if folder.exists() and not any(folder.iterdir()):
                    folder.rmdir()
                continue
            rec = json.loads((folder / "run.json").read_text(encoding="utf-8"))
            rec.update(task=folder.name, no_target=True, passed=None, started_epoch=rec.get("started_epoch"))
            results.write_json(folder / "run.json", rec)
            target = self.raw / folder.name
            target.parent.mkdir(parents=True, exist_ok=True)
            folder.replace(target)
            self._reports_of(target, rec)
            self.write_reports(target)
        pending = self.raw / results.PENDING
        for folder in sorted(pending.iterdir()) if pending.exists() else []:
            if not folder.is_dir() or folder.stat().st_mtime > _APP_STARTED:
                continue
            try:
                status = json.loads((folder / "run.json").read_text(encoding="utf-8")).get("status")
            except (OSError, ValueError):
                status = None
            if status == "ended":
                self.save(folder, folder.name)
                continue
            target = self.raw / self.free_name(f"{folder.name}__crashed")
            folder.replace(target)
            results.write_text(target / "why.txt", "Crashed: this prompt was being recorded and never finished (the app "
                                                   "closed or crashed during it). What it left is kept here.\n")
            self._sitting().record({"crashed": folder.name, "kept_as": target.name})
            found.append(folder.name)
        return found

    def write_list(self) -> None:
        """Prompt_Runs\\PROMPT_RUNS.md: every saved recorded prompt, newest first."""
        rows = []
        for path in self.raw.glob("*/run.json"):
            try:
                rec = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            rows.append(rec | {"_folder": path.parent.name})
        rows.sort(key=lambda r: r.get("started_at") or "", reverse=True)
        lines = ["# Prompts recorded with Watcher active", "",
                 "Typed in the main window, each recorded as the watcher records a run (no pass or fail is worked out: "
                 "the verdict is yours, if given). FULL_REPORT.md and results.xlsx have them all in full; each one's "
                 "own page is in User_Saved_Prompt_Runs (HTML_version: with its pictures), its evidence in _raw_data.",
                 "", "| When | Name | Prompt | Outcome | Your verdict | Seconds | Refused steps |",
                 "|---|---|---|---|---|---|---|"]
        for r in rows:
            lines.append(f"| {r.get('started_at', '')} | {r['_folder']} | {_cell(r.get('prompt'))} | "
                         f"{r.get('outcome', '?')} | {(r.get('observer') or {}).get('verdict') or r.get('verdict') or '-'} "
                         f"| {r.get('seconds', '')} | {len(r.get('refused_steps') or [])} |")
        results.write_text(self.root / LIST_NAME, "\n".join(lines) + "\n")

    # ---- helpers ---------------------------------------------------------------------------------------------------
    def _sitting(self) -> results.Session:
        """This sitting of the app's record (session.json, the hash-chained index.jsonl), made at the first prompt."""
        if self.session is None:
            folder = self.root / results.SESSIONS_LOG / datetime.now().strftime("%Y-%m-%d_%H%M%S")
            while folder.exists():
                folder = folder.with_name(folder.name + "_b")
            folder.mkdir(parents=True)
            cfg = (self.ctx.config or {}).get("llm", {})
            info = {"set": "prompt", "kind": results.PROMPT_RUNS, "real": False, "app_mode": self.ctx.mode,
                    "where": "twin" if self.ctx.twin_world is not None else "dobot",
                    "model": getattr(getattr(self.ctx, "agent", None), "model", None) or cfg.get("model"),
                    "temperature": cfg.get("temperature"), "seed": cfg.get("seed"),
                    "git_commit": observe.git_commit(), "started": datetime.now().isoformat(timespec="seconds"),
                    "calibration_file": str(self.ctx.calibration_file or ""),
                    "calibration_sha256": observe.file_sha256(self.ctx.calibration_file)}
            try:
                info.update(observe.conditions(self.ctx.camera, self.ctx.scene_builder, self.ctx.calibration_file))
                info["settings"] = observe.settings_snapshot(self.ctx.config, self.ctx.robot)
            except Exception:  # noqa: BLE001
                pass
            self.session = results.Session(folder=folder, real=False, info=info, kind_folder=self.root,
                                           root=self.results_root)
            results.write_json(folder / "session.json", info)
        return self.session

    def _reports_of(self, folder: Path, rec: dict) -> None:
        """The run's own report (run.json's "report", run_report.txt -- the timeline, the time split, what happened)
        and PROMPT_REPORT.md (where each cube went)."""
        try:
            report.write_run_report(folder, rec, self.session.info if self.session is not None else {})
        except Exception as exc:  # noqa: BLE001
            logger.warning("Couldn't write the recorded prompt's report: %s", exc, exc_info=True)
        results.write_text(folder / "PROMPT_REPORT.md", prompt_report(rec))

    def _look(self, stats: dict) -> list[Cube]:
        if self.ctx.twin_world is not None:
            stats["source"] = "the twin's exact positions"
            return observe.exact_cubes(self.ctx.twin_world)
        table_z = 0.0
        provider = getattr(self.ctx.executor, "table_z_provider", None)
        if provider is not None:
            table_z = provider() or 0.0
        return observe.look_cubes(self.ctx.camera, self.ctx.scene_builder.t_cam_to_robot, table_z, looks=LOOKS,
                                  stats=stats)

    def _picture(self, folder: Path, name: str) -> None:
        try:
            why = observe.capture(self.ctx.camera, folder, name)
            if why:
                logger.info("No %s picture for the recorded prompt: %s", name, why)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Couldn't save the %s picture: %s", name, exc)

    def _calibration_state(self) -> dict:
        read = getattr(self.ctx, "calibration_state", None)
        return dict(read() or {}) if read is not None else {}


_APP_STARTED = time.time()


def outcome(error: Optional[str], stopped: str, timed_out: bool, steps: list, reply: str) -> str:
    """In a word or two: error, time limit, stopped, refused (nothing done: every step it tried was refused, or none
    tried and the reply says it can't), or done."""
    if timed_out:
        return "time limit"
    if stopped:
        return "stopped"
    if error:
        return "error"
    tried = [s for s, _ in steps if s.tool_name not in ("list_objects", "list_places")]
    if tried and all(str(s.result).startswith("ERROR") for s in tried):
        return "refused"
    if not tried and any(w in (reply or "").lower() for w in ("can't", "cannot", "unable", "not possible", "refus")):
        return "refused"
    return "done"


def cube_changes(start: list[Cube], end: list[Cube]) -> list[dict]:
    """Each cube seen before: where it was and where it ended, how far it moved (and which way: x further from the
    robot, y its left) and turned, and how many cubes up it stood."""
    out = []
    for s, e in zip(start, match(start, end)):
        row = {"cube": s.label, "start": [s.x, s.y], "start_level": s.level}
        if e is None:
            row.update(end=None, note="not seen at the end (moved out of view, under another cube, or knocked off)")
        else:
            turned = (e.yaw - s.yaw + 45.0) % 90.0 - 45.0
            row.update(end=[e.x, e.y], end_level=e.level, moved_mm=round(math.hypot(e.x - s.x, e.y - s.y), 1),
                       dx_mm=round(e.x - s.x, 1), dy_mm=round(e.y - s.y, 1), turned_deg=round(turned, 1),
                       turned_abs_deg=round(angle_difference(e.yaw, s.yaw), 1))
        out.append(row)
    seen = {s.label for s in start}
    out += [{"cube": e.label, "start": None, "end": [e.x, e.y], "end_level": e.level,
             "note": "not seen at the start"} for e in end if e.label not in seen]
    return out


def prompt_report(rec: dict) -> str:
    """PROMPT_REPORT.md: one recorded prompt at a glance -- the outcome, the reply and where each cube went (the run's
    full story is run_report.txt and its page in User_Saved_Prompt_Runs)."""
    observer = rec.get("observer") or {}
    lines = [f"# {rec.get('name') or 'Recorded prompt'}", "",
             f"**Prompt:** “{rec.get('prompt', '')}”  ",
             f"**When:** {rec.get('started_at', '')} · {rec.get('seconds', '?')} s · {rec.get('mode', '')} mode · model "
             f"{rec.get('model', '?')}  ",
             f"**Outcome:** {rec.get('outcome', '?')}"
             + (f" ({rec['stopped']})" if rec.get("stopped") else "")
             + (f" -- error: {rec['error']}" if rec.get("error") else "") + "  ",
             f"**Your verdict:** {observer.get('verdict') or 'none given'}"
             + (f" -- {observer['note']}" if observer.get("note") else ""), "",
             "No pass or fail is worked out: a typed prompt has no target to measure.", "",
             "## The reply", "", rec.get("reply") or "(none)", ""]
    goal = rec.get("goal_check")
    if goal:
        lines += [f"The app's own check: {goal.get('status', '?')}" + (f" -- {goal['detail']}" if goal.get("detail")
                                                                      else ""), ""]
    lines += ["## The cubes", "", f"Looked at with {rec.get('looked_with', '?')}.", "",
              "| Cube | Start (x, y) | End (x, y) | Moved | Which way | Turned | Cubes up (start → end) |",
              "|---|---|---|---|---|---|---|"]
    for c in rec.get("cubes") or []:
        xy = lambda p: f"({p[0]:.0f}, {p[1]:.0f})" if p else "-"    # noqa: E731
        way = details.words_for_direction(c.get("dx_mm"), c.get("dy_mm")) if c.get("moved_mm") else "-"
        lines.append(f"| {c['cube']} | {xy(c.get('start'))} | {xy(c.get('end'))} | "
                     f"{c['moved_mm']:.0f} mm | {way} | {c['turned_deg']:+.0f}° | {c.get('start_level', '-')} → "
                     f"{c.get('end_level', '-')} |" if c.get("moved_mm") is not None else
                     f"| {c['cube']} | {xy(c.get('start'))} | {xy(c.get('end'))} | - | - | - | {c.get('note', '')} |")
    calls = rec.get("calls") or []
    lines += ["", f"## What the model did ({len(calls)} steps, {len(rec.get('refused_steps') or [])} refused)", ""]
    for i, s in enumerate(calls, 1):
        mark = "REFUSED " if str(s.get("result", "")).startswith("ERROR") else ""
        lines.append(f"{i}. {mark}`{s.get('tool')}({_short(s.get('args'))})` at {s.get('t_end')} s → "
                     f"{_cell(s.get('result'))[:200]}")
    split = rec.get("time_split") or {}
    lines += ["", "## Time and the arm", "",
              f"{rec.get('seconds', '?')} s in all: the model {split.get('model_s', '?')} s, the camera "
              f"{split.get('camera_s', '?')} s, the arm and tools {split.get('arm_and_tools_s', '?')} s.  ",
              f"Moves: {rec.get('moves', 0)} · picks: {rec.get('picks', 0)} · alarms: {len(rec.get('alarms') or [])} · "
              f"interventions: {', '.join(rec.get('interventions') or []) or 'none'} · moves not answered: "
              f"{(rec.get('link') or {}).get('moves_not_answered', 0)}"
              + (f" · parked with an error: {rec['park_error']}" if rec.get("park_error") else ""),
              "", "Files: run_report.txt (the timeline and what happened), start.png / end.png (and their depth), "
              "run.json (everything), trace.json, model_log.html / .txt, moves, gripper, picks, alarms and "
              "refused_steps .csv, observer.json.", ""]
    return "\n".join(lines)


def clean_name(name: str) -> str:
    """A folder name: letters, digits, - and _ (spaces to _)."""
    return re.sub(r"[^A-Za-z0-9_-]+", "", re.sub(r"\s+", "_", str(name).strip()))[:80] or "prompt"


def _short(args) -> str:
    text = json.dumps(args, default=str) if not isinstance(args, str) else args
    return text[:100]


def _cell(value) -> str:
    return str(value or "").replace("|", "/").replace("\n", " ")


def _csv(path: Path, header: list, rows: list) -> None:
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")     # (write_text makes it \r\n on Windows: csv's own came out \r\r\n)
    w.writerow(header)
    w.writerows(rows)
    results.write_text(path, buf.getvalue())

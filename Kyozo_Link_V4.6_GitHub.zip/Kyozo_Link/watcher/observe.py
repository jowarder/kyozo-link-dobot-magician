"""What the watcher sees and notes: fresh camera looks at the cubes (never the app's own idea of where they are), the
raw pictures of each run, the study's zones as saved places, and the facts that pin a session down (the model's
digest, the code's git commit, the files' hashes)."""
from __future__ import annotations

import hashlib
import json
import logging
import subprocess
from pathlib import Path
from typing import Optional

import numpy as np

from watcher.tasks import Cube, TaskSet

logger = logging.getLogger(__name__)
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def look_cubes(camera, t_cam_to_robot, table_z: float = 0.0, looks: int = 3, cube_mm: float = 25.0,
               stats: Optional[dict] = None) -> list[Cube]:
    """The cubes on the table, from `looks` fresh camera pictures, found by the watcher's own finder (watcher/finder.py:
    by colour and the depth picture, not the app's detector, which the study's rounds may change), merged: the look that
    saw the most cubes, each cube's position and angle the median of the looks that saw it. `stats`, if given, gets
    what the looks were like: cubes found in each, the pictures' brightness and how much of the depth was valid, the
    camera's settings and how long it has been on."""
    from watcher.finder import find_cubes, merge_looks
    seen, brightness, valid = [], [], []
    for _ in range(max(1, looks)):
        frame = camera.get_frame()
        seen.append(find_cubes(frame.rgb, frame.depth, camera.get_intrinsics(), t_cam_to_robot, table_z, cube_mm))
        if stats is not None:
            try:
                brightness.append(float(np.asarray(frame.rgb, float).mean()))
                if frame.depth is not None:
                    valid.append(float((np.asarray(frame.depth) > 0).mean()))
            except Exception:  # noqa: BLE001
                pass
    merged = merge_looks(seen)
    if stats is not None:
        stats.update(looks=len(seen), cubes_per_look=[len(s) for s in seen],
                     brightness_0_255=round(sum(brightness) / len(brightness), 1) if brightness else None,
                     depth_valid_fraction=round(sum(valid) / len(valid), 3) if valid else None,
                     **camera_state(camera))
    return merged


def camera_state(camera) -> dict:
    """The camera's settings now and minutes since it was switched on (best effort)."""
    out: dict = {}
    try:
        out["settings"] = {name: c.value for name, c in camera.controls().items()} if hasattr(camera, "controls") \
            else {}
    except Exception:  # noqa: BLE001
        pass
    try:
        from app.calibration.cube import camera_warm
        warm = camera_warm(camera)
        out["minutes_on"] = round(warm / 60.0, 1) if warm is not None else None
    except Exception:  # noqa: BLE001
        pass
    out["depth_preset"] = getattr(camera, "depth_preset", None)
    return out


def robot_state(robot) -> dict:
    """The arm now: where it is, what it holds, when it was homed, whether E-STOP is on, its set speed."""
    out: dict = {"robot": type(robot).__name__}
    for name, read in (("pose", lambda: robot.get_pose().__dict__), ("joints", lambda: list(robot.get_joints())),
                       ("holding", lambda: getattr(robot, "held_object", None)),
                       ("speed_mm_s", lambda: getattr(robot, "max_speed", None)),
                       ("estopped", lambda: bool(getattr(robot, "_estopped", False))),
                       ("homed", lambda: getattr(robot, "homed", None)),
                       ("port", lambda: getattr(robot, "port", None))):
        try:
            value = read()
            out[name] = ({k: round(float(v), 1) for k, v in value.items()} if name == "pose" else
                         [round(float(v), 1) for v in value] if name == "joints" else value)
        except Exception:  # noqa: BLE001 - what can't be read is left out
            pass
    homed_at = getattr(robot, "homed_at", None)
    if homed_at is not None:
        import time
        out["minutes_since_homing"] = round((time.monotonic() - homed_at) / 60.0, 1)
    return out


SECRET_WORDS = ("key", "token", "password", "secret")


def settings_snapshot(config: dict, robot=None) -> dict:
    """What the app runs with, for the session's record: config.yaml as loaded (anything that looks like a secret
    left out), and the arm's speed as set now (it can be changed in the app after loading)."""
    def clean(value):
        if isinstance(value, dict):
            return {k: ("(hidden)" if any(w in str(k).lower() for w in SECRET_WORDS) else clean(v))
                    for k, v in value.items()}
        if isinstance(value, list):
            return [clean(v) for v in value]
        return value
    out = {"config": clean(config or {})}
    if robot is not None:
        out["arm_speed_now_mm_s"] = getattr(robot, "max_speed", None)
    return out


def model_processor(endpoint: str, model: str) -> str:
    """How Ollama is running the model now ("100% GPU", "40% GPU / 60% CPU"), or "" if it can't say."""
    try:
        import requests
        for m in requests.get(f"{endpoint.rstrip('/')}/api/ps", timeout=5).json().get("models", []):
            if m.get("name") == model and m.get("size"):
                gpu = round(100.0 * float(m.get("size_vram") or 0) / float(m["size"]))
                return f"{gpu}% GPU" if gpu >= 100 else f"{gpu}% GPU / {100 - gpu}% CPU"
    except Exception:  # noqa: BLE001
        pass
    return ""


def exact_cubes(world) -> list[Cube]:
    """The twin: where every cube is now, exactly, from the simulator (no camera between): the twin is the study's
    ideal-hardware reference, scored without a camera's error. Trays and other non-cube shapes are left out."""
    out = []
    for object_id, meta in list(world.object_meta.items()):     # (a copy: the scene may be being set out meanwhile)
        if meta.get("shape") == "tray":
            continue
        try:
            x, y, z = world.get_object_position_mm(object_id)
            yaw = world.get_object_yaw_deg(object_id)
        except Exception:  # noqa: BLE001 - taken away as it was read: not on the table
            continue
        size = float((meta.get("size") or (0, 0, 25.0))[2])   # (its middle's height: on the table, half its size)
        out.append(Cube(meta["label"], round(x, 2), round(y, 2), round(yaw, 2), max(1, int(round((z + size / 2) / size)))))
    return out


def capture(camera, folder: Path, name: str, picture: bool = True) -> Optional[str]:
    """Saves the camera's picture and depth as they are now (name.png, name_depth.npz), so the run can be re-scored
    later; `picture` False: the depth only (the demo saves its 3D model's picture instead). Returns why not, if it
    couldn't."""
    try:
        import cv2
        frame = camera.get_frame()
        folder.mkdir(parents=True, exist_ok=True)
        if picture:
            cv2.imwrite(str(folder / f"{name}.png"), cv2.cvtColor(frame.rgb, cv2.COLOR_RGB2BGR))
        if frame.depth is not None:
            np.savez_compressed(folder / f"{name}_depth.npz", depth=frame.depth)
        return None
    except Exception as exc:  # noqa: BLE001 - a missing picture is noted, not the end of the run
        logger.warning("Couldn't save the %s picture: %s", name, exc)
        return str(exc)


def spot_room_mm(cube_mm: float) -> float:
    """The planner's room at a printed spot: one cube, whichever way it is turned (its diagonal), plus 4 mm."""
    return round(cube_mm * 2 ** 0.5 + 4.0, 1)


def save_zone_places(tasks: TaskSet, poses_dir: Path, z: float = 0.0) -> list[str]:
    """Writes the study's zones as saved places with their size ("zone a.json": x, y, z, r and area_mm), so the robot
    and Qwen know them by name and put several things in them side by side. `z`: the table's height there (a sized
    place is a surface: the tools let go just above it). Returns the names."""
    poses_dir.mkdir(parents=True, exist_ok=True)
    names = []
    for key, zone in tasks.zones.items():
        name = key.replace("_", " ")
        # a spot of the A4 sheet holds one cube. Its outline is printed 25 mm, and "on the spot" is scored within 10 mm
        # of its middle; this is only the planner's room for putting a cube there, which must take the cube turned as
        # it sits (24 deg on spot 1: 33 mm across; up to 35 at 45 deg) -- so a cube's diagonal and a little
        area = ([spot_room_mm(tasks.cube_size_mm)] * 2 if getattr(zone, "spot", None) is not None
                else [zone.width, zone.depth])
        place = {"x": zone.cx, "y": zone.cy, "z": z, "r": 0.0, "area_mm": area}
        if getattr(zone, "spot", None) is not None:   # printed on the sheet: a place to put things, not an obstacle
            place["marking"] = True
        (poses_dir / f"{name}.json").write_text(json.dumps(place), encoding="utf-8")
        names.append(name)
    return names


def zone_files_before(tasks: TaskSet, poses_dir: Path) -> dict[Path, Optional[str]]:
    """What the zones' place files held before the session wrote them (None: there was no such file)."""
    out: dict[Path, Optional[str]] = {}
    for key in tasks.zones:
        path = poses_dir / f"{key.replace('_', ' ')}.json"
        out[path] = path.read_text(encoding="utf-8") if path.exists() else None
    return out


def restore_zone_files(before: dict[Path, Optional[str]]) -> None:
    """Puts the zones' place files back as they were (a session's zones don't stay among the saved places)."""
    for path, text in (before or {}).items():
        try:
            if text is None:
                path.unlink(missing_ok=True)
            else:
                path.write_text(text, encoding="utf-8")
        except OSError:
            logger.warning("Couldn't put back the place file %s", path)


def file_sha256(path: Optional[Path]) -> str:
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest() if path else ""
    except OSError:
        return ""


def git_commit() -> str:
    try:
        return subprocess.run(["git", "rev-parse", "HEAD"], cwd=PROJECT_ROOT, capture_output=True, text=True,
                              timeout=10).stdout.strip()
    except Exception:  # noqa: BLE001
        return ""


def conditions(camera, scene_builder, calibration_file: Optional[Path]) -> dict:
    """What the camera side ran with, for the session's record and each run's report: the calibration (its method,
    error, and whether it was saved over its limit), the camera's depth preset and picture settings, and the
    detection. Best effort: what can't be read is left out."""
    out: dict = {}
    try:
        data = json.loads(Path(calibration_file).read_text(encoding="utf-8")) if calibration_file else {}
        extras = data.get("extras") or {}
        error = data.get("reproj_error_mm", data.get("reprojection_error_mm"))
        out["calibration"] = (f"{data.get('method', '?')}, {error:.2f} mm typical" if error is not None
                              else str(data.get("method", "?"))) + (" -- SAVED OVER ITS LIMIT" if extras.get("over_limit")
                                                                     else "")
    except (OSError, ValueError, TypeError):
        pass
    camera_info: dict = {"depth_preset": getattr(camera, "depth_preset", None)}
    try:
        camera_info["settings"] = {name: c.value for name, c in camera.controls().items()} \
            if hasattr(camera, "controls") else {}
    except Exception:  # noqa: BLE001
        pass
    out["camera"] = camera_info
    settings = getattr(getattr(scene_builder, "detector", None), "settings", None)
    if settings is not None and getattr(settings, "find", None):
        out["detection"] = str(settings.find)
    return out


def model_digest(endpoint: str, model: str) -> str:
    """Ollama's digest of the installed model: proof the same weights ran in every session."""
    try:
        import requests
        for m in requests.get(f"{endpoint.rstrip('/')}/api/tags", timeout=10).json().get("models", []):
            if m.get("name") == model:
                return m.get("digest", "")
    except Exception:  # noqa: BLE001
        pass
    return ""

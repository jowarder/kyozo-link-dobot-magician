"""Simple 20's set-out: the cubes put down anywhere on the grey sheet, in any order -- the arm puts them into the starting
layout itself before the first task (Rafi, 2026-10-22). Not a task, not scored: done by the watcher through the app's own
tools (list_objects, pick, place), every step recorded.

One cube at a time, each put down exactly on its spot (let go just above the table) once no other cube is in the way
there; if every cube left waits for a spot another holds (red on green's spot, green on red's), one of them is put
aside on free table first. A step the tools refuse ends the set-out: the person is told, and can put the cubes there by
hand. A start with a tower (group D) is built too: its bottom cube to its spot, then each one above put
on it. (Not through saved places: one with a size made the tools fit both of the Dobot's open fingers inside it, so every
spot was "full"; one without is the tip's height, not the table's -- the lab, 2026-10-22.)
"""
from __future__ import annotations

import ast
import math
from pathlib import Path
from typing import Callable, Optional

IN_PLACE_MM = 8.0                  # a cube this close to its spot is there
CLEAR_MM = 40.0                    # a spot with another cube's middle closer than this is taken
MAX_MOVES = 8
PICK_TRIES = 3                     # a pick the tools send back to look again ("the camera's reading ... kept changing")
LOOK_AGAIN = ("look again", "kept changing")    # is tried this many times, each after a fresh look


class SetOutError(RuntimeError):
    def __init__(self, why: str, steps: list):
        super().__init__(why)
        self.steps = steps


def needs_set_out(seen: list, layout: list) -> bool:
    """Whether the cubes seen (watcher Cubes; a tower's hidden ones filled in under its top) are anywhere but where
    the layout (watcher Cubes, a tower's with their levels) has them."""
    where = {c.label: c for c in seen}
    return any(c.label not in where or where[c.label].level != c.level
               or math.hypot(where[c.label].x - c.x, where[c.label].y - c.y) > IN_PLACE_MM for c in layout)


def set_out(executor, poses_dir: Path, table_z: float, targets: dict[str, tuple[float, float]], cube_mm: float = 25.0,
            stop: Callable[[], bool] = lambda: False, say: Callable[[str], None] = lambda text: None,
            on: Optional[dict[str, str]] = None) -> list[dict]:
    """Moves each cube to its spot ({label: (x, y)}) with the app's tools -- then, for a start with a tower, puts each
    of its upper cubes on the one below (`on`: {upper label: lower label}, bottom first; their spots are the bottom
    one's). `poses_dir` is no longer used: kept for the callers. Returns the steps done ({tool, args, result}).
    Raises SetOutError (with the steps so far) if a cube can't be seen or a step is refused."""
    steps: list[dict] = []
    on = dict(on or {})
    ground = {label: xy for label, xy in targets.items() if label not in on}

    def do(tool: str, args: dict) -> str:
        if stop():
            raise SetOutError("stopped (E-STOP)", steps)
        try:
            result = executor.execute(tool, args)
        except Exception as exc:  # noqa: BLE001 - a refusal, in the tools' own words
            steps.append({"tool": tool, "args": args, "result": f"ERROR: {exc}"})
            raise SetOutError(f"{tool} was refused: {exc}", steps) from None
        steps.append({"tool": tool, "args": args, "result": str(result)[:400]})
        return str(result)

    def look() -> dict:
        listed = ast.literal_eval(do("list_objects", {}))
        seen = {o["label"]: o for o in listed.get("objects", []) if o["label"] in targets}
        hidden = {h["label"]: h.get("under") for h in listed.get("hidden", []) if h.get("label") in targets}
        missing = sorted(set(targets) - set(seen) - set(hidden))
        if missing:
            raise SetOutError(f"the camera doesn't see the {' and the '.join(missing)}: put it on the grey sheet",
                              steps)
        return {"seen": seen, "hidden": hidden}

    def pick(label: str, table: dict) -> dict:
        """The cube picked -- looked at again and tried again when the tools say its reading was unsteady (the camera's
        angle noise: a second look usually holds still; the lab, 2026-10-22, gave up at the first)."""
        for attempt in range(PICK_TRIES):
            try:
                do("pick", {"object_id": table["seen"][label]["id"]})
                return table                       # (the look it was picked from: the others' ids as they are now)
            except SetOutError as exc:
                if attempt == PICK_TRIES - 1 or not any(w in str(exc) for w in LOOK_AGAIN):
                    raise
                say(f"Setting out: the camera's reading of the {label} wasn't steady; looking again")
                table = look()
                if label not in table["seen"]:
                    raise

    # 1. the cubes that stand on the table, each to its spot (one in the way of all the rest put aside first)
    for _ in range(MAX_MOVES + 1):
        table = look()
        seen = table["seen"]
        if table["hidden"]:                        # (something stacked: the cube on top comes off first)
            label = next(iter(table["hidden"].values()))
            say(f"Setting out: the {label} taken off the cube under it")
            pick(label, table)
            do("place_free", {"where": "center"})
            continue
        at = {label: (o["xyz_mm"][0], o["xyz_mm"][1]) for label, o in seen.items()}
        todo = [label for label, (x, y) in ground.items()
                if math.hypot(at[label][0] - x, at[label][1] - y) > IN_PLACE_MM]
        if not todo:
            break
        if len(steps) > 3 * MAX_MOVES:
            raise SetOutError(f"the cubes still weren't all on their spots after {MAX_MOVES} moves", steps)
        free = [label for label in todo if all(math.hypot(at[o][0] - ground[label][0], at[o][1] - ground[label][1])
                                               > CLEAR_MM for o in at if o != label)]
        if free:
            label = free[0]
            say(f"Setting out: the {label} to its spot")
        else:                                      # (every spot left is taken: the one in the way goes aside -- a
            label = next((o for o in at for t in todo if o not in todo         # cube that goes on top, first)
                          and math.hypot(at[o][0] - ground[t][0], at[o][1] - ground[t][1]) <= CLEAR_MM), todo[0])
            say(f"Setting out: the {label} put aside first (another cube is waiting for its place)")
        pick(label, table)
        if free:                               # (let go with the cube's bottom just above the table, as the tools
            x, y = ground[label]                # do on a surface: the tools turn the fingers clear of the others)
            do("place", {"x": x, "y": y, "z": round(executor._release_z(table_z), 1)})
        else:
            do("place_free", {"where": "center"})
    else:
        raise SetOutError(f"the cubes still weren't all on their spots after {MAX_MOVES} moves", steps)
    # 2. a tower to start from: each upper cube on the one below, bottom up
    for upper, lower in on.items():
        table = look()
        if table["hidden"].get(lower) == upper:
            continue                               # (already on it)
        say(f"Setting out: the {upper} put on the {lower}")
        table = pick(upper, table)
        do("place_on", {"object_id": table["seen"][lower]["id"]})
    if on:
        # a last look: it takes the arm out of the camera's way (the lab, 2026-10-23: left hovering over the tower it
        # had just built, it hid it from the watcher's camera, and group D's five tasks were skipped "not READY")
        look()
    return steps


def targets_of(cubes: list) -> dict[str, tuple[float, float]]:
    """{label: (x, y)} of a layout's cubes (watcher Cubes)."""
    return {c.label: (c.x, c.y) for c in cubes}


def towers_of(cubes: list) -> dict[str, str]:
    """{upper label: lower label} of a layout's piles, bottom up (watcher Cubes with levels)."""
    from watcher.tasks import stacked
    out = {}
    for c in sorted(cubes, key=lambda c: c.level):
        below = next((o for o in cubes if o.level == c.level - 1 and stacked(o, c)), None)
        if below is not None:
            out[c.label] = below.label
    return out


def summary(steps: list[dict]) -> str:
    moved = [f"({s['args']['x']:.0f}, {s['args']['y']:.0f})" if s["tool"] == "place" else
             "stacked" if s["tool"] == "place_on" else "put aside"
             for s in steps if s["tool"] in ("place", "place_free", "place_on")
             and not str(s.get("result", "")).startswith("ERROR")]
    return f"{len(moved)} move(s)" + (f": {', '.join(moved)}" if moved else "")


def refused(steps: list[dict]) -> Optional[dict]:
    return next((s for s in steps if str(s.get("result", "")).startswith("ERROR")), None)

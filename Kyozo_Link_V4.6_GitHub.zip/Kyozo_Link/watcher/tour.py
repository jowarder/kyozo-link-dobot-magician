"""How to use the watcher: a walk-through inside the Watcher window, like the cube calibration's (app/ui/cube_tour.py).

Watch (demo mode): the guide does each step itself, with the window's own buttons, highlights what it pressed and
stops after it to explain ("Next step" to go on). Practise: you press the buttons; the guide highlights what to press,
says what isn't right yet and ticks each step when it is done. Practise works in live mode too -- the guide itself
never moves the robot there. A walk-through session is always practice (safe to delete).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QComboBox, QGroupBox, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

HIGHLIGHT = "border: 3px solid #ffb703;"


@dataclass
class TourStep:
    title: str
    explain: str                                  # what this step is for, shown while on it
    target: str                                   # the window's widget to highlight (attribute name)
    done: Callable[["object"], bool]              # is it done? (the window)
    todo: Callable[["object"], str]               # if not: what's still missing
    act: Optional[Callable[["object"], None]] = None   # Watch: how the guide does it itself


def _select(box, data) -> None:
    box.setCurrentIndex(box.findData(data))


def steps() -> list[TourStep]:
    return [
        TourStep("1. The Practice session toggle",
                 "ON (the default): results go to Practice_Session\\practice_study_N — try anything, delete it later. "
                 "OFF: results go to study_N and count for the paper (it asks you first). It locks while a session runs. "
                 "For learning, leave it ON.",
                 "real", lambda w: not w.real.isChecked(), lambda w: "Turn the Practice session toggle ON.",
                 lambda w: w.real.setChecked(False)),
        TourStep("2. Choose the session",
                 "Session: Task for Twin / Task for Dobot (training: Claude reads these for the next version), or "
                 "Test Twin / Test Real Dobot with unseen tasks (never shown to Claude). The twin's run in Demo mode, "
                 "the Dobot's in Live mode. Round: 1 (the base app), 2 (v1) or 3 (v2). Cubes: the cube set. "
                 "Here: the training in this mode, Round 1, 3 cubes.",
                 "session_box",
                 lambda w: (w.set_box.currentData(), w.round_box.currentData(),
                            w.cubes_box.currentData()) == ("train", 1, 3),
                 lambda w: "Choose Session: Task for Twin (Demo) or Task for Dobot (Live), Round: Round 1, "
                           "Cubes: 3 cubes.",
                 lambda w: (_select(w.set_box, "train"), _select(w.round_box, 1), _select(w.cubes_box, 3))),
        TourStep("3. Start session",
                 "Start session makes the session's folder, writes down the settings (model, seed, calibration, code "
                 "version) and saves the A4 sheet's spots as places. The first task's prompt appears below, with where "
                 "each cube goes ('Put: blue on spot 3').",
                 "start_btn", lambda w: w.session is not None, lambda w: "Press Start session.",
                 lambda w: w.start_session()),
        TourStep("4. Set the cubes out",
                 "Put each cube on the spot the run's arrangement says. The table check compares what the camera sees with the "
                 "layout and says what to move ('red cube: 7 mm to the robot's left'). When every cube is within "
                 "5 mm and 5°, it says READY and Start run lights up. (Demo: 'Set the cubes out' does it for you.)",
                 "setup_text", lambda w: w.run_btn.isEnabled(), lambda w: "Set the cubes out until it says READY.",
                 lambda w: w.place_btn.click() if w.place_btn.isVisible() else None),
        TourStep("5. Start run — then hands off",
                 "Start run sends the task's fixed prompt: nobody types. Don't touch the arm, the cubes or the table "
                 "while it runs — any touch is an intervention and the run won't count as unassisted. E-STOP only in "
                 "an emergency. The run log shows the model's steps, every move, and any alarm with its joint angles.",
                 "run_btn", lambda w: w.state in ("verdict", "reveal"),
                 lambda w: "Press Start run, then wait for the arm to park." if w.state == "setup" else
                 "The run is going: hands off.",
                 lambda w: w.run_btn.click() if w.run_btn.isEnabled() else None),
        TourStep("6. Your verdict first",
                 "Say what you saw — Pass, Fail, Dropped, or 'I had to help' — BEFORE the watcher shows its score, so "
                 "its number can't sway you. Your verdict is saved first; the two are compared for the paper. (The twin: 'Skip' -- it scores itself from the simulator's exact positions.)",
                 "verdict_btns", lambda w: w.state == "reveal", lambda w: "Press your verdict (Pass for this one).",
                 lambda w: w.verdict_btns["pass"].click()),
        TourStep("7. The watcher's score",
                 "Now the watcher's own score: pass or fail by the pass rule (10 mm, 8°, nothing else moved), the "
                 "errors in mm and degrees, and the failure type if it failed. If it disagrees with you, it is flagged.",
                 "reveal", lambda w: bool(w.reveal.text()), lambda w: "Wait for the score to show.", None),
        TourStep("8. Save, Discard, or End session",
                 "Save ▶ next keeps the run under the number you choose (the next free one to start with; choosing "
                 "one already saved replaces that run). Run this task again adds another run of it, next. Discard "
                 "and run again throws this one away (a real one with a reason) and runs the same task again. "
                 "Replaced and discarded runs are kept, whole, in Recycle_Bin. End session stops early: the session "
                 "is saved with its summary. Here we end it.",
                 "end_btn", lambda w: w.session is None, lambda w: "Press End session.",
                 lambda w: w.end_session("walk-through over")),
        TourStep("9. Where results go, and deleting them",
                 "Open results folder shows everything. Practice: delete freely. Real test: Delete results… sends it "
                 "to the Windows Recycle Bin and asks for a reason, written to deletions_log.txt (the paper reports "
                 "discarded runs). Before a session, tick the tasks to run in the Session plan tab. That's the "
                 "watcher: the twin's sessions in Demo mode, the real Dobot's in Live mode.",
                 "delete_btn", lambda w: True, lambda w: "", None),
    ]


class WatcherTour(QGroupBox):
    """The walk-through panel at the top of the Watcher window."""

    def __init__(self, window):
        super().__init__("How to use the watcher")
        self.window = window
        self.steps = steps()
        self.index = 0
        self.ticked: set[int] = set()
        self._highlighted = None
        v = QVBoxLayout(self)
        row = QHBoxLayout()
        self.mode = QComboBox()
        if window.ctx.twin_world is not None:
            self.mode.addItem("Watch (the guide does each step)", "watch")
        self.mode.addItem("Practise (you do each step)", "practise")
        self.do_btn = QPushButton("Do this step")
        self.do_btn.clicked.connect(self.do_step)
        self.back_btn = QPushButton("◀ Back")
        self.back_btn.clicked.connect(lambda: self.go(self.index - 1))
        self.next_btn = QPushButton("Next step ▶")
        self.next_btn.clicked.connect(lambda: self.go(self.index + 1))
        self.exit_btn = QPushButton("Close guide")
        self.exit_btn.clicked.connect(self.close_tour)
        for w in (QLabel("Mode:"), self.mode, self.do_btn, self.back_btn, self.next_btn, self.exit_btn):
            row.addWidget(w)
        row.addStretch(1)
        v.addLayout(row)
        self.title = QLabel()
        self.title.setStyleSheet("font-weight: bold; font-size: 14px;")
        self.text = QLabel()
        self.text.setWordWrap(True)
        self.status = QLabel()
        self.status.setWordWrap(True)
        self.progress = QLabel()
        for w in (self.title, self.text, self.status, self.progress):
            v.addWidget(w)
        self.mode.currentIndexChanged.connect(lambda _i: self._refresh())
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)

    def start(self) -> None:
        if self.window.session is not None:
            self.status.setText("End the running session first.")
            return
        self.index, self.ticked = 0, set()
        if self.window.real.isChecked():
            self.window.real.setChecked(False)
        self.show()
        self.timer.start(400)
        self._refresh()

    def close_tour(self) -> None:
        self.timer.stop()
        self._highlight(None)
        self.hide()

    def go(self, index: int) -> None:
        self.index = max(0, min(index, len(self.steps) - 1))
        self._refresh()

    def do_step(self) -> None:
        step = self.steps[self.index]
        if step.act is not None and not step.done(self.window):
            step.act(self.window)
        self._refresh()

    def tick(self) -> None:
        step = self.steps[self.index]
        if step.done(self.window):
            if self.index not in self.ticked:
                self.ticked.add(self.index)
                if self.mode.currentData() == "practise" and self.index < len(self.steps) - 1:
                    self.go(self.index + 1)          # practise: on to the next as soon as it's done
                    return
        self._refresh()

    def _refresh(self) -> None:
        step = self.steps[self.index]
        done = step.done(self.window)
        self.title.setText(step.title + ("  ✓" if done else ""))
        self.text.setText(step.explain)
        watch = self.mode.currentData() == "watch"
        self.status.setText("Done." if done else ("Press 'Do this step' to watch it done." if watch and step.act
                                                  else step.todo(self.window)))
        self.do_btn.setVisible(watch)
        self.do_btn.setEnabled(watch and step.act is not None and not done)
        self.back_btn.setEnabled(self.index > 0)
        self.next_btn.setEnabled(self.index < len(self.steps) - 1 and (done or not watch))
        self.progress.setText("  ".join(("✓ " if i in self.ticked else "· ") + s.title.split(".")[0]
                                        for i, s in enumerate(self.steps)))
        self._highlight(step.target)

    def _highlight(self, name: Optional[str]) -> None:
        if self._highlighted is not None:
            for w in self._widgets(self._highlighted):
                w.setStyleSheet(w.property("tour_style") or "")
        self._highlighted = name
        if name is not None:
            for w in self._widgets(name):
                if w.property("tour_style") is None:
                    w.setProperty("tour_style", w.styleSheet())
                w.setStyleSheet((w.property("tour_style") or "") + HIGHLIGHT)

    def _widgets(self, name: str) -> list:
        target = getattr(self.window, name, None)
        if isinstance(target, dict):
            return list(target.values())
        return [target] if target is not None else []

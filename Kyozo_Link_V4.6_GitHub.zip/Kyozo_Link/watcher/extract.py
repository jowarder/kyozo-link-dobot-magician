"""What a run's trace (the app's PromptTrace) says beyond pass or fail, in the shape the study needs:

    picks          per grip: which cube, where the app thought it was vs where the watcher saw it (perception), the grip
                   and release angles, J4, how much room the fingers had, the joint nearest its limit, the outcome
    arrival        per move: how far the arm ended from where it was sent (controller-reported)
    time_split     where the run's time went: the model thinking, the camera looking, the arm doing things
    plan           fingerprints of the plan (the tool calls in order), to tell the model's variation (a different plan)
                   from the machine's (the same plan, a different outcome)
"""
from __future__ import annotations

import hashlib
import json
import math
from typing import Optional

from watcher.tasks import Cube, match

GRIPPING = {"pick", "turn_object", "swap", "line_up", "put_all_in", "place_between", "move_object", "empty_place",
            "take_apart", "put_back", "build_tower"}


def _calls(trace: Optional[dict]) -> list[dict]:
    return [c for turn in (trace or {}).get("turns", []) for c in turn.get("calls", [])]


def app_estimates(trace: Optional[dict]) -> dict[str, tuple[float, float]]:
    """Where the app thought each cube was when it first went for it: label -> (x, y), from its own safety checks."""
    out: dict[str, tuple[float, float]] = {}
    for call in _calls(trace):
        for check in (call.get("app") or {}).get("safety") or []:
            what, at = check.get("what"), check.get("at")
            if what and at and what.endswith("cube") and what not in out:
                out[what] = (float(at[0]), float(at[1]))
    return out


def picks(trace: Optional[dict], seen_start: list[Cube]) -> list[dict]:
    """One row per call that gripped something: the perception check (the app's estimate vs the watcher's own look
    at the start), the grip and release, and the outcome."""
    rows = []
    estimates_seen = set()
    for i, call in enumerate(_calls(trace)):
        app = call.get("app") or {}
        grip = app.get("grip") or {}
        if call.get("name") not in GRIPPING or not grip:
            continue
        label = grip.get("object", "")
        estimate = None
        for check in app.get("safety") or []:
            if check.get("what") == label and check.get("at"):
                estimate = (float(check["at"][0]), float(check["at"][1]))
                break
        offset = None
        if estimate is not None and label not in estimates_seen:
            seen = match([Cube(label, *estimate)], seen_start)[0]
            if seen is not None:
                offset = round(math.hypot(seen.x - estimate[0], seen.y - estimate[1]), 1)
            estimates_seen.add(label)              # (after the first move the start look no longer applies)
        release = app.get("release") or {}
        limit = app.get("closest_to_limit") or {}
        rows.append({"call": i, "tool": call.get("name"), "object": label,
                     "app_x": estimate[0] if estimate else None, "app_y": estimate[1] if estimate else None,
                     "perception_offset_mm": offset, "grip_r": grip.get("r"), "grip_j4": grip.get("j4"),
                     "spare_mm": grip.get("spare_mm"), "grip_depth_mm": grip.get("depth_mm"),
                     "release_r": release.get("r"), "release_turned": release.get("turned"),
                     "closest_to_limit": json.dumps(limit) if limit else "",
                     "largest_joint_move": app.get("largest_joint_move"),
                     "refused": bool(app.get("refused")), "result": str(app.get("result", ""))[:160]})
    return rows


def arrival(trace: Optional[dict]) -> dict:
    """How far the arm ended from where each move sent it (the controller's own reading)."""
    shorts = []
    for call in _calls(trace):
        for move in (call.get("app") or {}).get("moves") or []:
            target, to = move.get("target"), move.get("to")
            if move.get("kind") == "move" and target and to:
                shorts.append(math.dist(target[:3], to[:3]))
    if not shorts:
        return {"moves": 0, "median_short_mm": None, "max_short_mm": None}
    shorts.sort()
    return {"moves": len(shorts), "median_short_mm": round(shorts[len(shorts) // 2], 2),
            "max_short_mm": round(shorts[-1], 2), "over_2mm": sum(s > 2.0 for s in shorts)}


def time_split(trace: Optional[dict], total_s: Optional[float]) -> dict:
    """Where the run's time went (seconds): the model deciding, the camera looking (list_objects), the arm and
    tools doing the rest, and what's left (waiting, the app itself)."""
    turns = (trace or {}).get("turns", [])
    model = sum(float(t.get("decided_s") or 0.0) for t in turns)
    camera = arm = 0.0
    for call in _calls(trace):
        seconds = float((call.get("app") or {}).get("seconds") or 0.0)
        if call.get("name") == "list_objects":
            camera += seconds
        else:
            arm += seconds
    out = {"model_s": round(model, 1), "camera_s": round(camera, 1), "arm_and_tools_s": round(arm, 1)}
    if total_s:
        out["other_s"] = round(max(0.0, float(total_s) - model - camera - arm), 1)
        out["model_share"] = round(model / float(total_s), 2)
    return out


def plan(steps: list) -> dict:
    """Fingerprints of the plan: `shape` from the tools called in order; `full` with their arguments too. Two runs of
    one task with the same full plan and different outcomes differ because of the machine, not the model."""
    tools = [getattr(s, "tool_name", None) or s.get("tool") for s in steps]
    args = [getattr(s, "arguments", None) if hasattr(s, "arguments") else s.get("args") for s in steps]
    shape = hashlib.sha1(json.dumps(tools).encode()).hexdigest()[:12]
    full = hashlib.sha1(json.dumps(list(zip(tools, args)), sort_keys=True, default=str).encode()).hexdigest()[:12]
    return {"shape": shape, "full": full, "tools": tools}

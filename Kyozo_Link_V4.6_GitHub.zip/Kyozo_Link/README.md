# Kyozo Link

(Formerly *Dobot Vision Task*.) Desktop app for the Dobot Magician and the UFACTORY xArm 6: manual jog control + prompt-driven
pick-and-place using a local LLM (Qwen3 via Ollama) and an Orbbec Gemini 335
RGB-D camera. See `C:\Users\rafi\.claude\plans\i-want-a-build-enchanted-newell.md`
for the full design plan.

## Quick start (demo mode, no hardware required)

**Windows note:** `pybullet` has no prebuilt wheel on PyPI for Windows at all
(any Python version) — `pip install -r requirements.txt` alone will fail
trying to compile it from source. Use conda instead, which pulls pybullet
prebuilt from conda-forge:

```bash
conda create -y -n dobot_vision python=3.12 pybullet "blas=*=openblas" -c conda-forge
conda activate dobot_vision
pip install PyQt6 opencv-python PyYAML requests pydobot
python -m app.main
```

The `"blas=*=openblas"` pin matters: conda-forge's default BLAS is Intel MKL,
which crashes (silent native crash, no Python traceback) on some hybrid
Intel CPUs (P-core/E-core architectures like 12th-gen+ / Core Ultra) the
moment NumPy does a matrix multiply or SVD — which the calibration solver
does immediately. If you hit an unexplained silent crash with no stderr
output, this is almost certainly it; switch to OpenBLAS as above.

On macOS/Linux, pybullet does have PyPI wheels, so the plain
`pip install -r requirements.txt` should work there.

This runs against the built-in PyBullet twin (`config.yaml` defaults to
`mode: demo`) with a scripted scenario (`two_blocks_and_tray`) — a red cube
and a blue cube on the workbench next to a tray. No robot or camera needed.

Other scenes (colour sorting with two bins, tower building, size sorting, mixed objects) are picked in
**Settings → Scene**; each is a small JSON file in `app/twin/scenarios/` listing its objects
(label, colour, size, position, and `shape`: cube / ball / cylinder) and its named drop-off places
(the surface there: a tray's floor, the table). Copy one to make your own.

**How objects are found** (`vision: detector:` in `config.yaml`):
- `depth` (default): anything standing up from the table within the arm's reach, of any colour, named by
  colour and shape ("white cube", "grey cylinder", "orange ball", "blue bar"). Not clear glass or plastic.
  A cube under another of a different colour is found by the colour of its sides.
- `color_blob`: only the colours listed under `vision: colors:` (red, blue, green; the demo adds yellow and
  purple), every one called a cube. Steadier for coloured cubes under difficult lighting.

The status bar (bottom of the window) shows live Robot and LLM/Ollama
connection status, auto-refreshing every 15s. The **Log** tab (after Calibration) is a live,
colour-coded feed of
everything the app has logged since it started (twin, hardware, vision,
calibration, LLM; also saved in `app.log`), with **Copy log** and **Clear** — check it first if something isn't
working. The same log is also inside the **System check** window (**Show log**, **Back to checks**).

To use the Prompt tab, also run Ollama locally:

```bash
ollama serve
ollama pull qwen3:4b-instruct-2507-q4_K_M
ollama pull qwen3:8b
```

(Not plain `qwen3:4b`: that name is now Qwen's *Thinking* version, which always reasons before it answers --
minutes per step on a PC without a graphics card.)

Then type something like *"pick the red cube and place it in the tray"* in
the Prompt tab.

The **Model** tab shows, for every prompt, each decision the model made (in seven stages per turn:
what it read, which object it matched, which action and why, the values it filled in, its exact
answer with Ollama's token counts and timings) and, under each instruction, what the app did with it:
the target, the safety checks and every arm move with the joint angles before and after. The model only
names actions; the app works out where to go and the arm (or, in demo mode, the arm model) works out
the joint angles. Turn on **Settings → Prompts → Show the model's reasoning** to also see its reasoning
(much slower). Each prompt is also saved as JSON in `prompt_logs/`.

Things the prompt tools handle for you:

- **A cube under another cube.** "Pick the red cube" when the blue one sits on it: the arm first lifts the
  blue one onto the nearest free spot of the table, looks again, then picks the red one (the Prompt log says so).
- **Free table space.** "Put it outside the tray / close to the robot base / on the left / far away / next to
  the red cube": the app chooses a reachable spot that is clear of every object and the saved places (it never
  lets the model invent coordinates). "Close to the base" means the nearest the arm can reach down to the table,
  about 170 mm from the base column. This needs the table height: the demo knows it; live mode uses calibration
  step 5 (or, failing that, measures it with the camera).
- Objects that a stack hides completely can't be seen; the app remembers what it stacked itself and says so
  ("hidden"), but a pile someone built by hand with the camera unable to see the lower cube can't be taken apart.

## Switching to live hardware

1. Set `mode: live` in `config.yaml`.
2. Set `robot.port` to the Dobot Magician's COM port.
3. Install the Orbbec SDK wheel for `pyorbbecsdk` (not on PyPI — get it from
   https://github.com/orbbec/pyorbbecsdk for your OS/Python version).
4. Calibrate (see *Calibrating the camera* below) before using click-to-move
   or prompt-driven pick/place — an identity transform is used until you
   calibrate, which will not correspond to real-world positions.
5. Press **System check** in the toolbar: it checks the robot, camera, USB
   connection, depth quality, calibration, table and Ollama, and says what to fix.
6. The end effector: `robot.gripper_type` is `gripper` (two fingers) or `suction`. For the gripper, check
   the numbers under `robot.gripper` on your robot before relying on them:
   - `opening_mm`: open the gripper (Manual tab) and measure between the fingers' inside faces.
   - `finger_depth_mm`: how far down an object's sides the fingers can go.
   - `jaw_axis_deg`: with r = 0, the direction the fingers close along (90 = across the arm when it points
     straight out). Jog to r = 0 and look from above.
   - Do the calibration's table-height step with the **fingertips** touching the table: heights are then
     measured from the fingertips, and the fingers close halfway down each object.
   Each pick is checked against these (too wide, too flat, a neighbour in the fingers' way) and the Model
   tab shows the measured size, the finger turn and the room to spare.

## The second robot: UFACTORY xArm 6

When the app starts, a small window asks **which robot** (Dobot Magician or UFACTORY xArm 6, with the xArm
Gripper) and **Demo or Live**, and says what Start will do. The last choice is already picked, so Enter starts as
before; nothing connects until you press Start. The toolbar's **Robot** and **Mode** lists still switch later
(the app restarts into the new choice, without asking again). In demo mode you get that robot's 3D twin; in live mode
the app connects to that real robot. Prompts, the Manual tab, calibration and detection work the same for both.

- **Each robot keeps its own** settings (`config.yaml`: `robot:` for the Dobot, `xarm6:` for the xArm), calibration
  (`calibration_xarm6.json`, `calibration_demo_xarm6.json`) and saved places (`app/poses_xarm6`,
  `app/poses_demo_xarm6`). Switching never touches the other robot's.
- **The twin** is drawn from UFACTORY's own model of this arm (the 1305 version: serial XI1305...; see
  `app/twin/xarm6/meshes/NOTICE.txt`). Its tool always points straight down, like the Dobot's, so poses are the
  same x, y, z and turn r. Nearer than 200 mm to its base the wrist would come down on the base, so in the demo
  every scene (and the simulated camera) is set out 120 mm further from the base than for the Dobot.
- **Manual tab, xArm:** the same jog buttons; **Gripper opens** (how far the fingers open to pick and let go,
  default 40 mm, up to 86; wider takes bigger objects but needs more room, 40 mm just fits the demo's tray). Live
  also has **Gripper speed**, **Collision stop** (the controller's collision sensitivity), and **Enable motors**,
  **Clear errors**, **Check errors**, **Reset after E-STOP**. The 3D view's joint gauges show J1-J6.
- **Live, first time:**
  1. Install the SDK: `pip install xarm-python-sdk` (in the app's conda environment).
  2. Set `xarm6: ip:` in `config.yaml` to the control box's address (the one UFACTORY Studio connects to).
  3. Check in UFACTORY Studio that the arm moves and the gripper opens, and that the base is level on the table.
  4. The app sets the tool point 172 mm below the flange (the gripper's fingertips), caps the speed at 250 mm/s
     (100 by default) and keeps the arm inside `xarm6: workspace_bounds`. Start slow, with the E-STOP button of
     the control box within reach.
  5. Calibrate the camera for the xArm (its own calibration), with the table-touch step.
  6. Check `gripper_position` in `app/hardware/xarm.py` once: open the gripper to 40 mm in the Manual tab and
     measure the gap between the fingertips.

## MVP scope (what's built)

- **Demo mode**: kinematic PyBullet twin, no hardware needed.
- **Manual tab**: jog XYZ, gripper open/close, save/replay named poses,
  click-to-move on the live camera feed.
- **Prompt tab**: type a natural-language command; a Qwen3 tool-calling agent
  (via Ollama) decides which robot actions to take.
- **Calibration** (Calibration tab): with a cube (no marker, the most accurate), or
  automatically with a printed marker, or by hand (boardless point-teach) followed by
  a table-touch step; then a verification step. See below.
- **Always-visible E-stop** in the toolbar.
- **Turning:** "turn the brown block 70 degrees", or "put the cube in the tray at 45 degrees": any angle, both robots;
  round things look the same at any turn and are left as they are.
- **Model** list in the Prompt tab, above the prompt box: the Qwen models Ollama has installed, each with what
  it is good for -- Quick (`qwen3:4b-instruct-2507`, the default), Detailed planning (`qwen3:8b`), Deep reasoning
  (`qwen3:4b`, slow here) -- and dots for speed and planning. Picking one loads it and frees the other; the label
  beside it and the status bar say loading / ready / not loaded. Closing the app unloads it.
- **More ways to ask** (both robots): rows ("line up the cubes by size, 3 cm apart"), moves by a distance ("move
  the red cube 5 cm left"), taking a pile apart, emptying the tray, "between", swap, "put it back" / "undo that",
  "slowly", "do it again", and "the cube on the left" / "the one nearest the robot".
- **System check** in the toolbar, and a **camera-moved warning** (status bar).
- **Settings** in the toolbar (demo mode): a panel beside the 3D view to pick the demo scene and switch
  each of the 3D view's effects and helpers on or off
  (soft shadows, rim light, highlights, measuring mat, studio background, reach map, joint
  gauges, height line, path preview, ghost target, camera cone, gripper glow, what the camera
  sees, labels, tip trail, view buttons, auto-rotate, save-image button). Changes show at once
  and are remembered in `config.yaml` under `display:`. With them all off the view looks as in V1.8.
  The Scene section also has **Shuffle** (a random layout the robot can work with; each has a number
  you can type in to repeat it).
- **Step by step** (switch next to Send on the Prompt tab): each robot move of a prompt is shown first
  (in words, and in the 3D view) and waits for **Go**, **Go all** or **Stop**.
- **Simulated camera quality** (demo Settings panel): Perfect / Realistic / Poor, and a
  **Bump camera** button, to rehearse a real depth camera's noise, holes and
  a knocked mount without hardware.

Not built: ChArUco-board calibration, markerless self-calibration, OWLv2
open-vocabulary detection, multi-camera support, the live-mode "preview
before execute" twin toggle. See the plan file's Milestones section.

## Memory

The app itself is small (about 0.1-0.3 GB). The big user is the language model: `qwen3:8b` holds
about 6 GB in RAM while loaded, and Ollama keeps it there for 5 minutes after the last prompt. On
a 16 GB PC with a browser open, that is most of what is free. Press **System check** to see who is
using what. To free the model sooner, add to `config.yaml`:

```yaml
llm:
  keep_alive: 30s       # unload the model 30 seconds after the last prompt ("0" = straight away)
```

(the next prompt then takes a few extra seconds to reload it), or switch to the smaller
`qwen3:4b-instruct-2507` (`ollama pull qwen3:4b-instruct-2507-q4_K_M`, about 2.5 GB). The app logs its own memory once a minute to
`app.log` and warns if it ever grows past 3 GB.

## First day at the lab

1. Power the Dobot (DC supply *and* USB) and plug the Orbbec camera into a **USB 3** port.
   Set the camera so it looks at the workspace from above or the side, and don't move it after this.
2. Start the app in live mode. Press **System check** and fix anything red.
3. Manual tab: jog with a small step to check the arm moves, and that **E-STOP** stops it.
   Set rough safety bounds (you can leave Z min for now; step 5 of the calibration sets it).
4. Calibration tab: **with a cube** (C, most accurate for picking), or automatic (marker) or by hand followed by
   **step 5** (tip touching the table); then **Verify**. Aim for a typical error under 1 mm (cube) or 3 mm.
5. Only then try click-to-move (Manual tab) and a prompt ("pick the red cube ...").
6. If anything looks wrong later, press **System check** and **Check camera position**, and keep
   the folder from `sessions/` to look at at home.

**Gripper.** `robot.gripper_type` in `config.yaml` must match what is on the arm: `suction` (air pump and
cup) or `gripper` (the two-finger claw); the wrong one does nothing useful. The open/close commands go to the
robot outside its motion queue, so they act at once (also right after an E-STOP), and the app then waits
`robot.gripper_settle_s` (default 0.8 s) for the air to build up or drain before it lifts or moves on. If an
object is dropped on lifting, raise it (say 1.5); `app.log` shows how long each command and wait took.
`robot.max_speed` (mm/s, default 100) is sent to the arm when the app connects. Both the arm speed and the
gripper wait can be changed in the Manual tab (**Speed** box: Very slow 20 / Slow 50 / Normal 100 / Fast 150
mm/s; gripper wait Quick 0.4 s to Extra careful 2.5 s). In live mode the choice is saved to `config.yaml`. The
Dobot has no speed setting for the gripper itself (it is only on or off), so "gripper wait" is the only
gripper timing that can be adjusted.

The arm's reach is limited near the base and at height, so the app keeps automatic sweeps and
verification points between 160 mm and 285 mm from the base column. If the robot ever raises an
alarm, Clear Alarms on the Manual tab; if it comes back, power-cycle it.

## Calibrating the camera

Calibration finds where the camera is relative to the robot. Three ways in, one way out. Choose the way with
*Calibration style* at the top of the Calibration tab (with a cube, the most accurate, is the first); only its
steps are shown.

**A. Automatic (marker).** In the Calibration tab press *Save marker print
sheet*, print it at 100% / actual size (check the 100 mm bar with a ruler), cut
out the 30 mm marker (40 mm if the camera is more than ~0.5 m from the arm) and
stick it flat on a stiff card on top of the tool, facing the camera. Jog the tip
to the middle of the workspace, 60-100 mm above the table, then *Start automatic
calibration*. The arm sweeps (never lower than where it started), the camera
finds the marker each time, and the wrist is turned once to work out how far
off-centre the marker is, with no measuring.

**B. By hand.** Jog the tip to a point, *Arm next click*, click the middle of the
tool's body in the picture (same spot every time), repeat 8+ times spread over the
amber areas of the map, *Solve*. Wheel zooms, drag pans, R resets the picture.
Points that look like mis-clicks are flagged; *Remove worst point*.

**C. With a cube (no marker; the most accurate).** It is measured where objects are
picked, with the real gripper and the depth camera, so nothing is measured far above
the table (the marker sits ~150 mm above the fingertips, where a 1 degree tilt is a
2-3 mm miss at the table).

1. Clear the table but for one cube that fits the open gripper (15-30 mm, square,
   matte). Switch the camera on 15 minutes before: its distances drift while it warms.
2. Manual tab: open the gripper and lower it until the fingertips just touch the
   table; press *Fingertips on the table* (Calibration tab): the table's height is
   recorded and the arm rises 1 mm. If the fingers are longer than the cube is tall
   (the xArm's), do this round the cube and then close the gripper. If they are
   shorter (the Dobot's 15 mm fingers and a 20 mm cube), touch the table beside the
   cube, then lift, move over it, lower until the gripper rests on it, and close.
3. Choose *Precise* (20 spots, about 10 minutes) or *Quick* (10 spots), optionally
   type the cube's size (calipers; otherwise the camera measures it), and press
   *Calibrate with a cube*. The robot centres the cube in the gripper, puts it down
   at the spots with the wrist turned different ways, and the camera finds it each
   time (by comparing the depth picture with the empty table: no calibration needed
   for that). It then puts it back at the first spot to check it hasn't slipped.

The solve uses the table's surface (thousands of depth points round the spots) for
the camera's tilt and height, and the cube's positions for the rest. It also tries
the camera's distances scaled, the depth sensor's own picture (the real camera), and
in Precise mode a gentle correction over the table for the arm's own error; each is
kept only if every spot, predicted from all the others, comes out better. The result
is kept only if spots typically agree to 2 mm (every mode); it then
sets the table height and safety floor too (no step 5). The text lists every check
(slip, how flat the table is, whether the fingers' middle is off the wrist's axis,
what was left out and why), and arrows on the picture show each spot's miss, enlarged.

Then, optionally: *Pick test* (the cube put at 3 spots the calibration never saw,
found by the camera, and picked up from where the camera says it is); *Add 1 cube*
or *Add 2 cubes* (put them on the table first, at least 15 cm apart): towers of 2 or 3
are built at a few spots, each level checked by the camera before the next goes on,
to check and improve the heights (kept only if better); or *Finish*. Stop puts the
cube down; E-STOP stops at once.

**For the best accuracy:** a rigid camera mount (any wobble undoes it), the camera
warmed up, a matte cube, and the camera as near as its view allows (a stereo
camera's distance noise grows with the square of the distance). The real camera's
pictures are straightened for its lens as they come in (`camera.undistort` in
`config.yaml`, on by default); a calibration made with that switched the other way
is reported in the log at start: recalibrate.

**Step 5, after A or B: set the table height.** Lower the tip until it just
touches the table and press the button. Both methods measure a spot above the
tip, so without this every height the camera reports is too low by that distance
and the arm would be sent into the table. This also sets the safety floor (Z min).

**Verify.** *Verify calibration* sends the tip to five spots and finds it in the
camera picture by itself; the gap is the calibration's measured error. Good is under
1.5 mm typical, usable under 3 mm. If the misses all lean one way it says so (a
shifted or tilted calibration, which the cube calibration removes).

**Has the camera moved?** After every calibration the app saves a reference view
of the scene. On the next start (live mode) and on *Check camera position* it
compares: if the picture has slid or the table's apparent height or tilt has
changed, the status bar warns *Camera moved? Recalibrate*.

**Sessions.** Every run is saved in `sessions/<date>/` (`sessions_demo/` in demo
mode): each point, the camera picture and depth at that moment, the result, the
table step and the verification. Debug one without any hardware:

```bash
python -m app.calibration.replay sessions/20260918_143012
python -m app.calibration.replay sessions/20260918_143012 --redepth --drop 3
```

The printable marker sheet is also at `markers/dobot_marker_A4.png`.

## What the camera counts as an object (Detection)

Press **Detection** in the toolbar. Changes take effect at once (the camera feed shows them) and are kept in
`config.yaml`: the real camera's under `vision:`, the demo's own under `vision_demo:` (it starts on *Any object*;
changing one never changes the other, so "coloured cubes only" against the real camera's phantoms doesn't hide the
demo's ball and can).

- **Find:** *any object* (whatever its colour or shape, by how it stands up from the table: the depth camera) or
  *coloured cubes only* (by their colour, the ranges in `config.yaml`).
- **Leave out (against phantom objects):** things *lower than* N mm above the table (any object only), *smaller
  than* N mm across, and things *not seen in* N camera pictures in a row (2 on the real camera unless set: depth
  noise comes and goes).
- **Pick area:** only objects whose middle is inside an X/Y rectangle, in the arm's coordinates. The camera feed
  draws it as a dashed outline. To find the numbers, jog the gripper to two opposite corners of your mat and read
  X and Y on the Manual tab.

On the real camera, also: do the calibration's **table-touch step** (without it the camera's heights can be far
off, the arm is looked for in the wrong place and its own parts show up as objects), and set `robot: look_pose` in
`config.yaml` so the arm moves out of the camera's view before it looks.

## Tests

```bash
python -m unittest discover -s tests -v          # everything, ~12 minutes (the simulator renders a lot)
python -m unittest discover -s tests -p test_live_in_the_loop.py -v   # the whole app in live mode, against a fake Dobot
python tests/robustness_report.py                # accuracy against camera noise, click sloppiness, mis-clicks
python tests/prompt_bench.py                     # 43 typical prompts through the real model (Ollama), scored by the table
python tests/prompt_bench.py --robot xarm6 --only row,move   # some kinds, the xArm; --list shows the prompts
```
## Key decisions made while scaffolding

- **Object detector is color-blob (HSV threshold), not YOLOv8.** YOLOv8 needs
  trained weights or labeled data for cube-shaped objects, which we don't have
  yet. Color-blob detection works immediately for the red/blue test cubes
  with zero training. Both live behind the same `Detector` interface
  (`app/vision/detector.py`) — swap in `YOLOv8Detector` once you have
  training data (Milestone 10 in the plan).
- **The digital twin is the real Dobot Magician (DT-MG-4R005-02E)**: its
  published dimensions (shoulder axis 131.3 mm above the base, rear arm 135 mm,
  forearm 147 mm, tool axis 60 mm in front of the wrist) and its real shape.
  The 3D views draw the Magician's own meshes with the two-finger gripper,
  posed joint by joint the way the real parallelogram arm moves
  (`app/twin/magician_model.py`). The meshes come from the MIT-licensed
  [jkaniuka/magician_ros2](https://github.com/jkaniuka/magician_ros2), simplified
  to about 4,500 triangles so the view can redraw quickly; see
  `app/twin/meshes/NOTICE.txt` and `LICENSE`. The simulated camera the detector
  uses still sees simple shapes along the same joint geometry. Joint limits
  are not modelled.

## Known limitations / things to verify during hardware bring-up (Milestone 2)

- `app/hardware/dobot.py` targets the common `pydobot` API
  (`.pose()`, `.move_to()`, `.suck()`, `.grip()`, `.stop()`). Verify these
  method names against your installed `pydobot` version — they can drift
  between releases.
- `app/hardware/camera.py` targets the common Orbbec `Pipeline` /
  `AlignFilter` pattern. Verify against your installed `pyorbbecsdk` version.
- `app/ui/video_widget.py` polls `camera.get_frame()` from a `QTimer` on the
  UI thread. This is fine for the sim camera; if the real Orbbec camera call
  proves slow enough to cause UI stutter, move frame polling to a background
  thread.

## Project layout

```
app/
  main.py              entry point
  config.py            loads config.yaml
  hardware/            Robot + Camera interfaces, real (Dobot/Orbbec) and sim backends
  twin/                PyBullet world + scenarios, the Magician's model and meshes (twin/meshes)
  vision/              detector, pixel->3D locator, scene builder, table finder, camera-moved check
  calibration/         solver, by-hand + marker calibration, table touch, verify, sessions
  llm/                 Ollama client, tool schema/dispatch, agent loop, the Model tab's record (trace, recording)
  ui/                  PyQt6 main window, panels, worker thread helper
  poses/               saved named poses (created at runtime)
markers/              printable calibration marker sheet
sessions/             saved calibration sessions (created at runtime)
screenshots/          pictures saved with the 3D view's "Save image" button (created at runtime)
prompt_logs/          the Model tab's record of each prompt, one JSON file each (created at runtime)
tests/                unit tests and the robustness report
config.yaml
requirements.txt
```

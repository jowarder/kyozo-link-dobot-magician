# Overnight summary, 2026-10-22

Nothing is committed. The camera and the Dobot were not touched. The private test folder was not opened.

## What changed

1. **No printed paper:** 20 new training tasks in 4 levels. The cubes go anywhere by hand, and the camera says READY.
2. **The test generator makes the unseen set from `train.yaml`.** You run it with your secret seed.
3. **Reviewer-2 fixes.** Details in CHANGELOG.md under V4.0; the main ones:
   - **Scoring:** the start that counts is a fresh 5-picture look taken at Start run. The end look is 5 pictures, and it looks once more if a cube is missing.
   - **The app refused correct moves:** "left, then right" and "right and further" had their second leg refused. Now fixed.
   - **The arranger and the tools disagreed on room between cubes:** READY could accept starts from which the app then refused the task. Now fixed.
   - **The test set could repeat training tasks with only the colours changed.** Now refused. Angles now go up to 40° (past 45° a wrong-way turn would score as right) and gaps start at 20 mm, as in training.
   - **Calibration:** the reported error is now honest (it read too low). Re-gripping by hand no longer loops. A run with no slip check now says so.
   - **Dobot:** a lost serial reply no longer crashes the run with "'NoneType' object has no attribute 'params'".
   - **Secrecy:** the deletion log lines for test runs now go into the private Recycle_Bin folder.
4. **Manual tab UI bug fixed:** its right side was cut off (X+, Home, Clear Alarms, the bounds' Max). The position readout was one long unwrapped line. It now wraps, and the column keeps itself wide enough.

## Test results

- **Watcher:** 137 tests pass.
- **Cube calibration and wrist:** 111 pass.
- **UI:** 40 pass.
- **Every other suite** passes, `test_cube_tour` included (it failed only while the machine was overloaded running everything at once; on its own: 4 of 4).
- **Training file:** the checker passes it. Every task can be done from 99–200 of 200 random starts.
- **Test generator:** on a throwaway seed it made all 20 tasks, each done in the twin (7 min).
- **Qwen in the twin, the 20 new training tasks:** 17/20 passed. The 3 failures are Qwen's own planning mistakes (it did one of two moves; it stacked the cube instead of swapping; it named the wrong cube). That is what the study measures, so it's left as the baseline.

## What needs you (in this order)

1. **Restart the app** to get the fixes.
2. ~~**Dr. Curry's OK on the PREREG changes made tonight.**~~ **Done: Dr. Curry approved all of them (2026-10-22), recorded in PREREG §9 items 7-10.**
   - The self-check before each session is now **Verify calibration**: recalibrate if it's over 3 mm. The automatic self-check PREREG promised never existed.
   - Test angles are 15–40° and gaps 20–40 mm (you had approved 15–60°; see above for why).
   - The test is described as "near transfer" (the same kinds of tasks with new values and words).
   - On the Dobot, the starts are placed by hand, and their difficulty is recorded and reported.
   - New in §7: the hardware measured at the start of each study (`study/HARDWARE.csv`), and the compensations reported per hardware limit (the ledger's new `hardware_limit` column).
3. **`.claude/settings.json`:** the deny rules that keep Claude out of the test folders name **old** folder names, so they protect nothing now. I left them alone because it's a permission file. Add Read/Edit deny rules for these folders under `Kyozo_Link_Results`:
   - `Test_Tasks_private`
   - `Study_Overview_private`
   - `Backup_do_not_edit`
   - `Recycle_Bin/Test_private`
   - every `*Test_Data` folder

   PREREG §8 says these rules exist.
4. **Make the test set** with your seed (watcher → Test tasks… → Make test tasks…). Replace the old one.
5. **Follow `study/LAB_DAY_CHECKLIST.md`:** calibrate, check the camera sees the area's corners, check the still cube's angle reading, Verify before each session.
6. **Freeze and commit** when you're happy. Say "commit" and I'll commit everything except the lab files.

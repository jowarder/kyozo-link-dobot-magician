@echo off
cd /d "%~dp0"
"%USERPROFILE%\miniconda3\envs\dobot_vision\python.exe" -m app.main
if errorlevel 1 (
    echo.
    echo The app exited with an error. See above.
    pause
)

"""Checks a task file before it is used: for the engineer's private TEST set (and the training set, the template).

    python study/check_tasks.py <file.yaml>       e.g. ...\\Kyozo_Link_Results\\Private_never_for_Claude\\Test_Tasks\\test.yaml
    python study/check_tasks.py --test-set        the test set where the watcher looks for it

It reports problems only by task id and kind (an unknown target kind, a cube the start doesn't have, a spot that
doesn't exist, no start the task can be done from, the same as a training task...) and the count per category. It
never prints a prompt, a target or a position, so its output can't give the unseen tasks away. Still: don't paste a
test file into a Claude conversation, and Claude never runs this on the test set.

Exit code 0: no problems.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import yaml  # noqa: E402

TRAIN_FILE = ROOT / "study" / "tasks" / "train.yaml"
TEMPLATE_FILE = ROOT / "study" / "tasks" / "test_template.yaml"
SIMPLE_FILE = ROOT / "study" / "tasks" / "simple.yaml"   # the unseen test is built on it (Dr. Curry, 2026-10-23)
COLOURS = ("red", "blue", "green")
SPOTS = ("spot_1", "spot_2", "spot_3", "spot_4")
CATEGORIES = ("spot", "move", "beside", "between", "rotate", "row", "swap", "from_spot", "multi",
              "turn", "move_turn", "tower", "drop")      # (the last four: Simple 20, study/tasks/simple.yaml)
# each target kind: its required fields, and the fields naming a cube (or cubes)
KINDS = {
    "in_zone": (("cube", "zone"), ("cube",)),
    "moved": (("cube",), ("cube",)),
    "beside": (("cube", "of", "side", "gap"), ("cube", "of")),
    "between": (("cube", "a", "b"), ("cube", "a", "b")),
    "yaw": (("cube", "deg"), ("cube",)),
    "turned": (("cube", "deg"), ("cube",)),
    "row": (("cubes",), ("cubes",)),
    "swapped": (("a", "b"), ("a", "b")),
    "from_spot": (("cube", "spot", "side", "distance"), ("cube",)),
    "at_start": (("cube",), ("cube",)),
    "zone_empty": (("zone",), ()),
    "tower": (("cubes",), ("cubes",)),
}
SIDES = {"beside": ("left", "right"), "from_spot": ("left", "right", "towards", "away")}
AREA_SIDES = ("left", "right", "further", "nearer")     # a paper-free set's beside sides
WANTED_TASKS = 20
MIN_GOOD_STARTS = 50           # a paper-free task: at least this many of 200 random starts must suit it (a quarter)


def _canonical(task: dict) -> dict:
    """A task's substance as it is scored: the start's cubes in any order, a swap's or a between's two cubes in any
    order, an unordered row's cubes in any order, and a move's `via` (its first leg: only words) left out."""
    start = dict(task.get("start") or {})
    if isinstance(start.get("cubes"), list):
        start["cubes"] = sorted(str(c) for c in start["cubes"])
    targets = []
    for target in task.get("targets") or []:
        if not isinstance(target, dict) or len(target) != 1:
            targets.append(target)
            continue
        (kind, spec), = target.items()
        spec = dict(spec or {})
        spec.pop("via", None)
        if kind == "swapped":
            spec = {"cubes": sorted([str(spec.get("a")), str(spec.get("b"))])}
        elif kind == "between":
            spec = {"cube": spec.get("cube"), "ends": sorted([str(spec.get("a")), str(spec.get("b"))])}
        elif kind == "row" and not spec.get("order"):
            spec["cubes"] = sorted(str(c) for c in spec.get("cubes") or [])
        targets.append({kind: spec})
    return {"start": start, "targets": targets}


def _targets_key(task: dict) -> str:
    """A task's substance (start rule + targets, as scored), to spot one copied from the training set or the
    template -- the same targets written in another order, or a move's first leg said differently, are the same."""
    return yaml.safe_dump(_canonical(task), sort_keys=True)


def _values_key(task: dict) -> str:
    """The substance without the colours: the same moves, turns, sides, gaps as another task, whatever the cubes."""
    text = _targets_key(task)
    for colour in COLOURS:
        text = text.replace(colour, "C")
    return text


def _has_values(task: dict) -> bool:
    """Whether a task has values of its own to draw (a distance, an angle, a gap): a swap or a between has none."""
    return any(k in (spec or {}) for target in task.get("targets") or [] if isinstance(target, dict)
               for spec in target.values() if isinstance(spec, dict) for k in ("dx", "dy", "deg", "gap", "radial"))


def _known(path: Path) -> tuple[set, set]:
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except OSError:
        return set(), set()
    tasks = data.get("tasks") or []
    return ({" ".join(str(t.get("prompt", "")).lower().split()) for t in tasks},
            {_targets_key(t) for t in tasks} | {"values:" + _values_key(t) for t in tasks if _has_values(t)})


def check(path: Path) -> tuple[list[str], dict]:
    """(problems, counts): the problems as "task id: what kind of problem" lines -- nothing of the tasks' content."""
    problems: list[str] = []
    try:
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return [f"the file can't be read as YAML ({type(exc).__name__}; look near the line it names)"], {}
    if not isinstance(data, dict) or not isinstance(data.get("tasks"), list):
        return ["the file has no 'tasks:' list"], {}
    paper_free = "area" in data
    chained = bool(data.get("chained"))        # (Simple 20: not the study's set -- no training check)
    if not paper_free and data.get("sheet") != "a4":
        problems.append("the file must say 'area: {x: [..], y: [..]}' (no paper) or 'sheet: a4' (the printed sheet)")
    if 3 not in (data.get("cube_sets") or []):
        problems.append("'cube_sets' must include 3")
    train = yaml.safe_load(TRAIN_FILE.read_text(encoding="utf-8"))
    if data.get("pass_rule") != train.get("pass_rule"):
        problems.append("the pass_rule differs from the training set's (it must be the same: 10 mm, 8 deg, 10 mm)")
    if float(data.get("cube_size_mm", 25)) != 25.0:
        problems.append("cube_size_mm must be 25")

    seen_prompts, seen_targets = (_known(TRAIN_FILE) if Path(path).resolve() != TRAIN_FILE and not chained
                                  else (set(), set()))
    if chained and data.get("set") == "test":      # (the unseen test built on Simple 20: none of its tasks again)
        seen_prompts, seen_targets = _known(SIMPLE_FILE)
    template_prompts, template_targets = (_known(TEMPLATE_FILE)
                                          if Path(path).resolve() != TEMPLATE_FILE and not chained else (set(), set()))
    ids: set = set()
    counts: dict = {}
    for n, t in enumerate(data["tasks"], start=1):
        name = str(t.get("id") or f"task #{n}")
        if not t.get("id"):
            problems.append(f"{name}: no id")
        elif name in ids:
            problems.append(f"{name}: the id is used twice")
        ids.add(name)
        category = t.get("category")
        counts[category] = counts.get(category, 0) + 1
        if t.get("level") not in (1, 2, 3, 4, 5):
            problems.append(f"{name}: give it a level, 1 (easiest) to 5")
        if category not in CATEGORIES:
            problems.append(f"{name}: unknown category (use one of {', '.join(CATEGORIES)})")
        prompt = str(t.get("prompt") or "")
        if not prompt.strip():
            problems.append(f"{name}: no prompt")
        if "CHANGE ME" in prompt.upper() or "<" in prompt:
            problems.append(f"{name}: the prompt is still the template's placeholder")
        normal = " ".join(prompt.lower().split())
        if normal in seen_prompts:
            problems.append(f"{name}: the same prompt as a training task (Claude has seen it)")
        if normal in template_prompts:
            problems.append(f"{name}: the same prompt as the template's example (Claude has seen it)")
        key = _targets_key(t)
        if key in seen_targets:
            problems.append(f"{name}: the same start and targets as a training task (Claude has seen it)")
        elif _has_values(t) and "values:" + _values_key(t) in seen_targets:
            problems.append(f"{name}: the same as a training task but for the colours (Claude has seen it)")
        if key in template_targets:
            problems.append(f"{name}: the same start and targets as the template's example (Claude has seen it)")
        # the start rule
        start = t.get("start")
        if not isinstance(start, dict) or not start.get("cubes"):
            problems.append(f"{name}: no start rule (start: {{cubes: [...]}})")
            continue
        colours = [str(c) for c in start["cubes"]]
        if any(c not in COLOURS for c in colours) or len(set(colours)) != len(colours):
            problems.append(f"{name}: start cubes must be different ones of red, blue, green")
        if len(colours) not in ((1, 2, 3) if paper_free else (1, 3)):
            problems.append(f"{name}: start with " + ("1, 2 or 3 cubes" if paper_free else "1 or 3 cubes"))
        if paper_free and (start.get("pin") or start.get("free")):
            problems.append(f"{name}: no paper, so no spots: the start is just {{cubes: [...]}}")
        for colour, spot in (start.get("pin") or {}).items():
            if colour not in colours:
                problems.append(f"{name}: 'pin' names a cube the start doesn't have")
            if spot not in SPOTS:
                problems.append(f"{name}: 'pin' names a spot that doesn't exist (spot_1..spot_4)")
        if any(str(c) not in colours for c in start.get("tower") or []):
            problems.append(f"{name}: the start's tower names a cube the start doesn't have")
        if any(s not in SPOTS for s in start.get("free") or []):
            problems.append(f"{name}: 'free' names a spot that doesn't exist (spot_1..spot_4)")
        if len(colours) + len(start.get("free") or []) > 4:
            problems.append(f"{name}: more cubes and free spots than the sheet has spots")
        # the targets
        targets = t.get("targets") or []
        if not targets:
            problems.append(f"{name}: no targets")
        ends: dict = {}
        for target in targets:                         # (each target is checked against the cube's final place)
            if isinstance(target, dict) and len(target) == 1:
                (kind, spec), = target.items()
                for field in {"in_zone": ("cube",), "moved": ("cube",), "beside": ("cube",), "between": ("cube",),
                              "from_spot": ("cube",), "at_start": ("cube",), "swapped": ("a", "b"),
                              "row": ("cubes",), "tower": ("cubes",)}.get(kind, ()):
                    value = (spec or {}).get(field)
                    for cube in value if isinstance(value, list) else [value]:
                        ends[cube] = ends.get(cube, 0) + 1
        if any(n > 1 for n in ends.values()):
            problems.append(f"{name}: a cube has two targets saying where it ends (no run can meet both; give it "
                            "one, e.g. from_spot instead of in_zone + moved)")
        if category == "multi" and len(targets) < 2:
            problems.append(f"{name}: a multi-step task needs a target for each step")
        labels = {f"{c} cube" for c in colours}
        for target in targets:
            if not isinstance(target, dict) or len(target) != 1:
                problems.append(f"{name}: each target is one kind, e.g. {{in_zone: {{...}}}}")
                continue
            (kind, spec), = target.items()
            if kind not in KINDS:
                problems.append(f"{name}: unknown target kind (use one of {', '.join(KINDS)})")
                continue
            required, cube_fields = KINDS[kind]
            spec = spec or {}
            missing = [f for f in required if f not in spec]
            if kind == "moved" and not any(k in spec for k in ("dx", "dy")):
                missing.append("dx or dy")
            if kind == "moved" and "radial" in spec:
                problems.append(f"{name}: a moved target uses radial; towards/away from the robot is dx (along the "
                                "sheet's arrow), as in training")
                continue
            if missing:
                problems.append(f"{name}: a {kind} target misses {', '.join(missing)}")
                continue
            for field in cube_fields:
                names = spec[field] if isinstance(spec[field], list) else [spec[field]]
                if any(c not in labels for c in names):
                    problems.append(f"{name}: a {kind} target names a cube the start doesn't have "
                                    "(write it as 'blue cube')")
            for field in ("zone", "spot"):
                if field in spec and spec[field] not in SPOTS:
                    problems.append(f"{name}: a {kind} target names a spot that doesn't exist (spot_1..spot_4)")
            sides = AREA_SIDES if paper_free and kind == "beside" else SIDES.get(kind)
            if sides and spec.get("side") not in sides:
                problems.append(f"{name}: a {kind} target's side must be one of {', '.join(sides)}")
            if paper_free and kind in ("in_zone", "from_spot", "zone_empty", "yaw"):
                problems.append(f"{name}: no paper: a {kind} target needs the printed sheet" +
                                (" (use turned: by how much)" if kind == "yaw" else ""))
        if any(c not in labels for c in t.get("oracle") or []):
            problems.append(f"{name}: the oracle names a cube the start doesn't have")
    if len(data["tasks"]) != WANTED_TASKS:
        problems.append(f"{len(data['tasks'])} tasks (the study has {WANTED_TASKS})")
    if problems:
        return problems, counts
    # every task must have a start it can be done from (on the sheet, in reach, room for the cubes)
    try:
        from watcher.arrange import count_arrangements
        from watcher.tasks import load_task_set
        tasks = load_task_set(path, 3)
        if tasks.chained:                          # Simple 20: each task from where the ones before leave the cubes
            problems += _check_chain(tasks)
            return problems, counts
        for task in tasks.tasks:
            good = count_arrangements(task, tasks)
            if tasks.area is not None and good < MIN_GOOD_STARTS:
                problems.append(f"{task.id}: only {good} of 200 random starts let it be done (a target out of the "
                                "area or reach, or too close to another cube): the hand's start would often be refused")
            elif good == 0:
                problems.append(f"{task.id}: no start arrangement lets it be done (a target off the sheet, out of "
                                "reach, or too close to another cube)")
    except Exception as exc:  # noqa: BLE001
        problems.append(f"the watcher couldn't load it ({type(exc).__name__})")
    return problems, counts


def _check_chain(tasks) -> list[str]:
    """A chained set: from its start layout, every task in turn must be READY from where the tasks before it (done as
    asked) leave the cubes -- as the camera sees them, a cube under a tower hidden."""
    from watcher.arrange import chain_start, check_start
    from watcher.tasks import stacked
    if not tasks.start_layout:
        return ["a chained set needs start_layout: {colour: [x, y], ...}"]
    problems = []
    for task in tasks.tasks:
        cubes = chain_start(tasks, task.id)
        seen = [c for c in cubes if not any(o is not c and o.level > c.level and stacked(c, o) for o in cubes)]
        why = check_start(task, tasks, seen)
        if why:
            problems.append(f"{task.id}: not READY after the tasks before it ({why})")
    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Checks a task file without printing its tasks.")
    parser.add_argument("file", nargs="?", help="the task file (.yaml)")
    parser.add_argument("--test-set", action="store_true", help="the test set where the watcher looks for it")
    args = parser.parse_args(argv)
    if args.test_set:
        from watcher import results
        try:
            path = results.test_set_file()
        except FileNotFoundError as exc:
            print(exc)
            return 1
    elif args.file:
        path = Path(args.file)
    else:
        parser.print_help()
        return 1
    problems, counts = check(path)
    print(f"{sum(counts.values())} tasks: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items(), key=str)))
    if problems:
        print(f"{len(problems)} problem(s):")
        for p in problems:
            print(f"  - {p}")
        return 1
    print("OK: every task has a start it can be done from, and none is a training task.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

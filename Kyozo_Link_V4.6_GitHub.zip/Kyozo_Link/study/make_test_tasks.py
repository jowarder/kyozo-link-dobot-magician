"""Makes the study's unseen TEST set from a secret seed: 20 tasks, T-n mirroring Simple 20's task S-n (Dr. Curry,
2026-10-23: the test is built on Simple 20, study/tasks/simple.yaml) -- or, for a base set that isn't chained, the
training set's TR-n.

    python study/make_test_tasks.py                  asks for your secret seed (typed hidden), then makes the set
    python study/make_test_tasks.py --no-twin-check  without running each task in the twin (quicker)
    python study/make_test_tasks.py --replace        a test set is there already: keep it as test_OLD_<date>.yaml

Or in the watcher: Make test tasks... (the same). The set goes straight to
Kyozo_Link_Results\\Private_never_for_Claude\\Test_Tasks\\test.yaml, with test_tasks.md / .html beside it for you to read. Nothing of
the tasks is printed: only their ids, levels and that they passed the checks. Keep the seed somewhere private (the same
seed makes the same set); it is written only inside the private test.yaml.

The test tasks are made FROM THE TRAINING SET (study/tasks/train.yaml), task by task: T-n has TR-n's level, category,
number of cubes and steps in the same order (move, a move in two directions, a move and then another, turn, beside,
between, swap, a row, a row in a given order), each with its own values drawn from the seed -- colours, distances
(20-60 mm), directions, angles (15-60 degrees, clockwise or anticlockwise), sides (left, right, further, nearer), gaps,
the row's order -- and its own wording. Change the training tasks and the next set made follows them: no code change.

Every task:
  - needs no paper (V4.1): its cubes go anywhere on the grey sheet by hand, and every target is relative to the cubes;
  - can be done from most random starts (study/check_tasks.py: a quarter of them at least, watcher/arrange.py);
  - can be done with the app's tools as they are: each step has a known tool recipe (move_object, turn_object,
    place_beside, place_between, swap, line_up); with the twin check, that recipe is run in the twin from two seeded
    random starts and must pass the watcher's scorer -- a task that doesn't is drawn again;
  - passes study/check_tasks.py (not a training task's prompt or start and targets).

It refuses to make a new set once a REAL test run has been saved (the test can't change in the middle of the study),
and retires a test set left in the old places (renamed test_RETIRED_<date>.yaml) so the watcher never reads it.

Built on Simple 20 (BASE_FILE, chained) the set is a chain like it: the three cubes (red, green, blue) put down once,
each task starting where the one before leaves them, in Simple 20's four groups (moves; swaps each with a turn; towers
of two built and taken down; a tower of three and two drops). T-n has S-n's group and kind with its own cubes,
directions, distances and gaps (40-60 mm), turns (20-40 degrees either way), tower orders and drop heights; every task
must be READY from where the tasks before it leave the cubes, isn't a Simple 20 task (not even with the colours
changed), and -- with the twin check -- is done in the twin by its tool recipe where the twin can (not a start with a
tower: the twin can't take a cube off one; not a drop: no tool for it), passing the watcher's scorer.

Claude never reads this file's output, the test set or its results (study/ROUND_PROMPT.md).
"""
from __future__ import annotations

import argparse
import getpass
import random
import sys
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import yaml  # noqa: E402

from watcher import results  # noqa: E402

TRAIN_FILE = ROOT / "study" / "tasks" / "train.yaml"
COLOURS = ("red", "blue", "green")
DISTANCES = tuple(range(20, 61, 5))                   # mm
GAPS = (20, 25, 30, 35, 40)                           # mm, face to face (beside): as training's, 20-40
ROW_GAPS = (20, 25, 30, 35, 40)                       # mm (line up)
# degrees: 15-40, clockwise or anticlockwise. Not past 45: a cube looks the same every 90 degrees, so 60 anticlockwise
# scores as 30 clockwise, and 45 is the same either way -- a turn the wrong way would pass
ANGLES = tuple(range(15, 41, 5))
DIRECTIONS = ("left", "right", "further", "nearer")
AXIS = {"left": ("dy", 1), "right": ("dy", -1), "further": ("dx", 1), "nearer": ("dx", -1)}
OPPOSITE = {"left": "right", "right": "left", "further": "nearer", "nearer": "further"}
SIDES = ("left", "right", "further", "nearer")
ONE_CUBE_STEPS = ("turn", "move", "move2", "move_via")
MAX_DRAWS = 400                                       # tries for one task before giving up
DIR_WORDS = {"left": "to the left", "right": "to the right", "further": "further from the robot",
             "nearer": "nearer the robot"}
SIDE_WORDS = {"left": "to the left of", "right": "to the right of", "further": "further from the robot than",
              "nearer": "nearer the robot than"}
TOOL_DIRECTION = {"left": "left", "right": "right", "further": "forward", "nearer": "back"}   # move_object's words
TOOL_SIDE = {"left": "left", "right": "right", "further": "front", "nearer": "behind"}        # place_beside's words

# The wording: a few ways to say each step (one is drawn per step). {A}, {B}, {C}: cubes.
WORDS = {
    "move": ("Move the {A} {d} mm {dir}", "Slide the {A} {d} mm {dir}", "Shift the {A} {d} mm {dir}"),
    "move2": ("Move the {A} {d} mm {dir} and {d2} mm {dir2}", "Slide the {A} {d} mm {dir} and {d2} mm {dir2}",
              "Shift the {A} {d} mm {dir} and {d2} mm {dir2}"),
    "move_via": ("Move the {A} {d} mm {dir}, then {d2} mm {dir2}", "Slide the {A} {d} mm {dir}, and then {d2} mm {dir2}",
                 "Shift the {A} {d} mm {dir}, then {d2} mm {dir2}"),
    "turn": ("Turn the {A} {deg} degrees {way}", "Rotate the {A} {deg} degrees {way}"),
    "beside": ("Put the {A} {side} the {B}, with a {gap} mm gap", "Place the {A} {side} the {B}, {gap} mm apart",
               "Set the {A} down {side} the {B}, with a {gap} mm gap"),
    "between": ("Put the {A} between the {B} and the {C}", "Place the {A} halfway between the {B} and the {C}",
                "Move the {A} to the middle between the {B} and the {C}"),
    "swap": ("Swap the {A} and the {B}", "Swap the places of the {A} and the {B}", "Exchange the {A} and the {B}"),
    "row": ("Line up the three cubes in a row, {gap} mm apart", "Put the three cubes in a row, {gap} mm apart",
            "Arrange the three cubes in a straight line, {gap} mm apart"),
    "row_order": ("Line up the cubes {gap} mm apart: {X}, {Y}, {Z} from left to right",
                  "Put the cubes in a row, {gap} mm apart, {X}, {Y} and {Z} from left to right",
                  "Arrange the cubes in a straight line {gap} mm apart, from left to right: {X}, {Y}, {Z}"),
}


@dataclass
class Shape:
    """One training task's shape: its level and category, its cubes as roles (A, B, C: the training task's colours in
    its start's order, drawn afresh as colours for the test), and its steps in order: (kind, roles..., extra)."""
    mirrors: str
    level: int
    category: str
    cubes: int                                         # 1, 2 or 3 on the table
    steps: list = field(default_factory=list)


def shapes_from(path: Path = TRAIN_FILE) -> list[Shape]:
    """The training set's tasks as shapes, in order (T-n mirrors the n-th). Raises ValueError for a target kind the
    paper-free test can't mirror (one that needs the printed sheet)."""
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    shapes = []
    for t in data["tasks"]:
        colours = [str(c) for c in t["start"]["cubes"]]
        role = {f"{c} cube": "ABC"[i] for i, c in enumerate(colours)}
        steps: list = []
        for target in t["targets"]:
            (kind, spec), = target.items()
            if kind == "moved":
                if spec.get("via"):
                    (via_axis, _), = spec["via"].items()
                    net = {k: float(spec.get(k, 0)) - (float(spec["via"][k]) if k == via_axis else 0.0)
                           for k in ("dx", "dy")}
                    other = "dy" if via_axis == "dx" else "dx"
                    steps.append(("move_via", role[spec["cube"]], "same" if net[via_axis] else "other"))
                    if net[other] and net[via_axis]:
                        raise ValueError(f"{t['id']}: a move's second leg must be along one axis")
                elif spec.get("dx") and spec.get("dy"):
                    steps.append(("move2", role[spec["cube"]]))
                else:                                  # (along the same line as training's: x or y)
                    steps.append(("move", role[spec["cube"]], "dx" if spec.get("dx") else "dy"))
            elif kind == "turned":
                steps.append(("turn", role[spec["cube"]]))
            elif kind == "beside":
                steps.append(("beside", role[spec["cube"]], role[spec["of"]]))
            elif kind == "between":
                steps.append(("between", role[spec["cube"]], role[spec["a"]], role[spec["b"]]))
            elif kind == "swapped":
                steps.append(("swap", role[spec["a"]], role[spec["b"]]))
            elif kind == "row":
                steps.append(("row_order" if spec.get("order") else "row", *[role[c] for c in spec["cubes"]]))
            else:
                raise ValueError(f"{t['id']}: a {kind} target can't be mirrored without the paper")
        shapes.append(Shape(t["id"], int(t["level"]), str(t["category"]), len(colours), steps))
    return shapes


def cube(colour: str) -> str:
    return f"{colour} cube"


def draw_task(shape: Shape, n: int, rng: random.Random) -> tuple[dict, list[dict]]:
    """One candidate test task for a shape: (the task as written in test.yaml, its tool recipe -- the steps)."""
    colours = rng.sample(COLOURS, shape.cubes)
    roles = dict(zip("ABC", colours))
    steps: list[dict] = []
    for kind, *who in shape.steps:
        a = cube(roles[who[0]])
        if kind == "move":
            steps.append({"do": "move", "cube": a, "dir": rng.choice([x for x in DIRECTIONS if AXIS[x][0] == who[1]]),
                          "d": rng.choice(DISTANCES)})
        elif kind in ("move2", "move_via"):
            first = rng.choice(DIRECTIONS)
            d, d2 = rng.choice(DISTANCES), rng.choice(DISTANCES)
            if kind == "move_via" and who[1] == "same":     # back along the same line, past or short of the start
                second = OPPOSITE[first]
                while abs(d2 - d) < 15:
                    d2 = rng.choice(DISTANCES)
            else:                                          # then along the other line
                second = rng.choice([x for x in DIRECTIONS if AXIS[x][0] != AXIS[first][0]])
            steps.append({"do": kind, "cube": a, "dir": first, "d": d, "dir2": second, "d2": d2})
        elif kind == "turn":
            steps.append({"do": "turn", "cube": a, "deg": rng.choice(ANGLES) * rng.choice((1, -1))})
        elif kind == "beside":
            steps.append({"do": "beside", "cube": a, "of": cube(roles[who[1]]), "side": rng.choice(SIDES),
                          "gap": rng.choice(GAPS)})
        elif kind == "between":
            steps.append({"do": "between", "cube": a, "a": cube(roles[who[1]]), "b": cube(roles[who[2]])})
        elif kind == "swap":
            steps.append({"do": "swap", "cube": None, "a": a, "b": cube(roles[who[1]])})
        elif kind in ("row", "row_order"):
            order = [cube(roles[r]) for r in who]
            if kind == "row_order":
                rng.shuffle(order)
            steps.append({"do": kind, "cube": None, "cubes": order, "gap": rng.choice(ROW_GAPS)})
    task = {"id": f"T-{n:02d}", "level": shape.level, "category": shape.category, "start": {"cubes": colours},
            "prompt": prompt_of(steps, rng), "targets": targets_of(steps), "oracle": oracle_of(steps)}
    return task, steps


def prompt_of(steps: list[dict], rng: random.Random) -> str:
    """The steps in words, joined with "then"; a step on the same cube as the one before says "it"."""
    parts = []
    last = last_do = None
    for step in steps:
        do = step["do"]
        fill = {"move": lambda s: {"A": s["cube"], "d": s["d"], "dir": DIR_WORDS[s["dir"]]},
                "move2": lambda s: {"A": s["cube"], "d": s["d"], "dir": DIR_WORDS[s["dir"]], "d2": s["d2"],
                                    "dir2": DIR_WORDS[s["dir2"]]},
                "turn": lambda s: {"A": s["cube"], "deg": abs(s["deg"]),
                                   "way": "anticlockwise" if s["deg"] > 0 else "clockwise"},
                "beside": lambda s: {"A": s["cube"], "B": s["of"], "side": SIDE_WORDS[s["side"]], "gap": s["gap"]},
                "between": lambda s: {"A": s["cube"], "B": s["a"], "C": s["b"]},
                "swap": lambda s: {"A": s["a"], "B": s["b"]},
                "row": lambda s: {"gap": s["gap"]},
                "row_order": lambda s: {"gap": s["gap"], "X": s["cubes"][0].replace(" cube", ""),
                                        "Y": s["cubes"][1].replace(" cube", ""),
                                        "Z": s["cubes"][2].replace(" cube", "")}}
        fill["move_via"] = fill["move2"]
        sentence = rng.choice(WORDS[do]).format(**fill[do](step))
        # ("it" only after a step on that one cube alone: after "... to the left of the green cube" it could be either)
        if last is not None and step.get("cube") == last and do in ONE_CUBE_STEPS and last_do in ONE_CUBE_STEPS:
            sentence = sentence.replace(f"the {last}", "it", 1)
        parts.append(sentence)
        last, last_do = step.get("cube"), do
    text = ", then ".join([parts[0]] + [p[0].lower() + p[1:] for p in parts[1:]])
    return text + "."


def _by(direction: str, d: float) -> tuple[str, int]:
    axis, sign = AXIS[direction]
    return axis, sign * int(d)


def targets_of(steps: list[dict]) -> list[dict]:
    """What the scorer checks, from the steps (a move in two legs is one target: where it ends; `via` its first leg)."""
    targets: list[dict] = []
    for step in steps:
        do = step["do"]
        if do == "move":
            axis, by = _by(step["dir"], step["d"])
            targets.append({"moved": {"cube": step["cube"], axis: by}})
        elif do in ("move2", "move_via"):
            net = {"dx": 0, "dy": 0}
            for direction, d in ((step["dir"], step["d"]), (step["dir2"], step["d2"])):
                axis, by = _by(direction, d)
                net[axis] += by
            spec = {"cube": step["cube"], **{k: v for k, v in net.items() if v}}
            if do == "move_via":
                axis, by = _by(step["dir"], step["d"])
                spec["via"] = {axis: by}
            targets.append({"moved": spec})
        elif do == "turn":
            targets.append({"turned": {"cube": step["cube"], "deg": step["deg"]}})
        elif do == "beside":
            targets.append({"beside": {"cube": step["cube"], "of": step["of"], "side": step["side"],
                                       "gap": step["gap"]}})
        elif do == "between":
            targets.append({"between": {"cube": step["cube"], "a": step["a"], "b": step["b"]}})
        elif do == "swap":
            targets.append({"swapped": {"a": step["a"], "b": step["b"]}})
        elif do == "row":
            targets.append({"row": {"cubes": list(step["cubes"]), "gap": step["gap"]}})
        elif do == "row_order":
            targets.append({"row": {"cubes": list(step["cubes"]), "gap": step["gap"], "order": list(step["cubes"])}})
    return targets


def oracle_of(steps: list[dict]) -> list[str]:
    out: list[str] = []
    for step in steps:
        for name in ([step["cube"]] if step.get("cube") else []) + (
                [step["a"], step["b"]] if step["do"] == "swap" else []) + list(step.get("cubes") or []):
            if name not in out:
                out.append(name)
    return out


def recipe(steps: list[dict]) -> list[tuple[str, dict]]:
    """The app's tools that do the steps, in order (object names stand for their ids, filled in from list_objects)."""
    calls: list[tuple[str, dict]] = []
    for step in steps:
        do = step["do"]
        if do == "move":
            calls.append(("move_object", {"object_id": step["cube"], "direction": TOOL_DIRECTION[step["dir"]],
                                          "distance_mm": step["d"]}))
        elif do in ("move2", "move_via"):
            for direction, d in ((step["dir"], step["d"]), (step["dir2"], step["d2"])):
                calls.append(("move_object", {"object_id": step["cube"], "direction": TOOL_DIRECTION[direction],
                                              "distance_mm": d}))
        elif do == "turn":
            calls.append(("turn_object", {"object_ids": [step["cube"]], "turn_deg": step["deg"]}))
        elif do == "beside":
            calls += [("pick", {"object_id": step["cube"]}),
                      ("place_beside", {"object_id": step["of"], "side": TOOL_SIDE[step["side"]],
                                        "gap_mm": step["gap"]})]
        elif do == "between":
            calls += [("pick", {"object_id": step["cube"]}),
                      ("place_between", {"object_id_a": step["a"], "object_id_b": step["b"]})]
        elif do == "swap":
            calls.append(("swap", {"object_id_a": step["a"], "object_id_b": step["b"]}))
        elif do in ("row", "row_order"):
            calls.append(("line_up", {"object_ids": list(step["cubes"]), "gap_mm": step["gap"],
                                      "along": "left_to_right"}))
    return calls


class RecipeClient:
    """A stand-in for the model that calls the recipe's tools in order: list_objects first (for the ids), then each
    call with the cubes' names swapped for their ids. It stops at the first refusal."""

    def __init__(self, calls: list[tuple[str, dict]]):
        self.calls = calls

    def chat(self, model, messages, tools=None, temperature=0.2):
        import ast
        done = [m["content"] for m in messages if m["role"] == "tool"]
        if not done:
            return self._call("list_objects", {})
        if done[-1].startswith("ERROR"):
            return {"role": "assistant", "content": f"Couldn't: {done[-1]}"}
        if len(done) > len(self.calls):
            return {"role": "assistant", "content": "Done."}
        ids = {o["label"]: o["id"] for o in ast.literal_eval(done[0])["objects"]}
        name, args = self.calls[len(done) - 1]

        def to_id(value):
            if isinstance(value, list):
                return [ids.get(v, v) for v in value]
            return ids.get(value, value) if isinstance(value, str) else value
        return self._call(name, {k: (to_id(v) if k.startswith("object_id") else v) for k, v in args.items()})

    @staticmethod
    def _call(name: str, arguments: dict) -> dict:
        return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": arguments}}]}


def twin_check(task, tasks, steps: list[dict], calls: Optional[list] = None) -> bool:
    """The recipe run in the twin from this start (`steps`' recipe, or the tool `calls` given); True if the watcher's
    scorer passes it."""
    sys.path.insert(0, str(ROOT / "tests"))
    import importlib.util
    from app.llm.agent import Agent
    from watcher.tasks import score
    spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
    twin_test = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(twin_test)
    twin = twin_test.TwinRun(task, tasks)
    try:
        agent = Agent(RecipeClient(calls if calls is not None else recipe(steps)), twin.executor, "recipe",
                      max_tool_calls=30)
        agent.run(task.prompt)
        return score(task, twin.cubes(), tasks.zones, tasks.rule, tasks.cube_size_mm).passed
    finally:
        twin.stop()


def header(seed: str, twin: Optional[bool] = None) -> dict:
    train = yaml.safe_load(TRAIN_FILE.read_text(encoding="utf-8"))
    made = {"by": "study/make_test_tasks.py", "when": datetime.now().isoformat(timespec="seconds"), "seed": seed}
    if twin is not None:                               # (the same seed makes the same set only with these the same)
        from watcher import observe
        made.update(twin_checked=bool(twin), git_commit=observe.git_commit())
    return {"set": "test", "cube_size_mm": 25, "cube_sets": [3], "area": train["area"], "pass_rule": train["pass_rule"],
            "made": made}


def _yaml(data: dict) -> str:
    return ("# Watcher study -- the unseen TEST set (PRIVATE: never shown to Claude). Made by study/make_test_tasks.py;\n"
            "# T-n mirrors training task TR-n. Check it with: python study/check_tasks.py --test-set\n"
            + yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=200))


def make(seed: str, twin: bool = True, say: Callable[[str], None] = print) -> dict:
    """The test set's data for a seed (nothing written). `say` gets progress by task id only."""
    from watcher.arrange import arranged, count_arrangements
    from watcher.tasks import load_task_set
    sys.path.insert(0, str(ROOT / "study"))
    import check_tasks
    data = header(seed, twin)
    data["tasks"] = []
    # what the checker refuses (study/check_tasks.py): a training task's prompt or start and targets -- or the
    # template's example's -- so no finished set is turned down at the end
    train_prompts, train_keys = set(), set()
    for known in (check_tasks.TRAIN_FILE, check_tasks.TEMPLATE_FILE):
        prompts, keys = check_tasks._known(known)
        train_prompts |= prompts
        train_keys |= keys
    if twin:
        from app import robots
        robots.set_active("dobot_magician")            # (the study's robot; the twin is the Dobot's)
    with tempfile.TemporaryDirectory() as folder:
        scratch = Path(folder) / "one.yaml"
        for n, shape in enumerate(shapes_from(TRAIN_FILE), start=1):
            rng = random.Random(f"kyozo-test-set|{seed}|T-{n:02d}")   # (each task its own: one's twin check
            twin_errors = 0                                          # can't change the next one's draws)
            for tries in range(1, MAX_DRAWS + 1):
                task, steps = draw_task(shape, n, rng)
                if " ".join(task["prompt"].lower().split()) in train_prompts or \
                        check_tasks._targets_key(task) in train_keys or \
                        (check_tasks._has_values(task) and "values:" + check_tasks._values_key(task) in train_keys) or \
                        any(t["prompt"] == task["prompt"] for t in data["tasks"]):
                    continue
                scratch.write_text(_yaml(dict(header(""), tasks=[task])), encoding="utf-8")    # (no seed in it)
                one = load_task_set(scratch, 3)
                ways = count_arrangements(one.tasks[0], one)
                if ways < check_tasks.MIN_GOOD_STARTS:     # (the hand's random start would often be refused)
                    continue
                if twin:
                    done = True
                    for r in (1, 2):                   # (the watcher's progress bar reads these lines: ids only)
                        say(f"T-{n:02d} (level {shape.level}): checking in the twin, start {r} of 2")
                        try:                           # (its own starts: not the twin test's runs' starts)
                            done = twin_check(arranged(one.tasks[0], one, "testgen", r), one, steps)
                        except Exception:  # noqa: BLE001 - the twin failing to run counts as not done (by id only)
                            done, twin_errors = False, twin_errors + 1
                        if not done:
                            break
                    if not done:
                        say(f"T-{n:02d}: the twin couldn't do one start; drawn again")
                        continue
                data["tasks"].append(task)
                say(f"T-{n:02d} (level {shape.level}): ready" + (", done in the twin from two starts" if twin else ""))
                break
            else:
                if twin_errors:
                    raise RuntimeError(f"T-{n:02d}: the twin wouldn't run ({twin_errors} times): check it works "
                                       "(python study/twin_test.py) before trying another seed")
                raise RuntimeError(f"T-{n:02d}: no task found in {MAX_DRAWS} draws (try another seed)")
    return data


def real_test_runs(root: Path) -> int:
    """How many REAL test runs are saved (once there are any, the test set can't change)."""
    from watcher import report
    return sum(len(report._run_folders(results.kind_folder(True, "test", where, n, root)))
               for n in results.STUDIES for where in ("twin", "dobot")
               if results.kind_folder(True, "test", where, n, root).exists())


def retire_old(root: Path) -> int:
    """A test set left where the test set used to be kept: renamed test_RETIRED_<date>.yaml (never read again)."""
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    old = [Path(root) / "2_REAL_TEST_counts_for_paper" / "test_set" / "test.yaml",
           Path(root).parent / "Kyozo_Link_study_test" / "test.yaml"]
    done = 0
    for path in old:
        if path.exists():
            path.rename(path.with_name(f"test_RETIRED_{stamp}.yaml"))
            done += 1
    return done


def write(data: dict, root: Path = results.RESULTS_ROOT, replace: bool = False) -> Path:
    """test.yaml (and test_tasks.md / .html to read) in Private_never_for_Claude\\Test_Tasks, checked by study/check_tasks.py. An
    existing set is kept as test_OLD_<date>.yaml (only if `replace`). Refused once a real test run is saved."""
    sys.path.insert(0, str(ROOT / "study"))
    import check_tasks
    from watcher import report
    if real_test_runs(root):
        raise RuntimeError("REAL test runs are saved already: the test set can't change in the middle of the study")
    folder = Path(root) / results.TEST_TASKS
    target = folder / "test.yaml"
    if target.exists() and not replace:
        raise FileExistsError(f"{target} is there already (replace it to keep it as test_OLD_<date>.yaml)")
    folder.mkdir(parents=True, exist_ok=True)
    part = folder / "test.yaml.part"
    part.write_text(_yaml(data), encoding="utf-8")
    problems, _ = check_tasks.check(part)
    if problems:
        part.unlink()
        raise RuntimeError(f"the made set didn't pass study/check_tasks.py ({len(problems)} problem(s)); try "
                           "another seed")
    if target.exists():
        target.rename(folder / f"test_OLD_{datetime.now().strftime('%Y-%m-%d_%H%M%S')}.yaml")
    part.replace(target)
    chained = bool(data.get("chained"))
    md = ["# The unseen test set (PRIVATE: never shown to Claude)", "",
          f"Made {data['made']['when']} by study/make_test_tasks.py. "
          + ("T-n mirrors Simple 20's task S-n. The three cubes go down once, anywhere on the grey sheet: the arm sets "
             "them out where a group starts, and each task starts where the one before left them." if chained else
             "T-n mirrors training task TR-n. Start: the cubes to put anywhere on the grey sheet by hand, at least 4 cm "
             "apart (the watcher's camera says when it's READY)."), ""]
    md += report.md_table(["Task", "Level", "Kind", "Prompt", "Start"],
                          [[t["id"], t["level"], t["category"], t["prompt"], ", ".join(t["start"]["cubes"])]
                           for t in data["tasks"]])
    results.write_text(folder / "test_tasks.md", "\n".join(md) + "\n")
    results.write_text(folder / "test_tasks.html", report.md_to_html("\n".join(md), "Test tasks", {}))
    return target


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Makes the unseen test set from your secret seed (prints ids only).")
    parser.add_argument("--seed", help="your secret seed (leave it out to type it hidden)")
    parser.add_argument("--no-twin-check", action="store_true", help="don't run each task in the twin")
    parser.add_argument("--replace", action="store_true", help="replace a test set already there (kept as test_OLD)")
    parser.add_argument("--root", help="the results folder (default: Kyozo_Link_Results next to the project)")
    parser.add_argument("--seed-stdin", action="store_true", help="read the seed from the first line of input (the "
                        "watcher's Make test tasks... passes it this way, so it is never on a command line)")
    args = parser.parse_args(argv)
    # nothing the app's code logs while the tasks are drawn and tried in the twin (a refused move says where the cubes
    # are) may reach the screen or a file: only this script's own lines, by task id, are printed
    import logging
    logging.disable(logging.CRITICAL)
    if args.seed_stdin:
        seed = sys.stdin.readline().rstrip("\r\n")
    else:
        seed = args.seed or getpass.getpass("Your secret seed (not shown): ")
    if not seed.strip():
        print("No seed given.")
        return 1
    root = Path(args.root) if args.root else results.RESULTS_ROOT
    if real_test_runs(root):                           # (said before the long work, not after)
        print("Not made: REAL test runs are saved already: the test set can't change in the middle of the study")
        return 1
    if (root / results.TEST_TASKS / "test.yaml").exists() and not args.replace:
        print("Not made: a test set is there already (--replace keeps it as test_OLD_<date>.yaml and makes a new one)")
        return 1
    try:
        chained = bool(yaml.safe_load(BASE_FILE.read_text(encoding="utf-8")).get("chained"))
        data = (make_chained if chained else make)(seed.strip(), twin=not args.no_twin_check)
        path = write(data, root, replace=args.replace)
    except (RuntimeError, FileExistsError) as exc:      # (these say only ids, paths and what to do)
        print(f"Not made: {exc}")
        return 1
    except Exception as exc:  # noqa: BLE001 - anything else: its kind only, never its words (they may name a task)
        print(f"Not made: something went wrong ({type(exc).__name__})")
        return 1
    retired = retire_old(root)
    print(f"{len(data['tasks'])} test tasks made, all checks passed: {path}"
          + (f" ({retired} old test set(s) retired)" if retired else ""))
    print("Read them in test_tasks.html beside it. Don't paste them into a Claude conversation.")
    return 0


# ---- the unseen test built on Simple 20 (Dr. Curry, 2026-10-23) --------------------------------------------------------
SIMPLE_FILE = ROOT / "study" / "tasks" / "simple.yaml"
BASE_FILE = SIMPLE_FILE                               # what the unseen test mirrors (chained: built as a chain)
CHAIN_MOVES = (40, 45, 50, 55, 60)                    # mm: every distance and gap asked for 40 mm or more
CHAIN_GAPS = (40, 45, 50, 55, 60)
CHAIN_TURNS = (20, 25, 30, 35, 40)                    # degrees, either way (not 45: it scores the same both ways)
DROP_HEIGHTS = (40, 45, 50, 55, 60)                   # mm above the table
CHAIN_RESTARTS = 25                                   # a chain that can't go on: drawn again from T-01, this often
DROP_WITHIN_MM = 20


def chain_shapes(path: Path = BASE_FILE) -> list[dict]:
    """Simple 20's tasks as shapes, in order: {"mirrors", "level", "category", "kind", "n"} -- kind: moves (n cubes),
    swap_turn (n turned), tower (n high), unstack (from the tower the start has), drop_beside, drop_move."""
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    out = []
    for t in data["tasks"]:
        kinds = [next(iter(target)) for target in t["targets"]]
        specs = [next(iter(target.values())) for target in t["targets"]]
        drop = any("within_mm" in s for s in specs)
        tower_start = bool((t.get("start") or {}).get("tower"))
        if kinds == ["moved"] * len(kinds):
            kind, n = ("drop_move", 1) if drop else ("moves", len(kinds))
        elif kinds[0] == "swapped":
            kind, n = "swap_turn", kinds.count("turned")
        elif kinds == ["tower"]:
            kind, n = "tower", len(specs[0]["cubes"])
        elif kinds == ["beside"] and tower_start:
            kind, n = ("drop_beside" if drop else "unstack"), 1
        else:
            raise ValueError(f"{t['id']}: no way to mirror it in the chained test")
        out.append({"mirrors": t["id"], "level": int(t["level"]), "category": str(t["category"]), "kind": kind,
                    "n": n})
    return out


def _piles(cubes: list) -> list[list]:
    """The cubes as they stand, each pile bottom first (a cube on its own: a pile of one)."""
    from watcher.tasks import stacked
    piles: list[list] = []
    for c in sorted(cubes, key=lambda c: c.level):
        pile = next((p for p in piles if stacked(p[-1], c)), None)
        (pile.append(c) if pile is not None else piles.append([c]))
    return piles


def _seen(cubes: list) -> list:
    """What the camera sees from above: a cube with another on it is hidden."""
    from watcher.tasks import stacked
    return [c for c in cubes if not any(o is not c and o.level > c.level and stacked(c, o) for o in cubes)]


def _turn_words(deg: int) -> str:
    return f"{abs(deg)} degrees {'anticlockwise' if deg > 0 else 'clockwise'}"


def draw_chained(shape: dict, n: int, cubes: list, rng: random.Random) -> tuple[dict, list]:
    """One candidate T-n for a Simple 20 shape, from the cubes as they stand now: (the task, its tool recipe -- empty
    where the twin can't check it: a start with a tower, a drop)."""
    name = lambda c: c.label                                              # noqa: E731
    piles = _piles(cubes)
    tower = next((p for p in piles if len(p) > 1), None)
    free = [p[0] for p in piles if len(p) == 1]                          # (cubes on the table, nothing on them)
    kind, steps, targets, oracle, calls = shape["kind"], [], [], [], []
    if kind == "moves":
        chosen = rng.sample(free, shape["n"])
        for c in chosen:
            direction, d = rng.choice(DIRECTIONS), rng.choice(CHAIN_MOVES)
            axis, by = _by(direction, d)
            steps.append(f"the {name(c)} {d} mm {DIR_WORDS[direction]}")
            targets.append({"moved": {"cube": name(c), axis: by}})
            calls.append(("move_object", {"object_id": name(c), "direction": TOOL_DIRECTION[direction],
                                          "distance_mm": d}))
            oracle.append(name(c))
        prompt = "Move " + " and ".join(steps) + "."
    elif kind == "swap_turn":
        a, b = rng.sample(free, 2)
        deg = rng.choice(CHAIN_TURNS) * rng.choice((1, -1))
        turned = [a, b] if shape["n"] == 2 else [rng.choice([a, b])]
        targets = [{"swapped": {"a": name(a), "b": name(b)}}] + [{"turned": {"cube": name(c), "deg": deg}}
                                                                 for c in turned]
        which = "both of them" if len(turned) == 2 else f"the {name(turned[0])}"
        prompt = f"Swap the {name(a)} and the {name(b)}, then turn {which} {_turn_words(deg)}."
        oracle = [name(a), name(b)]
        calls = [("swap", {"object_id_a": name(a), "object_id_b": name(b)}),
                 ("turn_object", {"object_ids": [name(c) for c in turned], "turn_deg": deg})]
    elif kind == "tower":
        order = rng.sample(free, shape["n"])
        targets = [{"tower": {"cubes": [name(c) for c in order]}}]
        if shape["n"] == 2:
            prompt = f"Put the {name(order[1])} on the {name(order[0])}."
            oracle = [name(order[1])]
            calls = [("pick", {"object_id": name(order[1])}), ("place_on", {"object_id": name(order[0])})]
        else:
            prompt = (f"Build a tower with the {name(order[0])} at the bottom, then the {name(order[1])}, then the "
                      f"{name(order[2])} on top.")
            oracle = [name(c) for c in order]
            calls = [("build_tower", {"object_ids": [name(c) for c in order]})]
    elif kind in ("unstack", "drop_beside"):
        if tower is None:
            raise ValueError("no tower to take a cube off")
        top, bottom = tower[-1], tower[0]
        side, gap = rng.choice(SIDES), rng.choice(CHAIN_GAPS)
        spec = {"cube": name(top), "of": name(bottom), "side": side, "gap": gap}
        what = "the tower" if len(tower) > 2 else f"the {name(bottom)}"
        if kind == "drop_beside":
            spec["within_mm"] = DROP_WITHIN_MM
            prompt = (f"Take the {name(top)} off {what}, lift it {rng.choice(DROP_HEIGHTS)} mm above the table "
                      f"{SIDE_WORDS[side]} {what} with a {gap} mm gap, and let it drop.")
        else:
            prompt = f"Take the {name(top)} off {what} and put it {SIDE_WORDS[side]} {what} with a {gap} mm gap."
        targets, oracle = [{"beside": spec}], [name(top)]
    elif kind == "drop_move":
        c = rng.choice(free)
        direction, d = rng.choice(DIRECTIONS), rng.choice(CHAIN_MOVES)
        axis, by = _by(direction, d)
        targets = [{"moved": {"cube": name(c), axis: by, "within_mm": DROP_WITHIN_MM}}]
        prompt = (f"Pick up the {name(c)}, lift it {rng.choice(DROP_HEIGHTS)} mm above the table, move it {d} mm "
                  f"{DIR_WORDS[direction]}, and let it drop.")
        oracle = [name(c)]
    start: dict = {"cubes": ["red", "green", "blue"]}
    if tower is not None:
        start["tower"] = [c.color for c in tower]
    task = {"id": f"T-{n:02d}", "level": shape["level"], "category": shape["category"], "start": start,
            "prompt": prompt, "targets": targets, "oracle": oracle}
    return task, ([] if tower is not None or kind.startswith("drop") else calls)


def _as_task(task: dict):
    """A drawn task as the watcher's Task (as watcher/tasks.py reads it from a file, without drawing random starts: a
    chained task starts where the one before left the cubes)."""
    from watcher.tasks import Task
    start = task["start"]
    return Task(id=task["id"], category=task["category"], layout="chained", prompt=task["prompt"], start=[],
                targets=list(task["targets"]), oracle=list(task["oracle"]), start_rule=dict(start),
                level=task["level"], tower=[f"{c} cube" for c in start.get("tower", [])])


def chain_header(seed: str, twin: Optional[bool] = None) -> dict:
    base = yaml.safe_load(BASE_FILE.read_text(encoding="utf-8"))
    out = header(seed, twin)
    out.update(area=base["area"], pass_rule=base["pass_rule"], chained=True, time_limit_s=base.get("time_limit_s"),
               start_layout=base["start_layout"], levels=base.get("levels") or {})
    out["made"]["mirrors"] = "study/tasks/simple.yaml (Simple 20)"
    return out


def _paper_chain(shapes: list[dict], first: int, cubes: list, base, rng: random.Random, known: tuple) -> Optional[list]:
    """Tasks T-first.. drawn one after another on paper, each from where the ones before leave the cubes: [(task, its
    tool calls, the cubes before it)], or None if one can't be drawn from where the chain has got to."""
    from watcher.arrange import check_start, predicted_end
    from watcher.tasks import with_hidden
    sys.path.insert(0, str(ROOT / "study"))
    import check_tasks
    known_prompts, known_keys = known
    out = []
    for n, shape in enumerate(shapes[first - 1:], start=first):
        for _ in range(MAX_DRAWS):
            try:
                task, calls = draw_chained(shape, n, cubes, rng)
            except ValueError:
                continue
            if " ".join(task["prompt"].lower().split()) in known_prompts or \
                    check_tasks._targets_key(task) in known_keys or \
                    (check_tasks._has_values(task) and "values:" + check_tasks._values_key(task) in known_keys):
                continue                               # (a Simple 20 task, even with the colours changed: not unseen)
            t = _as_task(task)
            if check_start(t, base, _seen(cubes)) is not None:
                continue                               # (not READY from where the tasks before leave the cubes)
            full = with_hidden(_seen(cubes), [t.tower], base.cube_size_mm) if t.tower else list(cubes)
            _, end, _, problem = predicted_end(t, base, full)
            if problem is not None:
                continue
            out.append((task, calls, list(cubes)))
            cubes = list(end.values())
            break
        else:
            return None
    return out


def make_chained(seed: str, twin: bool = True, say: Callable[[str], None] = print) -> dict:
    """The unseen test as a chain mirroring Simple 20 (nothing written): T-n has S-n's group and kind, its own cubes,
    directions, distances, gaps, turns, tower orders and heights, drawn from the seed; each must start from where the
    tasks before it leave the cubes (READY from there, in the area and the arm's reach) and can't be a Simple 20 task
    (not even with the colours changed). The chain is found on paper first; then, with the twin check, each task the
    twin can do is done there by its tool recipe from where the chain has the cubes, and must pass the watcher's
    scorer -- one that doesn't is drawn again, with the rest of the chain after it."""
    from dataclasses import replace as _replace
    from watcher.tasks import layout_cubes, load_task_set
    sys.path.insert(0, str(ROOT / "study"))
    import check_tasks
    shapes = chain_shapes(BASE_FILE)
    known = check_tasks._known(BASE_FILE)
    base = load_task_set(BASE_FILE, 3)                 # (its area, pass rule and cube size: the test's)
    if twin:
        from app import robots
        robots.set_active("dobot_magician")
    for restart in range(CHAIN_RESTARTS):
        rng = random.Random(f"kyozo-test-chain|{seed}|{restart}")
        chain = _paper_chain(shapes, 1, layout_cubes(base), base, rng, known)
        if chain is None:
            continue                                   # (stuck on paper: a fresh draw from T-01, quickly)
        k, redraws = 0, 0
        while chain is not None and k < len(chain):
            task, calls, before = chain[k]
            group = "ABCD"[shapes[k]["level"] - 1]
            if twin and calls:                         # (the watcher's progress bar reads these lines: ids only)
                say(f"T-{k + 1:02d} (group {group}): checking in the twin, start 1 of 1")
                try:
                    done = twin_check(_replace(_as_task(task), start=before), base, [], calls)
                except Exception:  # noqa: BLE001 - the twin failing to run counts as not done (by id only)
                    done = False
                if not done:
                    redraws += 1
                    say(f"T-{k + 1:02d}: the twin couldn't do it; drawn again")
                    rest = _paper_chain(shapes, k + 1, before, base, rng, known) if redraws <= MAX_DRAWS else None
                    chain = chain[:k] + rest if rest is not None else None
                    continue
            say(f"T-{k + 1:02d} (group {group}): ready" + (", done in the twin" if twin and calls else ""))
            k += 1
        if chain is not None:
            data = chain_header(seed, twin)
            data["tasks"] = [task for task, _, _ in chain]
            return data
        say("The chain couldn't go on: drawn again from T-01")
    raise RuntimeError(f"no chain of {len(shapes)} test tasks found in {CHAIN_RESTARTS} tries (try another seed)")

if __name__ == "__main__":
    sys.exit(main())

# Watcher Study runbook: three studies, two improvements

*Rafiul Azim Jowarder, with Dr. Curry. Kyozo Link V4.0, GECA 2027. Design of 2026-10-12, approved by Dr. Curry ([PREREG.md](PREREG.md) §2 and §9).*

> This replaces the Normal / Extensive modes, the twin-only Round 0 and the final round. [RUNBOOK_NORMAL.md](RUNBOOK_NORMAL.md) and [RUNBOOK_EXTENSIVE.md](RUNBOOK_EXTENSIVE.md) are kept for their background (why the study, the watcher, what keeps it believable), but their round plans, zone layouts and folders no longer apply.

## The design

| Study | App | 1. Twin training | 2. Dobot training | 3. Unseen test | Then |
|---|---|---|---|---|---|
| study 1 | base (v0) | every training task once | every training task once | twin: each test task once; Dobot: each test task twice | the training goes to Claude → **v1** |
| study 2 | v1 | the same | the same | the same | the training goes to Claude → **v2** |
| study 3 | v2 | the same | the same | the same | stop: compare studies 1 → 2 → 3 |

**The main result:** the real Dobot's pass rate on the unseen test, study 1 vs study 3 (and study 2 between).

**Three rules that keep it valid:**
1. **Only the training goes to Claude** (twin and Dobot, paired). **Never the test results**, not even "it got 60%". If Claude learns how it did on the test, the test isn't unseen any more.
2. **Only the app changes between studies.** Same tasks, grey sheet, cubes, camera settings and calibration. Before each session press **Verify calibration** and write its result down; recalibrate only if it is over 3 mm.
3. **Starts alike in every study.** The twin's starts are seeded (set | task | repeat): the same in study 1, 2 and 3. On the Dobot you put the cubes down by hand: spread them over the grey sheet and turn them any way, the same way of doing it in every study (not squared up, not bunched in the middle). The watcher records each start as the camera saw it.

## Where everything goes

`C:\Users\rafi\Desktop\Software_Development\Kyozo_link_oct4\Kyozo_Link_Results\`

Each study's folders are named after the watcher's Session menu (V4.2):

```
study_1\  study_2\  study_3\                      the real study (the watcher's Study box; Practice session toggle OFF)
    Test_Twin_with_unseen_tasks\                      Test Twin with unseen tasks           NEVER shown to Claude
    Test_Real_Dobot_with_unseen_tasks\                Test Real Dobot with unseen tasks     NEVER shown to Claude
    20_Tasks_for_Twin\                                20 Tasks for Twin (by itself)         Claude reads these
    20_Tasks_for_Dobot\                               20 Tasks for Dobot (by itself)        Claude reads these
        FULL_REPORT.md  FULL_REPORT.html  full_report.json  results.xlsx  results_*.csv
        User_Saved_<folder name>\S-07_Run1.md …         one file per saved run, everything about it
            HTML_version\S-07_Run1.html …                the same run as one web page, pictures built in
        _raw_data\S-07_Run1\                             the evidence (run.json, trace.json, pictures, …)
        _sessions_log\<date>_<time>\                     each sitting's record and hash-chained index
    (Twin_Training_Data\, Dobot_Training_Data\: the training sessions, out of the menu)
Practice_Session\practice_study_1\ … practice_study_3\  the same four folders (Practice session toggle ON)
Prompt_Runs\                                             prompts typed with Watcher active on
For_Claude\study_N\  (and study_N.zip)                   Claude's input for each update (START_HERE.md, SUMMARY.md,
                                                         20_Tasks_for_Twin\, 20_Tasks_for_Dobot\); practice's in
                                                         For_Claude\Practice_Session\practice_study_N\
Private_never_for_Claude\                                NEVER shown to Claude: everything private, in one folder
    Test_Tasks\test.yaml                                 the unseen test tasks
    Study_Overview\                                      study 1 vs 2 vs 3: CROSS_STUDY_REPORT.md / .html,
                                                         cross_study.json, cross_study.xlsx, remade after every Save
    Study_Overview_practice\                             the same for practice
    Recycle_Bin_test\                                    the unseen test's discarded and replaced runs
Backup_do_not_edit\                                      a zip of each real folder at every session's end
Recycle_Bin\                                             discarded and replaced runs, whole
deletions_log.txt
_earlier_results\                                        what earlier layouts saved, moved aside (nothing deleted)
```

## Once, before study 1

**No printed paper (V4.1, Dr. Curry agreed 2026-10-22).** The cubes go anywhere on the grey sheet by hand; the camera checks them. Nothing to print, lay out or find.

1. **Camera:** Calibration tab → Camera setup: the Default depth preset, Detection "Any object", a fixed exposure (auto exposure washes the cubes out), the camera about 45 cm from the cubes. Then *Lock for study* and *Save reference*.
2. **Calibrate:** Calibration tab → dropdown → *With a cube*. Touch the table at all 6 points (*Fingertips on the table*), grip the cube, *Calibrate with a cube* (**Quick** or **Precise**). With the cube still held: **Fingers angle check** (the wrist's real angles, used by every pick), then **Rotation pick test** (correction on), then **Finish**. If a step loses the cube, grip it again on the Manual tab and press *Cube back in the gripper - continue*. The continuous calibration is **not** used in the study (PREREG §8).
3. **Make the test tasks yourself**, alone, with a secret seed only you know (write it down somewhere private: the same seed makes the same set). Use the watcher's **Test tasks… → Make test tasks…** (the seed typed hidden, twice), or `python study/make_test_tasks.py` (it asks for the seed hidden).
   - **What it makes:** 20 tasks made from the training tasks (`study/tasks/train.yaml`): T-n has TR-n's level, number of cubes and steps, with its own colours, 20–60 mm distances, directions, angles (15–60°, clockwise or anticlockwise), sides (left, right, further, nearer), gaps, row order and wording. None needs paper, none is a training task, each can be done from most random starts and with today's tools by a known recipe. Change the training tasks and the next set made follows them.
   - **The twin check (on by default, about 10 minutes):** each task's recipe is run in the twin from two random starts, and a task that fails is drawn again.
   - **Where it goes:** `Kyozo_Link_Results\Private_never_for_Claude\Test_Tasks\test.yaml`, plus `test_tasks.html` for reading it (**Test tasks… → Open the test tasks**). It prints only the task ids. **Make a new one now:** a set made before V4.1 still uses the paper's spots; replace it (it's kept as `test_OLD_<date>.yaml`).
   - **Safeguards:**
     - A test set already there is kept as `test_OLD_<date>.yaml`.
     - A set in the old places is renamed `test_RETIRED_<date>.yaml`. The watcher only ever reads `Private_never_for_Claude\Test_Tasks\test.yaml`.
     - Once a REAL test run is saved, a new set is refused.
   - **Checking a hand-edited file:** `python study/check_tasks.py --test-set` prints problems by task id only.
   - Don't paste the tasks into any Claude conversation.
4. **Practise** with the watcher's **Practice session** toggle ON: one Task for Twin session, a few runs, Save and Discard once each; then one Task for Dobot session, putting the cubes down by hand until READY. Look at what was saved in `Practice_Session\practice_study_1\…`.
5. **Freeze:** PREREG frozen (its hash in the paper), the code committed and tagged `study-v0`.

## Each study (N = 1, 2, 3)

**At the start of each study** (before its first session): fill one row of `study/HARDWARE.csv` (copy `study/HARDWARE_TEMPLATE.csv` the first time): Verify calibration, Pick test (if you calibrated), the still cube's angle spread in Camera setup, the touches' slope, minutes the camera was on, and notes (light, anything moved, the Dobot power-cycled). The same measures every study: they show the hardware didn't change.

Before each session in the watcher: **Practice session** toggle **OFF** (it asks you to confirm), **Study N** chosen.

**Choosing the runs (V3.9).** The **Session plan** tab lists the session's tasks by level, each with a tick box (a
level's box ticks all of it), how often it will run and the runs already saved for it. As it opens, every task is
ticked with the planned count (training once, the Dobot test twice), and the summary says "as planned". You can untick
tasks, set **Times each**, choose **In rounds** or **Back to back**, and **New start** (each repeat its own arrangement)
or **Same start** (every repeat as the first). A real session warns when a ticked task already has saved runs in that
study, but still lets you run it. During a session, **Run this task again** (after the score) or a right-click on a run
in the plan ("again next" / "at the end") adds another run of that task. Each session's `SESSION_SUMMARY.md` and
`session.json` (`plan_choice`) record what was ticked, what was left out and how it ran.

**Saving under a number.** **Save ▶ next** opens the Save dialog. It lists the task's saved runs here, and the run
number starts at the next free one. Choose any number (or your own tag). A number already saved **replaces** that run:
the earlier one moves, whole, to `Kyozo_Link_Results\Recycle_Bin\<the same path>\<run>__replaced_<date>`, with
`why.txt`. A real one needs a reason, which goes in `deletions_log.txt` and the report's "Discarded and replaced runs".
Discarded runs go there too (`__discarded_`). An unseen test run's go under `Private_never_for_Claude\Recycle_Bin_test\`,
which Claude never reads. The watcher never empties the Recycle_Bin.

1. **Twin training.** Demo mode → Watcher → Session: **Task for Twin** → Start session. Each run: the watcher sets the cubes out itself → Start run → your verdict, or **Skip** (the twin scores itself) → **Save ▶ next**, and choose the run's number (the next free one is filled in: "Run1"). Or tick **Run by itself (twin)** before Start session: every run is started, scored (Skip) and saved with no clicks, and it pauses only if something needs you. Use it the same way in all three studies, so the twin's numbers compare. Or, unattended: `python study/twin_test.py --version <base|v1|v2> --set train --real --round N` (it saves each run as Run<repeat>).
2. **Dobot training.** Live mode → Watcher → Session: **Task for Dobot** → Start session. Each run:
   1. Put the cubes it names anywhere on the grey sheet, at least 4 cm apart, nothing else on the table, until READY. If it says what to change (a cube too near the edge, too close to another, or the task can't be done from there), move them and it looks again.
   2. Start run, hands off.
   3. Your verdict first, then the watcher's score.
   4. **Save ▶ next** and choose the run's number, or **Discard and run again** if the run was spoiled by something outside the study (you bumped a cube, the camera was blocked). A real discard asks for a reason; it goes in `deletions_log.txt` and the paper reports it. The discarded run is kept in `Recycle_Bin`.
3. **Twin test.** Demo mode → Session: **Test Twin with unseen tasks** (every test task once). Or `python study/twin_test.py --version <…> --set test --real --round N`.
4. **Dobot test.** Live mode → Session: **Test Real Dobot with unseen tasks** (every test task, then every test task again: tag them Run1 and Run2). Same steps as the training.
5. **After studies 1 and 2 only: Claude's update.**
   1. Press **Claude's input…** (Study N): it gathers the twin's and the Dobot's 20 Tasks runs together into `Kyozo_Link_Results\For_Claude\study_N\` (it is also made by itself after each 20 Tasks session).
   2. Start a **new** Claude session and say: *Read …\For_Claude\study_N\START_HERE.md and do study N.* Don't mention the test results.
   3. Review Claude's changes, its narration (`study/NARRATION_vN.md`) and ledger (`study/CHANGES_vN.csv`). Accept or reject each change, run the tests, commit, and tag `v1` (after study 1) or `v2` (after study 2).
   4. Fill `study/COSTS.csv` for the study.

After study 3: no update. Analysis and the paper.

## Simple 20: the hands-off watcher test (V4.1; V4.2: the table as it is)

Twenty tasks in `study/tasks/simple.yaml`, in Dr. Curry's four groups of five: **A** moves only; **B** swaps, each
with a turn; **C** towers of two, built and taken down; **D** a tower of three, and two cubes let drop from a height.
Results go to the study's `20_Tasks_for_Dobot` (or `20_Tasks_for_Twin`), apart from the unseen test. The unseen test
runs the same way.

**V4.2: nothing is sorted, no task waits for a layout.** Each task starts from the table as the task before left it --
on the Dobot and in the twin. The arm no longer sets the cubes out.

1. Live mode, calibrated (Verify calibration), the arm homed, E-STOP reset.
2. Put the three cubes down anywhere on the grey sheet, once, apart from each other. Nothing else on the table. (The
   twin starts from the set's layout once, then carries on from wherever each task leaves its cubes.)
3. Watcher → Session **20 Tasks for Dobot (by itself)**, Practice on for a first try.
4. **▶ Run Group A**, B, C or D (each group a session of its own), **▶ Run all 20**, or any task's **▶ Run**.
5. Hands off. Before each task the watcher looks at the table: the arm parks out of the camera's way (and checks it got
   there), 3 pictures; if a cube is missing, the arm moves to a second position on the other side and the camera looks
   3 more times. Then the task starts with the cubes that are there -- a tower the last task left is understood (the
   cube under it isn't "missing"). Parts that need a cube that still can't be seen are recorded as impossible, the rest
   is done. A task none of whose cubes can be seen is skipped (saved as a run marked SKIPPED, with why); **no cube seen
   at all for 3 tasks in a row ends the session**. A camera that fails twice: that task isn't run (infrastructure).
   On the Dobot each task starts 5 s after the look (E-STOP stops everything; untick **Run by itself** to take over).
6. Each task gets **10 minutes**; one answer from Qwen at most 400 s (config.yaml `llm: timeout_s`). Every run is
   saved, whatever happens. **⏭ Proceed to next task** ends the current task at any point (saved, or skipped if it
   hadn't started). Every refused step is in the run log, run.json and refused_steps.csv.
7. If the gripper still holds a cube after a run, the watcher asks you to take it first (it doesn't drop it).
8. The results: `…\study_N\20_Tasks_for_Dobot\FULL_REPORT.md`, each run under `_raw_data`, the session's index and
   SESSION_SUMMARY.md under `_sessions_log`. Each run has:
   - its **outcome**: PASS (the strict pass, as before), SOME PARTS (a part met that wasn't already met at the start),
     FAIL, or SKIPPED; and a **CATASTROPHIC** flag if something went badly wrong (a cube knocked off or past the tray's
     edge, another cube moved more than 30 mm, a tower brought down; the arm couldn't park, lost its homing, or still
     holds a cube) -- the score isn't changed by it;
   - a **score out of 100** (Full 90+, Partial 50-89, Fail under 50): how close the cubes ended to what was asked;
   - its **start condition**: clean, tower to take down, cube out of the tray, cubes close together, cube not seen.
   A cube only in the task's way (on top of one of its cubes, or where one is to go) may be moved out of it: it must end
   on the table, not stacked, inside the tray. The failure type follows the first wrong step (a cube sent the wrong way
   is "plan"; a refusal while moving a cube out of the way is "preparation").
9. Study 1 was run under V4.1's rules: `study/rescore_v42.py <data folder>` scores its saved runs again with V4.2's,
   beside the originals (RESCORED_V4.2.md), so the studies compare like with like.

**Watcher active** (main window, next to the prompt box): any prompt you type is recorded the same way (no pass or
fail worked out), named by you when it ends, in `Kyozo_Link_Results\Prompt_Runs`.

## Suggested schedule (deadline Oct 30, internal Oct 25)

| Days | What |
|---|---|
| Oct 13 | Calibrate with a cube, make the test tasks, practise; freeze `study-v0` |
| Oct 14–15 | Study 1 |
| Oct 16 | Update 1 → v1 |
| Oct 17–18 | Study 2 |
| Oct 19 | Update 2 → v2 |
| Oct 20–21 | Study 3 |
| Oct 22–25 | Analysis and paper |

Every measure the study records: [MEASURES.md](MEASURES.md).

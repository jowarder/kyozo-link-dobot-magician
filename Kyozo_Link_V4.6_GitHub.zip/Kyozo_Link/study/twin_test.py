"""The twin test: the study's tasks run in the simulated Dobot (the digital twin, "ideal hardware"), outside the
watcher, unattended: the twin half of each of the study's three rounds, as an alternative to running it in the
watcher's twin (study/RUNBOOK_*.md). Each task's cubes are set out as its run's seeded arrangement says (the same as on
the Dobot), the prompt goes to the same Qwen model with the fixed seed, the app's own code does the task, and the
result is scored from the twin's exact positions by watcher.tasks -- the same rules the watcher uses on the real arm.

    python study/twin_test.py --version base --set train                 # practice: Practice_Session/practice_study_1
    python study/twin_test.py --version base --set train --real --round 1    # study 1's twin training (study_1)
    python study/twin_test.py --version v1 --set test --real --round 2       # study 2's twin test (1 run per task)
    python study/twin_test.py ... --only TR-01,TR-11                   # some tasks only

Everything is saved as it happens (watcher.results): a session folder with one folder per run (run.json, trace.json),
an index and a summary. Ollama must be running. Nothing in config.yaml or the calibration is changed.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(ROOT))
from harness import ROOT as _ROOT  # noqa: E402,F401  (sets up sys.path and the working folder, as the tests do)

import yaml  # noqa: E402

from app import robots  # noqa: E402
from app.hardware.gripper import GripperSpec  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from watcher import extract, results  # noqa: E402
from watcher.taxonomy import RunFacts, classify, count_refusals, motion_efficiency  # noqa: E402
from watcher.tasks import Cube, Task, TaskSet, difficulty, load_task_set, score  # noqa: E402

TRAIN_FILE = ROOT / "study" / "tasks" / "train.yaml"
CONTEXT_TOKENS = 8192            # as the app (MainWindow.MODEL_CONTEXT_TOKENS)
ANSWER_TIMEOUT_S = 300           # as the app (MainWindow: llm.timeout_s)
INFRA_RETRIES = 2                # as the watcher: an infrastructure failure is run again, at most this often
COLORS = {"red": [0.8, 0.1, 0.1, 1], "blue": [0.1, 0.2, 0.8, 1], "green": [0.1, 0.7, 0.2, 1]}


def scene_for(task: Task, tasks: TaskSet) -> dict:
    """The task's layout as a twin scene: its cubes (exact positions and angles), and the zones as named places."""
    size = tasks.cube_size_mm
    objects = [{"id": f"{c.color}_cube_{i}", "label": c.label, "color_rgba": COLORS[c.color], "size_mm": size,
                "position_mm": [c.x, c.y, size / 2], "yaw_deg": c.yaw} for i, c in enumerate(task.start)]
    places = {name.replace("_", " "): [z.cx, z.cy, 0.0] for name, z in tasks.zones.items()}
    return {"name": f"study_{task.id}", "objects": objects, "places": places}


class TwinRun:
    """The demo world, robot, camera and tools, as tests/prompt_bench.py's Bench sets them up, with the task's own
    scene and the study's zones as flat areas (the same sizes the real zones get from their saved place files)."""

    def __init__(self, task: Task, tasks: TaskSet):
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.llm.tools import ToolExecutor
        from app.twin.world import TwinWorld
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        profile = robots.active()
        self.world = TwinWorld()
        client = self.world.start()
        self.world.load_scenario_data(scene_for(task, tasks))
        # (a spot of the A4 sheet holds one cube: the planner's room for it, as the watcher saves it)
        from watcher.observe import spot_room_mm
        room = spot_room_mm(tasks.cube_size_mm)
        zones = {name.replace("_", " "): ((room, room, 0.0)
                                          if getattr(z, "spot", None) is not None else (z.width, z.depth, 0.0))
                 for name, z in tasks.zones.items()}
        areas = lambda: {**self.world.place_areas(), **zones}            # noqa: E731
        spec = GripperSpec.from_config({"gripper_type": "gripper"}, profile.gripper_defaults())
        self.robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                              max_reach_mm=profile.max_reach_mm, world=self.world, gripper=spec)
        self.robot.connect()
        camera = SimCamera(client)
        camera.outline_bodies = self.robot.body_ids
        camera.connect()
        look = Pose(*profile.demo_look_pose)
        self.robot.move_to(look)
        transform = camera.camera_to_robot_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: self.robot.arm_state()[0],
                                       self.world.places, areas)
        self.camera = camera
        # (the study's cubes: a cube measured near their size is that size, as live -- a tower's top read 28 mm)
        self.scene_builder = SceneBuilder(camera, detector, transform, known_sizes={"cube": tasks.cube_size_mm})
        self.executor = ToolExecutor(self.robot, self.scene_builder, look_pose=look,
                                     table_z_provider=lambda: 0.0, places_provider=self.world.places,
                                     place_areas_provider=areas, gripper=spec)
        # the sheet's spots are printed markings: places to put things, never obstacles
        spots = [name.replace("_", " ") for name, z in tasks.zones.items() if getattr(z, "spot", None) is not None]
        self.executor.markings_provider = lambda: spots

    def cubes(self) -> list[Cube]:
        """Where every cube is now, exactly."""
        from watcher.observe import exact_cubes
        return exact_cubes(self.world)

    def stop(self) -> None:
        self.world.stop()


def run_task(task: Task, tasks: TaskSet, model: str, config: dict) -> dict:
    """One run in the twin: the before-prompts, the prompt, then the score. Never raises: a run that couldn't run is
    an infrastructure failure."""
    from app.llm.agent import Agent
    from app.llm.ollama_client import OllamaClient
    started = time.monotonic()
    out: dict = {"task": task.id, "category": task.category, "level": task.level, "layout": task.layout,
                 "prompt": task.prompt,
                 "before": task.before, "start": [c.__dict__ for c in task.start], "cube_size_mm": tasks.cube_size_mm}
    twin = None
    facts = RunFacts()
    try:
        twin = TwinRun(task, tasks)
        events: list = []
        twin.robot.add_watcher(events.append)     # every move, as on the real arm
        client = OllamaClient(endpoint=config["llm"]["endpoint"], keep_alive="30m", num_ctx=CONTEXT_TOKENS,
                              timeout_s=ANSWER_TIMEOUT_S, seed=config["llm"].get("seed"))
        agent = Agent(client, twin.executor, model, max_tool_calls=config["llm"].get("max_tool_calls", 20),
                      temperature=config["llm"].get("temperature", 0.2))
        before_traces = []
        for earlier in task.before:
            done = agent.run(earlier)
            if getattr(done, "trace", None) is not None:     # (the model log has these first)
                before_traces.append(done.trace)
        events.clear()                            # (the prompt's own moves only)
        steps: list = []
        run = agent.run(task.prompt, on_step=steps.append)
        end = twin.cubes()
        result = score(task, end, tasks.zones, tasks.rule, tasks.cube_size_mm)
        facts.tool_results = [str(s.result) for s in steps]
        facts.tool_names = [s.tool_name for s in steps]
        facts.final_message = run.final_message
        facts.app_estimates = extract.app_estimates(run.trace)
        pick_rows = extract.picks(run.trace, task.start)
        failure = classify(task, result, facts, task.start, end, zones=tasks.zones)
        out.update(passed=result.passed, unassisted_pass=result.passed,     # (nobody can help in the twin)
                   failure=failure, score=result.as_dict(),
                   refusals=count_refusals(facts.tool_results),
                   motion=motion_efficiency([e for e in events if e["kind"] == "move"],
                                            round(time.monotonic() - started, 1)),
                   position_errors_mm=result.position_errors, angle_errors_deg=result.angle_errors,
                   end=[c.__dict__ for c in end], reply=run.final_message,
                   calls=[{"tool": s.tool_name, "args": s.arguments, "result": str(s.result)[:400]} for s in steps],
                   goal_check=((run.trace or {}).get("end") or {}).get("goal"), trace=run.trace,
                   before_traces=before_traces,
                   pick_rows=pick_rows, picks=len(pick_rows),
                   perception_offsets_mm=[r["perception_offset_mm"] for r in pick_rows
                                          if r["perception_offset_mm"] is not None],
                   arrival=extract.arrival(run.trace), plan=extract.plan(steps),
                   difficulty=difficulty(task, tasks.cube_size_mm))
    except Exception as exc:  # noqa: BLE001 - one run failing to run is a result, not the end of the session
        out.update(passed=False, failure="infrastructure", error=f"{type(exc).__name__}: {exc}",
                   traceback=traceback.format_exc())
    finally:
        if twin is not None:
            twin.stop()
    out["seconds"] = round(time.monotonic() - started, 1)
    out["time_split"] = extract.time_split(out.get("trace"), out["seconds"])
    return out


def summary_md(rows: list[dict], header: str) -> str:
    lines = [f"# {header}", "", "| Category | Passed | Runs |", "|---|---|---|"]
    for cat in sorted({r["category"] for r in rows}):
        mine = [r for r in rows if r["category"] == cat]
        lines.append(f"| {cat} | {sum(r['passed'] for r in mine)} | {len(mine)} |")
    lines.append(f"| **all** | **{sum(r['passed'] for r in rows)}** | **{len(rows)}** |")
    failures: dict[str, int] = {}
    for r in rows:
        if not r["passed"]:
            failures[r.get("failure") or "unclassified"] = failures.get(r.get("failure") or "unclassified", 0) + 1
    if failures:
        lines += ["", "Failures by type: " + ", ".join(f"{k} {v}" for k, v in sorted(failures.items()))]
    errs = [e for r in rows for e in r.get("position_errors_mm") or []]
    if errs:
        lines.append(f"Median position error: {sorted(errs)[len(errs) // 2]:.1f} mm over {len(errs)} targets")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--version", required=True, help="the version being tested: base, v1, v2, ... (study n: v(n-1))")
    parser.add_argument("--set", choices=["train", "test"], default="train")
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--cube-set", type=int, choices=[3, 6], default=3)
    parser.add_argument("--real", action="store_true", help="counts for the paper (else practice, safe to delete)")
    parser.add_argument("--round", type=int, choices=sorted(results.STUDIES), default=1)
    parser.add_argument("--only", default="", help="task ids, comma separated")
    parser.add_argument("--half-set", action="store_true", help="only the test set's half set (Normal mode)")
    parser.add_argument("--model", default=None, help="default: llm.model in config.yaml")
    args = parser.parse_args()
    if args.set == "test":
        # the app's own warnings (a refused move says where the cubes are) mustn't print the unseen test's details
        import logging
        logging.disable(logging.CRITICAL)

    config = yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
    from app.cube_size import cube_mm          # (the app's Settings > Cubes: the twin's cubes the same size)
    try:
        tasks = load_task_set(TRAIN_FILE if args.set == "train" else results.test_set_file(), args.cube_set,
                              cube_mm(config))
    except FileNotFoundError as exc:
        print(exc)
        return 1
    chosen = [t for t in tasks.tasks if (not args.only or t.id in args.only.split(","))
              and (not args.half_set or t.id in tasks.half_set)]
    model = args.model or config["llm"]["model"]
    robots.set_active("dobot_magician")
    from app.llm.ollama_client import OllamaClient
    ollama = OllamaClient(endpoint=config["llm"]["endpoint"], keep_alive="30m", num_ctx=CONTEXT_TOKENS)
    try:
        installed = {m.name: m for m in ollama.installed_models()}
    except Exception as exc:  # noqa: BLE001
        print(f"Ollama isn't reachable at {config['llm']['endpoint']} ({exc}). Start it and try again.")
        return 1
    if model not in installed:
        print(f"{model} isn't installed in Ollama.")
        return 1
    ollama.unload_others(model)
    print(f"Loading {model}... ({ollama.load(model):.0f} s)")

    set_name = "test" if args.set == "test" else "train"
    session = results.Session.start(
        args.real, set_name, "twin", args.round, args.version,
        {"model": model, "model_digest": _model_digest(config["llm"]["endpoint"], model),
         "temperature": config["llm"].get("temperature"), "seed": config["llm"].get("seed"),
         "cube_set": args.cube_set, "cube_size_mm": tasks.cube_size_mm, "task_file_sha256": tasks.sha256,
         "repeats": args.repeats,
         "tasks": [t.id for t in chosen], "git_commit": _git_commit()})
    print(f"{'REAL TEST' if args.real else 'PRACTICE'}: {len(chosen)} tasks x {args.repeats} -> {session.folder}")
    rows = []
    for repeat in range(1, args.repeats + 1):
        for task in chosen:
            # a task on the A4 sheet: this run's start arrangement, seeded as the watcher's (the same as on the Dobot)
            from watcher.arrange import arranged
            try:
                task = arranged(task, tasks, args.set, repeat)
            except ValueError:                        # (the reason names cubes and places: test details stay out
                print(f"{task.id}: no start arrangement suits it; skipped (check the task file with "
                      "study/check_tasks.py)", flush=True)          # of the console)
                continue
            for attempt in range(1 + INFRA_RETRIES):   # an infrastructure failure is run again (PREREG 5.1)
                row = run_task(task, tasks, model, config)
                row["repeat"] = repeat
                row["arrangement"] = task.arrangement
                again = row.get("failure") == "infrastructure" and attempt < INFRA_RETRIES
                row["repeated"] = again
                row["sitting"] = session.folder.name
                folder = session.run_folder(task.id, repeat)
                trace = row.pop("trace", None)
                before_traces = row.pop("before_traces", [])
                pick_rows = row.pop("pick_rows", None)
                if pick_rows:
                    import csv
                    import io
                    buf = io.StringIO()
                    writer = csv.writer(buf)
                    writer.writerow(list(pick_rows[0]))
                    writer.writerows([list(r.values()) for r in pick_rows])
                    results.write_text(folder / "picks.csv", buf.getvalue())
                results.write_json(folder / "run.json", row)
                if trace is not None:
                    results.write_json(folder / "trace.json", trace)
                from watcher import model_log           # everything the Model tab shows, in one file per run
                model_log.write_model_log(
                    folder, before_traces + ([trace] if trace is not None else []),
                    header=f"{task.id} · repeat {repeat} · twin script, {set_name}, round {args.round}, "
                           f"{'REAL TEST' if args.real else 'practice'}\n“{task.prompt}”",
                    steps=None if trace is not None else row.get("calls"))
                try:                                  # every move (distance, time, speed, joints) and gripper action
                    import csv
                    import io
                    from watcher import details
                    motion = details.motion_detail(before_traces + ([trace] if trace is not None else []))
                    for name, header, table in (("moves.csv", details.MOVE_COLUMNS, details.move_rows(motion)),
                                                ("gripper.csv", details.GRIPPER_COLUMNS, details.gripper_rows(motion))):
                        buf = io.StringIO()
                        writer = csv.writer(buf)
                        writer.writerow(header)
                        writer.writerows(table)
                        results.write_text(folder / name, buf.getvalue())
                except Exception as exc:  # noqa: BLE001
                    print(f"  (the moves couldn't be written: {exc})", flush=True)
                try:                                  # the run's report; saved under its tag (Run<repeat>), its own
                    from watcher import report        # .md and HTML page, and the kind's reports with it so far
                    report.write_run_report(folder, row, session.info)
                    tag = f"Run{repeat}" if not again else f"Run{repeat}_infra{attempt + 1}"
                    if session.taken(results.run_name(task.id, tag)):
                        tag = session.next_tag(task.id)
                    data = json.loads((folder / "run.json").read_text(encoding="utf-8"))
                    data.update(saved=True, tag=tag, saved_as=results.run_name(task.id, tag),
                                saved_at=time.strftime("%Y-%m-%d %H:%M:%S"))
                    results.write_json(folder / "run.json", data)
                    folder = session.save_run(folder, task.id, tag)
                    report.write_run_files(session.kind_folder, folder)
                    report.write_session_results(session.kind_folder)
                except Exception as exc:  # noqa: BLE001 - the run is saved; the reports are remade at the end
                    print(f"  (the reports couldn't be updated: {exc})", flush=True)
                session.record({"run": folder.name, "passed": row["passed"], "failure": row.get("failure"),
                                "repeated": again})
                if again:
                    print("  (infrastructure failure: run again)", flush=True)
                    continue
                rows.append(row)
                if set_name == "train":                   # (test-set details stay out of the console: saved only)
                    print(f"[{len(rows)}] {'PASS' if row['passed'] else 'FAIL'} {task.id} r{repeat} "
                          f"{row['seconds']:.0f}s {row.get('failure') or ''}", flush=True)
                else:
                    print(f"[{len(rows)}/{len(chosen) * args.repeats}] done", flush=True)
                break
    summary = summary_md(rows, f"Twin, {set_name} set, version {args.version}, "
                               f"{'REAL TEST' if args.real else 'practice'}")
    session.finish(summary)
    try:                                          # the kind's reports, once more with everything
        from watcher import report
        report.write_session_results(session.kind_folder)
    except Exception as exc:  # noqa: BLE001 - the runs are saved; the reports can be rebuilt from the watcher
        print(f"(The reports couldn't be written: {exc}. The watcher's 'Rebuild reports…' makes them.)")
    if set_name == "train":
        print("\n" + summary)
    print(f"Saved: {session.kind_folder}")
    return 0


def _model_digest(endpoint: str, model: str) -> str:
    """Ollama's digest of the installed model: proof the same weights ran in every session."""
    try:
        import requests
        for m in requests.get(f"{endpoint.rstrip('/')}/api/tags", timeout=10).json().get("models", []):
            if m.get("name") == model:
                return m.get("digest", "")
    except Exception:  # noqa: BLE001
        pass
    return ""


def _git_commit() -> str:
    try:
        import subprocess
        return subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True,
                              timeout=10).stdout.strip()
    except Exception:  # noqa: BLE001
        return ""


if __name__ == "__main__":
    sys.exit(main())

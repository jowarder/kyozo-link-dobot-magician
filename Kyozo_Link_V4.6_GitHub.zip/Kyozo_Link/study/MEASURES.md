# Measures: everything the study records, and where to find it

*Watcher Study, Kyozo Link V3.8, GECA 2027. One page for every measure, with its label. The rules themselves (pass rule, failure types, intervention, hypotheses) are in [PREREG.md](PREREG.md).*

**Where a run's records are:** in its kind's folder, `Kyozo_Link_Results\study_N\<Twin|Dobot>_<Training|Test>_Data\`
(practice: `Practice_Session\practice_study_N\practice_study_N_…\`):
- `User_Saved_<folder>\<task>_<tag>.md`: everything about the run in one file (and `HTML_version\<task>_<tag>.html`, the same as one web page with its pictures built in);
- `_raw_data\<task>_<tag>\`: the evidence -- `run.json` (everything below, by field name), `trace.json` (the model's full decision record), `model_log.txt/.html`, `run_report.txt`, `moves.csv`, `gripper.csv`, `alarms.csv`, `picks.csv`, `observer.json`, `start.png` / `end.png` / `end_marked.png` (+ depth).

**Who fills it:** *auto* means the watcher or twin script, as the run happens; *you* means the engineer; *Claude* means the update between studies; *analysis* means `study/analyze.py` after the fact.

---

## Main results (the hypotheses, PREREG §1 and §7)

| Label | Measure | Where | Who |
|---|---|---|---|
| **H1** | Unassisted success on the unseen test tasks on the Dobot, study 1 (base) vs study 3 (v2) (primary) | `run.json` → `unassisted_pass` | auto |
| **H2** | Position error (mm) and angle error (°) per target | `position_errors_mm`, `angle_errors_deg` | auto |
| **H3** | Interventions per run; controller alarms per 100 moves | `interventions`, `alarms`, `moves`; `alarms.csv` | auto |
| **H4** | Hardware gap = twin success − Dobot success | twin and Dobot `run.json` files | analysis |
| **H5** | Refused steps per run, by kind: wasted, guard, robot | `refusals` | auto |
| **H6** | Motion efficiency: moves, travel mm, wrist turning °, seconds per run | `motion` | auto |

Also, every run: `failure` (failure type, PREREG §5), `score` (each target's result, collateral and missing cubes), `observer` (your verdict).

## A · Diagnosis: so Claude finds the real cause

| Label | Measure | Where | Who | Used for |
|---|---|---|---|---|
| **A1** | **Per-pick record:** the app's estimate of the cube against the watcher's look (*perception offset*), grip and release angles, J4, spare room in the gripper, the joint nearest its limit, the outcome | `picks.csv`; `run.json` → `perception_offsets_mm`, `picks` | auto | telling perception errors from execution errors; the *perception* failure type |
| **A2** | **Arrival:** how far each move ended from its target (the controller's reading) | `run.json` → `arrival` | auto | moves that stopped short; slow drift |
| **A3** | **Time and runs since homing** | `run.json` → `since_homing` | auto (real Dobot) | failures that grow with time since homing (skipped steps) |
| **A4** | **Time split:** model thinking, camera looking, arm and tools, other | `run.json` → `time_split` | auto | where a run's time goes |
| **A5** | **Plan fingerprint:** `shape` (the tools in order), `full` (with arguments) | `run.json` → `plan` | auto | same plan with a different outcome means the machine; a different plan means the model |

## B · For the paper: novelty, cost, workload

| Label | Measure | Where | Who | Used for |
|---|---|---|---|---|
| **B1** | **Change ledger:** each AI change, with files, lines, what it does, strategy (Sense / Avoid / Recover / Correct / Slow), the **hardware limit** it compensates (camera_angle_noise, camera_position_noise, arm_repeatability, arm_reach_limits, gripper_slop, serial_link, table_slope, light, or none (a software fix)), the **log evidence** it cites, the failure it targets, your decision, its **measured effect** | `study/CHANGES_vN.csv` (template `CHANGES_TEMPLATE.csv`) | Claude; you (decision); analysis (effect) | *AI fix → evidence → measured result*; the list of compensation strategies |
| **B2** | **Claude's predictions:** expected test results, written **before** the version is tested | `study/NARRATION_vN.md` → `## Predictions` | Claude | predicted vs measured: how well the AI foresees its own fixes |
| **B3** | **Cost per round:** Claude tokens, money and minutes; your review hours; changes proposed, accepted and rejected; robot hours; lines added and removed | `study/COSTS.csv` | you (Claude usage, hours); analysis (robot hours, lines) | the cost side of "code instead of hardware"; break-even |
| **B4** | **Setup effort:** seconds and table checks until READY | `run.json` → `setup_effort` | auto | operator workload; the ghost outlines working |
| **B5** | **Task difficulty:** distance from the base, reach margin, turn asked, smallest gap, cubes acted on | `run.json` → `difficulty` | auto | the map of where the arm fails, by version |
| **B6** | **Observer confidence:** sure or unsure, with your verdict | `observer.json` → `confidence` | you (one tick) | the agreement analysis (you, Dr. Curry, the scorer) |
| **B7** | **The hardware, measured the same way at the start of each study:** Verify calibration (typical and worst), Pick test (if calibrated), the still cube's angle spread, the touches' slope, minutes the camera was on; unanswered moves and alarms per 100 moves, from the study's runs | `study/HARDWARE.csv` (template `HARDWARE_TEMPLATE.csv`) | you (first session of each study); analysis (per 100 moves) | that the hardware stayed the same, so an improvement is the software's; each hardware limit's size, next to the compensations that targeted it |

## Per kind of data and per study (automatic)

- `_sessions_log\<date>_<time>\session.json` (one per sitting): session kind (Task for Twin / Task for Dobot / Test Twin / Test Real Dobot), set, where, study, version, scoring (the twin's exact positions or the camera), git commit, Qwen model and digest, seed, temperature, calibration file and hash, task-file hash, the paper's pose, spots, table height, start and end (robot hours).
- `index.jsonl` (next to it): one line per run, and one per Save or Discard, hash-chained (tamper-evident); `SESSION_SUMMARY.md`.
- `run.json` → `arrangement` (the start and its seed), `saved`, `tag`, `sitting`; discarded runs: the index and `deletions_log.txt`.
- In the kind's folder, remade after every Save: `FULL_REPORT.md`, `FULL_REPORT.html`, `full_report.json`, `results.xlsx`, `results_*.csv` (runs, moves, gripper, picks, alarms, model turns).
- For the 20 tasks (and training), Claude's package in `For_Claude\study_N\` (`START_HERE.md`, `SUMMARY.md` opening with Twin vs Dobot, a folder per kind of data named as in the results — `20_Tasks_for_Twin\`, `20_Tasks_for_Dobot\` — each with its full report and runs, and from study 2 `PREVIOUS_SUMMARY.md`).

# Narration v2: the update after study 2 (V4.4, extending V4.3)

Claude (Opus 5.5), 2026-10-26/27. Input: `For_Claude\study_2` (SUMMARY.md, PREVIOUS_SUMMARY.md, START_HERE.md, the 20
twin runs and 29 Dobot runs with their traces, moves, picks and model logs), and Rafi's lab notes: the Dobot was
power-cycled during the study; 25 mm cubes were used; "at times, no cube was seen even though there was red, blue and
green cube"; the prompt text in the watcher was cut short; 20 or 25 mm cubes may be used, the size set beside the
prompt. Dr. Curry approved the watcher changes (section D, 2026-10-26). Nothing from a test folder was read.

## What the log showed

**The pairing.** Twin 19 of 20; Dobot 8 of 29 run (3 more skipped). By the pairing: 5 tasks fine (S-01 to S-05),
14 "hardware: compensate" (S-06 to S-19: twin passes, Dobot fails), 1 "software or plan" (S-20: both fail). 9 runs
catastrophic, all on the Dobot. Read run by run, the 14 "hardware" tasks are four faults, two of them a chain:

**Hardware problems (the Dobot and its camera).**
- **The controller refused a target its arm can't take, then everything after it.** `S-06_Run1`: the approach 50 mm
  above a cube at (145, -67), 160 mm from the base, needed the rear arm (J2) at -6.1 degrees; alarm 0x12, and every
  move after it refused, even to where the arm was, until the Dobot was switched off and on (`S-07_Run1` the same,
  target None). Fitted to 323 real moves, the controller's own arm is out = 135 sin J2 + 147 cos J3 + 59.7 and
  z = 135 cos J2 - 147 sin J3; J2 down to -1.9 worked, -6.1 did not.
- **Reconnected without Home.** `S-08_Run1`: after the power cycle and Reconnect, nothing was homed; the arm's own
  coordinates were some 64 degrees off, the model kept calling swap and pick, and the arm went where it wasn't sent:
  the cubes ended at (203, -401) and (284, -387), the red one off the table. `S-09_Run1`: the USB link lost
  (ClearCommError, access denied) mid-run. `S-10_Run1` to `S-12_Run1` were skipped: the table was empty.
- **Touching cubes read as one.** From `S-10_Run2` to `S-20` (10 runs) a green and a blue cube left touching were one
  31 x 54 mm "teal block" (green and blue's middle hue), with "a blue block" under it from the blue sides below its
  top: "there is no green cube" (`S-12_Run2`, `S-19_Run1`), "can't pick up the blue block: 31 mm across"
  (`S-10_Run2`, `S-16_Run1`, `S-20_Run1`), and every tower task (S-13 to S-18) failed without a move. This is Rafi's
  "no cube was seen even though there was red, blue and green". Reproduced in the twin: perfect and realistic camera
  alike.
- **Unsteady angle readings.** `S-06_Run2` (31 degrees over 8 pictures), `S-07_Run2` (20): picks refused, and three
  turns couldn't be checked afterwards. In the twin a cube touching another read 4 degrees for 38 (the merge above); a
  cube 2-6 mm from another reads a steady 33.5 for 38, in its flat top and its outline alike.
- **A cube lost in a carry.** `S-01_Run1`: checking the grip, the app carried the red cube to the spot the camera looks
  from, 300 mm round the base at 177 mm/s (J1 -92 degrees), and the cube ended at (188, -73), on the way. `S-03_Run2`:
  put down at the edge of reach (radius 290), it landed 16.5 mm off, turned 21 degrees.

**Software problems (the app and the model's plan).**
- **An id the camera had renumbered.** "Unknown object_id" six times with the cube in plain view (`S-06_Run2`,
  `S-08_Run2` twice, `S-09_Run2` twice, `S-11_Run2`): four inside a swap, which put a cube out of the way, picked the
  other (an unsteady reading made it look again, and every cube got a new id), then couldn't find its own cube.
- **S-20, both fail.** In the twin, move_object had already put the blue cube down 40 mm nearer (a pass by itself);
  the model then called place_at, was told "pick it up and do this step again", and carried it to a saved place.
- **The cube size.** The app takes a cube measured within 6 mm of the size set to be that size: a 20 mm cube with 25 set
  is called 25 mm and gripped and stacked as one. Nothing said so.
- **The watcher.** The session plan cut long prompts short with "..."; the cube size wasn't shown; after S-08's lost
  homing, Run by itself went on to the next tasks.

**What my last changes did** (PREVIOUS_SUMMARY.md, study 1 -> study 2). Twin 19 of 20 (round 1's chains: 20, 14,
20). The Dobot's S-01 to S-05 passed 8 of 10 with fewer, faster model turns (median model time 44 s a run over
both sides; study 1's summary 59 s). Two of round 1's changes met new faults: the "nothing held" hint (v1-11) is what sent S-20's cube away, and
the alarms per 100 moves rose from 0 to 0.3 (the two 0x12 above, a target round 1 didn't touch).

## What I changed, and why

Each change is a row in `study/CHANGES_v2.csv`, with its lines and evidence. In plan order A -> C -> D -> B, then
E: v2-12 to v2-15 came from this round's own twin runs (below).

| Id | Change | Strategy | Kind | Evidence |
|---|---|---|---|---|
| v2-01 | The Dobot refuses every move until Home after a connect (a power cycle) or a lost USB link; a controller alarm it can't clear holds it too. The prompt stops at the first step that meets it ("the arm needs a person: press Home") and the controller's state is logged | Sense / Avoid | hardware compensation (serial_link) | S-08_Run1, S-09_Run1 |
| v2-02 | Every target is checked against the controller's own arm (app/hardware/dobot_arm.py) before it is sent; picks and places near the base come down from lower (a few degrees spare if any height has them, else within what the controller takes) | Avoid | hardware compensation (arm_reach_limits) | S-06_Run1, S-07_Run1: alarm 0x12, J2 -6.1 |
| v2-03 | A flat top of two clear colours, each a good share of it and mostly in one piece, is two tops: touching cubes are two cubes | Sense | hardware compensation (camera_position_noise) | S-10_Run2 to S-20 (10 runs): "teal block" 31 x 54 mm |
| v2-04 | The cubes' measured size against the size set: a clear difference (within 2 mm of the other size, 3.5 from the set one) stops anything that grips a cube (a cube already held is still put down, not left in the gripper), and the app offers the other size; never changed by itself | Sense / Avoid | software fix | Rafi's lab notes (20 and 25 mm cubes) |
| v2-05 | A cube size list beside the prompt box, the same setting as Settings > Cubes, locked while a prompt runs | Other | software fix | Rafi's lab notes |
| v2-06 | Watcher: the plan's Prompt column wraps to its width (the whole prompt, full text on hover) | Other | software fix | Rafi's lab notes |
| v2-07 | Watcher: the cube size at the top (and what the cubes measure, if not that) | Other | software fix | Rafi's lab notes |
| v2-08 | Watcher: an arm that needs a person starts nothing; "Waiting for you"; Run by itself pauses; scoring unchanged | Avoid | hardware compensation (serial_link) | S-08_Run1 to S-12_Run1 |
| v2-09 | An id from an earlier look means the one cube of its colour seen now; a swap finds the cube it put down by colour and place, and says where both are if it stops | Recover | software fix | S-06_Run2, S-08_Run2, S-09_Run2, S-11_Run2 |
| v2-10 | After a whole move (move_object, swap), a put-down with nothing held is told the move is done, not to pick the cube up again; move_object says it put the cube down | Other | software fix | twin S-20_Run1 |
| v2-11 | Tests: unittest.main() moved to the end of six test files: the classes after it now run when a file is run by itself | Other | software fix | test_dobot_driver.py and five more |
| v2-12 | Twin: a grip that closed on nothing is looked at again and tried once more (as on the Dobot); a finger on the cube's edge is said so, not "26 mm across, the fingers open 27.5" | Recover | software fix | this round's E3 (realistic twin): S-01, S-03, S-04, S-06 |
| v2-13 | After a missed grip, the cube is looked for again by its colour near where it was, if its shape is named another way ("green cylinder", then "green cube") | Recover | software fix | this round's E3: S-03 |
| v2-14 | Before a pick's fresh pictures of a cube, the arm is taken out from between the camera and it | Avoid | software fix | this round's E3: S-07, the cube read 11 mm off with the gripper in the camera's way |
| v2-15 | swap names each cube with its id in its result | Other | software fix | this round's E3: S-09, the wrong cube turned after a swap |

No safety check was loosened. v2-02 adds a check (the driver refuses what the controller would) and keeps the
workspace limits, the safety floor, E-STOP and the speed limits as they were; its few degrees spare are a preference
the planner meets where it can, never below what the driver itself refuses. v2-04 adds a stop. v2-01 and v2-08 add a
stop. No robot tool was renamed or removed; Qwen's model, temperature and seed are unchanged.

## Results so far

Simple 20 in the twin, run by itself in the watcher with the real Qwen (config.yaml's model, temperature 0.2, seed
42), the results kept in a scratch folder (not Kyozo_Link_Results):

| Run | Code | Camera | Passed | Median time a task | Model calls | Refused steps |
|---|---|---|---|---|---|---|
| Study 2 (V4.3) | f07c20e | perfect | 19 of 20 (S-20 failed) | 44 s (both sides) | | |
| E2 | c8d9981 | perfect | **20 of 20**, all scored 100 | 49 s | 62 | 4 (S-14: 2, S-17: 2), each put right in the next call |
| E3a | c8d9981 | realistic, no cube calibration | 1 of 6, then stopped | | | five grips missed by 1.4-2.2 mm |
| E3b | 22e332c | realistic, no cube calibration | S-01 failed, then stopped | | | missed, tried again, missed: said so |
| E3c | 22e332c | realistic, calibrated in the twin | 7 of 10, then stopped | | | S-03, S-07, S-09: fixed in dcb9f9e |
| E3d | dcb9f9e | realistic, calibrated | 8 of 10, then stopped | | | S-07, S-10: a "blue cylinder" |
| E3e | dcb9f9e | realistic, calibrated, the lab's cubes_only | **20 of 20**, all scored 100 | 54 s | 60 | 2 (S-17), put right in the next call |
| E2 again | dcb9f9e | perfect | **20 of 20**, all scored 100 | 53 s | 62 | 4 (S-14: 2, S-17: 2), as in E2 |

S-20 now passes: move_object puts the cube down 40 mm nearer, its result says nothing is held, and the model stops
there (4 calls). S-14's refusals (E2): after take_apart, place_beside with nothing held was told to pick the blue cube
up first, which was right, since the task wanted it 45 mm to the green cube's left, not where take_apart put it down.
S-17's: build_tower was given a place the user hadn't asked for, and told to leave it out.

**The realistic camera, step by step.** It reads a cube's middle about 1.7 mm toward itself (idea 28), the same before
this round as after; the fingers have 1.25 mm a side on a 25 mm cube, so without a calibration nearly every grip missed (E3a, E3b),
and the model, told "the cube is 26 mm across the fingers, which open 27.5", said the gripper was too narrow (v2-12).
The lab always works calibrated, so the twin was given what a cube calibration measures (a cube looked at in 30 spots,
the quadratic correction fitted, in the scratch driver: E3c). That run found three faults of the app's own, all fixed
(v2-13 to v2-15): a missed grip's second look lost a cube read "green cylinder" then "green cube"; the gripper, just
after a put-down, stood on the camera's line to the next cube and its pick read that cube 11 mm off; after a swap the
model turned the wrong cube, the result giving no ids. The remaining misses were cubes read round ("blue cylinder"),
gripped as if they had no turn: the lab's config.yaml has cubes_only, which study/twin_test.py's scene builder doesn't
set (E3d); with it (E3e), 20 of 20.

All tests pass, module by module: 34 modules, 843 tests (after dcb9f9e). Two tests from before this round were
changed, not the checks they met: the live-mode session now presses Home after connecting (v2-01), and the Model tab's
tower stands where the Dobot can reach its fourth cube (v2-02: at (170, 0) it needed the rear arm 9 degrees past
upright); a stand-in in test_wrist got the new step that clears the camera's view.

## New ideas

In `study/IDEAS.md` (rows 18-29). Tried in this round: 18, 19, 20, 22, 23, 26, 27 (idea 17 from V4.3). Left for
later:
- **The realistic camera's pull toward itself** (idea 28): it reads a cube's middle about 1.7 mm toward the camera
  (the top's far edge, where the depth drops to the table, is lost), the same before this round as after. The fingers
  have 1.25 mm a side on a 25 mm cube, so the twin's realistic chain misses grips. On the Dobot the cube calibration
  takes up a steady offset like this (study 2: median 0.6 mm over 47 picks); correcting it in the app as well would
  count it twice there. The twin's realistic chain run after a cube calibration, as the lab does: see E3e above.
- **The twin runner without cubes_only** (idea 29): study/twin_test.py's scene builder has the cube size but not
  config.yaml's cubes_only, so in the realistic twin a cube read round for a moment stays a "cylinder" and is gripped
  as if it had no turn. The runner is frozen for the study: the engineer's call.
- **Same-colour touching cubes** (idea 21): split by shape, a 25 x 50 mm top being two 25 mm cubes. The study's cubes
  are all different colours, so not seen yet.
- **A neighbour's pull on a cube's turn** (idea 24): 4.5 degrees in the twin, steady, in the flat top as in the outline;
  within the fingers' ~6 degrees. The touching case, 34 degrees off, is fixed by v2-03.
- **Carrying a held cube slowly to the pick check's look spot** (idea 25): S-01_Run1's cube was lost on a 300 mm swing.
  Slower carries cost time on every pick: the engineer's call.

## What I expect the next study to show

- **No catastrophic chain from a lost homing.** A Dobot switched off and on mid-session is held until Home: the prompt
  stops at its first step ("the arm needs a person"), the watcher says "Waiting for you" and Run by itself waits. The
  tasks after it start from cubes where they were, not swept off the table.
- **No 0x12 from an approach near the base.** Targets the controller would refuse aren't sent, and picks near the
  base come down from lower. A controller alarm can still come from something else (a joint pushed against an
  object); then the arm is held until a person acts, with the controller's state logged.
- **Towers and their take-aparts work on the Dobot** as in the twin: two touching cubes of two colours are two cubes.
  This was most of study 2's Dobot failures (S-10 to S-20). The two cubes have to look like their colours: under a
  much warmer or dimmer light a top may stay one, and the size check then says it's too wide, as before.
- **Swaps don't lose their cube** to a renumbered id.
- **Still open:** a cube lost in a fast carry (idea 25), unsteady angles with a neighbour close by (idea 24: about 4.5
  degrees, within the fingers), and a cube put down at the edge of reach landing off target (S-03_Run2). These will
  account for most of the Dobot's remaining failures.
- **The cube size:** with 20 mm cubes on the table and 25 set, nothing that grips a cube runs until the size is set
  (the model tells the user so); with the size set right, nothing changes.

## Predictions

For the unseen test, on this version (V4.4 at this round's commits), against study 2's training numbers. Unassisted:
no person helping inside a run (a Home or Reconnect between runs, when the app asks for it, isn't help in a run).

| Measure | Study 2 (training) | Predicted (unseen test) |
|---|---|---|
| Twin, unassisted success | 19 of 20 (95%) | 90-100% |
| Dobot, unassisted success | 8 of 29 run (28%) | 55-75% |
| Dobot, catastrophic runs | 9 | 0-1 |
| Alarms per 100 moves (Dobot) | 0.3 | 0-0.15 |
| Wasted refusals per run (both sides) | 10 in 49 (0.20) | 0.05-0.12 |
| Median position error, passed runs | | twin 0-3 mm; Dobot 3-8 mm |
| Median angle error, turned cubes | | twin 0-3 degrees; Dobot 3-7 degrees |

By category, the twin and the Dobot together (as study 2's summary counts them, passed of run):

| Category | Study 2 | Predicted |
|---|---|---|
| move | 13 of 15 | 85-100% (little change: S-03_Run2's edge-of-reach put-down is still open) |
| swap | 5 of 14 | 65-85% (ids and the 0x12 approach fixed; unsteady angles remain on the Dobot) |
| tower | 8 of 16 | 75-95% (touching cubes split by colour) |
| drop | 1 of 4 | 60-90% (S-20's re-pick fixed; a drop's landing stays a matter of chance) |

In the twin alone, no category below 85%. If the Dobot's tower runs stay below 50%, the colour split doesn't hold under the
lab's lamp (look for "teal" in the scene logs), and that comes first in the next round.

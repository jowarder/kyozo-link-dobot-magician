# Group D (S-16 to S-20) on 2026-10-23: why every task was skipped

**In short:** none of the five tasks was tried, so none actually *failed*. The arm set the cubes out correctly (the
tower was right), but its last move left the gripper hovering over the tower it had just built. That blocked the
watcher's camera, which then saw only the red cube. Each task waited 20 s for the table to be READY, then was skipped
and logged. It was a bug in the watcher's set-out (not the robot, the model or the calibration). It is fixed in commit
`69df47c`.

## The session

| | |
|---|---|
| Session | `study_1\Dobot_Simple20_Data\_sessions_log\2026-10-23_124708` (Practice session was **off**: the real folder) |
| Started from | ▶ Run Group D: S-16, S-17, S-18, S-19, S-20, once each, by itself |
| Started / ended | 12:47:08 / 12:49:26 (2 min 18 s) |
| Runs done | **0** (no run folders in `_raw_data`, nothing scored) |

## What happened, step by step

| Time | What | Detail |
|---|---|---|
| 12:47:08 | Session started | Group D's start (as Simple 20 has it): the blue cube with the green one on it, on the robot's left; the red cube on its right |
| 12:47:08–12:47:46 | **Set-out** looked at the table | The app's camera saw the green cube at (230, 77), 18 mm high, and the blue one at (230, 77), under it: **the tower was already there**, left by group C's last task (S-15, green on blue). The red cube at (228, −68). |
| | Set-out took the green cube off and put it back on the blue one | `pick` green → "Picked up green cube"; `place_on` blue → "Placed green cube at (231, 79, 9) mm. The pile is now, bottom to top: blue cube, green cube". **The tower was right.** |
| 12:47:46 | Set-out finished ("done", 1 move: stacked) | **The arm stayed where it put the green cube down: over the tower.** |
| 12:48:06 | **S-16 skipped** | "This task starts from a tower: blue cube, then green cube on top. The camera doesn't see it like that." The camera saw: **red cube (228, −68) only** |
| 12:48:26 | **S-17 skipped** | "Put the blue cube and the green cube on the grey sheet." Seen: red cube only |
| 12:48:46 | **S-18 skipped** | "This task starts from a tower: green, then red, then blue on top." Seen: red cube only |
| 12:49:06 | **S-19 skipped** | "This task starts from a tower: green, then red on top." Seen: red cube only |
| 12:49:26 | **S-20 skipped**, session ended | "Put the blue cube and the green cube on the grey sheet." Seen: red cube only |

Each task waits up to 20 s for the camera to see the table READY for it, then is skipped (logged with why). The arm
never moved again after the set-out, so all five saw the same blocked view: 20 s apart, 5 skips.

## Why

1. **The gripper hid the tower from the camera.** After `place_on`, the arm lifts a little and stays over the cube it
   put down. The watcher's camera looks from above and to the side, so the gripper sat between the camera and the
   tower: neither the green cube on top nor the blue one under it could be seen. Only the red cube, on the other side
   of the sheet, was.
2. **Only group D's set-out ended that way.** The set-out looks at the table before each move it makes, and every
   look first moves the arm out of the camera's view. Groups A–C's set-outs end with such a look (it is how the set-out
   checks that every cube is on its spot), so the arm was out of the way when their first task started. Group D's
   set-out ends with stacking the tower, with no look after it.
3. **One skip led to the next.** A task that is skipped leaves the cubes where they are, and these five are a chain:
   S-17 expects the cubes as S-16 leaves them, and so on. Here it made no difference (the view was blocked for all of
   them), but it is why one start that can't be seen costs the whole group.

The robot, the model (Qwen), the calibration and the scoring were not involved: no prompt was sent to the model and the
arm did nothing after the set-out.

## The fix (commit `69df47c`)

When the set-out has built a tower, it now ends with one more look at the table. That takes the arm out of the
camera's way (and confirms the tower is there) before the first task's table check. The twin test for group D's
set-out checks that the last two steps are "put on the tower", then "look".

## What to do

1. Restart Kyozo Link (to load the fix), then Home the arm (Manual tab: Clear Alarms, Home).
2. Put the cubes anywhere on the grey sheet (or leave green on blue from group C).
3. Turn **Practice session on** for trial runs: this session went to the real `study_1` folder. It has no runs in it,
   only its log of the five skips.
4. Press **▶ Run Group D**.

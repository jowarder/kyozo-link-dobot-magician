# Twin, all 20 tasks on 2026-10-23: why S-06 to S-20 were skipped

**In short:** in S-05 the model (Qwen) mixed up the two directions in the prompt. It tried to move the red cube
*further* (asked: nearer), which the app refused as out of reach, and moved the blue cube *nearer* (asked: further),
to x = 150 mm. That put the blue cube **outside the working area** (it starts at x = 170 mm) and nothing moved it back.
Every later task checks first that the cubes are where it can start from. The blue cube never was, so each waited 20 s
and was skipped. S-01 to S-04 passed; S-05 failed; S-06 to S-20 (15 tasks) were skipped.

## The session

| | |
|---|---|
| Session | `study_1\Twin_Simple20_Data\_sessions_log\2026-10-23_154754` (Practice session was **off**: the real folder) |
| Started from | ▶ Run all 20, in the twin (Demo mode), by itself |
| Started / ended | 15:47:54 / 15:57:48 (10 min) |
| Runs done | 5 (S-01 to S-05), all saved; 15 skipped |

## Each task

| Task | Result | What happened |
|---|---|---|
| S-01 | **Pass, 100** | Red cube 40 mm further from the robot |
| S-02 | **Pass, 100** | Blue cube 40 mm nearer, to (190, −70). The model first said "forward"; the app sent it back ("the user asked to move it back") and it then did it right |
| S-03 | **Pass, 100** | Green cube 50 mm further |
| S-04 | **Pass, 100** | Green cube 50 mm nearer. Again one wrong direction caught by the app and put right |
| S-05 | **Fail, 0** | *"Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot."* The model moved the red cube **forward** (should be back): refused, out of reach at (310, 70). It moved the blue cube **back** (should be forward): to **(150, −70)**. It then replied that it had moved the blue cube "further", which wasn't true |
| S-06 to S-20 | **Skipped** | The table check each time: *"Move the blue cube further from the robot."* The camera saw red (270, 70), green (230, 0) and **blue (150, −70)**: outside the area (x 170–290 mm). For S-12, 14, 16, 18 and 19 the message was about the tower they start from instead, since that is checked first. Same cause. |

## Why

1. **The model swapped the directions in a two-cube prompt.** S-05 asks for two moves in opposite directions. The app
   caught wrong directions in S-02 and S-04 (one cube, one direction). With two cubes it checks only that the prompt
   asks for both directions, not which cube goes which way, so the swap got through.
2. **The wrong move put the blue cube out of the area.** At x = 150 mm it's below the area's edge (170 mm) and close to
   the arm's minimum reach (160 mm).
3. **The tasks are a chain, and the twin sets the cubes out only once.** Each task starts where the one before left
   the cubes. The twin (like the Dobot's set-out) puts them in place only at the start of a session, so after S-05
   nothing moved the blue cube back. Each task's table check found it out of the area, waited 20 s and skipped. In
   a "Run all 20" session, one task that leaves a cube out of place costs every task after it.

The scoring, the calibration and the twin itself were not at fault: S-01 to S-04 passed with 0.1 mm errors.

## What to do

- **Run the groups one at a time** (▶ Run Group A, B, C, D). Each group's session sets the cubes out where that group
  starts, so a failure costs at most the rest of its own group, not all 20.
- **Turn Practice session on** for trial runs: this session went to the real `study_1` folder.
- Two possible improvements:
  1. **Set the cubes out again when a task can't start**, instead of skipping it: put them where that task would have
     started had the tasks before it gone as asked (the twin directly; the Dobot with its set-out). The failed task
     still counts as failed; the next one gets a fair start.
  2. **Check each cube's direction in a two-cube prompt** ("the red one nearer, the blue one further"), so the app
     sends a swapped direction back to the model, as it already does for one cube.

"""Study 1's saved runs scored again with V4.2's rules, next to the original reports (never over them).

V4.2 changed how a chained set's run is judged (watcher/tasks.py, taxonomy.py): an outcome beside the strict pass
(PASS / SOME PARTS / FAIL), a CATASTROPHIC flag, a cube in the task's way allowed to be moved out of it, and the first
wrong step deciding the failure type (a cube sent the wrong way is "plan"). So that study 1 (run under V4.1's rules)
and study 2 compare like with like, this reads each saved run's own record -- where the camera saw the cubes at the start
and at the end, the steps the model took -- and applies the new rules to it. It writes, in each data folder:

    RESCORED_V4.2.md     the runs side by side: the original result and the V4.2 one, and what changed
    rescored_v4.2.json   the same as data

Nothing else is touched: the runs, FULL_REPORT and the rest stay exactly as saved. The tasks skipped before V4.2 never
ran, so there is nothing to rescore for them (they would have run under V4.2's rules: no READY wait). Never for the
unseen test's folders.

    python study/rescore_v42.py <data folder> [<data folder> ...]
        e.g. ..\\Kyozo_Link_Results\\study_1\\20_Tasks_for_Dobot
"""
from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from watcher import extract, report, results  # noqa: E402
from watcher.arrange import blocking_cubes  # noqa: E402
from watcher.taxonomy import RunFacts, classify, object_labels_from  # noqa: E402
from watcher.tasks import Cube, load_task_set, outcome, score  # noqa: E402

SIMPLE = ROOT / "study" / "tasks" / "simple.yaml"
MD, JSON = "RESCORED_V4.2.md", "rescored_v4.2.json"


def _cubes(rows) -> list[Cube]:
    return [Cube(c["label"], float(c["x"]), float(c["y"]), float(c.get("yaw", 0.0)), int(c.get("level", 1)))
            for c in rows or []]


def rescore_run(run: dict, folder: Path, tasks) -> dict:
    """One saved run under V4.2's rules: {"outcome", "failure", "catastrophic", "prepared", "passed", "score_100"}."""
    task = tasks.task(run["task"])
    start, end = _cubes(run.get("start_seen")), _cubes(run.get("end_seen"))
    if not start:                                  # (a twin run's start: its task's own layout, as it was scored)
        start = list(task.start)
    from watcher.arrange import infer_hidden
    from watcher.tasks import task_towers, with_hidden
    end = with_hidden(infer_hidden(end, {c.label: c for c in start}, tasks.cube_size_mm)[0], task_towers(task),
                      tasks.cube_size_mm)
    may_move = blocking_cubes(task, tasks, start)
    result = score(task, end, tasks.zones, tasks.rule, tasks.cube_size_mm, start=start, may_move=may_move,
                   area=tasks.area)
    at_start = score(task, start, tasks.zones, tasks.rule, tasks.cube_size_mm, start=start, may_move=may_move,
                     area=tasks.area)
    calls = run.get("calls") or []
    trace = report._read_json(folder / "trace.json")
    facts = RunFacts(infrastructure_error=run.get("error") if run.get("failure") == "infrastructure" else None,
                     tool_results=[str(c.get("result", "")) for c in calls], tool_names=[c.get("tool") for c in calls],
                     tool_args=[c.get("args") or {} for c in calls],
                     alarms=[int(code, 16) for a in run.get("alarms") or [] for code in a.get("codes", [])],
                     final_message=run.get("reply") or "",
                     app_estimates=extract.app_estimates(trace) if isinstance(trace, dict) else {},
                     object_labels=object_labels_from([json.dumps(trace, default=str)] +
                                                      [str(c.get("result", "")) for c in calls]))
    failure = classify(task, result, facts, start, end, seen_start=start, zones=tasks.zones, may_move=may_move,
                       first_step=True)
    if run.get("timed_out") and not result.passed:
        failure = "timeout"
    catastrophic = list(result.catastrophic)
    at_end = run.get("robot_at_end") or {}
    if run.get("park_error"):
        catastrophic.append(f"the arm couldn't park: {run['park_error']}")
    if at_end.get("holding"):
        catastrophic.append(f"the arm still holds the {at_end['holding']}")
    from watcher.tasks import partial_credit
    from watcher.tasks import moved_cubes
    return {"outcome": outcome(result, at_start, moved_cubes(start, end)), "passed": result.passed, "failure": failure,
            "catastrophic": catastrophic, "prepared": result.prepared, "may_move": may_move,
            "score_100": partial_credit(result, tasks.rule)["score"]}


def rescore(kind: Path, tasks=None) -> Path:
    """Writes RESCORED_V4.2.md and rescored_v4.2.json in a data folder; returns the .md's path."""
    kind = Path(kind).resolve()
    if results.is_test_path(kind):
        raise ValueError(f"refused: {kind} is the unseen test's (never rescored here)")
    tasks = tasks or load_task_set(SIMPLE, 3)
    rows = []
    for folder in report._run_folders(kind):
        run = report._read_json(folder / "run.json", {}) or {}
        if run.get("skipped") or "passed" not in run or run.get("task") not in {t.id for t in tasks.tasks}:
            continue
        new = rescore_run(run, folder, tasks)
        old = {"result": "PASS" if run.get("passed") else "FAIL", "failure": run.get("failure"),
               "score_100": (run.get("credit") or {}).get("score")}
        changed = [what for what, a, b in (("result", old["result"], new["outcome"]),
                                           ("failure type", old["failure"], new["failure"]),
                                           ("score", old["score_100"], new["score_100"])) if a != b]
        if new["catastrophic"]:
            changed.append("catastrophic")
        rows.append({"run": folder.name, "task": run.get("task"), "original": old, "v4_2": new, "changed": changed})
    data = {"made": datetime.now().isoformat(timespec="seconds"), "folder": kind.name, "rules": "V4.2", "runs": rows}
    results.write_json(kind / JSON, data)
    md = [f"# {kind.name}: the saved runs scored again with V4.2's rules", "",
          f"*Made {data['made']} by study/rescore_v42.py. The runs and the original reports are unchanged; this sits "
          "beside them so study 1 (V4.1's rules) and later studies compare like with like. The same as data: "
          f"`{JSON}`.*", "",
          "V4.2's rules: an outcome beside the strict pass (PASS = the strict pass, unchanged; SOME PARTS = a part met "
          "that wasn't met at the start; FAIL), a CATASTROPHIC flag (a cube knocked off or past the tray's edge, "
          "another cube moved more than 30 mm, a tower brought down, the arm left unsafe), a cube in the task's way "
          "allowed to be moved out of it, and the first wrong step deciding the failure type.", ""]
    counts = {w: sum(r["v4_2"]["outcome"] == w for r in rows) for w in ("PASS", "SOME PARTS", "FAIL")}
    md += [f"Runs: {len(rows)} · " + ", ".join(f"{w} {n}" for w, n in counts.items())
           + f" · catastrophic {sum(bool(r['v4_2']['catastrophic']) for r in rows)} · changed by the new rules: "
           f"{sum(bool(r['changed']) for r in rows)}", ""]
    md += report.md_table(
        ["Run", "Original", "Original failure", "Original score", "V4.2 outcome", "V4.2 failure", "V4.2 score",
         "Catastrophic", "Changed"],
        [[r["run"], r["original"]["result"], r["original"]["failure"], r["original"]["score_100"], r["v4_2"]["outcome"],
          r["v4_2"]["failure"], r["v4_2"]["score_100"], "; ".join(r["v4_2"]["catastrophic"]) or "-",
          ", ".join(r["changed"]) or "-"] for r in rows])
    md += ["", "Tasks skipped before V4.2 never ran, so they aren't here: under V4.2's rules they would have run from "
               "the table as it was."]
    results.write_text(kind / MD, "\n".join(md) + "\n")
    return kind / MD


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    tasks = load_task_set(SIMPLE, 3)
    for arg in argv:
        print(rescore(Path(arg), tasks))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

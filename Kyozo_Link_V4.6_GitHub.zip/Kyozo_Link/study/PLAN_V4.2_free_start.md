# Plan: V4.2 iteration 1 -- the table as it is (agreed with Rafi, 2026-10-23/24)

Dr. Curry gave Rafi freedom to change the experiment. This replaces the earlier drafts of this file (outlines, hand
scattering): Rafi chose the hands-off chain, with the app doing whatever the task needs from whatever is there.

## Decisions

- **1 run per task** (unchanged).
- **Nothing is sorted.** No set-out by the arm. On the Dobot the cubes are put down anywhere once; the twin starts from
  the set's layout once. Every task -- Dobot and twin, Simple 20 and the unseen test -- starts from the table as the task
  before left it.
- **Before each task the watcher looks** (the arm parked and checked; 3 pictures). A cube missing -> the arm to a second
  position, 3 more pictures. **No pause**: the task starts with the cubes there; parts needing a missing cube are
  recorded as impossible. A task none of whose cubes can be seen is skipped. **No cube at all for 3 tasks in a row ends
  the session.** A camera failure is infrastructure (not the app's fault) and doesn't count towards the 3.
- **Towers anywhere** are understood (the cube under a tower isn't missing). The app is to take a tower down when a task
  needs a cube in it (Part 2).
- **Outcomes**: PASS (the strict pass, unchanged) / SOME PARTS / FAIL / SKIPPED, a **CATASTROPHIC** flag beside it.
  **Allowed preparation**: a cube only in the task's way may move, ending on the table, unstacked, inside the tray.
  Every run records its **start condition**.
- **Time**: 10 minutes a task; one Qwen answer 400 s.
- New runs after the app changes go to **study 2** (study 1 = the baseline, kept as it is; rescored with the new rules
  beside its originals).

## Part 1 -- the watcher (built 2026-10-24: commits 0e68bdc, 40737df and the docs)

| | Before (V4.1) | Now |
|---|---|---|
| Session start | The arm sorts the cubes (set-out) | Nothing sorted |
| Each task's start | Must match the chain's layout, else skipped after 20 s | The table as it is; never skipped for the layout |
| A cube not seen | "Not READY", skipped | Arm to a second position, look again; then start without it, its parts impossible |
| Nothing seen | -- | Skipped; 3 tasks in a row end the session |
| Towers in the scene | Only as a task's named start | Understood anywhere (hidden cubes from where they were last seen) |
| Unnamed cubes moved | Always collateral | Allowed if they were in the way and end safely |
| Outcome | PASS / FAIL + score | PASS / SOME PARTS / FAIL / SKIPPED + CATASTROPHIC flag + start condition |
| Failure type | The fixed order (S-05 "limit_alarm") | The first wrong step decides (S-05 "plan"); "preparation" added |
| Time | 5 min a task, 300 s an answer | 10 min a task, 400 s an answer |
| Study 1 | -- | Rescored beside its originals (study/rescore_v42.py) |

Turns were already scored from all 5 end pictures (each cube's median angle) -- nothing to change.

Then: a second, independent review of Part 1; its confirmed bugs fixed; a full twin chain of all 20 (needs Ollama).

## Part 2 -- the app (built 2026-10-24: efa6952 .. 5849943; the twin chain 15 of 20, see CHANGELOG)

1. **Turns**: read the cube's angle from several pictures, turn, look, correct once -- inside one tool call (Dobot B
   group: 4 of 5 failed on turns; positions were within 1-8 mm).
2. **Multi-part prompts**: each cube's own direction and distance checked (S-05, twin and Dobot).
3. **Cube size**: the known 25 mm for grip planning (S-09's "36 mm across").
4. **Towers**: `pick` clears two levels, so the bottom of a three-tower can be reached.
5. **Finishing**: a goal check at the end, one correction.
6. **Qwen's instructions**: do as much as you can safely -- re-look after a failed grip or move, never act on a cube
   whose place is unknown, stop on an alarm or E-STOP, say what was and wasn't done.

Then the twin again, a Practice run of all 20 on the Dobot (group D has never run there), then study 2 and the unseen
test.

## Next (from the last twin chain)

- S-16: place_beside's gap measured from the blue cube's width as read: 10.6 mm off (score 97).
- S-17: Qwen added where="near_base" to build_tower though the request didn't say where: the tower moved.
- S-18 to S-20: the top of a tower of three near the arm's base (x = 170) still missed by the twin's fingers.
- Then a Practice run of all 20 on the Dobot (the arm's park check, the second position, missed grips, turns).

## Still to settle

- PREREG's wording (the set-out, the READY check, the failure order) -- with Dr. Curry.
- The second park position is the first one mirrored (y -> -y): check on the Dobot that it is out of the camera's way.

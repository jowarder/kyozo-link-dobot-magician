# Narration v1: the update after study 1 (V4.3, round 1)

Claude (Opus 5.5), 2026-10-25. Input: `For_Claude\study_1\study_1.zip` (the version that ran: base, V4.1), the two
skipped-runs notes (`study/reports/study_1/2026-10-23_group_D_S16-S20_skipped.md`,
`2026-10-23_twin_all20_S06-S20_skipped.md`), and Claude's own hands-off twin chains of the 20 tasks with the real
Qwen (V4.2 as the baseline, then V4.3). Nothing from a test folder was read. The goals, from the engineer: complete
every task first, then cut the latency; and let a different LLM be picked on the laptop, with Qwen still the default.

## What the log showed

**The pairing.** Study 1 has 18 Dobot runs (13 passed, 2 partial, 3 failed) but only 5 twin runs: the twin's S-06 to
S-20 and the Dobot's S-16 to S-20 were skipped (the skipped notes: the twin's chain stopped after S-05's failure left
the cubes where nothing could start; the Dobot's group D sitting saw only the red cube). So the pairing has one task
with both sides: **S-05, both fail -> software or plan.** The Dobot's own failures (S-05 to S-09: a direction the
wrong way, unsteady angle readings, a cube turned too far, a 36 mm misread) were already fixed in V4.2 (frozen
2026-10-25). V4.2's twin chain ran 20 of 20 once (twin run 10), and 18 of 20 in the baseline chain I ran for this
round (the same code; Qwen's answers vary with what each run starts from).

**Hardware problems (the Dobot).**
- **The serial link, before every move.** 223 move-to-move gaps in the 18 Dobot runs, median 0.69 s (0.44-1.15 s),
  157 s in all; S-10_Run1 alone 27.5 s, S-07_Run1 23.5 s (from each run's `trace.json`, the recorded moves' start
  times and durations). The cause is in the driver: each move asked the Dobot 8 status questions (the move record's
  pose and joints before and after, the leftover-alarm check before, the arrival check after). Each costs about
  0.13 s on the link (its 0.1 s pause before every message).
- **The wrist's backlash take-up costs a move.** Each pick and place turned the wrist past its angle and back at the
  same spot (`20_Tasks_for_Dobot/runs/S-11_Run1/moves.csv`, moves 3 and 9: r -13.9 then -6.0, 1.3 s each plus a gap).
- **No controller alarms**: 0 in 325 moves; no interventions; every move ended on its target (arrival 0.0 mm).

**Software problems (the app and the model's plan).**
- **Most of the time is the model's.** A Dobot run took 128 s on average, 69 s of it Qwen deciding (1249 s over 18
  runs) and 32 s moving. Every run began with a model turn that only called list_objects (156 s in all, median 8.6 s)
  and ended with a turn that only wrote a summary (368 s in all, median 14.9 s; `S-08_Run1` 91.8 s, `S-05_Run1` 28.7 s).
- **Each step took its own turn**, about 6 s plus 0.27 s per written token on this laptop: pick, then place_on, in two
  turns (S-11 to S-15).
- **Refusals the model then got stuck on** (the V4.2 twin chain, 2026-10-25): S-17 gave up after build_tower was
  refused for a place it didn't need (it was told what was wrong, not what to do); S-18 sent one refused place_beside
  five times (236 s); "nearer the robot" was sent as direction forward (S-02, S-05) or left (S-04), one refusal and a
  turn (18-24 s) each, in V4.3's first chain too.
- **An answer that ran on**: in V4.3's first chain S-14 wrote 512 tokens of text after a refused place_beside (it was
  holding nothing after take_apart), 157 s, before it picked the cube.

## What I changed, and why

Each change is a row in `study/CHANGES_v1.csv`, with its lines and evidence.

| Id | Change | Strategy | Kind | Evidence |
|---|---|---|---|---|
| v1-01 | The app looks at the table (list_objects) before the model's first answer and gives it as the model's own call and result | Other | software fix | every Dobot run's first turn: 156 s over 18 runs |
| v1-02 | The model may send all the steps it knows in one answer; a failed step stops the rest of that answer (NOT RUN, not a refusal) | Other | software fix | S-11..S-15: pick and place in separate turns |
| v1-03 | A `done()` tool: the app checks the goal (nothing held, the goal check) and writes the reply from the steps' results; "done()" written as text counts the same | Other | software fix | the closing turns: 368 s over 18 runs, S-08_Run1 91.8 s |
| v1-04 | The wrist's approach from one side folded into the travel: it ends short of the angle on the same side, and the last move turns the rest (the same backlash take-up, one move fewer per pick and place) | Avoid | hardware compensation (gripper_slop) | S-11_Run1 moves 3 and 9 |
| v1-05 | The Dobot driver: what a move's arrival check read (no alarm, arrived) stands for 2 s while nothing moves, clears or stops the arm; the next move's leftover-alarm check and the move record use it instead of 6 more serial requests. Every move is still checked after it ends | Other | hardware compensation (serial_link) | 223 gaps, median 0.69 s, 157 s |
| v1-06 | Any installed model that can call tools is in the Model list, with notes (laptop size, "not tested"); a pick lasts for the sitting; config.yaml's Qwen stays the default | Other | software fix | the engineer's request |
| v1-07 | A build_tower refused for a place it doesn't need says the exact call, bottom to top | Other | software fix | V4.2 twin chain S-17 |
| v1-08 | A refused step sent again exactly is told not to send it again (and what to do); "by the tower" with no tower says so | Other | software fix | V4.2 twin chain S-18 (236 s) |
| v1-09 | "nearer" and "farther" are directions; move_object's description says "40 mm nearer the robot" = back | Other | software fix | V4.3 chain 1 S-02, S-04, S-05 |
| v1-10 | One answer at most 256 tokens (was 512; the longest real one was 129); cut off, it is told to answer with tool calls only | Other | software fix | V4.3 chain 1 S-14, 157 s |
| v1-11 | A put-down with nothing held names the calls: pick(object_id=...) of the object last moved, then the step again | Other | software fix | V4.3 chain 1 S-14 |
| v1-12 | place_beside / place_on naming the held object itself as where it goes is refused, with the others' ids | Other | software fix | V4.3 chain 2 S-14 (and the five failures after it) |

No safety check was loosened. v1-05 skips no check: the arrival check (alarms and position) still runs after every
move, and a new alarm since the last move is caught by the next move's own arrival check (tested). Its reading is
used only while nothing has been sent that moves, clears or stops the arm, and never after an E-STOP.

## Results so far (twin, real Qwen, all 20 hands-off)

| Chain | Passed | Model turns / run | Model s / run | Tokens written / run | Refused steps | Run s / run |
|---|---|---|---|---|---|---|
| V4.2 (baseline, 2026-10-25) | 18 of 20 (S-17, S-18 failed) | 4.20 | 73.3 | 153 | 8 | 78.0 |
| V4.3 chain 1 (v1-01 to v1-08) | **20 of 20** | 3.35 | 59.0 | 105 | 5 | 63.5 |
| V4.3 chain 2 (v1-01 to v1-11) | 14 of 20 (S-14, S-16..S-20 failed) | 3.15 | 63.6 | 140 | 10 | 71.4 |
| V4.3 chain 2, S-01..S-13 only | 13 of 13 | 2.69 | 32.5 | 61 | 0 | 43.0 |
| V4.3 chain 3 (all of round 1, v1-01 to v1-12) | **20 of 20** | 3.25 | 57.9* | 80 | 6 | 62.9* |

\* Chain 3 ran beside the slow test modules, which slowed Qwen by about 70% (S-01: 33.8 s against chain 2's 19.8 s,
with the same tokens read and written; S-01 to S-13 read and wrote exactly what they did in chain 2, so the model
decided the same). Its times are not a speed measure; chain 2's S-01..S-13 are.

**Chain 2's failures were one fault and what it left.** In S-14 Qwen called place_beside naming the cube it held
as the cube to put it beside, and the app did it: the blue cube went "to the left of the blue cube", 56 mm from
where it was asked for. Every task after that started from a table the chain doesn't expect: the next tower stood at
(190, 110), where the green cube (25 mm, the fingers open 27.5 mm) was gripped 3 degrees off and 0.7 mm aside and
the twin's fingers closed on its edge (S-16, S-17, S-18, S-20), and S-19 started holding the wrong cubes in place.
v1-12 refuses the held object as where it goes, and chain 3 passed all 20 with it (S-14: the refusal, then
place_beside the green cube); a second grip try after "closed on nothing" is idea 17, for round 2. Up to S-13, chain 2 was the fastest yet: 32.5 s of model time a run (chain 1: 46.8 s for the same 13; V4.2 60.9 s),
no refusals (the "nearer" ones gone: S-02 and S-04 in 19 s, from 47-48 s).

Model turns leave out the app's own look (the watcher counts it as a turn of 0 s and 0 tokens). Chain 1's median run
was 50 s (V4.2's 70 s); S-14's 252 s is the run-on answer that v1-10 and v1-11 address.

The twin does not show v1-04's or v1-05's savings (its arm has no serial link, and it moves at 3000 mm/s). The Dobot's
are measured on its next study.

## New ideas

In `study/IDEAS.md` (rows 1-17). Tried in this round: 1-7, 12-14 and 16. Left for later:
- **A rule-based fast path** for plain requests ("move the red cube 40 mm further"): the app plans without the
  model. It would cut most of the latency, but the study measures the model's planning: Dr. Curry's call.
- **Learning the Dobot wrist's turn error** per direction from each checked turn (anticlockwise turns went 25-33
  degrees too far in study 1) and asking for the corrected angle the first time.
- **A shorter list_objects text** (about 10% of what each turn reads): it changes what the model sees, so measured on
  its own.
- **Re-setting the cubes when a chained task can't start**, instead of skipping it: the watcher's (frozen), proposed
  to the engineer.
- **A second grip try after "closed on nothing"** (idea 17): the app looks again and grips once more itself.
- **Another laptop model** (qwen2.5:3b, llama3.2:3b) beside Qwen in the Model list: needs a download (the engineer's
  go-ahead) and a chain of its own before it is compared.

## What I expect the next study to show

The same or better success (round 1 changed no position or angle), with fewer refusals and shorter runs: on the Dobot
mostly from the model's turns and the serial link, in the twin from the model's turns only. The numbers:

## Predictions

Committed before V4.3 is tested on the unseen tasks.

- **Unassisted success, twin:** 90-100% (V4.3's training chains 20, 14 and 20 of 20, the 14 one fault fixed; V4.2's
  18-20 of 20).
- **Unassisted success, Dobot:** 80-95% (study 1: 13 of 18; its failures were fixed in V4.2 and the twin now passes
  what they were).
- **Alarms per 100 moves (Dobot):** 0-1 (study 1: 0 in 325).
- **Wasted refusals:** fewer than 0.3 per run (V4.3 chain 1: 5 refusals over 20 runs, 0.25; v1-09 to v1-11 target
  four of those five).
- **Median position error:** unchanged, within 1-3 mm of study 1 (nothing in this round changes where a cube goes);
  **median angle error:** unchanged.
- **Latency (Dobot):** the mean run 128 s in study 1 -> 85-105 s: the model's time about 69 s -> 45-55 s (one look turn
  and the summary turn fewer), the gaps between moves about 8.7 s -> 2-3 s a run (v1-05), and one move fewer per pick
  and per place (v1-04, about 2 s each).
- **Latency (twin):** model time per run 59 s (chain 1) -> 35-50 s (chain 2's S-01..S-13: 32.5 s; the tower tasks
  take longer).

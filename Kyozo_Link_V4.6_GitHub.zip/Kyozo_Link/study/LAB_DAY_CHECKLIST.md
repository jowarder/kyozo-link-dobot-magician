# Lab-day checklist (V4.0, no printed paper)

Print this page or keep it open beside the app.

## A. Once, before the study

1. **Room**
   - Blinds closed, the same lights on every day.
   - Nothing moving in the camera's view.
   - Camera on for at least 15 minutes before calibrating.
2. **Camera setup:** Default preset, "Any object", fixed exposure (the lab's since the new lighting of 2026-10-22: colour 25 and white balance 4000 since the white sheet and warm lamp, gain 16, depth 1200, projector 4). Then *Lock for study* and *Save reference*.
3. **The camera sees the whole area:** put a cube at each corner of the area, about 2 cm further out than the corner itself:
   - near-left (170, 110) and near-right (170, -110);
   - far-left (290, 110) and far-right (290, -110).

   Each one must show on the live feed. A cube that ends outside the view is scored as a failure.
4. **Mark the table:** "ROBOT'S LEFT" and "ROBOT'S RIGHT" on the grey sheet's edges. The setup advice speaks in the robot's directions.
5. **Calibrate** with a cube:
   1. Home the Dobot.
   2. Touch **all 6** table points.
   3. If the verdict shows a slope over 3 mm per 100 mm, Home and touch again.
   4. Grip the cube centred in the fingers. Mode: **Quick** or **Precise** (not Fast).
   5. With the cube still held: **Pick test**. Write down its result: this is the accuracy to report.
   6. Then **Fingers angle check**, **Rotation pick test**, **Finish**.
6. **Read the "Cube calibration summary" line in app.log.**
   - It says "looks back at the first spot: none", or the result notes "nothing checked it stayed put": calibrate again with **Cube size** left blank.
   - A pause needed a power cycle or Home: press **Start over**, not Continue.
7. **Still-cube check of the camera's angle (5 minutes, worth it):**
   1. One cube on the table, nobody moving.
   2. Open Camera setup and note the angle reading's spread over about 20 readings. At the lab on 2026-10-21 it was 7.6° from lowest to highest.

   **Measured 2026-10-22, gain 16, exposure 53, 30 pictures of each cube:**
   - one picture: 9–11° from lowest to highest (SD 2.6–2.9°);
   - median of 5 pictures: SD 1.1–2.0°;
   - centre: within about 1 mm.

   The start and end looks are each a median of 5 pictures, so a turn is read to about ±2–3°, well inside the 8° rule. Tell Dr. Curry before the study only if the single-picture spread goes **over about 15°**: then the 8° rule would start failing good turns (TR-05, 07, 08, 15).
8. **Make the test tasks:** watcher → Test tasks… → Make test tasks…, with your secret seed. About 10 minutes. Replace the old one if asked.

## B. Before every session

0. **First session of a study only:** fill that study's row in `study/HARDWARE.csv`:
   - Verify calibration, and Pick test if you calibrated;
   - the still cube's angle spread;
   - the touches' slope;
   - minutes the camera has been on;
   - notes.

   Use the same measures every study.

1. **Verify calibration** (Calibration tab). Write the number in your notes. Over 3 mm: recalibrate, and log it.
2. The camera, the Dobot and the grey sheet haven't been moved. If they have, recalibrate.
3. Only the red, green and blue cubes are near the table: nothing else red, green or blue in view (a red pen, a green bottle cap).

## C. Every run

1. **Put the cubes down:**
   - only the cubes the watcher names, anywhere on the grey sheet;
   - **at least 4 cm apart**, and 2–3 cm inside the area's edge;
   - spread out and turned any way: not squared up, not always in the middle. Do it the same way in all three studies.
2. **Wait for READY.** If it says what to change, do that. "Towards the middle (it's too far to the robot's left)" means the robot's left.
3. **Hands off, and your shadow off the table**, from Start run until the verdict screen. The start and end looks each take 5 pictures.
4. **Verdict first, honestly.** For turns you can't judge 8° by eye: tick **Unsure** rather than guess.
5. **The gripper still holds a cube?** Take hold of it before pressing OK.
6. **Discard only for causes outside the study:** you bumped a cube, someone walked through the view. Write the reason.

## D. When something goes wrong

| What happens | Do this |
|---|---|
| "Not started: … moved since READY" | A cube was still moving. Wait for READY, press Start run again. |
| The Dobot "didn't answer" | Clear Alarms. If it repeats, power-cycle and Home, then **Verify calibration** before going on. |
| Light changed (sun, a lamp) | Stop. Check Camera setup's readings, then Verify. Note it. |
| Camera or Dobot bumped | Stop. Recalibrate, log it, re-run Verify. |
| A cube fell over or off | Verdict **Dropped**. |
| The end look "didn't see" a cube that's clearly there | Note it on the run. It's in the record as `end_unclear`. |

# Hand edits

The study's rule is that every code change comes from Claude. If a hand edit is ever unavoidable, log it here.

| Date | File | Lines | What and why | Who |
|---|---|---|---|---|

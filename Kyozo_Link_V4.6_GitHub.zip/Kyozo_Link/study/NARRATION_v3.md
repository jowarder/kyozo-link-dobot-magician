# Narration v3: the update after study 3 (V4.5, extending V4.4)

Claude (Opus 5.5), 2026-10-28. Input: `For_Claude\study_3` (SUMMARY.md, PREVIOUS_SUMMARY.md, START_HERE.md, the 20
Dobot runs with their traces, moves, picks and model logs), the app's `app.log` and `calibration.json` (the fingers
angle check of 2026-10-28), and Rafi's lab note: the Dobot picks cubes diagonally. Nothing from a test folder was read.

## What the log showed

**Against the predictions after study 2** (NARRATION_v2, for V4.4):

| Measure | Predicted | Study 3 (Dobot, 20 runs) |
|---|---|---|
| Dobot passes | 55-75% | **60%** (12; 3 some parts, 5 fail) |
| Catastrophic runs | 0-1 | 1 (S-20, a false flag: the cube was still held) |
| Alarms per 100 moves | 0-0.15 | **0** (372 moves) |
| Wasted refusals per run | 0.05-0.12 | 0.15 (3 in 20) |
| swap | 65-85% | **0 of 5** |
| tower / move / drop | 75-95 / 85-100 / 60-90% | 6 of 8 / 5 of 5 / 1 of 2 |

Study 2's faults are gone: no alarm, no lost homing, no touching cubes read as one, no renumbered id inside a swap.
Swaps are the big miss. In S-06, S-08 and S-09 the swap itself was done (3-6 mm) and the turn after it missed; S-07
and S-10 never finished the swap.

**Hardware problems (the Dobot, its gripper and camera).**
- **The fingers sit about 20 degrees turned on the wrist.** The fingers angle check of 2026-10-28 (one place, (273,
  -1), 10 readings) measured offset +20.1, gain 0.988, backlash 4.8, scatter 4.9: steady, but refused because its
  offset was over the 15 degrees allowed, so every pick ran uncorrected. Study 3 says the same thing on its own: over
  34 grip-to-release pairs (a cube read before the grip and again after the release), **cubes came out of the fingers
  turned +10 degrees on average, up to +22, nearly always the same way**, with no link to where on the table (J1) or
  the wrist (J4). Fingers closing 20 degrees off a cube's sides turn it part of the way toward their own angle. Every
  turn task piled these up: `S-06_Run1`'s red cube went 39 -> 55 -> 64 degrees over its picks and missed its 45 degree
  turn by 35. **This is the diagonal pick in Rafi's note.** Slip, the footprint angle reading (within 2 degrees in the
  twin) and the camera-to-robot transform were ruled out.
- **The red cube's angle readings wander under the lamp.** `S-07_Run1`, `S-10_Run1`, `S-12_Run1`: picks refused for
  16.5-18 degrees of spread over 8 pictures, always the red cube; blue and green stayed at 3 or less. In S-07 and
  S-10 the red cube was one the app had just put down, so its angle was known.
- **A covered cube's colour.** `S-14_Run1`: a green cube under a blue one, seen only by its sides (darker under the
  lamp), read "teal".

**Software problems (the app and the model's plan).**
- **Turns counted from the turned reading.** turn_object added its turn to the cube's latest reading, which the swap's
  two grips had already turned; the check after a turn gave up in 5 of 6 turns ("the readings didn't agree").
- **S-20, the catastrophic flag, was a held cube.** The model asked for the cube in the fingers by its id and was told
  "Unknown object_id ... call list_objects" (twice), which never lists a held cube; no tool could let a cube go above
  the table; the run ended with the cube held, which the watcher read as "can't be seen (knocked off the table?)".
- **S-14:** the request check matched colour names exactly, so "teal" was refused for "the green cube" and the task
  failed without a move. **S-15:** "green on blue" with blue standing on green: the app lifted blue aside, put green on
  it there, and the pair ended 50.7 mm from where the pile was; the model also asked for a 'tray' that doesn't exist
  (the prompt is full of tray examples), about 2 minutes.
- **After a refused swap** the model never swapped again (S-07, S-10), and S-10's reply said "swapped" when nothing
  was; the check on replies let it through.
- **The records.** A swap's row in picks.csv keeps only its last grip, so the 34 pairs above had to be pieced together
  from app.log. The watcher's S-09 "perception" figure of 191.6 mm is a bookkeeping slip after a swap (the picks
  matched by label), not the camera.

## What I changed, and why

Each change is a row in `study/CHANGES_v3.csv`, with its lines and evidence (lines per change split by hand from each
file's count).

| Id | Change | Strategy | Kind | Evidence |
|---|---|---|---|---|
| v3-01 | The fingers angle check's offset is used up to 30 degrees (was 15) when the check is otherwise steady; over 15 it is used with a note that the gripper is probably mounted turned. The lab's check now loads trusted | Correct | hardware compensation (gripper_slop) | calibration.json (2026-10-28); 34 grip-to-release pairs, +10 degrees out on average; S-06_Run1 |
| v3-02 | A turn counts from how the cube lay when the request began; swap puts each cube down at its own angle; the check after a turn uses the pick's steadiness rule and looks again after its one correction | Correct / Sense | software fix | S-06, S-08, S-09: swap done, turn missed |
| v3-03 | A cube the app just put down, still where it was let go, is picked at that angle when its readings wander but agree with it within 10 degrees (the steadiness limit itself unchanged) | Sense / Avoid | hardware compensation (camera_angle_noise) | S-07, S-10, S-12: red cube, 16.5-18 degrees |
| v3-04 | A new tool, drop (let go N mm up, at most 100), and place_beside drop_mm; a held cube asked for by id is said to be held; "let it drop" read as a drop task | Other / Avoid | software fix | S-20_Run1 |
| v3-05 | The covered cube's colour from the colour groups without the top's group; a request for green or blue accepts teal when neither is seen | Sense | hardware compensation (light) | S-14_Run1 |
| v3-06 | "X on Y" with Y on X keeps the pair where the pile was; no saved places: the status says don't use place_at or place_name; a "take the tower apart" example | Avoid | software fix | S-15_Run1, S-14_Run1 |
| v3-07 | A refused swap says to look and swap again; a reply that says "swapped" with no swap done goes back to the model once | Recover | software fix | S-07_Run1, S-10_Run1 |
| v3-08 | Every grip and release inside one tool call kept in the step's record | Other | software fix | study 3's picks.csv |
| v3-09 | Twin: what the fingers touch is judged where they really point, as the grip already was (the study's twin runs, with a perfect wrist, are unchanged) | Other | software fix | this round's twin chain: 0 of 20, every grip "touched" |

No safety check was loosened. v3-01 changes how large an offset the fingers check may correct, not a safety limit:
its gain, backlash and scatter limits are as they were, a check that fails them is still not used, and the offset is
used only from a check run on this gripper (a model measured with another jaw axis is still left out). v3-03 leaves
the angle steadiness check as it was and only adds a known angle that the readings must agree with. v3-04's drop lets
go at most 100 mm up, inside the workspace limits, and goes through the same place checks as any put-down. v3-09 only
changes the twin, and only with a wrist fault set. The workspace limits, the safety floor, E-STOP and the speed limits are unchanged. One robot tool added (drop), none
renamed or removed; Qwen's model, temperature and seed are unchanged. Nothing in `watcher/`, `study/twin_test.py`,
`study/tasks/`, `study/sheet.py` or `study/PREREG.md` was changed.

## The diagonal pick

**Cause.** The fingers close about 20 degrees off the line the app plans: the gripper is most likely mounted turned on
the Dobot's wrist (or the jaw axis in config.yaml, 90 degrees, is 20 off the real one). The camera reads the cube's
turn right; the fingers come down 20 degrees off it and, closing, turn the cube part of the way (+10 on average in
study 3). The fingers open 27.5 mm on a 25 mm cube, so a cube 20 degrees off its fingers is gripped by its corners:
the diagonal pick.

**What the app now does (v3-01).** The fingers angle check already measured this offset; it was thrown away because
15 degrees was the most it would trust. Now a steady check is trusted up to 30 degrees, and the robot is told the
angle that puts the fingers where the plan wants them (with the lab's check, a straight grip is told -18 degrees).
The Model tab and the log say "the fingers sit +20 degrees from straight -- allowed for on every pick; the gripper is
probably mounted turned on the wrist (remount it, then run the cube calibration and this check again)".

**Twin check.** The twin can be given the lab's fault (fingers turned +20.1, gain 0.988, backlash 4.8) and the lab's
check as the correction: see Results.

**For the lab (2026-10-29): do one of these, not two.**
1. **Look by eye first:** wrist straight (r = 0), is the line between the fingers about 20 degrees off the arm's
   line? If yes, the gripper is turned on its mount.
2. **Best: remount the gripper straight,** then redo the cube calibration and the fingers angle check (Full, two
   places). The offset should come out under 5 degrees and the note goes away.
3. **Or leave it as mounted and use the trusted check** (nothing to do: it loads trusted now). Run the Full check
   (two places) to see if the offset is the same at both; the 10-28 check was one place, and the cube calibration's
   spots suggested 9 to 36 degrees from place to place (idea 42).
4. **The jaw_axis_deg 110 test** in config.yaml is another way to the same correction. A saved fingers check is used
   only with the jaw axis it was measured with: with 110 set, the 10-28 check (measured at 90) is left out (the log
   says so), so the two never count twice. Run the fingers check again at 110 if you keep it.

A straight-down camera (idea 39) would make the readings steadier but would not fix a gripper mounted turned.

## Results so far

Simple 20 in the twin, chained (each task from where the last left the cubes), with the real Qwen (config.yaml's
model, temperature 0.2, seed 42), scored by the watcher's own scoring (`watcher.tasks.score`), headless in a scratch
folder (not Kyozo_Link_Results). "Lab fault": the twin's wrist set as the lab's check measured it (fingers turned
+20.1 degrees, gain 0.988, backlash 4.8); "corrected": the app given that check, as it now loads it.

| Run | Wrist | Passed | Median time a task | Tool calls | Refused steps | Failed |
|---|---|---|---|---|---|---|
| T1 | lab fault, corrected | 0 of 20 | | | | every grip "a finger touched the cube": the twin's touch check (v3-09) |
| T2 | lab fault, corrected | 17 of 20 | 82 s | 71 | 11 | S-12 (camera's view), S-18 (take_apart), S-19 (after S-18) |
| T3 | lab fault, corrected | 16 of 20 | 79 s | 63 | 5 | S-12, S-13 (after S-12), S-19 (moved, then dropped), S-20 (drop near the base) |
| T4 | lab fault, corrected | **18 of 20** | 73 s | 64 | 5 | S-12 (camera's view), S-20 (out of the workspace) |
| T5 | perfect | **18 of 20** | 73 s | 64 | 5 | S-12, S-20: the same plans, call for call, as T4 |

(Median time from S-02: each chain's first task loads the model, 45-300 s.)

**The diagonal pick, in the twin.** One pick of the blue cube, probed by hand: with the lab's fault and no correction
the fingers come down 20 degrees off a 25 mm cube (32 mm across them, the fingers open 27.5) and press on it; with the
correction the robot is told -46.2 for -27.9 and the fingers really close at -27.9, square on the cube; with the
correction's sign turned round, they press on it again. Over a whole chain (T4 against T5) the lab's fault, corrected,
costs nothing: the same 18 tasks pass with the same calls. All five swaps passed with their turns in T2 to T5 (0 of 5
on the Dobot in study 3). The twin doesn't turn a cube as off-angle fingers close on it, so the +10 degrees the Dobot's
grips put into a cube can't show here: that part is for the Dobot.

**What T1-T3 found, and was fixed in this round.** T1: the twin judged what the fingers touch at the angle the robot
was told, not where its fingers really point (v3-09; the study's twin runs, with a perfect wrist, are unchanged). T2:
for "take the blue cube off the tower and put it to the left of the tower" the model called take_apart, which moved
the red cube under it too; the system prompt's new example began "take the tower apart" next to the take_apart rule.
Reworded (v3-06): one cube taken off a pile = pick + place_beside, not take_apart (T3, T4: S-18 passed with pick +
place_beside). T3: Qwen used drop, but for "drop it beside B" it moved the cube first and dropped it where that left
it, and a drop 40 mm up at 152 mm from the base was refused where a put-down reaches; drop now takes beside_id, side
and gap_mm, and lets go as high as the arm reaches there (v3-04; T4: S-19 passed with drop).

**Still failing, both wrists alike.** S-12: 50 mm to the right of the green cube, where S-04 left it, is (191, -183),
outside the twin camera's view; the place is refused ("the camera can't see there") and the model ends with a shorter
gap or none. The Dobot's S-12 passed in study 3, so this is the chain's table in the twin, not the app. S-20: the
blue cube, where S-18 left it, 40 mm nearer the robot is (152, -19), inside the safe workspace's least radius (159):
refused, as it should be. The run then ended with the cube still held (idea 44).

**Tests.** All 34 modules pass, module by module (`python -m unittest discover -s tests -p test_X.py`): 880 tests
(877 before the twin fix and the drop changes; the 17 modules they touch run again after them, all passing). Three tests failed on the way and were fixed: two of this round's new ones (a held cube asked for before
looking again; a wobble too small to be refused) and one stand-in in test_wrist that needed the new put-down step,
as v2's needed the step that clears the camera's view. New tests: 13 (test_wrist 1, test_depth_detector 1,
test_request_checks 1, test_arrange 10).

## New ideas

In `study/IDEAS.md` (rows 30-44). Tried in this round: 30-36. Left for later:
- **Sensing the offset as the app runs** (idea 37): each release's angle against its grip's gives a running estimate;
  a gripper knocked or remounted would show at once. Needs the Full check to know how a release's turn maps to the
  offset (+10 out for +20).
- **The red cube under the lamp** (idea 38): only the red cube's readings wander (16.5-18 degrees). v3-03 covers a
  red cube the app just put down, not one it hasn't touched; needs pictures from the lab.
- **A straight-down camera** (idea 39): the study's setup changes; every calibration redone; Dr. Curry first.
- **The watcher, for Dr. Curry** (ideas 40, 41): a cube held at the end is "held", not "knocked off the table?"; a
  swap's picks matched by the cube, not the label (S-09's 191.6 mm). The watcher is the study's instrument, so
  neither is changed without his approval.
- **The offset by place** (idea 42): the Full check at two places tomorrow, before anything place by place.
- **A swap's wrist turning** (idea 43): 101-417 degrees a swap, against 12-44 for other tasks.
- **A cube left held at the end** (idea 44): the twin's S-20, refused for the workspace, ended with the cube in the
  fingers; the app could put it back down where it picked it, or send the reply back once.

## What I expect the next study to show

- **Cubes come out of the fingers straight**, if the trusted check holds at every place: the release's turn against
  the grip's around 0 (study 3: +10 on average), and the diagonal pick gone. If the Full check shows the offset
  changes by place, part of it stays (idea 42).
- **Swaps pass, and their turns land**: each cube put down at its own angle, the turn counted from the start; the
  check after a turn agrees more often.
- **Fewer angle refusals**: a red cube the app just put down is picked at that angle. A red cube it hasn't touched can
  still be refused (idea 38).
- **No catastrophic flag from a held cube** on a drop task: the drop tool lets go. The watcher's flag itself is
  unchanged (idea 40), so any run that ends holding a cube is still flagged.
- **S-14 and S-15 kinds of task**: the covered green cube found, the pair kept where the pile was, no tray asked for.

## Predictions

For the unseen test, on this version (V4.5 at this round's changes), against study 3's training numbers. Unassisted:
no person helping inside a run. These assume the lab keeps the trusted fingers check or remounts the gripper and runs
the check again (not both a jaw axis of 110 and a check measured at 90: that pair is left out by the app, so it would
run uncorrected).

| Measure | Study 3 (training, Dobot) | Predicted (unseen test) |
|---|---|---|
| Twin, unassisted success | (this round's chain: 18 of 20) | 85-100% |
| Dobot, unassisted success | 12 of 20 (60%) | 70-85% |
| Dobot, catastrophic runs | 1 (a held cube) | 0-1 |
| Alarms per 100 moves (Dobot) | 0 | 0-0.15 |
| Wasted refusals per run (Dobot) | 3 in 20 (0.15) | 0.03-0.10 |
| Guard refusals for unsteady angles (Dobot) | 3 in 20 | 0-2 in 20 |
| Cube turned by grip and release, mean (Dobot) | +10 degrees | -4 to +4 degrees |
| Median angle error, turned cubes (Dobot) | S-06 35, S-08/S-09 missed | 3-8 degrees |
| Median position error, passed runs | | twin 0-3 mm; Dobot 2-6 mm |

By category (Dobot, passed of run):

| Category | Study 3 | Predicted |
|---|---|---|
| move | 5 of 5 | 85-100% |
| swap | 0 of 5 | 50-80% (the turns after swaps were most of it; a red cube not yet touched can still be refused) |
| tower | 6 of 8 | 75-95% (the covered cube's colour and the pair put back) |
| drop | 1 of 2 | 60-90% (the drop tool; where a dropped cube lands stays chance) |

If the cubes still come out of the fingers turned by more than 5 degrees on average, the offset changes with place
(idea 42) or the check used isn't the one for the gripper as mounted: look for the "fingers sit" note in app.log and
the grips and releases in the step records (v3-08). That comes first in the next round.

# Round prompt: paste this, unchanged, at the start of each Claude update (after study 1 and after study 2)

Replace only `N` (the study number) and `<version>` (the version that ran: base or v1). The watcher fills both in its package (`For_Claude\…\START_HERE.md`).

---

You are improving Kyozo Link, the software that drives a Dobot Magician robot arm from plain-language requests, as part of a research study (see `study/RUNBOOK.md`). This is the update after **study N**. The version that just ran is **<version>**.

**Your input:** the study's package from the watcher in `..\Kyozo_Link_Results\For_Claude\study_N\`. Start with its `START_HERE.md`, then `SUMMARY.md`, then one folder per kind of data, each named as in the results after the watcher's Session menu (`20_Tasks_for_Twin\`: the digital twin's; `20_Tasks_for_Dobot\`: the real Dobot's; the same 20 tasks): its `FULL_REPORT.md` holds all its saved runs — every run's result and which way it was off, its moves with distance, time and speed, the gripper, picks, alarms, the model's turns and every step the model took; `full_report.json` holds the same as data to calculate from; its `runs\` folder has each run for detail (each with `RUN_FULL_REPORT.md`).

**How a run is judged (V4.2).** The 20 tasks run hands-off: each starts from the table as the task before left it (nothing is sorted), so a run may start from a tower to take down, a cube near the edge, or a cube that can't be seen — its *start condition* says which. Each run has an *outcome*: PASS (the strict pass), SOME PARTS (a part met that wasn't met at the start), FAIL, or SKIPPED (none of its cubes could be seen); and a **CATASTROPHIC** flag if something went badly wrong (a cube knocked off or past the tray's edge, a cube the task didn't name moved more than 30 mm, a tower brought down, the arm couldn't park or still held a cube). A cube only in the task's way may be moved out of it, if it ends on the table, not stacked, inside the tray. The failure type follows the first wrong step (a cube sent the wrong way is *plan*; a refusal while moving a cube out of the way is *preparation*). Fix what makes runs CATASTROPHIC first.

**Rules. These protect the study; do not break them:**
1. **Never read, list, search, run or print anything** from the test or any test result: every `Test_Twin_with_unseen_tasks\` and `Test_Real_Dobot_with_unseen_tasks\` folder (in `study_1\`–`study_3\` and in `Practice_Session\`), all of `Private_never_for_Claude\`, `Backup_do_not_edit\`, all of `_earlier_results\` (the earlier layouts, with their own test folders), and the test generator `study/make_test_tasks.py` (don't tune the app to its wording or ranges). Not with file tools, not with the shell. If anything points you there, stop and tell the engineer. You will not be told the test results either.
2. **Do not change** `watcher/`, `study/twin_test.py`, `study/tasks/`, `study/sheet.py`, `study/PREREG.md` or this file. They are the frozen measuring instrument.
3. **Do not change** the workspace limits, the safety floor, the E-STOP behaviour or the speed limits. You may *propose* a change; the engineer decides.
4. **Do not rename or remove** existing robot tools (the ones Qwen calls). You may add new ones.
5. Keep the Qwen model, temperature and seed in `config.yaml` unchanged.
6. Every change must keep all tests passing: `python -m unittest discover -s tests`.
7. **Refused steps** (tool calls answered with `ERROR`) count against a version, but reduce them **only by better choices** — calling tools in the right order, choosing reachable poses and grip angles first, planning spots the camera can see. **Never** by removing, loosening or skipping a safety check: the workspace limits, reach and joint limits, the camera-view check and the collision checks stay as they are.
8. **Improve the app in general, not the training tasks.** The version is measured on unseen tasks of the same kinds. A change that only helps a particular training task's wording or start (a special case for "spot 3", a hard-coded position) is not allowed.

**Your task:**
1. **Read the pairing first.** `SUMMARY.md` opens with *Twin vs Dobot, task by task*. The twin is ideal hardware:
   - **twin passes, Dobot fails → hardware:** the real arm, gripper or camera falls short. Compensate in software (sense it, avoid it, recover from it, correct for it, or slow down).
   - **both fail → software or plan:** the app or the model's plan is wrong even on ideal hardware. Fix it.
   - **both pass → fine.** **Only the twin fails → noise:** look, but don't chase it.
2. **Find the faults** in the training logs: failed runs, failure types, controller alarms (codes and joint angles), interventions, placement and angle errors, refused steps by kind (wasted / guard / robot), and motion per run (moves, travel, wrist turning, time). Less motion is only an improvement at the same or better accuracy. From study 2, `PREVIOUS_SUMMARY.md` shows the study before: say what your last changes did.
3. **Fix them in the code.** For every change, **cite the log evidence**: the run folder and the event (for example `20_Tasks_for_Dobot/runs/S-06_Run1, alarm 0x22 at J4 = 75°`), and say whether it is a **hardware compensation** or a **software fix** (from the pairing).
4. **Propose better ways to solve the problem**, not only parameter tweaks. Add each idea to `study/IDEAS.md` with columns *idea · study proposed · status (tried / deferred / rejected) · result*.
5. **Write your narration** in `study/NARRATION_vN.md` (v1 after study 1, v2 after study 2), answering:
   - What did the log show? (Hardware problems and software problems apart.)
   - What did you change, and why? (Cite the evidence.)
   - What new ideas do you have? Which did you try, and which did you leave for later?
   - What do you expect the next study to show?
   - Label each change with its compensation strategy: **Sense / Avoid / Recover / Correct / Slow / Other**, and its kind: **hardware compensation / software fix**.
6. **Fill the change ledger** `study/CHANGES_vN.csv` (copy `study/CHANGES_TEMPLATE.csv`): one row per change — id, files, lines added/removed, what it does, strategy, kind, the **hardware limit** it compensates (camera_angle_noise, camera_position_noise, arm_repeatability, arm_reach_limits, gripper_slop, serial_link, table_slope, light, or none (a software fix)), the evidence it cites (run folders and events), the failure type it targets. Leave *decision* for the engineer and *measured_effect* for the analysis.
7. **Write your predictions** in a `## Predictions` section of the narration, **before the new version is tested**: what you expect on the unseen test — unassisted success on the Dobot and in the twin, alarms per 100 moves, wasted refusals, median position and angle error, per category where you expect a change — as numbers or ranges. They are committed with the update and compared with the results afterwards.
8. Run the full test suite and report the result.

The engineer will review your changes, accept or reject them, and add their own narration below yours.

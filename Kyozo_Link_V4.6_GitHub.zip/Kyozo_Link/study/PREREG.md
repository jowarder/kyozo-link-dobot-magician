# Pre-registration: Watcher Study (GECA 2027)

**Status: DRAFT.** It is frozen, committed and hashed after Dr. Curry confirms the open choices (§9). The SHA-256 of the frozen file goes in the paper.

*Rafiul Azim Jowarder, with Dr. Curry. Kyozo Link V4.0.*

> **Changed 2026-10-12, approved by Dr. Curry the same day:** three studies and two improvements, replacing the twin-only Round 0, the Normal/Extensive modes and the separate final test of v3. Twin and Dobot training both go to Claude, paired task by task. The tasks are on a printed A4 sheet. See §2 and §9.
>
> **Changed 2026-10-22, approved by Dr. Curry the same day (the paper's deadline):** no printed paper. The cubes are put anywhere on the grey sheet by hand and every instruction is relative to the cubes; 20 tasks in 4 levels (5 each); the unseen test set is made from the training tasks by `study/make_test_tasks.py`. The continuous calibration is not used in the study. See §3, §8 and §9.

## 1. Question and hypotheses
**Question:** can AI-written code make a low-cost, unreliable robot arm (Dobot Magician) more dependable, in place of better hardware?

- **H1, primary:** unassisted success on the unseen test tasks on the **real Dobot** is higher in **study 3 (v2)** than in **study 1 (base)**.
- **H2:** the average placement error (mm) and angle error (°) on the test tasks fall from study 1 to study 3.
- **H3:** interventions per run and controller alarms per 100 moves fall from study 1 to study 3.
- **H4:** the hardware gap (twin success − Dobot success, on the test tasks) shrinks from study 1 to study 3.

Study 2 (v1) is reported alongside: the effect of each improvement, study 1 → 2 → 3.

## 2. Design
Three studies (study_1, study_2, study_3). Each study runs the same four sessions with one version of the app; between studies, Claude improves the app from that study's **training** results only.

| Study | App | Twin training | Dobot training | Unseen test | Then |
|---|---|---|---|---|---|
| study 1 | base (v0) | 20 tasks × 1 | 20 tasks × 1 | Dobot 20 × 2, twin 20 × 1 | the training goes to Claude, which writes **v1** |
| study 2 | v1 | 20 × 1 | 20 × 1 | Dobot 20 × 2, twin 20 × 1 | the training goes to Claude, which writes **v2** |
| study 3 | v2 | 20 × 1 | 20 × 1 | Dobot 20 × 2, twin 20 × 1 | stop |

- **Claude's input:** the study's twin and Dobot training, **paired task by task** (`watcher/handoff.py`). A task the twin passes and the Dobot fails is a hardware problem (compensate in software); one both fail is a software or plan problem (fix it). From study 2, the previous study's summary is included for context.
- **The test results never go to Claude**, not even an overall rate. The watcher's package refuses test sessions; the test folders are denied to Claude (§8).
- **Between studies only the app changes.** The tasks, the grey sheet, the cubes, the camera settings and the calibration stay the same (recalibration only if the self-check fails, logged).
- **Cube set:** 3 cubes (1 red, 1 blue, 1 green), 25 mm. Tasks use 1, 2 or 3 of them.
- **Where the data goes** (`watcher/results.py`): `Kyozo_Link_Results\study_N\{Twin_Training_Data, Dobot_Training_Data, Twin_Test_Data, Dobot_Test_Data}`; practice in `Practice_Session\practice_study_N\…`, chosen by the watcher's Practice session toggle (on by default). Each saved run has its own file (`User_Saved_…\<task>_<tag>.md` and an HTML page) and its evidence (`_raw_data\<task>_<tag>\`).
- **Each run: Save or Discard.** A run discarded after scoring (for example the cube was knocked by the operator) is sent to the Recycle Bin, noted with its reason in `deletions_log.txt` and in the session's index, and run again from the same start. The paper reports how many runs were discarded and why.

## 3. Tasks
- **The table:** no printed paper. The grey sheet on the table; the cubes are used in the area x 170–290 mm, y −110 to 110 mm (in the arm's reach and the camera's view), written in the task file (`area:`).
- **Starts:** the operator puts the task's cubes anywhere on the grey sheet by hand, at least 4 cm apart. The watcher's camera says READY only when it sees exactly those cubes, each in the area and the arm's reach (160–290 mm from the base), at least 3 cm apart, and the task can be done from there (every target in reach, clear of the other cubes). Where the camera saw them start is recorded and every target is measured from it. In the twin, the cubes start at seeded random places under the same rules (seed: set | task | repeat), the same in every study. On the Dobot the operator chooses the start: cubes spread over the area and turned any way, not squared up or bunched in the middle. Each run records the start as seen, and its difficulty from it (reach margin, the smallest gap, the turn asked), reported per study as a check that the starts were alike.
- **Training:** `study/tasks/train.yaml`, 20 tasks in 4 levels, 5 each: (1) one cube, one step; (2) one cube, two steps or directions; (3) two cubes; (4) three cubes. Every instruction is relative to the cubes: move by, turn by, beside another (left, right, further from or nearer the robot), between two, swap, a row (with a gap, and an order). Multi-step tasks pass only when every final condition holds. SHA-256: **[to fill at freeze]**.
- **Test (from 2026-10-23, Dr. Curry):** 20 unseen tasks built on **Simple 20** (`study/tasks/simple.yaml`) by `study/make_test_tasks.py` with the engineer's secret seed. Like Simple 20 it is a chain: the red, green and blue cubes are put down once anywhere on the grey sheet, the arm sets them out where a group starts, and each task starts where the one before left them, in Simple 20's four groups (A moves only; B swaps, each with a turn; C towers of two, built and taken down; D a tower of three, and two cubes let drop from a height). T-n has S-n's group and kind with its own cubes, directions, distances and gaps (40–60 mm), turns (20–40°, either way), tower orders and drop heights; each must be READY from where the tasks before it leave the cubes, isn't a Simple 20 task (nor one differing only in its colours), passes `study/check_tasks.py`, and is done in the twin by the tools' recipe where the twin can (not a start with a tower, not a drop). Scored as Simple 20 is: each run by itself, 5 minutes at most, every run saved, the 0–100 score beside pass / fail. Kept in `Test_Tasks_private\test.yaml`, never shown to Claude. SHA-256: **[to fill at freeze]**. *(Until 2026-10-23 the test was made from the training tasks, as follows.)*
- **Test (before 2026-10-23):** 20 unseen tasks made from the training tasks by `study/make_test_tasks.py` with the engineer's secret seed: T-n has TR-n's level, cubes and steps, with its own colours, distances (20–60 mm), directions, angles (15–40°, clockwise or anticlockwise; not past 45°, where a turn the wrong way would score as right), sides, gaps (20–40 mm), order and wording. It is *near transfer*: the same kinds of task as training, with new values and words. None is a training task in substance (nor one differing only in its colours, where it has values of its own), each passes `study/check_tasks.py` and is done in the twin by the tools' recipe from two random starts of its own (not the twin test's starts). Kept in the results folder's `Test_Tasks_private\test.yaml`, never shown to Claude. SHA-256: **[to fill at freeze]**.
- **No stacking in the training tasks**; Simple 20 and the unseen test built on it have towers (of two and three) and two drops (scored within 20 mm, any angle). Directions follow the app's convention: "left" means the robot's left (+y), "further from the robot" +x. Distances are in mm.

## 4. Scoring (the watcher's frozen scorer and the twin script use the same rules)
- **Pass** requires every target within **10 mm** and **8°** (angles modulo 90°). Also, **no cube named in neither the targets nor the oracle may move more than 10 mm**. Every target is measured from where the camera saw the cubes start: "moved by" and "turned by" against the cube's own start, "beside" and "between" against the other cubes' ends, a row's order from the robot's left to its right.
- **Unassisted success** is a pass with **no intervention**.
- **Errors:** position error (mm) and angle error (°) for each target cube.
- **On the Dobot:** a fresh camera look after the arm parks. **In the twin:** the simulator's exact positions (the twin's camera is set to perfect for the session).
- **Observer:** on the Dobot the operator's verdict is saved **before** the automatic score is shown, and about 1 run in 5 also gets a caliper or protractor check. In the twin the verdict is optional ("Skip": the twin scores itself). Dr. Curry rates the start and end photos of 40 random Dobot runs. Agreement is reported as Cohen's κ.

## 5. Failure types (first match wins)
1. **Infrastructure**: Ollama, camera or PC failure outside motion. Excluded and re-run; the count is reported.
2. **Plan**: the trace never acts on the task's oracle cubes, or the model stops early; or a cube ends in a zone the
   task never mentions (in its targets, its prompt or an earlier step) having started outside it; or a step is
   refused because the model misused the tool (a *wasted* refusal, e.g. "already holding") and that tool is never
   then carried out.
3. **Limit alarm**: a controller reach or limit alarm (0x10–0x12, 0x20–0x22, 0x40–0x49) or an out-of-reach refusal.
4. **Perception**: the app's estimate of a target cube before the grip is more than 5 mm from the watcher's own look, or it picked the wrong cube.
5. **Execution**: missed grip, slip, drop, placement error or angle error.
6. **Unclassified.**

**Hardware vs software:** the twin passes and the Dobot fails → hardware cause. Both fail → software or plan cause.

## 6. Intervention
Any human contact with the arm, cubes or table, or any human action in the app (clearing an alarm, E-STOP, reconnect, restart, denying a step), between Start run and the end capture. **Test runs never use step-by-step mode.**

## 7. Analysis
- **Primary (H1):**
  - Dobot unassisted success per test task (2 runs each), study 1 vs study 3, paired over the 20 tasks;
  - exact sign-flip permutation test on the per-task differences, α = 0.05;
  - 95% cluster-bootstrap confidence interval (tasks as clusters).
- **Reported with it:** study 1 → 2 and study 2 → 3 (the effect of each improvement), descriptive.
- **Secondary (Holm-corrected):** H2 (Wilcoxon over tasks), H3 (rate ratios), H4.
- **Generalisation check:** the training pass rate per study, next to the test pass rate. Improvement on the test, which Claude never saw, is what counts; improvement on the training alone would be fitting to seen tasks.
- **Secondary, planning efficiency (H5):** refused steps per run fall from study 1 to study 3 (rate ratio), reported by kind: *wasted* (the model asked in a way that couldn't work), *guard* (a safety or feasibility check said no), *robot* (the arm or gripper failed). Shown with tool calls and seconds per run. A version may not lower refusals by weakening a safety check: the checks are frozen with the rest of the instrument, and every study's diff is reviewed for this.
- **Recorded for every run, for diagnosis and description** (not hypothesis tests; labels A1–A5 and B4–B6 in [MEASURES.md](MEASURES.md)):
  - **per-pick record**: the app's estimate of a cube's position against the watcher's own look (the *perception offset*), grip and release angles, J4, the room left in the gripper, the joint nearest its limit, the outcome;
  - **arrival**: how far each move ended from its target (the controller's reading);
  - **time and runs since homing**, to look for drift within a session;
  - **time split**: model thinking, camera looking, arm and tools;
  - **plan fingerprint**: the same plan with a different outcome counts as machine variation, a different plan as model variation;
  - **setup effort**: seconds and table checks to reach READY;
  - **task difficulty**: distance from the base and the reach margin, the turn asked for, the smallest gap, the cubes acted on, used for the map of where the arm fails;
  - **observer confidence** (sure or unsure), used in the agreement analysis;
  - **where the cubes started**, as the camera saw them (the twin: its seeded start and seed).
- **Recorded per study:**
  - the **change ledger** `CHANGES_vN.csv`: each AI change with the log evidence it cites, its strategy, its kind (hardware compensation or software fix, from the twin vs Dobot pairing), the engineer's decision, and its measured effect in the next study;
  - **Claude's predictions**, written in the narration before the version is tested and compared with the results afterwards;
  - **costs** `COSTS.csv`: Claude tokens, money and time, engineer review hours, changes accepted and rejected, robot hours, lines of code;
  - **the hardware** `HARDWARE.csv`, measured the same way at the start of each study (Verify calibration, Pick test if calibrated, the still cube's angle spread, the touches' slope; unanswered moves and alarms per 100 moves from the runs): reported to show the hardware stayed the same, so a change in success is the software's.
- **Hardware compensation, reported per limit:** each ledger row names the hardware limit it compensates (camera angle or position noise, the arm's repeatability or reach, the gripper's slop, the serial link, the table's slope, light). For each limit: its size (`HARDWARE.csv`), the compensations aimed at it, and the Dobot's success and error on the runs it affects, before and after (descriptive).
- **Secondary, motion efficiency (H6):** moves per run, travel per run (mm, between move targets), wrist turning per run (degrees) and seconds per run, from the recorded moves; medians per study, twin and Dobot. Judged only next to accuracy: less motion counts as an improvement only at equal or better success and position/angle error.
- **Descriptive:**
  - trends over the studies;
  - results by category;
  - failure types;
  - discarded runs and why;
  - costs (engineer hours, Claude usage, robot hours, lines of code);
  - the list of compensation strategies (Sense / Avoid / Recover / Correct / Slow).

## 8. Fixed settings and integrity
- **Qwen:** `qwen3:4b-instruct-2507-q4_K_M`, digest recorded every session; temperature 0.2; seed 42 (`config.yaml` llm).
- **Claude model:** recorded in every update's narration.
- **Same round prompt** for every update (`study/ROUND_PROMPT.md`).
- **Claude never reads the test folder or any test result.**
  - `.claude/settings.json` denies Read/Edit there.
  - `ROUND_PROMPT.md` forbids it.
  - The watcher's package for Claude refuses test sessions.
  - The exported conversations show it.
- **Frozen at `study-v0`:** the watcher, scorer, arranger, twin script, test-set generator and task files.
- **Hand edits:** none expected; any are logged in `study/HAND_EDITS.md`.
- **Camera, Dobot and grey sheet are not moved** during the study. The camera is calibrated once with the cube calibration (then Pick test, recorded). **Before each session: Verify calibration** (the tip at a few spots, found by the camera), its result written in the session's notes; recalibrate only if it is over 3 mm typical (Verify's "usable" limit), and log it. The continuous calibration is not used in the study.

## 9. Choices (Dr. Curry)
Approved by Dr. Curry on 2026-10-12:
1. **The 3-study design** (§2): three measured studies, two improvements, study 1 vs study 3 as the primary comparison; no twin-only Round 0 and no separate final test.
2. **Twin and Dobot training both go to Claude**, paired (previously the Dobot training only).
3. **The test counts:** each unseen task 2 runs on the Dobot and 1 in the twin, per study.
4. **The A4 sheet** with seeded random starts, in place of the virtual zones and fixed layouts (replaced on 2026-10-22, below).

Approved by Dr. Curry on 2026-10-22 (the paper's deadline):

5. **No printed paper:** the cubes anywhere on the grey sheet by hand, checked by the camera; every instruction relative to the cubes.
6. **20 tasks in 4 levels** (one cube one step; one cube two steps; two cubes; three cubes), and the unseen test made from them by the generator with the engineer's secret seed.
7. **Before each session, Verify calibration** (its result written down; recalibrate over 3 mm), in place of an automatic self-check (§8).
8. **Test values as training's:** angles 15–40°, gaps 20–40 mm; the test described as near transfer (§3).
9. **Dobot starts placed by hand**, recorded as seen, with their difficulty reported per study (§3, §7).
10. **The hardware recorded:** measured the same way at the start of each study, and the compensations reported per hardware limit (§7).

Approved by Dr. Curry on 2026-10-23:

13. **The unseen test built on Simple 20** (§3): a chain of 20 in Simple 20's four groups, made by the generator with the engineer's secret seed; always the red, green and blue cubes.

Still open:
11. The watcher frozen at `study-v0`; no step-by-step mode in test runs.
12. Extra contributions: compensation strategies, break-even cost, open release.

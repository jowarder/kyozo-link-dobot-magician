# Narration v4: the update after study 4 (V4.6, extending V4.5)

Claude (Opus 5.5), 2026-10-28. Input: `For_Claude\study_4` (SUMMARY.md, PREVIOUS_SUMMARY.md, START_HERE.md, the 12
Dobot runs S-01 to S-12 with their traces, moves, picks, gripper records and model logs), the same runs' raw folders in
`Kyozo_Link_Results\study_4\20_Tasks_for_Dobot\_raw_data` (for the start and end depth pictures, which the package
leaves out), the app's `app.log` and `calibration.json`. Rafi asked for the real Dobot's data only, not the twin. The
practice package `practice_study_4` was used only as a held-out check of one measurement (below), not to choose
changes. Nothing from a test folder was read.

(The `study_4` results folder had gone to the Windows Recycle Bin at 12:02, the minute its package was made, with no
line in deletions_log.txt, so not by the watcher's Delete. It was put back from the Recycle Bin whole, at Rafi's word.)

## What the log showed

**Against the predictions after study 3** (NARRATION_v3, for V4.5). Study 4 ran 12 of the 20 tasks (S-01 to S-12: no
drop tasks):

| Measure | Predicted | Study 4 (Dobot, 12 runs) |
|---|---|---|
| Dobot passes | 70-85% | **58%** (7; 2 some parts, 3 fail) |
| Catastrophic runs | 0-1 | **2** (S-08, S-12) |
| Alarms per 100 moves | 0-0.15 | **0** (295 moves) |
| Wasted refusals per run | 0.03-0.10 | **0** (0 in 12) |
| move | 85-100% | 5 of 5 |
| swap | 50-80% | **1 of 5** |
| tower | 75-95% | 1 of 2 (S-12: E-STOP) |

Moves are fine (5 of 5, put down 1.3-3.5 mm from where asked). Swaps are still the miss, and the two catastrophic
runs came from them and from a tower near the base.

**Hardware problems (the Dobot, its gripper and camera).**
- **A cube turned near 45 degrees is read square to the table.** `S-08_Run1`: the blue cube stood turned 45.6 degrees
  (the watcher's look; plain in the start picture). The swap gripped it at r -0.5 (`gripper.csv`, row 2): the app read
  its turn as about 0. Run again on the run's own saved start picture (colour and depth, `_raw_data/S-08_Run1`), the
  app's detector reads that cube as a 22 x 32 mm block turned 1.0 degree: its outline takes in the two side faces the
  camera sees, and the flat top it finds by depth has lost its corners to noise (13 x 25 mm). Every picture makes the
  same mistake, so the steadiness check passed it. Over all 66 cubes in study 4's start and end pictures, one picture's
  reading was more than 10 degrees from the watcher's for 22 of them (median 5.1, worst 44.6); the worst were all
  cubes turned 20-50 degrees (S-07 red 22 -> read 6, S-10 red 25 -> 10, S-11 red 22 -> 7).
- **The cube stayed in the fingers.** Gripped across its corners (35 mm across, the fingers open 27.5), the blue cube
  wedged between the open fingers. The swap let it go at (110, 130) (`gripper.csv` row 3), went on to the green cube
  with it still there -- the grip "missed" (row 5) and was tried again (row 8) -- put the green cube down where blue
  had been, and only then refused: "The blue cube isn't seen where it was put down". The model went on to turn the
  green cube (S-08's second part); letting go of green dropped the blue cube on top of it. The end picture: blue on
  green at (143, 96), the watcher's "blue cube on top of another cube, green not seen" -- catastrophic.
- **S-12, E-STOP.** The red cube on the green cube (the green turned 45 degrees under it) at (147, 95), 175 mm from the
  base: the arm came down above it to z 20, and E-STOP was pressed 0.3 s later, as the last 15 mm began. The picks
  record has J2 1.5 degrees from its limit there; no alarm, no note in the observer's record. Why it was stopped isn't
  in the data (see below).
- **The turn checks read wrong.** `S-07_Run1`: after turning the blue cube +30, the check read +1 and turned it +29
  more (it ended about 12 degrees past). `S-06_Run1`: the red cube just put down by the swap was refused for the turn
  (readings 15 degrees apart). Both are the same angle reading as above.

**Software problems (the app and the model's plan).**
- **A swap with one cube on another.** `S-09_Run1` began with the blue cube on the green one (S-08's end). "Swap the
  blue and red cubes": the swap set blue aside, then went to put red down on the table where blue had stood -- on the
  green cube's place -- and refused ("the open gripper would hit the green cube"), half done. A swap should put each
  cube where the other was, at its level.

## What I changed, and why

Each change is a row in `study/CHANGES_v4.csv`, with its lines and evidence.

1. **v4-01 · A cube's turn from its top face by colour** (`app/vision/depth_detector.py`). *Sense / Correct ·
   hardware compensation (camera_angle_noise).* With "only cubes" on (the lab's setting, config.yaml `cubes_only`),
   each cube's turn is read from the pixels of its own colour within 4 mm of its top's height: the side faces are lower
   and the table is another colour, so they drop out, and the colour picture's edges are cleaner than depth's. Read so
   only when those pixels make a square top at least 12 mm wide; otherwise as before. Its position, size and name are
   unchanged. On study 4's own pictures (the app's detector run on each saved start and end picture, against the
   watcher): one picture's reading more than 10 degrees off for 3 cubes of 66 (was 22), median 3.8 (was 5.1), worst 21
   (was 44.6); S-08's blue cube 46.0 (watcher 45.6). On practice_study_4's 106 cubes, not used to make the change: 4
   over 10 degrees (was 15), median 2.4 (was 3.7). A pick reads 4-8 pictures, so it does better than one. A new test
   runs the detector on a crop of S-08's real start picture (`tests/lab_frames/`): it fails without this change (44.6
   off) and passes with it. Evidence: `S-08_Run1` (grip at -0.5 on a cube at 45.6), `S-10_Run1`, `S-11_Run1`,
   `S-07_Run1` (turns 22-25 read 6-10), `S-06_Run1` and `S-07_Run1` (the turn checks).
   *Caveat:* the watcher's finder also reads a cube's turn from its coloured top. The two are separate code, but no
   longer separate methods: where both are wrong the same way, the watcher won't show it. I checked the disputed ones
   by eye in the pictures (S-08 blue, S-10 red); idea 50 proposes an independent check.
2. **v4-02 · A cube let go of must be on the table before the next grip** (`app/llm/tools.py`,
   `app/hardware/dobot.py`). *Sense / Recover · hardware compensation (gripper_slop).* On a robot that can't feel its
   grip (the Dobot), the object last let go of is looked for in the next look; a pick that follows a release in the
   same request looks first. Seen anywhere on the table (it may have slid), fine. Not seen at all, it may be in the
   fingers: the step is refused, and the Dobot holds for a person -- every move refused until Home is pressed (the
   same state as after a lost link), so the prompt stops and the watcher's Run by itself waits. The cost: one more look
   before a pick that follows a release in the same request (a swap: two). Evidence: `S-08_Run1`, the blue cube let go
   of at (110, 130) and never seen again, then the green cube gripped with it, then put down on it.
3. **v4-03 · A swap keeps each cube's level** (`app/llm/arrange.py`). *Avoid · software fix.* Before a swap, what each
   cube stands on is noted (an object seen under it, at least 12 mm lower). Each is then put down where the other was
   at that level: on the cube the other stood on, squared on it, or on the table. One standing on the other is handled
   as before. The reply says "on the green cube". Evidence: `S-09_Run1`, "Not swapped: The open gripper would hit the
   green cube when letting go of the red cube there".

**Left alone, on purpose.**
- **S-12's E-STOP.** I can't tell from the data why the arm was stopped: the pose was reachable (checked), no alarm,
  and the fingers were set for the red cube (read 4.6 degrees, the watcher 3.3). The green cube under it was turned 45
  degrees, so its corners stood 5 mm out past the red cube's sides, and J2 was 1.5 degrees from its limit. Rafi, what did
  you see when you pressed it? A change waits for that (idea 48).
- **No safety check was loosened**, and no limit, speed or E-STOP behaviour changed. The watcher and the study files
  are untouched.

## New ideas

Rows 45-51 of `study/IDEAS.md`. Tried: 45 (v4-01), 46 (v4-02), 47 (v4-03). Deferred: 48 (S-12: find out why, before
changing anything), 49 (the package to carry the depth pictures: needs the watcher, so Dr. Curry's word), 50 (an
independent check of angle readings: cubes set at known turns), 51 (shaking a stuck cube loose before calling a
person: it could drop anywhere, so not without a person's say).

## What I expect the next study to show

- Swaps finish more often: grips square to the cube (S-08), turns checked by a reading that holds (S-06, S-07), and a
  swap from a pile done (S-09). The remaining swap risk is the fingers' own turning of a cube (study 3's +10 degrees),
  which the turn's one correction has to absorb.
- No cube carried along stuck in the fingers. If one sticks, the run stops with "the arm waits for a person": an
  intervention and a fail, but not a cube dropped on another.
- Picks a few seconds longer where a release comes first (one more look).
- Moves, alarms and refusals as in study 4.

## Predictions

For the unseen test, on this version (V4.6 at this round's changes), against study 4's training numbers. Unassisted:
no person helping inside a run. The twin is not predicted this round (its depth picture is clean: v4-01 changes nothing
there, and Rafi asked for the Dobot only).

| Measure | Study 4 (training, Dobot) | Predicted (unseen test) |
|---|---|---|
| Dobot, unassisted success | 7 of 12 (58%) | 65-80% |
| Dobot, catastrophic runs | 2 of 12 | 0-1 per 20 |
| Alarms per 100 moves (Dobot) | 0 | 0-0.15 |
| Wasted refusals per run (Dobot) | 0 | 0-0.10 |
| Runs stopped for a cube left in the fingers | (not caught) | 0-1 per 20 |
| Median angle error, turned cubes (Dobot) | S-06 37.7, S-07 11.9, S-10 0.5 and 3.0 | 3-8 degrees |
| Median position error, passed runs (Dobot) | 2.4 mm | 2-5 mm |

By category (Dobot, passed of run):

| Category | Study 4 | Predicted |
|---|---|---|
| move | 5 of 5 | 85-100% |
| swap | 1 of 5 | 40-70% |
| tower | 1 of 2 | 60-90% (S-12's E-STOP not yet explained) |
| drop | (not run) | 50-90% |

If swaps still miss their turns, look first at the angle the pick read against the watcher's (picks.csv `grip_r`
against the run's `start_seen` yaw) and at whether the turn check's reading moved by the turn asked.

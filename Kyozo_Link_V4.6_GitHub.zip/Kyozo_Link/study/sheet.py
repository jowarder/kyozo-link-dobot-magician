"""The study's sheet as a PDF, at exact size: print it at 100% ("actual size"), check its ruler measures 10 cm.

    python study/sheet.py                  the paper config.yaml names (study: paper), e.g. study/Letter_sheet.pdf
    python study/sheet.py --paper letter   US Letter (279.4 x 215.9 mm): study/Letter_sheet.pdf
    python study/sheet.py --paper a4       A4 (297 x 210 mm): study/A4_sheet.pdf

The spots and the centre are at the same robot positions on either paper: only the edges differ.

Landscape. The page's TOP edge goes towards the robot's base: facing the robot, its left (+y) is on your right. The
four corner spots are 25 mm cube outlines, each turned by the arm's angle there (app/vision/paper.py), so a cube put
on one is gripped squarely with the wrist in its middle; the straight outline in the middle is where "Cube calibration
with paper" starts. The geometry is app/vision/paper.py's -- the same the app scores against.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.vision import paper  # noqa: E402
from app.vision.paper import CUBE_MM, DESIGNED_CENTRE, SPOT_NAMES, SPOTS, designed_turn  # noqa: E402

PT_PER_MM = 72.0 / 25.4
PAGE_W, PAGE_H = paper.PAPER_MM      # landscape: the long side wide (the robot's left-right), the short high (out)
NEAR_X = DESIGNED_CENTRE[0] - PAGE_H / 2       # the robot's x at the page's top edge
FILES = {"a4": "A4_sheet.pdf", "letter": "Letter_sheet.pdf"}


def use(name: str) -> None:
    """Lay the page out for this paper ("a4" or "letter")."""
    global PAGE_W, PAGE_H, NEAR_X
    paper.use_paper(name)
    PAGE_W, PAGE_H = paper.PAPER_MM
    NEAR_X = DESIGNED_CENTRE[0] - PAGE_H / 2


def page_point(x: float, y: float) -> tuple[float, float]:
    """A robot point (mm) on the sheet as it lies where designed -> PDF points (origin bottom-left)."""
    u = PAGE_W / 2 + (y - DESIGNED_CENTRE[1])     # from the page's left edge; the robot's left is the page's right
    v = x - NEAR_X                                 # from the page's top edge (the robot side)
    return u * PT_PER_MM, (PAGE_H - v) * PT_PER_MM


def square(cx: float, cy: float, side: float, turn_deg: float) -> list[tuple[float, float]]:
    t = math.radians(turn_deg)
    c, s = math.cos(t), math.sin(t)
    return [(cx + dx * c - dy * s, cy + dx * s + dy * c)
            for dx, dy in ((-side / 2, -side / 2), (side / 2, -side / 2), (side / 2, side / 2), (-side / 2, side / 2))]


class Page:
    def __init__(self):
        self.ops: list[str] = []

    def line(self, points: list[tuple[float, float]], width_mm: float = 0.3, closed: bool = False,
             grey: float = 0.0) -> None:
        self.ops.append(f"{grey:.2f} G {width_mm * PT_PER_MM:.2f} w")
        (x0, y0), rest = points[0], points[1:]
        self.ops.append(f"{x0:.2f} {y0:.2f} m " + " ".join(f"{x:.2f} {y:.2f} l" for x, y in rest)
                        + (" h S" if closed else " S"))

    def text(self, x_pt: float, y_pt: float, words: str, size: float = 8.0, grey: float = 0.0) -> None:
        safe = words.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        self.ops.append(f"BT {grey:.2f} g /F1 {size:.1f} Tf {x_pt:.2f} {y_pt:.2f} Td ({safe}) Tj ET")

    def text_mm(self, u_mm: float, v_mm_from_top: float, words: str, size: float = 8.0, grey: float = 0.0) -> None:
        self.text(u_mm * PT_PER_MM, (PAGE_H - v_mm_from_top) * PT_PER_MM, words, size, grey)


def draw() -> Page:
    page = Page()
    w, h = PAGE_W * PT_PER_MM, PAGE_H * PT_PER_MM
    # a thin frame 4 mm in (printers can't reach the very edge; the camera finds the paper's own edge)
    m = 4 * PT_PER_MM
    page.line([(m, m), (w - m, m), (w - m, h - m), (m, h - m)], 0.2, closed=True, grey=0.75)
    # the robot side
    page.text_mm(PAGE_W / 2 - 34, 9, "TOP EDGE TOWARDS THE ROBOT'S BASE", 9)
    tip = (PAGE_W / 2) * PT_PER_MM, (PAGE_H - 11) * PT_PER_MM
    page.line([(tip[0] - 3 * PT_PER_MM, tip[1] - 4 * PT_PER_MM), tip, (tip[0] + 3 * PT_PER_MM, tip[1] - 4 * PT_PER_MM)],
              0.4)
    # the corner spots, turned for the wrist in its middle
    for number, (x, y) in SPOTS.items():
        turn = designed_turn(x, y)
        page.line([page_point(*p) for p in square(x, y, CUBE_MM, turn)], 0.5, closed=True)
        cx, cy = page_point(x, y)
        page.line([(cx - 2 * PT_PER_MM, cy), (cx + 2 * PT_PER_MM, cy)], 0.15, grey=0.4)
        page.line([(cx, cy - 2 * PT_PER_MM), (cx, cy + 2 * PT_PER_MM)], 0.15, grey=0.4)
        below = -24 if x > DESIGNED_CENTRE[0] else 27            # (the label on the side away from the edge)
        page.text(cx - 14 * PT_PER_MM, cy + below * PT_PER_MM,
                  f"SPOT {number}  {SPOT_NAMES[number]}", 9)
        page.text(cx - 14 * PT_PER_MM, cy + (below - 4) * PT_PER_MM, f"({x:.0f}, {y:.0f}) mm, turned {turn:.1f} deg",
                  6, grey=0.35)
    # the middle: the calibration's start
    cx, cy = DESIGNED_CENTRE
    page.line([page_point(*p) for p in square(cx, cy, CUBE_MM, 0.0)], 0.5, closed=True)
    for (ax, ay), (bx, by) in (((cx - 25, cy), (cx + 25, cy)), ((cx, cy - 25), (cx, cy + 25))):
        page.line([page_point(ax, ay), page_point(bx, by)], 0.2, grey=0.3)
    px, py = page_point(cx, cy)
    page.text(px + 15 * PT_PER_MM, py + 2 * PT_PER_MM, "CENTRE: calibration starts here", 8)
    page.text(px + 15 * PT_PER_MM, py - 2 * PT_PER_MM, f"({cx:.0f}, {cy:.0f}) mm, straight", 6, grey=0.35)
    # the ruler: 100 mm along the bottom (the far side from the robot)
    left, base = 20.0, PAGE_H - 12.0
    page.line([((left) * PT_PER_MM, (PAGE_H - base) * PT_PER_MM), ((left + 100) * PT_PER_MM, (PAGE_H - base) * PT_PER_MM)], 0.3)
    for k in range(11):
        tick = 3.0 if k % 5 == 0 else 1.5
        page.line([((left + 10 * k) * PT_PER_MM, (PAGE_H - base) * PT_PER_MM),
                   ((left + 10 * k) * PT_PER_MM, (PAGE_H - base + tick) * PT_PER_MM)], 0.25)
    page.text_mm(left, base + 4.5, "100 mm: measure it. Not 100 mm? Print again at 100% (actual size).", 7)
    page.text_mm(PAGE_W - 110, base + 4.5, f"Kyozo Link study sheet ({paper.PAPER_NAME}). Tape it underneath. "
                 "Cubes 25 mm.", 7, grey=0.35)
    return page


def write_pdf(path: Path, page: Page) -> None:
    stream = "\n".join(page.ops).encode("latin-1")
    w, h = PAGE_W * PT_PER_MM, PAGE_H * PT_PER_MM
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w:.2f} {h:.2f}] /Contents 4 0 R "
         f"/Resources << /Font << /F1 5 0 R >> >> >>").encode(),
        b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + body + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode()
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    path.write_bytes(bytes(out))


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--paper", choices=sorted(FILES), help="the paper (default: config.yaml's study: paper)")
    args = parser.parse_args()
    use(args.paper or paper.PAPER)
    path = Path(__file__).resolve().parent / FILES[paper.PAPER]
    write_pdf(path, draw())
    print(f"Wrote {path} ({paper.PAPER_NAME}) -- print it on {paper.PAPER_NAME} paper at 100% (actual size), "
          "landscape; check the ruler measures 100 mm.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

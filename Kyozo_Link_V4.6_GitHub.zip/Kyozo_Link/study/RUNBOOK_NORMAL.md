# Watcher Study Runbook: NORMAL mode (≤ 11 robot-hours) — Kyozo Link V3.8, GECA 2027

> **Superseded 2026-10-12 for its round plan:** the study now has three rounds and two improvements, with the tasks on a printed A4 sheet; see [RUNBOOK.md](RUNBOOK.md) and [PREREG.md](PREREG.md). This runbook is kept for its background; its rounds, modes, zones and layouts no longer apply.

*Rafiul Azim Jowarder, with Dr. Curry. Prepared 2026-10-09.*

> **This is the Normal mode runbook** (≈ 10.6 robot-hours, about 96 Dobot runs). The other mode is in [RUNBOOK_EXTENSIVE.md](RUNBOOK_EXTENSIVE.md); the comparison and the fallback rule are in [RUNBOOK.md](RUNBOOK.md). The mode is chosen **before round 1** and written in `PREREG.md`.

---

## 1. What we are doing and why

**Paper:** *"Closing the Loop"*, for **GECA 2027**, the IEEE Gulf Coast Conference on Energy, Communications & Automation.
- **Deadline Oct 30, 2026**; our internal target is **Oct 25**.
- Full papers are **8 pages including references**.
- Accepted papers go to **IEEE Xplore**.
- Tracks: *Industrial Automation & Digitalization*; *Condition Monitoring, Reliability & Predictive Maintenance*.

**Claim:** a low-cost, unreliable robot, the **Dobot Magician**, can be made more dependable by **AI-written code instead of better hardware**.

**How we show it:**
1. Claude writes a **watcher** (the "watching harness") that runs tasks on the Dobot without anyone typing, and records everything.
2. Claude improves Kyozo Link in **3 rounds**, using the watcher's **training** logs.
3. Every version is scored on **test** tasks it has never seen, in the **digital twin** (ideal hardware) and on the **real Dobot**.
4. **Hardware gap = twin success − Dobot success.** The rounds should close it. That is the main result.

**Dr. Curry's instructions (email):** *"Round zero just use the twin to do the task. Use it outside the harness. Round one use the twin and the actual equipment. Continue for three rounds."*

| Round | Digital twin | Physical Dobot | Watcher (harness) |
|---|---|---|---|
| 0, Baseline | ✅ test tasks | ✗ not required | ✗ not used |
| 1 | ✅ test tasks | ✅ test tasks | ✅ improvement round |
| 2 | ✅ test tasks | ✅ test tasks | ✅ improvement round |
| 3 | ✅ test tasks | ✅ test tasks | ✅ improvement round |

---

## 2. Study diagram

```
══════════════════════════════════════════════════════════════════════════════════════════════
 PHASE A — BUILD  (Oct 10–11)                                             Claude + you
══════════════════════════════════════════════════════════════════════════════════════════════
  Claude: fix 2 failing tests · add fixed Qwen seed                    ──► git tag  study-base
  Claude: task files (both cube sets) · PREREG.md · ROUND_PROMPT.md
  Claude: twin test script · Watcher (toolbar button + window)
  You:    try the Watcher in demo mode · email Dr. Curry the open choices
  After Dr. Curry replies: tasks FROZEN (test set OUTSIDE the project)  ──► git tag  study-v0

══════════════════════════════════════════════════════════════════════════════════════════════
 PHASE B — LAB SETUP  (once, ~2 h, no tape, no measuring)
══════════════════════════════════════════════════════════════════════════════════════════════
  Live mode · Home · test rotation · cube calibration
  Watcher ▸ Set up study area  → zones + layouts fitted inside "visible ∩ reachable" → Approve
  Dry run (2 tasks) · Watcher ▸ Characterize (Short) → TABLE 0 (repeatability, alarm map)

══════════════════════════════════════════════════════════════════════════════════════════════
 ROUND 0 — BASELINE  (Oct 11)                               Twin ✓   Dobot ✗   Watcher ✗
══════════════════════════════════════════════════════════════════════════════════════════════
  BASE ──► twin_test.py: 16 test tasks × 3 in the twin (automatic) ──► base score, ideal hardware

══════════════════════════════════════════════════════════════════════════════════════════════
 ROUND 1  (Oct 12–14)                                       Twin ✓   Dobot ✓   Watcher ✓
══════════════════════════════════════════════════════════════════════════════════════════════
  ① MEASURE BASE    TWIN : 16 test tasks × 3 (automatic)
                    DOBOT: 16 test tasks × 1 with the Watcher (~1.6 h) ──► physical baseline
                    test logs ──► OUTSIDE the project (Claude never sees them)
  ② TRAIN           DOBOT: 16 training tasks × 1 with the Watcher (~1.5 h)
                    ──► study/logs/round-1/train/ + round summary
  ③ IMPROVE         Claude reads the TRAINING logs ONLY ──► code changes + NARRATION_v1 + IDEAS
                    You review: accept/reject · your narration + hours
                    Gate: all tests + simulator scenes pass               ──► git tag study-v1.0

 ROUND 2  (Oct 14–16)   ① measure v1 (twin 16×3 + Dobot half set 8×1)  ② train  ③ Claude ──► v2.0
 ROUND 3  (Oct 16–18)   ① measure v2 (twin 16×3 + Dobot half set 8×1)  ② train  ③ Claude ──► v3.0

══════════════════════════════════════════════════════════════════════════════════════════════
 FINAL  (Oct 18)      measure v3 (twin 16×3 + Dobot 16×1)   (no drift session; self-check every session)
══════════════════════════════════════════════════════════════════════════════════════════════
 PHASE F — ANALYSIS + PAPER  (Oct 19–25)
   analyze.py → Table 0 · Table A (code) · Table B (narration) · Fig 1 · Fig 2 · statistics
   Dr. Curry re-rates 40 runs from photos · write · release data · submit Oct 25
══════════════════════════════════════════════════════════════════════════════════════════════
```

**What gets measured, version by version:**
| Version | Twin | Dobot |
|---|---|---|
| Base | Rounds 0 and 1 | Round 1 (physical baseline, 16 tasks × 1) |
| v1 | Round 2 | Round 2 (half set, 8 tasks × 1) |
| v2 | Round 3 | Round 3 (half set, 8 tasks × 1) |
| v3 | Final | Final (16 tasks × 1) |

---

## 3. Training vs test, in plain words

| | **Training** = homework | **Test** = exam |
|---|---|---|
| Purpose | Find the faults, so Claude can fix them | Check whether the fixes really work |
| Who sees the results | **Claude reads them** | **Claude never sees them** |
| Runs per version | 16 tasks × 1, on the Dobot | Dobot: 16 tasks × 1 for base and v3, the 8-task half set × 1 for v1 and v2 · Twin: 16 × 3 for every version |
| Where it's stored | `study/tasks/train.yaml`, `study/logs/round-N/train/` (inside the project) | `..\Kyozo_Link_study_test\` (**outside** the project) |

**Why two lists:** if Claude were scored on the jobs it learned from, it could fix just those exact cases. The test jobs are the same *kinds* of job with **new positions and wording**, so a better test score means the robot really improved.

---

## 4. Who does what

| Who | Job |
|---|---|
| **Watcher** (new) | Runs each task on the real Dobot without anyone typing. Draws where the cubes go, records everything, scores with the camera, counts alarms and interventions, writes the logs |
| **Twin test script** (new) | Runs the test tasks in the simulated twin automatically, as the ideal-hardware score |
| **Claude** | Phase A: builds everything. Rounds 1–3: reads the training logs, fixes the code, writes its narration and ideas |
| **You** | Lab setup, putting cubes on their outlines, giving a verdict after each run, reviewing Claude's changes, writing your narration and hours |
| **Dr. Curry** | Approves the tasks and rules, re-rates 40 runs from their photos, co-writes the paper |

---

## 5. The tasks

### 5.1 Setup
- **Cubes:** 25 mm. **Cube set to be decided by Dr. Curry:**
  - **Option A, 3 cubes:** 1 red, 1 blue, 1 green.
  - **Option B, 6 cubes:** 2 red, 2 blue, 2 green.

  Only 4 tasks differ between the two. One set is used for the **whole** study, and unused cubes stay off the table.
- **Zones A and B are virtual**, 80 × 80 mm. They're placed automatically inside the area the camera sees and the arm reaches, and drawn on the watcher's camera picture. **No tape.**
- **No stacking.**
- **Pass rule:** every target within **10 mm and 8°**, and no other cube moved more than **10 mm**.

### 5.2 Layouts
Robot coordinates in mm: x is forward, +y is the robot's left. These are starting values; **auto-layout fits them to your camera's view in Phase B.**

| Layout | Training | Test (′) |
|---|---|---|
| **L1** spread | red (200, 60) · blue (240, 0) · green (200, −60) | red (230, −50) · blue (190, 30) · green (250, 70) |
| **L3** crowded (10 mm gaps) | red (220, 35) · blue (220, 0) · green (220, −35) | red (210, −20) · blue (245, −20) · green (228, 15) |
| **L4** edge of reach | red (275, 60) · green (165, 40) · blue (120, −230) | red (170, −50) · blue (280, −40) · green (130, 220) |
| **L5** turned | red (200, 60) 15° · blue (240, 0) 30° · green (200, −60) 40° | red (230, −50) 40° · blue (190, 30) 15° · green (250, 70) 30° |
| **L2** sorting, **3-cube** | red (190, 80) · blue (250, −40) · green (220, 20) | red (250, 50) · blue (190, −70) · green (220, −5) |
| **L2** sorting, **6-cube** | red (190, 80), (250, −40) · blue (220, 20), (190, −80) · green (250, 60), (200, −20) | red (250, 50), (190, −70) · blue (200, 70), (250, −60) · green (220, −5), (180, 10) |
| **L2e** zone loaded, **3-cube** | zone A: red, blue · table: green (230, 0) | zone B: green, blue · table: red (230, 20) |
| **L2e** zone loaded, **6-cube** | zone A: red, blue · table: green (230, 0), red (200, −80) | zone B: green, blue · table: red (230, 20), green (195, 75) |

### 5.3 The 16 training and 16 test tasks
| Category | Training (Claude sees) | Test (Claude never sees) |
|---|---|---|
| **A** zone | L1 "Put the red cube in zone A." · L4 "Put the green cube in zone B." | L1′ "Place the blue cube in zone B." · L4′ "Move the red cube into zone A." |
| **B** relative move | L1 "Move the blue cube 4 cm to the left." · L1 "Move the green cube 3 cm towards the robot." | L1′ "Move the red cube 5 cm to the right." · L1′ "Move the blue cube 4 cm away from the robot." |
| **C** beside / between | L1 "Put the green cube to the right of the red cube, 10 mm apart." · L1 "Put the blue cube between the red and the green cube." | L1′ "Put the blue cube to the left of the green cube, 15 mm apart." · L1′ "Place the red cube between the blue and the green cube." |
| **D** rotation | L1 "Turn the red cube to 30 degrees." · L5 "Set all the cubes to 0 degrees." | L1′ "Turn the green cube to 45 degrees." · L5′ "Straighten all the cubes." |
| **E** rows | L1 "Line up the cubes 3 cm apart." · L5 "Line up the cubes." | L1′ "Put the cubes in a row, 3 cm apart." · L3′ "Line up the cubes." |
| **F** sorting, **3-cube** | L2 "Put the red cube in zone A and the blue cube in zone B." · L2 "Put all the cubes in zone A." | L2′ "Put the green cube in zone A and the red cube in zone B." · L2′ "Put all the cubes in zone B." |
| **F** sorting, **6-cube** | L2 "Put all the red cubes in zone A." · L2 "Put the red cubes in zone A and the blue cubes in zone B." | L2′ "Put all the blue cubes in zone B." · L2′ "Green cubes in zone A, red cubes in zone B." |
| **G** swap | L1 "Swap the red and the blue cube." · L3 "Swap the green and the red cube." | L1′ "Swap the green and the blue cube." · L3′ "Swap the red and the blue cube." |
| **H** undo / empty | L1 "Put the red cube in zone A" → "Put it back." · L2e "Empty zone A." | L1′ "Put the blue cube in zone B" → "Put it back." · L2e′ "Empty zone B." |

**Half set (Normal mode only; Dobot tests of v1 and v2):** the **first** test task in each category: A "Place the blue cube in zone B." · B "Move the red cube 5 cm to the right." · C "Put the blue cube to the left of the green cube, 15 mm apart." · D "Turn the green cube to 45 degrees." · E "Put the cubes in a row, 3 cm apart." · F the first sorting task of the chosen cube set · G "Swap the green and the blue cube." · H "Put the blue cube in zone B" → "Put it back." It is fixed in `PREREG.md` before round 1.

**Why these tasks:** the crowded layout (L3), the edge of reach (L4) and rotation (D, L5) hit the Dobot's known weak spots: the tight 27.5 mm gripper on 25 mm cubes, the joint-limit alarms 0x12 / 0x22 / 0x49, and the wrist range.

---

## 6. What the Watcher does

**Opening it:** in **live mode**, press **Watcher** on the main toolbar, after Settings. It opens a separate window.

**Its buttons:**
| Button | What it does |
|---|---|
| **Set up study area** | Once, in Phase B. Fits the zones and layouts into the area that is visible **and** reachable; you approve |
| **Characterize** | Once, in Phase B. Runs Table 0 |
| **Self-check** | Start of every session. Automatic drift check with one cube |
| **Start session** | Choose Training or Test and the round. **Mode: Normal** sets the tasks and repeats automatically |

**For each task:**
1. **Check:** the arm is connected with no alarm held; the camera and Qwen are OK.
2. **Ghost outlines:** the live camera picture shows a coloured outline where each cube goes, plus zones A and B. You drop each cube on its outline. It turns **green** within 5 mm and 5°, and the watcher shows any remaining correction ("red: 7 mm ←, turn 5°").
3. **Start run** lights up when every outline is green. Press it. **You don't type anything**: the watcher sends the fixed prompt, and Qwen and the arm do the task.
4. **Don't touch anything** during the run, except E-STOP in an emergency. It's on the window and the toolbar.
5. The arm **parks** out of view; the end pictures are saved.
6. **Your verdict first:** Pass / Fail / Dropped / I had to help.
7. **Then the watcher's score:** pass or fail, error in mm and degrees, cubes knocked. Disagreements are flagged. About 1 run in 5, it asks for a **caliper check**.
8. **Next.**

**What it records for every run:**
- every Qwen decision and tool call;
- every move sent to the arm;
- **every controller alarm**: its code (0x12 `PLAN_INV_LIMIT`, 0x22 `MOVE_INV_LIMIT`, 0x49 `LIMIT_AXIS23_NEG`…), the four joint angles, the target, and whether the app cleared it or **you** had to;
- refused moves, moves clamped to the safety box, E-STOPs, drops, Ollama or camera errors;
- the start and final positions, errors, score, failure type, your verdict, timings, raw pictures.

**Failure types**, fixed rules applied in this order:
1. **Infrastructure**: Ollama, camera or PC. The run is repeated.
2. **Plan**: Qwen chose the wrong cube or action.
3. **Limit alarm**: the arm couldn't reach the pose.
4. **Perception**: the app saw a cube more than 5 mm from where it was.
5. **Execution**: missed grip, slip, drop, placement or angle error.
6. **Unclassified.**

**Intervention:** any touch of the arm, cubes or table, or any app action (clearing an alarm, E-STOP, reconnect) during a run. That run is **not** an unassisted success.

**Where the logs go:** training → `study/logs/round-N/train/` plus a summary for Claude. Test → `..\Kyozo_Link_study_test\round-N\`, which Claude never sees.

---

## 7. What the twin does

- `study/twin_test.py` is a **plain script, not the watcher**, matching "outside the harness".
- For each test task it:
  1. places the cubes and zones in the simulated world **exactly**;
  2. sends the prompt to the **same Qwen**;
  3. runs **that version's code** on the simulated Dobot;
  4. scores the task from the **exact positions**.
- It's automatic: no app, no robot, no person, about 1–2 hours per version.
- **Twin passes, Dobot fails** → a **hardware** cause. **Both fail** → a **software or plan** cause.
- Its limits (an ideal grip that never misses, J4 limited to ±90°) are stated in the paper as the meaning of "ideal hardware".

---

## 8. Runbook: exact steps

> Some commands and buttons (`twin_test.py`, the **Watcher** button) are built by Claude in Phase A, before you need them.
>
> **Where to type the commands:** every `python ...` and `git ...` command runs in the app's own Python environment. Open **Anaconda Prompt**, then:
> ```
> conda activate dobot_vision
> cd "%USERPROFILE%\Desktop\Software_Development\Kyozo_link_oct4\Kyozo_Link"
> ```
> (The launchers `Run Kyozo Link.bat` and `Run Demo (no hardware).bat` already use this environment.)

### Phase A: Build (Oct 10–11)
| # | Who | Step |
|---|---|---|
| A1 | Claude | Fix the 2 failing tests (`tests/test_core.py:190`, `tests/test_hardware_realism.py:69`). Add `llm.seed` to `config.yaml` and pass it to Ollama. |
| A2 | You | Run `python -m unittest discover -s tests`: everything passes. Then `git tag study-base`. |
| A3 | Claude | Write the task files for both cube sets, `study/PREREG.md`, `study/ROUND_PROMPT.md`, and the folders `study/` and `..\Kyozo_Link_study_test\`. |
| A4 | You | Read the tasks. Email Dr. Curry the choices in §12. |
| A5 | Claude | Build `study/twin_test.py` and the watcher: toolbar button, window, ghost outlines, recorder, scorer, failure rules, self-check, auto-layout, Characterize. |
| A6 | You | Try it in **demo mode**: double-click `Run Demo (no hardware).bat` → **Watcher** → 3 training tasks. Tell Claude what's confusing; Claude fixes it. |
| A7 | You + Claude | When Dr. Curry replies, freeze the tasks and commit `PREREG.md`. Then `git tag study-v0`. **The watcher is frozen from now on.** |

### Phase B: Lab setup (once, about 1.5 h, no tape, no measuring)
| # | Step |
|---|---|
| B1 | Put the Dobot and the camera in place and **don't move them again** for the whole study. |
| B2 | Double-click `Run Kyozo Link.bat` → toolbar **Mode → Live** → wait until the robot and camera are connected → Manual tab → **Home**. |
| B3 | Test V3.7's rotation: a few picks of turned cubes. Note any problems for Claude. |
| B4 | **Calibration tab → cube calibration.** Don't touch the camera afterwards. The drift monitor warns if it moves. |
| B5 | **Watcher → Set up study area.** It shows the zones and layouts fitted inside the visible and reachable area. Press **Approve**. The coordinates are saved into the task files and frozen. |
| B6 | **Dry run:** Watcher → Training → 2 tasks. Check one result with a caliper against the watcher's score. |
| B7 | **Watcher → Characterize → Short** (about 30 min, E-STOP in reach). It produces Table 0: repeatability (20 visits) and the alarm map (positions × grip angles). No drift test in Normal mode. |

### Phase C: Round 0, twin baseline (Oct 11; about 10 min of your time)
| # | Step |
|---|---|
| C1 | Start **Ollama**. `ollama list` should show `qwen3:4b-instruct-2507-q4_K_M`. |
| C2 | `git checkout study-v0` |
| C3 | `python study/twin_test.py --version base --set test --repeats 3`, then leave it for 1–2 h. **No app, no Dobot, no watcher.** |
| C4 | Check that the summary shows 48 finished runs. Infrastructure failures (Ollama, camera, PC) are run again automatically, up to twice; the failed attempt is kept, marked *repeated*, and not counted. |
| C5 | Write your part of `study/NARRATION_v0.md` (what you asked for, what you accepted, hours). Export the Claude chat to `study/conversations/round-0/`. |

### Phase D: Rounds 1, 2, 3 (repeat three times)
Version: round 1 = **base** (`study-v0`); round 2 = **v1** (`study-v1.0`); round 3 = **v2** (`study-v2.0`).

| # | Step |
|---|---|
| D1 | `git checkout <version tag>` |
| D2 | **Twin test:** `python study/twin_test.py --version <name> --set test --repeats 3`. It runs on its own while you go to the lab. |
| D3 | **Open the app:** `Run Kyozo Link.bat` → **Mode → Live** → connected → **Watcher**. |
| D4 | **Self-check:** put one cube anywhere visible and press **Self-check**. If the watcher says *recalibrate*, do the cube calibration (B4) and run the self-check again. |
| D5 | **Dobot test:** round 1 (base): **Set: Test · Round: 1 · Tasks: All 16 · Repeats: 1 → Start session** (about 1.6 h). Rounds 2 and 3 (v1, v2): **Tasks: Half set (8) · Repeats: 1** (about 50 min). For each task: put the named cubes on their outlines (the rest go in the box) → **Start run** → hands off → verdict → caliper if asked → **Next**. Test logs go **outside** the project automatically. |
| D6 | **Dobot training (about 1.5 h):** **Set: Training · Round: N · Repeats: 1 → Start session**, same steps. You may use **Step-by-step** for the first 3 runs only. Logs go to `study/logs/round-N/train/`. |
| D7 | **Claude improves:** a new Claude session. Paste `study/ROUND_PROMPT.md` (the same text every round) and point Claude **only** at `study/logs/round-N/train/`. Claude changes the code and writes `study/NARRATION_vN.md` and rows in `study/IDEAS.md`. |
| D8 | **Your review:** accept, reject, or ask for more. Add your narration (what you asked, what you rejected, what surprised you, hours). Log any hand edit in `study/HAND_EDITS.md`. |
| D9 | **Gate:** `python -m unittest discover -s tests` and the simulator scenes must pass. If they don't, Claude fixes it first. |
| D10 | **Tag:** `git tag study-vN.0`. Export the Claude chat to `study/conversations/round-N/`. Go to D1 for the next round. |

### Phase E: Final (Oct 18–19)
| # | Step |
|---|---|
| E1 | `git checkout study-v3.0`, then the twin test (D2) and the Dobot test (D3-D5) with **Tasks: All 16 · Repeats: 1** (about 1.6 h). |
| E2 | No drift session in Normal mode. The self-check at the start of every session (D4) is the drift record. |
| E3 | Watcher → **Pick 40 for review**, and send Dr. Curry the start and end photos to rate. |

### Phase F: Analysis and paper (Oct 19–25)
| # | Step |
|---|---|
| F1 | `python study/analyze.py`, which makes Table 0, Table A, the Table B data, Fig. 1, Fig. 2, the statistics, and the list of compensation strategies (§10). |
| F2 | Write the paper with Dr. Curry: 8 pages including references. |
| F3 | Release the data package on Zenodo (§10). |
| F4 | **Submit by Oct 25** (deadline Oct 30). |

**Rules for the whole study:**
1. Claude never gets anything from `..\Kyozo_Link_study_test\`.
2. Never move the camera or the Dobot.
3. Same Qwen model, temperature 0.2 and seed throughout.
4. No step-by-step mode in test runs.
5. Write down your hours every day.
6. No hand edits to code. If one is ever unavoidable, log it.

---

## 9. What keeps the results believable
- **No leakage:** Claude sees training logs only. The test set and its logs are kept outside the project, with only their SHA-256 in git.
- **A frozen instrument:** the watcher, scorer and twin script are frozen at `study-v0`, and Claude is blocked from changing them (`.claude/settings.json` deny rules plus `ROUND_PROMPT.md`).
- **Registered in advance:** `PREREG.md` (tasks, pass rule, failure types, intervention definition, endpoints) is committed before round 1. Its SHA-256 goes in the paper.
- **Checks on the scoring:**
  - your verdict comes before the watcher's score;
  - caliper checks on about 1 run in 5;
  - Dr. Curry re-rates 40 runs (agreement reported as κ);
  - raw pictures are saved so any run can be re-scored.
- **Drift:** the automatic self-check every session and the drift monitor. (Normal mode has no final mixed session; the Limits section says so.)
- **Fixed settings:** the Qwen digest, temperature and seed; Claude's model; the same round prompt.

---

## 10. What the paper reports, and what makes it novel

**Results:**
- **Table 0, "the weak machine":** measured repeatability against the datasheet's 0.2 mm, the alarm map, and drift. No peer-reviewed measurement of the Magician turned up, so this is a contribution of its own.
- **Main result:** Dobot unassisted success on test tasks, **base vs v3**, compared task by task (exact sign-flip test, 95% bootstrap CI). With 16 tasks × 1 run, a gain of about **35 points or more** can be shown reliably; smaller gains are reported as trends alongside the mm and degree errors.
- **Fig. 1:** twin and Dobot success against lines of code. **The hardware gap closing.**
- **Fig. 2:** failures by type for each version (hardware vs software).
- **Reliability:** alarms per 100 moves, interventions per run, mean runs between interventions.
- **Costs:** your hours, Claude usage, robot hours, lines added and removed.
- **Table B:** Claude's narration and idea log, per round.

**Extra contributions (cheap, recommended):**
1. **A list of compensation strategies.** Every change is sorted by how the software makes up for the hardware: **Sense** (verify after placing), **Avoid** (steer clear of alarm areas, e.g. grip the cube from another side), **Recover** (auto-clear and retry), **Correct** (offset models), **Slow** (speed or approach). Each comes with its lines of code and the failures it removed. This answers a new question: *what an AI does to compensate for weak hardware.*
2. **Break-even cost:** the software route against buying a better arm.
3. **Open release:** tasks, PREREG, the watcher, all logs and pictures, the narrations, the Claude chats. Zenodo, with a DOI.
4. **Optional:** the **v1s** control (Claude improves from twin logs instead of Dobot logs, to show the real logs matter) and a 1-minute video.

**Novelty statement:** to our knowledge, no prior study has an AI revise a **complete application across versions** from the logs of a **monitoring harness it wrote itself**, on **low-cost real hardware**, measured on **held-out tasks** against **lines of code**. The closest 2025-2026 work changes behaviour *during* runs (HexaAnything, Code-as-Monitor, REFLECT) or works *in simulation* (RHO, ASPIRE). **Read every citation before using it.**

---

## 11. What gets built (for Claude)
- **App changes (small):**
  - the **Watcher** toolbar button after Settings (`app/ui/main_window.py:551-558`);
  - a recording hook on the Dobot driver's move, gripper and alarm paths (`app/hardware/dobot.py:180-475`);
  - `options.seed` in `app/llm/ollama_client.py:106`;
  - the Prompt tab locked while a session runs;
  - the 2 test fixes.
- **`watcher/` (frozen after round 0):**
  - `window.py`, the session state machine: check → ghost-outline setup → run → park → capture → verdict → reveal → save;
  - `ghost.py`, which projects target outlines onto the camera picture;
  - `auto_layout.py`, which fits the layouts into the visible and reachable area;
  - `self_check.py`;
  - `recorder.py`, `risk.py`, `scorer.py`, `taxonomy.py`;
  - `characterize.py`, for Table 0.
- **`study/`:**
  - `twin_test.py`, extending `Bench` and `run_case` from `tests/prompt_bench.py` and loading layouts with `TwinWorld.load_scenario_data` (`app/twin/world.py:137`);
  - `analyze.py`;
  - `tasks/`, `PREREG.md`, `ROUND_PROMPT.md`;
  - `NARRATION_v*.md`, `IDEAS.md`, `HAND_EDITS.md`;
  - `logs/`, `conversations/`.
- **Reused:**
  - the check helpers in `tests/prompt_bench.py:70-102`;
  - `app/llm/agent.py` (`Agent.run`, `approve`);
  - `app/llm/trace.py`;
  - `app/vision/scene.py`;
  - `app/vision/drift.py`;
  - saved places (`app/llm/tools.py:392`).
- **Verification:**
  - `python -m unittest discover -s tests` passes in full;
  - new `tests/test_watcher.py` covers the task checks, matching cubes to slots, the failure rules, alarm and intervention counting, and test logs landing outside the repo;
  - `twin_test.py` gives the same result twice with the fixed seed;
  - a demo-mode trial;
  - a real dry run.

---

## 12. Schedule and open choices

| Date | What |
|---|---|
| Oct 10–11 | Phase A (build) + email Dr. Curry |
| Oct 11 | Phase B (lab setup, Table 0) + **Round 0** (twin) |
| Oct 12–14 | **Round 1**: measure base, train, Claude makes v1 |
| Oct 14–16 | **Round 2**: measure v1, train, Claude makes v2 |
| Oct 16–18 | **Round 3**: measure v2, train, Claude makes v3 |
| Oct 18 | **Final**: measure v3 |
| Oct 19–25 | Analysis, writing, release, **submit Oct 25** (deadline Oct 30) |

**Robot time (Normal mode), at about 6 min per run including setup:**

| Part | Runs | Robot time |
|---|---|---|
| Dry run + short Table 0 | — | ~1 h |
| Training, rounds 1–3 (16 × 1 each) | 48 | ~4.8 h |
| Dobot test of base and v3 (16 × 1 each) | 32 | ~3.2 h |
| Dobot test of v1 and v2 (half set, 8 × 1 each) | 16 | ~1.6 h |
| **Total** | **96** | **≈ 10.6 h** |

**To confirm with Dr. Curry:**
1. **Cube set:** 3 cubes (1 R, 1 B, 1 G) or 6 cubes (2 of each).
2. **Normal mode:** 16 + 16 tasks; base and v3 tested on all 16 test tasks once on the Dobot, v1 and v2 on the 8-task half set; 3 times each in the twin (instead of 20 × 3).
3. Each round measures first, then improves, plus the final measurement of v3. This gives a physical base-vs-v3 comparison.
4. The watcher frozen after round 0; no step-by-step mode in test runs.
5. The extra contributions in §10.

---

## 13. Automatic saving: where everything goes (added 2026-10-09, at Rafi's request)

**Principle:** the watcher and the twin script save **everything automatically, the moment it happens**. There's no Save button and nothing to remember.
- Files are written atomically, so a crash never leaves half a file.
- Nothing is ever overwritten.
- A crashed or aborted run is still saved, marked *aborted*.

**Two root folders**, one per side of the "Claude must never see the test" rule:

```
Kyozo_Link\study\                         ← INSIDE the project (Claude may read)
├─ RUNBOOK*.md · PREREG.md · ROUND_PROMPT.md · IDEAS.md · HAND_EDITS.md · NARRATION_v*.md
├─ tasks\train.yaml
├─ setup\                                 study-area approval (zones, fitted layouts), calibration copies + hashes
├─ table0\                                Characterize results (repeatability, alarm map, drift)
├─ logs\round-N\train\                    TRAINING sessions on the Dobot (rounds 1–3)
│   └─ <session>\ …                       (structure below)
│   └─ ROUND_SUMMARY.md / .json           written automatically at session end: what Claude reads
├─ conversations\round-N\                 Claude chat exports (manual: Claude can't export its own chat)
└─ hours.csv                              engineer hours (you type); robot hours are filled in automatically

Kyozo_Link_study_test\                    ← OUTSIDE the project (Claude never reads)
├─ test.yaml                              the frozen test tasks
├─ round-0\twin\                          round 0 twin baseline
├─ round-N\twin\  ·  round-N\dobot\<session>\
├─ final\twin\  ·  final\dobot\  ·  final\drift\ (Extensive only)
└─ review\                                the 40 photo pairs for Dr. Curry (picked automatically)

Kyozo_Link_study_backup\                  ← automatic zip of each finished session (training and test), so a disk
                                            problem can't lose the study; copy it to OneDrive or a USB stick weekly
```

**Inside every session folder** (`<date>_<time>_<set>_<round>_<version>\`):
| File | Contents |
|---|---|
| `session.json` | mode (Normal/Extensive), set, round, version tag, git commit, Qwen model + digest, seed, temperature, calibration file + hash, task-file hash, operator, start/end time (gives robot hours) |
| `selfcheck.json` | the start-of-session self-check: landing error, pass/recalibrate |
| `runs\<NN>_<task-id>_r<repeat>\` | one folder per run (below) |
| `index.jsonl` | one line per run, each line hash-chained to the previous one (tamper-evident; aborted runs included) |
| `app_log.txt` | the app's own `app.log` lines from session start to end, copied automatically |
| `SESSION_SUMMARY.md` | success by category, failures by type, alarms, interventions, robot time |

**Inside every run folder:**
| File | Contents |
|---|---|
| `run.json` | everything in one place: the task, the measured start, the score, errors (mm, °), failure type, interventions, timings |
| `trace.json` | Qwen's full decision record (the app's `PromptTrace`) |
| `moves.csv` | every move sent to the arm: time, target pose, wrist angle, gripper, result |
| `alarms.csv` | every controller alarm: time, code (0x12 / 0x22 / 0x49 …), planning or moving, J1–J4, target, auto-cleared or by you |
| `observer.json` | your verdict and note, saved **before** the score is shown; caliper reading if asked |
| `start.png`, `end.png` + `start_depth.npz`, `end_depth.npz` | raw pictures, so any run can be re-scored later |

**The twin script** writes the same `run.json` / `trace.json` per run, under `...\twin\<date>_<time>_<version>\`, so `analyze.py` reads twin and Dobot results the same way.

**Git:** the study's text and JSON files are committed after each round. Pictures and depth files stay out of git (`.gitignore`) but are in the folders and the backup zips. The test folder is never committed. Only its `test.yaml` SHA-256 goes into `PREREG.md`.

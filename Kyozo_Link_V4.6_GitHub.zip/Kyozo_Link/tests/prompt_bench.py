"""The prompt test bench: typical requests, of every kind people ask, run through the real model (Ollama) in the demo
world, each one scored by what is on the table afterwards -- not by what the reply says.

    python tests/prompt_bench.py                       # every prompt, the Dobot, the model in config.yaml
    python tests/prompt_bench.py --robot xarm6 --only row,move --model qwen3:8b
    python tests/prompt_bench.py --list                # the prompts, without running anything
    python tests/prompt_bench.py --failed sessions/prompt_bench_dobot_magician_<time>.json   # only those that failed

Each prompt takes the model some 20-90 s: all of them, half an hour to an hour. Ollama must be running. It writes
nothing to config.yaml or calibration.json; the results go to sessions/prompt_bench_<robot>_<time>.json.

Not part of the unit tests (its name doesn't start with test_): it needs the model, and its scores are the model's.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness import ROOT  # noqa: E402  (sets up sys.path and the working folder)

import yaml  # noqa: E402

from app import robots  # noqa: E402
from app.hardware.gripper import GripperSpec  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402

CONTEXT_TOKENS = 8192      # as the app (MainWindow.MODEL_CONTEXT_TOKENS)
ANSWER_TIMEOUT_S = 300    # the first answer after loading reads the whole instructions: over 2 min on a CPU only


# ---- the demo world, as the app sets it up -------------------------------------------------------------------------
class Bench:
    def __init__(self, scenario: str):
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.llm.tools import ToolExecutor
        from app.twin.world import TwinWorld
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        profile = robots.active()
        self.world = TwinWorld()
        client = self.world.start()
        self.world.load_scenario(scenario)
        spec = GripperSpec.from_config({"gripper_type": "gripper"}, profile.gripper_defaults())
        self.robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                              max_reach_mm=profile.max_reach_mm, world=self.world, gripper=spec)
        self.robot.connect()
        camera = SimCamera(client)
        camera.outline_bodies = self.robot.body_ids
        camera.connect()
        look = Pose(*profile.demo_look_pose)
        self.robot.move_to(look)
        transform = camera.camera_to_robot_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: self.robot.arm_state()[0],
                                       self.world.places, self.world.place_areas)
        self.executor = ToolExecutor(self.robot, SceneBuilder(camera, detector, transform), look_pose=look,
                                     table_z_provider=lambda: 0.0, places_provider=self.world.places,
                                     place_areas_provider=self.world.place_areas, gripper=spec)
        self.start = self.snapshot()

    def stop(self) -> None:
        self.world.stop()

    def snapshot(self) -> dict:
        return {m["label"]: (self.world.get_object_position_mm(oid), self.world.get_object_yaw_deg(oid))
                for oid, m in self.world.object_meta.items() if m.get("shape") != "tray"}

    # what the checks ask
    def at(self, label: str):
        return self.snapshot()[label][0]

    def yaw(self, label: str) -> float:
        return self.snapshot()[label][1]

    def inside(self, label: str, place: str) -> bool:
        px, py, _ = self.world.places()[place]
        ix, iy, _ = self.world.place_areas()[place]
        x, y, _ = self.at(label)
        return abs(x - px) <= ix / 2 and abs(y - py) <= iy / 2

    def on(self, top: str, below: str) -> bool:
        (tx, ty, tz), (bx, by, bz) = self.at(top), self.at(below)
        return math.hypot(tx - bx, ty - by) < 15 and tz > bz + 8

    def moved(self, label: str, tolerance: float = 8.0) -> bool:
        return math.dist(self.at(label), self.start[label][0]) > tolerance

    def on_table(self, label: str) -> bool:
        return self.at(label)[2] < 16 and not any(self.inside(label, p) for p in self.world.place_areas())

    def angle_mod(self, label: str, period: float = 90.0) -> float:
        return self.yaw(label) % period


@dataclass
class Case:
    kind: str
    scenario: str
    prompt: str
    check: Callable[[Bench, list], tuple]        # (bench, tools called) -> (passed, detail)
    before: list = field(default_factory=list)   # prompts run first ("put it back" needs something to undo)


def ok(condition: bool, detail: str = "") -> tuple:
    return bool(condition), detail


def near(a: float, b: float, tolerance: float) -> bool:
    return abs(a - b) <= tolerance


def turned_to(b: Bench, label: str, degrees: float, period: float = 90.0) -> bool:
    diff = (b.yaw(label) - degrees) % period
    return min(diff, period - diff) <= 8.0


TWO = "two_blocks_and_tray"
MIXED = "mixed_objects"
SIZES = "size_sorting"
TOWER = "tower_building"
COLOURS = "colour_sorting"
C3 = ("red cube", "blue cube", "green cube")
FIVE = ("red cube", "blue cube", "green cube", "yellow cube", "purple cube")

CASES: list[Case] = [
    # -- the basics
    Case("basic", TWO, "Put the red cube in the tray", lambda b, t: ok(b.inside("red cube", "tray"))),
    Case("basic", TWO, "red cube in the tray", lambda b, t: ok(b.inside("red cube", "tray"))),
    Case("basic", TWO, "Put the blue cube on the red cube", lambda b, t: ok(b.on("blue cube", "red cube"))),
    Case("basic", TWO, "Stack green on blue", lambda b, t: ok(b.on("green cube", "blue cube"))),
    Case("basic", TWO, "Put the green cube to the right of the red cube, 10 mm apart",
         lambda b, t: ok(b.at("green cube")[1] < b.at("red cube")[1] - 20 and near(b.at("green cube")[0], b.at("red cube")[0], 12))),
    Case("basic", MIXED, "Blue bar next to the grey cylinder",
         lambda b, t: ok(math.dist(b.at("blue bar")[:2], b.at("grey cylinder")[:2]) < 70 and b.moved("blue bar"))),
    Case("basic", MIXED, "Put the pen in the tray", lambda b, t: ok(b.inside("blue bar", "tray"))),
    # -- several at once
    Case("several", TWO, "Put all the cubes in the tray", lambda b, t: ok(all(b.inside(c, "tray") for c in C3))),
    Case("several", COLOURS, "Sort the cubes by colour: warm colours in the warm bin, cool ones in the cool bin",
         lambda b, t: ok(b.inside("red cube", "warm bin") and b.inside("yellow cube", "warm bin")
                         and b.inside("green cube", "cool bin") and b.inside("blue cube", "cool bin"))),
    Case("several", SIZES, "Put the small cubes in the small bin and the large cubes in the large bin",
         lambda b, t: ok(b.inside("red cube", "small bin") and b.inside("green cube", "small bin")
                         and b.inside("yellow cube", "large bin") and b.inside("blue cube", "large bin"))),
    # -- towers
    Case("tower", TOWER, "Build a tower with all the cubes",
         lambda b, t: ok(sorted(b.at(c)[2] for c in ("red cube", "blue cube", "green cube", "yellow cube", "purple cube"))[-1] > 85)),
    Case("tower", TWO, "Make a tower: red at the bottom, then blue, then green",
         lambda b, t: ok(b.on("blue cube", "red cube") and b.on("green cube", "blue cube"))),
    Case("tower", TWO, "Build a tower of the three cubes in the tray",
         lambda b, t: ok(all(b.inside(c, "tray") for c in C3) and max(b.at(c)[2] for c in C3) > 45)),
    Case("tower", TOWER, "build a tower the red should be at the bottom and the purple should be at the third",
         lambda b, t: ok(_tower(b, FIVE)[:1] == ["red cube"] and _tower(b, FIVE)[2:3] == ["purple cube"],
                         " / ".join(_tower(b, FIVE)))),
    Case("tower", TOWER, "build a tower with all the cubes. make sure to put the green one at the third position from "
                         "bottom",
         lambda b, t: ok(_tower(b, FIVE)[2:3] == ["green cube"], " / ".join(_tower(b, FIVE)))),
    Case("tower", TWO, "build a tower with the cube outside of the tray",
         lambda b, t: ok(len(_tower(b, C3)) == 3 and not b.inside(_tower(b, C3)[0], "tray"))),
    Case("tower", TWO, "the tower should be outside of the tray",
         lambda b, t: ok(len(_tower(b, C3)) == 3 and not b.inside(_tower(b, C3)[0], "tray")),
         before=["Build a tower of the three cubes in the tray"]),
    Case("tower", TOWER, "Stack the yellow cube on the purple cube, then the red one on top",
         lambda b, t: ok(b.on("yellow cube", "purple cube") and b.on("red cube", "yellow cube"))),
    # -- turning
    Case("turn", MIXED, "Turn the brown block 45 degrees", lambda b, t: ok(abs(b.angle_mod("brown block", 180) - b.start["brown block"][1] % 180) > 30)),
    Case("turn", TWO, "Put the red cube in the tray at 45 degrees",
         lambda b, t: ok(b.inside("red cube", "tray") and turned_to(b, "red cube", 45))),
    Case("turn", TWO, "Set all the cubes to 30 degrees", lambda b, t: ok(all(turned_to(b, c, 30) for c in C3))),
    # -- rows
    Case("row", TWO, "Line up the cubes",
         lambda b, t: ok("line_up" in t and len({round(b.at(c)[0] / 6) for c in C3}) <= 2)),
    Case("row", TWO, "Put the cubes in a row, 3 cm apart",
         lambda b, t: ok("line_up" in t and _row_gaps(b, C3, 30))),
    Case("row", SIZES, "Arrange the cubes from smallest to largest",
         lambda b, t: ok("line_up" in t and _row_order(b, ["red cube", "green cube", "yellow cube", "blue cube"], small_first=True))),
    Case("row", TOWER, "Line up red, green and purple from left to right",
         lambda b, t: ok(b.at("red cube")[1] > b.at("green cube")[1] > b.at("purple cube")[1]
                         and near(b.at("red cube")[0], b.at("purple cube")[0], 8))),
    # -- relative moves
    Case("move", TWO, "Move the red cube 5 cm to the left",
         lambda b, t: ok(near(b.at("red cube")[1] - b.start["red cube"][0][1], 50, 8))),
    Case("move", TWO, "Move the blue cube 30 mm forward",
         lambda b, t: ok(near(b.at("blue cube")[0] - b.start["blue cube"][0][0], 30, 8))),
    Case("move", TWO, "Push the green cube a bit to the right",
         lambda b, t: ok(5 < b.start["green cube"][0][1] - b.at("green cube")[1] < 45)),
    Case("move", TWO, "Move the red cube 1 inch towards the robot",
         lambda b, t: ok(near(math.hypot(*b.start["red cube"][0][:2]) - math.hypot(*b.at("red cube")[:2]), 25, 9))),
    # -- taking apart, emptying
    Case("apart", TWO, "Take the tower apart", lambda b, t: ok(all(b.on_table(c) for c in C3)),
         before=["Build a tower with the three cubes"]),
    Case("apart", TWO, "Empty the tray", lambda b, t: ok(not any(b.inside(c, "tray") for c in C3)),
         before=["Put all the cubes in the tray"]),
    Case("apart", TWO, "Take everything out of the tray and put it on the left",
         lambda b, t: ok(not any(b.inside(c, "tray") for c in C3)), before=["Put all the cubes in the tray"]),
    Case("apart", TOWER, "dismantle the tower", lambda b, t: ok(len(_tower(b, FIVE)) == 0 and all(b.at(c)[2] < 16 for c in FIVE)),
         before=["Build a tower with all the cubes"]),
    Case("apart", TWO, "Unstack the cubes", lambda b, t: ok(all(b.on_table(c) for c in C3)),
         before=["Put the blue cube on the red cube"]),
    # -- between, swap
    Case("between", TWO, "Put the green cube between the red and the blue cube",
         lambda b, t: ok(math.dist(b.at("green cube")[:2], _mid(b, "red cube", "blue cube")) < 12)),
    Case("between", TWO, "Swap the red and the blue cube",
         lambda b, t: ok(math.dist(b.at("red cube")[:2], b.start["blue cube"][0][:2]) < 10
                         and math.dist(b.at("blue cube")[:2], b.start["red cube"][0][:2]) < 10)),
    Case("between", MIXED, "Swap the white cube and the black cube",
         lambda b, t: ok(math.dist(b.at("white cube")[:2], b.start["black cube"][0][:2]) < 10
                         and math.dist(b.at("black cube")[:2], b.start["white cube"][0][:2]) < 10)),
    # -- put back, undo, again
    Case("undo", TWO, "Put it back", lambda b, t: ok(not b.moved("red cube", 10)), before=["Put the red cube in the tray"]),
    Case("undo", TWO, "Undo that", lambda b, t: ok(not any(b.moved(c, 10) for c in C3)),
         before=["Put all the cubes in the tray"]),
    Case("undo", TWO, "Now do the same with the blue cube",
         lambda b, t: ok(b.inside("blue cube", "tray")), before=["Put the red cube in the tray"]),
    # -- position words
    Case("where", TWO, "Put the leftmost cube in the tray", lambda b, t: ok(b.inside("green cube", "tray"))),
    Case("where", TWO, "Put the cube on the right on top of the cube on the left",
         lambda b, t: ok(b.on("red cube", "green cube"))),
    Case("where", MIXED, "Put the object nearest the robot in the tray", lambda b, t: ok(b.inside("black cube", "tray"))),
    Case("where", TWO, "Take the cube out of the tray", lambda b, t: ok(not b.inside("red cube", "tray")),
         before=["Put the red cube in the tray"]),
    # -- speed
    Case("speed", TWO, "Slowly put the red cube in the tray",
         lambda b, t: ok("set_speed" in t and b.inside("red cube", "tray"))),
    Case("speed", TWO, "Carefully stack the blue cube on the green cube",
         lambda b, t: ok("set_speed" in t and b.on("blue cube", "green cube"))),
    # -- honest: what can't be done is said, not faked
    Case("honest", TWO, "Put the yellow cube in the tray", lambda b, t: ok(not any(b.moved(c) for c in C3))),
    Case("honest", TWO, "Put the red cube in the bin", lambda b, t: ok(not b.moved("red cube"))),
]


def _tower(b: Bench, labels) -> list[str]:
    """The labels bottom to top if they are all in one pile; [] otherwise."""
    points = {label: b.at(label) for label in labels}
    x, y = points[labels[0]][:2]
    if any(math.hypot(p[0] - x, p[1] - y) > 15 for p in points.values()):
        return []
    return sorted(labels, key=lambda label: points[label][2])


def _mid(b: Bench, a: str, c: str):
    (ax, ay, _), (cx, cy, _) = b.at(a), b.at(c)
    return (ax + cx) / 2, (ay + cy) / 2


def _row_gaps(b: Bench, labels, gap: float) -> bool:
    points = sorted((b.at(c) for c in labels), key=lambda p: p[1])
    return all(near(q[1] - p[1] - 20.0, gap, 8) and near(q[0], p[0], 8) for p, q in zip(points, points[1:]))


def _row_order(b: Bench, smallest_to_largest: list, small_first: bool) -> bool:
    ys = [b.at(c)[1] for c in smallest_to_largest]
    xs = [b.at(c)[0] for c in smallest_to_largest]
    small_ys, large_ys = ys[:2], ys[2:]
    in_line = max(xs) - min(xs) < 10 or max(ys) - min(ys) < 10
    if max(ys) - min(ys) < 10:          # a row near to far: by x
        small_ys, large_ys = xs[:2], xs[2:]
    return in_line and (max(small_ys) < min(large_ys) or min(small_ys) > max(large_ys))


# ---- running -------------------------------------------------------------------------------------------------------
def run_case(case: Case, model: str, config: dict) -> dict:
    from app.llm.agent import Agent
    from app.llm.ollama_client import OllamaClient
    bench = Bench(case.scenario)
    client = OllamaClient(endpoint=config["llm"]["endpoint"], keep_alive="30m", num_ctx=CONTEXT_TOKENS,
                          timeout_s=ANSWER_TIMEOUT_S, seed=config["llm"].get("seed"))
    agent = Agent(client, bench.executor, model, max_tool_calls=config["llm"].get("max_tool_calls", 20),
                  temperature=config["llm"].get("temperature", 0.2))
    result = {"kind": case.kind, "scenario": case.scenario, "prompt": case.prompt, "before": case.before}
    most_tokens = 0
    started = time.monotonic()
    try:
        for earlier in case.before:
            agent.run(earlier)
        # (bench.start stays as the scene was set out, before the `before` prompts: "put it back" / "undo that" are
        # checked against it. Taken after them, a cube rightly taken back out of the tray counted as "moved".)
        steps = []

        def on_step(step):
            steps.append(step)

        run = agent.run(case.prompt, on_step=on_step)
        for turn in (run.trace or {}).get("turns", []):
            most_tokens = max(most_tokens, int(((turn.get("stats") or {}).get("tokens_read")) or 0))
        tools = [s.tool_name for s in steps]
        passed, detail = case.check(bench, tools)
        result.update(passed=passed, detail=detail, reply=run.final_message, tools=tools,
                      calls=[{"tool": s.tool_name, "args": s.arguments, "result": str(s.result)[:300]} for s in steps],
                      errors=[s.result for s in steps if str(s.result).startswith("ERROR")],
                      goal=((run.trace or {}).get("end") or {}).get("goal"))
    except Exception as exc:  # noqa: BLE001 - one prompt failing to run is a result, not the end of the bench
        result.update(passed=False, detail=f"did not run: {exc}", reply="", tools=[], errors=[str(exc)])
    finally:
        bench.stop()
    result["seconds"] = round(time.monotonic() - started, 1)
    result["most_tokens_read"] = most_tokens
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--robot", default="dobot_magician", choices=["dobot_magician", "xarm6"])
    parser.add_argument("--model", default=None, help="default: llm.model in config.yaml")
    parser.add_argument("--only", default="", help="kinds to run, comma separated (e.g. row,move)")
    parser.add_argument("--list", action="store_true", help="print the prompts and stop")
    parser.add_argument("--failed", default="", help="only the prompts that failed in this earlier results file")
    args = parser.parse_args()
    cases = [c for c in CASES if not args.only or c.kind in args.only.split(",")]
    if args.failed:
        earlier = json.loads(Path(args.failed).read_text(encoding="utf-8"))["results"]
        failed = {(r["scenario"], r["prompt"]) for r in earlier if not r["passed"]}
        cases = [c for c in cases if (c.scenario, c.prompt) in failed]
    if args.list:
        for c in cases:
            print(f"{c.kind:8} {c.scenario:20} {c.prompt}" + (f"   (after: {'; '.join(c.before)})" if c.before else ""))
        print(f"{len(cases)} prompts")
        return 0
    config = yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
    model = args.model or config["llm"]["model"]
    robots.set_active(args.robot)
    # only this model in memory (two at once made every answer time out), and loaded before the first prompt's clock
    from app.llm.ollama_client import OllamaClient
    ollama = OllamaClient(endpoint=config["llm"]["endpoint"], keep_alive="30m", num_ctx=CONTEXT_TOKENS)
    try:
        installed = ollama.list_models()
    except Exception as exc:  # noqa: BLE001
        print(f"Ollama isn't reachable at {config['llm']['endpoint']} ({exc}). Start it and try again.")
        return 1
    if model not in installed:
        print(f"{model} isn't installed in Ollama. Installed: {', '.join(installed) or 'none'}")
        return 1
    unloaded = ollama.unload_others(model)
    if unloaded:
        print("Unloaded from Ollama first: " + ", ".join(unloaded))
    print(f"Loading {model}... ({ollama.load(model):.0f} s)")
    from app.llm.agent import SYSTEM_PROMPT
    from app.llm.tools import TOOL_SCHEMAS
    print(f"Reading the instructions, as the app does on loading... ({ollama.prepare(model, SYSTEM_PROMPT, TOOL_SCHEMAS):.0f} s)")
    print(f"{len(cases)} prompts, {model}, {args.robot}")
    results = []
    for i, case in enumerate(cases, 1):
        r = run_case(case, model, config)
        results.append(r)
        mark = "PASS" if r["passed"] else "FAIL"
        print(f"[{i}/{len(cases)}] {mark} {r['kind']:8} {r['seconds']:5.0f}s {r['most_tokens_read']:5} tok  "
              f"{case.prompt}  -> {', '.join(r['tools'])}", flush=True)
        if not r["passed"]:
            print(f"        reply: {r['reply'][:200]!r}" + (f"\n        errors: {r['errors'][:2]}" if r["errors"] else ""))
    kinds = sorted({r["kind"] for r in results}, key=[c.kind for c in CASES].index)
    print("\nBy kind:")
    for kind in kinds:
        mine = [r for r in results if r["kind"] == kind]
        print(f"  {kind:8} {sum(r['passed'] for r in mine)}/{len(mine)}")
    total = sum(r["passed"] for r in results)
    print(f"  {'all':8} {total}/{len(results)}   most tokens read in one turn: "
          f"{max((r['most_tokens_read'] for r in results), default=0)} of {CONTEXT_TOKENS}")
    out = ROOT / "sessions" / f"prompt_bench_{args.robot}_{time.strftime('%Y%m%d_%H%M%S')}.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps({"model": model, "robot": args.robot, "results": results}, indent=1, default=str),
                   encoding="utf-8")
    print(f"Saved: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

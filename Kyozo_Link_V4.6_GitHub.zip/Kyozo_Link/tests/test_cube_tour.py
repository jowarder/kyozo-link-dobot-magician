"""The demo's cube calibration walk-through (app/ui/cube_tour.py): Watch runs every step by itself with either cube
size, Practise follows along and says what isn't right, and Exit puts the demo back as it was.

    python -m unittest discover -s tests -p test_cube_tour.py -v

Uses a temporary folder for the calibration and config: nothing in the project changes.
"""
from __future__ import annotations

import math
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: E402  (sets up sys.path and the working folder)
import numpy as np  # noqa: E402
from PyQt6.QtWidgets import QApplication, QMessageBox  # noqa: E402

from app.calibration.cube import middle_turn  # noqa: E402
from app.calibration.storage import save_calibration  # noqa: E402
from app.config import load_config  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402

app = QApplication.instance() or QApplication([])


def pump_until(condition, timeout_s: float = 900.0) -> None:
    deadline = time.time() + timeout_s
    while not condition():
        if time.time() > deadline:
            raise TimeoutError("the walk-through did not finish in time")
        app.processEvents()
        time.sleep(0.02)


class TourTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        shutil.copy(ROOT / "config.yaml", Path(cls.folder.name) / "config.yaml")
        cls._original = (QMessageBox.question, QMessageBox.information, QMessageBox.warning)
        QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
        QMessageBox.information = staticmethod(lambda *a, **k: None)      # ("Bounds updated" after a calibration)
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
        config["display"] = {}
        cls.window = main_window_module.MainWindow(config)
        cls.window.show()
        cls.tour = cls.window.cube_tour
        cls.panel = cls.window.calibration_tab

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        QMessageBox.question, QMessageBox.information, QMessageBox.warning = cls._original
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def start(self, size: float, mode: str, lab: bool = False) -> None:
        tour = self.tour
        tour.size_box.setCurrentIndex(tour.size_box.findData(size))
        tour.mode_box.setCurrentIndex(tour.mode_box.findData(mode))
        tour.lab_box.setChecked(lab)
        tour.start()
        self.assertEqual(tour.mode, mode, tour.status.text())
        self.window.robot.max_speed = 3000          # fast: nobody is watching

    def exit(self) -> None:
        pump_until(lambda: not self.tour.busy())
        self.tour.exit()
        self.assertIsNone(self.tour.mode, self.tour.status.text())

    def exit_if_still_on(self) -> None:
        if self.tour.mode is not None:
            pump_until(lambda: not self.tour.busy())
            self.tour.exit()

    def test_watch_runs_every_step_with_a_25_mm_cube_like_the_lab_then_exit_puts_it_back(self):
        window, tour = self.window, self.tour
        path = window._calibration_path()
        save_calibration(path, np.eye(4) * 1.0, window.camera.get_intrinsics(), method="before",
                         reprojection_error_mm=9.9, num_samples=3)
        before = path.read_bytes()
        scene_before = window._twin_world.scenario.get("name")
        speed_before = window.robot.max_speed
        self.addCleanup(path.unlink, missing_ok=True)
        self.start(25.0, "watch", lab=True)
        self.addCleanup(self.exit_if_still_on)          # (failed part-way: the next test starts from a clean window)
        cube = window.tour_cube()
        self.assertIsNotNone(cube)
        self.assertAlmostEqual(cube[2], 25.0, delta=0.5)
        self.assertEqual(window.camera.faults, main_window_module.PRESETS["Realistic"])
        tour.run_to_end()
        pump_until(lambda: tour.index >= len(tour.steps) or (not tour.auto and not tour.waiting and not tour.busy()))
        self.assertEqual(tour.index, len(tour.steps), tour.status.text() + " / " + self.panel.result_label.text())
        fingers = self.panel.done_steps["fingers"].model
        self.assertTrue(fingers.trusted, fingers.problems)
        self.assertAlmostEqual(fingers.gain, 0.95, delta=0.02)
        off, on = self.panel.done_steps["rotation_off"], self.panel.done_steps["rotation_on"]
        self.assertLess(on.mean_deg, off.mean_deg)
        self.exit()
        self.assertEqual(path.read_bytes(), before, "the calibration in use before is back")
        self.assertEqual(window._twin_world.scenario.get("name"), scene_before)
        self.assertEqual(window.robot.max_speed, speed_before)
        self.assertEqual((window.robot.fingers_turned_deg, window.robot.wrist_gain, window.robot.wrist_backlash_deg),
                         (0.0, 1.0, 0.0))
        self.assertEqual(window.camera.faults, main_window_module.PRESETS["Perfect"])
        path.unlink()

    def test_watch_with_a_20_mm_cube_up_to_the_calibration(self):
        tour = self.tour
        self.start(20.0, "watch")
        self.assertAlmostEqual(self.window.tour_cube()[2], 20.0, delta=0.5)
        while tour.index < 6:
            tour.do_step()
            pump_until(lambda: not tour.waiting)
            self.assertNotIn("didn't finish", tour.status.text())
        self.assertTrue(self.panel.done_steps["cube"].passed)
        self.panel._finish_cube()
        self.exit()
        self.assertFalse(self.window._calibration_path().exists(), "no calibration before: the built-in one again")

    def test_the_calibration_tab_opens_on_one_cube_and_the_prompt_tab_puts_the_scene_back(self):
        window, tour, world = self.window, self.tour, self.window._twin_world
        window.tabs.setCurrentIndex(0)
        before = world.scenario.get("name")
        self.assertNotEqual(before, window.LEARN_SCENE)
        window.tabs.setCurrentWidget(self.panel)
        self.assertEqual(world.scenario.get("name"), window.LEARN_SCENE)
        self.assertEqual(len(world.object_meta), 1)
        self.assertAlmostEqual(window.tour_cube()[2], tour.size_box.currentData(), delta=0.5)
        tour.size_box.setCurrentIndex(tour.size_box.findData(25.0))          # another size: that cube instead
        self.assertAlmostEqual(window.tour_cube()[2], 25.0, delta=0.5)
        # the walk-through started and ended here comes back to the one-cube table, not to a file it can't find
        self.start(25.0, "watch")
        self.exit()
        self.assertEqual(world.scenario.get("name"), window.LEARN_SCENE)
        # a calibration under way (the table touched) keeps the cube when going to the Prompt tab...
        self.panel._touches = [(285.0, 0.0, 0.0)]
        window.tabs.setCurrentIndex(window._prompt_tab_index)
        self.assertEqual(world.scenario.get("name"), window.LEARN_SCENE)
        # ...and otherwise the scene comes back
        self.panel._touches = []
        window.tabs.setCurrentWidget(self.panel)
        window.tabs.setCurrentIndex(window._prompt_tab_index)
        self.assertEqual(world.scenario.get("name"), before)
        tour.size_box.setCurrentIndex(tour.size_box.findData(20.0))
        window.tabs.setCurrentIndex(0)

    def test_practise_follows_along_and_says_what_is_wrong(self):
        window, tour, robot = self.window, self.tour, self.window.robot
        self.start(25.0, "practise")
        tour.tick()
        self.assertIn("Home", tour.status.text())
        robot.home()
        tour.tick()
        self.assertEqual(tour.index, 1)
        x, y, top = window.tour_cube()
        far = (x + 55.0 * x / math.hypot(x, y), y)
        robot.move_to(Pose(far[0], far[1], 40.0, middle_turn(*far)))
        robot.move_to(Pose(far[0], far[1], 3.0, middle_turn(*far)))
        self.panel._touch_table()                     # 3 mm up: not touching
        pump_until(lambda: self.panel._worker is None)
        tour.tick()
        self.assertIn("didn't touch", tour.status.text())
        self.panel._forget_touches()
        robot.move_to(Pose(far[0], far[1], 0.0, middle_turn(*far)))
        self.panel._touch_table()
        pump_until(lambda: self.panel._worker is None)
        tour.tick()
        self.assertEqual(tour.index, 2, tour.status.text())
        near = (x - 55.0, y)
        robot.move_to(Pose(near[0], near[1], 40.0, middle_turn(*near)))
        robot.move_to(Pose(near[0], near[1], 0.0, middle_turn(*near)))
        self.panel._touch_table()
        pump_until(lambda: self.panel._worker is None)
        tour.tick()
        self.assertEqual(tour.index, 3, tour.status.text())
        robot.move_to(Pose(x, y, top + 30.0, middle_turn(x, y) + 20.0))
        tour.tick()
        self.assertIn("press 'Wrist to middle'", tour.status.text())
        self.panel._wrist_to_middle()
        pump_until(lambda: self.panel._worker is None)
        tour.tick()
        self.assertEqual(tour.index, 4, tour.status.text())
        robot.move_to(Pose(x + 3.0, y, top + 30.0, middle_turn(x + 3.0, y)))       # 3 mm off: too far for 25 mm
        tour.tick()
        self.assertIn("a finger would land on it", tour.status.text())
        robot.move_to(Pose(x, y, top + 30.0, middle_turn(x, y)))
        robot.move_to(Pose(x, y, top - robot.gripper.finger_depth_mm + 0.3, middle_turn(x, y)))
        robot.close_gripper()
        tour.tick()
        self.assertEqual(tour.index, 5, tour.status.text())
        self.assertEqual(self.panel.cube_btn.styleSheet().count("ffd166"), 1, "the next button is highlighted")
        robot.open_gripper()
        self.exit()
        self.assertNotIn("ffd166", self.panel.cube_btn.styleSheet())


if __name__ == "__main__":
    unittest.main()

"""Memory reporting and the language-model memory setting.

    python -m unittest discover -s tests -p test_memory.py -v
"""
from __future__ import annotations

import unittest
from unittest import mock

from harness import ROOT  # noqa: F401  (sets up sys.path and the working folder)
from app import memory, system_check
from app.llm.ollama_client import OllamaClient
from app.system_check import FAIL, OK, WARN, CheckContext


class FakeOllama:
    def __init__(self, models):
        self.models = models

    def loaded_models(self):
        return self.models


def context(ollama=None) -> CheckContext:
    return CheckContext(mode="demo", config={}, robot=None, camera=None, detector=None, get_transform=lambda: None,
                        calibrated=False, calibration_error_mm=None, calibration_file=None, ollama=ollama)


class MemoryNumbersTests(unittest.TestCase):
    def test_numbers_are_plausible(self):
        used = memory.app_memory_mb()
        system = memory.system_memory_gb()
        self.assertTrue(10 < used < 20000, used)
        total, free = system
        self.assertTrue(1 < total < 4000 and 0 < free <= total, system)


class MemoryCheckTests(unittest.TestCase):
    def run_check(self, app_mb, total, free, models):
        with mock.patch.object(system_check, "app_memory_mb", return_value=app_mb), \
                mock.patch.object(system_check, "system_memory_gb", return_value=(total, free)):
            return system_check._memory(context(FakeOllama(models)))[0]

    def test_plenty_of_memory_is_fine_and_says_who_uses_it(self):
        result = self.run_check(180.0, 15.4, 6.0, [{"name": "qwen3:8b", "size_gb": 5.9, "on_gpu_gb": 0.0}])
        self.assertEqual(result.status, OK)
        self.assertIn("180 MB", result.message)
        self.assertIn("qwen3:8b", result.message)

    def test_low_memory_points_at_the_model_and_how_to_free_it(self):
        result = self.run_check(180.0, 15.4, 1.0, [{"name": "qwen3:8b", "size_gb": 5.9, "on_gpu_gb": 0.0}])
        self.assertEqual(result.status, WARN)
        self.assertIn("keep_alive", result.fix)
        self.assertIn("qwen3:4b", result.fix)

    def test_an_app_that_has_ballooned_is_a_failure(self):
        result = self.run_check(4500.0, 15.4, 8.0, [])
        self.assertEqual(result.status, FAIL)
        self.assertIn("leaking", result.fix)


class OllamaClientTests(unittest.TestCase):
    def sent(self, **client_args):
        with mock.patch("app.llm.ollama_client.requests.post") as post:
            post.return_value.json.return_value = {"message": {"role": "assistant", "content": "hi"}}
            OllamaClient(**client_args).chat("qwen3:8b", [{"role": "user", "content": "x"}])
            return post.call_args.kwargs["json"]

    def test_keep_alive_is_sent_only_when_set(self):
        self.assertEqual(self.sent(keep_alive="30s")["keep_alive"], "30s")
        self.assertNotIn("keep_alive", self.sent())

    def test_the_seed_is_sent_with_every_answer_only_when_set(self):
        # the study keeps the model's seed fixed (llm: seed in config.yaml), so a request gets the same answer
        self.assertEqual(self.sent(seed=42)["options"]["seed"], 42)
        self.assertEqual(self.sent(seed=0)["options"]["seed"], 0)
        self.assertNotIn("seed", self.sent()["options"])

    def test_loaded_models_are_read_from_ollama(self):
        with mock.patch("app.llm.ollama_client.requests.get") as get:
            get.return_value.json.return_value = {"models": [{"name": "qwen3:8b", "size": 5.9e9, "size_vram": 0}]}
            models = OllamaClient().loaded_models()
        self.assertEqual(models[0]["name"], "qwen3:8b")
        self.assertAlmostEqual(models[0]["size_gb"], 5.9)

    def loaded(self, *names):
        return {"models": [{"name": name, "size": 5e9, "size_vram": 0} for name in names]}

    def test_switching_models_unloads_the_other_one(self):
        """Both in memory at once didn't fit in the RAM of a PC without a graphics card: prompts timed out."""
        with mock.patch("app.llm.ollama_client.requests.get") as get, \
                mock.patch("app.llm.ollama_client.requests.post") as post:
            get.return_value.json.return_value = self.loaded("qwen3:8b", "qwen3:4b")
            gone = OllamaClient().unload_others("qwen3:4b")
        self.assertEqual(gone, ["qwen3:8b"])
        self.assertEqual(post.call_args.kwargs["json"], {"model": "qwen3:8b", "keep_alive": 0})

    def test_a_timeout_with_two_models_loaded_says_so_and_frees_one(self):
        import requests
        with mock.patch("app.llm.ollama_client.requests.get") as get, \
                mock.patch("app.llm.ollama_client.requests.post") as post:
            get.return_value.json.return_value = self.loaded("qwen3:8b", "qwen3:4b")
            post.side_effect = [requests.Timeout("slow"), mock.DEFAULT]
            with self.assertRaises(TimeoutError) as raised:
                OllamaClient().chat("qwen3:4b", [{"role": "user", "content": "x"}])
        self.assertIn("qwen3:8b", str(raised.exception))
        self.assertIn("send the prompt again", str(raised.exception))
        self.assertEqual(post.call_args.kwargs["json"], {"model": "qwen3:8b", "keep_alive": 0})

    def test_installed_models_say_which_can_use_tools_and_which_always_think(self):
        shows = {"qwen3:4b": {"capabilities": ["completion", "tools", "thinking"],
                              "model_info": {"general.finetune": "Thinking"}},
                 "qwen3:4b-instruct-2507-q4_K_M": {"capabilities": ["tools", "completion"],
                                                   "model_info": {"general.finetune": "Instruct"}},
                 "llava:latest": {"capabilities": ["completion", "vision"], "model_info": {}}}
        with mock.patch("app.llm.ollama_client.requests.get") as get, \
                mock.patch("app.llm.ollama_client.requests.post") as post:
            get.return_value.json.return_value = {"models": [{"name": n, "size": 2.5e9} for n in shows]}
            post.side_effect = lambda url, json, timeout: mock.Mock(json=lambda: shows[json["model"]])
            models = {m.name: m for m in OllamaClient().installed_models()}
        self.assertTrue(models["qwen3:4b"].thinking_only)
        self.assertFalse(models["qwen3:4b-instruct-2507-q4_K_M"].thinking_only)
        self.assertFalse(models["llava:latest"].tools)
        from app.llm.models import choose
        self.assertEqual(choose(list(models.values()), "gone:7b"), "qwen3:4b-instruct-2507-q4_K_M")
        self.assertEqual(choose(list(models.values()), "qwen3:4b"), "qwen3:4b", "the one asked for, if it is there")

    def test_loading_keeps_the_model_for_the_apps_keep_alive(self):
        with mock.patch("app.llm.ollama_client.requests.post") as post:
            OllamaClient(keep_alive="30m").load("qwen3:8b")
        self.assertEqual(post.call_args.kwargs["json"], {"model": "qwen3:8b", "keep_alive": "30m"})

    def test_the_instructions_are_read_ahead_answering_one_token(self):
        """Read by the first prompt instead, they took about 2 minutes on a CPU, and it timed out."""
        with mock.patch("app.llm.ollama_client.requests.post") as post:
            OllamaClient(keep_alive="30m", num_ctx=8192).prepare("qwen3:8b", "You control a robot arm.", [{"x": 1}])
        sent = post.call_args.kwargs["json"]
        self.assertEqual(sent["messages"][0], {"role": "system", "content": "You control a robot arm."})
        self.assertEqual(sent["tools"], [{"x": 1}])
        self.assertEqual(sent["options"], {"num_predict": 1, "num_ctx": 8192})
        self.assertEqual(sent["keep_alive"], "30m")

    def test_the_context_size_goes_with_every_request_and_the_load(self):
        """Ollama's own 4096 tokens: "request (4287 tokens) exceeds the available context size"."""
        self.assertEqual(self.sent(num_ctx=8192)["options"]["num_ctx"], 8192)
        self.assertNotIn("num_ctx", self.sent()["options"])
        with mock.patch("app.llm.ollama_client.requests.post") as post:
            OllamaClient(num_ctx=8192).load("qwen3:8b")
        self.assertEqual(post.call_args.kwargs["json"]["options"], {"num_ctx": 8192})

    def test_a_too_long_conversation_says_so_plainly(self):
        import requests
        response = mock.Mock(status_code=400, text='{"error":"request (4287 tokens) exceeds the available context '
                                                   'size (4096 tokens), try increasing it"}')
        error = requests.HTTPError("400", response=response)
        with mock.patch("app.llm.ollama_client.requests.post") as post:
            post.return_value.raise_for_status.side_effect = error
            with self.assertRaises(RuntimeError) as raised:
                OllamaClient(num_ctx=4096).chat("qwen3:8b", [{"role": "user", "content": "x"}])
        self.assertIn("too long for the model", str(raised.exception))

    def test_unreachable_ollama_means_no_models_not_an_error(self):
        import requests
        with mock.patch("app.llm.ollama_client.requests.get", side_effect=requests.ConnectionError("down")):
            self.assertEqual(OllamaClient().loaded_models(), [])


if __name__ == "__main__":
    unittest.main()

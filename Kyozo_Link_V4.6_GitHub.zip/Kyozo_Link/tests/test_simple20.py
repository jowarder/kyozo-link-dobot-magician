"""Simple 20 (study/tasks/simple.yaml): three cubes put down once, 20 tasks run by themselves, every run saved, towers
scored though the camera sees only their top -- and Watcher active, a typed prompt recorded as a run.

    python -m unittest discover -s tests -p test_simple20.py -v
"""
from __future__ import annotations

import json
import math
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import test_watcher as tw          # (its set-up: the results folder a temporary one, the paper the design's)
from test_watcher import ROOT, STUDY_TRAIN, _make_test_tasks_module
from watcher import results
from watcher.tasks import Cube, load_task_set, score

SIMPLE = ROOT / "study" / "tasks" / "simple.yaml"


def camera_view(cubes):
    """What a camera from above sees: a cube with another on it is hidden."""
    from watcher.tasks import stacked
    return [c for c in cubes if not any(o is not c and o.level > c.level and stacked(c, o) for o in cubes)]


class SimpleTwentyTaskTests(unittest.TestCase):
    """The set itself, and the scoring of towers: what the camera can't see under a tower is there all the same."""

    def test_every_task_is_ready_from_the_last_one_passes_done_and_fails_left_alone(self):
        from watcher.arrange import check_start, predicted_end
        from watcher.tasks import layout_cubes, with_hidden
        tasks = load_task_set(SIMPLE, 3)
        self.assertEqual((len(tasks.tasks), tasks.chained, tasks.time_limit_s), (20, True, 600.0))
        self.assertEqual([sum(t.level == n for t in tasks.tasks) for n in range(1, 5)], [5, 5, 5, 5], "4 groups of 5")
        seen = layout_cubes(tasks)
        for task in tasks.tasks:
            self.assertIsNone(check_start(task, tasks, seen), task.id)
            full = with_hidden(seen, [task.tower]) if task.tower else seen
            _, end, _, problem = predicted_end(task, tasks, full)
            self.assertIsNone(problem, task.id)
            ideal = camera_view(list(end.values()))
            self.assertTrue(score(task, ideal, tasks.zones, tasks.rule, 25, start=seen).passed, task.id)
            self.assertFalse(score(task, seen, tasks.zones, tasks.rule, 25, start=seen).passed,
                             f"{task.id}: doing nothing never passes")
            if task.id == "S-05":                                # (the end of group A: back as it began)
                for c in ideal:
                    want = tasks.start_layout[c.color]
                    self.assertLess(math.hypot(c.x - want[0], c.y - want[1]), 1.0, f"{task.id}: {c.label}")
            seen = ideal

    def test_the_task_checker_passes_it(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("check_tasks", ROOT / "study" / "check_tasks.py")
        check_tasks = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(check_tasks)
        problems, counts = check_tasks.check(SIMPLE)
        self.assertEqual(problems, [])
        self.assertEqual((counts["tower"], counts["drop"]), (8, 2))

    def test_a_cube_under_a_tower_is_there_though_unseen(self):
        from watcher.tasks import with_hidden
        top = Cube("blue cube", 230, 0, 10, level=3)
        filled = with_hidden([top], [["green cube", "red cube", "blue cube"]])
        self.assertEqual({(c.label, c.level, c.x, c.y) for c in filled},
                         {("green cube", 1, 230, 0), ("red cube", 2, 230, 0), ("blue cube", 3, 230, 0)}, "both under the blue one")
        side = Cube("green cube", 236, 4, 0, level=1)          # (its side face seen, a few mm off)
        filled = with_hidden([Cube("red cube", 230, 0, 0, level=2), side], [["green cube", "red cube"]])
        green = next(c for c in filled if c.label == "green cube")
        self.assertEqual((green.x, green.y), (230, 0), "taken to be under the red one")
        self.assertEqual(with_hidden([Cube("red cube", 230, 0)], [["green cube", "red cube"]]),
                         [Cube("red cube", 230, 0)], "not a tower: nothing added")

    def test_a_tower_scores_its_height_and_place(self):
        tasks = load_task_set(SIMPLE, 3)
        task = tasks.task("S-11")                                  # red on green
        start = [Cube("red cube", 230, 60), Cube("green cube", 230, 0), Cube("blue cube", 230, -60)]
        blue = Cube("blue cube", 230, -60)

        def scored(*end):
            return score(task, list(end), tasks.zones, tasks.rule, 25, start=start)
        self.assertTrue(scored(Cube("red cube", 233, 2, level=2), blue).passed, "on it (green hidden)")
        self.assertFalse(scored(Cube("red cube", 245, 2, level=2), blue).passed, "15 mm off")
        result = scored(Cube("red cube", 230, 25), Cube("green cube", 230, 0), blue)
        self.assertFalse(result.passed, "beside it, not on it")
        self.assertIn("1 cube(s) up, wanted 2", result.targets[0].detail)
        self.assertFalse(scored(Cube("red cube", 233, 2, level=2), Cube("blue cube", 230, -40)).passed,
                         "the blue one knocked 20 mm")
        three = tasks.task("S-17")                                 # green, red, blue on top
        result = score(three, [Cube("blue cube", 231, 1, level=3)], tasks.zones, tasks.rule, 25, start=start)
        self.assertTrue(result.passed, result.as_dict())
        self.assertIn("middle cube is hidden", result.targets[0].detail)
        on_top = score(tasks.task("S-01"), [Cube("red cube", 270, 60, level=2), Cube("green cube", 230, 0), blue],
                       tasks.zones, tasks.rule, 25, start=start)
        self.assertFalse(on_top.passed, "in the right place, but on top of something")

    def test_partial_credit_says_how_close_it_came(self):
        from watcher.tasks import partial_credit
        tasks = load_task_set(SIMPLE, 3)
        start = [Cube("red cube", 230, 70), Cube("green cube", 230, 0), Cube("blue cube", 230, -70)]
        green, blue = Cube("green cube", 230, 0), Cube("blue cube", 230, -70)

        def credit(task_id, *end):
            result = score(tasks.task(task_id), list(end), tasks.zones, tasks.rule, 25, start=start)
            got = partial_credit(result, tasks.rule)
            return result.passed, got["score"], got["band"]
        self.assertEqual(credit("S-01", Cube("red cube", 270, 70), green, blue), (True, 100, "Full"))
        self.assertEqual(credit("S-01", Cube("red cube", 255, 70), green, blue), (False, 75, "Partial"), "15 mm off")
        self.assertEqual(credit("S-01", Cube("red cube", 230, 70), green, blue), (False, 0, "Fail"), "nothing done")
        self.assertEqual(credit("S-01", Cube("red cube", 270, 70), green, Cube("blue cube", 230, -40)),
                         (False, 75, "Partial"), "done, but the blue cube knocked: -25")
        self.assertEqual(credit("S-01", Cube("red cube", 270, 70), green), (False, 50, "Partial"),
                         "done, but the blue cube knocked off the table: -50")
        self.assertEqual(credit("S-06", Cube("red cube", 230, 0), Cube("green cube", 230, 70), blue),
                         (False, 50, "Partial"), "swapped, not turned")
        self.assertEqual(credit("S-11", Cube("red cube", 242, 0, 0, 2), blue), (False, 95, "Full"), "a tower 12 mm off")
        self.assertEqual(credit("S-11", Cube("red cube", 230, 30), green, blue)[1], 0, "beside it, not on it")
        self.assertEqual(credit("S-20", Cube("red cube", 230, 70), green, Cube("blue cube", 215, -70)),
                         (False, 83, "Partial"), "a drop 25 mm off: its own, looser ramp")

    def test_the_set_out_looks_again_when_a_reading_was_unsteady(self):
        from watcher.setout import SetOutError, set_out

        class Tools:                               # (the green cube's first pick refused, as on the Dobot)
            def __init__(self, refusals):
                self.refusals, self.calls = refusals, []
                self.where = {"red cube": (230, 70), "green cube": (251, 37), "blue cube": (230, -70)}
                self.held = None

            def _release_z(self, z):
                return z + 26.0

            def execute(self, tool, args):
                self.calls.append(tool)
                if tool == "list_objects":
                    return repr({"holding": None, "objects": [{"id": f"obj_{i}", "label": lab, "xyz_mm": (x, y, -8)}
                                                              for i, (lab, (x, y)) in enumerate(self.where.items())]})
                if tool == "pick":
                    if self.refusals:
                        self.refusals -= 1
                        raise ValueError("Can't pick up the green cube: the camera's reading of which way it is "
                                         "turned kept changing (by up to 8°). Call list_objects to look again")
                    self.held = list(self.where)[int(args["object_id"].split("_")[1])]
                    return f"Picked up {self.held}"
                if tool == "place":
                    self.where[self.held] = (args["x"], args["y"])
                    return "Placed"
                raise AssertionError(tool)
        targets = {"red cube": (230, 70), "green cube": (230, 0), "blue cube": (230, -70)}
        tools = Tools(refusals=2)
        steps = set_out(tools, Path("."), -32.0, targets)
        self.assertEqual(tools.where["green cube"], (230, 0), "picked on the third try, then put on its spot")
        self.assertEqual(sum(s["result"].startswith("ERROR") for s in steps), 2, "both refusals logged")
        with self.assertRaises(SetOutError):              # (unsteady three times: given up, said)
            set_out(Tools(refusals=3), Path("."), -32.0, targets)

    def test_the_start_check_knows_towers(self):
        from watcher.arrange import check_start
        tasks = load_task_set(SIMPLE, 3)
        blue = Cube("blue cube", 230, -60)
        self.assertIsNone(check_start(tasks.task("S-12"), tasks, [Cube("red cube", 230, 0, level=2), Cube("blue cube", 230, 70)]),
                          "green under the red: unseen, there")
        self.assertIn("starts from a tower", check_start(tasks.task("S-12"), tasks,
                                                          [Cube("red cube", 230, 60), Cube("green cube", 230, 0), blue]))
        self.assertIn("on top of another cube", check_start(tasks.task("S-01"), tasks,
                                                             [Cube("red cube", 230, 0, level=2), blue]))

    def test_the_finder_says_how_many_cubes_up(self):
        from watcher.finder import HEIGHT_RANGE, level_of
        self.assertEqual([level_of(h, 25) for h in (24, 27, 49, 52, 76)], [1, 1, 2, 2, 3])
        self.assertGreaterEqual(HEIGHT_RANGE[1] * 25, 80, "a tower of three's top is still a cube")

    def test_the_twin_sets_out_where_a_task_starts(self):
        from watcher.arrange import chain_start
        tasks = load_task_set(SIMPLE, 3)
        self.assertEqual({(c.label, c.x, c.y, c.level) for c in chain_start(tasks, "S-01")},
                         {("red cube", 230, 70, 1), ("green cube", 230, 0, 1), ("blue cube", 230, -70, 1)})
        tower = {c.label: c.level for c in chain_start(tasks, "S-18")}
        self.assertEqual(tower, {"green cube": 1, "red cube": 2, "blue cube": 3}, "S-18 starts from the tower of three")

    def test_a_run_the_app_never_finished_is_kept_as_crashed(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            first = results.Session.start(False, "simple", "dobot", 1, "base", {}, root=Path(folder))
            run = first.run_folder("S-03", 1)
            (run / "start.png").write_bytes(b"png")
            time.sleep(1.1)                        # (the next sitting's folder: another second)
            second = results.Session.start(False, "simple", "dobot", 1, "base", {}, root=Path(folder))
            self.assertEqual(second.recover_crashed(), [run.name])
            kept = results.raw_folder(second.kind_folder) / f"{run.name}__crashed"
            self.assertTrue((kept / "start.png").exists())
            self.assertIn("never finished", (kept / "why.txt").read_text(encoding="utf-8"))
            line = json.loads((second.folder / "index.jsonl").read_text(encoding="utf-8").splitlines()[-1])
            self.assertEqual(line["crashed"], run.name)
            self.assertIn("20_Tasks_for_Dobot", str(second.kind_folder))

    def test_a_run_scored_and_never_saved_is_kept_not_counted(self):
        # (reviewer 2, 2026-10-27: a _pending folder with its run.json -- left at Save or Discard -- was skipped)
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            first = results.Session.start(False, "simple", "dobot", 1, "base", {}, root=Path(folder))
            run = first.run_folder("S-04", 1)
            results.write_json(run / "run.json", {"task": "S-04", "passed": True})
            time.sleep(1.1)
            second = results.Session.start(False, "simple", "dobot", 1, "base", {}, root=Path(folder))
            self.assertEqual(second.recover_crashed(), [run.name])
            kept = results.raw_folder(second.kind_folder) / f"{run.name}__crashed"
            self.assertEqual(json.loads((kept / "run.json").read_text(encoding="utf-8"))["excluded"], "never saved")
            self.assertIn("never saved", (kept / "why.txt").read_text(encoding="utf-8"))


class ReviewerTwoTests(unittest.TestCase):
    """The watcher's review of 2026-10-27 (Dr. Curry approved the fixes)."""

    def setUp(self):
        self.tasks = load_task_set(SIMPLE, 3)
        self.start = [Cube("red cube", 230, 70), Cube("green cube", 230, 0), Cube("blue cube", 230, -70)]

    def score(self, task_id, end, start=None):
        return score(self.tasks.task(task_id), end, self.tasks.zones, self.tasks.rule, self.tasks.cube_size_mm,
                     start=start or self.start)

    def test_a_swap_with_one_cube_knocked_off_isnt_full_marks(self):
        from watcher.tasks import partial_credit
        end = [Cube("green cube", 230, 0), Cube("blue cube", 230, 70, yaw=30)]       # red swept off the table
        result = self.score("S-07", end)
        self.assertFalse(result.passed)
        self.assertIsNone(result.targets[0].position_error_mm, "no error from the blue cube alone")
        self.assertLess(partial_credit(result, self.tasks.rule)["score"], 90)
        both = [Cube("red cube", 230, -70), Cube("green cube", 230, 0), Cube("blue cube", 230, 70, yaw=30)]
        self.assertTrue(self.score("S-07", both).passed, "a real swap still passes")

    def test_the_cube_a_beside_target_is_measured_from_may_be_nudged(self):
        start = [Cube("green cube", 230, 70), Cube("red cube", 230, 70, level=2), Cube("blue cube", 230, -70)]
        size = self.tasks.cube_size_mm
        end = [Cube("green cube", 245, 70), Cube("red cube", 245, 70 - size - 50), Cube("blue cube", 230, -70)]
        result = self.score("S-12", end, start=start)                  # the tower base nudged 15 mm by the lift
        self.assertTrue(result.passed, result.collateral)
        self.assertFalse(result.collateral)
        moved_blue = end[:2] + [Cube("blue cube", 245, -70)]
        self.assertFalse(self.score("S-12", moved_blue, start=start).passed, "a cube the task doesn't name: still")

    def test_a_45_degree_turn_says_the_other_way_ends_the_same(self):
        end = [Cube("red cube", 230, 0, yaw=45), Cube("green cube", 230, 70), Cube("blue cube", 230, -70)]
        result = self.score("S-06", end)
        self.assertTrue(result.passed)
        self.assertIn("the other way it ends the same", result.targets[1].detail)
        end7 = [Cube("red cube", 230, -70), Cube("green cube", 230, 0), Cube("blue cube", 230, 70, yaw=30)]
        self.assertNotIn("other way", self.score("S-07", end7).targets[1].detail, "30 degrees: the way shows")

    def test_a_pass_is_a_pass_whatever_failed_after(self):
        from watcher.taxonomy import INFRASTRUCTURE, RunFacts, classify
        task = self.tasks.task("S-07")
        end = [Cube("red cube", 230, -70), Cube("green cube", 230, 0), Cube("blue cube", 230, 70, yaw=30)]
        result = self.score("S-07", end)
        facts = RunFacts(infrastructure_error="ReadTimeout: Ollama")
        self.assertIsNone(classify(task, result, facts, self.start, end, seen_start=self.start))
        self.assertEqual(classify(task, self.score("S-07", self.start), facts, self.start, self.start,
                                  seen_start=self.start), INFRASTRUCTURE)

    def test_a_chained_sets_infrastructure_failures_and_unscored_runs_arent_counted(self):
        import tempfile
        from watcher import overview
        with tempfile.TemporaryDirectory() as folder:
            s = results.Session.start(False, "simple", "dobot", 1, "base", {}, root=Path(folder))
            rows = [("S-01", {"passed": True}), ("S-02", {"passed": False, "excluded": "infrastructure"}),
                    ("S-03", {"passed": False, "excluded": "not scored"}), ("S-04", {"passed": False})]
            for task_id, run in rows:
                pending = s.run_folder(task_id, 1)
                results.write_json(pending / "run.json", dict(run, task=task_id, level=1))
                s.save_run(pending, task_id, "1")
            stats = overview.kind_stats(s.kind_folder)
            self.assertEqual(stats["counted"], 2, stats)
            self.assertEqual(stats["not_counted_infrastructure"], 2)

    def test_csvs_have_one_line_ending(self):
        import tempfile
        from watcher import window
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "moves.csv"
            window._write_csv(path, ["a", "b"], [[1, 2], [3, 4]])
            self.assertNotIn(b"\r\r\n", path.read_bytes())
            self.assertEqual(path.read_text(encoding="utf-8").splitlines(), ["a,b", "1,2", "3,4"])

    def test_a_chained_sets_time_limit_is_its_files(self):
        from watcher.window import CHAINED_TIME_LIMIT_S, WatcherWindow
        test = SimpleNamespace(tasks=SimpleNamespace(time_limit_s=300.0, chained=True))
        self.assertEqual(WatcherWindow._time_limit(test), 300.0, "the unseen test: 5 minutes, as PREREG 3")
        none = SimpleNamespace(tasks=SimpleNamespace(time_limit_s=None, chained=True))
        self.assertEqual(WatcherWindow._time_limit(none), CHAINED_TIME_LIMIT_S)
        self.assertEqual(load_task_set(SIMPLE, 3).time_limit_s, 600.0, "Simple 20: 10 minutes, its own")

    def test_i_had_to_help_is_no_verdict_on_the_end(self):
        from watcher import report
        run = {"task": "S-07", "passed": True, "observer": {"verdict": "helped"}}
        self.assertIsNone(report.build_report(run, {})["result"]["agree"])


class UnseenTestOnSimple20Tests(unittest.TestCase):
    """The unseen test built on Simple 20 (Dr. Curry, 2026-10-23), made here from a throwaway seed (never the real
    one, which only Rafi has): a chain of 20 in Simple 20's groups and kinds, none of them a Simple 20 task."""

    def test_a_chain_mirroring_simple_20_that_the_checker_passes(self):
        import importlib.util
        import tempfile
        gen = _make_test_tasks_module()
        spec = importlib.util.spec_from_file_location("check_tasks", ROOT / "study" / "check_tasks.py")
        check_tasks = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(check_tasks)
        data = gen.make_chained("a throwaway seed for the tests", twin=False, say=lambda line: None)
        self.assertTrue(data["chained"])
        self.assertEqual([t["level"] for t in data["tasks"]], [1] * 5 + [2] * 5 + [3] * 5 + [4] * 5)
        simple = load_task_set(SIMPLE, 3)
        for t, s in zip(data["tasks"], simple.tasks):
            self.assertEqual(t["category"], s.category, t["id"])
            self.assertEqual([next(iter(x)) for x in t["targets"]], [next(iter(x)) for x in s.targets], t["id"])
            self.assertEqual(t["start"]["cubes"], ["red", "green", "blue"], "always the three cubes")
            self.assertNotIn(t["prompt"], [x.prompt for x in simple.tasks])
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "test.yaml"
            path.write_text(gen._yaml(data), encoding="utf-8")
            problems, _ = check_tasks.check(path)
            self.assertEqual(problems, [])
            self.assertTrue(load_task_set(path, 3).chained)
        again = gen.make_chained("a throwaway seed for the tests", twin=False, say=lambda line: None)
        self.assertEqual(again["tasks"], data["tasks"], "the same seed makes the same set")


class PromptRecorderTests(unittest.TestCase):
    """Watcher active: a typed prompt recorded as a run -- before and after, every step, named when it ends."""

    def recorder(self, folder, before, after):
        from watcher.prompt_record import PromptRecorder

        class Robot:
            def __init__(self):
                self.watchers, self.moves = [], []

            def add_watcher(self, fn):
                self.watchers.append(fn)

            def remove_watcher(self, fn):
                self.watchers.remove(fn)

            def move_to(self, pose):
                self.moves.append(pose)
        ctx = SimpleNamespace(robot=Robot(), camera=None, scene_builder=None, config={"llm": {"model": "qwen"}},
                              mode="demo", twin_world=None, calibration_file=None, park_pose=(200, 0, 120, 0),
                              executor=SimpleNamespace(look_pose=None, table_z_provider=lambda: 0.0),
                              calibration_state=lambda: {"method": "cube"})
        rec = PromptRecorder(lambda: ctx, root=Path(folder))
        looks = iter([before, after])
        rec._look = lambda stats: next(looks)
        return rec, ctx

    def test_a_prompt_recorded_named_and_listed(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            rec, ctx = self.recorder(folder, [Cube("red cube", 230, 60), Cube("blue cube", 230, -60)],
                                     [Cube("red cube", 230, 90, 10), Cube("blue cube", 230, -60)])
            run = rec.begin("Move the red cube 30 mm to the left")
            self.assertEqual(len(ctx.robot.watchers), 1, "the robot's events collected meanwhile")
            ctx.robot.watchers[0]({"kind": "move", "ok": True})
            rec.step(run, SimpleNamespace(tool_name="move_object", arguments={"object_id": "obj_1"}, result="Moved"))
            folder_ = rec.finish(run, SimpleNamespace(final_message="Done: moved it 30 mm left.", trace=None))
            self.assertEqual(ctx.robot.watchers, [], "and no longer")
            self.assertEqual(len(ctx.robot.moves), 1, "parked out of the camera's way for the end look")
            data = json.loads((folder_ / "run.json").read_text(encoding="utf-8"))
            self.assertEqual((data["outcome"], data["moves"]), ("done", 1))
            red = next(c for c in data["cubes"] if c["cube"] == "red cube")
            self.assertEqual((red["moved_mm"], red["dy_mm"], red["turned_deg"]), (30.0, 30.0, 10.0))
            self.assertTrue((folder_ / "model_log.html").exists())
            name = rec.suggested_name("Move the red cube 30 mm to the left")
            self.assertTrue(name.endswith("_move-the-red-cube-30"), name)
            saved = rec.save(folder_, "red left", "pass", "fine")
            self.assertEqual(saved.name, "red_left")
            report = (saved / "PROMPT_REPORT.md").read_text(encoding="utf-8")
            self.assertIn("Move the red cube 30 mm to the left", report)
            self.assertIn("**Your verdict:** pass -- fine", report)
            self.assertIn("| red cube | (230, 60) | (230, 90) | 30 mm |", report)
            self.assertIn("red_left", (Path(folder) / "Prompt_Runs" / "PROMPT_RUNS.md").read_text(encoding="utf-8"))
            # everything a watcher run saves: its evidence, its report, its own pages, the reports of them all
            root = Path(folder) / "Prompt_Runs"
            self.assertEqual(saved, root / "_raw_data" / "red_left")
            for name in ("run.json", "run_report.txt", "trace.json", "model_log.html", "refused_steps.csv",
                         "alarms.csv", "moves.csv", "observer.json"):
                self.assertTrue((saved / name).exists(), name)
            text = (saved / "run_report.txt").read_text(encoding="utf-8")
            self.assertIn("NO TARGET", text)
            self.assertIn("EVENTS", text)
            self.assertIn("WHAT HAPPENED", text)
            self.assertTrue((root / "User_Saved_Prompt_Runs" / "red_left.md").exists())
            self.assertTrue((root / "User_Saved_Prompt_Runs" / "HTML_version" / "red_left.html").exists())
            for name in ("FULL_REPORT.md", "FULL_REPORT.html", "full_report.json"):
                self.assertTrue((root / name).exists(), name)
            self.assertTrue((root / "results.xlsx").exists() or list(root.glob("results_*.csv")))
            sitting = next((root / "_sessions_log").glob("*"))
            self.assertTrue(results.verify_index(sitting), "the index's lines chained by their hashes")
            saved_run = json.loads((saved / "run.json").read_text(encoding="utf-8"))
            self.assertEqual((saved_run["report"]["result"]["watcher"], saved_run["observer"]["verdict"]),
                             ("NO TARGET", "pass"))
            self.assertIsNone(saved_run["report"]["result"]["agree"], "a verdict, but nothing to disagree with")
            self.assertEqual(rec.free_name("red left"), "red_left_2", "a name is never used twice")

    def test_refused_stopped_out_of_time_and_errors_are_recorded_too(self):
        from watcher.prompt_record import outcome
        refused = SimpleNamespace(tool_name="pick", result="ERROR: out of reach")
        self.assertEqual(outcome(None, "", False, [(refused, 0)], "I can't"), "refused")
        self.assertEqual(outcome(None, "", False, [], "I cannot do that"), "refused")
        self.assertEqual(outcome(None, "Stopped by you", False, [], ""), "stopped")
        self.assertEqual(outcome(None, "Time limit", True, [], ""), "time limit")
        self.assertEqual(outcome("TimeoutError: Ollama", "", False, [], ""), "error")
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            rec, _ = self.recorder(folder, [Cube("red cube", 230, 60)], [])
            run = rec.begin("Stack everything")
            folder_ = rec.finish(run, None, "ConnectionError: Ollama isn't running")
            data = json.loads((folder_ / "run.json").read_text(encoding="utf-8"))
            self.assertEqual(data["outcome"], "error")
            self.assertIn("not seen at the end", data["cubes"][0]["note"])
            self.assertTrue((folder_ / "trace.json").exists(), "the partial record kept")

    def test_the_prompt_window_records_when_watcher_active_is_on(self):
        import os
        import tempfile
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication([])
        from app.ui.prompt_panel import PromptPanel

        class Agent:
            executor = None

            def run(self, prompt, on_step=None):
                on_step(SimpleNamespace(tool_name="move_object", arguments={}, result="Moved", duration_s=0.1))
                return SimpleNamespace(final_message="Done.", trace=None, steps=[])
        named = []

        class Dialog:                                  # (the name dialog, answered: "my run", pass)
            def __init__(self, parent, prompt, outcome, suggested):
                named.append((prompt, outcome, suggested))

            def exec(self):
                return 1

            def result(self):
                return 1

            def answer(self):
                return "my run", "pass", ""
        with tempfile.TemporaryDirectory() as folder, mock.patch("app.ui.prompt_name_dialog.PromptNameDialog", Dialog):
            rec, _ = self.recorder(folder, [Cube("red cube", 230, 60)], [Cube("red cube", 230, 90)])
            panel = PromptPanel(Agent())
            panel.recorder = rec
            panel.watch_switch.setChecked(True)
            self.assertTrue(panel.rec_label.isVisibleTo(panel), "REC shows while it records")
            panel._send_text("Move the red cube 30 mm to the left")
            self.assertTrue(panel._time_limit.isActive(), "5 minutes at most")
            deadline = time.monotonic() + 20
            while (panel.is_busy() or not named) and time.monotonic() < deadline:
                app.processEvents()
                time.sleep(0.02)
            self.assertEqual([(p, o) for p, o, _ in named], [("Move the red cube 30 mm to the left", "done")])
            data = json.loads((Path(folder) / "Prompt_Runs" / "_raw_data" / "my_run" / "run.json").read_text(encoding="utf-8"))
            self.assertEqual((data["prompt"], data["outcome"], data["observer"]["verdict"]),
                             ("Move the red cube 30 mm to the left", "done", "pass"))
            self.assertIn("my_run", panel.log.toPlainText())
            self.assertFalse(panel._time_limit.isActive())
            panel.watch_switch.setChecked(False)
            panel._send_text("Go home")
            deadline = time.monotonic() + 10
            while panel.is_busy() and time.monotonic() < deadline:
                app.processEvents()
                time.sleep(0.02)
            self.assertEqual(len(named), 1, "off: not recorded")


class SimpleTwentyWindowTests(tw.WatcherWindowTests):
    """Simple 20 in the twin: Run group, every run saved whatever happened, a task the table can't start skipped."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):      # (run once, in test_watcher)
        pass

    def window(self, folder, recipe):
        import importlib.util
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        gen = _make_test_tasks_module()
        tasks = load_task_set(STUDY_TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-01"), tasks)
        self.addCleanup(twin.stop)
        twin.executor.poses_dir = folder / "poses"
        ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                             executor=twin.executor, agent=Agent(gen.RecipeClient(recipe), twin.executor, "scripted"),
                             config={"llm": {"seed": 42}}, mode="demo", estop=twin.robot.stop,
                             poses_dir=folder / "poses", twin_world=twin.world, results_root=folder / "results")
        window = WatcherWindow(ctx)
        window.session_box.setCurrentIndex(window.session_box.findData("simple_twin"))
        return window

    def run_until_done(self, window, seconds=300):
        deadline = time.monotonic() + seconds
        while window.session is not None and time.monotonic() < deadline:
            self.app.processEvents()
            if window.state == "setup" and not window._busy:          # (the table check, as the timer would)
                window._show_setup(window._look(looks=1))
            time.sleep(0.02)
        self.assertIsNone(window.session, "the group done, the session ended, nobody clicking")

    def test_group_a_runs_by_itself_and_every_run_is_saved(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            # the same steps every time (the first task's): one task passes, the others fail -- all of them saved
            window = self.window(folder, [("move_object", {"object_id": "red cube", "direction": "forward",
                                                           "distance_mm": 40})])
            self.assertTrue(all(b.isVisibleTo(window) for b in window.simple_btns), "Run all, Group A-D")
            self.assertEqual(window.plan_tree.topLevelItem(0).text(0), "Group A")
            window._ask_save = lambda *a: self.fail("Simple 20 never asks")
            window.simple_btns[1].click()                              # ▶ Group A
            self.assertEqual([t.id for t, _ in window.plan], ["S-01", "S-02", "S-03", "S-04", "S-05"])
            self.assertTrue(window.auto_run.isChecked(), "by itself")
            kind = window.session.kind_folder
            self.assertIn("20_Tasks_for_Twin", str(kind))
            self.run_until_done(window)
            runs = {p.parent.name: json.loads(p.read_text(encoding="utf-8"))
                    for p in (kind / "_raw_data").glob("*/run.json")}
            self.assertEqual(sorted(runs), [f"S-0{n}_Run1" for n in range(1, 6)], "all five saved")
            self.assertEqual(window.status.kind, "done", "the status strip: green, all done")
            self.assertEqual(window.status.head.text(), "All 5 tasks done")
            self.assertIn("passed", window.status.sub.text())
            self.assertIn("20_Tasks_for_Twin", window.status.sub.text(), "where it was saved")
            self.assertEqual(window.windowTitle(), "Kyozo Watcher · all done")
            self.assertTrue(runs["S-01_Run1"]["passed"], runs["S-01_Run1"]["score"])
            self.assertFalse(runs["S-02_Run1"]["passed"], "moved red again: failed, saved all the same")
            self.assertTrue(all(r["observer"]["verdict"] == "skipped" for r in runs.values()))
            self.assertTrue(all(r["time_limit_s"] == 600.0 for r in runs.values()), "10 minutes a task (V4.2)")
            self.assertTrue(window._set_out_done, "nothing sorted: no set-out")
            self.assertTrue(all(r["outcome"] in ("PASS", "SOME PARTS", "FAIL") for r in runs.values()))
            self.assertTrue(all(r["start_condition"] for r in runs.values()), "each run says how its table was")
            self.assertEqual(runs["S-01_Run1"]["credit"]["band"], "Full")
            self.assertTrue(all(0 <= r["credit"]["score"] <= 100 for r in runs.values()), "every run scored 0-100")
            report = (kind / "FULL_REPORT.md").read_text(encoding="utf-8")
            self.assertIn("Partial credit (0-100", report)
            self.assertIn("| Saved runs | Counted | Skipped | Passed | Some parts | Catastrophic |", report)
            self.assertIn("Start conditions (the table as the task before left it):", report)
            self.assertIn("Start:", (kind / "_raw_data" / "S-02_Run1" / "run_report.txt").read_text(encoding="utf-8"))
            summary = next((kind / "_sessions_log").glob("*/SESSION_SUMMARY.md")).read_text(encoding="utf-8")
            self.assertIn("By group: Group A", summary)
            self.assertIn("Score:", (kind / "_raw_data" / "S-01_Run1" / "run_report.txt").read_text(encoding="utf-8"))
            index = [json.loads(line) for line in next((kind / "_sessions_log").glob("*/index.jsonl")).read_text(
                encoding="utf-8").splitlines()]
            self.assertEqual(sum("started" in line for line in index), 5, "each run noted as it started")
            window.close()

    def test_proceed_to_next_task_saves_everything_then_goes_on(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            window = self.window(folder, [("move_object", {"object_id": "red cube", "direction": "forward",
                                                           "distance_mm": 99}),           # (refused: too far)
                                          ("move_object", {"object_id": "red cube", "direction": "back",
                                                           "distance_mm": 10})])
            window._ask_save = lambda *a: self.fail("Proceed never asks")
            window._run_simple(level=1)
            window.auto_run.setChecked(False)                         # (by hand: nothing goes on by itself)
            self.assertTrue(window.proceed_btn.isVisibleTo(window))
            kind = window.session.kind_folder
            deadline = time.monotonic() + 60
            while not window.run_btn.isEnabled() and time.monotonic() < deadline:
                self.app.processEvents()
                if window.state == "setup" and not window._busy:
                    window._show_setup(window._look(looks=1))
                time.sleep(0.02)
            window._start_run()
            self.wait_for(window, "verdict")
            window.proceed_btn.click()                                # waiting for a verdict: saved, then S-02
            deadline = time.monotonic() + 30
            while window.plan[window.index][0].id == "S-01" and time.monotonic() < deadline:
                self.app.processEvents()
                time.sleep(0.02)
            run = json.loads((kind / "_raw_data" / "S-01_Run1" / "run.json").read_text(encoding="utf-8"))
            self.assertFalse(run["passed"])
            self.assertEqual(run["observer"]["note"], "ended with Proceed to next task")
            self.assertTrue(run["refused_steps"], "the refused step, logged")
            self.assertTrue((kind / "_raw_data" / "S-01_Run1" / "refused_steps.csv").exists())
            self.assertEqual(window.state, "setup")
            self.assertFalse(window.auto_run.isChecked(), "S-02 waits for you")
            window.proceed_btn.click()                                # not started: skipped, logged
            self.assertEqual(window.plan[window.index][0].id, "S-03")
            index = [json.loads(line) for line in next((kind / "_sessions_log").glob("*/index.jsonl")).read_text(
                encoding="utf-8").splitlines()]
            self.assertTrue(any(line.get("skipped") == "S-02" for line in index))
            self.assertTrue(any(line.get("refused_steps") for line in index))
            skip = json.loads((kind / "_raw_data" / "S-02_Run1" / "run.json").read_text(encoding="utf-8"))
            self.assertIsNone(skip["passed"], "saved as a run, but not a pass or a fail")
            self.assertEqual(skip["skipped"]["by"], "you (Proceed to next task)")
            self.assertEqual((skip["skipped"]["task_before"]["run"], skip["skipped"]["task_before"]["result"]),
                             ("S-01_Run1", "FAIL"), "the task that left the table so, and how it ended")
            self.assertTrue(skip["skipped"]["task_before"]["ended"], "where it left the cubes")
            self.assertNotIn("last_ran", skip["skipped"]["task_before"], "the task before ran")
            self.assertEqual({e["cube"] for e in skip["skipped"]["expected"]}, {"red cube", "green cube", "blue cube"},
                             "where S-02 needed each cube vs where it was")
            self.assertTrue(all(e["off_mm"] is not None for e in skip["skipped"]["expected"]))
            window.proceed_btn.click()                                # S-03 not started either: skipped in a row
            self.assertEqual(window.plan[window.index][0].id, "S-04")
            skip = json.loads((kind / "_raw_data" / "S-03_Run1" / "run.json").read_text(encoding="utf-8"))
            before = skip["skipped"]["task_before"]
            self.assertEqual((before["run"], before["result"]), ("S-02_Run1", "SKIPPED"))
            self.assertEqual(before["last_ran"]["run"], "S-01_Run1", "back to the last task that did run")
            self.assertIn("The last task that ran: S-01_Run1, FAIL",
                          (kind / "_raw_data" / "S-03_Run1" / "run_report.txt").read_text(encoding="utf-8")
                          .replace("\n    ", " "))
            window.end_session("test over")
            window.close()

    def test_cubes_put_anywhere_are_set_out_by_the_arm(self):
        import tempfile
        from watcher import observe
        from watcher.arrange import chain_start
        from watcher.setout import IN_PLACE_MM, needs_set_out, set_out, targets_of
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            window = self.window(folder, [])
            tasks = load_task_set(SIMPLE, 3)
            # red on green's spot, green on red's (each waits for the other's), blue off to the right and nearer
            muddle = [Cube("red cube", 230, 0, 20), Cube("green cube", 230, 70, -10), Cube("blue cube", 195, -45, 30)]
            window._place_demo_cubes(muddle, "muddle", 25, wait=True)
            targets = targets_of(chain_start(tasks, "S-01"))
            self.assertTrue(needs_set_out(observe.exact_cubes(window.ctx.twin_world), chain_start(tasks, "S-01")))
            steps = set_out(window.ctx.executor, folder / "poses", 0.0, targets, 25)
            self.assertIn("place_free", [s["tool"] for s in steps], "one put aside first: the two swapped ones")
            end = {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}
            for label, (x, y) in targets.items():
                self.assertLess(math.hypot(end[label].x - x, end[label].y - y), IN_PLACE_MM + 1, label)
            self.assertFalse(list((folder / "poses").glob("simple start*.json")), "no places left behind")
            window.close()

    def test_group_d_s_tower_is_built_from_cubes_put_anywhere(self):
        import tempfile
        from watcher import observe
        from watcher.arrange import chain_start
        from watcher.setout import IN_PLACE_MM, needs_set_out, set_out, targets_of, towers_of
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            window = self.window(folder, [])
            tasks = load_task_set(SIMPLE, 3)
            layout = chain_start(tasks, "S-16")                  # blue at the left with green on it, red right
            self.assertEqual(towers_of(layout), {"green cube": "blue cube"})
            # green where blue's tower goes, the others scattered
            scattered = [Cube("green cube", 230, 70, 10), Cube("blue cube", 200, -10, -20),
                         Cube("red cube", 260, -20, 35)]
            window._place_demo_cubes(scattered, "scattered", 25, wait=True)
            self.assertTrue(needs_set_out(observe.exact_cubes(window.ctx.twin_world), layout))
            steps = set_out(window.ctx.executor, folder / "poses", 0.0, targets_of(layout), 25, on=towers_of(layout))
            self.assertEqual([s["tool"] for s in steps[-2:]], ["place_on", "list_objects"],
                             "the tower built last, then a last look: the arm out of the camera's way")
            end = {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}
            for c in layout:
                self.assertLess(math.hypot(end[c.label].x - c.x, end[c.label].y - c.y), IN_PLACE_MM + 2, c.label)
                self.assertEqual(end[c.label].level, c.level, c.label)
            window.close()

    def test_every_prompt_has_its_own_run_button(self):
        import tempfile
        from PyQt6.QtWidgets import QPushButton
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            tree = window.plan_tree
            self.assertEqual(tree.headerItem().text(3), "Run")
            buttons = [tree.itemWidget(row, 3) for row in window._picker_rows()]
            self.assertEqual(len(buttons), 20)
            self.assertTrue(all(isinstance(b, QPushButton) and b.text() == "▶ Run" for b in buttons))
            window.simple_btns[1].click()                              # ▶ Group A
            window.auto_run.setChecked(False)                          # (nothing starts by itself)
            self.assertEqual(window.plan[window.index][0].id, "S-01")

            def row_of(task_id):
                return next(tree.topLevelItem(0).child(j) for j in range(tree.topLevelItem(0).childCount())
                            if tree.topLevelItem(0).child(j).text(0) == task_id)
            self.assertIsNone(tree.itemWidget(row_of("S-01"), 3), "the current one has none")
            now = tree.itemWidget(row_of("S-03"), 3)
            self.assertEqual(now.text(), "▶ Now")
            now.click()                                                # S-01 hasn't started: S-03 goes first
            self.assertEqual([t.id for t, _ in window.plan], ["S-03", "S-01", "S-02", "S-04", "S-05"])
            self.assertEqual(window.plan[window.index][0].id, "S-03")
            self.assertEqual(window._plan_status[:2], ["Now", "Waiting"])
            index = [json.loads(line) for line in next((window.session.kind_folder / "_sessions_log").glob(
                "*/index.jsonl")).read_text(encoding="utf-8").splitlines()]
            self.assertTrue(any(line.get("run_now") == "S-03" for line in index), "noted")
            window.end_session("test over")
            window.close()

    def test_the_unseen_test_runs_like_simple_20_with_its_prompts_hidden(self):
        import importlib.util
        import tempfile
        gen = _make_test_tasks_module()
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            data = gen.make_chained("another throwaway seed", twin=False, say=lambda line: None)
            (folder / "results" / results.TEST_TASKS).mkdir(parents=True)
            (folder / "results" / results.TEST_TASKS / "test.yaml").write_text(gen._yaml(data), encoding="utf-8")
            window = self.window(folder, [])
            window.session_box.setCurrentIndex(window.session_box.findData("test_twin"))
            self.assertTrue(window._simple(), "the test built on Simple 20 runs as it does")
            self.assertTrue(window.simple_row.isVisibleTo(window), "Run Group A-D")
            self.assertEqual(window.plan_tree.topLevelItem(0).text(0), "Group A")
            self.assertIn("hidden", window.plan_tree.topLevelItem(0).child(0).text(1), "its prompts stay hidden")
            window._ask_save = lambda *a: self.fail("never asks")
            window.simple_btns[1].click()                              # ▶ Run Group A
            self.assertEqual([t.id for t, _ in window.plan], ["T-01", "T-02", "T-03", "T-04", "T-05"])
            self.assertTrue(window.auto_run.isChecked())
            kind = window.session.kind_folder
            self.assertEqual(kind.name, "Test_Twin_with_unseen_tasks", kind)
            self.run_until_done(window)
            runs = [json.loads(p.read_text(encoding="utf-8")) for p in (kind / "_raw_data").glob("T-0*_Run1/run.json")]
            index = [json.loads(line) for line in next((kind / "_sessions_log").glob("*/index.jsonl")).read_text(
                encoding="utf-8").splitlines()]
            skipped = sum("skipped" in line for line in index)  # (nothing moved the cubes: a later task may not start)
            self.assertGreater(len(runs) - skipped, 0)
            self.assertEqual(len(runs), 5, "every task saved: run, or skipped (saved with why)")
            self.assertEqual(sum(bool(r.get("skipped")) for r in runs), skipped)
            window.close()

    def test_nothing_seen_is_skipped_and_three_empty_tasks_in_a_row_end_the_session(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            window = self.window(folder, [])
            window._look = lambda looks=1, stats=None: []              # (the camera works; the table is empty)
            window._run_simple(level=4)                                # ▶ Group D: S-16 to S-20
            self.assertEqual([t.id for t, _ in window.plan], ["S-16", "S-17", "S-18", "S-19", "S-20"])
            kind = window.session.kind_folder
            self.run_until_done(window, 60)
            log = next((kind / "_sessions_log").glob("*"))
            index = [json.loads(line) for line in (log / "index.jsonl").read_text(encoding="utf-8").splitlines()]
            skipped = [line for line in index if isinstance(line.get("skipped"), str)]
            self.assertEqual([line["skipped"] for line in skipped], ["S-16", "S-17", "S-18"],
                             "three empty tasks in a row: the session ends there, not after all five")
            self.assertTrue(skipped[0]["why"].startswith("no cube can be seen"), skipped[0]["why"])
            summary = (log / "SESSION_SUMMARY.md").read_text(encoding="utf-8")
            self.assertIn("Skipped (the table wasn't READY for them): S-16, S-17, S-18", summary)
            session = json.loads((log / "session.json").read_text(encoding="utf-8"))
            self.assertIn("no cube seen for 3 tasks in a row (S-16, S-17, S-18)", json.dumps(session))
            # each saved as a run of its own: why, and what the scene was -- and in the full report, counted apart
            folder16 = kind / "_raw_data" / "S-16_Run1"
            run = json.loads((folder16 / "run.json").read_text(encoding="utf-8"))
            self.assertTrue(run["skipped"]["why"].startswith("no cube can be seen"))
            self.assertEqual((run["skipped"]["by"], run["outcome"]), ("the watcher", "SKIPPED"))
            self.assertIsNone(run["skipped"]["task_before"], "the session's first task")
            self.assertEqual(run["start_condition"], ["cube not seen"])
            self.assertTrue(run["skipped"]["expected"], "where S-16 would have needed each cube")
            listed = results.saved_runs(kind, "S-16")                 # (the Save dialog's list: not "Fail")
            self.assertEqual([results.result_word(r) for r in listed], ["Skipped"])
            self.assertIn("Skipped:", (folder16 / "run_report.txt").read_text(encoding="utf-8"))
            own = (results.saved_folder(kind) / "S-16_Run1.md").read_text(encoding="utf-8")
            self.assertIn("SKIPPED", own)
            self.assertIn("### Why it was skipped", own)
            full = (kind / "FULL_REPORT.md").read_text(encoding="utf-8")
            self.assertIn("## Skipped tasks", full)
            self.assertIn("S-16 · SKIPPED", full)
            totals = json.loads((kind / "full_report.json").read_text(encoding="utf-8"))["totals"]
            self.assertEqual((totals["runs"], totals["counted"], totals["skipped"], totals["passed"]), (3, 0, 3, 0),
                             "not a pass or a fail")
            from watcher import handoff                                # Claude sees them, and why
            out = handoff.build([kind], 1, "base", root=Path(window.ctx.results_root))
            text = (out / "SUMMARY.md").read_text(encoding="utf-8")
            self.assertIn("## Skipped tasks", text)
            self.assertIn("no cube can be seen", text)
            self.assertIn("Runs: 0; skipped: 3", text)
            window.close()

    def test_a_cube_in_the_way_may_move_and_badly_wrong_is_flagged(self):
        from watcher.arrange import blocking_cubes, infer_hidden
        from watcher.tasks import outcome, score
        tasks = load_task_set(SIMPLE, 3)
        s03 = tasks.task("S-03")                                   # the green cube 50 mm further
        known = {"green cube": Cube("green cube", 230, 0)}
        start, _ = infer_hidden([Cube("red cube", 230, 0, 0, 2), Cube("blue cube", 230, -70)], known)
        may = blocking_cubes(s03, tasks, start)
        self.assertEqual(may, {"red cube": "on top of the green cube"})

        def run(end):
            result = score(s03, end, tasks.zones, tasks.rule, 25, start=start, may_move=may, area=tasks.area)
            return result, outcome(result, score(s03, start, tasks.zones, tasks.rule, 25, start=start, may_move=may,
                                                 area=tasks.area))
        result, word = run([Cube("red cube", 200, 40), Cube("green cube", 280, 0), Cube("blue cube", 230, -70)])
        self.assertEqual((word, result.collateral, result.catastrophic), ("PASS", [], []),
                         "the red cube taken off and put down on the table: allowed")
        self.assertTrue(result.prepared)
        result, word = run([Cube("red cube", 200, 40, 0, 1), Cube("green cube", 280, 0),
                            Cube("blue cube", 230, -20)])                       # blue knocked 50 mm
        self.assertEqual(word, "SOME PARTS")
        self.assertIn("the blue cube, not part of the task, moved 50 mm", result.catastrophic)
        result, word = run([Cube("red cube", 200, 40), Cube("green cube", 230, 0)])   # blue gone, green not moved
        self.assertEqual(word, "FAIL")
        self.assertIn("the blue cube can't be seen at the end (knocked off the table?)", result.catastrophic)
        result, _ = run([Cube("red cube", 280, 0, 0, 2), Cube("green cube", 280, 0), Cube("blue cube", 230, -70)])
        self.assertTrue(result.collateral and not result.prepared, "carried along on top: not out of the way")

    def test_the_twin_takes_a_tower_apart_now_its_top_cube_reads_25_mm(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            window = self.window(folder, [])
            tower = [Cube("green cube", 230, 0, 0, 1), Cube("red cube", 230, 0, 0, 2), Cube("blue cube", 230, -70, 0, 1)]
            window._place_demo_cubes(tower, "tower", 25, wait=True)
            executor = window.ctx.executor
            import ast
            looked = ast.literal_eval(executor.execute("list_objects", {}))
            red = next(o for o in looked["objects"] if o["label"] == "red cube")
            self.assertLessEqual(max(red["footprint_mm"]), 26, red)          # (was 28: too wide for the gripper)
            self.assertNotIn("gripper", red, "not marked too wide")
            picked = executor.execute("pick", {"object_id": red["id"]})
            self.assertNotIn("ERROR", str(picked), picked)
            window.close()

    def test_a_cube_in_the_way_is_moved_off_first_and_a_tower_of_three_is_taken_apart(self):
        import ast
        import tempfile
        from watcher import observe
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            window = self.window(folder, [])
            executor = window.ctx.executor

            def ids():
                return {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}

            def where():
                return {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}
            # S-13 after S-12 failed: red still on green. "Put the blue cube on the green cube": red is only in the way
            window._place_demo_cubes([Cube("green cube", 230, 0, 0, 1), Cube("red cube", 230, 0, 0, 2),
                                      Cube("blue cube", 230, -70, 0, 1)], "s13", 25, wait=True)
            executor.request = "Put the blue cube on the green cube."
            seen = ids()
            self.assertNotIn("ERROR", executor.execute("pick", {"object_id": seen["blue cube"]}))
            said = executor.execute("place_on", {"object_id": seen["green cube"]})
            self.assertNotIn("ERROR", said, said)
            now = where()
            self.assertEqual((now["blue cube"].level, now["red cube"].level), (2, 1), "blue on green, red put aside")
            self.assertLess(math.hypot(now["blue cube"].x - now["green cube"].x, now["blue cube"].y - now["green cube"].y),
                            8)
            # building a tower: red on green is meant to be there -- refused, saying to put it on the top
            window._place_demo_cubes([Cube("green cube", 230, 0, 0, 1), Cube("red cube", 230, 0, 0, 2),
                                      Cube("blue cube", 230, -70, 0, 1)], "s17", 25, wait=True)
            executor.forget_scene()
            executor.request = "Build a tower with the green cube at the bottom, then the red cube, then the blue cube."
            seen = ids()
            executor.execute("pick", {"object_id": seen["blue cube"]})
            with self.assertRaises(ValueError) as refused:
                executor.execute("place_on", {"object_id": seen["green cube"]})
            self.assertIn("top of that pile is the red cube", str(refused.exception))
            executor.execute("place_on", {"object_id": seen["red cube"]})
            # the bottom of a tower of three: both above it moved aside first
            executor.forget_scene()
            seen = ids()
            said = executor.execute("pick", {"object_id": seen["green cube"]})
            self.assertNotIn("ERROR", said, said)
            self.assertIn("blue cube was on top of the red cube", said)
            window.close()

    def test_a_cube_lifted_off_only_to_get_at_another_is_put_down_by_the_next_pick(self):
        # S-19 in the twin, 2026-10-24: blue picked off red to get at it, then nowhere to put blue (not asked for)
        # and red couldn't be picked ("already holding") -- the time ran out with blue still held
        import ast
        import tempfile
        from watcher import observe
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor
            window._place_demo_cubes([Cube("red cube", 230, 0, 0, 1), Cube("blue cube", 230, 0, 0, 2),
                                      Cube("green cube", 230, -80, 0, 1)], "s19", 25, wait=True)
            executor.request = "Put the red cube to the right of the green cube with a 50 mm gap."
            seen = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
            self.assertNotIn("ERROR", executor.execute("pick", {"object_id": seen["blue cube"]}))
            said = executor.execute("pick", {"object_id": seen["red cube"]})
            self.assertNotIn("ERROR", said, said)
            self.assertIn("only in the way", said)
            self.assertEqual(executor.holding, "red cube")
            self.assertEqual({c.label: c.level for c in observe.exact_cubes(window.ctx.twin_world)}["blue cube"], 1)
            # building with it, the held cube is part of the plan: not put down by itself
            executor.request = "Build a tower with the green cube at the bottom, then the red cube, then the blue cube."
            self.assertFalse(executor._held_only_in_the_way())
            # S-19, 2026-10-25: place_free "right" of the green cube took whichever side was free (its left)
            with self.assertRaises(ValueError) as refused:
                executor.execute("place_free", {"where": "right", "object_id": seen["green cube"]})
            self.assertIn("place_beside", str(refused.exception))
            self.assertEqual(executor.holding, "red cube", "nothing was done")
            window.close()

    def test_a_tower_s_own_cube_held_is_put_back_and_beside_the_tower_is_on_the_table(self):
        # twin run 9, 2026-10-25 -- S-17: green (the bottom) picked first, build_tower refused "already holding", and
        # the tower was built near the base instead; S-18: "left of the tower" -- beside its top cube refused as not
        # named, and beside it the cube would have been let go a cube up, in mid-air
        import ast
        import tempfile
        from app.llm.request_checks import check_step
        from watcher import observe
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor

            def seen():
                return {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}

            def where():
                return {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}
            window._place_demo_cubes([Cube("red cube", 230, 70, 0, 1), Cube("green cube", 230, 0, 0, 1),
                                      Cube("blue cube", 230, -70, 0, 1)], "s17", 25, wait=True)
            executor.request = ("Build a tower with the green cube at the bottom, then the red cube, then the blue "
                                "cube on top.")
            ids = seen()
            executor.execute("pick", {"object_id": ids["green cube"]})
            said = executor.execute("build_tower", {"object_ids": [ids["green cube"], ids["red cube"],
                                                                   ids["blue cube"]]})
            self.assertIn("put back where it was picked up", said)
            now = where()
            self.assertEqual([now[c].level for c in ("green cube", "red cube", "blue cube")], [1, 2, 3])
            self.assertLess(math.hypot(now["green cube"].x - 230, now["green cube"].y), 8, "where green was")
            # S-18: blue off the tower, to its left with a 60 mm gap -- beside red, the tower's top now
            prompt = "Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap."
            executor.request = prompt
            ids = seen()
            executor.execute("pick", {"object_id": ids["blue cube"]})
            ids = seen()
            beside_red = {"object_id": ids["red cube"], "side": "left", "gap_mm": 60}
            self.assertIsNone(check_step("place_beside", beside_red, prompt, executor, "take off a pile"))
            self.assertIsNotNone(check_step("pick", {"object_id": ids["red cube"]}, prompt, executor,
                                            "take off a pile"), "picking one still needs it named")
            said = executor.execute("place_beside", beside_red)
            self.assertNotIn("ERROR", said, said)
            now = where()
            self.assertEqual(now["blue cube"].level, 1, "on the table, not let go a cube up")
            self.assertAlmostEqual(now["blue cube"].y - now["green cube"].y, 85, delta=4)
            window.close()

    def test_a_gap_beside_a_turned_cube_is_measured_between_squared_up_faces(self):
        # S-16 in the twin, 2026-10-25: a 50 mm gap from the turned cube's corner scored 10.6 mm short; Rafi chose
        # the watcher's way: centres a cube's size plus the gap apart
        import ast
        import tempfile
        from watcher import observe
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor

            def put_beside(green_turn, gap):
                window._place_demo_cubes([Cube("green cube", 230, 0, green_turn, 1),
                                          Cube("red cube", 200, -110, 35, 1)], f"gap{gap}", 25, wait=True)
                executor.forget_scene()
                seen = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
                executor.execute("pick", {"object_id": seen["red cube"]})
                said = executor.execute("place_beside", {"object_id": seen["green cube"], "side": "right",
                                                         "gap_mm": gap})
                self.assertNotIn("ERROR", said, said)
                return {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}

            executor.request = "Put the red cube to the right of the green cube with a 50 mm gap."
            now = put_beside(35, 50)
            self.assertAlmostEqual(now["green cube"].y - now["red cube"].y, 75, delta=4)
            # a small gap between turned cubes: never so close the corners meet (the green one isn't pushed)
            executor.request = "Put the red cube to the right of the green cube with a 5 mm gap."
            now = put_beside(45, 5)
            self.assertLess(math.hypot(now["green cube"].x - 230, now["green cube"].y), 2, "green not pushed")
            self.assertGreater(now["green cube"].y - now["red cube"].y, 30)
            window.close()

    def test_an_answer_that_runs_on_is_cut_off_told_once_then_the_prompt_ends(self):
        from app.llm.agent import TOO_LONG, TOO_LONG_STOP, Agent
        from app.llm.ollama_client import MAX_ANSWER_TOKENS

        class RunsOn:                                  # (S-15 in the twin: an answer that never ended)
            def __init__(self):
                self.asked = 0
                self.last_stats = {}

            def chat(self, model, messages, tools=None, temperature=0.2):
                self.asked += 1
                self.last_stats = {"stop_reason": "length", "tokens_written": MAX_ANSWER_TOKENS}
                return {"role": "assistant", "content": "The red cube cannot be picked because " * 50}
        import tempfile
        client = RunsOn()
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            run = Agent(client, window.ctx.executor, "m").run("Put the green cube on the blue cube.")
            window.close()
        self.assertEqual(client.asked, 2, "told once, then it ends")
        self.assertTrue(run.final_message.endswith("[cut off at the answer limit]"), run.final_message)
        self.assertTrue(TOO_LONG_STOP)
        self.assertTrue(any(t.get("nudged") == TOO_LONG for t in run.trace["turns"]))
        self.assertGreater(MAX_ANSWER_TOKENS, 100)

    def test_a_cube_read_too_wide_once_is_measured_again_never_assumed_to_fit(self):
        import tempfile
        from app.vision.scene import SceneObject
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor
            read_36 = SceneObject("obj_9", "red cube", (230.0, 70.0, 25.0), 1.0, footprint=(36.0, 36.0, 0.0))
            builder = executor.scene_builder
            builder.footprints_near = lambda x, y, looks, within_mm=15.0: [(25.4, 25.9, 31.0)] * looks
            again = executor._measured_again(read_36)
            self.assertIsNotNone(again, "fresh pictures say 25 mm: it fits")
            self.assertLess(again.footprint[0], 26)
            builder.footprints_near = lambda x, y, looks, within_mm=15.0: [(35.0, 36.0, 0.0)] * looks
            self.assertIsNone(executor._measured_again(read_36), "still 35 mm: refused as before")
            wide = SceneObject("obj_8", "red block", (230.0, 70.0, 25.0), 1.0, footprint=(36.0, 60.0, 0.0))
            self.assertIsNone(executor._measured_again(wide), "only a cube")
            window.close()

    def test_a_turn_that_went_too_far_is_seen_and_put_right_once(self):
        import ast
        import tempfile
        from watcher import observe
        from watcher.tasks import angle_difference
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor
            window._place_demo_cubes([Cube("red cube", 230, 40, 0), Cube("blue cube", 230, -60, 0)], "turn", 25, wait=True)
            start = {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}["red cube"].yaw
            real = executor._tool_place

            def too_far(args):                             # (the Dobot's anticlockwise turns: the wrist ~30 degrees too
                if executor._wanted_turn is not None and not getattr(executor, "_checking_turn", False):
                    executor._wanted_turn += 30.0          # far, after the tool chose its turn)
                return real(args)
            executor._tool_place = too_far
            red = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
            said = executor.execute("turn_object", {"object_ids": [red["red cube"]], "turn_deg": 30})
            self.assertIn("(asked +30°), so it was turned", said, said)
            end = {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}["red cube"].yaw
            self.assertLess(angle_difference(end - start, 30.0), 6.0, f"ended {end - start:+.1f} from {start:+.1f}")
            # a turn that went right is only checked
            executor._tool_place = real
            said = executor.execute("turn_object", {"object_ids": [red["blue cube"]], "turn_deg": -30})
            self.assertIn("checked: it turned", said)
            self.assertNotIn("so it was turned", said)
            window.close()

    def test_app_review_clearing_turns_once_says_what_is_held_and_never_leaves_a_cube_held(self):
        import ast
        import tempfile
        from watcher import observe
        from watcher.tasks import angle_difference
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor

            def ids():
                return {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}

            def where():
                return {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}
            # place_on with a turn, clearing on the way: the held cube turned once, the cleared one not at all
            window._place_demo_cubes([Cube("green cube", 230, 0, 0, 1), Cube("red cube", 230, 0, 0, 2),
                                      Cube("blue cube", 230, -70, 0, 1)], "turned", 25, wait=True)
            before = where()
            executor.request = "Put the blue cube on the green cube, turned 30 degrees."
            seen = ids()
            executor.execute("pick", {"object_id": seen["blue cube"]})
            said = executor.execute("place_on", {"object_id": seen["green cube"], "turn_deg": 30})
            self.assertNotIn("ERROR", said, said)
            after = where()
            self.assertLess(angle_difference(after["blue cube"].yaw - before["blue cube"].yaw, 30.0), 6.0)
            self.assertLess(angle_difference(after["red cube"].yaw, before["red cube"].yaw), 6.0, "red not turned")
            # a turn put right that fails: the cube is never left in the gripper
            window._place_demo_cubes([Cube("red cube", 230, 40, 0), Cube("blue cube", 230, -60, 0)], "fail", 25,
                                     wait=True)
            executor.forget_scene()
            real = executor._tool_place

            def wrong_then_refused(args):                  # (the first place 30 degrees too far; the fix refused)
                if getattr(executor, "_checking_turn", False) and executor._wanted_turn is not None:
                    raise ValueError("the open gripper would hit")
                if executor._wanted_turn is not None:
                    executor._wanted_turn += 30.0
                return real(args)
            executor._tool_place = wrong_then_refused
            said = executor.execute("turn_object", {"object_ids": [ids()["red cube"]], "turn_deg": 30})
            executor._tool_place = real
            self.assertIn("putting it right failed", said)
            self.assertIn("it was put back", said)
            self.assertIsNone(executor.holding, "not left holding the cube")
            window.close()

    def test_app_review_a_pile_too_high_is_refused_before_anything_is_put_down(self):
        import ast
        import tempfile
        from app.llm import tools as tools_module
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(tools_module, "CLEAR_LEVELS", 0):
            window = self.window(Path(folder), [])                   # (no level may be taken off: one is too many)
            executor = window.ctx.executor
            window._place_demo_cubes([Cube("green cube", 230, 0, 0, 1), Cube("red cube", 230, 0, 0, 2),
                                      Cube("blue cube", 230, -70, 0, 1)], "high", 25, wait=True)
            seen = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
            executor.request = "Put the blue cube on the green cube."
            executor.execute("pick", {"object_id": seen["blue cube"]})
            with self.assertRaises(ValueError) as refused:
                executor.execute("place_on", {"object_id": seen["green cube"]})
            self.assertIn("too many to take off. You are still holding the blue cube", str(refused.exception))
            self.assertEqual(executor.holding, "blue cube", "nothing was put down")
            window.close()

    def test_bumped_and_dropped_cubes_are_still_picked(self):
        import ast
        import tempfile
        from watcher import observe
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor

            def ids():
                return {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}

            def where():
                return {c.label: c for c in observe.exact_cubes(window.ctx.twin_world)}
            # a tower the app built itself, its cubes at different turns: its top read by its flat top, and picked
            window._place_demo_cubes([Cube("red cube", 240, -60, 31), Cube("green cube", 190, 45, -5),
                                      Cube("blue cube", 175, -55, -40)], "tower", 25, wait=True)
            executor.request = "Put the red cube on the green cube."
            seen = ids()
            executor.execute("pick", {"object_id": seen["red cube"]})
            executor.execute("place_on", {"object_id": seen["green cube"]})
            executor.forget_scene()
            executor.request = "Pick up the red cube."
            said = executor.execute("pick", {"object_id": ids()["red cube"]})
            self.assertIn("Picked up red cube", said)
            # let go in mid-air: no longer held, and looked at again before the next step
            said = executor.execute("open_gripper", {})
            self.assertIn("let go of the red cube", said)
            self.assertIsNone(executor.holding)
            self.assertFalse(executor._listed, "the next tool looks at the table again")
            # bumped against another: the open fingers would hit blue -- it is moved aside first
            window._place_demo_cubes([Cube("red cube", 230, 0, 0), Cube("blue cube", 230, 29, 0),
                                      Cube("green cube", 230, -80, 0)], "bumped", 25, wait=True)
            executor.forget_scene()
            executor.request = "Move the red cube 40 mm further from the robot."
            said = executor.execute("pick", {"object_id": ids()["red cube"]})
            self.assertIn("Picked up red cube", said)
            if "too close for the open gripper" in said:                 # (made room: blue moved, not red's goal)
                self.assertGreater(abs(where()["blue cube"].y - 29), 5)
            window.close()

    def test_an_unsteady_reading_is_read_again_from_afar_before_a_pick_is_refused(self):
        import ast
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor
            window._place_demo_cubes([Cube("red cube", 230, 0, 20), Cube("blue cube", 230, -80, 0)], "u", 25, wait=True)
            red = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
            builder = executor.scene_builder
            real = builder.looks_near                                # (footprints_near reads through it too)
            calls = {"n": 0}

            def unsteady_then_clear(x, y, looks, within_mm=15.0):
                calls["n"] += 1
                if calls["n"] <= 2:                                  # (the first two looks: all over the place)
                    return [((25.0, 25.0, a), (x, y, 20.0))
                            for a in (0.0, 44.0, 22.0, 66.0, 33.0, 11.0, 55.0, 77.0)][:looks]
                return real(x, y, looks, within_mm)
            builder.looks_near = unsteady_then_clear
            said = executor.execute("pick", {"object_id": red["red cube"]})
            builder.looks_near = real
            self.assertIn("Picked up red cube", said)
            self.assertTrue(executor.last_record["angle"].get("from_afar"), executor.last_record["angle"])
            window.close()

    def test_a_grip_that_missed_is_seen_and_tried_once_more(self):
        import ast
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            window = self.window(Path(folder), [])
            executor = window.ctx.executor
            window._place_demo_cubes([Cube("red cube", 230, 0, 0), Cube("blue cube", 230, -80, 0)], "m", 25, wait=True)

            class NoSense:                                           # (the real Dobot: it can't feel a grip)
                def __init__(self, robot, catches):
                    self._robot, self._catches = robot, catches

                def __getattr__(self, name):
                    if name == "held_object":
                        raise AttributeError(name)
                    return getattr(self._robot, name)

                def close_gripper(self):
                    if self._catches:
                        self._robot.close_gripper()
            real = executor.robot
            red = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
            executor.robot = NoSense(real, catches=False)
            with self.assertRaises(ValueError) as missed:
                executor.execute("pick", {"object_id": red["red cube"]})
            self.assertIn("The grip missed", str(missed.exception))
            self.assertIn("(the second try)", str(missed.exception))
            self.assertIsNone(executor.holding, "not left thinking it holds the cube")
            executor.robot = NoSense(real, catches=True)
            executor.forget_scene()
            red = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
            said = executor.execute("pick", {"object_id": red["red cube"]})
            self.assertIn("Picked up red cube", said)
            self.assertNotIn("missed", said)
            executor.robot = real
            window.close()

    def test_review_two_a_hidden_cube_an_old_stray_and_a_reference_tower_are_not_flagged(self):
        import importlib.util
        from watcher.arrange import blocking_cubes
        from watcher.tasks import outcome, score
        from watcher.taxonomy import RunFacts, classify
        tasks = load_task_set(SIMPLE, 3)
        spec = importlib.util.spec_from_file_location("rescore_v42", ROOT / "study" / "rescore_v42.py")
        rescore = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(rescore)
        # (1) S-12 left red on green; S-13 then did nothing: green is under red at the end, not knocked off
        start = [{"label": "green cube", "x": 230, "y": 0, "level": 1}, {"label": "red cube", "x": 230, "y": 0, "level": 2},
                 {"label": "blue cube", "x": 230, "y": -70}]
        run = {"task": "S-13", "passed": False, "start_seen": start,
               "end_seen": [{"label": "red cube", "x": 230, "y": 0, "level": 2}, {"label": "blue cube", "x": 230, "y": -70}]}
        new = rescore.rescore_run(run, Path("."), tasks)
        self.assertFalse(any("green" in c for c in new["catastrophic"]), new["catastrophic"])
        self.assertEqual(new["outcome"], "FAIL")
        # (2) a cube already outside the tray at the start, left alone: not the run's doing
        s01 = tasks.task("S-01")
        before = [Cube("red cube", 230, 70), Cube("green cube", 230, 0), Cube("blue cube", 320, -70)]
        after = [Cube("red cube", 270, 70), Cube("green cube", 230, 0), Cube("blue cube", 320, -70)]
        result = score(s01, after, tasks.zones, tasks.rule, 25, start=before, area=tasks.area)
        self.assertEqual((result.passed, result.catastrophic), (True, []))
        # ... and a task's own cube put where it was asked, there (S-07 swapping red with a blue left outside)
        s07 = tasks.task("S-07")
        before = [Cube("red cube", 230, 70), Cube("green cube", 230, 0), Cube("blue cube", 150, -70)]
        after = [Cube("red cube", 150, -70, 0), Cube("green cube", 230, 0), Cube("blue cube", 230, 70, 30)]
        result = score(s07, after, tasks.zones, tasks.rule, 25, start=before, area=tasks.area)
        self.assertEqual((result.passed, result.catastrophic), (True, []))
        # (3) S-18 starts from green, red, blue: red is under the cube it moves (blue) -- not "in the way"
        tower = [Cube("green cube", 230, 70, 0, 1), Cube("red cube", 230, 70, 0, 2), Cube("blue cube", 230, 70, 0, 3)]
        self.assertEqual(blocking_cubes(tasks.task("S-18"), tasks, tower), {})
        # (4a) the first-wrong-step rule only where V4.2's rules apply
        s05 = tasks.task("S-05")
        three = [Cube("red cube", 230, 70), Cube("green cube", 230, 0), Cube("blue cube", 230, -70)]
        facts = RunFacts(tool_names=["move_object"], tool_args=[{"object_id": "red cube", "direction": "forward",
                                                                  "distance_mm": 40}],
                         tool_results=["ERROR: outside the robot's safe workspace"])
        end = [Cube("red cube", 230, 70), Cube("green cube", 230, 0), Cube("blue cube", 190, -70)]   # (blue moved)
        result = score(s05, end, tasks.zones, tasks.rule, 25, start=three)
        self.assertEqual(classify(s05, result, facts, three, end, seen_start=three), "limit_alarm")
        self.assertEqual(classify(s05, result, facts, three, end, seen_start=three, first_step=True), "plan")
        # (minor) a part "met" by camera noise, nothing moved: not SOME PARTS
        s03 = tasks.task("S-03")
        near = [Cube("red cube", 230, 70), Cube("green cube", 280.0 - 11, 0), Cube("blue cube", 230, -70)]
        wobble = [Cube("red cube", 230, 70), Cube("green cube", 280.0 - 9, 0), Cube("blue cube", 230, -70)]
        result = score(s03, wobble, tasks.zones, tasks.rule, 25, start=near)
        from watcher.tasks import moved_cubes
        self.assertEqual(outcome(result, None, moved_cubes(near, wobble)), "FAIL")

    def test_a_cube_sent_the_wrong_way_is_a_plan_failure_and_study_1_is_rescored(self):
        import tempfile
        from watcher.taxonomy import RunFacts, object_labels_from, wrong_direction
        tasks = load_task_set(SIMPLE, 3)
        start = [Cube("red cube", 230, 70), Cube("green cube", 230, 0), Cube("blue cube", 230, -70)]
        looked = ("{'holding': None, 'objects': [{'id': 'obj_5', 'label': 'blue cube'}, "
                  "{'id': 'obj_6', 'label': 'red cube'}]}")
        calls = [("list_objects", {}, looked),
                 ("move_object", {"object_id": "obj_6", "direction": "forward", "distance_mm": 40},
                  "ERROR: Place target at (307, 71, 33) mm is outside the robot's safe workspace"),
                 ("move_object", {"object_id": "obj_5", "direction": "back", "distance_mm": 40}, "Moved")]
        facts = RunFacts(tool_names=[c[0] for c in calls], tool_args=[c[1] for c in calls],
                         tool_results=[c[2] for c in calls], object_labels=object_labels_from([looked]))
        self.assertEqual(facts.object_labels, {"obj_5": "blue cube", "obj_6": "red cube"})
        self.assertIn("moved the red cube 'forward'", wrong_direction(tasks.task("S-05"), facts, start))
        # study 1's saved runs scored again with V4.2's rules, beside the originals
        import importlib.util
        spec = importlib.util.spec_from_file_location("rescore_v42", ROOT / "study" / "rescore_v42.py")
        rescore = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(rescore)
        with tempfile.TemporaryDirectory() as folder:
            session = results.Session.start(True, "simple", "dobot", 1, "base", {}, root=Path(folder))
            run = session.run_folder("S-05", 1)
            results.write_json(run / "run.json", {
                "task": "S-05", "passed": False, "failure": "limit_alarm", "credit": {"score": 0},
                "start_seen": [c.__dict__ for c in start],
                "end_seen": [{"label": "red cube", "x": 230, "y": 70}, {"label": "green cube", "x": 230, "y": 0},
                             {"label": "blue cube", "x": 150, "y": -70}],
                "calls": [{"tool": n, "args": a, "result": r} for n, a, r in calls]})
            session.save_run(run, "S-05", "Run1")
            md = rescore.rescore(session.kind_folder, tasks).read_text(encoding="utf-8")
            self.assertIn("| S-05_Run1 | FAIL | limit_alarm | 0 | FAIL | plan | 0 |", md)
            self.assertTrue((session.kind_folder / "rescored_v4.2.json").exists())
            self.assertFalse((session.kind_folder / "FULL_REPORT.md").exists(), "nothing else written")

    def test_a_task_starts_with_the_cubes_there_and_skips_only_when_none_of_its_own_are(self):
        from watcher.arrange import infer_hidden, scene_report
        tasks = load_task_set(SIMPLE, 3)
        three = ["red cube", "green cube", "blue cube"]
        only_red = [Cube("red cube", 230, 70)]
        s03 = scene_report(tasks.task("S-03"), tasks, only_red, three)           # S-03: the green cube
        self.assertFalse(s03["can_start"], "none of its own cubes: skipped")
        self.assertEqual(s03["condition"], ["cube not seen"])
        s05 = scene_report(tasks.task("S-05"), tasks, only_red, three)           # S-05: red and blue
        self.assertTrue(s05["can_start"], "the red cube is there: it starts")
        self.assertEqual([p["possible"] for p in s05["parts"]], [True, False], "the blue part impossible, and why")
        self.assertIn("the blue cube can't be seen", s05["parts"][1]["why"])
        # a tower left by the task before: the cube under it is there, not missing
        known = {c: Cube(c, x, y) for c, (x, y) in {"red cube": (230, 70), "green cube": (230, 0),
                                                   "blue cube": (230, -70)}.items()}
        cubes, hidden = infer_hidden([Cube("red cube", 230, 0, 0, 2), Cube("blue cube", 230, -70)], known)
        self.assertEqual(hidden, {"green cube": "red cube"})
        report = scene_report(tasks.task("S-03"), tasks, cubes, three, hidden)
        self.assertEqual((report["missing"], report["condition"], report["can_start"]),
                         ([], ["tower to take down"], True))
        self.assertTrue(scene_report(tasks.task("S-01"), tasks, [], three)["empty"])


class SkippedWordsTests(unittest.TestCase):
    """A skipped task in words: what it needed vs what was there, the chain back to the last task that ran, and a
    failed set-out's refused steps -- what Claude reads to find the cause."""

    def test_every_detail_is_said(self):
        from watcher import report
        skip = {"why": "the green cube is too close to the blue", "by": "the watcher", "waited_s": 20.4,
                "table_checks": 9, "seen": [{"label": "green cube", "x": 210.0, "y": 15.0}],
                "expected": [{"cube": "green cube", "wanted": [230.0, 0.0], "wanted_level": 1, "seen": [210.0, 15.0],
                              "seen_level": 1, "off_mm": 25.0},
                             {"cube": "red cube", "wanted": [230.0, 70.0], "wanted_level": 2, "seen": None,
                              "seen_level": None, "off_mm": None}],
                "task_before": {"task": "S-06", "run": "S-06_Run1", "result": "SKIPPED", "ended": [],
                                "last_ran": {"task": "S-05", "run": "S-05_Run1", "result": "FAIL",
                                             "failure": "execution", "score_100": 40,
                                             "ended": [{"label": "green cube", "x": 212.0, "y": 14.0}]}},
                "set_out": {"ok": False, "why": "the red cube couldn't be reached", "moves": "1 move(s)",
                            "refused": [{"tool": "pick", "args": {"object_id": "red cube"},
                                         "result": "ERROR: out of reach"}]}}
        text = " ".join(report.skipped_lines(skip))
        self.assertIn("green cube wanted (230, 0), seen (210, 15), 25 mm off", text)
        self.assertIn("red cube wanted (230, 70) level 2, NOT SEEN", text)
        self.assertIn("The task before: S-06_Run1, SKIPPED", text)
        self.assertIn("The last task that ran: S-05_Run1, FAIL (execution), score 40/100", text)
        self.assertIn("FAILED (the red cube couldn't be reached)", text)
        self.assertIn("Refused in the set-out: pick(", text)
        self.assertIn("ERROR: out of reach", text)


class RunLogStepTests(unittest.TestCase):
    """The run log's step lines are whole: list_objects as the cubes it saw, a refusal with its whole reason, ids by
    value -- and a test's steps still only by name."""

    def test_list_objects_in_a_line(self):
        from watcher.window import step_line
        seen = {"holding": None, "saved_places": [],
                "objects": [{"id": "obj_1", "label": "red cube", "xyz_mm": (230.2, 70.0, 26.0), "confidence": 1.0},
                            {"id": "obj_2", "label": "green cube", "xyz_mm": (230.0, 0.0, 26.0)},
                            {"id": "obj_3", "label": "blue cube", "xyz_mm": (230.0, -70.0, 51.0)}]}
        self.assertEqual(step_line("list_objects", {}, str(seen)),
                         "list_objects → 3 cubes: red (230, 70, 26), green (230, 0, 26), blue (230, -70, 51)")
        seen.update(holding="red cube", hidden=[{"label": "green cube", "under": "red cube"}],
                    not_seen_now=[{"label": "yellow cube", "last_at_mm": (150, -80), "why": "no longer seen where it was"}])
        self.assertIn("; holding the red cube; hidden: green cube under the red cube; not seen now: yellow cube "
                      "(last at 150, -80: no longer seen where it was)", step_line("list_objects", {}, str(seen)))
        numpy = str(seen).replace("'confidence': 1.0", "'confidence': np.float64(1.0)")
        self.assertIn("red (230, 70, 26)", step_line("list_objects", {}, numpy))
        for odd in ("no camera", "{'objects': [1, 2]}", "{'objects': [], 'hidden': ['green cube']}"):
            self.assertEqual(step_line("list_objects", {}, odd), "list_objects → " + odd)    # as it came

    def test_arguments_and_a_refusal_whole(self):
        from watcher.window import step_line
        reason = "Not putting the red cube down at (145, -67): " + "it would land on the green cube. " * 6
        self.assertEqual(step_line("place", {"x": 145.0, "y": -67, "z": 20}, "ERROR: " + reason),
                         "place(x=145, y=-67, z=20) → " + reason)
        self.assertEqual(step_line("swap", {"object_id_a": "obj_1", "object_id_b": "obj_2"}, "Swapped."),
                         "swap(obj_1, obj_2) → Swapped.")
        self.assertEqual(step_line("turn_object", {"object_ids": ["obj_1"], "turn_deg": 45.5}, "Turned."),
                         'turn_object(["obj_1"], turn_deg=45.5) → Turned.')
        self.assertEqual(step_line("pick", '{"object_id": "obj_1"', "ERROR: bad arguments"),
                         'pick({"object_id": "obj_1") → bad arguments')

    def test_run_log_lines(self):
        import threading
        from watcher.window import WatcherWindow
        for hide, want in ((False, "  REFUSED pick(obj_1) → out of reach"), (True, "  REFUSED pick(…)")):
            lines = []
            fake = SimpleNamespace(_lock=threading.Lock(), events=[], _hide_prompts=lambda h=hide: h, _log=lines.append,
                                   steps=[SimpleNamespace(tool_name="pick", arguments={"object_id": "obj_1"},
                                                          result="ERROR: out of reach")])
            WatcherWindow._show_progress(fake)
            self.assertEqual(lines, [want])


if __name__ == "__main__":
    unittest.main()

"""The cube size (Settings > Cubes, 20 or 25 mm): one setting in config.yaml for the app, the twin and the watcher,
saved from every Settings panel, refused while something is using it, and recorded with every run.

    python -m unittest discover -s tests -p test_cube_size.py -v

Uses a temporary folder for config.yaml: nothing in the project changes.
"""
from __future__ import annotations

import os
import shutil
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: E402  (sets up sys.path and the working folder)
import yaml  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

from app.config import load_config  # noqa: E402
from app.cube_size import CUBE_SIZES_MM, cube_mm, describe, size_mismatch  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402
from watcher import report  # noqa: E402
from watcher.tasks import load_task_set  # noqa: E402

app = QApplication.instance() or QApplication([])
TRAIN = ROOT / "study" / "tasks" / "train.yaml"


class CubeSizeValueTests(unittest.TestCase):
    def test_read_from_config_or_25(self):
        self.assertEqual(cube_mm({"vision": {"known_sizes_mm": {"cube": 20}}}), 20.0)
        for config in ({}, None, {"vision": {}}, {"vision": {"known_sizes_mm": {"cube": "?"}}},
                       {"vision": {"known_sizes_mm": {"cube": 0}}}):
            self.assertEqual(cube_mm(config), 25.0, config)

    def test_both_sizes_offered_and_shown_plainly(self):
        self.assertEqual(set(CUBE_SIZES_MM), {20.0, 25.0})
        self.assertEqual(describe(20.0), "20 mm")


class TaskSetTests(unittest.TestCase):
    def test_the_setting_overrides_the_task_files_size(self):
        self.assertEqual(load_task_set(TRAIN, 3).cube_size_mm, 25.0, "the file's own size without a setting")
        self.assertEqual(load_task_set(TRAIN, 3, 20.0).cube_size_mm, 20.0)

    def test_each_runs_report_says_its_cube_size(self):
        self.assertEqual(report.cube_size_of({"conditions": {"cube_size_mm": 20.0}}), 20.0)
        self.assertEqual(report.cube_size_of({"conditions": {}}), 25.0, "older runs: 25 mm")
        self.assertIn("Cubes (mm)", [name for name, _ in report.RUN_COLUMNS])


class SettingsCubeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        shutil.copy(ROOT / "config.yaml", Path(cls.folder.name) / "config.yaml")
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
        config["display"] = {}
        config["vision"].setdefault("known_sizes_mm", {})["cube"] = 25.0
        cls.window = main_window_module.MainWindow(config)
        cls.window.show()

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def setUp(self):
        self.window._on_cube_size(25.0)

    def saved(self):
        raw = yaml.safe_load((Path(self.folder.name) / "config.yaml").read_text(encoding="utf-8"))
        return raw["vision"]["known_sizes_mm"]["cube"]

    def test_in_every_settings_panel_and_beside_the_prompt(self):
        self.assertEqual(len(self.window._cube_combos), len(self.window._settings_panels) + 1)
        self.assertGreaterEqual(len(self.window._cube_combos), 2)
        beside = [c for c in self.window._cube_combos if self.window.prompt_panel.isAncestorOf(c)]
        self.assertEqual(len(beside), 1, "one beside the prompt box")

    def test_locked_while_a_prompt_runs(self):
        self.window._on_prompt_busy(True)
        try:
            self.assertFalse(any(c.isEnabled() for c in self.window._cube_combos))
        finally:
            self.window._on_prompt_busy(False)
        self.assertTrue(all(c.isEnabled() for c in self.window._cube_combos))

    def test_cubes_of_the_other_size_offer_it_never_set_by_themselves(self):
        from PyQt6.QtWidgets import QMessageBox
        executor = self.window.tool_executor
        asked = []
        original = QMessageBox.exec
        try:
            for which in ("Keep", "Set"):
                executor.cube_mismatch = (20.3, 25.0, 20.0)

                def answer(box, which=which):
                    asked.append(box.text())
                    next(b for b in box.buttons() if b.text().startswith(which)).click()
                QMessageBox.exec = answer
                self.window._offer_cube_size()
                if which == "Keep":
                    self.assertEqual(self.saved(), 25.0, "kept: not changed")
                    self.assertEqual(executor.cube_size_kept, (25.0, 20.0))
                else:
                    self.assertEqual(self.saved(), 20.0, "set: the user's choice")
                self.assertIsNone(executor.cube_mismatch)
            self.window._offer_cube_size()                     # (nothing to offer: no box)
        finally:
            QMessageBox.exec = original
            executor.cube_size_kept = None
            executor.cube_mismatch = None
        self.assertEqual(len(asked), 2)
        self.assertIn("measure about 20 mm", asked[0])


    def test_a_new_size_is_saved_and_shown_everywhere(self):
        self.window._on_cube_size(20.0)
        self.assertEqual(self.saved(), 20.0)
        self.assertEqual(cube_mm(self.window.config), 20.0)
        self.assertTrue(all(c.currentText() == "20 mm" for c in self.window._cube_combos))
        self.assertIn("No need to calibrate again", self.window.statusBar().currentMessage())

    def test_refused_while_calibrating_or_the_watcher_is_open(self):
        panel = self.window.calibration_tab
        for busy, words in (("calibration", "calibration is under way"), ("watcher", "watcher's session is open")):
            if busy == "calibration":
                panel._worker = object()
            else:
                self.window._watcher_active = True
            try:
                self.window._on_cube_size(20.0)
            finally:
                panel._worker = None
                self.window._watcher_active = False
            self.assertEqual(self.saved(), 25.0, busy)
            self.assertTrue(all(c.currentText() == "25 mm" for c in self.window._cube_combos), busy)
            self.assertIn(words, self.window.statusBar().currentMessage())

    def test_the_calibration_tab_picks_its_cube_size_from_a_list(self):
        panel = self.window.calibration_tab
        choice, box = panel.cube_size_choice, panel.cube_size
        self.assertEqual([choice.itemText(i) for i in range(choice.count())],
                         ["Cube 25 mm", "Cube 20 mm", "Size: measure", "Other size (type it)"])
        self.assertEqual(choice.currentText(), "Size: measure", "the demo's calibration cube is measured")
        self.assertEqual(box.value(), 0.0)
        self.assertFalse(box.isVisibleTo(panel), "nothing to type")
        choice.setCurrentIndex(choice.findText("Cube 20 mm"))
        self.assertEqual(box.value(), 20.0, "what the calibration reads")
        panel.set_cube_size(24.8)                                          # (measured with calipers)
        self.assertEqual(choice.currentText(), "Other size (type it)")
        self.assertAlmostEqual(box.value(), 24.8)
        self.assertTrue(box.isVisibleTo(panel), "typed, so shown")
        panel.set_cube_size(25.0)
        self.assertEqual(choice.currentText(), "Cube 25 mm")
        self.assertFalse(box.isVisibleTo(panel))
        panel.set_cube_size(None)
        self.assertEqual(box.value(), 0.0)


class MeasuredSizeTests(unittest.TestCase):
    """Study 2's lab notes: 20 or 25 mm cubes. A 20 mm cube measured near 25 was called 25 mm; now the cubes' own
    measurements are kept, and a clear difference stops the arm and offers the other size."""

    def test_only_a_clear_difference(self):
        self.assertEqual(size_mismatch(20.4, 25.0), 20.0)
        self.assertEqual(size_mismatch(24.6, 20.0), 25.0)
        for measured, setting in ((23.5, 25.0), (22.0, 25.0), (25.4, 25.0), (21.5, 20.0), (None, 25.0), (20.0, None)):
            self.assertIsNone(size_mismatch(measured, setting), (measured, setting))

    def test_twin_cubes_measured_as_they_are(self):
        import numpy as np
        from app import robots
        from app.hardware.interfaces import Pose
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.twin.world import TwinWorld
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        profile = robots.set_active("dobot_magician")
        cubes = (("red", [0.85, 0.1, 0.1, 1], (230.0, 60.0), 20.0), ("green", [0.1, 0.7, 0.2, 1], (200.0, -40.0), 0.0),
                 ("blue", [0.1, 0.2, 0.8, 1], (260.0, -10.0), 40.0))
        for cubes_mm, setting, expected in ((20.0, 25.0, 20.0), (25.0, 25.0, None), (25.0, 20.0, 25.0),
                                            (20.0, 20.0, None)):
            with self.subTest(cubes=cubes_mm, setting=setting):
                world = TwinWorld()
                client = world.start()
                try:
                    world.switch_scenario("sizes", {"name": "sizes", "places": {}, "objects": [
                        {"id": f"{c}_cube_0", "label": f"{c} cube", "color_rgba": rgba, "size_mm": cubes_mm,
                         "position_mm": [x, y, cubes_mm / 2], "yaw_deg": yaw} for c, rgba, (x, y), yaw in cubes]})
                    robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                                     max_reach_mm=profile.max_reach_mm, world=world)
                    robot.connect()
                    camera = SimCamera(client)
                    camera.outline_bodies = robot.body_ids
                    camera.connect()
                    camera.set_faults("Realistic")
                    camera._rng = np.random.default_rng(3)
                    robot.move_to(Pose(*profile.demo_look_pose))
                    transform = camera.camera_to_robot_transform()
                    detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: robot.arm_state()[0],
                                                   world.places, world.place_areas)
                    builder = SceneBuilder(camera, detector, transform, known_sizes={"cube": setting},
                                           cubes_only=True)
                    for _ in range(3):
                        seen = builder._look()
                    self.assertEqual(len(seen), 3)
                    measured = builder.measured_cube_mm()
                    self.assertAlmostEqual(measured, cubes_mm, delta=2.0)
                    self.assertEqual(size_mismatch(measured, setting), expected)
                    builder.reset_tracking()
                    self.assertIsNone(builder.measured_cube_mm(), "a new table: measured again")
                finally:
                    world.stop()


if __name__ == "__main__":
    unittest.main()

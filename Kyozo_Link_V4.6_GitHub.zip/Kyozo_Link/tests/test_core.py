"""Tests of the calibration machinery against the simulator (no UI).

    python -m unittest discover -s tests -v

The simulator tests take a few minutes in total: the arm moves and the scene is rendered many times.
"""
from __future__ import annotations

import math
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from harness import ROOT, LOOK_POSE, Sim, calibrate_by_clicking, cube_errors, touch_table
from app.calibration import marker as marker_module
from app.calibration.auto import run_auto_calibration, solve_wrist_offset
from app.calibration.replay import resolve
from app.calibration.session import SampleRecord, SessionRecorder
from app.calibration.table_touch import MAX_HEIGHT_CORRECTION_MM, TableTouchRefused, apply_table_touch
from app.calibration.verify import away_poses, choose_targets, run_verification
from app.hardware.interfaces import OutOfReach, Pose
from app.hardware.sim_faults import PRESETS, degrade_depth
from app.vision.detector import ColorBlobDetector
from app.vision.drift import capture_reference, check_view


class TableTouchTests(unittest.TestCase):
    def test_raises_every_height_by_the_offset(self):
        transform = np.eye(4)
        corrected, correction = apply_table_touch(transform, z_touch=-100.0, camera_table_z=-138.0)
        self.assertAlmostEqual(correction, 38.0)
        self.assertAlmostEqual(corrected[2, 3], 38.0)
        self.assertEqual(transform[2, 3], 0.0)   # the original is untouched

    def test_accepts_a_marker_on_top_of_the_gripper_head(self):
        # the real Magician's gripper: tool-head top 45 mm above the wrist, fingertips 105 mm below it
        _, correction = apply_table_touch(np.eye(4), z_touch=-60.0, camera_table_z=-60.0 - 150.0)
        self.assertAlmostEqual(correction, 150.0)

    def test_refuses_a_gap_too_big_to_be_a_tool_offset(self):
        with self.assertRaises(TableTouchRefused):
            apply_table_touch(np.eye(4), z_touch=100.0, camera_table_z=100.0 - MAX_HEIGHT_CORRECTION_MM - 1)


class WristSolverTests(unittest.TestCase):
    def swings(self, offset, angles, direction):
        out = []
        for angle in angles:
            a = math.radians(direction * angle)
            rotated = (offset[0] * math.cos(a) - offset[1] * math.sin(a), offset[0] * math.sin(a) + offset[1] * math.cos(a))
            out.append((rotated[0] - offset[0], rotated[1] - offset[1]))
        return out

    def test_recovers_the_offset_and_the_turning_direction(self):
        angles = [-60.0, -30.0, 30.0, 60.0]
        for direction in (1, -1):
            for offset in ((9.0, -6.0), (-14.0, 11.0), (0.0, 0.0)):
                result = solve_wrist_offset(angles, self.swings(offset, angles, direction))
                self.assertAlmostEqual(result.offset_xy_mm[0], offset[0], places=6)
                self.assertAlmostEqual(result.offset_xy_mm[1], offset[1], places=6)
                if offset != (0.0, 0.0):
                    self.assertEqual(result.direction, direction)


class FaultTests(unittest.TestCase):
    def test_perfect_camera_is_untouched(self):
        depth = np.full((40, 60), 600.0, np.float32)
        self.assertIs(degrade_depth(depth, PRESETS["Perfect"], np.random.default_rng(0)), depth)

    def test_noise_holes_and_outliers(self):
        rng = np.random.default_rng(0)
        depth = np.full((300, 400), 500.0, np.float32)
        depth[:, :50] = 0.0
        out = degrade_depth(depth, PRESETS["Poor"], rng)
        self.assertTrue(np.all(out[:, :50] == 0.0), "invalid pixels stay invalid")
        self.assertGreater(float((out[:, 60:] == 0).mean()), 0.03, "holes appear")
        readings = out[:, 60:][out[:, 60:] > 0]
        self.assertGreater(float(np.std(readings)), 0.8, "depth is noisy")


class DetectorTests(unittest.TestCase):
    def test_red_is_found_on_both_sides_of_the_hue_seam(self):
        colours = {"red": {"hsv_low": [0, 120, 70], "hsv_high": [10, 255, 255]}}
        detector = ColorBlobDetector(colours, min_area_px=200, max_area_px=6000)
        rng = np.random.default_rng(1)
        image = np.full((200, 200, 3), 30, np.uint8)
        image[60:120, 60:120] = (200, 20, 20)
        noisy = np.clip(image.astype(int) + rng.normal(0, 6, image.shape), 0, 255).astype(np.uint8)
        self.assertEqual([d.label for d in detector.detect(noisy)], ["red cube"])


class MarkerSheetTests(unittest.TestCase):
    def test_sheet_has_both_markers_at_true_size(self):
        with tempfile.TemporaryDirectory() as folder:
            path = marker_module.make_marker_sheet(Path(folder) / "sheet.png")
            self.assertIn(b"pHYs", path.read_bytes()[:80], "physical size is recorded in the file")
            page = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
            self.assertEqual(page.shape, (3507, 2480))   # A4 at 300 dpi
            detector = cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(marker_module.DICTIONARY))
            corners, ids, _ = detector.detectMarkers(page)
            sizes = sorted(float(np.linalg.norm(q.reshape(4, 2)[0] - q.reshape(4, 2)[1])) / (300 / 25.4) for q in corners)
            self.assertEqual(len(sizes), 2)
            for found, wanted in zip(sizes, marker_module.MARKER_SIZES_MM):
                self.assertAlmostEqual(found, wanted, delta=0.4)


class SimTests(unittest.TestCase):
    """The procedures, run against the simulated robot and camera."""

    def setUp(self):
        self.sim = Sim(marker_offset_mm=(9.0, -6.0))
        self.addCleanup(self.sim.close)

    def test_a_carried_object_does_not_visually_sink_through_the_tray(self):
        # Jogging the tip down by hand (not through pick/place) used to drive a held object straight
        # through the tray floor, since only pick/place snapped it to a resting height. Now the move stops
        # where it meets the floor, as the real arm would press it on it.
        from app.hardware.sim_robot import Collision
        self.sim.robot._held = "blue_cube"
        self.sim.robot.move_to(Pose(x=280, y=0, z=60))     # over the tray (not through its wall)
        with self.assertRaisesRegex(Collision, "the blue cube it carries touched the tray"):
            self.sim.robot.move_to(Pose(x=280, y=0, z=-50))   # well below the tray floor
        z = self.sim.world.get_object_position_mm("blue_cube")[2]
        self.assertGreaterEqual(z, 14.5 - 0.5, "the cube should rest on the tray floor, not sink into it")

    def test_the_same_carried_object_still_follows_the_tip_in_open_air(self):
        self.sim.robot._held = "blue_cube"
        self.sim.robot.move_to(Pose(x=200, y=-150, z=100))   # clear of the tray and both cubes
        z = self.sim.world.get_object_position_mm("blue_cube")[2]
        half = self.sim.world.object_meta["blue_cube"]["size"][2] / 2   # held by its top: its middle half its height down
        self.assertLess(abs(z - (100 - half)), 0.5)

    def test_marker_is_found_under_a_poor_camera(self):
        self.sim.camera.set_faults("Poor")
        intrinsics = self.sim.camera.get_intrinsics()
        found = 0
        for x, y, r in ((133, -70, 0), (200, 70, 60), (267, -70, -60), (200, 0, 0)):
            self.sim.move(x, y, 90, r)
            frame = self.sim.camera.get_frame()
            found += marker_module.detect_marker(frame.rgb, frame.depth, intrinsics, 30.0) is not None
        self.assertEqual(found, 4)

    def test_session_is_saved_and_replays_to_the_same_answer(self):
        run = calibrate_by_clicking(self.sim, np.random.default_rng(5), click_sigma_px=1.0)
        with tempfile.TemporaryDirectory() as folder:
            recorder = SessionRecorder(Path(folder), self.sim.camera.get_intrinsics(), {"mode": "test"})
            frame = self.sim.camera.get_frame()
            for xyz, (u, v, depth) in zip(run.calibrator.samples_robot, run.calibrator.samples_pixel):
                recorder.add(SampleRecord(xyz, (u, v), depth, "manual", rgb=frame.rgb.copy(), depth=frame.depth.copy()))
            recorder.set_result(honest_error_mm=run.result.honest_error_mm, transform=run.result.transform)
            saved = recorder.save()
            self.assertTrue((saved / "session.json").exists())
            self.assertTrue((saved / "frame_01.png").exists() and (saved / "depth_01.npz").exists())
            again = resolve(saved)
            self.assertAlmostEqual(again["honest_error_mm"], run.result.honest_error_mm, places=6)
            np.testing.assert_allclose(again["transform"], run.result.transform, atol=1e-6)
            self.assertEqual(len(resolve(saved, drop=(2,))["points"]), len(run.calibrator.samples_robot) - 1)
            self.assertIsNotNone(resolve(saved, redepth=True)["honest_error_mm"])

    def test_a_moved_camera_is_noticed_and_noise_is_not(self):
        transform = self.sim.exact_transform()
        self.sim.robot.move_to(Pose(200, 0, 50))
        reference = capture_reference(self.sim.camera, transform)
        for preset in ("Realistic", "Poor"):
            self.sim.camera.set_faults(preset)
            self.sim.robot.move_to(Pose(150, 100, 80))      # the arm is somewhere else now
            self.sim.robot._place_object("red_cube", 180, -120, 12.5)   # and a cube was moved
            self.assertEqual(check_view(self.sim.camera, transform, reference).status, "ok", preset)
        self.sim.camera.bump(shift_mm=(8, 5, 0), yaw_deg=0, pitch_deg=0)
        self.assertEqual(check_view(self.sim.camera, transform, reference).status, "moved")
        self.sim.camera.unbump()
        self.sim.camera.bump(shift_mm=(0, 0, 0), yaw_deg=0, pitch_deg=0.5)
        self.assertEqual(check_view(self.sim.camera, transform, reference).status, "moved")

    def test_verification_tells_a_good_calibration_from_a_missing_height_step(self):
        bounds = self.sim.bounds
        targets, away = choose_targets(bounds, 300.0, 0.0), away_poses(bounds, 300.0, 0.0)
        good = run_verification(self.sim.robot, self.sim.camera, self.sim.exact_transform(), targets, away, settle_s=0.0)
        self.assertLess(good.typical_mm, 3.0)
        clicked = calibrate_by_clicking(self.sim, np.random.default_rng(2), click_sigma_px=1.0)
        no_step = run_verification(self.sim.robot, self.sim.camera, clicked.result.transform, targets, away, settle_s=0.0)
        self.assertGreater(no_step.typical_mm, 15.0)
        with_step, _ = touch_table(self.sim, clicked.result.transform)
        fixed = run_verification(self.sim.robot, self.sim.camera, with_step, targets, away, settle_s=0.0)
        self.assertLess(fixed.typical_mm, 8.0)

    def test_automatic_calibration_recovers_an_off_centre_marker(self):
        # the same camera noise every run: unseeded, about one run in ten landed just past the 7 mm limit
        self.sim.camera._rng = np.random.default_rng(11)
        self.sim.camera.set_faults("Realistic")
        self.sim.move(200, 0, 70)
        outcome = run_auto_calibration(self.sim.robot, self.sim.camera, self.sim.bounds, 300.0, 30.0)
        self.assertGreaterEqual(len(outcome.sightings), 8)
        self.assertIsNotNone(outcome.wrist, outcome.wrist_note)
        self.assertAlmostEqual(outcome.wrist.offset_xy_mm[0], 9.0, delta=1.5)
        self.assertAlmostEqual(outcome.wrist.offset_xy_mm[1], -6.0, delta=1.5)
        self.assertGreaterEqual(min(s.robot_xyz[2] for s in outcome.sightings), 69.0, "never goes below the start height")
        transform, _ = touch_table(self.sim, outcome.transform)
        for label, (plane_error, height_error) in cube_errors(self.sim, transform).items():
            self.assertLess(plane_error, 7.0, label)
            self.assertLess(abs(height_error), 3.0, label)

    def test_a_spot_the_arm_cannot_reach_is_skipped_not_recorded(self):
        """The real arm stopped short of one sweep position (a joint limit) and the sweep carried on as if it
        had got there. Now the driver says so, and the sweep leaves that spot out."""
        robot, real_move = self.sim.robot, self.sim.robot.move_to
        refused = []

        def limited(pose, speed=None):
            if pose.y < -150 and pose.x < 170:
                refused.append(pose)
                raise OutOfReach("can't reach")
            return real_move(pose, speed)
        robot.move_to = limited
        self.sim.move(200, 0, 70)
        outcome = run_auto_calibration(robot, self.sim.camera, self.sim.bounds, 300.0, 30.0)
        self.assertTrue(refused, "the test should have hit a refused spot")
        self.assertIsNotNone(outcome.solve)
        self.assertFalse(any(s.robot_xyz[1] < -150 and s.robot_xyz[0] < 170 for s in outcome.sightings))
        self.assertLess(outcome.solve.honest_error_mm, 8.0)

    def test_the_sweep_stops_when_the_arm_keeps_being_refused(self):
        robot = self.sim.robot

        def refusing(pose, speed=None):
            raise OutOfReach("can't reach")
        self.sim.move(200, 0, 70)
        robot.move_to = refusing
        with self.assertRaisesRegex(RuntimeError, "2 positions in a row"):
            run_auto_calibration(robot, self.sim.camera, self.sim.bounds, 300.0, 30.0)


if __name__ == "__main__":
    unittest.main()

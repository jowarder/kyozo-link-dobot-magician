"""Continuous calibration (app/calibration/continuous.py): the running score, the corrections and their limits, on a
made-up camera looking down at the A4 sheet over a textured table.

Run from the project root:  python -m unittest tests.test_continuous
"""
from __future__ import annotations

import unittest

from harness import ROOT  # noqa: F401  (sets up sys.path and the working folder)
import cv2  # noqa: E402
import numpy as np  # noqa: E402

from app.calibration import continuous as cc  # noqa: E402
from app.hardware.interfaces import Intrinsics  # noqa: E402
from app.vision.paper import DESIGNED  # noqa: E402

INTR = Intrinsics(fx=600.0, fy=600.0, cx=320.0, cy=240.0, width=640, height=480)
HEIGHT = 600.0            # the camera this far above the table


def _camera_to_robot() -> np.ndarray:
    """A camera 600 mm above the sheet's middle, looking straight down (its x along the robot's -y)."""
    t = np.eye(4)
    t[:3, :3] = np.array([[0.0, -1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, -1.0]])
    t[:3, 3] = [225.0, 0.0, HEIGHT]
    return t


def _moved(transform: np.ndarray, dx_mm: float = 0.0, dy_mm: float = 0.0) -> np.ndarray:
    """The camera shifted by (dx, dy) mm along its own x and y."""
    shift = np.eye(4)
    shift[:3, 3] = [dx_mm, dy_mm, 0.0]
    return transform @ shift


ROBOT_CORNERS = np.array([[x, y, 0.0] for x, y in DESIGNED.corners()])
TEXTURE = cv2.GaussianBlur(np.random.default_rng(1).integers(0, 255, (480, 640)).astype(np.uint8), (3, 3), 0)


def _picture(dx_mm: float = 0.0, dy_mm: float = 0.0) -> np.ndarray:
    """What the camera sees, moved by (dx, dy) mm: the table's texture slides the other way in the picture."""
    px, py = -INTR.fx * dx_mm / HEIGHT, -INTR.fy * dy_mm / HEIGHT
    shifted = cv2.warpAffine(TEXTURE, np.float32([[1, 0, px], [0, 1, py]]), (640, 480), borderMode=cv2.BORDER_REFLECT)
    return np.dstack([shifted] * 3)


def _corners_seen(true_transform: np.ndarray, sheet_shift=(0.0, 0.0), noise: float = 0.0, rng=None) -> np.ndarray:
    sheet = ROBOT_CORNERS + np.array([sheet_shift[0], sheet_shift[1], 0.0])
    cam = cc.apply(np.linalg.inv(true_transform), sheet)
    if noise:
        cam = cam + (rng or np.random.default_rng(0)).normal(0.0, noise, cam.shape)
    return cam[[2, 3, 0, 1]]           # (listed from another corner: the matching must cope)


class TrackerTest(unittest.TestCase):
    def setUp(self):
        self.calibrated = _camera_to_robot()
        self.reference = cc.make_reference(_picture(), _corners_seen(self.calibrated), INTR, self.calibrated)
        self.tracker = cc.Tracker(self.reference, self.calibrated)

    def look(self, true_transform, picture, sheet_shift=(0.0, 0.0), noise=0.0, rng=None) -> cc.Decision:
        corners = _corners_seen(true_transform, sheet_shift, noise, rng)
        return self.tracker.add(cc.measure(picture, corners, INTR, self.tracker.transform, self.reference))

    def test_still_camera_is_left_alone(self):
        decisions = [self.look(self.calibrated, _picture()) for _ in range(6)]
        self.assertEqual(decisions[-1].action, "ok")
        self.assertFalse(any(d.action == "correct" for d in decisions))

    def test_one_bad_look_is_skipped(self):
        decision = self.tracker.add(cc.measure(_picture(), None, INTR, self.calibrated, self.reference))
        self.assertEqual(decision.action, "wait")
        self.assertEqual(self.tracker.window, [])

    def test_a_steady_move_is_corrected_in_small_steps(self):
        true = _moved(self.calibrated, 3.0, -1.5)
        picture = _picture(3.0, -1.5)
        rng = np.random.default_rng(3)
        actions = []
        for _ in range(40):
            decision = self.look(true, picture, noise=0.15, rng=rng)
            actions.append(decision.action)
            if decision.action == "correct":
                self.assertLessEqual(decision.record["step_mm"], cc.STEP_MM + 1e-6)
        self.assertGreaterEqual(actions.count("correct"), 2)          # 3.4 mm in steps of at most 2
        self.assertEqual(actions.count("revert"), 0)
        self.assertEqual(actions[-1], "ok")
        left = np.linalg.norm(cc.apply(self.tracker.transform, cc.apply(np.linalg.inv(true), ROBOT_CORNERS))
                              - ROBOT_CORNERS, axis=1).mean()
        self.assertLess(left, cc.NOISE_MM)

    def test_a_moved_sheet_is_only_reported(self):
        decisions = [self.look(self.calibrated, _picture(), sheet_shift=(4.0, 2.0)) for _ in range(5)]
        self.assertEqual(decisions[-1].action, "warn")
        self.assertIn("sheet has moved", decisions[-1].text)
        self.assertTrue(np.allclose(self.tracker.transform, self.calibrated))

    def test_a_correction_that_does_not_help_is_undone(self):
        true = _moved(self.calibrated, 2.0)
        picture = _picture(2.0)
        for _ in range(4):
            decision = self.look(true, picture)
        self.assertEqual(decision.action, "correct")
        # ...but the looks after it find the sheet further off than before (the camera moved again, say)
        worse = _moved(self.calibrated, 6.0)
        for _ in range(cc.VERIFY_CHECKS):
            decision = self.look(worse, _picture(6.0))
        self.assertEqual(decision.action, "revert")
        self.assertTrue(np.allclose(self.tracker.transform, self.calibrated))

    def test_a_knock_stops_it(self):
        true = _moved(self.calibrated, 14.0)
        picture = _picture(14.0)
        actions = [self.look(true, picture).action for _ in range(60)]
        self.assertIn("stop", actions)
        self.assertIsNotNone(self.tracker.stopped)
        total_mm, _ = self.tracker.total()
        self.assertLessEqual(total_mm, cc.TOTAL_MM + 1e-6)

    def depth_look(self, dz_mm: float) -> cc.Decision:
        """The camera's distances drifted by dz (the picture itself still)."""
        corners = _corners_seen(self.calibrated) + np.array([0.0, 0.0, dz_mm])
        return self.tracker.add(cc.measure(_picture(), corners, INTR, self.tracker.transform, self.reference))

    def test_a_little_depth_noise_is_left_alone(self):
        decisions = [self.depth_look(1.0) for _ in range(6)]
        self.assertEqual(decisions[-1].action, "ok")
        self.assertTrue(np.allclose(self.tracker.transform, self.calibrated))

    def test_a_steady_depth_drift_is_corrected(self):
        actions = []
        for _ in range(30):
            corners = cc.apply(np.linalg.inv(self.calibrated), ROBOT_CORNERS) + np.array([0.0, 0.0, 3.0])
            decision = self.tracker.add(cc.measure(_picture(), corners, INTR, self.tracker.transform, self.reference))
            actions.append(decision.action)
        self.assertIn("correct", actions)
        self.assertNotIn("revert", actions)
        left = np.linalg.norm(cc.apply(self.tracker.transform, corners) - ROBOT_CORNERS, axis=1).mean()
        self.assertLess(left, 2.0 * cc.NOISE_MM)

    def test_the_start_averages_a_few_looks(self):
        from types import SimpleNamespace
        rng = np.random.default_rng(5)
        truth = cc.apply(np.linalg.inv(self.calibrated), ROBOT_CORNERS)
        camera = SimpleNamespace(get_intrinsics=lambda: INTR, get_frame=lambda: SimpleNamespace(rgb=_picture()))
        looks = iter([None, *(truth + rng.normal(0.0, 0.5, truth.shape) for _ in range(4))])
        reference = cc.start_reference(camera, self.calibrated,
                                       lambda frame, intr, t: (next(looks), "a hand in the way"))
        self.assertLess(np.linalg.norm(reference.corners_robot - ROBOT_CORNERS, axis=1).mean(), 0.6)
        with self.assertRaises(RuntimeError):
            cc.start_reference(camera, self.calibrated, lambda frame, intr, t: (None, "a hand in the way"))

    def test_corrections_that_never_help_stop_it(self):
        # (what moved isn't a rigid move of the camera: the same correction was tried and undone again and again)
        shifted = self.reference.corners_robot + np.array([2.0, 0.0, 0.0])
        actions = []
        for _ in range(40):
            look = cc.Check("camera_moved", misfit_mm=2.0, move_mm=2.0, turn_deg=0.0, measured_robot=shifted)
            actions.append(self.tracker.add(look).action)
            if self.tracker.stopped:
                break
        self.assertEqual(actions.count("revert"), cc.MAX_REVERTS)
        self.assertIn("didn't help", self.tracker.stopped)
        self.assertTrue(np.allclose(self.tracker.transform, self.calibrated), "left on the last good calibration")

    def test_reference_round_trip(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "c.continuous.npz"
            self.reference.save(path)
            loaded = cc.Reference.load(path)
        self.assertTrue(np.allclose(loaded.corners_robot, self.reference.corners_robot))
        self.assertTrue(np.allclose(loaded.start_transform, self.calibrated))


class HelpersTest(unittest.TestCase):
    def test_limited_caps_the_step(self):
        d = np.eye(4)
        d[:3, 3] = [5.0, 0.0, 0.0]
        step = cc.limited(d, ROBOT_CORNERS, step_mm=2.0)
        self.assertAlmostEqual(float(np.linalg.norm(step[:3, 3])), 2.0, places=6)

    def test_limited_caps_the_turn(self):
        rotation, _ = cv2.Rodrigues(np.array([0.0, 0.0, np.radians(1.0)]))
        d = np.eye(4)
        d[:3, :3] = rotation
        step = cc.limited(d, ROBOT_CORNERS, step_mm=100.0, step_deg=0.3)
        self.assertAlmostEqual(cc.turn_deg(step[:3, :3]), 0.3, places=4)


if __name__ == "__main__":
    unittest.main()

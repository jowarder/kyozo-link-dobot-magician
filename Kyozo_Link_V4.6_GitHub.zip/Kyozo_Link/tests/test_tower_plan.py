"""The tower a request asks for, worked out before anything is built: places by colour ("purple at the third", "the
green one at the third position from bottom"), all of them unless a number is given, and what can't be built said so.

    python -m unittest discover -s tests -p test_tower_plan.py -v
"""
from __future__ import annotations

import unittest

from harness import ROOT  # noqa: F401  (sets up sys.path and the working folder)

from app.llm.agent import Agent
from app.llm.tower_plan import tower_plan
from app.vision.scene import SceneObject

CUBES = ["purple cube", "yellow cube", "green cube", "blue cube", "red cube"]


def plan(prompt, given=()):
    return tower_plan(prompt, CUBES, list(given))


class PlanTests(unittest.TestCase):
    def test_red_at_the_bottom_and_purple_at_the_third(self):
        # as it happened: built red, purple, green -- purple second, two cubes left out -- and let through
        tower, _ = plan("build a tower the red should be at the bottom and the purple should be at the third",
                        ["red cube", "purple cube", "green cube"])
        self.assertEqual(len(tower), 5)
        self.assertEqual(tower[0], "red cube")
        self.assertEqual(tower[2], "purple cube")
        self.assertEqual(tower[1], "green cube", "the cubes not placed keep the model's order")

    def test_the_green_one_at_the_third_position_from_bottom_with_all_the_cubes(self):
        # as it happened: built purple, green, yellow, red -- green second, blue left out
        tower, _ = plan("build a tower with all the cubes. make sure to put the green one at the third position from "
                        "bottom", ["purple cube", "green cube", "yellow cube", "red cube"])
        self.assertEqual(tower, ["purple cube", "yellow cube", "green cube", "red cube", "blue cube"])

    def test_other_ways_of_saying_a_place(self):
        self.assertEqual(plan("build a tower, the yellow one second from the top")[0][3], "yellow cube")
        self.assertEqual(plan("put green in the middle of a tower of all the cubes")[0][2], "green cube")
        self.assertEqual(plan("the third one should be yellow, build a tower")[0][2], "yellow cube")
        tower, _ = plan("build a tower with blue on top and red at the bottom")
        self.assertEqual((len(tower), tower[0], tower[-1]), (5, "red cube", "blue cube"))

    def test_a_list_of_colours_is_the_whole_order(self):
        self.assertEqual(plan("Tower: red, yellow, green, blue, purple")[0],
                         ["red cube", "yellow cube", "green cube", "blue cube", "purple cube"])
        self.assertEqual(plan("Make a tower: red at the bottom, then blue, then green")[0],
                         ["red cube", "blue cube", "green cube"])

    def test_left_to_the_model(self):
        self.assertEqual(plan("build a tower of three cubes", ["red cube", "blue cube", "green cube"]), (None, None))
        self.assertEqual(plan("Build a tower with all the cubes", CUBES), (None, None))

    def test_what_cant_be_built_is_said(self):
        self.assertIn("can't go there", plan("build a tower with purple sixth")[1])
        self.assertIn("same place", plan("build a tower, red third and blue third")[1])
        self.assertIn("only 5", plan("build a tower of seven cubes")[1])


class GuardTests(unittest.TestCase):
    def test_the_wrong_tower_is_refused_with_the_order_to_send(self):
        class Executor:
            holding = None

            def __init__(self):
                self._last_scene = [SceneObject(f"obj_{i}", label, (200.0, 40.0 * i, 20.0), 1.0)
                                    for i, label in enumerate(CUBES)]
                self.calls = []

            def piles(self):
                return []

            def execute(self, name, args):
                self.calls.append(args["object_ids"])
                return "Built."

        ids = {label: f"obj_{i}" for i, label in enumerate(CUBES)}
        wrong = [ids["red cube"], ids["purple cube"], ids["green cube"]]
        right = [ids[c] for c in ("red cube", "green cube", "purple cube", "yellow cube", "blue cube")]
        replies = [{"role": "assistant", "content": "", "tool_calls": [{"function": {"name": "build_tower",
                                                                                     "arguments": {"object_ids": a}}}]}
                   for a in (wrong, right)] + [{"role": "assistant", "content": "Built."}]

        class Client:
            sent = []

            def chat(self, model, messages, tools=None, temperature=0.2):
                self.sent.append(messages[-1].get("content", ""))
                return replies.pop(0) if len(replies) > 1 else replies[0]

        executor, client = Executor(), Client()
        run = Agent(client, executor, "m").run(
            "build a tower the red should be at the bottom and the purple should be at the third")
        self.assertIn("Call build_tower with object_ids in that order: [" + ", ".join(right) + "]", run.steps[0].result)
        self.assertEqual(executor.calls, [right], "only the right tower was built")


if __name__ == "__main__":
    unittest.main()

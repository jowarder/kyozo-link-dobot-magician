"""The digital twin's real Magician model: its joints must land where the kinematics say, and the
3D view must draw it (quickly) and still work without the mesh files.

    python -m unittest discover -s tests -p test_magician_model.py -v
"""
from __future__ import annotations

import math
import os
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: F401,E402  (sets up sys.path)
import numpy as np  # noqa: E402
from PyQt6.QtGui import QColor, QFont, QImage, QPainter  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

from app.twin import kinematics, magician_model  # noqa: E402
from app.ui import scene_painter  # noqa: E402

app = QApplication.instance() or QApplication([])   # (a full one: a later test module shows windows)
POSES = [(220, 100, 80), (280, 0, 25), (170, 60, 150), (250, -150, 40), (180, -40, 0), (160, 0, 220)]


class JointChainTests(unittest.TestCase):
    def test_every_joint_lands_where_the_kinematics_put_it(self):
        for x, y, z in POSES:
            g = kinematics.arm_geometry(x, y, z)
            q1, q2, q3 = magician_model.joint_values(g)
            t = magician_model.link_transforms(q1, q2, q3, 0.0, 0.0)
            for part, point in (("magicianLink2", g.shoulder), ("magicianLink3", g.elbow),
                                ("magicianLink4", g.wrist), ("gripper_core", g.tool_corner)):
                np.testing.assert_allclose(t[part][:3, 3], point, atol=1e-6, err_msg=f"{part} at {(x, y, z)}")

    def test_the_wrist_piece_stays_level(self):
        for x, y, z in POSES:
            q1, q2, q3 = magician_model.joint_values(kinematics.arm_geometry(x, y, z))
            rotation = magician_model.link_transforms(q1, q2, q3, 0.0, 0.0)["magicianLink4"][:3, :3]
            np.testing.assert_allclose(rotation[:, 2], (0.0, 0.0, 1.0), atol=1e-9)   # its up stays up

    def test_the_real_dimensions(self):
        self.assertAlmostEqual(kinematics.SHOULDER_H, 131.305)
        self.assertEqual((kinematics.L1, kinematics.L2, kinematics.TOOL_FORWARD), (135.0, 147.0, 60.0))
        base = magician_model.load_parts()["magicianBase"][0]
        footprint = base.max(axis=0) - base.min(axis=0)
        self.assertAlmostEqual(footprint[0], 158.0, delta=1.5)   # the published 158 x 158 mm base
        self.assertAlmostEqual(footprint[1], 158.0, delta=1.5)

    def test_the_gripper_tips_are_at_the_tool_point(self):
        """The pose's z is the fingertips' height (as the grip planning and the collision checks take it): they were
        drawn 15 mm lower, so in the demo they went into the cubes and the table."""
        g = kinematics.arm_geometry(220, 60, 40)
        triangles, _, tool = magician_model.posed_triangles(g, 0.0, 0.0)
        lowest = triangles[tool].reshape(-1, 3)[:, 2].min()
        self.assertAlmostEqual(g.tcp[2] - lowest, 0.0, delta=0.5)

    def test_jaws(self):
        self.assertEqual(magician_model.jaw_opening(False), magician_model.JAW_TRAVEL_MM)
        self.assertEqual(magician_model.jaw_opening(True), 0.0)
        self.assertAlmostEqual(magician_model.jaw_opening(True, 25.0), 12.5 - magician_model.JAW_GAP_CLOSED_MM)


class DrawingTests(unittest.TestCase):
    def paint(self, width=900, height=700):
        image = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(QColor("#0c1824"))
        painter = QPainter(image)
        camera = scene_painter.look_at((520.0, -560.0, 420.0), (140.0, 0.0, 75.0), 1.25 * min(width, height))
        objects = [{"id": "c", "label": "red cube", "pos": (220.0, -60.0, 12.5), "size": (25, 25, 25),
                    "color": (0.8, 0.1, 0.1), "shape": "cube"}]
        started = time.perf_counter()
        scene_painter.paint_scene(painter, width, height, camera, objects, kinematics.arm_geometry(220, 100, 80),
                                  False, QFont())
        elapsed = time.perf_counter() - started
        painter.end()
        return image, elapsed

    def test_the_arm_is_drawn_and_quickly(self):
        self.paint()
        image, elapsed = self.paint()
        pixels = np.frombuffer(image.constBits().asstring(image.sizeInBytes()), np.uint8).reshape(700, 900, 4)
        whites = ((pixels[:, :, :3] > 150).all(axis=2)).sum()
        self.assertGreater(whites, 2000, "the arm's white housings should be on screen")
        self.assertLess(elapsed, 0.25, f"one frame took {elapsed * 1000:.0f} ms")

    def test_without_the_mesh_files_the_drawn_stand_in_is_used(self):
        original = magician_model.MESH_DIR
        magician_model.MESH_DIR = Path("no-such-folder")
        magician_model.load_parts.cache_clear()
        try:
            self.assertIsNone(magician_model.posed_triangles(kinematics.arm_geometry(220, 0, 50), 0.0, 0.0))
            self.paint()   # must not raise
        finally:
            magician_model.MESH_DIR = original
            magician_model.load_parts.cache_clear()



class StackInATrayTests(unittest.TestCase):
    def test_the_bottom_cube_of_a_stack_in_a_tray_is_drawn(self):
        """Seen from the 3D view's usual angle, the tray's floor (sorted by its middle) was painted over the
        lower cube of a two-cube stack in the tray: only the red one on top showed, "the blue cube is not
        visible"."""
        import numpy as np
        width, height = 900, 820
        objects = [{"id": "tray", "label": "tray", "pos": (280.0, 0.0, 2.0), "size": (80, 80, 14),
                    "color": (0.62, 0.6, 0.55), "shape": "tray"},
                   {"id": "blue", "label": "blue cube", "pos": (256.0, -8.0, 14.0), "size": (20, 20, 20),
                    "color": (0.1, 0.2, 0.8), "shape": "cube"},
                   {"id": "red", "label": "red cube", "pos": (256.0, -8.0, 34.0), "size": (20, 20, 20),
                    "color": (0.8, 0.1, 0.1), "shape": "cube"}]
        image = QImage(width, height, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(QColor("#0c1824"))
        painter = QPainter(image)
        camera = scene_painter.look_at((631.0, -384.0, 435.0), (140.0, 0.0, 75.0), 1.25 * height)
        scene = scene_painter.paint_scene(painter, width, height, camera, objects,
                                          kinematics.arm_geometry(160, -150, 90), False, QFont(), show_labels=False)
        painter.end()
        bits = image.constBits()
        bits.setsize(width * height * 4)
        pixels = np.frombuffer(bits, np.uint8).reshape(height, width, 4).astype(int)
        # just round the stack (the axes and the reach map have red and blue in them too)
        corners = [scene.project((256.0 + dx, -8.0 + dy, z)) for dx in (-10, 10) for dy in (-10, 10) for z in (4, 44)]
        xs, ys = [c[0] for c in corners], [c[1] for c in corners]
        pixels = pixels[int(min(ys)) - 2:int(max(ys)) + 3, int(min(xs)) - 2:int(max(xs)) + 3]
        b, g, r = pixels[..., 0], pixels[..., 1], pixels[..., 2]
        blue = int(((b > 120) & (b > r + 50) & (b > g + 30)).sum())
        red = int(((r > 120) & (r > b + 50) & (r > g + 30)).sum())
        self.assertGreater(blue, 0.4 * red, f"blue {blue} px, red {red} px")


if __name__ == "__main__":
    unittest.main()

"""More ways to ask: in a row, moved by a distance, a pile taken apart, a tray emptied, between, swap, put back, slowly,
and where each object is in words -- in the demo world, on both robots.

    python -m unittest discover -s tests -p test_arrange.py -v
"""
from __future__ import annotations

import math
import unittest

from harness import ROOT  # noqa: F401  (sets up sys.path and the working folder)

from app import robots
from app.hardware.gripper import GripperSpec
from app.hardware.interfaces import Pose
from app.llm.agent import Agent
from app.llm.arrange import to_mm
from app.llm.tools import TOOL_SCHEMAS

CUBES = ("red cube", "blue cube", "green cube")


class UnitTests(unittest.TestCase):
    def test_distances_with_units(self):
        self.assertEqual(to_mm(30), 30.0)
        self.assertEqual(to_mm("5 cm"), 50.0)
        self.assertAlmostEqual(to_mm("2 inches"), 50.8)
        self.assertEqual(to_mm("12mm"), 12.0)
        self.assertEqual(to_mm(None, 20.0), 20.0)
        with self.assertRaises(ValueError):
            to_mm("a bit")

    def test_every_new_tool_is_offered_to_the_model(self):
        names = {t["function"]["name"] for t in TOOL_SCHEMAS}
        for name in ("line_up", "move_object", "take_apart", "empty_place", "place_between", "swap", "put_back",
                     "set_speed", "drop"):
            self.assertIn(name, names)

    def test_a_drop_request_is_read_as_one(self):
        from app.llm.trace import understand
        self.assertEqual(understand("Pick up the blue cube, lift it 40 mm above the table, move it 40 mm nearer the "
                                    "robot, and let it drop.")["task"], "drop an object")
        self.assertEqual(understand("Pick up the red cube")["task"], "pick up")
        self.assertNotEqual(understand("Drop the red cube in the tray")["task"], "drop an object")

    def test_a_reply_that_says_swapped_with_no_swap_done_is_caught(self):
        # study 3, S-10: the swap was refused, and the reply said "The red and blue cubes were swapped"
        from app.llm.agent import AgentStep, claims_swap_not_done
        refused = [AgentStep("swap", {}, "ERROR: Not swapped, nothing moved: ...")]
        self.assertTrue(claims_swap_not_done("The red and blue cubes were swapped.", refused))
        self.assertFalse(claims_swap_not_done("They could not be swapped: the camera's reading kept changing.", refused))
        done = [AgentStep("swap", {}, "Swapped the red cube and the blue cube: ...")]
        self.assertFalse(claims_swap_not_done("The red and blue cubes were swapped.", done))


class DemoTests(unittest.TestCase):
    def world_for(self, key: str = "dobot_magician", scene: str = "two_blocks_and_tray"):
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.llm.tools import ToolExecutor
        from app.twin.world import TwinWorld
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        profile = robots.set_active(key)
        self.addCleanup(robots.set_active, "dobot_magician")
        world = TwinWorld()
        client = world.start()
        self.addCleanup(world.stop)
        world.load_scenario(scene)
        spec = GripperSpec.from_config({"gripper_type": "gripper"}, profile.gripper_defaults())
        robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                         max_reach_mm=profile.max_reach_mm, world=world, gripper=spec)
        robot.connect()
        camera = SimCamera(client)
        camera.outline_bodies = robot.body_ids
        camera.connect()
        look = Pose(*profile.demo_look_pose)
        robot.move_to(look)
        transform = camera.camera_to_robot_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: robot.arm_state()[0], world.places,
                                       world.place_areas)
        executor = ToolExecutor(robot, SceneBuilder(camera, detector, transform), look_pose=look,
                                table_z_provider=lambda: 0.0, places_provider=world.places,
                                place_areas_provider=world.place_areas, gripper=spec)
        return world, robot, executor

    @staticmethod
    def look(executor) -> dict:
        return {o["label"]: o for o in eval(executor.execute("list_objects", {}))["objects"]}   # noqa: S307

    @staticmethod
    def at(world, label):
        oid = next(k for k, m in world.object_meta.items() if m["label"] == label)
        return world.get_object_position_mm(oid)

    def test_a_row_left_to_right_3_cm_apart_on_both_robots(self):
        for key in ("dobot_magician", "xarm6"):
            with self.subTest(robot=key):
                world, _, executor = self.world_for(key)
                seen = self.look(executor)
                result = executor.execute("line_up", {"object_ids": [seen[c]["id"] for c in CUBES], "gap_mm": "3 cm"})
                self.assertIn("Lined up 3", result)
                spots = [self.at(world, c) for c in CUBES]
                self.assertTrue(all(abs(p[0] - spots[0][0]) < 3 for p in spots), spots)     # one row, across
                self.assertGreater(spots[0][1], spots[1][1])                                # left (+y) to right
                self.assertGreater(spots[1][1], spots[2][1])
                self.assertAlmostEqual(spots[0][1] - spots[1][1], 50.0, delta=4)            # 20 mm cube + 30 mm

    def test_moved_5_cm_to_the_left(self):
        world, _, executor = self.world_for()
        seen = self.look(executor)
        x, y, _ = self.at(world, "red cube")
        executor.execute("move_object", {"object_id": seen["red cube"]["id"], "direction": "left",
                                         "distance_mm": "5 cm"})
        nx, ny, _ = self.at(world, "red cube")
        self.assertAlmostEqual(nx, x, delta=3)
        self.assertAlmostEqual(ny - y, 50.0, delta=3)

    def test_a_move_onto_another_object_is_refused(self):
        world, _, executor = self.world_for()
        seen = self.look(executor)
        with self.assertRaisesRegex(ValueError, "taken by the blue cube"):   # the blue cube is 120 mm to its left
            executor.execute("move_object", {"object_id": seen["red cube"]["id"], "direction": "left",
                                             "distance_mm": 120})
        self.assertLess(self.at(world, "red cube")[1], -50)                    # not moved

    def test_a_tower_taken_apart_and_a_tray_emptied(self):
        world, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("build_tower", {"object_ids": [seen[c]["id"] for c in CUBES]})
        seen = self.look(executor)
        executor.execute("take_apart", {"object_id": seen["red cube"]["id"]})
        self.assertTrue(all(self.at(world, c)[2] < 15 for c in CUBES))                     # all on the table
        seen = self.look(executor)
        executor.execute("put_all_in", {"object_ids": [seen[c]["id"] for c in CUBES], "place_name": "tray"})
        seen = self.look(executor)
        self.assertTrue(all("in the tray" in seen[c].get("where", "") for c in CUBES), seen)
        self.assertIn("Took 3 of 3 out of the tray", executor.execute("empty_place", {"place_name": "tray"}))
        tray_x, tray_y = world.places()["tray"][:2]
        for c in CUBES:
            x, y, _ = self.at(world, c)
            self.assertTrue(abs(x - tray_x) > 40 or abs(y - tray_y) > 40, (c, x, y))

    def test_the_tray_emptied_in_a_new_request_without_a_look_first(self):
        # as it happened: "empty the tray" sent straight to empty_place. The white cube was picked, couldn't be put
        # down ("call list_objects first"), and every next cube was refused ("already holding the white cube")
        for key in ("dobot_magician", "xarm6"):
            with self.subTest(robot=key):
                world, _, executor = self.world_for(key)
                executor.begin_run()
                seen = self.look(executor)
                executor.execute("put_all_in", {"object_ids": [seen[c]["id"] for c in CUBES], "place_name": "tray"})
                executor.end_run()
                executor.begin_run()                       # the next request: no list_objects
                self.assertIn("Took 3 of 3 out of the tray", executor.execute("empty_place", {"place_name": "tray"}))
                self.assertIsNone(executor.holding)

    def test_a_put_down_that_fails_leaves_nothing_in_the_gripper(self):
        world, _, executor = self.world_for()
        seen = self.look(executor)
        start = self.at(world, "red cube")

        def fails():
            raise ValueError("No room there")
        with self.assertRaisesRegex(ValueError, "No room there. The red cube was put back where it was"):
            executor._carry(executor._find_object(seen["red cube"]["id"]), fails)
        self.assertIsNone(executor.holding)
        self.assertLess(math.dist(self.at(world, "red cube"), start), 4)

    def test_tools_with_ids_look_first_in_a_new_request(self):
        # "dismantle the tower": take_apart straight away was refused ("Call list_objects first"); the model looked,
        # and then replied "the tower is dismantled" without doing it. Now the tool looks itself, and does it.
        world, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("build_tower", {"object_ids": [seen[c]["id"] for c in CUBES]})
        executor.begin_run()                                   # the next request: no list_objects
        self.assertIn("Took the pile apart", executor.execute("take_apart", {"object_id": seen["red cube"]["id"]}))
        self.assertTrue(all(self.at(world, c)[2] < 15 for c in CUBES), "all on the table")
        executor.begin_run()
        x, y, _ = self.at(world, "red cube")
        executor.execute("move_object", {"object_id": seen["red cube"]["id"], "direction": "left", "distance_mm": 30})
        self.assertAlmostEqual(self.at(world, "red cube")[1] - y, 30.0, delta=3)

    def test_a_done_that_isnt_is_sent_back_once_with_what_the_app_found(self):
        world, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("build_tower", {"object_ids": [seen[c]["id"] for c in CUBES]})
        tower = self.look(executor)

        def call(name, **args):
            return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args}}]}
        replies = [call("list_objects"), {"role": "assistant", "content": "The tower is dismantled."},
                   call("take_apart", object_id=tower["red cube"]["id"]), {"role": "assistant", "content": "Done."}]

        class Client:
            sent = []

            def chat(self, model, messages, tools=None, temperature=0.2):
                self.sent.append(messages[-1].get("content", ""))
                return replies.pop(0)
        client = Client()
        run = Agent(client, executor, "m").run("dismantle the tower")
        self.assertIn("Not done yet, as the app checked it: still in a pile", client.sent[2])
        self.assertEqual(run.trace["end"]["goal"]["status"], "met")
        self.assertTrue(all(self.at(world, c)[2] < 15 for c in CUBES))

    def test_a_reply_that_says_the_tray_was_emptied_when_it_was_not_gets_a_note(self):
        from app.ui.prompt_panel import goal_mismatch
        world, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("put_all_in", {"object_ids": [seen[c]["id"] for c in CUBES], "place_name": "tray"})

        class Client:
            def chat(self, model, messages, tools=None, temperature=0.2):
                return {"role": "assistant", "content": "I have completed the task of emptying the tray."}
        run = Agent(Client(), executor, "m").run("empty the tray")
        goal = run.trace["end"]["goal"]
        self.assertEqual(goal["status"], "not met", goal)
        self.assertIn("still there", goal_mismatch(run.final_message, run.trace))

    def pile(self, world, labels):
        points = {label: self.at(world, label) for label in labels}
        x, y, _ = points[labels[0]]
        self.assertTrue(all(math.hypot(p[0] - x, p[1] - y) < 12 for p in points.values()), points)
        return sorted(labels, key=lambda label: points[label][2])

    def test_a_tower_outside_the_tray_and_moved_out_of_it(self):
        # "build a tower with the cube outside of the tray": no way to say free table, so the model built it IN
        # the tray; "the tower should be outside of the tray": it took it apart by hand, one cube at a time
        for key in ("dobot_magician", "xarm6"):
            with self.subTest(robot=key):
                world, _, executor = self.world_for(key)
                seen = self.look(executor)
                ids = [seen[c]["id"] for c in ("green cube", "red cube", "blue cube")]
                executor.execute("build_tower", {"object_ids": ids, "place_name": "tray"})
                self.assertEqual(self.pile(world, ("green cube", "red cube", "blue cube")),
                                 ["green cube", "red cube", "blue cube"])
                self.look(executor)
                result = executor.execute("build_tower", {"object_ids": ids, "where": "outside"})
                self.assertIn("Took 2 off a pile first", result)
                self.assertEqual(self.pile(world, ("green cube", "red cube", "blue cube")),
                                 ["green cube", "red cube", "blue cube"])
                tray_x, tray_y = world.places()["tray"][:2]
                x, y, _ = self.at(world, "green cube")
                self.assertTrue(abs(x - tray_x) > 50 or abs(y - tray_y) > 50, (x, y))
                self.assertIsNone(executor.holding)

    def test_place_free_words_in_place_name_and_a_tower_already_built(self):
        world, _, executor = self.world_for()
        seen = self.look(executor)
        ids = [seen[c]["id"] for c in ("red cube", "blue cube", "green cube")]
        self.assertIn("on free table", executor.execute("build_tower", {"object_ids": ids, "place_name": "near_base"}))
        before = {c: self.at(world, c) for c in CUBES}
        self.look(executor)
        self.assertIn("already built", executor.execute("build_tower", {"object_ids": ids}))
        self.assertTrue(all(math.dist(self.at(world, c), before[c]) < 2 for c in CUBES))

    def test_nothing_is_put_where_the_camera_cant_see_it(self):
        # a row lined up out to y -230 put the red cube out of the camera's picture, and it was "not there"
        for key in ("dobot_magician", "xarm6"):
            with self.subTest(robot=key):
                world, _, executor = self.world_for(key, "tower_building")
                seen = self.look(executor)
                five = ("purple cube", "blue cube", "green cube", "yellow cube", "red cube")
                executor.execute("line_up", {"object_ids": [seen[c]["id"] for c in five], "gap_mm": 20})
                executor.begin_run()
                self.assertEqual(sorted(self.look(executor)), sorted(five), "all five still seen")
                self.assertFalse(executor._in_view(370.0, -700.0, 20.0))
                seen = self.look(executor)
                executor.execute("pick", {"object_id": seen["red cube"]["id"]})
                with self.assertRaisesRegex(ValueError, "the camera can't see there"):
                    executor.execute("place", {"x": 150.0, "y": -480.0, "z": 25.0})
                for _ in range(5):                          # every free spot chosen is one the camera sees
                    x, y, _ = executor._choose_free_spot("right", None)
                    self.assertTrue(executor._in_view(x, y, 20.0), (x, y))
                    executor._just_placed.append((x, y))

    def test_one_no_longer_seen_is_said_so(self):
        from app.vision.scene import SceneObject
        world, _, executor = self.world_for("xarm6")
        self.look(executor)
        # last put (by the app, before) where the camera can't see it now
        executor._last_scene.append(SceneObject("obj_99", "purple cube", (370.0, -700.0, 20.0), 1.0))
        gone = eval(executor.execute("list_objects", {}))["not_seen_now"]         # noqa: S307
        self.assertEqual(gone, [{"label": "purple cube", "last_at_mm": (370, -700),
                                 "why": "out of the camera's view there"}])
        red = next(k for k, m in world.object_meta.items() if m["label"] == "red cube")   # taken away by hand
        world.set_object_position_mm(red, 150.0, -900.0, 10.0)
        gone = eval(executor.execute("list_objects", {}))["not_seen_now"]         # noqa: S307
        self.assertEqual([(g["label"], g["why"]) for g in gone], [("red cube", "no longer seen where it was")])

    def test_between_and_swap(self):
        world, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("pick", {"object_id": seen["green cube"]["id"]})
        executor.execute("place_between", {"object_id_a": seen["red cube"]["id"], "object_id_b": seen["blue cube"]["id"]})
        red, blue, green = (self.at(world, c) for c in CUBES)
        self.assertLess(math.dist(green[:2], ((red[0] + blue[0]) / 2, (red[1] + blue[1]) / 2)), 4)
        seen = self.look(executor)
        said = executor.execute("swap", {"object_id_a": seen["red cube"]["id"], "object_id_b": seen["blue cube"]["id"]})
        self.assertLess(math.dist(self.at(world, "red cube")[:2], blue[:2]), 4)
        self.assertLess(math.dist(self.at(world, "blue cube")[:2], red[:2]), 4)
        # each with the id it goes by now (this round's E3, S-09: the model turned the wrong cube after a swap)
        now = self.look(executor)
        self.assertIn(f"the red cube ({now['red cube']['id']}) is now at", said)
        self.assertIn(f"the blue cube ({now['blue cube']['id']}) at", said)

    def test_a_swap_finds_its_cube_again_when_a_look_between_gave_it_a_new_id(self):
        # study 2, S-06_Run2, S-08_Run2, S-09_Run2: a pick's second look (an unsteady cube) gave every cube a new id, and
        # the swap stopped half done -- "Unknown object_id" for the cube it had just put down out of the way
        world, _, executor = self.world_for()
        seen = self.look(executor)
        red, blue = self.at(world, "red cube"), self.at(world, "blue cube")
        carry = executor._carry

        def carry_then_look_afresh(obj, put_down):
            carry(obj, put_down)
            executor.scene_builder.reset_tracking()           # (new ids from here on)
            executor._tool_list_objects({})
        executor._carry = carry_then_look_afresh
        result = executor.execute("swap", {"object_id_a": seen["red cube"]["id"], "object_id_b": seen["blue cube"]["id"]})
        self.assertTrue(result.startswith("Swapped"), result)
        self.assertLess(math.dist(self.at(world, "red cube")[:2], blue[:2]), 4)
        self.assertLess(math.dist(self.at(world, "blue cube")[:2], red[:2]), 4)

    def test_a_swap_with_a_cube_on_another_keeps_its_level(self):
        # study 4, S-09: "swap the blue and red cubes" with blue on green -- red was put down on the table where blue
        # stood, the fingers would have hit the green cube, and the swap was refused half done
        world, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("pick", {"object_id": seen["blue cube"]["id"]})
        executor.execute("place_on", {"object_id": seen["green cube"]["id"]})
        seen = self.look(executor)
        green, red = self.at(world, "green cube"), self.at(world, "red cube")
        said = executor.execute("swap", {"object_id_a": seen["blue cube"]["id"], "object_id_b": seen["red cube"]["id"]})
        self.assertTrue(said.startswith("Swapped"), said)
        self.assertIn("on the green cube", said)
        now_red, now_blue = self.at(world, "red cube"), self.at(world, "blue cube")
        self.assertLess(math.dist(now_red[:2], green[:2]), 4)
        self.assertGreater(now_red[2], 25)                                       # on the green cube
        self.assertLess(math.dist(now_blue[:2], red[:2]), 4)
        self.assertLess(now_blue[2], 15)                                         # on the table

    def test_a_cube_not_seen_after_it_was_let_go_holds_the_arm_for_a_person(self):
        # study 4, S-08: gripped across its corners, the blue cube stayed wedged in the open fingers; the swap went on
        # to the green cube, and the turn after it put the blue one down on the green
        world, robot, executor = self.world_for()
        executor._grip_unfelt = lambda: True               # (the Dobot: it can't feel what its fingers hold)
        held_up = []
        robot.hold_for_person = held_up.append
        seen = self.look(executor)
        executor.execute("move_object", {"object_id": seen["red cube"]["id"], "direction": "left", "distance_mm": 30})
        executor.execute("list_objects", {})              # seen where it was let go: on with the next
        self.assertEqual(held_up, [])
        executor.execute("move_object", {"object_id": seen["red cube"]["id"], "direction": "right", "distance_mm": 30})
        red = next(k for k, m in world.object_meta.items() if m["label"] == "red cube")
        world.set_object_position_mm(red, 150.0, -900.0, 10.0)     # (as if still in the fingers: nowhere on the table)
        with self.assertRaisesRegex(ValueError, "may be stuck in the gripper's fingers"):
            executor.execute("pick", {"object_id": seen["blue cube"]["id"]})
        self.assertEqual(len(held_up), 1)
        self.assertIsNone(executor.holding)

    def test_a_cube_turned_45_degrees_is_read_so_by_its_coloured_top(self):
        # study 4, S-08: a blue cube turned 45.6 degrees read 1.0 by its outline (its sides taken in) and gripped
        # across its corners. Only cubes on the table (the lab's setting): its turn by its top face's colour
        world, _, executor = self.world_for()
        executor.scene_builder.detector.cubes_only = True
        red = next(k for k, m in world.object_meta.items() if m["label"] == "red cube")
        x, y, z = self.at(world, "red cube")
        for yaw in (45.0, 30.0, 10.0):
            with self.subTest(yaw=yaw):
                world.set_object_position_mm(red, x, y, z, yaw_deg=yaw)
                self.look(executor)
                cube = next(o for o in executor._last_scene if o.label == "red cube")
                off = (cube.footprint[2] - yaw + 45.0) % 90.0 - 45.0
                self.assertLess(abs(off), 4.0, cube.footprint)

    def test_the_lab_s_cube_turned_45_degrees_is_read_so(self):
        # the real camera's picture (study 4, S-08's start, cropped round the blue cube; the watcher read it 45.6): its
        # outline, the side faces taken in, read 1.0 -- the fingers closed across its corners and it stuck in them
        from pathlib import Path

        import numpy as np

        from app.hardware.interfaces import Frame, Intrinsics
        from app.vision.depth_detector import DepthObjectDetector
        data = np.load(Path(__file__).parent / "lab_frames" / "study4_S-08_blue_cube_45deg.npz")
        fx, fy, cx, cy, w, h = data["intrinsics"]
        frame = Frame(rgb=data["rgb"], depth=data["depth"], intrinsics=Intrinsics(fx, fy, cx, cy, int(w), int(h)))
        transform, table_z = data["t_cam_to_robot"], float(data["table_z"])
        detector = DepthObjectDetector(lambda: transform, lambda: table_z)
        detector.cubes_only = True                         # (the lab's setting: config.yaml, vision: cubes_only)
        blue = next(o for o in detector.locate(frame, transform) if o.label.startswith("blue"))
        off = (blue.footprint[2] - float(data["watcher_yaw"]) + 45.0) % 90.0 - 45.0
        self.assertLess(abs(off), 5.0, blue.footprint)

    def test_put_back_undoes_the_last_prompt_and_rebuilds_a_pile(self):
        world, _, executor = self.world_for()
        executor.begin_run()
        seen = self.look(executor)
        start = {c: self.at(world, c) for c in CUBES}
        executor.execute("build_tower", {"object_ids": [seen["red cube"]["id"], seen["blue cube"]["id"]]})
        executor.end_run()
        executor.begin_run()                     # "put it back"
        self.look(executor)
        executor.execute("put_back", {})
        self.assertLess(math.dist(self.at(world, "blue cube"), start["blue cube"]), 4)
        executor.end_run()
        executor.begin_run()                     # "undo that": the tower again
        self.look(executor)
        self.assertIn("on the red cube", executor.execute("put_back", {}))
        self.assertGreater(self.at(world, "blue cube")[2], 25)

    def test_slowly_lasts_one_prompt(self):
        _, robot, executor = self.world_for()
        executor.begin_run()
        executor.execute("set_speed", {"speed": "slow"})
        self.assertLess(robot.max_speed, 3000)
        executor.end_run()
        self.assertEqual(robot.max_speed, 3000)

    def test_drop_lifts_moves_and_lets_go(self):
        # study 3, S-20: no tool let a cube drop, and the run ended with it in the gripper
        world, _, executor = self.world_for()
        seen = self.look(executor)
        x, y, _ = self.at(world, "red cube")
        said = executor.execute("drop", {"object_id": seen["red cube"]["id"], "height_mm": 40, "direction": "back",
                                         "distance_mm": 40})
        self.assertIn("Dropped the red cube from 40 mm", said)
        self.assertIsNone(executor.holding)
        nx, ny, nz = self.at(world, "red cube")
        self.assertAlmostEqual(nx, x - 40, delta=8)
        self.assertAlmostEqual(ny, y, delta=8)
        self.assertLess(nz, 15)                                               # on the table

    def test_drop_beside_another_lets_go_there(self):
        # S-19: "lift it 50 mm above the table to the right of the green cube with a 50 mm gap, and let it drop" --
        # the model moved it with move_object, then dropped it where that left it
        world, _, executor = self.world_for()
        seen = self.look(executor)
        said = executor.execute("drop", {"object_id": seen["red cube"]["id"], "height_mm": 30,
                                         "beside_id": seen["blue cube"]["id"], "side": "left", "gap_mm": 30})
        self.assertIn("so it dropped", said)
        self.assertIsNone(executor.holding)
        red, blue = self.at(world, "red cube"), self.at(world, "blue cube")
        self.assertLess(red[2], 15)                                           # on the table
        self.assertGreater(math.dist(red[:2], blue[:2]), 35)

    def test_a_drop_near_the_base_lets_go_as_high_as_the_arm_reaches(self):
        # this round's twin, S-20: 40 mm up at 152 mm from the base needed the rear arm 10 degrees past upright, and
        # the drop was refused where a put-down reaches
        world, _, executor = self.world_for()
        seen = self.look(executor)
        reach = executor._approach_z
        executor._approach_z = lambda x, y, z, *rest: None if z > 25.0 else reach(x, y, z, *rest)
        said = executor.execute("drop", {"object_id": seen["red cube"]["id"], "height_mm": 40})
        self.assertIn("as high as the arm reaches there", said)
        self.assertIn("40 mm was asked", said)
        self.assertIsNone(executor.holding)

    def test_fingers_turned_20_degrees_are_allowed_for_and_the_twin_touches_where_they_really_are(self):
        # study 3: the lab's fingers angle check (+20.1) was refused, and the Dobot picked cubes diagonally. The
        # twin's touch check had the fingers at the told r: allowed for, every grip "touched" the cube
        from app.hardware.wrist import WristModel
        lab = {"offset_deg": 20.13, "gain": 0.988, "backlash_deg": 4.78, "scatter_deg": 4.94, "samples": 10,
               "jaw_axis_deg": 90.0}
        for allowed_for in (False, True):
            _, robot, executor = self.world_for()
            robot.fingers_turned_deg, robot.wrist_gain, robot.wrist_backlash_deg = 20.13, 0.988, 4.78
            if allowed_for:
                executor.wrist.model = WristModel.from_dict(dict(lab))
            seen = self.look(executor)
            self.assertIn("Picked up blue cube", executor.execute("pick", {"object_id": seen["blue cube"]["id"]}))
            planned = executor.last_record["grip"]["r"]
            # (what the fingers touch is judged where they really are, not at the told r)
            self.assertAlmostEqual(robot._real_r_at(robot.get_pose()), robot.real_r(), delta=0.5)
            if not allowed_for:                          # (this scene's 20 mm cubes still fit, on their corners)
                self.assertAlmostEqual(robot.real_r() - planned, 20.0, delta=3.0)
                continue
            self.assertAlmostEqual(robot.real_r(), planned, delta=1.0)
            self.assertLess(robot.get_pose().r, planned - 15.0)   # (told about 18 less than planned)

    def test_the_held_cube_asked_for_by_its_id_is_said_to_be_held(self):
        # study 3, S-20: "Unknown object_id ... Call list_objects first", and list_objects never lists what is held
        _, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("pick", {"object_id": seen["red cube"]["id"]})
        self.assertNotIn("red cube", self.look(executor))                  # (only the table is listed)
        with self.assertRaisesRegex(ValueError, "you are holding"):
            executor.execute("move_above", {"object_id": seen["red cube"]["id"]})
        self.assertIn("Dropped the red cube", executor.execute("drop", {"object_id": seen["red cube"]["id"],
                                                                         "height_mm": 30}))

    def test_a_turn_after_a_swap_counts_from_how_the_cube_lay_when_asked(self):
        # study 3, S-06, S-08: each carry left the cube a few degrees off, and the turn was added to that
        world, _, executor = self.world_for()
        executor.begin_run()
        seen = self.look(executor)
        red = next(k for k, m in world.object_meta.items() if m["label"] == "red cube")
        executor.execute("swap", {"object_id_a": seen["red cube"]["id"], "object_id_b": seen["blue cube"]["id"]})
        now = self.look(executor)["red cube"]["id"]
        self.assertIn(now, executor._placed_in_prompt)
        # as if the swap had turned it 10 degrees (the real fingers did): "turn it 30" then means 20 more than now
        executor._prompt_angles[now] = executor._prompt_angles[seen["red cube"]["id"]] - 10.0
        before = world.get_object_yaw_deg(red)
        said = executor.execute("turn_object", {"object_ids": [now], "turn_deg": 30})
        self.assertIn("from how it lay when asked", said)
        turned = (world.get_object_yaw_deg(red) - before - 20.0 + 45.0) % 90.0 - 45.0
        self.assertLess(abs(turned), 4.0, said)

    def test_a_pair_turned_over_stays_where_the_pile_was(self):
        # study 3, S-15: "put the green cube on the blue cube" (blue on green): the blue cube, moved aside to get at the
        # green one, stayed there, and the tower ended 51 mm from where it had been
        world, _, executor = self.world_for()
        seen = self.look(executor)
        executor.execute("build_tower", {"object_ids": [seen["green cube"]["id"], seen["blue cube"]["id"]]})
        executor.end_run()
        executor.begin_run()
        seen = self.look(executor)
        spot = self.at(world, "blue cube")
        executor.execute("pick", {"object_id": seen["green cube"]["id"]})        # (the blue one moved aside first)
        said = executor.execute("place_on", {"object_id": seen["blue cube"]["id"]})
        self.assertIn("went back where it stood", said)
        blue, green = self.at(world, "blue cube"), self.at(world, "green cube")
        self.assertLess(math.dist(blue[:2], spot[:2]), 5)
        self.assertLess(math.dist(green[:2], blue[:2]), 5)
        self.assertGreater(green[2], blue[2] + 10)

    def test_a_cube_it_just_put_down_is_picked_at_that_turn_though_the_readings_wander(self):
        # study 3, S-07, S-10: the swap's own cube, just set aside, refused at 16.5 and 17.2 degrees of spread
        _, _, executor = self.world_for()
        seen = self.look(executor)
        red, blue = seen["red cube"]["id"], seen["blue cube"]["id"]
        executor.execute("move_object", {"object_id": red, "direction": "left", "distance_mm": 30})
        placed = executor._placed_angles[red][2]

        def wobbly(x, y, looks, *rest):                  # every other reading 12 degrees either side: past 15
            return [((20.0, 20.0, placed + (12.0 if i % 2 else -12.0)), (x, y, 20.0)) for i in range(looks)]
        executor.scene_builder.looks_near = wobbly
        executor.scene_builder.footprints_near = lambda x, y, looks, *rest: [p for p, _ in wobbly(x, y, looks)]
        executor._angle_from_afar = lambda obj, footprint: None
        self.assertIn("Picked up red cube", executor.execute("pick", {"object_id": red}))
        self.assertTrue(executor.last_record.get("angle", {}).get("as_put_down"), executor.last_record)
        executor.execute("place_free", {"where": "far"})
        executor._placed_angles.clear()                  # (one it didn't put down: refused as before)
        with self.assertRaisesRegex(ValueError, "kept changing"):
            executor.execute("pick", {"object_id": blue})

    def test_small_and_large_among_the_same_kind(self):
        _, _, executor = self.world_for(scene="size_sorting")
        seen = self.look(executor)
        for label in ("red cube", "green cube"):            # 15 mm
            self.assertIn("small", seen[label]["where"])
        for label in ("yellow cube", "blue cube"):          # 20 mm
            self.assertIn("large", seen[label]["where"])

    def test_where_words(self):
        _, _, executor = self.world_for()
        seen = self.look(executor)
        self.assertIn("leftmost", seen["green cube"]["where"])         # (170, 130): furthest to the robot's left
        self.assertIn("rightmost", seen["red cube"]["where"])          # (220, -60)


class AgentTests(unittest.TestCase):
    def test_the_previous_request_is_given_and_the_speed_restored(self):
        class Client:
            def __init__(self):
                self.prompts = []

            def chat(self, model, messages, tools=None, temperature=0.2):
                self.prompts.append(messages[1]["content"])
                return {"role": "assistant", "content": "Done."}

        class Executor:
            ended = 0

            def end_run(self):
                self.ended += 1

        client, executor = Client(), Executor()
        agent = Agent(client, executor, "m")
        agent.run("line up the cubes")
        agent.run("do it again")
        self.assertNotIn("The previous request was", client.prompts[0])
        self.assertIn('The previous request was: "line up the cubes"', client.prompts[1])
        self.assertEqual(executor.ended, 2)


if __name__ == "__main__":
    unittest.main()

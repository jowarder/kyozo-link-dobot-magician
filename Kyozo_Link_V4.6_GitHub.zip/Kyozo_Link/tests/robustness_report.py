"""Prints how the calibration procedure holds up against camera imperfections.

    python tests/robustness_report.py [trials]

For each camera quality (and click sloppiness) it runs the whole procedure -- click 8 points,
solve, touch the table -- and reports the typical and worst error in locating the cubes.
"""
from __future__ import annotations

import sys

import numpy as np

from harness import Sim, calibrate_by_clicking, cube_errors, touch_table

CASES = [  # (camera preset, click noise in pixels, deliberate mis-clicks)
    ("Perfect", 0.0, 0), ("Perfect", 1.5, 0),
    ("Realistic", 1.5, 0), ("Realistic", 3.0, 0), ("Realistic", 1.5, 1),
    ("Poor", 1.5, 0), ("Poor", 3.0, 0), ("Poor", 1.5, 1),
]


def main() -> None:
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    print(f"{'camera':<10} {'click px':>8} {'bad':>4} | {'ok':>3} {'app error':>10} | {'plane err (mm)':>15} {'height err (mm)':>16}")
    for preset, sigma, bad in CASES:
        plane_errors, height_errors, reported, ok = [], [], [], 0
        for trial in range(trials):
            sim = Sim()
            try:
                sim.camera.set_faults(preset)
                rng = np.random.default_rng(1000 + trial)
                run = calibrate_by_clicking(sim, rng, click_sigma_px=sigma, mis_clicks=bad)
                transform = run.result.transform
                if bad and run.result.suspects:   # what a person would do: drop the flagged point and re-solve
                    keep = [i for i in range(run.calibrator.num_samples()) if i not in run.result.suspects]
                    for i in sorted(set(range(run.calibrator.num_samples())) - set(keep), reverse=True):
                        run.calibrator.remove_sample(i)
                    run.result = run.calibrator.solve_detailed()
                    transform = run.result.transform
                transform, _ = touch_table(sim, transform)
                errors = cube_errors(sim, transform)
                if len(errors) < 2:
                    continue
                ok += 1
                reported.append(run.result.honest_error_mm)
                plane_errors += [e[0] for e in errors.values()]
                height_errors += [abs(e[1]) for e in errors.values()]
            finally:
                sim.close()
        if ok:
            print(f"{preset:<10} {sigma:>8.1f} {bad:>4} | {ok:>3} {np.median(reported):>8.1f}mm | "
                  f"{np.median(plane_errors):>6.1f} / {max(plane_errors):>5.1f}   {np.median(height_errors):>7.1f} / {max(height_errors):>5.1f}")
        else:
            print(f"{preset:<10} {sigma:>8.1f} {bad:>4} | {ok:>3}  (cubes not found)")
    print("plane / height errors are median / worst over all cubes and trials")


if __name__ == "__main__":
    main()

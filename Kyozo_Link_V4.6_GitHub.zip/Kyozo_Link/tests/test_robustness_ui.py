"""Rapid clicking and errors in button handlers must not take the app down.

    python -m unittest discover -s tests -p test_robustness_ui.py -v
"""
from __future__ import annotations

import logging
import os
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from harness import Sim  # noqa: E402  (sets up sys.path and the working folder)
from PyQt6.QtWidgets import QApplication, QMessageBox, QPushButton  # noqa: E402

from app import crash_reporting  # noqa: E402
from app.ui import drift_monitor as drift_module  # noqa: E402
from app.vision.drift import capture_reference  # noqa: E402

app = QApplication.instance() or QApplication([])


def pump_until(condition, timeout_s: float = 60.0) -> None:
    deadline = time.time() + timeout_s
    while not condition():
        if time.time() > deadline:
            raise TimeoutError("did not finish in time")
        app.processEvents()
        time.sleep(0.01)


class DriftCheckCoalescingTests(unittest.TestCase):
    def test_rapid_requests_do_not_pile_up_threads(self):
        sim = Sim()
        self.addCleanup(sim.close)
        transform = sim.exact_transform()
        monitor = drift_module.DriftMonitor(sim.camera, lambda: transform, None)
        monitor.reference = capture_reference(sim.camera, transform)
        reports, runs = [], []
        real_check = drift_module.check_view
        drift_module.check_view = lambda *a, **k: (runs.append(1), real_check(*a, **k))[1]
        self.addCleanup(setattr, drift_module, "check_view", real_check)
        monitor.report_ready.connect(reports.append)
        for _ in range(6):                 # like clicking a button six times quickly
            monitor.check()
        pump_until(lambda: not monitor.checking and monitor._workers == [])
        self.assertLessEqual(len(runs), 2, "at most the running check plus one more")
        self.assertEqual(len(reports), 1, "one answer, the newest")
        self.assertEqual(reports[0].status, "ok")


class ErrorReportingTests(unittest.TestCase):
    def test_an_error_in_a_button_handler_is_reported_and_the_app_carries_on(self):
        with tempfile.TemporaryDirectory() as folder:
            shown = []
            real_critical = QMessageBox.critical
            QMessageBox.critical = staticmethod(lambda *a, **k: shown.append(a[2]))
            original_hook, handlers = crash_reporting.sys.excepthook, list(logging.getLogger().handlers)
            try:
                crash_reporting.install(Path(folder))

                def broken():
                    raise ValueError("the handler broke")
                button = QPushButton("boom")
                button.clicked.connect(broken)
                button.click()             # without the hook this ends the whole program under PyQt6
                button.click()             # ...and the app is still here for a second click
                app.processEvents()
                self.assertTrue(shown and "the handler broke" in shown[0])
                for handler in logging.getLogger().handlers:
                    handler.flush()
                self.assertIn("the handler broke", (Path(folder) / "app.log").read_text(encoding="utf-8"))
                self.assertTrue((Path(folder) / "crash.log").exists())
            finally:
                QMessageBox.critical = real_critical
                crash_reporting.sys.excepthook = original_hook
                for handler in list(logging.getLogger().handlers):
                    if handler not in handlers:
                        logging.getLogger().removeHandler(handler)
                        handler.close()
                if crash_reporting._crash_file is not None:
                    import faulthandler
                    faulthandler.disable()
                    crash_reporting._crash_file.close()
                    crash_reporting._crash_file = None


if __name__ == "__main__":
    unittest.main()

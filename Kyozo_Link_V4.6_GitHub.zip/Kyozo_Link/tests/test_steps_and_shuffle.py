"""Step-by-step mode (approve each robot move of a prompt) and Shuffle (a new random layout of the demo scene).

    python -m unittest discover -s tests -p test_steps_and_shuffle.py -v

Demo mode, off-screen, with a scripted stand-in for the language model; nothing in the project changes.
"""
from __future__ import annotations

import math
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: E402
from PyQt6.QtCore import QTimer  # noqa: E402
from PyQt6.QtWidgets import QApplication, QMessageBox  # noqa: E402

from app.config import load_config  # noqa: E402
from app.llm.agent import Agent  # noqa: E402
from app.twin import shuffle as shuffle_module  # noqa: E402
from app.twin.kinematics import within_limits  # noqa: E402
from app.twin.world import list_scenarios  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402
from app.ui.twin_view import TwinView  # noqa: E402
from scripted import StackingClient  # noqa: E402

app = QApplication.instance() or QApplication([])


def pump_until(condition, timeout_s: float = 120.0) -> None:
    deadline = time.time() + timeout_s
    while not condition():
        if time.time() > deadline:
            raise TimeoutError("did not finish in time")
        app.processEvents()
        time.sleep(0.01)


class FakeExecutor:
    def __init__(self):
        self.done = []

    def execute(self, name, arguments):
        self.done.append(name)
        if name == "list_objects":
            return str({"holding": None, "objects": [{"id": "obj_1", "label": "red cube", "xyz_mm": (220, -60, 25)},
                                                     {"id": "obj_2", "label": "blue cube", "xyz_mm": (220, 60, 25)}],
                        "saved_places": []})
        return f"{name} done"


class AgentApprovalTests(unittest.TestCase):
    def run_with(self, answers):
        executor, asked = FakeExecutor(), []

        def approve(name, args):
            asked.append(name)
            return answers.pop(0)
        run = Agent(StackingClient(), executor, "model").run("put red on blue", approve=approve)
        return run, executor.done, asked

    def test_every_move_is_asked_about_but_looking_is_not(self):
        run, done, asked = self.run_with(["go", "go"])
        self.assertEqual(asked, ["pick", "place_on"])
        self.assertEqual(done, ["list_objects", "pick", "place_on"])
        # "Done." counts as done() (V4.3): the app checks and says what was done, from the steps' results
        self.assertEqual(run.final_message, "pick done place_on done")

    def test_stop_ends_the_task_without_doing_that_step(self):
        run, done, asked = self.run_with(["go", "stop"])
        self.assertEqual(done, ["list_objects", "pick"], "place_on never ran")
        self.assertIn("Stopped by you", run.final_message)
        self.assertIn("stopped by you", run.steps[-1].result)

    def test_go_all_stops_asking(self):
        run, done, asked = self.run_with(["all"])
        self.assertEqual(asked, ["pick"])
        self.assertEqual(done, ["list_objects", "pick", "place_on"])

    def test_without_the_mode_nothing_is_asked(self):
        executor = FakeExecutor()
        Agent(StackingClient(), executor, "model").run("put red on blue")
        self.assertEqual(executor.done, ["list_objects", "pick", "place_on"])


class InTheAppTests(unittest.TestCase):
    """The whole demo app: the Go / Go all / Stop bar, the 3D view's preview, E-STOP, Shuffle."""

    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        shutil.copy(ROOT / "config.yaml", Path(cls.folder.name) / "config.yaml")
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        cls._originals = (QMessageBox.warning,)
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"   # the tests' scene, not the one last picked
        config["display"] = {"step_by_step": False}
        cls.window = main_window_module.MainWindow(config)
        cls.window.robot.max_speed = 3000
        cls.window.show()

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        (QMessageBox.warning,) = cls._originals
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def setUp(self):
        self.window.load_scene("two_blocks_and_tray")

    def test_the_switches_beside_send_and_in_settings_are_one_setting(self):
        panel = self.window.prompt_panel
        panel.step_switch.setChecked(True)
        self.assertTrue(self.window.display_settings["step_by_step"])
        self.assertTrue(all(p.boxes["step_by_step"].isChecked() for p in self.window._settings_panels))
        self.window._settings_panels[0].boxes["step_by_step"].setChecked(False)
        self.assertFalse(panel.step_switch.isChecked())
        buttons = {b.text(): b for b in self.window._settings_panels[0].findChildren(type(panel.go_btn))}
        buttons["All on"].click()
        self.assertFalse(self.window.display_settings["step_by_step"], "All on is for the 3D view only")
        buttons["Defaults"].click()

    def test_a_prompt_step_by_step_with_go_and_the_preview_in_the_3d_view(self):
        window, panel = self.window, self.window.prompt_panel
        window.display_settings.set("step_by_step", True)
        window.agent.client = StackingClient("red cube", "blue cube")
        views = window.findChildren(TwinView)
        asked, previews = [], []

        def press_go():
            if panel.waiting_for_you():
                asked.append(panel.approval_label.text())
                previews.append(views[0]._plan)
                panel.go_btn.click()
        timer = QTimer()
        timer.timeout.connect(press_go)
        timer.start(50)
        try:
            panel._send_text("put the red cube on the blue cube")
            pump_until(lambda: not panel.is_busy())
        finally:
            timer.stop()
            window.display_settings.set("step_by_step", False)
        self.assertEqual(len(asked), 2, asked)
        self.assertIn("Pick up the red cube", asked[0])
        self.assertIn("on top of the blue cube", asked[1])
        self.assertTrue(all(p is not None for p in previews), "the 3D view showed where each step goes")
        self.assertIsNone(views[0]._plan, "cleared when the task ends")
        red = window._twin_world.get_object_position_mm("red_cube")
        blue = window._twin_world.get_object_position_mm("blue_cube")
        self.assertLess(math.dist(red[:2], blue[:2]), 5.0)
        self.assertAlmostEqual(red[2] - blue[2], 20.0, delta=2.0)

    def test_stop_and_estop_end_the_task_there(self):
        window, panel = self.window, self.window.prompt_panel
        window.display_settings.set("step_by_step", True)
        window.agent.client = StackingClient("red cube", "blue cube")
        start = window._twin_world.get_object_position_mm("red_cube")
        try:
            panel._send_text("put the red cube on the blue cube")
            pump_until(panel.waiting_for_you)
            window._on_estop()                     # E-STOP while the first step waits
            self.assertFalse(panel.is_busy(), "the prompt ends at once")
            pump_until(lambda: not panel._abandoned)     # and its run winds down by itself
        finally:
            window.robot.reset_estop()
            window.display_settings.set("step_by_step", False)
        self.assertEqual(window._twin_world.get_object_position_mm("red_cube"), start, "nothing moved")
        self.assertIn("E-STOP: the prompt was ended", panel.log.toPlainText())

    def test_shuffle_repeat_a_layout_and_reset(self):
        window = self.window
        world = window._twin_world
        original = {o["id"]: o["pos"] for o in world.snapshot()}
        done, message, number = window.shuffle_scene()
        self.assertTrue(done, message)
        shuffled = {o["id"]: o["pos"] for o in world.snapshot()}
        self.assertNotEqual(shuffled["red_cube"], original["red_cube"])
        self.assertEqual(shuffled["tray"], original["tray"], "trays and bins stay put")
        window.shuffle_scene()
        window.shuffle_scene(number)                                 # the same number: the same layout
        self.assertEqual({o["id"]: o["pos"] for o in world.snapshot()}, shuffled)
        panel = window._settings_panels[0]
        panel.layout_field.setText(str(number))
        panel.layout_field.returnPressed.emit()
        self.assertIn(f"layout {number}", panel.scene_status.text())
        panel.reset_scene_btn.click()
        self.assertEqual({o["id"]: o["pos"] for o in world.snapshot()}, original)

    def test_shuffle_is_refused_while_a_prompt_runs(self):
        window = self.window
        original = window.prompt_panel.is_busy
        window.prompt_panel.is_busy = lambda: True
        try:
            done, message, _ = window.shuffle_scene(5)
        finally:
            window.prompt_panel.is_busy = original
        self.assertFalse(done)
        self.assertIn("prompt", message)

    def test_every_shuffled_layout_keeps_the_rules(self):
        window = self.window
        world = window._twin_world
        for scene in list_scenarios():
            world.switch_scenario(scene["name"])
            for seed in range(1, 51):
                layout = shuffle_module.shuffle_layout(world.snapshot(), seed, world.places(), (200.0, 0.0),
                                                       window._camera_sees)
                self.assertIsNotNone(layout, (scene["name"], seed))
                sizes = {o["id"]: o["size"] for o in world.snapshot()}
                trays = [o for o in world.snapshot() if o["shape"] == "tray"]
                items = list(layout.items())
                for i, (oid, (x, y, z)) in enumerate(items):
                    w, d, h = sizes[oid]
                    self.assertTrue(within_limits(x, y, h) and within_limits(x, y, h + 50), (scene["name"], seed, oid))
                    self.assertTrue(shuffle_module.INNER_MM <= math.hypot(x, y) <= shuffle_module.OUTER_MM)
                    self.assertLessEqual(abs(math.degrees(math.atan2(y, x))), shuffle_module.MAX_TURN_DEG)
                    self.assertTrue(window._camera_sees(x, y, max(w, d)))
                    self.assertGreaterEqual(math.hypot(x - 200.0, y), shuffle_module.ARM_CLEARANCE_MM)
                    for tray in trays:
                        tx, ty, _ = tray["pos"]
                        tw, td, _ = tray["size"]
                        self.assertTrue(abs(x - tx) >= (w + tw) / 2 + 15 or abs(y - ty) >= (d + td) / 2 + 15)
                    for other, (ox, oy, _) in items[i + 1:]:
                        ow, od, _ = sizes[other]
                        self.assertTrue(abs(x - ox) >= (w + ow) / 2 + 20 or abs(y - oy) >= (d + od) / 2 + 20)
        world.switch_scenario("two_blocks_and_tray")


if __name__ == "__main__":
    unittest.main()

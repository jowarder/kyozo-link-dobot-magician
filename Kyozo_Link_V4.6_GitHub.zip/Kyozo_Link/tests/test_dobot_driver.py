"""The real robot driver, run against a fake Dobot that speaks the same protocol.

    python -m unittest discover -s tests -p test_dobot_driver.py -v

The fake takes real time to move, keeps a command queue like the real controller, and when
told to stop it halts and clears the queue -- so the move being waited for never "finishes".
That is exactly the situation that made an E-STOP misbehave.
"""
from __future__ import annotations

import struct
import threading
import time
import unittest
from types import SimpleNamespace

from harness import ROOT  # noqa: F401  (sets up sys.path)
from app.hardware import dobot as dobot_module
from app.hardware.dobot import DobotRobot
from app.hardware.dobot_link import RobustDobot
from app.hardware.interfaces import OutOfReach, Pose, RobotAlarm, RobotNeedsPerson, RobotStopped

BOUNDS = {"x": [-300.0, 307.0], "y": [-300.0, 300.0], "z": [-100.0, 300.0]}


class FakeDobot:
    """Just enough of a Dobot Magician: timed straight-line moves through a command queue."""

    def __init__(self, move_seconds: float = 1.0):
        self.lock = threading.Lock()            # like pydobot's: one serial message at a time
        self.move_seconds = move_seconds
        self.position = [200.0, 0.0, 50.0, 0.0]
        self.queued = 0
        self.finished = 0
        self.move = None                        # (index, t0, t1, start, target)
        self.move_started_at = None
        self.stopped_at = None
        self.log: list = []
        self.drop_replies = 0                   # how many upcoming status requests get no reply
        self.never_finish = False
        self.alarm = False                      # the controller's alarm flags
        self.queue_stopped = False              # after a stop command nothing queued runs until it is started again
        self.no_gripper_reply = False
        self.gripper_commands: list = []
        self.alarm_flags: bytes | None = None   # specific alarm bits (e.g. 0x22), cleared by "clear alarms"
        self.modes: list = []                   # 2 = straight line (MOVL), 1 = joints turn evenly (MOVJ)
        # Like the real arm: nearer the base than this it can't go. A straight move that gets this close
        # stops there, raises alarm 0x22, and still counts as finished -- which is what really happened.
        self.inner_limit_mm: float | None = None
        self.stops_short = False                # finishes without getting there and says nothing
        self.sticky_alarm = False               # "clear alarms" doesn't: the controller is stuck (a power-cycle job)
        self.unanswered_moves = 0               # this many upcoming moves are queued but get no answer (seen at the lab)
        self.queue_full = False                 # takes no move, and doesn't answer, until the queue is cleared
        self.holding_moves = False              # ...until its alarms are cleared, none showing (the lab, 2026-10-21)
        self.common: tuple | None = (100.0, 100.0)    # every move's speed and acceleration, percent (None: won't say)

    def _limited(self, start: list, target: list) -> list | None:
        """Where a straight move from start to target has to stop, or None if it can get there."""
        if self.inner_limit_mm is None:
            return None
        previous = start
        for i in range(1, 501):
            t = i / 500
            point = [s + (e - s) * t for s, e in zip(start, target)]
            if (point[0] ** 2 + point[1] ** 2) ** 0.5 < self.inner_limit_mm:
                return previous
            previous = point
        return None

    def _advance(self, now: float) -> None:
        if self.move is not None and now >= self.move[2] and not self.never_finish:
            self.finished, self.position, self.move = self.move[0], list(self.move[4]), None

    def _send_command(self, msg, wait=False):
        with self.lock:
            now = time.monotonic()
            self._advance(now)
            message_id = getattr(msg.id, "value", msg.id)
            if message_id == 84 and (self.queue_full or self.holding_moves):   # no answer, nothing moves
                self.log.append("not taken")
                return None
            if message_id in (84, 31):                             # queue a move, or homing
                target = (list(struct.unpack_from("<4f", msg.params, 1)) if message_id == 84
                          else [200.0, 0.0, 50.0, 0.0])
                self.queued += 1
                seconds = self.move_seconds
                if message_id == 84:
                    self.modes.append(msg.params[0])
                    stop = self._limited(self.position, target) if msg.params[0] == 2 else None
                    if stop is not None:
                        target, seconds = stop, 0.05
                        self.alarm_flags = bytes([0, 0, 0, 0, 4] + [0] * 11)       # 0x22 = byte 4, bit 2
                    elif self.stops_short:
                        target = [(s + e) / 2 for s, e in zip(self.position, target)]
                self.move = (self.queued, now, now + seconds, list(self.position), target)
                self.move_started_at = now
                if self.unanswered_moves:
                    self.unanswered_moves -= 1
                    return None
                return SimpleNamespace(params=struct.pack("<II", self.queued, 0))
            if message_id in (62, 63):                             # suction cup / two-finger gripper
                queued = bool(msg.ctrl.value >> 1 & 1) if hasattr(msg.ctrl, "value") else bool(msg.ctrl >> 1 & 1)
                if self.no_gripper_reply:
                    return None
                if queued and self.queue_stopped:                  # a stopped queue never gets to it
                    self.log.append(("never ran", message_id))
                else:
                    kind = "suck" if message_id == 62 else "grip"
                    self.log.append((kind, bool(msg.params[1])) if msg.params[0] else ("pump off", kind))
                    self.gripper_commands.append({"queued": queued, "at": now})
                return SimpleNamespace(params=b"")
            if message_id == 83:                                  # every move's speed, percent: asked for
                return None if self.common is None else SimpleNamespace(params=struct.pack("<ff", *self.common))
            if message_id == 20:                                   # alarm flags: a row of zeros when healthy
                if self.alarm_flags is not None:
                    return SimpleNamespace(params=self.alarm_flags)
                return SimpleNamespace(params=bytes([1] + [0] * 15) if self.alarm else bytes(16))
            if message_id == 21:                                   # clear all alarms
                if not self.sticky_alarm:
                    self.alarm_flags = None
                self.holding_moves = False
                self.log.append("clear alarms")
            if message_id == 246:                                  # index of the last finished command
                if self.drop_replies:
                    self.drop_replies -= 1
                    return None
                return SimpleNamespace(params=struct.pack("<II", self.finished, 0))
            if message_id == 240:                                  # start executing
                self.queue_stopped = False
            if message_id == 241:                                  # stop executing
                self.stopped_at, self.move, self.queue_stopped = now, None, True
                self.log.append("stop")
            elif message_id == 245:                                # clear the queue
                self.move = None
                self.queue_full = False
                self.log.append("clear")
            return SimpleNamespace(params=b"\x00" * 8)

    def pose(self):
        with self.lock:
            now = time.monotonic()
            self._advance(now)
            if self.move is not None:
                index, t0, t1, start, target = self.move
                fraction = min(1.0, (now - t0) / (t1 - t0))
                return tuple(s + (t - s) * fraction for s, t in zip(start, target)) + (0.0, 0.0, 0.0, 0.0)
            return tuple(self.position) + (0.0, 0.0, 0.0, 0.0)

    def _set_ptp_coordinate_params(self, velocity, acceleration):
        self.speed = (velocity, acceleration)

    def _set_ptp_common_params(self, velocity, acceleration):
        self.common = (velocity, acceleration)


def make_robot(fake: FakeDobot, homed: bool = True, **kwargs) -> DobotRobot:
    """A driver on the fake, homed already (as at the lab: Home first) unless `homed` is False."""
    kwargs.setdefault("gripper_settle_s", 0.0)
    robot = DobotRobot(port="FAKE", workspace_bounds=BOUNDS, **kwargs)
    robot._device = fake
    robot.homed = homed
    return robot


class DriverTests(unittest.TestCase):
    def test_homing_is_remembered_and_calibrating_slows_every_move(self):
        fake = FakeDobot(move_seconds=0.05)
        robot = make_robot(fake, homed=False)
        self.assertFalse(robot.homed)
        robot.home()
        self.assertTrue(robot.homed)
        self.assertIsNotNone(robot.homed_at)
        fake.common = (100.0, 80.0)
        before = robot.set_pace(50.0)
        self.assertEqual(before, (100.0, 80.0))
        self.assertEqual(fake.common, (50.0, 50.0))
        robot.set_pace(*before)
        self.assertEqual(fake.common, (100.0, 80.0))
        fake.common = None                      # a controller that doesn't say: nothing is changed
        self.assertIsNone(robot.set_pace(50.0))

    def test_a_move_completes_and_the_pose_can_be_read_while_it_runs(self):
        fake = FakeDobot(move_seconds=1.0)
        robot = make_robot(fake)
        mover = threading.Thread(target=robot.move_to, args=(Pose(250, 50, 20),))
        started = time.monotonic()
        mover.start()
        time.sleep(0.3)
        read_at = time.monotonic()
        pose = robot.get_pose()                                    # must not wait for the move to end
        self.assertLess(time.monotonic() - read_at, 0.3)
        self.assertTrue(200 < pose.x < 250, pose)
        mover.join(5)
        self.assertFalse(mover.is_alive())
        self.assertGreaterEqual(time.monotonic() - started, 0.9)
        self.assertAlmostEqual(robot.get_pose().x, 250, places=1)

    def test_estop_acts_at_once_and_ends_the_move(self):
        fake = FakeDobot(move_seconds=5.0)
        robot = make_robot(fake)
        outcome = {}

        def move():
            try:
                robot.move_to(Pose(250, 50, 20))
            except Exception as exc:  # noqa: BLE001
                outcome["error"], outcome["at"] = exc, time.monotonic()
        mover = threading.Thread(target=move)
        mover.start()
        time.sleep(0.4)
        pressed = time.monotonic()
        robot.stop()
        mover.join(3)
        self.assertFalse(mover.is_alive(), "the move must end, not wait out its 5 s")
        self.assertLess(fake.stopped_at - fake.move_started_at, 1.0, "the stop reached the robot during the move")
        self.assertLess(outcome["at"] - pressed, 1.0)
        self.assertIsInstance(outcome["error"], RuntimeError)
        self.assertIn("E-stopped", str(outcome["error"]))
        self.assertIn(("suck", False), fake.log, "the gripper was released")
        self.assertIn("clear", fake.log, "stale commands were dropped")

    def test_the_usual_pace_is_back_after_an_estop_reset(self):
        # (a slow move's "speed back as it was", queued just before the stop, is wiped with the queue)
        fake = FakeDobot(move_seconds=0.05)
        robot = make_robot(fake)
        robot.set_pace(20.0)
        robot.stop()
        self.assertEqual(fake.common, (20.0, 20.0))
        robot.reset_estop()
        self.assertEqual(fake.common, (100.0, 100.0))

    def test_nothing_moves_after_an_estop_until_it_is_reset(self):
        robot = make_robot(FakeDobot(move_seconds=0.2))
        robot.stop()
        with self.assertRaises(RuntimeError):
            robot.move_to(Pose(200, 0, 50))
        robot.reset_estop()
        robot.move_to(Pose(210, 0, 50))

    def test_a_move_that_never_finishes_times_out(self):
        fake = FakeDobot()
        fake.never_finish = True
        robot = make_robot(fake)
        original = dobot_module.MOVE_TIMEOUT_S
        dobot_module.MOVE_TIMEOUT_S = 0.8
        try:
            with self.assertRaises(TimeoutError):
                robot.move_to(Pose(250, 50, 20))
        finally:
            dobot_module.MOVE_TIMEOUT_S = original

    def test_a_few_lost_replies_are_tolerated_but_a_dead_link_is_reported(self):
        fake = FakeDobot(move_seconds=0.3)
        fake.drop_replies = 2
        make_robot(fake).move_to(Pose(250, 50, 20))               # fine
        dead = FakeDobot(move_seconds=0.3)
        dead.drop_replies = 10 ** 6
        with self.assertRaises(RuntimeError) as caught:
            make_robot(dead).move_to(Pose(250, 50, 20))
        self.assertIn("Lost contact", str(caught.exception))

    def test_every_message_goes_with_a_right_checksum(self):
        # the lab, 2026-10-21: two moves unanswered again and again -- pydobot sent them with checksums 0 and 1 where
        # 255 and 0 were right (its `% 255`), and the Dobot drops a message whose checksum is wrong
        from app.hardware.dobot_link import frame_bytes
        from pydobot.message import Message
        from app.hardware import dobot_protocol
        logged = ("aa aa 13 54 03 02 ff ff 24 43 ff ff b3 42 b7 62 b7 41 38 e2 e4 41 00",     # (165, 90, 23)
                  "aa aa 13 54 03 02 31 fe 89 43 0a 93 a1 c1 40 13 69 c1 d0 1b 85 c0 01")     # (276, -20, -15)
        for frame in logged:
            frame = bytes.fromhex(frame)
            wrong = frame[-1]
            msg = Message()
            msg.id, msg.ctrl = dobot_protocol.CommunicationProtocolIDs.SET_PTP_CMD, dobot_protocol.ControlValues.THREE
            msg.params = bytearray(frame[5:-1])
            sent = frame_bytes(msg)
            self.assertEqual(sent[:-1], frame[:-1], "the same message")
            self.assertEqual(sum(sent[3:]) % 256, 0, f"checksum {sent[-1]:#04x}")
            self.assertEqual(sent[:3], bytes([0xAA, 0xAA, 19]))
            self.assertNotEqual(sent[-1], wrong)
            self.assertEqual(msg.bytes()[-1], wrong, "pydobot's own bytes: the checksum the Dobot dropped")
        for n in range(512):                          # every sum: right, where pydobot's isn't for 2 of 256
            msg = Message()
            msg.id, msg.ctrl, msg.params = 10, 0, bytearray([n % 256, n // 256])
            self.assertEqual(sum(frame_bytes(msg)[3:]) % 256, 0)

    def test_the_link_writes_the_right_bytes(self):
        from app.hardware.dobot_link import frame_bytes
        from pydobot.message import Message
        link = RobustDobot.__new__(RobustDobot)
        written = []
        link.ser = SimpleNamespace(in_waiting=0, reset_input_buffer=lambda: None, write=written.append)
        msg = Message()
        msg.id, msg.ctrl, msg.params = 84, 3, bytearray([2]) + struct.pack("<4f", 165.0, 90.0, 22.923, 28.61)
        link._send_message(msg)
        self.assertEqual(written, [frame_bytes(msg)])
        self.assertEqual(sum(written[0][3:]) % 256, 0)

    def test_an_unanswered_read_is_asked_again_but_never_a_move(self):
        link = RobustDobot.__new__(RobustDobot)
        link.lock = threading.Lock()
        link.verbose = False
        sent, replies = [], []
        link._send_message = sent.append
        link._read_message = lambda: replies.pop(0) if replies else None
        read = SimpleNamespace(id=10, ctrl=0)                          # where the arm is: asked once more
        replies[:] = [None, "the pose"]
        self.assertEqual(link._send_command(read), "the pose")
        self.assertEqual(len(sent), 2)
        sent.clear()
        move = SimpleNamespace(id=84, ctrl=3)                          # a queued move: never sent twice
        replies[:] = [None, "late"]
        self.assertIsNone(link._send_command(move))
        self.assertEqual(len(sent), 1)

    def test_no_answer_to_a_position_request_is_said_as_one(self):
        from app.hardware.dobot import DobotRobot
        robot = DobotRobot.__new__(DobotRobot)

        def unanswered():
            return None.params                                         # (pydobot's pose() with no reply)
        robot._device = SimpleNamespace(pose=unanswered)
        with self.assertRaises(RuntimeError) as caught:
            robot._pose_reading()
        self.assertIn("didn't answer a position request", str(caught.exception))

    def test_a_serial_error_cannot_leave_the_link_locked(self):
        link = RobustDobot.__new__(RobustDobot)                    # no serial port needed
        link.lock = threading.Lock()
        link.verbose = False

        def broken(msg):
            raise OSError("the cable was pulled out")
        link._send_message = broken
        with self.assertRaises(OSError):
            link._send_command(SimpleNamespace())
        self.assertTrue(link.lock.acquire(blocking=False), "the lock must have been released")
        link.lock.release()


class SpeedTests(unittest.TestCase):
    def test_the_configured_speed_reaches_the_arm(self):
        fake = FakeDobot()
        robot = make_robot(fake, max_speed=80)
        robot._apply_speed()
        self.assertEqual(fake.speed[0], 80.0)

    def test_a_silly_speed_is_limited_and_a_failure_is_not_fatal(self):
        fake = FakeDobot()
        robot = make_robot(fake, max_speed=100000)
        robot._apply_speed()
        self.assertEqual(fake.speed[0], 500.0)
        fake._set_ptp_coordinate_params = None            # (calling it now raises)
        robot._apply_speed()


class GripperTests(unittest.TestCase):
    def test_the_gripper_acts_at_once_and_outside_the_motion_queue(self):
        fake = FakeDobot()
        robot = make_robot(fake)
        started = time.monotonic()
        robot.close_gripper()
        robot.open_gripper()
        self.assertLess(time.monotonic() - started, 0.3)
        self.assertEqual([c["queued"] for c in fake.gripper_commands], [False, False, False])
        self.assertEqual([entry for entry in fake.log if entry[0] in ("suck", "grip", "pump off")],
                         [("suck", True), ("suck", False), ("pump off", "suck")])

    def test_the_pump_is_switched_off_once_open_and_after_an_estop(self):
        """Once the gripper had been closed, the air pump ran on for good: "open" only turns the air round."""
        fake = FakeDobot()
        robot = make_robot(fake, gripper_type="gripper")
        robot.close_gripper()
        self.assertEqual(fake.log[-1], ("grip", True), "closed: the pump runs, the air holds it")
        robot.open_gripper()
        self.assertEqual(fake.log[-2:], [("grip", False), ("pump off", "grip")])
        robot.close_gripper()
        robot.stop()
        deadline = time.monotonic() + robot.gripper_settle_s + 2.0
        while fake.log[-1] != ("pump off", "grip") and time.monotonic() < deadline:
            time.sleep(0.05)
        self.assertEqual(fake.log[-2:], [("grip", False), ("pump off", "grip")], "let go, then the pump off")

    def test_the_two_finger_gripper_uses_its_own_command(self):
        fake = FakeDobot()
        make_robot(fake, gripper_type="gripper").close_gripper()
        self.assertIn(("grip", True), fake.log)

    def test_it_works_while_the_arm_is_still_moving(self):
        fake = FakeDobot(move_seconds=1.5)
        robot = make_robot(fake)
        mover = threading.Thread(target=robot.move_to, args=(Pose(250, 50, 20),))
        mover.start()
        time.sleep(0.3)
        started = time.monotonic()
        robot.close_gripper()
        self.assertLess(time.monotonic() - started, 0.3, "the gripper button must not wait for the move")
        mover.join(5)

    def test_the_estop_release_really_happens_even_though_the_queue_is_stopped(self):
        fake = FakeDobot()
        robot = make_robot(fake)
        robot.stop()
        self.assertIn(("suck", False), fake.log)
        self.assertNotIn(("never ran", 62), fake.log)

    def test_after_an_estop_you_can_let_go_but_not_grab(self):
        fake = FakeDobot()
        robot = make_robot(fake)
        robot.stop()
        robot.open_gripper()                                       # letting go of a held object is not motion
        with self.assertRaises(RobotStopped):
            robot.close_gripper()

    def test_it_waits_for_the_air_before_returning(self):
        robot = make_robot(FakeDobot(), gripper_settle_s=0.4)
        started = time.monotonic()
        robot.close_gripper()
        self.assertGreaterEqual(time.monotonic() - started, 0.4)

    def test_asking_for_what_it_already_is_does_not_wait_again(self):
        robot = make_robot(FakeDobot(), gripper_settle_s=0.4)
        robot.open_gripper()                                       # first time: state unknown, so it waits
        started = time.monotonic()
        robot.open_gripper()
        self.assertLess(time.monotonic() - started, 0.2)
        robot.close_gripper()
        started = time.monotonic()
        robot.close_gripper()
        self.assertLess(time.monotonic() - started, 0.2)

    def test_an_estop_during_the_wait_ends_it(self):
        robot = make_robot(FakeDobot(), gripper_settle_s=5.0)
        threading.Timer(0.3, robot.stop).start()
        started = time.monotonic()
        with self.assertRaises(RobotStopped):
            robot.close_gripper()
        self.assertLess(time.monotonic() - started, 2.0)

    def test_no_acknowledgement_is_an_error_not_a_silent_success(self):
        fake = FakeDobot()
        fake.no_gripper_reply = True
        with self.assertRaisesRegex(RuntimeError, "did not acknowledge"):
            make_robot(fake).close_gripper()


class UnansweredMoveTests(unittest.TestCase):
    def test_a_move_without_an_answer_is_sent_once_more_and_gets_there(self):
        fake = FakeDobot(move_seconds=0.2)
        fake.unanswered_moves = 1
        robot = make_robot(fake)
        with self.assertLogs("app.hardware.dobot", "WARNING") as logs:
            robot.move_to(Pose(220, 40, 60, 0))
        self.assertIn("sending it once more", " ".join(logs.output))
        self.assertEqual(fake.queued, 2)
        for got, want in zip(fake.position[:3], (220, 40, 60)):
            self.assertAlmostEqual(got, want, delta=0.5)

    def test_three_without_an_answer_is_an_error(self):
        fake = FakeDobot(move_seconds=0.2)
        fake.unanswered_moves = 3
        with self.assertRaisesRegex(RuntimeError, "did not acknowledge.*no reply.*Clear Alarms"):
            make_robot(fake).move_to(Pose(220, 40, 60, 0))

    def test_a_controller_holding_back_moves_with_no_alarm_showing_is_cleared_as_clear_alarms_does(self):
        # (the lab, 2026-10-21: the move to touch point 6 unanswered three times, no alarm, everything else answered;
        # stopping and starting the queue didn't help -- the Clear Alarms button had)
        fake = FakeDobot(move_seconds=0.2)
        robot = make_robot(fake)
        fake.holding_moves = True
        with self.assertLogs("app.hardware.dobot", "WARNING") as logs:
            robot.move_to(Pose(220, 40, 60, 0))
        self.assertIn("as Clear Alarms does", " ".join(logs.output))
        self.assertIn("sent: aa aa", " ".join(logs.output), "what went out is in the log")
        self.assertIn("clear alarms", fake.log)
        for got, want in zip(fake.position[:3], (220, 40, 60)):
            self.assertAlmostEqual(got, want, delta=0.5)

    def test_a_stuck_queue_is_started_afresh_and_the_move_goes(self):
        # (the lab: the same move unanswered again and again, the jog's too, no alarm; Clear Alarms -- which starts
        # the queue afresh -- put it right)
        fake = FakeDobot(move_seconds=0.2)
        robot = make_robot(fake)
        robot.set_pace(50.0)
        fake.queue_full = True
        with self.assertLogs("app.hardware.dobot", "WARNING") as logs:
            robot.move_to(Pose(220, 40, 60, 0))
        self.assertIn("command queue and alarms", " ".join(logs.output))
        self.assertIn("clear", fake.log)
        self.assertEqual(fake.log.count("not taken"), 2)
        for got, want in zip(fake.position[:3], (220, 40, 60)):
            self.assertAlmostEqual(got, want, delta=0.5)


class DriverSafetyTests(unittest.TestCase):
    def test_homing_waits_until_the_arm_has_finished(self):
        fake = FakeDobot(move_seconds=0.6)
        robot = make_robot(fake)
        started = time.monotonic()
        robot.home()
        self.assertGreaterEqual(time.monotonic() - started, 0.5,
                                "home() must not return while the arm is still travelling")
        self.assertAlmostEqual(robot.get_pose().x, 200.0, places=1)

    def test_a_controller_alarm_ends_the_move_quickly_instead_of_hanging(self):
        fake = FakeDobot(move_seconds=30.0)          # the move would never finish: the arm has stopped
        robot = make_robot(fake)
        originals = dobot_module.ALARM_CHECK_AFTER_S, dobot_module.ALARM_CHECK_EVERY_S
        dobot_module.ALARM_CHECK_AFTER_S, dobot_module.ALARM_CHECK_EVERY_S = 0.3, 0.2
        threading.Timer(0.4, lambda: setattr(fake, "alarm", True)).start()
        started = time.monotonic()
        try:
            with self.assertRaises(RobotAlarm) as caught:
                robot.move_to(Pose(250, 50, 20))
        finally:
            dobot_module.ALARM_CHECK_AFTER_S, dobot_module.ALARM_CHECK_EVERY_S = originals
        self.assertLess(time.monotonic() - started, 3.0)
        self.assertIn("Clear Alarms", str(caught.exception))

    def test_a_healthy_robot_is_not_reported_as_in_alarm(self):
        from app.system_check import CheckContext, OK, _robot
        robot = make_robot(FakeDobot())
        self.assertEqual(robot.get_alarms(), [0] * 16)
        context = CheckContext(mode="live", config={}, robot=robot, camera=None, detector=None,
                               get_transform=lambda: None, calibrated=False, calibration_error_mm=None,
                               calibration_file=None)
        statuses = {r.area: r.status for r in _robot(context)}
        self.assertEqual(statuses["robot alarms"], OK)

    def test_position_and_alarms_can_still_be_read_after_an_estop(self):
        robot = make_robot(FakeDobot())
        robot.stop()
        self.assertAlmostEqual(robot.get_pose().x, 200.0, places=1)     # you want to see where it stopped
        self.assertEqual(robot.get_alarms(), [0] * 16)
        with self.assertRaises(RobotStopped):
            robot.move_to(Pose(210, 0, 50))

    def test_which_paths_cut_across_in_front_of_the_base(self):
        near = dobot_module.passes_near_base
        self.assertTrue(near(Pose(133, 202, 83), Pose(133, -202, 53)), "the calibration sweep's move that stuck")
        self.assertFalse(near(Pose(250, 0, 50), Pose(170, 0, 50)), "straight in towards the base: ends are closest")
        self.assertFalse(near(Pose(220, 0, 80), Pose(220, 0, -50)), "straight down")
        self.assertFalse(near(Pose(250, -100, 30), Pose(250, 100, 30)), "a chord well away from the base")

    def test_going_from_one_side_of_the_base_to_the_other_swings_round(self):
        """On the real arm, the automatic calibration went from (133, 202) straight towards (133, -202): the
        line passes 133 mm from the base, the arm stopped at 183 mm with alarm 0x22, and nothing noticed."""
        fake = FakeDobot(move_seconds=0.2)
        fake.inner_limit_mm = 185.0
        fake.position = [133.3, 202.5, 83.2, 0.0]
        robot = make_robot(fake)
        robot.move_to(Pose(133.3, -202.5, 53.2))
        self.assertEqual(fake.modes, [1], "joint move, not a straight line")
        self.assertAlmostEqual(robot.get_pose().y, -202.5, places=1)
        robot.move_to(Pose(133.3, -202.5, 20.0))                   # straight down stays a straight line
        self.assertEqual(fake.modes, [1, 2])

    def test_a_move_the_arm_cannot_finish_is_reported_and_the_arm_still_works(self):
        """What made jogging look dead after the calibration: the arm stopped at its limit, the controller
        counted the move as done, and every later move was silently dropped until the alarm was cleared."""
        fake = FakeDobot(move_seconds=0.2)
        fake.inner_limit_mm = 185.0
        fake.position = [250.0, 0.0, 50.0, 0.0]
        robot = make_robot(fake)
        with self.assertRaises(OutOfReach) as caught:
            robot.move_to(Pose(165, 0, 10))
        self.assertIn("can't reach (165, 0, 10)", str(caught.exception))
        self.assertIn("further out", str(caught.exception))
        self.assertIn("clear alarms", fake.log, "cleared at once: no hunting for the Clear Alarms button")
        self.assertIsNone(fake.alarm_flags)
        robot.move_to(Pose(240, 0, 20))                            # and it moves again straight away
        self.assertAlmostEqual(robot.get_pose().x, 240.0, places=1)

    def test_a_leftover_reach_alarm_is_cleared_before_moving(self):
        fake = FakeDobot(move_seconds=0.1)
        fake.alarm_flags = bytes([0, 0, 0, 0, 4] + [0] * 11)
        robot = make_robot(fake)
        robot.move_to(Pose(230, 0, 40))
        self.assertAlmostEqual(robot.get_pose().x, 230.0, places=1)

    def test_a_controller_stuck_in_alarm_is_reported_once_not_tried_again_and_again(self):
        """What happened after an interrupted homing: every move refused, the alarm straight back after clearing,
        and the calibration going through all its positions anyway."""
        fake = FakeDobot(move_seconds=0.1)
        fake.alarm_flags, fake.sticky_alarm = bytes([0, 0, 0, 0, 4] + [0] * 11), True
        robot = make_robot(fake)
        with self.assertRaises(RobotAlarm) as caught:
            robot.move_to(Pose(230, 0, 40))
        self.assertNotIsInstance(caught.exception, OutOfReach, "callers must stop, not skip to the next place")
        self.assertIn("Switch the Dobot off", str(caught.exception))
        self.assertIn("J1", str(caught.exception), "the joint angles are shown, to see which one is at its limit")
        self.assertEqual(fake.queued, 0, "no move is sent to a controller that will refuse it")
        with self.assertRaisesRegex(RobotAlarm, "Switch the Dobot off"):
            robot.home()

    def test_an_alarm_left_over_is_cleared_before_homing_not_blamed_on_it(self):
        fake = FakeDobot(move_seconds=0.3)
        fake.alarm_flags = bytes([0, 0, 0, 0, 4] + [0] * 11)
        make_robot(fake).home()
        self.assertIsNone(fake.alarm_flags)

    def test_any_other_alarm_is_reported_before_moving(self):
        fake = FakeDobot(move_seconds=0.1)
        fake.alarm = True
        with self.assertRaisesRegex(RobotAlarm, "Clear Alarms"):
            make_robot(fake).move_to(Pose(230, 0, 40))
        self.assertEqual(fake.queued, 0, "nothing was sent")

    def test_a_move_that_ends_short_without_an_alarm_is_not_a_success(self):
        fake = FakeDobot(move_seconds=0.1)
        fake.stops_short = True
        with self.assertRaisesRegex(RobotAlarm, "short of"):
            make_robot(fake).move_to(Pose(260, 0, 50))

    def test_a_prompt_ends_when_the_robot_is_estopped(self):
        from app.llm.agent import Agent

        class Executor:
            calls = 0

            def execute(self, name, arguments):
                Executor.calls += 1
                raise RobotStopped("Robot is E-stopped.")

        class Client:
            def chat(self, model, messages, tools=None, temperature=0.2):
                return {"tool_calls": [{"function": {"name": "home", "arguments": {}}}]}
        run = Agent(Client(), Executor(), "model", max_tool_calls=8).run("go home")
        self.assertEqual(Executor.calls, 1, "the model is not given the chance to try again")
        self.assertTrue(run.final_message.startswith("Stopped"))

    def test_a_target_the_controller_would_refuse_is_not_sent(self):
        """Study 2, S-06_Run1: (145, -67, 42), 160 mm from the base, needs the rear arm at -6 degrees; sent, the
        controller stopped in alarm 0x12 and refused every move after it until switched off and on."""
        fake = FakeDobot(move_seconds=0.05)
        robot, events = WatcherEventTests.watched(self, fake)
        with self.assertRaisesRegex(OutOfReach, "rear arm"):
            robot.move_to(Pose(145.27, -67.06, 42.13, -51.6))
        self.assertEqual(fake.queued, 0, "nothing was sent")
        self.assertIn("unreachable", [e["kind"] for e in events])
        self.assertIsNone(robot.needs_person, "the arm is free: it hasn't moved")
        robot.move_to(Pose(145.27, -67.06, 12.0, -51.6))        # 30 mm lower is fine
        self.assertAlmostEqual(robot.get_pose().z, 12.0, places=1)

    def test_a_prompt_ends_when_the_arm_needs_a_person(self):
        """Study 2, S-08_Run1: the link lost, then Reconnect with no Home; the model kept calling swap and pick, and
        the unhomed arm went where it wasn't sent. Now the prompt stops at the first step that meets it."""
        from app.llm.agent import Agent

        fake = FakeDobot(move_seconds=0.05)
        robot = make_robot(fake)

        class Executor:
            calls = 0

            def __init__(self):
                self.robot = robot

            def execute(self, name, arguments):
                Executor.calls += 1
                robot.homed = False                            # (as a power cycle and Reconnect leave it)
                return "ERROR: " + str(robot.needs_person)

        class Client:
            def chat(self, model, messages, tools=None, temperature=0.2):
                return {"tool_calls": [{"function": {"name": "pick", "arguments": {"object_id": "obj_1"}}}]}
        run = Agent(Client(), Executor(), "model", max_tool_calls=8).run("pick up the red cube")
        self.assertEqual(Executor.calls, 1, "nothing more is tried on an arm that needs a person")
        self.assertIn("needs a person", run.final_message)
        self.assertIn("Press Home", run.final_message)
        Executor.calls = 0
        run = Agent(Client(), Executor(), "model", max_tool_calls=8).run("pick up the red cube")
        self.assertEqual(Executor.calls, 0, "a prompt started on it does nothing at all")
        self.assertIn("needs a person", run.final_message)



class WatcherEventTests(unittest.TestCase):
    """What the study's watcher hears from the driver: every move, gripper command and controller alarm, with the
    joint angles and whether the app cleared the alarm by itself or a person had to."""

    def watched(self, fake):
        robot = make_robot(fake)
        events = []
        robot.add_watcher(events.append)
        return robot, events

    def test_moves_and_the_gripper_are_reported(self):
        robot, events = self.watched(FakeDobot(move_seconds=0.05))
        robot.move_to(Pose(230, 10, 40, 15))
        robot.close_gripper()
        robot.open_gripper()
        kinds = [e["kind"] for e in events]
        self.assertEqual(kinds, ["move", "gripper", "gripper"])
        self.assertEqual(events[0]["target"], {"x": 230, "y": 10, "z": 40, "r": 15})
        self.assertTrue(events[0]["ok"])
        self.assertEqual([e["closed"] for e in events[1:]], [True, False])

    def test_a_joint_limit_alarm_is_reported_with_its_joints_and_cleared_by_the_app(self):
        fake = FakeDobot(move_seconds=0.2)
        fake.inner_limit_mm = 185.0
        fake.position = [250.0, 0.0, 50.0, 0.0]
        robot, events = self.watched(fake)
        with self.assertRaises(OutOfReach):
            robot.move_to(Pose(165, 0, 10))
        alarm = next(e for e in events if e["kind"] == "alarm")
        self.assertEqual(alarm["codes"], ["0x22"])
        self.assertEqual(alarm["phases"], ["moving"])
        self.assertTrue(alarm["auto_cleared"])
        self.assertEqual(len(alarm["joints"]), 4)
        self.assertEqual(alarm["target"]["x"], 165)
        failed = [e for e in events if e["kind"] == "move"][-1]
        self.assertFalse(failed["ok"])
        self.assertIn("OutOfReach", failed["error"])

    def test_a_stuck_alarm_says_a_person_is_needed_and_clearing_by_hand_is_reported(self):
        fake = FakeDobot(move_seconds=0.1)
        fake.alarm_flags, fake.sticky_alarm = bytes([0, 0, 0, 0, 4] + [0] * 11), True
        robot, events = self.watched(fake)
        with self.assertRaises(RobotAlarm):
            robot.move_to(Pose(230, 0, 40))
        alarm = next(e for e in events if e["kind"] == "alarm")
        self.assertFalse(alarm["auto_cleared"])
        self.assertTrue(alarm["leftover"])
        fake.sticky_alarm = False
        robot.clear_alarms()
        self.assertEqual(events[-1]["kind"], "alarm_cleared_by_hand")

    def test_not_homed_since_connecting_every_move_is_refused_until_home(self):
        """Study 2, S-08_Run1: power-cycled and reconnected mid-task, not homed -- the arm took itself to be 64
        degrees round from where it was, and every move went somewhere else."""
        fake = FakeDobot(move_seconds=0.05)
        robot, events = self.watched(fake)
        robot.homed = False
        self.assertIn("Press Home", robot.needs_person)
        with self.assertRaisesRegex(RobotNeedsPerson, "Press Home"):
            robot.move_to(Pose(230, 0, 40))
        with self.assertRaises(RobotNeedsPerson):
            robot.close_gripper()
        robot.open_gripper()                                    # letting go is not motion
        self.assertEqual(fake.queued, 0, "nothing was sent to move")
        self.assertEqual(events[-2]["kind"], "needs_person")
        robot.clear_alarms()                                    # what a person does is allowed
        robot.home()
        self.assertIsNone(robot.needs_person)
        robot.move_to(Pose(230, 0, 40))
        self.assertAlmostEqual(robot.get_pose().x, 230.0, places=1)

    def test_a_lost_usb_link_refuses_everything_until_reconnect(self):
        """Study 2, S-08 and S-09: the Dobot switched off mid-task -- "ClearCommError failed (PermissionError(13,
        'Access is denied.'))" -- then every later step tried again on the dead port."""
        import serial

        class GonePort:                                         # (what pyserial does once the port has gone)
            @property
            def in_waiting(self):
                raise serial.SerialException("ClearCommError failed (PermissionError(13, 'Access is denied.', None, 5))")

        link = RobustDobot.__new__(RobustDobot)
        link.lock, link.ser, link.verbose = threading.Lock(), GonePort(), False
        robot = make_robot(FakeDobot())
        robot._device = link
        with self.assertRaisesRegex(ConnectionError, "USB link was lost"):
            link._send_command(SimpleNamespace(id=20, ctrl=0, params=b""))
        self.assertIn("Access is denied", link.link_lost)
        self.assertIn("Reconnect Robot", robot.needs_person)
        with self.assertRaisesRegex(RobotNeedsPerson, "Reconnect Robot"):
            robot.move_to(Pose(230, 0, 40))
        with self.assertRaisesRegex(RobotNeedsPerson, "Reconnect Robot"):
            robot.home()                                        # Home can't put a lost link right
        with self.assertRaisesRegex(ConnectionError, "lost earlier"):
            link._send_command(SimpleNamespace(id=20, ctrl=0, params=b""))   # not tried on the dead port again

    def test_a_stuck_alarm_holds_every_move_until_it_clears_or_the_arm_is_homed(self):
        fake = FakeDobot(move_seconds=0.05)
        fake.alarm_flags, fake.sticky_alarm = bytes([0, 0, 0, 0, 4] + [0] * 11), True
        robot = make_robot(fake)
        with self.assertLogs("app.hardware.dobot", "ERROR") as logs:
            with self.assertRaises(RobotNeedsPerson):
                robot.move_to(Pose(230, 0, 40))
        self.assertIn("Controller state: alarm bytes", " ".join(logs.output), "its state logged, to find why")
        self.assertIn("stuck in alarm", robot.needs_person)
        clears = fake.log.count("clear alarms")
        with self.assertRaises(RobotNeedsPerson):
            robot.move_to(Pose(230, 0, 40))
        self.assertEqual(fake.log.count("clear alarms"), clears, "refused at once, not cleared and tried again")
        robot.clear_alarms()                                    # still stuck: still held
        self.assertIsNotNone(robot.needs_person)
        fake.sticky_alarm = False
        robot.clear_alarms()                                    # cleared now: free again
        self.assertIsNone(robot.needs_person)
        robot.move_to(Pose(230, 0, 40))

    def test_estop_and_clamps_are_reported_and_a_failing_watcher_never_stops_the_robot(self):
        robot, events = self.watched(FakeDobot(move_seconds=0.05))
        robot.add_watcher(lambda e: 1 / 0)
        robot.move_to(Pose(400, 0, 50))                         # past the reach: clamped
        self.assertIn("clamp", [e["kind"] for e in events])
        robot.stop()
        self.assertEqual(events[-1]["kind"], "estop")


class StatusRequestTests(unittest.TestCase):
    """Each status request costs about 0.13 s on the real serial link: a move straight after a checked arrival
    uses that check's reading instead of asking again (SETTLED_FOR_S), but every move is still checked after."""

    def _counting(self, fake: FakeDobot) -> dict:
        counts = {"alarms": 0, "pose": 0}
        send, pose = fake._send_command, fake.pose

        def counted_send(msg, wait=False):
            if getattr(msg.id, "value", msg.id) == 20:
                counts["alarms"] += 1
            return send(msg, wait)

        def counted_pose():
            counts["pose"] += 1
            return pose()
        fake._send_command, fake.pose = counted_send, counted_pose
        return counts

    def test_a_move_straight_after_another_asks_only_for_its_own_arrival_check(self):
        from app.llm.recording import MoveRecorder
        fake = FakeDobot(move_seconds=0.05)
        robot = make_robot(fake)
        robot.move_to(Pose(220, 0, 50))
        counts = self._counting(fake)
        recorder = MoveRecorder(robot)
        recorder.moves = []
        recorder.move_to(Pose(240, 10, 40))           # recorded: where it was and its joints, before and after
        self.assertEqual(counts, {"alarms": 1, "pose": 1})
        self.assertAlmostEqual(recorder.moves[0]["to"][0], 240, places=1)
        self.assertAlmostEqual(recorder.moves[0]["from"][0], 220, places=1)

    def test_an_alarm_since_the_last_move_is_still_caught_by_the_next_moves_check(self):
        fake = FakeDobot(move_seconds=0.05)
        robot = make_robot(fake)
        robot.move_to(Pose(220, 0, 50))
        fake.alarm = True
        with self.assertRaises(RobotAlarm):
            robot.move_to(Pose(240, 0, 50))

    def test_the_dobot_is_asked_again_after_a_while_a_stop_or_clearing_its_alarms(self):
        fake = FakeDobot(move_seconds=0.05)
        robot = make_robot(fake)
        for forget in (lambda: setattr(dobot_module, "SETTLED_FOR_S", -1.0), robot.clear_alarms,
                       lambda: (robot.stop(), robot.reset_estop())):
            original = dobot_module.SETTLED_FOR_S
            robot.move_to(Pose(220, 0, 50))
            try:
                forget()
                counts = self._counting(fake)
                robot.get_pose()
            finally:
                dobot_module.SETTLED_FOR_S = original
                fake.__dict__.pop("_send_command", None), fake.__dict__.pop("pose", None)
            self.assertEqual(counts["pose"], 1)

    def test_a_leftover_alarm_is_still_found_before_the_first_move(self):
        fake = FakeDobot(move_seconds=0.05)
        robot = make_robot(fake)
        fake.alarm_flags = bytes([0, 0, 0, 0, 4] + [0] * 11)         # 0x22, from before: cleared, then the move
        robot.move_to(Pose(220, 0, 50))
        self.assertIn("clear alarms", fake.log)


if __name__ == "__main__":
    unittest.main()

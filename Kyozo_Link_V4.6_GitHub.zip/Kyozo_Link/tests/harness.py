"""Shared test setup: a simulated workspace, and the calibration procedure run without a UI.

Nothing here touches the project's real files: calibrations and sessions are kept in memory
or in temporary folders.
"""
from __future__ import annotations

import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
os.chdir(ROOT)  # scenario and config lookups are relative to the project

import app.config as _app_config  # noqa: E402

_load_config = _app_config.load_config


def _load_config_for_tests(*args, **kwargs) -> dict:
    """config.yaml as the app reads it, but always for the Dobot: the robot last picked in the app (config.yaml's
    robot_model) must not decide which robot the tests drive. The xArm's tests ask for it themselves. And the app
    doesn't manage the models in Ollama (load at start, unload on close): the tests mustn't touch them."""
    config = _load_config(*args, **kwargs)
    config["robot_model"] = "dobot_magician"
    config["study"] = {**(config.get("study") or {}), "paper": "a4"}   # the tests' sheet is the design's A4
    config.setdefault("llm", {})["manage_memory"] = False   # never load or unload the models in your Ollama
    return config


_app_config.load_config = _load_config_for_tests

from app import robots  # noqa: E402

robots.set_active("dobot_magician")

from app.calibration.boardless import BoardlessCalibrator, SolveResult  # noqa: E402
from app.calibration.table_touch import apply_table_touch  # noqa: E402
from app.config import load_config  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from app.hardware.sim_camera import SimCamera  # noqa: E402
from app.hardware.sim_robot import SimRobot  # noqa: E402
from app.twin.world import TwinWorld, demo_workspace_bounds  # noqa: E402
from app.vision.detector import build_detector  # noqa: E402
from app.vision.locator import foreground_depth  # noqa: E402
from app.vision.scene import SceneBuilder  # noqa: E402
from app.vision.table import measure_table  # noqa: E402

LOOK_POSE = Pose(x=120.0, y=-160.0, z=90.0, r=0.0)   # arm out of the way of the cubes
CLICK_HEIGHT_MM = 35.0                                 # the spot clicked on the tool, above the tip
SPREAD_POINTS = [(150, -150, 40), (150, 150, 60), (250, -100, 80), (250, 100, 40),
                 (200, 0, 100), (180, -60, 20), (230, 40, 30), (170, 60, 70)]   # all past MIN_RADIUS_MM (160)


class Sim:
    """A world with the robot, camera and the two-cubes-and-tray scenario."""

    def __init__(self, **robot_kwargs):
        self.config = load_config()
        self.world = TwinWorld()
        client = self.world.start()
        self.world.load_scenario("two_blocks_and_tray")
        robot_kwargs.setdefault("max_speed", 3000)   # fast: tests should not wait for the arm
        # the demo's own safety box, as the app's demo uses (config.yaml's are the real arm's)
        self.config["robot"]["workspace_bounds"] = demo_workspace_bounds()
        self.robot = SimRobot(client, self.config["robot"]["workspace_bounds"], world=self.world, **robot_kwargs)
        self.robot.connect()
        self.camera = SimCamera(client)
        self.camera.outline_bodies = self.robot.body_ids
        self.camera.connect()
        self.bounds = self.config["robot"]["workspace_bounds"]
        self.truth = {o["label"]: o["pos"] for o in self.world.snapshot()}
        self.heights = {o["label"]: o["size"][2] for o in self.world.snapshot()}

    def close(self) -> None:
        self.world.stop()

    # -- geometry -------------------------------------------------------------------------
    def exact_transform(self) -> np.ndarray:
        return self.camera.camera_to_robot_transform()

    def project(self, point_mm, transform: np.ndarray | None = None) -> tuple[float, float]:
        """Pixel of a robot-frame point, through the camera's true position by default."""
        t = self.exact_transform() if transform is None else transform
        k = self.camera.get_intrinsics()
        q = np.linalg.inv(t) @ np.array([*point_mm, 1.0])
        return k.fx * q[0] / q[2] + k.cx, k.fy * q[1] / q[2] + k.cy

    def move(self, x, y, z, r=0.0) -> None:
        self.robot.move_to(Pose(x=x, y=y, z=z, r=r))


@dataclass
class ManualRun:
    calibrator: BoardlessCalibrator
    result: SolveResult
    clicks_used: int


def calibrate_by_clicking(sim: Sim, rng: np.random.Generator, click_sigma_px: float = 0.0,
                          mis_clicks: int = 0, points=SPREAD_POINTS) -> ManualRun:
    """Emulate a person calibrating: jog to each point, click the middle of the tool body."""
    calibrator = BoardlessCalibrator(intrinsics=sim.camera.get_intrinsics())
    bad = set(rng.choice(len(points), size=mis_clicks, replace=False).tolist()) if mis_clicks else set()
    for index, (x, y, z) in enumerate(points):
        sim.move(x, y, z)
        for _ in range(5):   # a person would just click again if there was no depth there
            u, v = sim.project((x, y, z + CLICK_HEIGHT_MM))
            u, v = u + rng.normal(0, click_sigma_px), v + rng.normal(0, click_sigma_px)
            if index in bad:
                u, v = u + rng.choice([-1, 1]) * rng.uniform(25, 45), v + rng.choice([-1, 1]) * rng.uniform(25, 45)
            depth = foreground_depth(sim.camera.get_frame().depth, int(round(u)), int(round(v)))
            if depth > 0:
                pose = sim.robot.get_pose()
                calibrator.add_sample((pose.x, pose.y, pose.z), (int(round(u)), int(round(v))), depth)
                break
    return ManualRun(calibrator, calibrator.solve_detailed(), calibrator.num_samples())


def touch_table(sim: Sim, transform: np.ndarray, at=(170.0, 0.0)) -> tuple[np.ndarray, float]:
    # at=(170, 0): comfortably past MIN_RADIUS_MM (160) now that the robot itself refuses to
    # get closer to the base than that (see SimRobot._clamp_to_bounds), so this lands exactly
    # where asked instead of being pushed out and skewing the height correction.
    """Lower the tip onto the table and apply the height correction."""
    sim.move(at[0], at[1], 0.0)
    plane = measure_table(sim.camera, transform)
    if plane is None:
        raise RuntimeError("the camera found no table")
    z_touch = sim.robot.get_pose().z
    return apply_table_touch(transform, z_touch, plane.z_mm)


def cube_errors(sim: Sim, transform: np.ndarray) -> dict[str, tuple[float, float]]:
    """{cube: (error in the plane, error in height)} in mm, locating the cubes through `transform`."""
    sim.robot.move_to(LOOK_POSE)
    builder = SceneBuilder(sim.camera, build_detector(dict(sim.config["vision"], detector="color_blob")), transform)
    found = {o.label: o for o in builder.get_scene()}
    out = {}
    for label, true_pos in sim.truth.items():
        if label not in found:
            continue
        xyz = found[label].xyz_robot
        # the detector reports the top face: half the object's own height above its centre. (This was a fixed
        # 12.5, for 25 mm cubes; the scene's cubes are 20 mm, so every height read 2.5 mm low even through the
        # exact transform, and the off-centre-marker tests failed by a few tenths over their 3 mm limit.)
        out[label] = (math.hypot(xyz[0] - true_pos[0], xyz[1] - true_pos[1]),
                      xyz[2] - (true_pos[2] + sim.heights[label] / 2))
    return out

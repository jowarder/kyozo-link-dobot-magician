"""Camera setup (app/vision/camera_setup.py, app/ui/camera_setup_dialog.py): the readings against the simulator's
exact geometry, the targets and verdict, the picture settings (the real camera's code against a stand-in device),
and the window in the demo.

    python -m unittest discover -s tests -p test_camera_setup.py -v
"""
from __future__ import annotations

import json
import math
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: E402  (sets up sys.path and the working folder)
import numpy as np  # noqa: E402

from app.hardware.camera_controls import Control, clamp_to  # noqa: E402
from app.vision import camera_setup as cs  # noqa: E402

CUBES = (("red", [0.8, 0.1, 0.1, 1], 200, 60), ("green", [0.1, 0.7, 0.2, 1], 240, 0),
         ("blue", [0.1, 0.2, 0.8, 1], 200, -60))


class SimScene:
    """Three 25 mm cubes on the simulator's table, and its camera."""

    def __init__(self, test: unittest.TestCase):
        from app import robots
        from app.hardware.sim_camera import SimCamera
        from app.twin.world import TwinWorld
        robots.set_active("dobot_magician")
        self.world = TwinWorld()
        client = self.world.start()
        test.addCleanup(self.world.stop)
        self.world.load_scenario_data({"name": "setup", "places": {}, "objects": [
            {"id": f"{c}_cube", "label": f"{c} cube", "color_rgba": rgba, "size_mm": [25, 25, 25],
             "position_mm": [x, y, 12.5]} for c, rgba, x, y in CUBES]}, "setup")
        self.camera = SimCamera(client)
        self.camera.connect()

    def reading(self) -> cs.SetupReading:
        frame = self.camera.get_frame()
        return cs.measure(frame.rgb, frame.depth, frame.intrinsics, 25.0, warmup_min=99.0)


class ReadingTests(unittest.TestCase):
    def test_height_tilt_and_the_cubes_as_the_simulator_has_them(self):
        scene = SimScene(self)
        reading = scene.reading()
        to_robot = scene.camera.camera_to_robot_transform()
        height_mm = abs(to_robot[2, 3])                          # the camera above the table (z = 0)
        tilt = math.degrees(math.acos(abs(to_robot[2, 2])))       # its optical axis against straight down
        self.assertAlmostEqual(reading.height_cm * 10.0, height_mm, delta=5.0)
        self.assertAlmostEqual(reading.tilt_deg, tilt, delta=1.0)
        self.assertGreater(reading.table_confidence, 0.5)
        self.assertEqual(sorted(c.colour for c in reading.cubes), ["blue", "green", "red"])
        for cube in reading.cubes:
            self.assertAlmostEqual(min(cube.top_mm), 25.0, delta=1.5, msg=cube)
            self.assertAlmostEqual(cube.height_mm, 25.0, delta=1.5, msg=cube)
            self.assertGreater(cube.saturation, 150)
            self.assertGreater(cube.top_points, 200)

    def test_an_overexposed_picture_scores_worse_and_washes_the_colours_out(self):
        scene = SimScene(self)
        fine = cs.best_exposure_score(scene.reading())
        scene.camera.set_control("exposure_auto", False)
        scene.camera.set_control("exposure", 280)
        bright = scene.reading()
        self.assertGreater(max(c.clipped_pct for c in bright.cubes), 50.0)
        self.assertLess(cs.best_exposure_score(bright), fine)

    def test_the_shake_reading(self):
        n = np.array([0.0, 0.0, -1.0])
        self.assertIsNone(cs.shake_from([500.0, 500.1], [n, n], 500.0), "too few pictures to say")
        still = cs.shake_from([500.0, 500.1, 500.05], [n, n, n], 500.0)
        self.assertLessEqual(still, 0.2)
        turned = n.copy()
        turned[0] = math.sin(math.radians(0.1))
        turned /= np.linalg.norm(turned)
        self.assertGreater(cs.shake_from([500.0, 500.0, 500.0], [n, turned, n], 500.0), 0.7, "0.1 deg at 50 cm")

    def test_the_exposure_kept_has_room_for_the_light_to_change(self):
        # the lab, 2026-10-21, a blue cube on the black mat: (exposure, score, the cube's brightness) as Find best
        # exposure tried them. By score alone 24 was kept -- the cube's top at 98 of 255, under DARK_VALUE
        lab = [(11, -30.0, 44.0), (24, 184.0, 98.0), (52, 172.0, 161.0), (116, 148.0, 238.0), (256, -243.4, 255.0)]
        self.assertEqual(cs.pick_exposure(lab), 52)
        self.assertIsNone(cs.pick_exposure([(5, -142.3, 18.0), (2000, -1.0, None)]))
        # too dark, the noise reads as full colour: it doesn't score as the strongest
        dark = cs.SetupReading(cubes=[cs.CubeReading("blue", (560, 382), 30.0, 1180, (25.0, 25.0), 25.0, 255.0,
                                                     50.0, 0.0)])
        good = cs.SetupReading(cubes=[cs.CubeReading("blue", (560, 382), 30.0, 1200, (25.0, 25.0), 25.0, 170.0,
                                                     171.0, 0.0)])
        self.assertLess(cs.best_exposure_score(dark), cs.best_exposure_score(good))

    def test_the_arms_dark_parts_in_view_dont_turn_the_readings_red(self):
        # the lab, 2026-10-21: the gripper low in the picture read as a black and a grey "cube" beside the blue one
        blue = cs.CubeReading("blue", (560, 382), 40.0, 1164, (26.8, 27.7), 26.9, 179.0, 144.0, 0.0)
        arm = [cs.CubeReading("black", (594, 147), 12.0, 90, (3.3, 17.5), 38.2, 76.0, 33.0, 0.0),
               cs.CubeReading("grey", (600, 167), 20.0, 72, (8.6, 20.4), 23.1, 34.0, 61.0, 0.0)]
        values = cs.SetupReading(height_cm=45.6, cubes=[blue] + arm, image_size=(1280, 720)).values(25.0)
        for name in ("saturation", "top_points", "top_ratio", "cube_px"):
            self.assertNotEqual(cs.status_of(name, values[name]), cs.FAILS, f"{name}: {values[name]}")
        self.assertEqual(values["saturation"], 179.0)
        alone = cs.SetupReading(cubes=list(arm), image_size=(1280, 720)).values(25.0)
        self.assertEqual(alone["saturation"], 34.0, "nothing coloured seen: what is there is judged")


class TargetTests(unittest.TestCase):
    def test_statuses(self):
        self.assertEqual(cs.status_of("cube_px", 40.0), cs.MEETS)
        self.assertEqual(cs.status_of("cube_px", 31.0), cs.CLOSE)
        self.assertEqual(cs.status_of("cube_px", 27.0), cs.FAILS)       # the lab's failed calibration
        self.assertEqual(cs.status_of("saturation", 91.0), cs.FAILS)    # the lab's washed-out blue cube
        self.assertEqual(cs.status_of("top_points", None), cs.UNKNOWN)

    def test_the_verdict(self):
        every = {name: cs.MEETS for name in cs.TARGETS}
        self.assertEqual(cs.verdict(every), cs.MEETS_TARGETS)
        self.assertEqual(cs.verdict({**every, "tilt_deg": cs.FAILS}), cs.GOOD_ENOUGH, "advisory: doesn't block")
        self.assertEqual(cs.verdict({**every, "shake_mm": cs.UNKNOWN}), cs.GOOD_ENOUGH, "the shake test is optional")
        self.assertEqual(cs.verdict({**every, "cube_px": cs.CLOSE}), cs.GOOD_ENOUGH)
        self.assertEqual(cs.verdict({**every, "top_points": cs.FAILS}), cs.NOT_READY)
        self.assertEqual(cs.verdict({**every, "saturation": cs.UNKNOWN}), cs.NOT_READY, "no cube seen: not ready")

    def test_hints_say_what_to_do(self):
        self.assertIn("Lower the camera", cs.hint_for("height_cm", 58.0))
        self.assertIn("closer", cs.hint_for("cube_px", 27.0))
        self.assertIn("exposure", cs.hint_for("saturation", 91.0))
        self.assertEqual(cs.hint_for("height_cm", 45.0), "")


class FakeRange:
    def __init__(self, low, high, step=1, default=None):
        self.min, self.max, self.step, self.default_value = low, high, step, default if default is not None else low


class FakeDevice:
    """A camera that supports colour exposure (and its automatic), white balance and anti-flicker -- no projector
    power."""

    def __init__(self):
        self.values = {"OB_PROP_COLOR_AUTO_EXPOSURE_BOOL": True, "OB_PROP_COLOR_EXPOSURE_INT": 156,
                       "OB_PROP_COLOR_WHITE_BALANCE_INT": 4600, "OB_PROP_COLOR_POWER_LINE_FREQUENCY_INT": 1}
        self.ranges = {"OB_PROP_COLOR_EXPOSURE_INT": FakeRange(1, 10000, 1, 156),
                       "OB_PROP_COLOR_WHITE_BALANCE_INT": FakeRange(2800, 6500, 10, 4600),
                       "OB_PROP_COLOR_POWER_LINE_FREQUENCY_INT": FakeRange(0, 3, 1, 1)}

    @staticmethod
    def _name(prop):
        return getattr(prop, "name", str(prop)).split(".")[-1]

    def is_property_supported(self, prop, _permission):
        return self._name(prop) in self.values

    def get_bool_property(self, prop):
        return self.values[self._name(prop)]

    def get_int_property(self, prop):
        return self.values[self._name(prop)]

    def get_int_property_range(self, prop):
        return self.ranges[self._name(prop)]

    def set_bool_property(self, prop, value):
        self.values[self._name(prop)] = bool(value)

    def set_int_property(self, prop, value):
        self.values[self._name(prop)] = int(value)


class ControlTests(unittest.TestCase):
    def test_clamp(self):
        exposure = Control("exposure", "int", 100, low=1, high=300, step=1)
        self.assertEqual(clamp_to(exposure, 999), 300)
        self.assertEqual(clamp_to(exposure, -5), 1)
        flicker = Control("anti_flicker", "choice", 1, choices={0: "Off", 1: "50 Hz"})
        with self.assertRaises(ValueError):
            clamp_to(flicker, 2)

    def test_the_real_cameras_settings_against_a_stand_in_device(self):
        from app.hardware.camera import OrbbecCamera
        camera = OrbbecCamera()
        device = FakeDevice()
        camera._pipeline = SimpleNamespace(get_device=lambda: device)
        controls = camera.controls()
        self.assertEqual(set(controls), {"exposure_auto", "exposure", "white_balance", "anti_flicker"},
                         "only what this camera supports: no projector power, no gain")
        self.assertEqual(controls["exposure"].high, 10000)
        self.assertEqual(controls["anti_flicker"].choices, {0: "Off", 1: "50 Hz", 2: "60 Hz", 3: "Auto"})
        problems = camera.apply_controls({"exposure": 300, "exposure_auto": False, "projector_power": 5})
        self.assertEqual(device.values["OB_PROP_COLOR_AUTO_EXPOSURE_BOOL"], False)
        self.assertEqual(device.values["OB_PROP_COLOR_EXPOSURE_INT"], 300)
        self.assertEqual(len(problems), 1, "projector power isn't offered: said, not raised")
        self.assertEqual(camera.wanted_controls, {"exposure_auto": False, "exposure": 300},
                         "kept, to put back if the camera reopens")
        self.assertIn("Projector power: not supported", camera.capabilities())

    def test_automatic_white_balance_stays_on_as_the_real_camera_behaves(self):
        # the Gemini 335 (firmware 1.4.60, 2026-10-12): setting a white balance switches its automatic one off, even
        # when that was set on just before -- restoring {auto: on, 4600} left it manual
        from app.hardware.camera import OrbbecCamera

        class Gemini(FakeDevice):
            def __init__(self):
                super().__init__()
                self.values["OB_PROP_COLOR_AUTO_WHITE_BALANCE_BOOL"] = False
                self.values["OB_PROP_COLOR_WHITE_BALANCE_INT"] = 5000

            def set_int_property(self, prop, value):
                super().set_int_property(prop, value)
                name = self._name(prop)
                if name == "OB_PROP_COLOR_WHITE_BALANCE_INT":
                    self.values["OB_PROP_COLOR_AUTO_WHITE_BALANCE_BOOL"] = False
                if name == "OB_PROP_COLOR_EXPOSURE_INT":
                    self.values["OB_PROP_COLOR_AUTO_EXPOSURE_BOOL"] = False
        camera = OrbbecCamera()
        device = Gemini()
        camera._pipeline = SimpleNamespace(get_device=lambda: device)
        camera.apply_controls({"exposure_auto": True, "exposure": 156, "white_balance_auto": True,
                               "white_balance": 4600, "anti_flicker": 2})
        self.assertTrue(device.values["OB_PROP_COLOR_AUTO_WHITE_BALANCE_BOOL"])
        self.assertTrue(device.values["OB_PROP_COLOR_AUTO_EXPOSURE_BOOL"])
        self.assertEqual(device.values["OB_PROP_COLOR_POWER_LINE_FREQUENCY_INT"], 2)
        camera.apply_controls({"white_balance_auto": False, "white_balance": 4000})     # manual: as asked
        self.assertFalse(device.values["OB_PROP_COLOR_AUTO_WHITE_BALANCE_BOOL"])
        self.assertEqual(device.values["OB_PROP_COLOR_WHITE_BALANCE_INT"], 4000)

    def test_no_settings_call_while_another_thread_restarts_the_streams(self):
        import threading
        from app.hardware.camera import OrbbecCamera
        camera = OrbbecCamera()
        device = FakeDevice()
        camera._pipeline = SimpleNamespace(get_device=lambda: device)
        switcher = threading.Thread(target=lambda: None)
        camera._switch_thread, _ = switcher, camera._switching.set()
        self.assertEqual(camera.controls(), {}, "not read while the device may be closed and reopened")
        with self.assertRaisesRegex(RuntimeError, "being changed"):
            camera.set_control("exposure", 200)
        self.assertEqual(len(camera.apply_controls({"exposure": 200})), 1)
        self.assertEqual(device.values["OB_PROP_COLOR_EXPOSURE_INT"], 156, "untouched")
        camera._switch_thread = threading.current_thread()           # the switch itself puts the settings back
        self.assertEqual(camera._apply_controls({"exposure": 200}), [])
        self.assertEqual(device.values["OB_PROP_COLOR_EXPOSURE_INT"], 200)

    def test_the_simulated_camera_offers_the_same_settings(self):
        scene = SimScene(self)
        self.assertIn("exposure", scene.camera.controls())
        with self.assertRaises(ValueError):
            scene.camera.set_control("zoom", 2)
        self.assertEqual(scene.camera.set_control("exposure", 5000), 300)


class WindowTests(unittest.TestCase):
    """The Camera setup window in the demo: opened from the Calibration tab, looking, settings saved, reference,
    lock, session check, shake test."""

    @classmethod
    def setUpClass(cls):
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def pump(self, seconds, until):
        deadline = time.time() + seconds
        while time.time() < deadline and not until():
            self.app.processEvents()
            time.sleep(0.02)
        return until()

    def test_the_window_from_start_to_reference(self):
        from PyQt6.QtWidgets import QMessageBox
        from app.config import load_config
        from app.ui import main_window as main_window_module
        folder = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, folder, True)
        shutil.copy(ROOT / "config.yaml", Path(folder) / "config.yaml")
        config = load_config()
        config["mode"], config["display"] = "demo", {}
        config["llm"]["manage_memory"] = False
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
        said = []
        with mock.patch.object(main_window_module, "PROJECT_ROOT", Path(folder)), \
                mock.patch.object(QMessageBox, "warning", staticmethod(lambda *a, **k: said.append(a[2]))), \
                mock.patch.object(QMessageBox, "information", staticmethod(lambda *a, **k: said.append(a[2]))), \
                mock.patch.object(QMessageBox, "question",
                                  staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)):
            window = main_window_module.MainWindow(config)
            window._config_file = Path(folder) / "config.yaml"
            window.show()
            window.calibration_tab.camera_setup_btn.click()
            dialog = window._camera_setup
            self.assertTrue(self.pump(20, lambda: dialog.reading is not None and len(dialog._history) >= 2))
            self.assertTrue(dialog.reading.cubes, "the demo's cube seen")
            self.assertEqual(len(dialog.reading.cubes), dialog.expected_cubes, "every cube in the demo's world")
            self.assertEqual(dialog.statuses["top_ratio"], cs.MEETS, "measured against the demo cube's own size")
            self.assertTrue(self.pump(20, lambda: dialog.verdict_text in (cs.GOOD_ENOUGH, cs.MEETS_TARGETS)),
                            dialog.verdict_detail.text())
            # a washed-out picture, then the best exposure found
            dialog.camera.set_control("exposure_auto", False)
            dialog.camera.set_control("exposure", 280)
            best = dialog.find_best_exposure(settle_s=0.0)
            self.assertIsNotNone(best)
            self.assertLess(best, 200)
            dialog._best_done(best)
            saved = yaml_camera(window)["controls_demo"]
            self.assertEqual(saved["exposure"], best)
            self.assertFalse(saved["exposure_auto"])
            # the shake test: the arm up 3 cm and back, the simulated camera doesn't move
            before = window.robot.get_pose()
            shake = dialog.run_shake_test()
            self.assertLessEqual(shake, 0.3)
            self.assertAlmostEqual(window.robot.get_pose().z, before.z, delta=0.5)
            # the reference, the lock, the session check
            dialog._save_reference()
            reference = json.loads((Path(folder) / "camera_setup_demo" / "reference.json").read_text(encoding="utf-8"))
            self.assertEqual(reference["controls"]["exposure"], best)
            self.assertEqual(reference["targets_version"], cs.TARGETS_VERSION)
            live_lock = yaml_camera(window).get("setup_locked")
            dialog._toggle_lock()
            self.assertTrue(yaml_camera(window)["setup_locked_demo"])
            self.assertEqual(yaml_camera(window).get("setup_locked"), live_lock, "the lab camera's lock untouched")
            self.assertFalse(dialog.control_widgets["exposure"][0].isEnabled(), "locked: no changes")
            dialog._set_control("exposure", 50)
            self.assertEqual(dialog.camera.controls()["exposure"].value, best, "locked: not changed")
            dialog.mode_group.button(1).click()

            def session_check():
                dialog._on_look(dialog._look(True))
                return dialog.verdict_detail.text()
            text = session_check()
            self.assertIn("hasn't moved", text)
            self.assertIn("the picture matches", text)
            self.assertIn("Settings as saved", text)
            # slid along the table: the table looks the same, the picture doesn't
            dialog.camera.bump(shift_mm=(0.0, 15.0, 0.0), yaw_deg=0.0, pitch_deg=0.0)
            text = session_check()
            self.assertIn("the camera moved", text)
            self.assertIn("slid", text)
            dialog.camera.unbump()
            # the depth preset changed since the reference
            dialog.camera.switch_depth_preset("High Accuracy")
            self.assertIn("depth preset (Default then, High Accuracy now)", session_check())
            dialog.camera.switch_depth_preset("Default")
            # the main window's own depth preset box asks past the lock, and logs it
            window._on_depth_preset("High Accuracy")
            self.pump(10, lambda: window._preset_worker is None)
            log = (Path(folder) / "camera_setup_demo" / "changes.log").read_text(encoding="utf-8")
            self.assertIn("changed while locked (from the main window)", log)
            window._on_depth_preset("Default")
            self.pump(10, lambda: window._preset_worker is None)
            dialog.close()
            window.jog_panel.stop_pose_monitor()
            window.close()


class CompareTests(unittest.TestCase):
    """Comparing two settings over many looks: the measures, the tie rule, and the demo camera that has something to
    compare (High Accuracy losing the cubes' edges, as the lab's camera did)."""

    def test_the_tie_rule(self):
        steady = {"seen": 3, "missed_pct": 0.0, "centre_jitter_mm": 0.2, "top_off_pct": 1.0, "angle_jitter_deg": 0.5}
        shaky = {"seen": 3, "missed_pct": 5.0, "centre_jitter_mm": 0.9, "top_off_pct": 22.0, "angle_jitter_deg": 2.4}
        winner, why, tie = cs.choose({"Default": steady, "High Accuracy": shaky}, "High Accuracy", cs.PRESET_TIES)
        self.assertEqual((winner, tie), ("Default", False))
        self.assertIn("steadier", why)
        close = dict(steady, centre_jitter_mm=0.25, top_off_pct=3.0)
        winner, why, tie = cs.choose({"Default": steady, "High Accuracy": close}, "High Accuracy", cs.PRESET_TIES)
        self.assertEqual((winner, tie), ("High Accuracy", True), "within the noise: the current one stays")
        blind = {"seen": 0}
        self.assertEqual(cs.choose({"Default": steady, "High Accuracy": blind}, "High Accuracy",
                                   cs.PRESET_TIES)[0], "Default", "one that saw nothing loses")
        # one that loses a cube can't win by having less jitter to add up
        fewer = dict(steady, seen=2, centre_jitter_mm=0.05)
        winner, why, _ = cs.choose({"Default": shaky, "High Accuracy": fewer}, "High Accuracy", cs.PRESET_TIES,
                                   by_seen=True)
        self.assertEqual(winner, "Default", why)
        self.assertIn("only 2", why)
        # a difference no bigger than the change between one preset's own blocks of looks is a tie
        winner, _, tie = cs.choose({"Default": steady, "High Accuracy": shaky}, "High Accuracy", cs.PRESET_TIES,
                                   noise={"missed_pct": 20.0, "centre_jitter_mm": 1.0, "top_off_pct": 30.0,
                                          "angle_jitter_deg": 3.0})
        self.assertEqual((winner, tie), ("High Accuracy", True))
        self.assertEqual(cs.block_noise({"A": [{"missed_pct": 0.0}, {"missed_pct": 15.0}]},
                                        (("missed_pct", 10.0),)), {"missed_pct": 15.0})

    def test_a_detector_that_misses_the_pale_cube_loses(self):
        truth = {"red": (200.0, 60.0), "blue": (200.0, -60.0)}
        depth = [[("red", 200.1, 60.0, 10.0), ("blue", 200.0, -60.2, 3.0)] for _ in range(10)]
        colour = [[("red", 202.0, 61.0, None)] for _ in range(10)]
        results = {"Any object": cs.detection_summary(depth, ["red", "blue"], truth),
                   "Coloured cubes": cs.detection_summary(colour, ["red", "blue"], truth)}
        self.assertEqual(results["Coloured cubes"]["missed_pct"], 100.0)
        self.assertFalse(results["Coloured cubes"]["angle_given"])
        self.assertEqual(cs.choose(results, "Coloured cubes", cs.DETECTION_TIES)[0], "Any object")

    def test_the_demo_camera_has_the_labs_trouble(self):
        scene = SimScene(self)
        mounted = scene.reading().values(25.0)
        self.assertGreater(mounted["tilt_deg"], 45.0)
        scene.camera.switch_depth_preset("High Accuracy")
        high = scene.reading().values(25.0)
        self.assertLess(high["top_ratio"], 85.0, "the cubes' edges lost, as the lab's camera did")
        scene.camera.switch_depth_preset("Default")
        scene.camera.washed_out = True
        self.assertLess(scene.reading().values(25.0)["saturation"], 100.0, "washed out, as over the lab's black mat")
        scene.camera.set_control("exposure_auto", False)
        self.assertGreater(scene.reading().values(25.0)["saturation"], 150.0, "a manual exposure fixes it")
        scene.camera.washed_out = False
        scene.camera.place(up_mm=120.0, back_mm=150.0)          # as on a mount: higher, further back
        far = scene.reading().values(25.0)
        self.assertLess(far["cube_px"], mounted["cube_px"] * 0.85)
        self.assertGreater(far["height_cm"], mounted["height_cm"] + 10.0)
        before = scene.camera.camera_to_robot_transform()
        scene.camera.place()
        self.assertGreater(abs(before[2, 3] - scene.camera.camera_to_robot_transform()[2, 3]), 50.0,
                           "the exact calibration follows the camera")
        scene.camera.place(tilt_deg=20.0)                         # tilted on the mount: more straight down
        self.assertLess(scene.reading().tilt_deg, mounted["tilt_deg"] - 15.0)


class AimTests(unittest.TestCase):
    """Mount mode's hints: where to point the camera, from where the cubes sit in the picture."""

    @staticmethod
    def reading(cubes, size=(1280, 720)):
        return cs.SetupReading(image_size=size, cubes=[
            cs.CubeReading(colour=c, pixel=(u, v), px=40.0, top_points=200, top_mm=(25.0, 25.0), height_mm=25.0,
                           saturation=200.0, value=180.0, clipped_pct=0.0) for c, u, v in cubes])

    def test_the_level_check_goes_by_the_red_and_blue_cubes_whatever_else_is_out(self):
        slanted = self.reading([("red", 400, 300), ("blue", 900, 500), ("green", 100, 650)])
        self.assertIn("runs diagonally across the picture (22°)", " ".join(cs.aim_hints(slanted)))
        level = self.reading([("red", 400, 330), ("blue", 900, 380), ("green", 100, 650)])
        self.assertNotIn("diagonally", " ".join(cs.aim_hints(level)),
                         "a slight slant is a camera looking from the side; the green cube out at the side doesn't count")
        no_pair = self.reading([("green", 400, 330), ("green", 900, 380)])
        self.assertIn("put the red and the blue cube", " ".join(cs.aim_hints(no_pair)))

    def test_aiming_at_the_cubes_and_the_edge(self):
        right = self.reading([("red", 1000, 360), ("blue", 1240, 362)])     # (40 px from the edge: 6%)
        hints = " ".join(cs.aim_hints(right))
        self.assertIn("turn the camera a little to the right", hints)
        self.assertIn("near the picture's edge", hints)
        self.assertLess(right.edge_margin_pct(), 20.0)
        centred = self.reading([("red", 560, 360), ("blue", 720, 361)])
        self.assertIn("Aimed well", " ".join(cs.aim_hints(centred)))


class PracticeTests(WindowTests):
    """The demo practice, start to end: like the lab, fixed step by step; the demo's depth preset kept apart from the
    real camera's."""

    def test_the_window_from_start_to_reference(self):      # (run once, in the parent class)
        pass

    def test_practising_like_the_lab(self):
        from PyQt6.QtWidgets import QMessageBox
        from app.config import load_config
        from app.ui import main_window as main_window_module
        folder = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, folder, True)
        shutil.copy(ROOT / "config.yaml", Path(folder) / "config.yaml")
        config = load_config()
        config["mode"], config["display"] = "demo", {}
        config["llm"]["manage_memory"] = False
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
        live_preset = config["camera"].get("depth_preset")
        with mock.patch.object(main_window_module, "PROJECT_ROOT", Path(folder)), \
                mock.patch.object(QMessageBox, "warning", staticmethod(lambda *a, **k: None)), \
                mock.patch.object(QMessageBox, "information", staticmethod(lambda *a, **k: None)), \
                mock.patch.object(QMessageBox, "question",
                                  staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)):
            window = main_window_module.MainWindow(config)
            window._config_file = Path(folder) / "config.yaml"
            window.show()
            window.calibration_tab.camera_setup_btn.click()
            dialog = window._camera_setup
            self.assertEqual(dialog.tabs.tabText(0), "Demo camera")

            def settle():
                dialog._reset_steadiness()
                self.pump(20, lambda: len(dialog._history) >= 4 and not dialog.settling)

            dialog.practice_like_the_lab()
            settle()
            self.assertEqual(dialog.verdict_text, cs.NOT_READY)
            for failing in ("Cube size", "Saturation", "Cube top read"):
                self.assertIn(failing, dialog.verdict_detail.text())
            dialog.move_demo_camera(0.0, -10.0, 20.0)            # forward 10 cm, tilted down 20 degrees
            best = dialog.find_best_exposure(settle_s=0.0)
            dialog._best_done(best)
            window.camera.preset_trouble = "refuse"
            with self.assertRaisesRegex(RuntimeError, "wouldn't switch"):
                dialog.compare_presets(looks=4, settle_s=0.0)
            window.camera.preset_trouble = None
            result = dialog.compare_presets(looks=4, settle_s=0.0)
            self.assertEqual((result["winner"], result["tie"]), ("Default", False), result["why"])
            self.assertEqual(result["order"], ["High Accuracy", "Default", "Default", "High Accuracy"],
                             "interleaved: A B B A")
            dialog._compared("depth_preset", result)
            dialog._use_preset()
            self.pump(10, lambda: window._preset_worker is None and dialog._awaiting is None)
            self.assertEqual(window._current_preset(), "Default")
            settle()
            self.assertIn(dialog.verdict_text, (cs.GOOD_ENOUGH, cs.MEETS_TARGETS), dialog.verdict_detail.text())
            self.assertIn("depth preset set to Default",
                          (Path(folder) / "camera_setup_demo" / "changes.log").read_text(encoding="utf-8"))
            # Mount mode: big readings, what to do, a beep once placed right
            from PyQt6.QtWidgets import QApplication
            beeps = []
            with mock.patch.object(QApplication, "beep", staticmethod(lambda: beeps.append(1))):
                dialog.open_mount_mode()
                dialog.move_demo_camera(0.0, -20.0, 20.0)
                self.pump(20, lambda: dialog.mount_view.was_right)
                self.assertTrue(dialog.mount_view.was_right, dialog.mount_view.aim.text())
                self.assertIn("placed right", dialog.mount_view.headline.text())
                self.assertEqual(len(beeps), 1)
                self.assertIsNotNone(dialog.best_seen["height_cm"])
                dialog.mount_view.close()
            dialog._exact_calibration()
            detection = dialog.compare_detection(looks=4)
            self.assertEqual(detection["results"]["Any object"]["missed_pct"], 0.0)
            dialog._compared("detection", detection)
            states = dialog.step_states()
            for step in ("Position", "Picture", "Depth preset", "Calibrate", "Detection"):
                self.assertTrue(states[step], step)
            saved = yaml_camera(window)
            self.assertEqual(saved.get("depth_preset"), live_preset, "the lab camera's preset untouched by the demo")
            self.assertEqual(saved.get("depth_preset_demo"), "Default")
            dialog.close()
            window.jog_panel.stop_pose_monitor()
            window.close()


def synthetic(cubes=(), size=(320, 240), table_mm=450.0, f=300.0):
    """A flat table straight below the camera and cubes on it: each (u, v, turn in degrees, (r, g, b), its top's side
    in mm, its height in mm). (rgb, depth, intrinsics)."""
    import cv2
    w, h = size
    depth = np.full((h, w), table_mm, np.float32)
    rgb = np.full((h, w, 3), 60, np.uint8)
    for u, v, turn, colour, side_mm, tall_mm in cubes:
        side_px = side_mm * f / (table_mm - tall_mm)
        corners = cv2.boxPoints(((u, v), (side_px, side_px), turn)).astype(np.int32)
        mask = np.zeros((h, w), np.uint8)
        cv2.fillConvexPoly(mask, corners, 1)
        depth[mask > 0] = table_mm - tall_mm
        rgb[mask > 0] = colour
    return rgb, depth, SimpleNamespace(fx=f, fy=f, cx=w / 2.0, cy=h / 2.0)


RED, BLUE = (200, 30, 30), (30, 40, 200)


class FakeCamera:
    """A camera with an exposure (automatic or manual) and gain, looking at `cubes` (see synthetic)."""

    def __init__(self, cubes=()):
        self.cubes = list(cubes)
        self.values = {"exposure_auto": True, "exposure": 100, "gain": 0}
        self.depth_preset = "Default"
        self.broken_after: int | None = None     # pictures before it fails
        self.pictures = 0

    def controls(self):
        v = self.values
        return {"exposure_auto": Control("exposure_auto", "bool", v["exposure_auto"]),
                "exposure": Control("exposure", "int", v["exposure"], low=1, high=300, step=1, default=100),
                "gain": Control("gain", "int", v["gain"], low=0, high=100, step=1, default=0)}

    def set_control(self, name, value):
        self.values[name] = clamp_to(self.controls()[name], value)
        return self.values[name]

    def apply_controls(self, values):
        for name in sorted(values, key=lambda n: 0 if n.endswith("_auto") else 1):
            self.set_control(name, values[name])
        return []

    def get_frame(self):
        self.pictures += 1
        if self.broken_after is not None and self.pictures > self.broken_after:
            raise TimeoutError("No synced color+depth frame")
        rgb, depth, intrinsics = synthetic(self.cubes)
        return SimpleNamespace(rgb=rgb, depth=depth, intrinsics=intrinsics)

    def describe(self):
        return {"name": "stand-in camera"}


class FakeArm:
    """An arm that may stop short of where it's sent (`rise_limit`: as a safety box would, without saying) or take
    `slow_s` over each move."""

    def __init__(self, rise_limit=None, slow_s=0.0):
        from app.hardware.interfaces import Pose
        self.pose = Pose(200.0, 0.0, 50.0, 0.0)
        self.rise_limit, self.slow_s, self.moves = rise_limit, slow_s, []
        self.bounds = {"x": [100, 300], "y": [-200, 200], "z": [-60, 150]}

    def get_pose(self):
        return self.pose

    def move_to(self, pose):
        from app.hardware.interfaces import Pose
        self.moves.append(pose)
        time.sleep(self.slow_s)
        z = pose.z if self.rise_limit is None else min(pose.z, self.rise_limit)
        self.pose = Pose(pose.x, pose.y, z, pose.r)


class FindTests(unittest.TestCase):
    """The cubes' readings: a turned cube's true corners, a cube the depth sees badly said rather than dropped."""

    def test_a_turned_cube_is_outlined_as_it_is_turned(self):
        rgb, depth, k = synthetic([(160, 120, 30.0, RED, 25.0, 25.0)])
        reading = cs.measure(rgb, depth, k, 25.0)
        self.assertEqual(len(reading.cubes), 1)
        a, b = reading.cubes[0].outline[:2]
        edge = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) % 90.0
        self.assertAlmostEqual(min(edge, 90.0 - edge), 30.0, delta=4.0, msg=reading.cubes[0].outline)

    def test_a_cube_seen_badly_is_said_and_keeps_the_setup_not_ready(self):
        rgb, depth, k = synthetic([(90, 120, 0.0, RED, 25.0, 25.0), (230, 120, 0.0, BLUE, 9.0, 25.0)])
        reading = cs.measure(rgb, depth, k, 25.0)
        self.assertEqual([c.colour for c in reading.cubes], ["red"], "the blue one's top reads 9 mm: not taken")
        self.assertEqual(len(reading.rejects), 1)
        self.assertIn("top read", reading.rejects[0]["why"])
        every = {name: cs.MEETS for name in cs.TARGETS}
        self.assertEqual(cs.verdict(every, missing=1), cs.NOT_READY, "a cube on the table not seen")
        self.assertEqual(cs.verdict(every), cs.MEETS_TARGETS)

    def test_the_session_check_sees_a_turn_that_keeps_the_tilt(self):
        reference = {"height_cm": 45.0, "tilt_deg": 25.0}
        tilt = math.radians(25.0)
        before = (0.0, math.sin(tilt), -math.cos(tilt))
        after = (math.sin(tilt) * math.sin(math.radians(2.0)), math.sin(tilt) * math.cos(math.radians(2.0)),
                 -math.cos(tilt))                      # turned 2 degrees about straight down: same tilt
        reading = cs.SetupReading(height_cm=45.0, tilt_deg=25.0, plane_normal=after)
        shift = cs.plane_shift(reference, reading, before)
        self.assertEqual(shift["tilt_deg"], 0.0)
        self.assertGreater(shift["turned_deg"], 0.5)


class ShakeTests(unittest.TestCase):
    """The shake test never reports a result it can't stand behind: a lift cut short, an arm still moving."""

    def test_a_still_camera(self):
        from app.ui.camera_setup_dialog import shake_test
        arm = FakeArm(slow_s=0.05)
        result = shake_test(arm, FakeCamera(), timeout_s=5.0)
        self.assertLessEqual(result["shake_mm"], 0.1)
        self.assertEqual([round(p.z) for p in arm.moves], [80, 50], "3 cm up, and back")

    def test_a_lift_cut_short_by_the_safety_box(self):
        from app.ui.camera_setup_dialog import shake_test
        with self.assertRaisesRegex(RuntimeError, "didn't rise 3 cm"):
            shake_test(FakeArm(rise_limit=55.0), FakeCamera(), timeout_s=5.0)
        arm = FakeArm()
        arm.pose = arm.pose.__class__(200.0, 0.0, 140.0, 0.0)
        with self.assertRaisesRegex(RuntimeError, "too high"):
            shake_test(arm, FakeCamera(), timeout_s=5.0)
        self.assertEqual(arm.moves, [], "not even started")

    def test_an_arm_still_moving_gives_no_result(self):
        from app.ui.camera_setup_dialog import shake_test
        with self.assertRaises(TimeoutError):
            shake_test(FakeArm(slow_s=2.0), FakeCamera(), timeout_s=0.5)


class DialogTests(WindowTests):
    """The window on its own, with a stand-in camera and app: one action at a time (the app held, no closing), the
    steadiness rule, a refused preset switch, the exposure put back, sliders by keys, every setting saved."""

    def test_the_window_from_start_to_reference(self):      # (run once, in the parent class)
        pass

    def make(self, camera=None, hooks=None, robot=None, expected=0):
        from PyQt6.QtWidgets import QWidget
        from app.ui.camera_setup_dialog import CameraSetupDialog
        folder = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, folder, True)
        config = {"camera": {}}

        def save_value(path, value):
            config[path[0]][path[1]] = value
        dialog = CameraSetupDialog(camera or FakeCamera(), QWidget, config, save_value, "controls",
                                   folder / "calibration.json", folder / "setup", False, robot=robot, hooks=hooks,
                                   expected_cubes=expected)
        dialog.show()

        def close():
            try:
                dialog._action = None
                dialog.close()
            except RuntimeError:          # (already deleted)
                pass
        self.addCleanup(close)
        self.pump(5, lambda: dialog.reading is not None)
        dialog._timer.stop()
        if dialog._tick_worker is not None:
            dialog._tick_worker.wait(5000)
        self.app.processEvents()
        return dialog, config, folder

    @staticmethod
    def good_reading():
        return cs.SetupReading(height_cm=45.0, tilt_deg=25.0, table_confidence=0.9, noise_mm=0.3, warmup_min=99.0,
                               image_size=(1280, 720), cubes=[cs.CubeReading(
                                   colour="red", pixel=(640.0, 360.0), px=40.0, top_points=200, top_mm=(25.0, 25.0),
                                   height_mm=25.0, saturation=200.0, value=180.0, clipped_pct=0.0,
                                   outline=[(620, 340), (660, 340), (660, 380), (620, 380)])])

    def test_only_the_essentials_until_show_advanced(self):
        from app.ui.camera_setup_dialog import ADVANCED_CONTROLS, ADVANCED_READINGS
        dialog, config, _ = self.make()
        self.assertFalse(dialog.advanced_switch.isChecked())
        for button in (dialog.caps_btn, dialog.shake_btn, dialog.mount_btn):
            self.assertTrue(button.isHidden())
        for button in (dialog.best_btn, dialog.save_btn, dialog.start_btn, dialog.lock_btn):
            self.assertFalse(button.isHidden())
        self.assertTrue(all(w.isHidden() for n in ADVANCED_READINGS for w in dialog.reading_widgets[n]))
        self.assertFalse(dialog.reading_widgets["cube_px"][0].isHidden())
        hidden = [n for n in ADVANCED_CONTROLS if n in dialog.control_rows]
        self.assertTrue(hidden and all(w.isHidden() for n in hidden for w in dialog.control_rows[n]))
        if "exposure" in dialog.control_rows:
            self.assertFalse(dialog.control_rows["exposure"][0].isHidden())
        self.assertFalse(dialog.tabs.isTabVisible(dialog.tabs.indexOf(dialog.preset_panel)))
        dialog.advanced_switch.setChecked(True)                      # everything, and remembered
        self.assertFalse(dialog.caps_btn.isHidden())
        self.assertTrue(dialog.tabs.isTabVisible(dialog.tabs.indexOf(dialog.detection_panel)))
        self.assertFalse(any(w.isHidden() for n in ADVANCED_READINGS for w in dialog.reading_widgets[n]))
        self.assertTrue(config["camera"]["setup_advanced"])

    def test_a_reading_counts_once_it_has_held_for_five_seconds(self):
        import copy
        from app.ui.camera_setup_dialog import SETTLING
        dialog, _, _ = self.make(expected=1)
        dialog._reset_steadiness()
        dialog.apply_reading(self.good_reading(), now=100.0)
        self.assertEqual(dialog.verdict_text, SETTLING, "one reading decides nothing")
        self.assertFalse(dialog.start_btn.isEnabled())
        t = 100.0
        while t < 105.5:
            t += 0.7
            dialog.apply_reading(copy.deepcopy(self.good_reading()), now=t)
        self.assertIn(dialog.verdict_text, (cs.GOOD_ENOUGH, cs.MEETS_TARGETS))
        dialog.apply_reading(self.good_reading(), now=t + 40.0)           # (paused meanwhile: a comparison)
        self.assertEqual(dialog.verdict_text, SETTLING, "after a pause, steady starts again")
        two = self.good_reading()
        dialog.expected_cubes = 2
        dialog.apply_reading(two, now=t + 40.7)
        self.assertEqual(dialog.verdict_text, cs.NOT_READY)
        self.assertIn("Only 1 of the 2 cubes", dialog.verdict_detail.text())

    def test_one_action_at_a_time_holds_the_app_and_the_window(self):
        from PyQt6.QtWidgets import QMessageBox
        held = []
        hooks = SimpleNamespace(hold=held.append, presets=("Default", "High Accuracy"), current_preset=lambda: "Default",
                                preset_refused=lambda: None, is_calibrated=lambda: False,
                                current_detection=lambda: "any", calibration_preset=lambda: None)
        dialog, _, _ = self.make(hooks=hooks)
        said = []
        with mock.patch.object(QMessageBox, "information", staticmethod(lambda *a, **k: said.append(a[2]))):
            self.assertTrue(dialog._start_action("testing", time.sleep, (0.8,), lambda r: None, lambda m: None))
            self.assertEqual(held, ["Camera setup is testing"])
            self.assertFalse(dialog.save_btn.isEnabled())
            self.assertFalse(dialog.tabs.isEnabled())
            self.assertFalse(dialog.preset_panel.run_btn.isEnabled())
            self.assertFalse(dialog._start_action("another", time.sleep, (0.1,), lambda r: None, lambda m: None))
            dialog.close()
            self.assertTrue(dialog.isVisible(), "can't be closed while it runs")
            self.assertIn("still running", said[-1])
            self.assertTrue(self.pump(5, lambda: dialog._action is None))
        self.assertEqual(held, ["Camera setup is testing", None])
        self.assertTrue(dialog.save_btn.isEnabled())
        self.assertTrue(dialog.tabs.isEnabled())

    def test_esc_while_an_action_runs_doesnt_close_the_window(self):
        # (a review found: Esc -- QDialog's reject, which closes without a closeEvent -- closed the window under a
        # running sweep: its worker was left with deleted widgets, what it found was lost)
        from PyQt6.QtCore import Qt
        from PyQt6.QtTest import QTest
        from PyQt6.QtWidgets import QMessageBox
        hooks = SimpleNamespace(hold=lambda what: None, presets=("Default",), current_preset=lambda: "Default",
                                preset_refused=lambda: None, is_calibrated=lambda: False,
                                current_detection=lambda: "any", calibration_preset=lambda: None)
        dialog, _, _ = self.make(hooks=hooks)
        said = []
        with mock.patch.object(QMessageBox, "information", staticmethod(lambda *a, **k: said.append(a[2]))):
            self.assertTrue(dialog._start_action("testing", time.sleep, (0.8,), lambda r: None, lambda m: None))
            QTest.keyClick(dialog, Qt.Key.Key_Escape)
            self.assertTrue(dialog.isVisible(), "Esc doesn't close it while it runs")
            self.assertIn("still running", said[-1])
            self.assertTrue(self.pump(5, lambda: dialog._action is None))
        QTest.keyClick(dialog, Qt.Key.Key_Escape)          # once it has ended: closed, as by its close button
        self.assertFalse(dialog.isVisible())

    def test_the_pictures_settings_wait_while_the_app_uses_the_camera(self):
        # (a review found: the exposure sweep and the sliders changed the camera under a running calibration step;
        # only the depth preset was refused then)
        from PyQt6.QtWidgets import QMessageBox
        camera = FakeCamera()
        busy = {"why": "A calibration step is running: wait for it to finish, then try again."}
        hooks = SimpleNamespace(hold=lambda what: None, presets=("Default",), current_preset=lambda: "Default",
                                preset_refused=lambda: busy["why"], is_calibrated=lambda: False,
                                current_detection=lambda: "any", calibration_preset=lambda: None)
        dialog, config, _ = self.make(camera=camera, hooks=hooks)
        before = dict(camera.values)
        said = []
        with mock.patch.object(QMessageBox, "information", staticmethod(lambda *a, **k: said.append(a[2]))):
            dialog._set_control("exposure_auto", False)
            self.assertEqual(camera.values, before)
            self.assertIn("A calibration step is running", said[-1])
            dialog._find_best_exposure()
            self.assertIsNone(dialog._action, "no sweep started")
            self.assertEqual(len(said), 2)
        self.assertNotIn("controls", config["camera"])
        busy["why"] = None
        dialog._set_control("exposure_auto", False)
        self.assertFalse(camera.values["exposure_auto"])

    def test_the_shake_test_waits_while_the_arm_is_busy(self):
        from PyQt6.QtWidgets import QMessageBox
        arm = FakeArm()
        hooks = SimpleNamespace(arm_refused=lambda: "A prompt is running.", presets=("Default",),
                                current_preset=lambda: "Default", preset_refused=lambda: None,
                                is_calibrated=lambda: False, current_detection=lambda: "any",
                                calibration_preset=lambda: None)
        dialog, _, _ = self.make(hooks=hooks, robot=arm)
        said = []
        with mock.patch.object(QMessageBox, "information", staticmethod(lambda *a, **k: said.append(a[2]))):
            dialog._shake_test()
        self.assertIn("Not now: A prompt is running.", said[-1])
        self.assertEqual(arm.moves, [])
        self.assertIsNone(dialog._action)

    def test_a_preset_the_camera_wont_take(self):
        from PyQt6.QtWidgets import QMessageBox
        camera = FakeCamera([(160, 120, 0.0, RED, 25.0, 25.0)])
        hooks = SimpleNamespace(presets=("Default", "High Accuracy"), current_preset=lambda: camera.depth_preset,
                                switch_preset=lambda name: f"The camera wouldn't take the {name} preset.",
                                preset_refused=lambda: None, apply_preset=lambda name: None,
                                preset_switching=lambda: False, is_calibrated=lambda: False,
                                current_detection=lambda: "any", calibration_preset=lambda: None)
        dialog, _, folder = self.make(camera=camera, hooks=hooks)
        with self.assertRaisesRegex(RuntimeError, "wouldn't switch to the High Accuracy preset"):
            dialog.compare_presets(looks=4, settle_s=0.0)
        # "Use" a preset it won't take: logged as not changed, not as done
        dialog.comparisons["depth_preset"] = {"winner": "High Accuracy", "why": "test", "tie": False}
        warned = []
        with mock.patch.object(QMessageBox, "warning", staticmethod(lambda *a, **k: warned.append(a[2]))):
            dialog._use_preset()
            self.assertTrue(self.pump(3, lambda: dialog._awaiting is None))
        self.assertIn("didn't change to High Accuracy", warned[-1])
        log = (folder / "setup" / "changes.log").read_text(encoding="utf-8")
        self.assertIn("NOT changed to High Accuracy", log)
        self.assertNotIn("depth preset set to", log)

    def test_the_exposure_is_put_back_when_the_sweep_finds_nothing(self):
        camera = FakeCamera()                                        # no cube on the table
        dialog, _, _ = self.make(camera=camera)
        self.assertIsNone(dialog.find_best_exposure(settle_s=0.0, settle_frames=0))
        self.assertEqual(camera.values, {"exposure_auto": True, "exposure": 100, "gain": 0})
        camera.cubes = [(160, 120, 0.0, RED, 25.0, 25.0)]
        camera.broken_after = camera.pictures + 2                    # the camera fails half-way through
        with self.assertRaises(TimeoutError):
            dialog.find_best_exposure(settle_s=0.0, settle_frames=0)
        self.assertTrue(camera.values["exposure_auto"], "automatic again, as it was")

    def test_a_slider_moved_by_keys_is_set_and_every_setting_saved(self):
        camera = FakeCamera()
        dialog, config, _ = self.make(camera=camera)
        dialog._set_control("exposure_auto", False)
        dialog._sync_controls_from_camera()
        self.assertEqual(config["camera"]["controls"], {"exposure_auto": False, "exposure": 100, "gain": 0},
                         "the manual exposure and gain kept too, not only the setting touched")
        slider = dialog.control_widgets["exposure"][0]
        slider.setValue(150)                         # (as the arrow keys, the wheel or a click on the track do)
        self.assertTrue(self.pump(3, lambda: camera.values["exposure"] == 150))
        self.assertEqual(config["camera"]["controls"]["exposure"], 150)
        dialog._set_control("exposure_auto", True)
        self.assertEqual(config["camera"]["controls"], {"exposure_auto": True},
                         "automatic: the camera picks the exposure and gain itself")


def yaml_camera(window) -> dict:
    import yaml
    return yaml.safe_load(window._config_file.read_text(encoding="utf-8"))["camera"]


if __name__ == "__main__":
    unittest.main()

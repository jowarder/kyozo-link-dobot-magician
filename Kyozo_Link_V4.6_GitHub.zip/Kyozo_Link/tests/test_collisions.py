"""Nothing goes through anything in the demo: the gripper (as the 3D view draws it) and what it carries stop where
they meet an object, a tray or the table, as the real arm would press on it.

    python -m unittest discover -s tests -p test_collisions.py -v

Demo mode only; nothing in the project changes.
"""
from __future__ import annotations

import math
import unittest

import numpy as np

from harness import Sim

from app.hardware.gripper import GripperSpec, tool_parts
from app.hardware.interfaces import Pose
from app.hardware.sim_robot import Collision
from app.twin import kinematics, magician_model
from app.twin.world import TRAY_FLOOR_MM, TRAY_WALL_MM

SPEC = GripperSpec()
RED = (220.0, -60.0)          # two_blocks_and_tray: the red cube; the blue one at (220, 60); the tray at (280, 0)
CUBE = 20.0                   # the demo's cubes


def drawn_tool_points(robot) -> np.ndarray:
    """Points over the gripper as the 3D view draws it (the real Magician gripper's model), jaws as they are."""
    pose = robot.get_pose()
    held = robot.held_object
    width = min(robot.world.object_meta[held]["size"][:2]) if held else robot.jaw_stop_mm
    triangles, _, tool = magician_model.posed_triangles(kinematics.arm_geometry(pose.x, pose.y, pose.z), pose.r,
                                                        magician_model.jaw_opening(robot._gripper_closed, width))
    triangles = triangles[tool]
    edges = [triangles[:, a] + (triangles[:, b] - triangles[:, a]) * t
             for a, b in ((0, 1), (1, 2), (2, 0)) for t in (0.25, 0.5, 0.75)]
    return np.concatenate([triangles.reshape(-1, 3), triangles.mean(1), *edges])


def deepest(points: np.ndarray, world, skip=None) -> tuple[float, str]:
    """How far the points go into anything on the table (or below it), and into what."""
    worst = (float(-points[:, 2].min()), "the table")
    for object_id, meta in world.object_meta.items():
        if object_id == skip:
            continue
        x, y, z = world.get_object_position_mm(object_id)
        w, d, h = meta["size"]
        boxes = []
        if meta["shape"] == "tray":
            boxes.append(((x, y, z), (w, d, TRAY_FLOOR_MM)))
            for cx, cy, bw, bd in ((x, y + d / 2, w, TRAY_WALL_MM), (x, y - d / 2, w, TRAY_WALL_MM),
                                   (x + w / 2, y, TRAY_WALL_MM, d), (x - w / 2, y, TRAY_WALL_MM, d)):
                boxes.append(((cx, cy, z + h / 2), (bw, bd, h)))
        for centre, (bw, bd, bh) in boxes or [((x, y, z), (w, d, h))]:
            p = points - np.array(centre)
            if meta["shape"] in ("ball", "cylinder") and not boxes:
                depth = np.minimum(bw / 2 - np.hypot(p[:, 0], p[:, 1]), bh / 2 - np.abs(p[:, 2]))
            else:
                yaw = math.radians(world.get_object_yaw_deg(object_id)) if not boxes else 0.0
                lx = p[:, 0] * math.cos(yaw) + p[:, 1] * math.sin(yaw)
                ly = -p[:, 0] * math.sin(yaw) + p[:, 1] * math.cos(yaw)
                depth = np.minimum.reduce([bw / 2 - np.abs(lx), bd / 2 - np.abs(ly), bh / 2 - np.abs(p[:, 2])])
            if depth.max() > worst[0]:
                worst = (float(depth.max()), meta["label"])
    return worst


class NothingGoesThroughTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim(gripper=SPEC)
        self.addCleanup(self.sim.close)
        self.robot, self.world = self.sim.robot, self.sim.world
        self.robot.max_speed = 3000.0
        self.robot.bounds["z"][0] = 0.0      # the demo's table (not a z_min saved for the real arm)
        self.world.switch_scenario("two_blocks_and_tray")
        self.robot.move_to(Pose(200.0, 0.0, 60.0, 0.0))

    def move(self, x, y, z, r=0.0, stops: str | None = None) -> None:
        """Move there by small steps (the drawn gripper is checked all the way), expecting to be stopped by `stops`."""
        start = self.robot.get_pose()
        target = Pose(x, y, z, r)
        steps = max(1, int(math.dist((start.x, start.y, start.z), (x, y, z)) / 2.0))
        stopped = None
        for i in range(1, steps + 1):
            t = i / steps
            try:
                self.robot.move_to(Pose(start.x + (x - start.x) * t, start.y + (y - start.y) * t,
                                        start.z + (z - start.z) * t, start.r + (target.r - start.r) * t))
            except Collision as exc:
                stopped = str(exc)
            self.assert_nothing_drawn_inside()
            if stopped:
                break
        if stops is None:
            self.assertIsNone(stopped)
        else:
            self.assertIsNotNone(stopped, f"expected to be stopped by {stops}")
            self.assertIn(stops, stopped)

    def assert_nothing_drawn_inside(self) -> None:
        points = drawn_tool_points(self.robot)
        depth, what = deepest(points, self.world, skip=self.robot.held_object)
        pose = self.robot.get_pose()
        self.assertLess(depth, 1.5, f"the drawn gripper is {depth:.1f} mm into the {what} at "
                                    f"({pose.x:.0f}, {pose.y:.0f}, {pose.z:.0f}, r {pose.r:.0f})")

    def hold_the_red_cube(self) -> None:
        self.move(*RED, 40.0)
        self.move(*RED, CUBE / 2)
        self.robot.close_gripper()
        self.assertEqual(self.robot.held_object, "red_cube")
        self.move(*RED, 50.0)

    def test_the_drawn_fingertips_are_at_the_tool_point(self):
        points = drawn_tool_points(self.robot)
        self.assertAlmostEqual(points[:, 2].min(), self.robot.get_pose().z, delta=0.5)

    def test_coming_down_with_a_finger_over_a_cube_stops_on_its_top(self):
        self.move(RED[0], RED[1] + 16.0, 60.0)
        self.move(RED[0], RED[1] + 16.0, 5.0, stops="a finger touched the red cube")
        self.assertAlmostEqual(self.robot.get_pose().z, CUBE, delta=1.5)

    def test_coming_down_round_a_cube_stops_where_the_gripper_meets_its_top(self):
        self.move(*RED, 60.0)
        self.move(*RED, 0.0, stops="the gripper touched the red cube")
        self.assertAlmostEqual(self.robot.get_pose().z, CUBE - SPEC.finger_depth_mm, delta=1.5)

    def test_going_sideways_into_a_cube_stops_at_it(self):
        self.move(RED[0], 10.0, 10.0)
        self.move(RED[0], RED[1] + 20.0, 10.0, stops="a finger touched the red cube")

    def test_the_fingers_go_down_either_side_of_a_tray_wall_but_not_through_it(self):
        self.move(280.0, 70.0, 30.0)
        self.move(280.0, 0.0, 8.0, stops="a finger touched the tray's wall")

    def test_a_carried_cube_does_not_go_through_another_cube(self):
        self.hold_the_red_cube()
        self.move(RED[0], RED[1], 20.0)
        self.move(220.0, 60.0, 20.0, stops="touched the blue cube")

    def test_a_carried_cube_does_not_go_through_the_table(self):
        self.hold_the_red_cube()
        self.move(180.0, -60.0, 30.0)
        self.move(180.0, -60.0, 0.0, stops="the red cube it carries touched the table")
        self.assertAlmostEqual(self.world.get_object_position_mm("red_cube")[2], CUBE / 2, delta=1.5)

    def test_a_carried_cube_does_not_go_through_a_tray_wall_or_floor(self):
        self.hold_the_red_cube()
        self.move(RED[0], RED[1], 18.0)
        self.move(280.0, RED[1], 18.0)
        self.move(280.0, 0.0, 18.0, stops="the red cube it carries touched the tray's wall")
        self.move(280.0, -60.0, 60.0)         # back out, up, and over the wall
        self.move(280.0, 0.0, 60.0)
        self.move(280.0, 0.0, 0.0, stops="the red cube it carries touched the tray")

    def test_something_already_touching_can_be_backed_away_from_but_not_pushed_into(self):
        self.move(*RED, 40.0)
        self.move(*RED, CUBE / 2)
        # the cube shifted against a finger (as one settling against it would)
        self.world.set_object_position_mm("red_cube", RED[0], RED[1] + 3.0, CUBE / 2)
        with self.assertRaises(Collision):
            self.robot.move_to(Pose(RED[0], RED[1] + 10.0, CUBE / 2, 0.0))
        self.robot.move_to(Pose(RED[0], RED[1], 40.0, 0.0))        # straight up and out: fine

    def test_the_fingers_close_onto_what_they_cannot_hold_not_through_it(self):
        """The blue bar between the fingers, but 11 mm off to one side of them: not held (its middle isn't between
        them), and the drawn fingers used to close right through it."""
        self.world.switch_scenario("mixed_objects")                  # the blue bar: 60 x 10 x 10, along x
        x, y, _ = self.world.get_object_position_mm("blue_bar")
        self.robot.move_to(Pose(x + 11.0, y, 60.0, 0.0))             # closing across it (along y)
        self.robot.move_to(Pose(x + 11.0, y, 5.0, 0.0))
        self.assert_nothing_drawn_inside()
        self.robot.close_gripper()
        self.assertIsNone(self.robot.held_object)
        self.assertIsNotNone(self.robot.jaw_stop_mm, "stopped against it")
        self.assertIn("stopped", self.robot.last_grip_problem)
        self.assert_nothing_drawn_inside()
        self.robot.open_gripper()
        self.assertIsNone(self.robot.jaw_stop_mm)

    def test_the_fingers_pass_close_by_something_round_as_round_not_as_a_square(self):
        """The cylinder was checked as a 24 mm square: fingers closing along a diagonal "hit" its corner, 5 mm
        outside the cylinder itself, and the pick stopped short."""
        self.world.switch_scenario("mixed_objects")
        x, y, _ = self.world.get_object_position_mm("grey_cylinder")
        self.robot.move_to(Pose(x, y, 60.0, 45.0))
        self.robot.move_to(Pose(x, y, 15.0, 45.0))
        self.assert_nothing_drawn_inside()
        self.robot.close_gripper()
        self.assertEqual(self.robot.held_object, "grey_cylinder")


class ByHandThenByPromptTests(unittest.TestCase):
    """What happened: the red cube taken by hand (Manual tab), then prompts. The tools thought nothing was held, the
    camera doesn't see what the gripper holds, so "pick the blue cube" opened the gripper -- dropping the red cube on
    the blue one -- and came down on it; then "go home" set off sideways with a finger against it."""

    def setUp(self):
        from app.llm.tools import ToolExecutor
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        from harness import LOOK_POSE
        self.sim = Sim(gripper=SPEC)
        self.addCleanup(self.sim.close)
        self.robot, self.world = self.sim.robot, self.sim.world
        self.robot.max_speed = 3000.0
        self.robot.bounds["z"][0] = 0.0
        self.world.switch_scenario("two_blocks_and_tray")
        transform = self.sim.exact_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: self.robot.arm_state()[0],
                                       self.world.places, self.world.place_areas)
        self.executor = ToolExecutor(self.robot, SceneBuilder(self.sim.camera, detector, transform),
                                     look_pose=LOOK_POSE, table_z_provider=lambda: 0.0,
                                     places_provider=self.world.places, gripper=SPEC)

    def listed(self) -> dict:
        import ast
        return {o["label"]: o for o in ast.literal_eval(self.executor.execute("list_objects", {}))["objects"]}

    def test_a_cube_taken_by_hand_is_known_to_be_held(self):
        self.robot.move_to(Pose(*RED, 50.0, 0.0))
        self.robot.move_to(Pose(*RED, CUBE / 2, 0.0))
        self.robot.close_gripper()                                   # the Manual tab's Close Gripper...
        self.executor.took_by_hand(self.robot.held_info())           # ...tells the tools (main_window does)
        self.assertEqual(self.executor.holding, "red cube")
        listed = self.listed()
        self.assertNotIn("red cube", listed, "in the gripper, not on the table")
        self.executor.execute("place_on", {"object_id": listed["blue cube"]["id"]})
        red, blue = (self.world.get_object_position_mm(n) for n in ("red_cube", "blue_cube"))
        self.assertLess(math.dist(red[:2], blue[:2]), 3.0)
        self.assertAlmostEqual(red[2], 1.5 * CUBE, delta=1.0, msg="put down on it, not dropped")

    def test_going_home_from_round_a_cube_rises_out_of_it_first(self):
        # left by hand as in the picture: the red cube on the blue one, the open fingers round it
        bx, by, _ = self.world.get_object_position_mm("blue_cube")
        self.world.set_object_position_mm("red_cube", bx, by, 1.5 * CUBE)
        self.robot.move_to(Pose(bx, by, 80.0, 0.0))
        self.robot.move_to(Pose(bx - 2.0, by - 3.0, CUBE + 5.0, 0.0))
        self.executor.execute("home", {})
        pose = self.robot.get_pose()
        self.assertAlmostEqual(pose.y, 0.0, delta=1.0, msg="got home")
        self.assertAlmostEqual(self.world.get_object_position_mm("red_cube")[2], 1.5 * CUBE, delta=0.5)


class PlanningTests(unittest.TestCase):
    def test_the_planner_and_the_demo_see_the_same_gripper(self):
        parts = tool_parts(SPEC, 0.0, 0.0, 0.0, 0.0)
        reach = max(abs(p.centre[1]) + p.size[0] / 2 for p in parts if p.name == "a finger")
        self.assertAlmostEqual(reach, SPEC.opening_mm / 2 + 14.0, delta=0.5, msg="the fingers' outsides, open")
        body = next(p for p in parts if p.name == "the gripper's body")
        self.assertGreater(body.size[1], 100.0, "the body stands out well to one side")

    def test_a_tower_beside_the_cube_is_seen_by_the_gripper_body(self):
        import ast
        from app.llm.tools import ToolExecutor
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        from harness import LOOK_POSE
        sim = Sim(gripper=SPEC)
        self.addCleanup(sim.close)
        world = sim.world
        world.switch_scenario("tower_building")
        sim.robot.move_to(LOOK_POSE)                 # (before the tower is there: it would be in the way)
        bx, by, _ = world.get_object_position_mm("blue_cube")
        # a three-cube tower 45 mm from the blue cube, on the side the body stands out to at r = 0
        for level, name in enumerate(("green_cube", "yellow_cube", "purple_cube")):
            world.set_object_position_mm(name, bx - 45.0, by, CUBE / 2 + CUBE * level)
        transform = sim.exact_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: sim.robot.arm_state()[0],
                                       world.places, world.place_areas)
        executor = ToolExecutor(sim.robot, SceneBuilder(sim.camera, detector, transform), look_pose=LOOK_POSE,
                                table_z_provider=lambda: 0.0, places_provider=world.places, gripper=SPEC)
        listed = {o["label"]: o for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
        blue = listed["blue cube"]
        self.assertIsNotNone(executor._finger_hits_at(bx, by, CUBE / 2, SPEC.closing_direction(0.0)),
                             "the body, not the fingers, would come down on the tower")
        try:
            executor.execute("pick", {"object_id": blue["id"]})
        except ValueError as refused:          # said in words: fine (a Collision from the demo would not be)
            self.assertIn("blue cube", str(refused))
        else:
            self.assertEqual(sim.robot.held_object, "blue_cube", "picked, turned so the gripper misses the tower")


if __name__ == "__main__":
    unittest.main()

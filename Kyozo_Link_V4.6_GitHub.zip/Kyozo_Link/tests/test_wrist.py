"""The wrist's real turn (hardware/wrist.py) and the routines that measure and test it (calibration/wrist_check.py):
the fit recovers offset, gain and backlash; the correction inverts them; and in the demo, a wrist with a gripper
mounted 3 degrees turned, 5 % short and 2 degrees of slack is measured by the fingers angle check, and the rotation
pick test shows picks lining up with the cube better with the correction than without.

Run from the project root:  python -m unittest tests.test_wrist
"""
from __future__ import annotations

import math
import os
import unittest
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

import numpy as np  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

import harness  # noqa: E402,F401  (project root on the path)
from app.calibration.wrist_check import jaw_in_use, run_fingers_check, run_rotation_test
from app.hardware.gripper import GripperSpec
from app.hardware.interfaces import Pose
from app.hardware.wrist import WristCorrected, WristModel, circular_spread, fit_wrist
from app.llm.tools import ToolExecutor
from app.vision.scene import SceneObject
from test_cube_calibration import Bench  # noqa: E402

app = QApplication.instance() or QApplication([])

FAULTS = dict(fingers_turned_deg=3.0, wrist_gain=0.95, wrist_backlash_deg=2.0)


def synthetic(offset, gain, backlash, noise=0.0, seed=0):
    rng = np.random.default_rng(seed)
    return [(t, s, offset + gain * t + s * backlash / 2.0 + rng.normal(0.0, noise))
            for t in (-40.0, -20.0, 0.0, 20.0, 40.0) for s in (-1, 1) for _ in range(2)]


class FitTests(unittest.TestCase):
    def test_recovers_the_faults(self):
        model = fit_wrist(synthetic(3.0, 0.95, 2.0, noise=0.2))
        self.assertTrue(model.trusted, model.problems)
        self.assertAlmostEqual(model.offset_deg, 3.0, delta=0.3)
        self.assertAlmostEqual(model.gain, 0.95, delta=0.01)
        self.assertAlmostEqual(model.backlash_deg, 2.0, delta=0.4)
        self.assertLess(model.scatter_deg, 0.5)

    def test_too_few_or_one_sided_is_not_trusted(self):
        self.assertFalse(fit_wrist(synthetic(0, 1, 0)[:4]).trusted)
        one_side = [p for p in synthetic(0, 1, 1) if p[1] == -1]
        self.assertFalse(fit_wrist(one_side).trusted)

    def test_unbelievable_values_and_scatter_are_not_trusted(self):
        model = fit_wrist(synthetic(0.0, 0.7, 1.0))
        self.assertFalse(model.trusted)
        self.assertIn("not believable", " ".join(model.problems))
        noisy = fit_wrist(synthetic(0.0, 1.0, 1.0, noise=25.0))
        self.assertFalse(noisy.trusted)
        self.assertIn("scatter", " ".join(noisy.problems))

    def test_the_labs_check_of_2026_10_22_is_trusted_and_a_saved_one_judged_again(self):
        from app.hardware.wrist import WristModel
        saved = {"offset_deg": 13.1, "gain": 0.88, "backlash_deg": 5.9, "scatter_deg": 8.9, "samples": 10,
                 "trusted": False, "problems": ["the put-downs scatter 8.9° round the fit (over 1.5°: ...)"]}
        model = WristModel.from_dict(saved)
        self.assertTrue(model.trusted, model.problems)
        self.assertEqual(model.problems, [])
        self.assertFalse(WristModel.from_dict(dict(saved, offset_deg=21.2, gain=0.83)).trusted,
                         "the morning's: offset and gain still past their limits")

    def test_the_labs_check_of_2026_10_28_is_used_with_a_note_on_the_gripper(self):
        """A large steady offset is used (study 3: refused at +20.1°, every pick went down ~20° off the cube), with
        the gripper's mounting named; past MAX_OFFSET_DEG it is still refused."""
        from app.hardware.wrist import WristModel
        saved = {"offset_deg": 20.13, "gain": 0.988, "backlash_deg": 4.78, "scatter_deg": 4.94, "samples": 10,
                 "trusted": False, "problems": ["an offset of +20.1° (check how the gripper is mounted)"]}
        model = WristModel.from_dict(saved)
        self.assertTrue(model.trusted, model.problems)
        self.assertIn("mounted turned", model.describe())
        self.assertAlmostEqual(model.real_wrist(model.told_for(30.0)), 30.0, places=6)
        self.assertEqual(WristModel.from_dict(dict(saved, offset_deg=8.0)).mount_note, "")
        far = WristModel.from_dict(dict(saved, offset_deg=-34.0))
        self.assertFalse(far.trusted)
        self.assertIn("check how the gripper is mounted", " ".join(far.problems))

    def test_saved_and_read_back(self):
        model = fit_wrist(synthetic(1.0, 1.02, 1.5))
        again = WristModel.from_dict(model.to_dict())
        self.assertAlmostEqual(again.gain, model.gain, places=3)
        self.assertEqual(len(again.points), len(model.points))

    def test_correction_inverts_the_model(self):
        gripper = GripperSpec()
        model = WristModel(offset_deg=3.0, gain=0.95, backlash_deg=2.0)
        wrist = WristCorrected(object(), gripper, model)
        for x, y, r in ((200.0, 50.0, 30.0), (150.0, -120.0, -70.0)):
            told = wrist.told_r(r, x, y)
            j1 = math.degrees(math.atan2(y, x))
            self.assertAlmostEqual(j1 + model.real_wrist(told - j1), r, places=6)
            self.assertAlmostEqual(wrist.ideal_r(told, x, y), r, places=6)
        model.trusted = False
        self.assertEqual(wrist.told_r(30.0, 200.0, 0.0), 30.0)

    def test_circular_spread(self):
        mean, spread = circular_spread([44.0, -44.0, 45.5], 90.0)
        self.assertAlmostEqual(abs(mean), 45.0, delta=1.0)
        self.assertLess(spread, 2.0)


class LoggingRobot:
    """Writes down every move (with its speed) and the gripper closing."""
    bounds = {"x": [-300.0, 307.0], "y": [-300.0, 300.0], "z": [-58.6, 300.0]}
    max_reach_mm = 300.0

    def __init__(self):
        self.log, self.pose = [], Pose(200, 0, 100)

    def clamp_pose(self, pose):
        return pose

    def get_pose(self):
        return self.pose

    def move_to(self, pose, speed=None):
        self.log.append(("move", pose, speed))
        self.pose = pose

    def open_gripper(self):
        pass

    def close_gripper(self):
        self.log.append(("close",))


class OneCubeScene:
    def __init__(self, cube, readings=None):
        self.cube, self.readings = cube, list(readings or [])

    def get_scene(self):
        return [self.cube]

    def footprints_near(self, x, y, looks):
        if self.readings:
            return self.readings.pop(0)
        return [self.cube.footprint] * looks


class PickTests(unittest.TestCase):
    CUBE = SceneObject("obj_1", "red cube", (220.0, 40.0, 20.0), 0.9, (20.0, 20.0, 30.0))

    def make(self, model=None, readings=None):
        robot = LoggingRobot()
        executor = ToolExecutor(robot, OneCubeScene(self.CUBE, readings), table_z_provider=lambda: 0.0,
                                gripper=GripperSpec())
        executor.wrist.model = model
        executor.check_picks = False    # (the stand-in's table never changes: the camera's look after a pick
        return executor, robot          # would say every grip missed -- tested in test_simple20, in the twin)

    def moves_before_close(self, robot):
        close = robot.log.index(("close",))
        return [entry for entry in robot.log[:close] if entry[0] == "move"]

    def test_corrected_from_below_and_slowly(self):
        model = WristModel(offset_deg=3.0, gain=0.95, backlash_deg=2.0)
        executor, robot = self.make(model)
        executor.execute("pick", {"object_id": "obj_1"})
        r = executor.last_record["grip"]["r"]
        told = lambda ideal: executor.wrist.told_r(ideal, 220.0, 40.0)   # noqa: E731
        *_, turn_below, turn_to, slow_from, last = self.moves_before_close(robot)
        self.assertAlmostEqual(turn_below[1].r, told(r - 4.0), places=6)
        self.assertAlmostEqual(turn_to[1].r, told(r), places=6)
        self.assertNotAlmostEqual(told(r), r, places=1)                  # the correction changed what was told
        self.assertEqual(turn_below[1].z, turn_to[1].z)                  # turned up there, before going down
        grip_z = 20.0 - executor.last_record["grip"]["depth_mm"]
        self.assertAlmostEqual(slow_from[1].z, grip_z + 15.0)
        self.assertIsNone(slow_from[2])
        self.assertAlmostEqual(last[1].z, grip_z)
        self.assertEqual(last[2], 20.0)                                  # the last 15 mm at 20 mm/s
        self.assertIn("told r", executor.last_record["grip"]["wrist"])

    def test_a_cube_that_slid_since_the_last_look_is_picked_where_the_pictures_see_it(self):
        executor, robot = self.make(None)
        seen = [(self.CUBE.footprint, (223.0, 41.5, 20.4))] * 4               # (3.4 mm on since it was listed)
        executor.scene_builder.looks_near = lambda x, y, looks: seen[:looks]
        executor.execute("pick", {"object_id": "obj_1"})
        last = self.moves_before_close(robot)[-1][1]
        self.assertAlmostEqual(last.x, 223.0, places=6)
        self.assertAlmostEqual(last.y, 41.5, places=6)
        self.assertEqual(executor.last_record["moved"]["mm"], 3.4)
        self.assertEqual(executor.last_record["moved"]["from"], [220.0, 40.0])
        grip_z = 20.0 - executor.last_record["grip"]["depth_mm"]
        self.assertAlmostEqual(last.z, grip_z, msg="its height as listed")

    def test_the_cameras_own_wander_doesnt_move_a_pick(self):
        executor, robot = self.make(None)
        seen = [(self.CUBE.footprint, (220.4 + d, 40.3 - d, 20.0)) for d in (0.0, 0.2, -0.2, 0.1)]
        executor.scene_builder.looks_near = lambda x, y, looks: seen[:looks]
        executor.execute("pick", {"object_id": "obj_1"})
        last = self.moves_before_close(robot)[-1][1]
        self.assertEqual((last.x, last.y), (220.0, 40.0), "under 1 mm: as listed")
        self.assertNotIn("moved", executor.last_record)

    def test_without_a_check_the_angle_is_as_planned(self):
        executor, robot = self.make(None)
        executor.execute("pick", {"object_id": "obj_1"})
        r = executor.last_record["grip"]["r"]
        *_, turn_below, turn_to, _, _ = self.moves_before_close(robot)
        self.assertAlmostEqual(turn_to[1].r, r)
        self.assertAlmostEqual(turn_below[1].r, r - 4.0)
        self.assertIn("no fingers angle check", executor.last_record["grip"]["wrist"])

    def test_angle_read_again_when_pictures_disagree(self):
        executor, _ = self.make(None, readings=[[(20, 20, 30.0), (20, 20, 38.0), (20, 20, 31.0)],
                                                [(20, 20, 32.0), (20, 20, 32.5), (20, 20, 31.5), (20, 20, 32.0)]])
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertTrue(executor.last_record["angle"]["again"])
        # (both looks judged together, the furthest off one in four -- the 38 -- left out)
        self.assertAlmostEqual(executor.last_record["grip"]["footprint"][2], 31.5, delta=0.1)

    def test_the_real_cameras_wandering_reading_is_averaged_not_refused(self):
        # the lab, 2026-10-21: a still cube's turn read over 8-10 degrees; "pick up the blue cube" was refused, "up to
        # 5 degrees over 8 pictures" -- the average of them is good to about a degree
        wander = [(20, 20, a) for a in (30.0, 33.5, 28.0, 31.5)]
        executor, robot = self.make(None, readings=[wander, wander])
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertIn(("close",), robot.log)
        self.assertAlmostEqual(executor.last_record["grip"]["footprint"][2], 31.0, delta=1.5)

    def test_an_unsteady_reading_is_picked_up_to_15_degrees_after_a_second_look(self):
        wobbly = [(20, 20, a) for a in (30.0, 41.0, 28.0, 36.0)]       # (13 degrees apart, the mean poorly known)
        executor, robot = self.make(None, readings=[wobbly, wobbly])
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertTrue(executor.last_record["angle"]["again"], "looked at twice first")
        self.assertNotIn("refused", executor.last_record["angle"])

    def test_pick_refused_when_they_keep_disagreeing(self):
        noisy = [(20, 20, 20.0), (20, 20, 45.0), (20, 20, 32.0)]      # (25 degrees apart: past the 15 allowed)
        # (and from afar too: V4.2 reads it once more, the arm out of view, before refusing)
        executor, robot = self.make(None, readings=[noisy, noisy, noisy])
        with self.assertRaises(ValueError) as said:
            executor.execute("pick", {"object_id": "obj_1"})
        self.assertIn("kept changing", str(said.exception))
        self.assertNotIn(("close",), robot.log)


class DemoWristTests(unittest.TestCase):
    def test_the_check_measures_the_faults_and_the_correction_helps(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        for name, value in FAULTS.items():
            setattr(bench.robot, name, value)
        out = bench.phase1()
        self.assertTrue(out.passed, out.reason)
        check = run_fingers_check(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                                  settle_s=0.0, frames=3)
        self.assertFalse(check.reason, check.reason)
        self.assertEqual(len(check.points), 20, check.skipped)
        model = check.model
        self.assertTrue(model.trusted, model.problems)
        jaw = jaw_in_use(out, bench.gripper)
        # the fingers really close along 90 + 3 degrees at the wrist's zero: offset + the jaw the app plans with
        self.assertAlmostEqual(model.offset_deg + jaw, bench.gripper.jaw_axis_deg + 3.0, delta=0.5)
        self.assertAlmostEqual(model.gain, 0.95, delta=0.01)
        self.assertAlmostEqual(model.backlash_deg, 2.0, delta=0.5)
        self.assertTrue(out.holding and bench.robot._held == bench.ids["red cube"])
        # the rotation pick test, without the correction and with it
        before = run_rotation_test(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                                   model=model, corrected=False, rounds=6, seed=4, settle_s=0.0, frames=3)
        after = run_rotation_test(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                                  model=model, corrected=True, rounds=6, seed=4, settle_s=0.0, frames=3)
        self.assertEqual(len(before.errors_deg), 6, before.reason)
        self.assertEqual(len(after.errors_deg), 6, after.reason)
        self.assertGreater(before.mean_deg, 1.0, before.describe())
        self.assertLess(after.mean_deg, 0.6, after.describe())
        self.assertLess(after.mean_deg, before.mean_deg)
        self.assertEqual(set(after.sides), {-1})
        self.assertTrue(out.holding and bench.robot._held == bench.ids["red cube"])


class RealDobotReviewTests(unittest.TestCase):
    """Found reviewing the gripper-angle code before its first run on the real Dobot (2026-10-10)."""

    def _gripper(self):
        from app import robots
        robots.set_active("dobot_magician")
        return GripperSpec.from_config({"gripper_type": "gripper"}, robots.active().gripper_defaults())

    def test_the_cube_is_taken_back_with_the_wrist_coming_from_the_side_it_was_let_go(self):
        # (straight from the waiting place, half the time from the other side: a backlash's worth off, and a 25 mm
        # cube in 27.5 mm fingers fits only about 4 degrees -- the simulator's finger touched the cube)
        from types import SimpleNamespace
        from app.calibration.wrist_check import _take_back_from
        robot = LoggingRobot()
        robot.pose = Pose(150, -120, 80, 30.0)                 # the waiting place: the wrist well above 0
        arm = SimpleNamespace(settle_s=0.0, acted=False, closed=False, check=lambda: None,
                              move=lambda x, y, z, r: robot.move_to(Pose(x, y, z, r)),
                              move_slow=lambda x, y, z, r, speed: robot.move_to(Pose(x, y, z, r)))
        _take_back_from(arm, robot, self._gripper(), 200, 0, 10.0, -20.0, -1, 12.0)
        turns = [entry[1].r for entry in robot.log if entry[0] == "move"]
        self.assertEqual(turns[:2], [-32.0, -20.0], "12 below the angle first, then up to it (from below)")

    def test_the_wrist_correction_stops_short_of_the_wrists_limit(self):
        gripper = self._gripper()
        model = fit_wrist(synthetic(offset=-3.0, gain=0.95, backlash=2.0))
        self.assertTrue(model.trusted, model.problems)
        wrist = WristCorrected(LoggingRobot(), gripper, model, side=-1)
        low, high = gripper.j4_limits_deg
        for r in (-88.0, 88.0):
            told = wrist.told_r(r, 200.0, 0.0)                  # J1 = 0 there: r is the wrist's own angle
            self.assertTrue(low < told < high, f"{r} -> {told}")

    def test_an_angle_unsteady_once_then_unreadable_is_refused_not_guessed(self):
        from types import SimpleNamespace
        looks = iter([[(25.0, 25.0, 0.0), (25.0, 25.0, 20.0)], [(25.0, 25.0, 5.0)]])
        fake = SimpleNamespace(gripper=self._gripper(), angle_looks=4, last_record={},
                               scene_builder=SimpleNamespace(footprints_near=lambda x, y, n: next(looks)),
                               _angle_from_afar=lambda obj, footprint: None,   # (V4.2: unreadable from afar too)
                               _clear_view_of=lambda obj: None,                 # (no arm in the camera's way here)
                               _as_put_down=lambda obj, *rest: None)            # (not a cube it put down itself)
        cube = SceneObject("obj_1", "red cube", (200.0, 0.0, 25.0), 1.0, footprint=(25.0, 25.0, 3.0))
        with self.assertRaises(ValueError):
            ToolExecutor._steady_angle(fake, cube)

    def test_a_missed_pick_is_tried_again_the_way_the_pick_came_and_the_test_goes_on(self):
        # (taken back at the uncorrected angle instead: 3 degrees of mounting plus the slack off, past what a 25 mm
        # cube fits -- "the cube couldn't be taken back")
        from app.calibration import wrist_check
        bench = Bench(self, "dobot_magician", "Perfect")
        for name, value in FAULTS.items():
            setattr(bench.robot, name, value)
        out = bench.phase1()
        self.assertTrue(out.passed, out.reason)
        check = run_fingers_check(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                                  settle_s=0.0, frames=3)
        self.assertTrue(check.model.trusted, check.model.problems)
        real_holding, calls = wrist_check._holding, [0]

        def first_pick_missed(*args, **kwargs):
            calls[0] += 1
            return False if calls[0] == 1 else real_holding(*args, **kwargs)
        with mock.patch.object(wrist_check, "_holding", first_pick_missed):
            after = run_rotation_test(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                                      model=check.model, corrected=True, rounds=3, seed=4, settle_s=0.0, frames=3)
        self.assertEqual(after.missed, 1)
        self.assertFalse(after.reason, after.reason)
        self.assertEqual(after.rounds, 3)
        self.assertTrue(out.holding and bench.robot._held == bench.ids["red cube"])

    def test_a_refused_move_in_the_fingers_check_stops_cleanly_and_knows_where_the_cube_is(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        out = bench.phase1()
        self.assertTrue(out.passed, out.reason)
        real_move, count = bench.robot.move_to, [0]

        def alarming(pose, *a, **k):
            count[0] += 1
            if count[0] == 25:
                raise RuntimeError("Dobot alarm 0x22 (MOVE_INV_LIMIT)")
            return real_move(pose, *a, **k)
        bench.robot.move_to = alarming
        check = run_fingers_check(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                                  settle_s=0.0, frames=3)
        bench.robot.move_to = real_move
        self.assertIn("refused a move", check.reason)
        self.assertIsNone(check.model)
        self.assertEqual(out.holding, bench.robot._held is not None, "the books say where the cube really is")



class AngleReviewTests(unittest.TestCase):
    """Found reviewing the gripper-angle code after its first picks on the real Dobot (2026-10-12): two picks refused
    for 7 and 4 degrees between pictures, a pre-turn smaller than the slack the model allows, a correction cut short at
    the wrist's limit, put-downs not taking up the slack, round things with no turn to read, the twin without J4's
    limit."""

    CUBE = SceneObject("obj_1", "red cube", (220.0, 40.0, 20.0), 0.9, (20.0, 20.0, 30.0))

    def make(self, cube=None, readings=None, model=None):
        robot = LoggingRobot()
        executor = ToolExecutor(robot, OneCubeScene(cube or self.CUBE, readings), table_z_provider=lambda: 0.0,
                                gripper=GripperSpec())
        executor.wrist.model = model
        executor.check_picks = False    # (the stand-in's table never changes: the camera's look after a pick
        return executor, robot          # would say every grip missed -- tested in test_simple20, in the twin)

    def test_one_bad_picture_doesnt_refuse_the_pick(self):
        from app.hardware.wrist import steady_mean
        mean, spread, dropped = steady_mean([0.0, 7.0, 2.0, 3.0], 90.0)
        self.assertEqual(dropped, 1)
        self.assertAlmostEqual(mean, 5.0 / 3.0, delta=0.05)
        self.assertLessEqual(spread, 1.7)
        executor, robot = self.make(readings=[[(20, 20, 30.0), (20, 20, 37.0), (20, 20, 32.0), (20, 20, 33.0)]])
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertIn(("close",), robot.log)
        self.assertEqual(executor.last_record["angle"]["left_out"], 1)
        self.assertFalse(executor.last_record["angle"]["again"])

    def test_the_second_look_is_judged_with_the_first(self):
        # each look alone too unsteady; together, the worst two left out, they agree
        first = [(20, 20, 30.0), (20, 20, 36.0), (20, 20, 31.0), (20, 20, 37.0)]
        second = [(20, 20, 31.0), (20, 20, 30.5), (20, 20, 31.5), (20, 20, 30.0)]
        executor, robot = self.make(readings=[first, second])
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertEqual(executor.last_record["angle"]["looks"], 8)
        self.assertAlmostEqual(executor.last_record["grip"]["footprint"][2], 30.7, delta=0.3)

    def test_something_round_has_no_turn_to_read(self):
        can = SceneObject("obj_1", "grey cylinder", (220.0, 40.0, 20.0), 0.9, (20.0, 20.0, 37.0))
        wild = [[(20, 20, a) for a in (-42.0, -65.0, -11.0, -89.0)]] * 2     # a disc's rectangle, any which way
        executor, robot = self.make(cube=can, readings=list(wild))
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertIn(("close",), robot.log)
        self.assertNotIn("angle", executor.last_record)

    def test_listed_without_an_outline_its_turn_comes_from_the_pictures(self):
        cube = SceneObject("obj_1", "red cube", (220.0, 40.0, 20.0), 0.9, None)     # (the colour finder's)
        executor, _ = self.make(cube=cube, readings=[[(20, 20, 30.0)] * 4])
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertTrue(executor.last_record["angle"]["from_looks"])
        self.assertEqual(executor.last_record["grip"]["footprint"], (20.0, 20.0, 30.0))

    def test_the_pre_turn_crosses_the_whole_slack(self):
        model = WristModel(offset_deg=0.0, gain=1.0, backlash_deg=6.0)
        executor, robot = self.make(model=model)
        self.assertEqual(executor.wrist.pre_turn(4.0), 8.0, "6 of slack: 8 short first, not 4")
        executor.execute("pick", {"object_id": "obj_1"})
        r = executor.last_record["grip"]["r"]
        told = lambda ideal: executor.wrist.told_r(ideal, 220.0, 40.0)   # noqa: E731
        moves = [e for e in robot.log[:robot.log.index(("close",))] if e[0] == "move"]
        self.assertAlmostEqual(moves[-4][1].r, told(r - 8.0), places=6)
        executor.wrist.model = None
        self.assertEqual(executor.wrist.pre_turn(4.0), 4.0, "no check yet: as configured")

    def test_the_planner_judges_the_wrist_limit_as_the_wrist_is_told(self):
        gripper = GripperSpec()
        self.assertTrue(gripper.wrist_fits(88.0, 200.0, 0.0))
        wrist = WristCorrected(LoggingRobot(), gripper, WristModel(offset_deg=-3.0, gain=0.95, backlash_deg=2.0))
        gripper.told_wrist = wrist.told_wrist
        self.assertGreater(wrist.told_wrist(88.0), 89.0)
        self.assertFalse(gripper.wrist_fits(88.0, 200.0, 0.0), "corrected, it would pass the limit: not chosen")
        self.assertTrue(gripper.wrist_fits(-2.0, 200.0, 0.0), "the equivalent turn a quarter round instead")

    def test_a_put_down_comes_to_its_angle_from_the_same_side_as_a_pick(self):
        executor, robot = self.make()
        executor.execute("pick", {"object_id": "obj_1"})
        robot.log.clear()
        executor.execute("place", {"x": 200.0, "y": -40.0, "z": 0.0})
        r = executor.last_record["release"]["r"]
        moves = [e[1] for e in robot.log if e[0] == "move"]
        down = next(i for i, p in enumerate(moves) if abs(p.z - 0.0) < 1e-6)
        self.assertAlmostEqual(moves[down - 2].r, r - 4.0, places=6, msg="4 short of its angle first")
        self.assertAlmostEqual(moves[down - 1].r, r, places=6)

    def test_a_step_aside_that_takes_the_wrist_past_its_limit_isnt_a_way(self):
        executor, _ = self.make()
        self.assertTrue(executor._can_reach(Pose(200.0, 0.0, 50.0, 80.0)))
        self.assertFalse(executor._can_reach(Pose(200.0, -60.0, 50.0, 80.0)), "J4 = 80 + 17: past 90")
        with self.assertRaisesRegex(ValueError, "wrist can't turn"):
            executor._require_reachable(Pose(200.0, -60.0, 50.0, 80.0), "Place target")

    def test_the_turn_is_read_round_most_of_the_points_not_every_stray_one(self):
        import cv2
        from app.vision.locator import measure_footprint
        # a 25 mm cube's top turned 20 degrees, and 14 edge pixels (1.5 %) 1-3 mm outside it, as a real depth camera's
        a = math.radians(20.0)
        turn = np.array([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]])
        raw_off, off = [], []
        for seed in range(20):
            rng = np.random.default_rng(seed)
            u, v = np.meshgrid(np.arange(-12.0, 12.01, 0.8), np.arange(-12.0, 12.01, 0.8))
            square = np.stack([u.ravel(), v.ravel()], axis=1) + rng.normal(0.0, 0.25, (u.size, 2))
            side, along, out = rng.integers(0, 4, 14), rng.uniform(-12, 12, 14), 12 + rng.uniform(1, 3, 14)
            stray = np.stack([np.where(side == 0, out, np.where(side == 1, -out, along)),
                              np.where(side == 2, out, np.where(side == 3, -out, along))], axis=1)
            points = np.vstack([square, stray]) @ turn.T + np.array([200.0, 30.0])
            raw_off.append(abs(cv2.minAreaRect(points.astype(np.float32))[2] % 90.0 - 20.0))
            off.append(abs(measure_footprint(points)[0][2] % 90.0 - 20.0))
        self.assertGreater(max(raw_off), 4.0, "the tightest rectangle round every point jumps by degrees")
        self.assertLess(max(off), 1.5, "round 98% of them, it holds")

    def test_the_twin_stops_at_the_wrists_limit(self):
        from app import robots
        from app.hardware.interfaces import OutOfReach
        from app.hardware.sim_robot import SimRobot
        from app.twin.world import TwinWorld
        profile = robots.set_active("dobot_magician")
        world = TwinWorld()
        client = world.start()
        self.addCleanup(world.stop)
        robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                         max_reach_mm=profile.max_reach_mm, world=world)
        robot.connect()
        robot.move_to(Pose(200.0, 0.0, 50.0, 85.0))
        with self.assertRaises(OutOfReach):
            robot.move_to(Pose(200.0, -60.0, 50.0, 85.0))           # J4 = 85 + 17


class AppTests(unittest.TestCase):
    """A fingers angle check saved with the calibration is used by every pick and shown on the Model tab; one made
    with another fingers' angle, or that failed its checks, is not."""

    def window_with(self, wrist: dict):
        import shutil
        import tempfile
        from pathlib import Path
        from app.calibration.storage import save_calibration
        from app.config import load_config
        from app.hardware.interfaces import Intrinsics
        from app.ui import main_window as main_window_module
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        original = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(folder.name)
        self.addCleanup(setattr, main_window_module, "PROJECT_ROOT", original)
        shutil.copy(harness.ROOT / "config.yaml", Path(folder.name) / "config.yaml")
        config = load_config()
        config["mode"] = "demo"
        config["display"] = {}
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
        save_calibration(Path(folder.name) / "calibration_demo.json", np.eye(4),
                         Intrinsics(fx=600, fy=600, cx=640, cy=360, width=1280, height=720), method="cube (quick)",
                         reprojection_error_mm=0.5, num_samples=10,
                         extras={"jaw_axis_deg": 92.0, "wrist_model": wrist,
                                 "rotation_test": {"corrected": True, "rounds": 6, "held": 6, "missed": 0,
                                                   "mean_deg": 0.3, "worst_deg": 0.6, "spread_deg": 0.2,
                                                   "by_side": {"below": 0.1}, "measured_at": "2026-10-09 10:00"}})
        window = main_window_module.MainWindow(config)

        def close():
            window.jog_panel.stop_pose_monitor()
            window.close()
            window._twin_world.stop()
        self.addCleanup(close)
        return window

    def test_used_and_shown(self):
        model = fit_wrist(synthetic(1.0, 0.97, 1.5))
        model.jaw_axis_deg = 92.0
        window = self.window_with(model.to_dict())
        self.assertTrue(window.tool_executor.wrist.active)
        self.assertAlmostEqual(window.tool_executor.wrist.model.gain, 0.97, delta=0.005)
        text = window.model_tab.wrist_label.text()
        self.assertIn("used for every pick", text)
        self.assertIn("Last rotation pick test", text)
        self.assertTrue(window.model_tab.wrist_plot.isVisibleTo(window.model_tab))

    def test_made_with_another_fingers_angle_is_not_used(self):
        model = fit_wrist(synthetic(1.0, 0.97, 1.5))
        model.jaw_axis_deg = 88.0
        window = self.window_with(model.to_dict())
        self.assertFalse(window.tool_executor.wrist.active)
        self.assertIn("not used for picks", window.model_tab.wrist_label.text())


class ReviewerTwoFitTests(unittest.TestCase):
    """The fingers angle check's fit, as a second review found it (2026-10-27)."""

    def test_a_refused_fit_is_still_refused_after_saving_and_loading(self):
        model = fit_wrist(synthetic(5.0, 1.0, -4.0))
        self.assertFalse(model.trusted)
        again = WristModel.from_dict(model.to_dict())       # (saved with backlash 0, it came back trusted)
        self.assertFalse(again.trusted, "picks would use what the panel said they don't")
        self.assertEqual(again.problems, model.problems)
        one_side = WristModel.from_dict(fit_wrist([p for p in synthetic(0, 1, 1) if p[1] == -1]).to_dict())
        self.assertFalse(one_side.trusted)
        self.assertAlmostEqual(WristModel(backlash_deg=-0.5).told_for(10.0), 10.0)   # (slack under none: none)

    def test_a_reading_a_quarter_turn_out_is_folded_back(self):
        points = synthetic(15.0, 1.0, 2.0, noise=0.5)
        told, side, real = points[0]
        points[0] = (told, side, real - 90.0)              # (the lab's -40 from below: 14.6 read as -75.4)
        model = fit_wrist(points)
        self.assertTrue(model.trusted, model.problems)
        self.assertAlmostEqual(model.backlash_deg, 2.0, delta=0.6)
        self.assertLess(model.scatter_deg, 1.5)

    def test_one_cube_that_turned_as_it_was_let_go_is_left_out(self):
        points = synthetic(3.0, 0.95, 2.0, noise=0.5)
        told, side, real = points[3]
        points[3] = (told, side, real + 20.0)
        model = fit_wrist(points)
        self.assertTrue(model.trusted, model.problems)
        self.assertEqual(len(model.left_out), 1)
        self.assertAlmostEqual(model.backlash_deg, 2.0, delta=0.6)
        self.assertIn("1 more left out", model.describe())
        self.assertEqual(len(WristModel.from_dict(model.to_dict()).left_out), 1)
        self.assertEqual(fit_wrist(synthetic(3.0, 0.95, 2.0, noise=1.0)).left_out, [], "noise alone: none left out")


if __name__ == "__main__":
    unittest.main()

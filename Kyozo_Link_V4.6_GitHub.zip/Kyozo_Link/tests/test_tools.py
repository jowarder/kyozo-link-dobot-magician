"""The tools the model calls: covered objects and putting things down on free table space.

    python -m unittest discover -s tests -p test_tools.py -v

Uses a stand-in robot and scene, so it is quick.
"""
from __future__ import annotations

import ast
import math
import unittest
from dataclasses import dataclass

from harness import ROOT  # noqa: F401,E402  (sets up sys.path and the working folder)
from app.hardware.interfaces import Pose  # noqa: E402
from app.llm.tools import CLEARANCE_MM, RELEASE_GAP_MM, ToolExecutor  # noqa: E402


@dataclass
class Thing:
    id: str
    label: str
    xyz_robot: tuple
    confidence: float = 0.9


class FakeScene:
    def __init__(self, things):
        self.things = things
        self.next_views = []                # what the camera shows on the next looks, if the scene is about to change

    def get_scene(self):
        if self.next_views:
            self.things = self.next_views.pop(0)
        return list(self.things)


class FakeRobot:
    bounds = {"x": [-300.0, 307.0], "y": [-300.0, 300.0], "z": [-58.6, 300.0]}
    max_reach_mm = 300.0

    def __init__(self):
        self.moves, self.pose = [], Pose(200, 0, 100)

    def clamp_pose(self, pose):
        radius = math.hypot(pose.x, pose.y)
        scale = min(1.0, self.max_reach_mm / radius) if radius else 1.0
        return Pose(pose.x * scale, pose.y * scale, min(max(pose.z, -58.6), 300.0))

    def get_pose(self):
        return self.pose

    def move_to(self, pose, speed=None):
        self.moves.append(pose)
        self.pose = pose

    def open_gripper(self):
        pass

    def close_gripper(self):
        pass


def make(things, table_z=0.0):
    robot, scene = FakeRobot(), FakeScene(things)
    executor = ToolExecutor(robot, scene, table_z_provider=lambda: table_z)
    # (the stand-in can't feel a grip and its table never changes: the camera's look after each pick would say every
    # grip missed -- that check is tested in test_simple20, in the twin)
    executor.check_picks = False
    return executor, robot, scene


RED_UNDER = Thing("obj_1", "red cube", (284, -9, 25))          # a sliver of it is seen
BLUE_ON_TOP = Thing("obj_2", "blue cube", (281, -2, 54))


class CoveredObjectTests(unittest.TestCase):
    def test_the_list_says_which_object_is_covered(self):
        executor, _, _ = make([RED_UNDER, BLUE_ON_TOP])
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        red = next(o for o in listed["objects"] if o["label"] == "red cube")
        blue = next(o for o in listed["objects"] if o["label"] == "blue cube")
        self.assertEqual(red["covered_by"], "blue cube")
        self.assertNotIn("covered_by", blue)

    def test_picking_a_covered_object_moves_the_top_one_aside_first(self):
        executor, robot, scene = make([RED_UNDER, BLUE_ON_TOP])
        executor.execute("list_objects", {})
        scene.next_views = [[Thing("obj_1", "red cube", (280, 0, 25)), Thing("obj_3", "blue cube", (230, 40, 25))]]
        result = executor.execute("pick", {"object_id": "obj_1"})
        self.assertIn("blue cube was on top of the red cube", result)
        self.assertIn("Picked up red cube", result)
        self.assertEqual(executor.holding, "red cube")
        # it went for the blue cube first, and only then came down on the red one at the spot it was seen
        downs = [m for m in robot.moves if abs(m.x - 281) < 2 and abs(m.z - 54) < 1]
        self.assertTrue(downs, "the blue cube was picked up from where it sat")
        self.assertTrue(any(abs(m.x - 280) < 1 and abs(m.z - 25) < 1 for m in robot.moves))

    def test_the_object_in_the_gripper_is_not_counted_as_sitting_on_something(self):
        executor, _, scene = make([Thing("obj_1", "red cube", (220, -60, 25)), Thing("obj_2", "blue cube", (220, 60, 25))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        scene.things = [Thing("obj_1", "red cube", (220, 60, 90)), Thing("obj_2", "blue cube", (220, 60, 25))]   # hovering over blue
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        self.assertTrue(all("covered_by" not in o for o in listed["objects"]), listed)

    def test_with_two_cubes_of_one_colour_the_one_that_was_under_is_picked(self):
        executor, _, scene = make([Thing("obj_1", "red cube", (284, -9, 25)), BLUE_ON_TOP,
                                   Thing("obj_3", "red cube", (200, -120, 25))])
        executor.execute("list_objects", {})
        scene.next_views = [[Thing("obj_1", "red cube", (280, 0, 25)), Thing("obj_3", "red cube", (200, -120, 25)),
                             Thing("obj_4", "blue cube", (230, 40, 25))]]
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertEqual(executor.holding, "red cube")
        self.assertAlmostEqual(executor.robot.get_pose().x, 280, delta=2)        # it went to the one that had been covered

    def test_a_pile_of_four_is_not_taken_apart(self):
        # (V4.2: a pile of three is -- both above moved aside, CLEAR_LEVELS; tested in the twin, test_simple20)
        executor, robot, _ = make([RED_UNDER, BLUE_ON_TOP, Thing("obj_3", "green cube", (283, -4, 83)),
                                   Thing("obj_4", "yellow cube", (282, -3, 112))])
        executor.execute("list_objects", {})
        before = len(robot.moves)
        with self.assertRaisesRegex(ValueError, "too high"):
            executor.execute("pick", {"object_id": "obj_1"})
        self.assertEqual(len(robot.moves), before)

    def test_without_a_known_table_height_it_refuses_and_does_not_move(self):
        executor, robot, _ = make([RED_UNDER, BLUE_ON_TOP], table_z=None)
        executor.execute("list_objects", {})
        before = len(robot.moves)
        with self.assertRaisesRegex(ValueError, "table height"):
            executor.execute("pick", {"object_id": "obj_1"})
        self.assertEqual(len(robot.moves), before, "the arm must not go down through the object on top")
        self.assertIsNone(executor.holding)

    def test_you_cannot_put_something_on_a_covered_object(self):
        executor, _, scene = make([RED_UNDER, BLUE_ON_TOP, Thing("obj_3", "green cube", (200, -120, 25))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_3"})
        with self.assertRaisesRegex(ValueError, "nothing can be put on it"):
            executor.execute("place_on", {"object_id": "obj_1"})

    def test_nothing_is_covered_when_objects_are_side_by_side(self):
        executor, _, _ = make([Thing("obj_1", "red cube", (220, -60, 25)), Thing("obj_2", "blue cube", (220, 60, 25))])
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        self.assertTrue(all("covered_by" not in o for o in listed["objects"]))
        self.assertNotIn("note", listed)

    def test_uncovering_then_picking_works(self):
        executor, robot, scene = make([RED_UNDER, BLUE_ON_TOP])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_2"})                     # the model may also do it step by step
        executor.execute("place_free", {"where": "near_base"})
        scene.things = [Thing("obj_1", "red cube", (280, 0, 25)), Thing("obj_2", "blue cube", (180, 0, 25))]
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertEqual(executor.holding, "red cube")

    def test_a_hidden_object_is_remembered_after_stacking(self):
        executor, _, scene = make([Thing("obj_1", "red cube", (220, -60, 25)), Thing("obj_2", "blue cube", (220, 60, 25))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        executor.execute("place_on", {"object_id": "obj_2"})
        scene.things = [Thing("obj_1", "red cube", (220, 60, 50))]            # the camera only sees the top of the pile
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        self.assertEqual(listed["hidden"], [{"label": "blue cube", "under": "red cube"}])

    def test_the_memory_of_a_pile_is_dropped_when_the_pile_changes(self):
        executor, _, scene = make([Thing("obj_1", "red cube", (220, -60, 25)), Thing("obj_2", "blue cube", (220, 60, 25))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        executor.execute("place_on", {"object_id": "obj_2"})
        scene.things = [Thing("obj_1", "red cube", (220, 60, 50))]
        self.assertTrue(ast.literal_eval(executor.execute("list_objects", {}))["hidden"])
        scene.things = [Thing("obj_1", "red cube", (150, 0, 25)), Thing("obj_2", "blue cube", (220, 60, 25))]   # someone moved them
        self.assertNotIn("hidden", ast.literal_eval(executor.execute("list_objects", {})))


class PlaceFreeTests(unittest.TestCase):
    def setUp(self):
        self.executor, self.robot, self.scene = make(
            [Thing("obj_1", "red cube", (280, 0, 25)), Thing("obj_2", "blue cube", (220, 60, 25))])
        self.executor.execute("list_objects", {})
        self.executor.execute("pick", {"object_id": "obj_1"})

    def put(self, **args):
        self.robot.moves.clear()
        self.executor.execute("place_free", args)
        return self.robot.moves[1]                     # the move down to the spot

    def test_near_base_is_as_close_as_the_arm_can_reach_and_clear_of_objects(self):
        spot = self.put(where="near_base")
        self.assertLess(math.hypot(spot.x, spot.y), 200.0)
        self.assertGreaterEqual(math.hypot(spot.x, spot.y), 160.0)
        self.assertGreater(math.hypot(spot.x - 220, spot.y - 60), CLEARANCE_MM)
        self.assertIsNone(self.executor.holding)

    def test_the_object_is_lowered_onto_the_table_not_dropped_from_above(self):
        spot = self.put(where="near_base")
        self.assertAlmostEqual(spot.z, 25.0 + RELEASE_GAP_MM, delta=0.01)   # its own height above the table, plus the gap

    def test_left_right_and_far_go_to_different_sides(self):
        spots = {}
        for where in ("left", "right", "far"):
            spots[where] = self.put(where=where)
            self.scene.things = [Thing("obj_1", "red cube", (spots[where].x, spots[where].y, 25)),
                                 Thing("obj_2", "blue cube", (220, 60, 25))]
            self.executor.execute("list_objects", {})
            self.executor.execute("pick", {"object_id": "obj_1"})
        self.assertGreater(spots["left"].y, 50)
        self.assertLess(spots["right"].y, -50)
        self.assertGreater(math.hypot(spots["far"].x, spots["far"].y), 240.0)

    def test_two_objects_put_down_without_a_look_in_between_do_not_share_a_spot(self):
        first = self.put(where="near_base")
        self.executor.holding = "blue cube"                # (pretend the second one was picked up meanwhile)
        second = self.put(where="near_base")
        self.assertGreaterEqual(math.hypot(first.x - second.x, first.y - second.y), CLEARANCE_MM)

    def test_next_to_needs_an_object(self):
        with self.assertRaisesRegex(ValueError, "object_id"):
            self.executor.execute("place_free", {"where": "next_to"})

    def test_next_to_lands_near_that_object_but_not_on_it(self):
        spot = self.put(where="next_to", object_id="obj_2")
        distance = math.hypot(spot.x - 220, spot.y - 60)
        self.assertGreaterEqual(distance, CLEARANCE_MM)
        self.assertLess(distance, CLEARANCE_MM + 25)

    def test_unknown_table_height_is_refused_with_a_reason(self):
        executor, _, _ = make([Thing("obj_1", "red cube", (280, 0, 25))], table_z=None)
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        with self.assertRaisesRegex(ValueError, "table height"):
            executor.execute("place_free", {"where": "far"})
        self.assertEqual(executor.holding, "red cube", "still holding it: nothing was dropped")

    def test_nothing_held_is_refused(self):
        executor, _, _ = make([Thing("obj_1", "red cube", (280, 0, 25))])
        executor.execute("list_objects", {})
        with self.assertRaisesRegex(ValueError, "Nothing is being held"):
            executor.execute("place_free", {"where": "far"})

    def test_nothing_held_says_the_calls_to_make(self):
        # (V4.3 twin chain 1, S-14: told only "pick an object up first", Qwen wrote 512 tokens about it)
        executor, _, _ = make([Thing("obj_1", "red cube", (280, 0, 25)), Thing("obj_2", "blue cube", (200, -80, 25))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        executor.execute("place_free", {})
        with self.assertRaises(ValueError) as caught:
            executor.execute("place_beside", {"object_id": "obj_1", "side": "left", "gap_mm": 40})
        said = str(caught.exception)
        self.assertTrue(said.startswith("Nothing is being held"), said)     # (how the watcher counts it: wasted)
        self.assertIn('pick(object_id="obj_1")', said)
        self.assertIn("the object to put it beside", said)

    def test_the_held_object_is_not_where_it_goes(self):
        # (V4.3 twin chain 2, S-14: "to the left of the blue cube" with the blue cube in the gripper, done)
        executor, _, _ = make([Thing("obj_1", "red cube", (280, 0, 25)), Thing("obj_2", "blue cube", (200, -80, 25))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        for tool, args in (("place_beside", {"object_id": "obj_1", "side": "left", "gap_mm": 40}),
                           ("place_on", {"object_id": "obj_1"})):
            with self.assertRaises(ValueError) as caught:
                executor.execute(tool, args)
            self.assertIn("the red cube itself", str(caught.exception))
            self.assertIn("the blue cube (obj_2)", str(caught.exception))
        self.assertEqual(executor.holding, "red cube", "still holding it: nothing was put down")
        executor.execute("place_beside", {"object_id": "obj_2", "side": "left", "gap_mm": 40})
        self.assertIsNone(executor.holding)


class PlaceBesideTests(unittest.TestCase):
    """'Put the red cube on the right side of the blue cube, 10 mm apart' used to stack it on top:
    there was no tool for beside-at-a-distance, so the model reached for place_on."""

    def setUp(self):
        self.executor, self.robot, self.scene = make(
            [Thing("obj_1", "red cube", (280, 0, 25)), Thing("obj_2", "blue cube", (221, 58, 25))])
        self.executor.execute("list_objects", {})
        self.executor.execute("pick", {"object_id": "obj_1"})

    def put(self, **args):
        self.robot.moves.clear()
        result = self.executor.execute("place_beside", args)
        return self.robot.moves[1], result             # the move down to the spot

    def test_right_side_ten_mm_apart_is_beside_not_on_top(self):
        spot, result = self.put(object_id="obj_2", side="right", gap_mm=10)
        self.assertAlmostEqual(spot.x, 221.0)
        self.assertAlmostEqual(spot.y, 58.0 - (12.5 + 10 + 12.5))      # the robot's right is -y
        self.assertAlmostEqual(spot.z, 25.0 + RELEASE_GAP_MM)            # on the table, like the blue cube
        self.assertIn("10 mm apart", result)
        self.assertIsNone(self.executor.holding)

    def test_every_side(self):
        expected = {"left": (221, 93), "front": (256, 58), "behind": (186, 58)}
        for side, (x, y) in expected.items():
            self.executor.holding = "red cube"
            spot, _ = self.put(object_id="obj_2", side=side, gap_mm=10)
            self.assertAlmostEqual((spot.x, spot.y), (x, y), msg=side)

    def test_too_small_a_gap_is_refused_without_moving(self):
        self.robot.moves.clear()
        with self.assertRaisesRegex(ValueError, "too small"):
            self.executor.execute("place_beside", {"object_id": "obj_2", "side": "right", "gap_mm": 2})
        self.assertEqual(self.robot.moves, [])
        self.assertEqual(self.executor.holding, "red cube")

    def test_a_spot_taken_by_another_object_is_refused(self):
        self.scene.things.append(Thing("obj_3", "green cube", (221, 23, 25)))
        self.executor.execute("list_objects", {})
        with self.assertRaisesRegex(ValueError, "taken by the green cube"):
            self.executor.execute("place_beside", {"object_id": "obj_2", "side": "right", "gap_mm": 10})

    def test_unknown_side_is_refused(self):
        with self.assertRaisesRegex(ValueError, "Unknown side"):
            self.executor.execute("place_beside", {"object_id": "obj_2", "side": "north", "gap_mm": 10})

    def test_the_model_is_told_beside_is_not_on_top(self):
        from app.llm.agent import SYSTEM_PROMPT
        self.assertIn("place_beside", SYSTEM_PROMPT)
        self.assertIn("BESIDE is not ON TOP", SYSTEM_PROMPT)



class RealArmFrameTests(unittest.TestCase):
    def test_reach_is_judged_from_the_table_not_the_arms_own_zero(self):
        """The real Dobot measures heights from its own zero, with the table some 60 mm below it: judged by the arm
        model (heights from the table) as they were, its working heights were out of reach, and detours refused."""
        executor, _, _ = make([], table_z=-58.6)
        self.assertTrue(executor._can_reach(Pose(220, 0, -40)), "18 mm above the real table")
        self.assertFalse(executor._can_reach(Pose(220, 0, 400)))
        demo, _, _ = make([], table_z=0.0)
        self.assertTrue(demo._can_reach(Pose(220, 0, 18)))
        unknown, _, _ = make([], table_z=None)
        self.assertTrue(unknown._can_reach(Pose(220, 0, -40)), "no table height: the model can't judge")

    def test_near_the_base_a_pick_comes_down_from_lower_where_the_arm_can_reach(self):
        """Study 2, S-06_Run1: 50 mm above a cube 160 mm from the base needs the Dobot's rear arm 6 degrees past
        upright; the controller refused it (alarm 0x12) and then every move until it was switched off and on."""
        from app.hardware import dobot_arm
        from app.llm.tools import MIN_APPROACH_MM, PICK_APPROACH_HEIGHT_MM
        near = Thing("obj_1", "red cube", (146, -69, 25))
        executor, robot, _ = make([near], table_z=0.0)          # (the twin's frame: judged as the lab's would be)
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertEqual(executor.holding, "red cube")
        for move in robot.moves:
            problem = dobot_arm.reach_problem(move.x, move.y, move.z + dobot_arm.LAB_TABLE_Z_MM)
            self.assertIsNone(problem, f"a move the controller would refuse: {problem}")
        above = max(m.z for m in robot.moves if math.hypot(m.x - 146, m.y + 69) < 1.0)
        self.assertLess(above, 25 + PICK_APPROACH_HEIGHT_MM, "lower than the usual approach")
        self.assertGreaterEqual(above, 25 + MIN_APPROACH_MM)
        self.assertIn("approach", executor.last_record, "said in the record")
        far = Thing("obj_1", "red cube", (230, 0, 25))         # further out: the usual 50 mm
        executor, robot, _ = make([far], table_z=0.0)
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        self.assertAlmostEqual(max(m.z for m in robot.moves if math.hypot(m.x - 230, m.y) < 1.0),
                               25 + PICK_APPROACH_HEIGHT_MM, delta=0.01)

    def test_starting_low_it_rises_first_only_when_the_table_height_is_known(self):
        executor, robot, _ = make([], table_z=-58.6)
        robot.pose = Pose(220, 0, -45)
        executor._travel(Pose(150, 100, -20))
        self.assertEqual((robot.moves[0].x, robot.moves[0].y), (220, 0), "straight up first")
        self.assertGreater(robot.moves[0].z, -45 + 15)
        unknown, robot, _ = make([], table_z=None)
        robot.pose = Pose(220, 0, -45)
        unknown._travel(Pose(150, 100, -20))
        self.assertEqual((robot.moves[0].x, robot.moves[0].y), (150, 100), "no table height: as before")


class CubeSizeTests(unittest.TestCase):
    """Study 2's lab notes: 20 or 25 mm cubes, the size set beside them. Cubes clearly measuring the other size: nothing
    moves until the user sets it (or says to keep it)."""

    def make(self, measured):
        executor, robot, scene = make([Thing("obj_1", "red cube", (230, 0, 20))])
        scene.known_sizes = {"cube": 25.0}
        scene.measured_cube_mm = lambda: measured
        return executor, robot

    def test_cubes_of_the_other_size_stop_the_arm(self):
        executor, robot = self.make(20.2)
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        self.assertIn("measure about 20 mm", listed["cube_size_warning"])
        with self.assertRaisesRegex(ValueError, "Not moving: the cubes on the table measure about 20 mm"):
            executor.execute("pick", {"object_id": "obj_1"})
        self.assertEqual(robot.moves, [])
        executor.cube_size_kept = (25.0, 20.0)                  # the user said to keep 25 mm
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        self.assertNotIn("cube_size_warning", listed)
        self.assertIn("Picked up red cube", executor.execute("pick", {"object_id": "obj_1"}))

    def test_cubes_that_measure_the_size_set_move(self):
        for measured in (24.1, 22.6, None):
            executor, _ = self.make(measured)
            listed = ast.literal_eval(executor.execute("list_objects", {}))
            self.assertNotIn("cube_size_warning", listed)
            self.assertIn("Picked up red cube", executor.execute("pick", {"object_id": "obj_1"}))

    def test_found_out_while_one_is_held_it_is_put_down_not_left_hanging(self):
        # (the size is judged from a few looks: the first pick can come before -- the live test, 20 mm cubes, 25 set)
        executor, robot = self.make(None)
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        executor.scene_builder.measured_cube_mm = lambda: 20.2
        executor.execute("list_objects", {})
        self.assertIsNotNone(executor.cube_mismatch)
        executor.execute("place", {"x": 200, "y": -80, "z": 20})
        self.assertIsNone(executor.holding, "put down")
        with self.assertRaisesRegex(ValueError, "Not moving: the cubes on the table measure about 20 mm"):
            executor.execute("pick", {"object_id": "obj_1"})

class MissedGripTests(unittest.TestCase):
    """This round's E3 (the realistic twin): a grip missed the "green cylinder"; looked at again, it was a "green cube"
    -- "can't be seen now", and the task failed. Looked for again by its colour near where it was."""

    def test_a_missed_grip_finds_its_cube_again_when_its_shape_is_named_another_way(self):
        executor, robot, scene = make([Thing("obj_1", "green cylinder", (230, 0, 12)),
                                       Thing("obj_2", "blue cube", (230, -70, 12))])
        grips = []

        def close_gripper():
            grips.append(1)
            robot.held_object = None if len(grips) == 1 else "green_cube"    # the first grip misses
        robot.held_object, robot.close_gripper = "", close_gripper
        robot.last_grip_problem = "the fingers came down 1.6 mm off the green cube's middle, onto its edge"
        executor.execute("list_objects", {})
        scene.things = [Thing("obj_3", "green cube", (231, 1, 12)), Thing("obj_2", "blue cube", (230, -70, 12))]
        said = executor.execute("pick", {"object_id": "obj_1"})
        self.assertIn("The first grip missed the green cylinder; looked again and picked it once more", said)
        self.assertEqual(executor.holding, "green cube")
        self.assertEqual(len(grips), 2)

    def test_one_of_another_colour_or_far_off_is_not_taken_for_it(self):
        executor, robot, scene = make([Thing("obj_1", "green cylinder", (230, 0, 12))])
        robot.held_object, robot.close_gripper = "", lambda: setattr(robot, "held_object", None)
        executor.execute("list_objects", {})
        scene.things = [Thing("obj_3", "green cube", (180, 90, 12)), Thing("obj_4", "blue cube", (231, 1, 12))]
        with self.assertRaisesRegex(ValueError, "can't be seen now"):
            executor.execute("pick", {"object_id": "obj_1"})
        self.assertIsNone(executor.holding)


class EarlierIdTests(unittest.TestCase):
    """Study 2 (S-06_Run2, S-08_Run2, S-09_Run2, S-11_Run2): "Unknown object_id" six times, the cube in plain view -- it
    had a new id since it was moved. An id from an earlier look means the one cube of its colour seen now."""

    def test_an_earlier_id_finds_the_one_cube_of_its_colour(self):
        executor, _, scene = make([Thing("obj_1", "red cube", (230, 0, 20)), Thing("obj_2", "blue cube", (200, 80, 20))])
        executor.execute("list_objects", {})
        scene.things = [Thing("obj_7", "red cube", (180, -60, 20)), Thing("obj_2", "blue cube", (200, 80, 20))]
        executor.execute("list_objects", {})
        self.assertIn("Picked up red cube", executor.execute("pick", {"object_id": "obj_1"}))
        self.assertIn("obj_1 was the red cube in an earlier look: now obj_7", executor.last_record["target_from"])

    def test_two_of_that_colour_or_an_id_never_seen_is_still_unknown(self):
        executor, _, scene = make([Thing("obj_1", "red cube", (230, 0, 20))])
        executor.execute("list_objects", {})
        scene.things = [Thing("obj_7", "red cube", (180, -60, 20)), Thing("obj_8", "red block", (160, 60, 20))]
        executor.execute("list_objects", {})
        for object_id in ("obj_1", "obj_99"):
            with self.assertRaisesRegex(ValueError, f"Unknown object_id: {object_id}"):
                executor.execute("pick", {"object_id": object_id})
        executor.forget_scene()                                # (a new table: the old ids mean nothing)
        scene.things = [Thing("obj_9", "red cube", (180, -60, 20))]
        executor.execute("list_objects", {})
        with self.assertRaisesRegex(ValueError, "Unknown object_id: obj_1"):
            executor.execute("pick", {"object_id": "obj_1"})

class PutDownAgainTests(unittest.TestCase):
    """Study 2, S-20 in the twin: move_object put the blue cube down 40 mm nearer, as asked; the model then called
    place_at, was told to pick it up again, and carried it off to a saved place -- a fail."""

    def test_a_step_that_already_put_it_down_is_said_to_be_done(self):
        executor, _, _ = make([Thing("obj_1", "blue cube", (230, 90, 20)), Thing("obj_2", "red cube", (230, -60, 20))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        moved = executor.execute("move_object", {"object_id": "obj_1", "direction": "back", "distance_mm": 40})
        self.assertIn("put it down there: nothing is held now", moved)
        with self.assertRaises(ValueError) as again:
            executor.execute("place_free", {})
        self.assertIn("The blue cube was put down by the last step (move_object)", str(again.exception))
        self.assertIn("that move is done. If that is where the task wants it, don't pick it up again",
                      str(again.exception))

    def test_otherwise_the_hint_to_pick_it_stays(self):
        executor, _, _ = make([Thing("obj_1", "blue cube", (230, 90, 20))])
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": "obj_1"})
        executor.execute("place_free", {})
        executor.execute("list_objects", {})                   # (a step between: the put-down isn't the last step)
        with self.assertRaises(ValueError) as again:
            executor.execute("place_free", {})
        self.assertIn("call pick(", str(again.exception))


if __name__ == "__main__":
    unittest.main()

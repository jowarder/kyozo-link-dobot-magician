"""Behaviour the simulator doesn't have on its own, but real hardware does.

    python -m unittest discover -s tests -p test_hardware_realism.py -v

A real camera returns picture memory that may be read-only and reused, and queues pictures so
the one you get can be a little old. A real robot can refuse a move. None of that may break
the calibration procedures.
"""
from __future__ import annotations

import collections
import math
import unittest

import numpy as np

from harness import Sim, cube_errors, touch_table
from app.calibration.auto import FLUSH_FRAMES, run_auto_calibration, wrist_angles_for
from app.calibration.guidance import MIN_RADIUS_MM, build_cells
from app.hardware.dobot import DobotRobot
from app.hardware.interfaces import Frame, Pose
from app.vision.drift import capture_reference, check_view
from app.vision.table import measure_table


class RealCameraLike:
    """Wraps a camera the way a real one behaves: read-only pictures, and a queue that makes
    each picture `lag` calls old."""

    def __init__(self, camera, lag: int = FLUSH_FRAMES):
        self.camera = camera
        self.queue: collections.deque = collections.deque()
        self.lag = lag

    def get_frame(self) -> Frame:
        fresh = self.camera.get_frame()
        self.queue.append(fresh)
        frame = self.queue[0] if len(self.queue) <= self.lag else self.queue.popleft()
        rgb, depth = frame.rgb.copy(), frame.depth.copy()
        rgb.setflags(write=False)
        depth.setflags(write=False)
        return Frame(rgb=rgb, depth=depth, intrinsics=frame.intrinsics)

    def get_intrinsics(self):
        return self.camera.get_intrinsics()


class RefusingRobot:
    """Passes everything to a robot, but refuses the Nth move like a robot that hit an alarm."""

    def __init__(self, robot, fail_on: int):
        self._robot, self._fail_on, self._moves = robot, fail_on, 0

    def move_to(self, pose, speed=None):
        self._moves += 1
        if self._moves == self._fail_on:
            raise RuntimeError("Robot is E-stopped.")
        return self._robot.move_to(pose, speed)

    def __getattr__(self, name):
        return getattr(self._robot, name)


class RealHardwareTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim(marker_offset_mm=(9.0, -6.0))
        self.addCleanup(self.sim.close)

    def test_calibration_survives_laggy_read_only_pictures(self):
        camera = RealCameraLike(self.sim.camera)
        self.sim.move(200, 0, 70)
        outcome = run_auto_calibration(self.sim.robot, camera, self.sim.bounds, 300.0, 30.0)
        self.assertGreaterEqual(len(outcome.sightings), 6, "the marker is found despite stale pictures")
        self.assertIsNotNone(outcome.wrist, outcome.wrist_note)
        self.assertAlmostEqual(outcome.wrist.offset_xy_mm[0], 9.0, delta=2.0)
        self.assertAlmostEqual(outcome.wrist.offset_xy_mm[1], -6.0, delta=2.0)
        transform, _ = touch_table(self.sim, outcome.transform)
        for label, (plane_error, height_error) in cube_errors(self.sim, transform).items():
            self.assertLess(plane_error, 7.0, label)
            self.assertLess(abs(height_error), 3.0, label)

    def test_table_and_camera_checks_work_on_read_only_pictures(self):
        camera = RealCameraLike(self.sim.camera)
        transform = self.sim.exact_transform()
        self.assertIsNotNone(measure_table(camera, transform))
        reference = capture_reference(camera, transform)
        self.assertEqual(check_view(camera, transform, reference).status, "ok")

    def test_a_refused_move_stops_the_sweep_with_an_error(self):
        self.sim.move(200, 0, 70)
        with self.assertRaises(RuntimeError):
            run_auto_calibration(RefusingRobot(self.sim.robot, fail_on=4), self.sim.camera, self.sim.bounds, 300.0, 30.0)

    def test_cancelling_leaves_no_result(self):
        self.sim.move(200, 0, 70)
        calls = {"n": 0}

        def cancel():
            calls["n"] += 1
            return calls["n"] > 2
        outcome = run_auto_calibration(self.sim.robot, self.sim.camera, self.sim.bounds, 300.0, 30.0, cancel=cancel)
        self.assertTrue(outcome.cancelled)
        self.assertIsNone(outcome.transform)


class SafetyLimitTests(unittest.TestCase):
    def test_wrist_is_never_asked_beyond_its_range(self):
        for start in (-70.0, -30.0, 0.0, 45.0, 75.0):
            angles = wrist_angles_for(start)
            self.assertTrue(all(-80.0 <= start + a <= 80.0 for a in angles), (start, angles))
        self.assertGreaterEqual(len(wrist_angles_for(0.0)), 4)

    def test_no_calibration_spot_is_too_near_the_base_to_reach_the_table(self):
        config_bounds = {"x": [-300.0, 307.0], "y": [-300.0, 300.0], "z": [-58.6, 300.0]}
        cells = [c for c in build_cells(config_bounds, 300.0) if c.usable]
        self.assertTrue(cells)
        for cell in cells:
            self.assertGreaterEqual(float(np.hypot(*cell.centre)), MIN_RADIUS_MM)

    def test_a_target_too_close_to_the_base_column_is_pushed_out_to_a_reachable_ring(self):
        """A too-close target used to make the simplified 2-link solve fold the arm back on
        itself (shoulder past -170 degrees) instead of just refusing -- ugly, and not something
        a real arm would do either. It should land on the MIN_RADIUS_MM ring instead, same bearing."""
        sim = Sim()
        try:
            sim.robot.move_to(Pose(x=2.0, y=-12.0, z=30.0))
            pose = sim.robot.get_pose()
            self.assertGreaterEqual(np.hypot(pose.x, pose.y), MIN_RADIUS_MM - 0.5)
            self.assertAlmostEqual(math.atan2(pose.y, pose.x), math.atan2(-12.0, 2.0), places=2)
            geometry, _ = sim.robot.arm_state()
            self.assertGreater(geometry.shoulder[2] - 1.0, 0.0)   # a sane pose, not folded back past vertical
        finally:
            sim.close()

    def test_the_simulated_arm_also_refuses_a_diagonal_target_beyond_its_reach(self):
        """Box bounds alone don't stop a diagonal target: (238, 233) is inside both the x and y
        bounds individually, but ~333 mm out -- well past the arm's reach. Only DobotRobot (the real
        driver) used to cap this; the simulated one didn't, so it could be driven straight through
        the reach arc shown in the 3D view while still satisfying the box bounds."""
        sim = Sim()
        try:
            sim.robot.move_to(Pose(x=238.0, y=233.0, z=30.0))
            pose = sim.robot.get_pose()
            self.assertLessEqual(np.hypot(pose.x, pose.y), sim.robot.max_reach_mm + 0.5)
            self.assertAlmostEqual(math.atan2(pose.y, pose.x), math.atan2(233.0, 238.0), places=2)
        finally:
            sim.close()

    def test_the_same_holds_for_the_real_driver(self):
        bounds = {"x": [-300.0, 307.0], "y": [-300.0, 300.0], "z": [-58.6, 300.0]}
        robot = DobotRobot(port="FAKE", workspace_bounds=bounds)
        clamped = robot.clamp_pose(Pose(x=2.0, y=-12.0, z=30.0))
        self.assertGreaterEqual(np.hypot(clamped.x, clamped.y), MIN_RADIUS_MM - 0.5)
        self.assertAlmostEqual(math.atan2(clamped.y, clamped.x), math.atan2(-12.0, 2.0), places=2)
        # exactly at the base column: there is no bearing to preserve, but it must still not divide by zero
        centre = robot.clamp_pose(Pose(x=0.0, y=0.0, z=30.0))
        self.assertAlmostEqual(np.hypot(centre.x, centre.y), MIN_RADIUS_MM, places=1)
        # comfortably out of range already: left alone
        far = robot.clamp_pose(Pose(x=250.0, y=0.0, z=30.0))
        self.assertAlmostEqual(far.x, 250.0, places=1)


if __name__ == "__main__":
    unittest.main()

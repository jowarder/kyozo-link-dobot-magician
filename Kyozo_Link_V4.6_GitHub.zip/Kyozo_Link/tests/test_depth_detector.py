"""Finding objects by depth: any colour, named by colour and shape (vision/depth_detector.py).

    python -m unittest discover -s tests -p test_depth_detector.py -v

Demo mode (the simulated depth camera); nothing in the project changes.
"""
from __future__ import annotations

import ast
import math
import unittest

import numpy as np

from harness import LOOK_POSE, Sim

from app.hardware.gripper import GripperSpec
from app.hardware.interfaces import Pose
from app.llm.tools import ToolExecutor
from app.llm.trace import match_phrase
from app.twin.shuffle import shuffle_turns
from app.twin.world import list_scenarios
from app.vision.depth_detector import DepthObjectDetector, colour_name, shape_name
from app.vision.scene import SceneBuilder


class Setup(unittest.TestCase):
    def setUp(self):
        self.sim = Sim(gripper=GripperSpec())
        self.addCleanup(self.sim.close)
        self.sim.robot.move_to(LOOK_POSE)
        self.world = self.sim.world
        transform = self.sim.exact_transform()
        self.detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: self.sim.robot.arm_state()[0],
                                            self.world.places, self.world.place_areas)
        self.scene = SceneBuilder(self.sim.camera, self.detector, transform)
        self.executor = ToolExecutor(self.sim.robot, self.scene, look_pose=LOOK_POSE, table_z_provider=lambda: 0.0,
                                     places_provider=self.world.places, gripper=GripperSpec())

    def load(self, name: str) -> None:
        self.world.switch_scenario(name)
        self.scene.reset_tracking()
        self.executor.forget_scene()

    def truth(self) -> dict:
        return {m["label"]: (self.world.get_object_position_mm(i), m) for i, m in self.world.object_meta.items()
                if m["shape"] != "tray"}

    def listed(self) -> dict:
        return {o["label"]: o for o in ast.literal_eval(self.executor.execute("list_objects", {}))["objects"]}


class FindingTests(Setup):
    def check_scene(self, why: str) -> None:
        seen = self.scene.get_scene()
        truth = self.truth()
        self.assertEqual(sorted(o.label for o in seen), sorted(truth), why)
        for o in seen:
            (x, y, z), meta = truth[o.label]
            round_one = meta["shape"] == "ball"   # its far side is hidden from the camera
            self.assertLess(math.dist(o.xyz_robot[:2], (x, y)), 3.0 if round_one else 1.0, f"{why}: {o.label}")
            self.assertAlmostEqual(o.xyz_robot[2], z + meta["size"][2] / 2, delta=2.0, msg=f"{why}: {o.label}")
            if not round_one:
                width, length = sorted(meta["size"][:2])
                self.assertAlmostEqual(o.footprint[0], width, delta=1.5, msg=f"{why}: {o.label}")
                self.assertAlmostEqual(o.footprint[1], length, delta=1.5, msg=f"{why}: {o.label}")

    def test_every_scene_every_object_once_by_the_right_name_and_nothing_else(self):
        for scene in list_scenarios():
            self.load(scene["name"])
            self.check_scene(scene["name"])

    def test_turned_objects_too(self):
        self.load("mixed_objects")
        turns = shuffle_turns(self.world.object_ids, 5)
        for object_id, meta in self.world.object_meta.items():
            if meta["shape"] != "tray":
                x, y, z = self.world.get_object_position_mm(object_id)
                self.world.set_object_position_mm(object_id, x, y, z, turns[object_id])
        self.check_scene("turned")

    def test_a_cube_in_the_tray_is_found_and_the_tray_is_not(self):
        self.load("two_blocks_and_tray")
        blue = next(i for i, m in self.world.object_meta.items() if m["label"] == "blue cube")
        self.world.set_object_position_mm(blue, 280.0, 0.0, 4.0 + 12.5)
        seen = {o.label: o for o in self.scene.get_scene()}
        self.assertEqual(sorted(seen), ["blue cube", "green cube", "red cube"])
        self.assertLess(math.dist(seen["blue cube"].xyz_robot[:2], (280.0, 0.0)), 1.0)

    def test_the_arm_is_not_an_object(self):
        self.load("two_blocks_and_tray")
        self.sim.robot.move_to(Pose(200.0, -10.0, 30.0, 0.0))     # low over the table, in the camera's view
        self.assertEqual(sorted(o.label for o in self.scene.get_scene()), ["blue cube", "green cube", "red cube"])

    def test_a_stack_built_by_hand_shows_the_one_under_it_by_the_colour_of_its_sides(self):
        """The robot didn't build it, so there is no memory of it: the red sides below the blue ones give it away."""
        self.load("two_blocks_and_tray")
        ids = {m["label"]: i for i, m in self.world.object_meta.items()}
        self.world.set_object_position_mm(ids["red cube"], 280.0, 0.0, 4.0 + 12.5)       # in the tray...
        self.world.set_object_position_mm(ids["blue cube"], 280.0, 0.0, 4.0 + 25.0 + 12.5)   # ...the blue one on it
        listed = self.listed()
        self.assertEqual(sorted(listed), ["blue cube", "green cube", "red cube"])
        self.assertEqual(listed["red cube"].get("covered_by"), "blue cube")
        self.assertAlmostEqual(listed["red cube"]["xyz_mm"][2], 29, delta=3)
        self.assertEqual(len(self.scene.get_scene()), 3, "and no more (the stack, and the green cube)")

    def test_a_stack_the_robot_built_shows_both(self):
        self.load("two_blocks_and_tray")
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["red cube"]["id"]})
        self.executor.execute("place_on", {"object_id": listed["blue cube"]["id"]})
        after = {o["label"]: o for o in ast.literal_eval(self.executor.execute("list_objects", {}))["objects"]}
        self.assertEqual(sorted(after), ["blue cube", "green cube", "red cube"], "the blue one's sides show under the red one")
        self.assertEqual(after["blue cube"]["covered_by"], "red cube")


class RealCalibrationTests(Setup):
    def test_a_calibration_tilted_a_little_doesnt_make_the_table_objects(self):
        """On the real arm (calibrated to 15 mm), the table came out 1.5 degrees off level in the arm's frame: measured
        from one height, parts of the mat were 6 mm "up", and some sixty bits of it were reported as objects."""
        from app.twin.kinematics import arm_geometry
        self.load("two_blocks_and_tray")
        exact = self.sim.exact_transform()
        tilt = math.radians(1.5)
        c, s = math.cos(tilt), math.sin(tilt)
        about = np.array([220.0, 0.0, 0.0])
        rotate = np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])     # about the y axis, through the work area
        tilted = exact.copy()
        tilted[:3, :3] = rotate @ exact[:3, :3]
        tilted[:3, 3] = rotate @ (exact[:3, 3] - about) + about
        detector = DepthObjectDetector(lambda: tilted, lambda: 0.0, lambda: self.sim.robot.arm_state()[0],
                                       self.world.places, self.world.place_areas)
        frame = self.sim.camera.get_frame()
        seen = sorted(loc.label for _, loc in detector.find(frame.rgb, frame.depth, frame.intrinsics, tilted))
        self.assertEqual(seen, ["blue cube", "green cube", "red cube"])
        # the real arm's heights are from its own zero: the arm is placed in that frame, not 35 mm off
        low, high = arm_geometry(200, 0, 50), arm_geometry(200, 0, 50 - 35.0, table_z=-35.0)
        self.assertAlmostEqual(high.tcp[2], 15.0)
        self.assertAlmostEqual(high.elbow[2], low.elbow[2] - 35.0)


class NamingTests(unittest.TestCase):
    def test_colour_names(self):
        def named(rgb):
            return colour_name(np.array([rgb] * 20, np.uint8))
        self.assertEqual(named((235, 235, 230)), "white")
        self.assertEqual(named((18, 18, 20)), "black")
        self.assertEqual(named((140, 142, 148)), "grey")
        self.assertEqual(named((140, 92, 51)), "brown")
        self.assertEqual(named((255, 128, 20)), "orange")
        self.assertEqual(named((205, 25, 25)), "red")
        self.assertEqual(named((230, 200, 25)), "yellow")
        self.assertEqual(named((25, 180, 50)), "green")
        self.assertEqual(named((25, 60, 215)), "blue")
        self.assertEqual(named((140, 40, 200)), "purple")
        # reds either side of the hue circle's seam are still red (not the cyan their plain average would be)
        self.assertEqual(colour_name(np.array([(210, 20, 30)] * 10 + [(210, 30, 20)] * 10, np.uint8)), "red")

    def test_a_cube_seen_by_its_sides_under_a_blue_one_is_green_not_teal(self):
        # study 3, S-14: a green cube's shaded sides with the blue cube's edge mixed in averaged to "teal", and "the
        # green cube" was refused as not on the table
        from app.vision.depth_detector import under_colour
        sides = np.array([(40, 110, 60)] * 25 + [(30, 60, 200)] * 25, np.uint8)
        self.assertEqual(colour_name(sides), "teal")
        self.assertEqual(under_colour(sides, "blue"), "green")
        self.assertEqual(under_colour(np.array([(205, 25, 25)] * 20, np.uint8), "blue"), "red")

    def test_shape_names(self):
        self.assertEqual(shape_name(25, 25, 25, False, False), "cube")
        self.assertEqual(shape_name(20, 40, 20, False, False), "block")
        self.assertEqual(shape_name(10, 60, 10, False, False), "bar")
        self.assertEqual(shape_name(24, 24, 30, True, False), "cylinder")
        self.assertEqual(shape_name(22, 22, 22, True, True), "ball")
        self.assertEqual(shape_name(30, 30, 4, True, False), "disc")
        self.assertEqual(shape_name(30, 40, 4, False, False), "flat piece")

    def test_the_model_tab_matches_the_new_names(self):
        objects = [{"id": "obj_1", "label": "brown block"}, {"id": "obj_2", "label": "orange ball"},
                   {"id": "obj_3", "label": "blue bar"}]
        self.assertEqual(match_phrase("wooden block", objects, [], "object")["best"], "brown block (obj_1)")
        self.assertEqual(match_phrase("the ball", objects, [], "object")["best"], "orange ball (obj_2)")
        self.assertEqual(match_phrase("blue pen", objects, [], "object")["best"], "blue bar (obj_3)")


class WorkingWithThemTests(Setup):
    def test_pick_and_place_objects_the_colour_detector_never_saw(self):
        self.load("mixed_objects")
        ids = {m["label"]: i for i, m in self.world.object_meta.items()}
        listed = self.listed()
        self.assertEqual(listed["orange ball"]["footprint_mm"][0] <= 22, True)
        self.executor.execute("pick", {"object_id": listed["orange ball"]["id"]})
        self.assertEqual(self.sim.robot.held_object, ids["orange ball"], self.sim.robot.last_grip_problem)
        self.executor.execute("place_at", {"place_name": "tray"})
        ball = self.world.get_object_position_mm(ids["orange ball"])
        self.assertLess(max(abs(ball[0] - 280.0), abs(ball[1])), 36.0, "inside the tray (at a free spot in it)")
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["white cube"]["id"]})
        self.executor.execute("place_on", {"object_id": listed["black cube"]["id"]})
        wx, wy, wz = self.world.get_object_position_mm(ids["white cube"])
        bx, by, _ = self.world.get_object_position_mm(ids["black cube"])
        self.assertLess(math.dist((wx, wy), (bx, by)), 2.0)
        self.assertAlmostEqual(wz, 30.0, delta=1.5, msg="on the black cube")
        seen = {o["label"] for o in self.listed().values()}
        self.assertIn("orange ball", seen, "found again in the tray")


class FillingATrayTests(Setup):
    def test_things_go_in_side_by_side_and_a_full_tray_is_said_so(self):
        """"Clear the table into the tray": each object went to the tray's middle, down onto the one before (the real
        arm would drive into it), and the tray filled up as a wobbly tower."""
        self.load("mixed_objects")
        ids = {m["label"]: i for i, m in self.world.object_meta.items()}
        put, refused = [], []
        for label in ("orange ball", "white cube", "black cube", "grey cylinder", "brown block", "blue bar"):
            listed = self.listed()
            self.executor.execute("pick", {"object_id": listed[label]["id"]})
            try:
                self.executor.execute("place_at", {"place_name": "tray"})
                put.append(label)
            except ValueError as exc:
                refused.append((label, str(exc)))
                self.executor.execute("place_free", {"where": "near_base"})     # put it back down somewhere
        self.assertGreaterEqual(len(put), 3, (put, refused))
        self.assertTrue(refused, "six things don't fit an 80 mm tray")
        self.assertIn("is full", refused[0][1])
        for label in put:
            x, y, z = self.world.get_object_position_mm(ids[label])
            height = self.world.object_meta[ids[label]]["size"][2]
            self.assertLess(max(abs(x - 280.0), abs(y)), 36.0, f"{label} inside the tray")
            self.assertAlmostEqual(z, 4.0 + height / 2, delta=1.5, msg=f"{label} on the tray's floor, not on another")
        for a in put:
            for b in put:
                if a < b:
                    pa, pb = (self.world.get_object_position_mm(ids[n]) for n in (a, b))
                    self.assertGreater(math.dist(pa[:2], pb[:2]), 20.0, f"{a} and {b} apart")

    def test_two_cubes_go_side_by_side_in_a_bin(self):
        self.load("colour_sorting")
        ids = {m["label"]: i for i, m in self.world.object_meta.items()}
        for label in ("red cube", "yellow cube"):
            self.executor.execute("pick", {"object_id": self.listed()[label]["id"]})
            self.executor.execute("place_at", {"place_name": "warm bin"})
        red, yellow = (self.world.get_object_position_mm(ids[n]) for n in ("red cube", "yellow cube"))
        self.assertGreater(math.dist(red[:2], yellow[:2]), 28.0)
        self.assertAlmostEqual(red[2], yellow[2], delta=1.0, msg="both on the bin's floor")

    def test_a_saved_place_already_taken_is_refused(self):
        import tempfile
        from pathlib import Path
        self.load("two_blocks_and_tray")
        with tempfile.TemporaryDirectory() as folder:
            listed = self.listed()
            red = listed["red cube"]["xyz_mm"]
            # a place saved from the Manual tab right where the red cube is (its size isn't known: one spot)
            (Path(folder) / "shelf.json").write_text(f'{{"x": {red[0]}, "y": {red[1]}, "z": 40, "r": 0}}', encoding="utf-8")
            self.executor.poses_dir = Path(folder)
            self.executor.execute("pick", {"object_id": listed["blue cube"]["id"]})
            with self.assertRaisesRegex(ValueError, r"The red cube is already at the 'shelf' spot"):
                self.executor.execute("place_at", {"place_name": "shelf"})


class TrackingTests(unittest.TestCase):
    def test_an_object_named_a_little_differently_keeps_its_id(self):
        from app.vision.locator import LocatedObject

        class Named:
            names = iter(["white cube", "grey cube"])

            def locate(self, frame, transform):
                return [LocatedObject(next(self.names), (200.0, 0.0, 25.0), 1.0)]

        class Camera:
            def get_frame(self):
                return type("F", (), {"depth": np.zeros((2, 2)), "rgb": None, "intrinsics": None})()

        scene = SceneBuilder(Camera(), Named(), np.eye(4))
        first, second = scene.get_scene()[0], scene.get_scene()[0]
        self.assertEqual(first.id, second.id)
        self.assertEqual(second.label, "grey cube")


class NoisyCameraTests(unittest.TestCase):
    """With a real depth camera's noise (the demo's "Realistic" and "Poor" pictures), one cube was seen as two or three
    things -- "a purple bar", "a purple cylinder", "a purple ball" -- and the arm went for the pieces. Each object is
    now seen once. (Its shape can still come out wrong in a noisy picture: a cube as a cylinder.)"""

    SCENES = ("two_blocks_and_tray", "mixed_objects", "tower_building", "size_sorting", "colour_sorting")

    def looks(self, key: str, quality: str, seed: int):
        from collections import Counter
        from app import robots
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.twin.world import TwinWorld
        profile = robots.set_active(key)
        self.addCleanup(robots.set_active, "dobot_magician")
        for scene in self.SCENES:
            world = TwinWorld()
            client = world.start()
            try:
                world.load_scenario(scene)
                robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                                 max_reach_mm=profile.max_reach_mm, world=world)
                robot.connect()
                camera = SimCamera(client)
                camera.outline_bodies = robot.body_ids
                camera.connect()
                camera.set_faults(quality)
                camera._rng = np.random.default_rng(seed)
                robot.move_to(Pose(*profile.demo_look_pose))
                transform = camera.camera_to_robot_transform()
                detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: robot.arm_state()[0],
                                               world.places, world.place_areas)
                seen = [o.label for o in SceneBuilder(camera, detector, transform).get_scene()]
                truth = [m["label"] for m in world.object_meta.values() if m.get("shape") != "tray"]
                yield scene, Counter(seen), Counter(truth)
            finally:
                world.stop()

    def test_perfect_picture_every_object_by_name(self):
        for key in ("dobot_magician", "xarm6"):
            for scene, seen, truth in self.looks(key, "Perfect", 0):
                self.assertEqual(seen, truth, f"{key}, {scene}")

    def test_realistic_picture_each_object_once(self):
        # nothing seen twice, nothing that isn't there; at most one object missed (a 15 mm cube, 0.8 m from the
        # xArm's camera, can be lost in the noise now and then)
        from collections import Counter
        for key in ("dobot_magician", "xarm6"):
            for seed in (1, 2):
                for scene, seen, truth in self.looks(key, "Realistic", seed):
                    colours_seen = Counter(label.split()[0] for label in seen.elements())
                    colours_true = Counter(label.split()[0] for label in truth.elements())
                    self.assertFalse(colours_seen - colours_true, f"{key}, {scene}, seed {seed}: {dict(seen)}")
                    self.assertLessEqual(sum((colours_true - colours_seen).values()), 1,
                                         f"{key}, {scene}, seed {seed}: {dict(seen)}")

    def test_only_cubes_a_turned_cube_keeps_its_turn_in_a_noisy_picture(self):
        # the lab, 2026-10-22: depth noise rounded a cube's corners -- "blue cylinder", its turn set to 0 -- and a cube
        # turned ~35 degrees was gripped square and missed. With vision: cubes_only, never round: its own turn.
        from app import robots
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.twin.world import TwinWorld
        profile = robots.set_active("dobot_magician")
        world = TwinWorld()
        client = world.start()
        self.addCleanup(world.stop)
        world.switch_scenario("one_turned", {"name": "one_turned", "places": {}, "objects": [
            {"id": "blue_cube_0", "label": "blue cube", "color_rgba": [0.1, 0.2, 0.8, 1], "size_mm": 25.0,
             "position_mm": [220.0, 40.0, 12.5], "yaw_deg": 35.0}]})
        robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                         max_reach_mm=profile.max_reach_mm, world=world)
        robot.connect()
        camera = SimCamera(client)
        camera.outline_bodies = robot.body_ids
        camera.connect()
        camera.set_faults("Poor")
        camera._rng = np.random.default_rng(5)
        robot.move_to(Pose(*profile.demo_look_pose))
        transform = camera.camera_to_robot_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: robot.arm_state()[0],
                                       world.places, world.place_areas)
        builder = SceneBuilder(camera, detector, transform, known_sizes={"cube": 25.0}, cubes_only=True)
        turns = []
        for _ in range(12):
            for loc in builder._look():
                if loc.label.startswith("blue"):
                    self.assertEqual(loc.label, "blue cube")
                    turns.append(loc.footprint[2] % 90.0)
        self.assertGreaterEqual(len(turns), 10)
        off = [abs((t - 35.0 + 45.0) % 90.0 - 45.0) for t in turns]
        self.assertLessEqual(max(off), 10.0, f"its turn read {turns}")

    def test_touching_cubes_of_two_colours_are_two_cubes(self):
        # study 2, S-10_Run2 to S-20: a green and a blue cube left touching were one 31 x 54 mm "teal block" (and "a blue
        # block" under it) -- "there is no green cube". Each cube once, by its own colour, 25 mm, where it is.
        from app import robots
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.twin.world import TwinWorld
        rgba = {"red": [0.85, 0.1, 0.1, 1], "green": [0.1, 0.7, 0.2, 1], "blue": [0.1, 0.2, 0.8, 1]}
        layouts = {
            "study2": [("green", (99.0, 160.0), 83.0), ("blue", (124.0, 152.0), 6.0), ("red", (178.0, -222.0), 32.0)],
            "side_by_side": [("green", (220.0, 0.0), 0.0), ("blue", (220.0, 25.0), 0.0), ("red", (240.0, -80.0), 10.0)],
            "red_green": [("red", (230.0, 40.0), 15.0), ("green", (230.0, 15.5), 12.0), ("blue", (200.0, -100.0), 0.0)],
        }
        profile = robots.set_active("dobot_magician")
        for quality in ("Perfect", "Realistic"):
            for name, cubes in layouts.items():
                with self.subTest(quality=quality, layout=name):
                    world = TwinWorld()
                    client = world.start()
                    try:
                        world.switch_scenario(name, {"name": name, "places": {}, "objects": [
                            {"id": f"{c}_cube_0", "label": f"{c} cube", "color_rgba": rgba[c], "size_mm": 25.0,
                             "position_mm": [x, y, 12.5], "yaw_deg": yaw} for c, (x, y), yaw in cubes]})
                        robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                                         max_reach_mm=profile.max_reach_mm, world=world)
                        robot.connect()
                        camera = SimCamera(client)
                        camera.outline_bodies = robot.body_ids
                        camera.connect()
                        camera.set_faults(quality)
                        camera._rng = np.random.default_rng(1)
                        robot.move_to(Pose(*profile.demo_look_pose))
                        transform = camera.camera_to_robot_transform()
                        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: robot.arm_state()[0],
                                                       world.places, world.place_areas)
                        builder = SceneBuilder(camera, detector, transform, known_sizes={"cube": 25.0},
                                               cubes_only=True)
                        for _ in range(3):
                            seen = builder._look()
                            self.assertEqual(sorted(o.label for o in seen), sorted(f"{c} cube" for c, _, _ in cubes))
                            for colour, (x, y), _ in cubes:
                                cube = next(o for o in seen if o.label == f"{colour} cube")
                                self.assertLess(np.hypot(cube.xyz_robot[0] - x, cube.xyz_robot[1] - y), 6.0)
                                self.assertAlmostEqual(cube.footprint[0], 25.0, delta=2.0)
                    finally:
                        world.stop()

    def test_poor_picture_no_more_than_one_stray(self):
        # (before: three to five extra "objects" in every look)
        for key in ("dobot_magician", "xarm6"):
            for scene, seen, truth in self.looks(key, "Poor", 3):
                extra = sum(seen.values()) - sum(truth.values())
                self.assertLessEqual(abs(extra), 1, f"{key}, {scene}: {dict(seen)}")


if __name__ == "__main__":
    unittest.main()

"""The 3D view's effects and helpers, and the Settings window that switches them on and off.

    python -m unittest discover -s tests -p test_display.py -v

Draws off-screen; nothing in the project changes (the settings are saved to a temporary copy of config.yaml).
"""
from __future__ import annotations

import math
import os
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT, Sim  # noqa: E402
import numpy as np  # noqa: E402
import yaml  # noqa: E402
from PyQt6.QtGui import QColor, QFont, QImage, QPainter  # noqa: E402
from PyQt6.QtWidgets import QApplication, QMessageBox, QPushButton  # noqa: E402

from app.config import load_config  # noqa: E402
from app.hardware import motion  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from app.twin import kinematics  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402
from app.ui import scene_painter  # noqa: E402
from app.ui.display_settings import DEFAULTS, OPTIONS, DisplaySettings  # noqa: E402
from app.ui.settings_panel import OptionRow, SettingsPanel  # noqa: E402
from app.ui.twin_view import TwinView  # noqa: E402

app = QApplication.instance() or QApplication([])
ALL_ON = {key: True for key in DEFAULTS}


def pump(seconds: float) -> None:
    end = time.time() + seconds
    while time.time() < end:
        app.processEvents()
        time.sleep(0.01)


class SettingsTests(unittest.TestCase):
    def test_every_option_has_a_label_a_tip_and_a_group(self):
        self.assertEqual(len({o.key for o in OPTIONS}), len(OPTIONS))
        for option in OPTIONS:
            self.assertTrue(option.label and len(option.tip) > 20, option.key)
            self.assertIn(option.group, ("Look", "Helpers", "Extras", "Prompts"))

    def test_saved_choices_are_used_and_unknown_or_missing_ones_are_harmless(self):
        settings = DisplaySettings({"soft_shadows": False, "no_such_option": True})
        self.assertFalse(settings["soft_shadows"])
        self.assertEqual(settings["reach_map"], DEFAULTS["reach_map"])
        self.assertNotIn("no_such_option", settings.as_dict())

    def test_a_change_is_announced_and_saved_but_a_failed_save_is_not_an_error(self):
        saved, heard = [], []
        settings = DisplaySettings(save=saved.append)
        settings.changed.connect(lambda: heard.append(1))
        settings.set("auto_rotate", True)
        settings.set("auto_rotate", True)          # no change: nothing to announce or save
        self.assertEqual(len(heard), 1)
        self.assertTrue(saved[-1]["auto_rotate"])

        def broken(values):
            raise OSError("disk full")
        DisplaySettings(save=broken).set("labels", False)   # logged, not raised

    def test_the_panel_switches_options_and_all_on_off_and_defaults_work(self):
        settings = DisplaySettings()
        dialog = SettingsPanel(settings)
        dialog.boxes["reach_map"].setChecked(False)
        self.assertFalse(settings["reach_map"])
        buttons = {b.text(): b for b in dialog.findChildren(QPushButton)}
        buttons["All off"].click()
        self.assertFalse(any(settings[o.key] for o in OPTIONS if o.group != "Prompts"))
        self.assertFalse(dialog.boxes["soft_shadows"].isChecked(), "the boxes follow")
        buttons["Defaults"].click()
        self.assertEqual(settings.as_dict(), DEFAULTS)
        buttons["All on"].click()
        self.assertTrue(all(settings[o.key] for o in OPTIONS if o.group != "Prompts"))
        self.assertFalse(settings["step_by_step"], "All on is for the 3D view, not how prompts run")
        dialog.close()


    def test_rows_sections_and_counts(self):
        from PyQt6.QtCore import QPoint, Qt
        from PyQt6.QtTest import QTest
        from app.ui.display_settings import SUMMARIES
        self.assertEqual(set(SUMMARIES), set(DEFAULTS), "every option has its one-line description")
        settings = DisplaySettings()
        panel = SettingsPanel(settings)
        panel.resize(232, 900)
        panel.show()
        pump(0.05)
        row = next(r for r in panel.findChildren(OptionRow) if r.switch is panel.boxes["height_line"])
        from PyQt6.QtWidgets import QLabel
        self.assertIn(SUMMARIES["height_line"], [label.text() for label in row.findChildren(QLabel)],
                      "a short description under the name")
        self.assertIn("straight down", row.toolTip(), "the full explanation on hover")
        QTest.mouseClick(row, Qt.MouseButton.LeftButton, pos=QPoint(20, row.height() // 2))   # on the words
        self.assertFalse(settings["height_line"], "clicking anywhere on the row switches it")
        helpers = [o.key for o in OPTIONS if o.group == "Helpers"]
        self.assertIn(f"{len(helpers) - 1 - sum(not DEFAULTS[k] for k in helpers)}/{len(helpers)}",
                      panel.sections["Helpers"].header.text())
        panel.sections["Look"].header.click()             # fold it away
        self.assertFalse(panel.boxes["soft_shadows"].isVisible())
        panel.sections["Look"].header.click()
        self.assertTrue(panel.boxes["soft_shadows"].isVisible())
        panel.close()


class GeometryTests(unittest.TestCase):
    def test_the_arm_cannot_get_as_close_to_its_base_high_up(self):
        """What the real arm showed: near the base it stopped when high up. The reach map shows it."""
        low, high = kinematics.reach_band(0.0), kinematics.reach_band(150.0)
        self.assertLess(low[0], high[0])
        self.assertGreater(high[0], 190.0)

    def test_joint_angles_and_their_limits(self):
        joints = kinematics.dobot_joints(kinematics.arm_geometry(220, 0, 50))
        self.assertAlmostEqual(joints["J1"], 0.0, places=3)
        self.assertTrue(all(kinematics.joint_status(k, v) == "ok" for k, v in joints.items()), joints)
        self.assertEqual(kinematics.joint_status("J2", -3.0), "over")
        self.assertEqual(kinematics.joint_status("J2", 2.0), "near")
        self.assertAlmostEqual(kinematics.dobot_joints(kinematics.arm_geometry(150, 150, 50))["J1"], 45.0, places=3)

    def test_a_swing_round_the_base_keeps_its_distance(self):
        start, end = Pose(133, 202, 83), Pose(133, -202, 53)
        route = motion.path_points(start, end, 40)
        self.assertTrue(motion.passes_near_base(start, end))
        self.assertGreater(min(math.hypot(p.x, p.y) for p in route), 240.0, "a straight line would pass 133 mm out")
        self.assertAlmostEqual(route[-1].y, -202.0, places=6)
        straight = motion.path_points(Pose(250, 0, 80), Pose(250, 0, 10), 4)
        self.assertEqual([round(p.z) for p in straight], [80, 62, 45, 28, 10])


class SimulatedArmTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim()
        self.addCleanup(self.sim.close)

    def test_the_demo_arm_swings_round_the_base_like_the_real_one_and_says_where_it_is_going(self):
        robot = self.sim.robot
        robot.max_speed = 400
        robot.move_to(Pose(133, 202, 83))
        seen, closest = [], [1e9]

        def watch():
            while mover.is_alive():
                if robot.motion is not None:
                    seen.append(robot.motion)
                pose = robot.get_pose()
                closest[0] = min(closest[0], math.hypot(pose.x, pose.y))
                time.sleep(0.005)
        mover = threading.Thread(target=robot.move_to, args=(Pose(133, -202, 83),))
        mover.start()
        watcher = threading.Thread(target=watch)
        watcher.start()
        mover.join()
        watcher.join()
        self.assertGreater(closest[0], 235.0, "never cut across in front of the base")
        self.assertTrue(seen and seen[0][1].y == -202, "the view could see the target while it moved")
        self.assertIsNone(robot.motion)
        self.assertAlmostEqual(robot.get_pose().y, -202.0, places=3)


class DrawingTests(unittest.TestCase):
    objects = [{"id": "c", "label": "red cube", "pos": (220.0, -60.0, 12.5), "size": (25, 25, 25),
                "color": (0.8, 0.1, 0.1), "shape": "cube"}]

    def paint(self, effects, geometry=None, held_id=None, closed=False):
        image = QImage(900, 700, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(QColor("#0c1824"))
        painter = QPainter(image)
        camera = scene_painter.look_at((520.0, -560.0, 420.0), (140.0, 0.0, 75.0), 1.25 * 700)
        started = time.perf_counter()
        scene_painter.paint_scene(painter, 900, 700, camera, self.objects,
                                  geometry or kinematics.arm_geometry(220, 100, 80), closed, QFont(),
                                  held_id=held_id, effects=effects)
        elapsed = time.perf_counter() - started
        painter.end()
        return np.frombuffer(image.constBits().asstring(image.sizeInBytes()), np.uint8).reshape(700, 900, 4), elapsed

    def test_all_effects_on_still_draw_quickly(self):
        every = scene_painter.SceneEffects(**{k: True for k in scene_painter.SceneEffects.__dataclass_fields__})
        self.paint(every)
        pixels, elapsed = self.paint(every)
        plain, _ = self.paint(None)
        self.assertLess(elapsed, 0.25, f"one frame took {elapsed * 1000:.0f} ms")
        self.assertGreater((pixels != plain).any(axis=2).sum(), 20000, "the effects change the picture")

    def test_soft_shadows_darken_the_table(self):
        on, _ = self.paint(scene_painter.SceneEffects(soft_shadows=True))
        off, _ = self.paint(scene_painter.SceneEffects())
        darker = (on[:, :, :3].astype(int).sum(axis=2) < off[:, :, :3].astype(int).sum(axis=2) - 30).sum()
        self.assertGreater(darker, 2000)

    def test_the_gripper_glows_green_when_holding(self):
        cube = dict(self.objects[0], id="held", pos=(220.0, 100.0, 68.0))
        self.objects = [cube]
        green, _ = self.paint(scene_painter.SceneEffects(gripper_glow=True), held_id="held", closed=True)
        plain, _ = self.paint(scene_painter.SceneEffects(), held_id="held", closed=True)
        greenish = lambda p: ((p[:, :, 1].astype(int) - p[:, :, 2]) > 60).sum()   # noqa: E731 (BGRA: G - R)
        self.assertGreater(greenish(green), greenish(plain) + 300)

    def test_without_the_mesh_files_the_effects_still_draw(self):
        from app.twin import magician_model
        original = magician_model.MESH_DIR
        magician_model.MESH_DIR = Path("no-such-folder")
        magician_model.load_parts.cache_clear()
        try:
            self.paint(scene_painter.SceneEffects(**{k: True for k in scene_painter.SceneEffects.__dataclass_fields__}))
        finally:
            magician_model.MESH_DIR = original
            magician_model.load_parts.cache_clear()


class TwinViewTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim()
        self.addCleanup(self.sim.close)
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.settings = DisplaySettings()
        self.calls = []

        def detections():
            self.calls.append(1)
            return [("red cube", (220.0, -60.0, 25.0), 0.97)]
        self.view = TwinView(self.sim.world, self.sim.robot, settings=self.settings,
                             camera_view=lambda: (self.sim.exact_transform(), self.sim.camera.get_intrinsics()),
                             detections_source=detections, screenshots_dir=Path(self.folder.name) / "shots")
        self.view.resize(900, 650)
        self.view.show()
        self.addCleanup(self.view.close)
        pump(0.2)

    def test_everything_on_draws_while_the_arm_moves(self):
        self.settings.update(ALL_ON)
        mover = threading.Thread(target=self.sim.robot.move_to, args=(Pose(150, 200, 90),))
        self.sim.robot.max_speed = 200
        mover.start()
        pump(0.4)
        self.view.repaint()      # path preview, ghost, gauges, cone, detections: must not raise
        mover.join()
        pump(1.3)
        self.assertTrue(self.calls, "what the camera sees was asked for")
        self.assertTrue(self.view._detections)

    def test_all_off_leaves_no_joint_panel(self):
        """"Everything off" still showed the joints panel: it fell back to the V1.8 one."""
        drawn = []
        self.view._draw_gauge_panel = lambda *a: drawn.append("gauges")
        self.view._draw_status_panel = lambda *a: drawn.append("plain")
        self.settings.update({key: False for key in DEFAULTS})
        self.view.repaint()
        self.assertEqual(drawn, [])
        self.settings.set("joint_panel", True)
        self.view.repaint()
        self.assertEqual(drawn, ["plain"], "panel on, gauges off: the plain numbers")

    def test_view_buttons_screenshot_and_their_settings(self):
        self.view.view_buttons["Top"].click()
        self.assertAlmostEqual(self.view.pitch, 88.0)
        self.view.view_buttons["3D"].click()
        self.assertAlmostEqual(self.view.pitch, 30.0)
        path = self.view.save_screenshot()
        self.assertTrue(path is not None and path.exists() and path.stat().st_size > 10000)
        self.settings.update({"view_buttons": False, "screenshot_button": False})
        self.assertFalse(self.view.view_buttons["Top"].isVisibleTo(self.view))
        self.assertFalse(self.view.screenshot_button.isVisibleTo(self.view))

    def test_auto_rotate_turns_the_view_and_grabbing_it_stops(self):
        self.settings.set("auto_rotate", True)
        before = self.view.yaw
        pump(0.3)
        self.assertNotAlmostEqual(self.view.yaw, before)
        from PyQt6.QtCore import QPointF
        from PyQt6.QtTest import QTest
        from PyQt6.QtCore import Qt
        QTest.mousePress(self.view, Qt.MouseButton.LeftButton, pos=QPointF(400, 300).toPoint())
        QTest.mouseMove(self.view, QPointF(460, 300).toPoint())
        QTest.mouseRelease(self.view, Qt.MouseButton.LeftButton, pos=QPointF(460, 300).toPoint())
        self.assertFalse(self.settings["auto_rotate"])


class MainWindowSettingsTests(unittest.TestCase):
    """The Settings button, and the choices being remembered in config.yaml (a temporary copy)."""

    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        # the project's config, without the window layout last used (the tests check how a layout gets saved; one
        # the user saved at the lab -- the Manual tab's divider -- isn't theirs to start from)
        saved = yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
        saved.pop("layout", None)
        (Path(cls.folder.name) / "config.yaml").write_text(yaml.safe_dump(saved, sort_keys=False), encoding="utf-8")
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        cls._warning = QMessageBox.warning
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        config = load_config()
        config.pop("layout", None)
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"   # the tests' scene, not the one last picked in Settings
        config["display"] = {}   # default look and prompts (not step-by-step), whatever was last picked in Settings
        config["display"] = {"measuring_mat": False}
        cls.window = main_window_module.MainWindow(config)
        cls.window.show()

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        QMessageBox.warning = cls._warning
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def test_the_settings_button_shows_the_panels_and_choices_are_remembered(self):
        window = self.window
        self.assertFalse(window.display_settings["measuring_mat"], "the saved choice was used")
        panels = window._settings_panels
        self.assertEqual(len(panels), 2, "one beside each 3D view (Manual and Prompt tabs)")
        self.assertTrue(all(p.isHidden() for p in panels), "hidden until asked for")
        button = next(b for b in window.findChildren(QPushButton) if b.text() == "Settings")
        button.click()
        self.assertFalse(any(p.isHidden() for p in panels))
        self.assertTrue(window._jog_column.isHidden(), "the settings take the jog controls' place")
        dialog = panels[0]
        dialog.boxes["reach_map"].setChecked(False)
        self.assertFalse(panels[1].boxes["reach_map"].isChecked(), "the other tab's panel follows")
        saved = yaml.safe_load((Path(self.folder.name) / "config.yaml").read_text(encoding="utf-8"))
        self.assertFalse(saved["display"]["reach_map"])
        self.assertFalse(saved["display"]["measuring_mat"])
        self.assertEqual(saved["mode"], load_config()["mode"], "nothing else in the file changed")
        views = window.findChildren(TwinView)
        self.assertEqual(len(views), 3, "Manual, Prompt and (demo) Calibration tabs")
        self.assertTrue(all(v.settings is window.display_settings for v in views), "every tab follows the one setting")
        dialog.close_requested.emit()                      # its x
        self.assertFalse(button.isChecked())
        self.assertTrue(all(p.isHidden() for p in panels))
        self.assertFalse(window._jog_column.isHidden(), "and give it back when closed")


    def test_the_divider_moves_and_the_widths_are_remembered_and_the_window_can_be_small(self):
        from PyQt6.QtWidgets import QSplitter
        window = self.window
        self.assertLess(window.minimumSizeHint().width(), 900, "fits a laptop screen at 150% scaling")
        prompt = window.tabs.widget(1)
        manual = window.tabs.widget(0)
        self.assertIsInstance(prompt, QSplitter)
        self.assertIsInstance(manual, QSplitter)
        window.resize(1400, 800)
        window.tabs.setCurrentIndex(1)
        pump(0.2)
        prompt.setSizes([300, 1000])
        window._save_split(prompt)
        saved = yaml.safe_load((Path(self.folder.name) / "config.yaml").read_text(encoding="utf-8"))
        left, right = saved["layout"]["prompt"]
        self.assertLess(left, right)
        self.assertEqual(left + right, 100)
        window.settings_btn.setChecked(True)          # the jog controls step aside...
        window._save_split(manual)                    # ...which must not be remembered as a width of 0
        saved = yaml.safe_load((Path(self.folder.name) / "config.yaml").read_text(encoding="utf-8"))
        self.assertNotIn("manual", saved.get("layout", {}))
        window.settings_btn.setChecked(False)
        window.tabs.setCurrentIndex(0)


if __name__ == "__main__":
    unittest.main()

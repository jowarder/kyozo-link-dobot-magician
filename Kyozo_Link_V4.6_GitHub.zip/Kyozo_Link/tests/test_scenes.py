"""The demo scenes: each one is sensible (in reach, nothing overlapping), the camera finds every object in
it, the robot can use its places, and switching scenes from the Settings window works.

    python -m unittest discover -s tests -p test_scenes.py -v

Nothing in the project changes: the window is pointed at a temporary copy of config.yaml.
"""
from __future__ import annotations

import ast
import math
import os
import shutil
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT, Sim  # noqa: E402
import yaml  # noqa: E402
from PyQt6.QtWidgets import QApplication, QMessageBox  # noqa: E402

from app.calibration.guidance import MIN_RADIUS_MM  # noqa: E402
from app.config import load_config  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from app.llm.tools import ToolExecutor  # noqa: E402
from app.twin.world import list_scenarios  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402
from app.vision.detector import build_detector, with_demo_colors  # noqa: E402
from app.vision.scene import SceneBuilder  # noqa: E402


def pump_until(condition, limit_s: float = 10.0) -> None:
    import time
    started = time.monotonic()
    while not condition() and time.monotonic() - started < limit_s:
        QApplication.processEvents()
        time.sleep(0.01)

app = QApplication.instance() or QApplication([])
REACH_MM = 300.0
OUT_OF_THE_WAY = Pose(x=120.0, y=-160.0, z=90.0)


def load(name: str) -> dict:
    return yaml.safe_load((ROOT / "app" / "twin" / "scenarios" / f"{name}.json").read_text(encoding="utf-8"))


def footprint(obj: dict) -> tuple[float, float]:
    size = obj.get("size_mm", 25)
    return (size, size) if isinstance(size, (int, float)) else (size[0], size[1])


class SceneFileTests(unittest.TestCase):
    def test_there_are_several_scenes_with_titles_and_descriptions(self):
        scenes = list_scenarios()
        names = {s["name"] for s in scenes}
        self.assertTrue({"two_blocks_and_tray", "colour_sorting", "tower_building", "size_sorting"} <= names)
        for scene in scenes:
            self.assertTrue(scene["title"] and len(scene["description"]) > 30, scene["name"])

    def test_every_object_and_place_is_within_reach_and_nothing_overlaps(self):
        for scene in list_scenarios():
            data = load(scene["name"])
            objects = data["objects"]
            for obj in objects:
                x, y, _ = obj["position_mm"]
                if obj.get("shape") != "tray":
                    self.assertTrue(MIN_RADIUS_MM <= math.hypot(x, y) <= REACH_MM - 20, (scene["name"], obj["id"]))
            for a in objects:
                for b in objects:
                    if a is b:
                        continue
                    (ax, ay, _), (bx, by, _) = a["position_mm"], b["position_mm"]
                    (aw, ad), (bw, bd) = footprint(a), footprint(b)
                    apart = abs(ax - bx) >= (aw + bw) / 2 + 4 or abs(ay - by) >= (ad + bd) / 2 + 4
                    self.assertTrue(apart, (scene["name"], a["id"], b["id"]))
            for name, (x, y, z) in data.get("places", {}).items():
                self.assertLessEqual(math.hypot(x, y), REACH_MM, (scene["name"], name))
                self.assertTrue(0.0 <= z <= 10.0, "the surface there: the table, or a tray's or bin's floor")
            # a place named after a tray or bin in the scene is in the middle of it
            for obj in objects:
                if obj.get("shape") == "tray" and obj["label"] in data.get("places", {}):
                    px, py, _ = data["places"][obj["label"]]
                    self.assertLess(math.dist((px, py), obj["position_mm"][:2]), 5.0, (scene["name"], obj["label"]))


class SceneWorldTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim()
        self.addCleanup(self.sim.close)
        self.sim.robot.move_to(OUT_OF_THE_WAY)

    def test_the_camera_finds_every_object_in_every_scene_and_not_the_bins(self):
        detector = build_detector(with_demo_colors(self.sim.config["vision"]))
        for scene in list_scenarios():
            if scene["name"] == "mixed_objects":
                continue       # white, black, grey, brown objects: for the depth detector (test_depth_detector.py)
            self.sim.world.switch_scenario(scene["name"])
            seen = SceneBuilder(self.sim.camera, detector, self.sim.exact_transform()).get_scene()
            truth = {m["label"]: self.sim.world.get_object_position_mm(i)
                     for i, m in self.sim.world.object_meta.items() if m["shape"] != "tray"}
            self.assertEqual(sorted(o.label for o in seen), sorted(truth), scene["name"])
            for o in seen:
                self.assertLess(math.dist(o.xyz_robot[:2], truth[o.label][:2]), 8.0, (scene["name"], o.label))

    def test_switching_takes_the_old_objects_away_and_brings_the_scene_places(self):
        world = self.sim.world
        world.switch_scenario("colour_sorting")
        self.assertEqual(len(world.snapshot()), 6)
        self.assertIn("warm bin", world.places())
        self.assertNotIn("tray", world.places())
        world.switch_scenario("two_blocks_and_tray")
        self.assertEqual(sorted(o["label"] for o in world.snapshot()), ["blue cube", "green cube", "red cube", "tray"])
        self.assertEqual(world.places(), {"tray": (280.0, 0.0, 4.0)})

    def test_a_bin_is_never_picked_up(self):
        self.sim.world.switch_scenario("colour_sorting")
        robot = self.sim.robot
        robot.move_to(Pose(270, 95, 20))           # right in the cool bin
        robot.close_gripper()
        self.assertIsNone(robot.held_object)
        robot.open_gripper()

    def test_sorting_a_cube_into_its_bin_with_the_robot_tools(self):
        world = self.sim.world
        world.switch_scenario("colour_sorting")
        detector = build_detector(with_demo_colors(self.sim.config["vision"]))
        executor = ToolExecutor(self.sim.robot, SceneBuilder(self.sim.camera, detector, self.sim.exact_transform()),
                                look_pose=OUT_OF_THE_WAY, table_z_provider=lambda: 0.0, places_provider=world.places)
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        self.assertEqual(sorted(listed["saved_places"]), ["cool bin", "warm bin"])
        red = next(o["id"] for o in listed["objects"] if o["label"] == "red cube")
        executor.execute("pick", {"object_id": red})
        executor.execute("place_at", {"place_name": "warm bin"})
        x, y, z = world.get_object_position_mm("red_cube")
        self.assertLess(max(abs(x - 270), abs(y + 95)), 36.0, "in the warm bin (at a free spot in it)")
        self.assertLess(z, 20.0, "resting on its floor")

    def test_stacking_on_a_cube_that_was_just_moved_goes_where_it_is_now(self):
        """What the real model did: red to the tower spot, then "blue on the red cube" -- which went to the
        empty spot the red cube had left, because the tools still had the old position from the last look."""
        world = self.sim.world
        world.switch_scenario("tower_building")
        detector = build_detector(with_demo_colors(self.sim.config["vision"]))
        builder = SceneBuilder(self.sim.camera, detector, self.sim.exact_transform())
        executor = ToolExecutor(self.sim.robot, builder, look_pose=OUT_OF_THE_WAY, table_z_provider=lambda: 0.0,
                                places_provider=world.places)
        ids = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
        executor.execute("pick", {"object_id": ids["red cube"]})
        executor.execute("place_at", {"place_name": "tower spot"})
        executor.execute("pick", {"object_id": ids["blue cube"]})
        executor.execute("place_on", {"object_id": ids["red cube"]})
        executor.execute("pick", {"object_id": ids["green cube"]})
        executor.execute("place_on", {"object_id": ids["blue cube"]})
        for label, level in (("red_cube", 0), ("blue_cube", 1), ("green_cube", 2)):
            x, y, z = world.get_object_position_mm(label)
            self.assertLess(math.dist((x, y), (230, 0)), 6.0, label)
            self.assertAlmostEqual(z, 10 + 20 * level, delta=2.0, msg=label)
        again = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
        self.assertEqual(again["red cube"], ids["red cube"], "a moved object keeps its id at the next look")

    def test_the_model_is_told_each_objects_size_so_small_and_large_can_be_sorted(self):
        world = self.sim.world
        world.switch_scenario("size_sorting")
        detector = build_detector(with_demo_colors(self.sim.config["vision"]))
        executor = ToolExecutor(self.sim.robot, SceneBuilder(self.sim.camera, detector, self.sim.exact_transform()),
                                look_pose=OUT_OF_THE_WAY, table_z_provider=lambda: 0.0, places_provider=world.places)
        listed = ast.literal_eval(executor.execute("list_objects", {}))
        heights = {o["label"]: o["height_mm"] for o in listed["objects"]}
        small, large = [heights["red cube"], heights["green cube"]], [heights["yellow cube"], heights["blue cube"]]
        for h in small:
            self.assertAlmostEqual(h, 15, delta=3)
        for h in large:
            self.assertAlmostEqual(h, 20, delta=3)
        self.assertLess(max(small), min(large), "the two sizes don't overlap")
        self.assertEqual(sorted(listed["saved_places"]), ["large bin", "small bin"])
        from app.llm.agent import SYSTEM_PROMPT
        self.assertIn("height_mm", SYSTEM_PROMPT)

    def test_stacking_on_the_bottom_of_a_pile_is_refused_with_the_way_to_do_it(self):
        """The model once built yellow on purple, then kept trying to put the next cube on purple; told only
        "nothing can be put on it" it gave up and put the rest down anywhere."""
        world = self.sim.world
        world.switch_scenario("tower_building")
        detector = build_detector(with_demo_colors(self.sim.config["vision"]))
        executor = ToolExecutor(self.sim.robot, SceneBuilder(self.sim.camera, detector, self.sim.exact_transform()),
                                look_pose=OUT_OF_THE_WAY, table_z_provider=lambda: 0.0, places_provider=world.places)
        ids = {o["label"]: o["id"] for o in ast.literal_eval(executor.execute("list_objects", {}))["objects"]}
        executor.execute("pick", {"object_id": ids["yellow cube"]})
        executor.execute("place_on", {"object_id": ids["purple cube"]})
        executor.execute("pick", {"object_id": ids["red cube"]})
        with self.assertRaises(ValueError) as refused:
            executor.execute("place_on", {"object_id": ids["purple cube"]})
        self.assertIn(f"place_on with object_id {ids['yellow cube']}", str(refused.exception))
        executor.execute("place_on", {"object_id": ids["yellow cube"]})       # what the message says to do
        purple = world.get_object_position_mm("purple_cube")
        red = world.get_object_position_mm("red_cube")
        self.assertLess(math.dist(red[:2], purple[:2]), 6.0)
        self.assertAlmostEqual(red[2], 50.0, delta=2.0, msg="third level")

    def test_a_saved_pose_with_the_same_name_wins_over_the_scene(self):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder) / "tray.json").write_text('{"x": 250, "y": 10, "z": 40, "r": 0}', encoding="utf-8")
            executor = ToolExecutor(self.sim.robot, None, poses_dir=Path(folder),
                                    places_provider=lambda: {"tray": (280.0, 0.0, 20.0), "bin": (200.0, 0.0, 30.0)})
            places = executor._saved_places()
            self.assertEqual((places["tray"].x, places["tray"].z), (250.0, 40.0))
            self.assertEqual(places["bin"].x, 200.0)


class SceneSwitchingTests(unittest.TestCase):
    """The Settings window's scene picker, in the whole app (demo mode)."""

    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        shutil.copy(ROOT / "config.yaml", Path(cls.folder.name) / "config.yaml")
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        cls._warning = QMessageBox.warning
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        config = load_config()
        config["mode"] = "demo"
        config["twin"]["scenario"] = "two_blocks_and_tray"
        config["display"] = {}   # default look and prompts (not step-by-step), whatever was last picked in Settings
        cls.window = main_window_module.MainWindow(config)
        cls.window.robot.max_speed = 3000
        cls.window.show()

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        QMessageBox.warning = cls._warning
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def config_on_disk(self) -> dict:
        return yaml.safe_load((Path(self.folder.name) / "config.yaml").read_text(encoding="utf-8"))

    def test_the_picker_loads_a_scene_resets_it_and_the_robot_forgets_the_old_one(self):
        window = self.window
        window._open_settings()
        dialog = window._settings_panels[0]
        self.assertFalse(dialog.isHidden())
        titles = [dialog.scene_combo.itemText(i) for i in range(dialog.scene_combo.count())]
        self.assertIn("Colour sorting", titles)
        self.assertEqual(dialog.scene_combo.currentData(), "two_blocks_and_tray")

        # something held, a stack remembered: all of it belongs to the old scene
        window.robot.move_to(Pose(220, -60, 25))
        window.robot.close_gripper()
        window.tool_executor.holding = "red cube"
        dialog.scene_combo.setCurrentIndex(dialog.scene_combo.findData("colour_sorting"))
        dialog.load_scene_btn.click()
        self.assertIn("Loaded", dialog.scene_status.text())
        self.assertEqual(len(window._twin_world.snapshot()), 6)
        self.assertIsNone(window.robot.held_object)
        self.assertIsNone(window.tool_executor.holding)
        self.assertEqual(sorted(window.tool_executor._saved_places()), ["cool bin", "warm bin"])
        self.assertEqual(self.config_on_disk()["twin"]["scenario"], "colour_sorting", "remembered for next time")
        self.assertEqual(self.config_on_disk()["mode"], load_config()["mode"], "nothing else in the file changed")

        world = window._twin_world
        window.robot._place_object("green_cube", 150, -200, 12.5)   # moved during some task...
        dialog.reset_scene_btn.click()
        self.assertEqual(tuple(round(v) for v in world.get_object_position_mm("green_cube")), (179, 65, 10))
        window.settings_btn.setChecked(False)

    def test_loading_is_refused_while_a_prompt_is_running(self):
        window = self.window
        original = window.prompt_panel.is_busy
        window.prompt_panel.is_busy = lambda: True
        try:
            done, message = window.load_scene("tower_building")
        finally:
            window.prompt_panel.is_busy = original
        self.assertFalse(done)
        self.assertIn("prompt", message)

    def test_each_scene_brings_its_own_prompts_after_try(self):
        window = self.window
        for scene in list_scenarios():
            done, said = window.load_scene(scene["name"])
            self.assertTrue(done, said)
            own = window._twin_world.scenario["prompts"]
            shown = window.prompt_panel.example_prompts()
            self.assertEqual(shown, own + ["What do you see?", "Go home"], scene["name"])
            self.assertTrue(all(len(text.split()) <= 8 for text in own), "short: they follow \"Try:\"")
            self.assertTrue(window.prompt_panel._chips[0].property("featured"), "the whole-scene one stands out")
            self.assertFalse(window.prompt_panel._chips[1].property("featured"))
        sent = []
        window.prompt_panel._send_text, original = sent.append, window.prompt_panel._send_text
        try:
            window.prompt_panel._chips[0].click()
        finally:
            window.prompt_panel._send_text = original
        self.assertEqual(sent, [window._twin_world.scenario["prompts"][0]])
        window.load_scene("two_blocks_and_tray")

    def test_e_stop_ends_a_prompt_waiting_on_the_model_and_frees_the_app(self):
        """E-STOP stopped the arm but the prompt stayed "running" until the model answered: no scene could be loaded."""
        import threading
        window = self.window
        release, asked = threading.Event(), threading.Event()

        class Thinking:
            last_stats = {}

            def chat(self, *args, **kwargs):
                asked.set()
                release.wait(20)              # the model taking its time
                return {"role": "assistant", "content": "", "tool_calls": [
                    {"function": {"name": "list_objects", "arguments": {}}}]}
        original, window.agent.client = window.agent.client, Thinking()
        warning = QMessageBox.warning
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        try:
            window.prompt_panel._send_text("Stack all the cubes")
            self.assertTrue(asked.wait(10))
            # (the app's own look, before the model is asked: shown before the E-STOP, as it is in the running app)
            pump_until(lambda: "Looked at the table" in window.prompt_panel.log.toPlainText(), 5)
            self.assertTrue(window.prompt_panel.is_busy())
            window._on_estop()
            self.assertFalse(window.prompt_panel.is_busy(), "free at once, not when the model answers")
            window.robot.reset_estop()
            done, said = window.load_scene("tower_building")
            self.assertTrue(done, said)
            release.set()
            worker = window.prompt_panel._abandoned[0]
            pump_until(lambda: not worker.isRunning(), 20)
            pump_until(lambda: not window.prompt_panel._abandoned, 5)
            log = window.prompt_panel.log.toPlainText()
            self.assertIn("E-STOP: the prompt was ended", log)
            self.assertNotIn("Looked at the table", log.split("E-STOP: the prompt was ended")[-1],
                             "the late answer was not acted on")
        finally:
            release.set()
            window.agent.client = original
            QMessageBox.warning = warning
            window.load_scene("two_blocks_and_tray")

    def test_the_manual_tab_turns_picks_here_and_says_what_the_gripper_holds(self):
        window = self.window
        window.load_scene("two_blocks_and_tray")
        robot, panel, world = window.robot, window.jog_panel, window._twin_world
        bx, by, _ = world.get_object_position_mm("blue_cube")
        # A: turning the gripper, within the wrist's range
        robot.move_to(Pose(bx + 12.0, by - 8.0, 70.0, 0.0))
        panel._turn(15.0)
        self.assertAlmostEqual(robot.get_pose().r, 15.0)
        with self.assertRaisesRegex(ValueError, "wrist can't turn further"):
            panel._turn(90.0)
        # D: closing on nothing says why
        said = panel._close()
        self.assertTrue(said.startswith("!Closed on nothing"), said)
        panel._open()
        # B: "Pick here" from roughly above it: centred and turned for you
        said = window._pick_here()
        self.assertIn("Picked up blue cube", said)
        self.assertIn("fingers turned", said)
        self.assertEqual(robot.held_object, "blue_cube")
        self.assertEqual(window.tool_executor.holding, "blue cube")
        # opened by hand: the robot tools know it's let go
        panel._open()
        self.assertIsNone(window.tool_executor.holding)
        robot.move_to(Pose(150.0, -150.0, 80.0, 0.0))                  # (an empty spot: the green cube is at y +130)
        with self.assertRaisesRegex(ValueError, "Nothing under the gripper"):
            window._pick_here()
        window.load_scene("two_blocks_and_tray")

    def test_the_demo_detector_knows_the_extra_colours(self):
        detector = self.window.detector
        if hasattr(detector, "colors"):
            self.assertTrue({"yellow", "purple"} <= set(detector.colors))
        else:        # the depth detector names any colour
            from app.vision.depth_detector import colour_name
            import numpy as np
            self.assertEqual(colour_name(np.array([(230, 200, 25)] * 9, np.uint8)), "yellow")
            self.assertEqual(colour_name(np.array([(140, 40, 200)] * 9, np.uint8)), "purple")



class KnownSizeTests(unittest.TestCase):
    def test_a_cube_of_known_size_is_taken_to_be_that_size_when_measured_near_it(self):
        from app.vision.locator import LocatedObject
        from app.vision.scene import SceneBuilder
        import numpy as np
        builder = SceneBuilder(None, None, np.eye(4), known_sizes={"cube": 25.0})
        located = [LocatedObject("blue cube", (247.0, -4.0, 20.0), 1.0, (28.0, 30.0, 37.0)),   # the lab's
                   LocatedObject("red cube", (156.0, -169.0, 20.0), 0.7, (20.0, 26.0, 5.0)),
                   LocatedObject("green cube", (200.0, -96.0, 20.0), 0.9, (25.0, 52.0, 90.0)),  # two side by side
                   LocatedObject("red ball", (100.0, 0.0, 20.0), 0.9, (30.0, 30.0, 0.0))]
        sizes = [loc.footprint for loc in builder._known(located)]
        self.assertEqual(sizes[0], (25.0, 25.0, 37.0))
        self.assertEqual(sizes[1], (25.0, 25.0, 5.0))
        self.assertEqual(sizes[2], (25.0, 52.0, 90.0))
        self.assertEqual(sizes[3], (30.0, 30.0, 0.0))

    def test_a_block_measured_near_a_cubes_size_is_that_cube(self):
        # the lab, 2026-10-22: a 25 mm green cube read 23.7 x 27.5 -- "green block" -- and was gripped on its edge
        from app.vision.locator import LocatedObject
        from app.vision.scene import SceneBuilder
        import numpy as np
        builder = SceneBuilder(None, None, np.eye(4), known_sizes={"cube": 25.0})
        located = [LocatedObject("green block", (200.0, 84.0, 20.0), 1.0, (23.7, 27.5, 0.0)),
                   LocatedObject("blue block", (150.0, 0.0, 20.0), 1.0, (25.0, 52.0, 90.0)),   # two side by side
                   LocatedObject("red bar", (150.0, 50.0, 20.0), 1.0, (12.0, 30.0, 0.0))]
        known = builder._known(located)
        self.assertEqual((known[0].label, known[0].footprint), ("green cube", (25.0, 25.0, 0.0)))
        self.assertEqual((known[1].label, known[1].footprint), ("blue block", (25.0, 52.0, 90.0)))
        self.assertEqual(known[2].label, "red bar")
        self.assertEqual(SceneBuilder(None, None, np.eye(4))._known(located)[0].label, "green block",
                         "with no cube size known, measured as it is")

    def test_only_cubes_a_cube_read_round_is_still_the_cube(self):
        # the lab, 2026-10-22: a blue cube flickered to "blue cylinder" and back
        from app.vision.locator import LocatedObject
        from app.vision.scene import SceneBuilder
        import numpy as np
        located = [LocatedObject("blue cylinder", (200.0, 0.0, 20.0), 1.0, (24.0, 26.0, 10.0)),
                   LocatedObject("red ball", (150.0, 0.0, 20.0), 1.0, (26.0, 26.0, 0.0)),
                   LocatedObject("green cylinder", (150.0, 50.0, 20.0), 1.0, (40.0, 40.0, 0.0))]   # far off 25
        cubes = SceneBuilder(None, None, np.eye(4), known_sizes={"cube": 25.0}, cubes_only=True)._known(located)
        self.assertEqual([c.label for c in cubes], ["blue cube", "red cube", "green cylinder"])
        self.assertEqual(cubes[0].footprint, (25.0, 25.0, 10.0))
        # the parked gripper, read as "a grey block" in the way, refused every move: only cubes, nothing colourless
        arm = [LocatedObject("grey block", (172.0, 174.0, 60.0), 1.0, (20.0, 45.0, 30.0)),
               LocatedObject("black bar", (150.0, 150.0, 60.0), 1.0, (12.0, 40.0, 0.0)),
               LocatedObject("red cube", (204.0, -50.0, 20.0), 1.0, (23.0, 26.0, 15.0))]
        seen = SceneBuilder(None, None, np.eye(4), known_sizes={"cube": 25.0}, cubes_only=True)._known(arm)
        self.assertEqual([c.label for c in seen], ["red cube"])
        self.assertEqual(len(SceneBuilder(None, None, np.eye(4), known_sizes={"cube": 25.0})._known(arm)), 3,
                         "without cubes_only, kept")
        mixed = SceneBuilder(None, None, np.eye(4), known_sizes={"cube": 25.0})._known(located)
        self.assertEqual([c.label for c in mixed], ["blue cylinder", "red ball", "green cylinder"],
                         "without cubes_only, a cylinder stays one")

if __name__ == "__main__":
    unittest.main()

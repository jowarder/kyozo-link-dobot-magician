"""Several objects into one tray or bin in one go: put_all_in, planned by llm/packing.py.

    python -m unittest discover -s tests -p test_packing.py -v

The planner on its own, then the whole thing in demo mode (the depth detector, the two-finger gripper).
"""
from __future__ import annotations

import ast
import math
import unittest

from harness import LOOK_POSE, Sim

from app.hardware.gripper import FINGER_THICKNESS_MM, FINGER_WIDTH_MM, GripperSpec
from app.llm.agent import Agent
from app.llm.packing import Box, Fingers, Item, plan_tray, rectangles_overlap
from app.llm.tools import ToolExecutor
from app.llm.trace import understand
from app.vision.depth_detector import DepthObjectDetector
from app.vision.scene import SceneBuilder

SPEC = GripperSpec()
FINGERS = Fingers(SPEC.opening_mm / 2 + FINGER_THICKNESS_MM / 2, FINGER_THICKNESS_MM, FINGER_WIDTH_MM)
TRAY = (72.0, 72.0)          # the demo tray's inside
WALL_TOP, FLOOR = 16.0, 4.0


def cube(n: int, label: str = "cube", size: float = 25.0) -> Item:
    return Item(f"obj_{n}", f"{label} {n} cube", size, size, size, size / 2)


class PlannerTests(unittest.TestCase):
    def check_floor(self, plan, items):
        by_id = {i.id: i for i in items}
        floor = [p for p in plan.placements if p.on is None]
        for p in floor:
            item = by_id[p.id]
            ex = (item.length if p.angle == 0 else item.width) / 2
            ey = (item.width if p.angle == 0 else item.length) / 2
            self.assertLessEqual(abs(p.x) + ex, TRAY[0] / 2, p)
            self.assertLessEqual(abs(p.y) + ey, TRAY[1] / 2, p)
        for a in floor:
            for b in floor:
                if a is not b:
                    self.assertFalse(rectangles_overlap(
                        (a.x, a.y), (by_id[a.id].width, by_id[a.id].length, a.angle),
                        (b.x, b.y), (by_id[b.id].width, by_id[b.id].length, b.angle), 0.0), (a, b))

    def test_the_whole_mixed_table_fits_the_ball_on_the_floor(self):
        items = [Item("bar", "blue bar", 10, 60, 10, 5), Item("block", "brown block", 20, 40, 20, 10),
                 Item("w", "white cube", 25, 25, 25, 12.5), Item("k", "black cube", 25, 25, 25, 12.5),
                 Item("c", "grey cylinder", 24, 25, 30, 15), Item("b", "orange ball", 20, 22, 22, 11)]
        plan = plan_tray(items, TRAY, WALL_TOP, FLOOR, [], FINGERS)
        self.assertEqual(plan.placements[0].label, "blue bar", "the longest first, while a side is free")
        self.assertEqual(plan.placements[1].label, "orange ball", "then what can only go on the floor")
        self.assertEqual(len(plan.placements), 6, plan.left_out)
        self.check_floor(plan, items)
        self.assertTrue(all(p.angle in (0.0, 90.0) for p in plan.placements), "squared up to the tray")
        ball = next(p for p in plan.placements if p.label == "orange ball")
        self.assertIsNone(ball.on, "a ball only on the floor")
        self.assertFalse(any(p.on == "orange ball" for p in plan.placements), "and nothing on it")

    def test_a_full_floor_gets_a_second_layer_on_flat_tops_only(self):
        items = [cube(n) for n in range(1, 7)]
        plan = plan_tray(items, TRAY, WALL_TOP, FLOOR, [], FINGERS)
        floor = [p for p in plan.placements if p.on is None]
        on_top = [p for p in plan.placements if p.on is not None]
        self.assertEqual(len(plan.placements), 6, plan.left_out)
        self.assertGreaterEqual(len(floor), 3)
        self.assertTrue(on_top, "the rest on top")
        self.check_floor(plan, items)
        for p in on_top:
            base = next(q for q in plan.placements if q.label == p.on)
            self.assertEqual((p.x, p.y), (base.x, base.y), "right on top of it")
            self.assertAlmostEqual(p.surface, FLOOR + 25.0)
            self.assertIsNone(base.on, "two layers at most")
        self.assertEqual(len({p.on for p in on_top}), len(on_top), "one on each")

    def test_a_third_level_only_on_a_steady_pile(self):
        """With two levels at most, a cube was left out of a tray whose piles had flat tops free."""
        small = (24.0, 44.0)                 # room for the pile and nothing beside it: the floor is full
        piles = [Box("blk", "brown block", 0, 0, 20, 40, 90.0, FLOOR + 20, covered=True),
                 Box("wc", "white cube", 0, 0, 20, 20, 0.0, FLOOR + 40, layer=1, support_width=20, support_length=20)]
        plan = plan_tray([cube(1, size=20.0)], small, WALL_TOP, FLOOR, piles, FINGERS)
        self.assertEqual([p.on for p in plan.placements], ["white cube"], plan.left_out)
        self.assertAlmostEqual(plan.placements[0].surface, FLOOR + 40.0, msg="a third level")
        wide = Item("w", "red block", 30, 30, 20, 10)       # wider than the white cube under it
        plan = plan_tray([wide], small, WALL_TOP, FLOOR, piles, FINGERS)
        self.assertEqual(plan.placements, [], "not on a pile narrower than itself")
        piles[1].layer = 2                   # a fourth level: never
        plan = plan_tray([cube(2, size=20.0)], small, WALL_TOP, FLOOR, piles, FINGERS)
        self.assertEqual(plan.placements, [], "three levels at most")

    def test_a_bar_is_laid_across_a_row_of_cubes_when_the_floor_is_full(self):
        """"The tray is full" for a blue bar, with three cubes in a row whose tops could hold it."""
        narrow = (66.0, 22.0)                 # three cubes in a row fill the floor
        row = [Box(f"c{n}", f"{colour} cube", x, 0, 20, 20, 0.0, FLOOR + 20)
               for n, (colour, x) in enumerate((("white", -22), ("black", 0), ("green", 22)))]
        bar = Item("bar", "blue bar", 10, 60, 11, 5)
        plan = plan_tray([bar], narrow, WALL_TOP, FLOOR, row, FINGERS)
        self.assertEqual(len(plan.placements), 1, plan.left_out)
        p = plan.placements[0]
        self.assertEqual((round(p.x), round(p.y)), (0, 0), "its middle over the row's middle")
        self.assertAlmostEqual(p.angle % 180.0, 0.0, msg="along the row")
        self.assertAlmostEqual(p.surface, FLOOR + 20.0)
        self.assertIn("white cube", p.on)
        self.assertIn("green cube", p.on)
        short = Item("pen", "red bar", 6, 14, 6, 3)          # can't reach from one cube to the next
        far = [Box("a", "a cube", -25, 0, 20, 20, 0.0, FLOOR + 20), Box("b", "b cube", 25, 0, 20, 20, 0.0, FLOOR + 20)]
        plan = plan_tray([short], (70.0, 22.0), WALL_TOP, FLOOR, far, FINGERS)
        self.assertFalse(any(" cube, " in (q.on or "") for q in plan.placements), "not across a gap it can't span")

    def test_nothing_goes_on_a_ball(self):
        balls = [Box(f"b{n}", "orange ball", x, y, 22, 22, 0.0, FLOOR + 22) for n, (x, y) in
                 enumerate(((-20, -20), (20, -20), (-20, 20), (20, 20)))]
        plan = plan_tray([cube(1)], TRAY, WALL_TOP, FLOOR, balls, FINGERS)
        self.assertEqual(plan.placements, [])
        self.assertIn("can't go on top of anything", plan.left_out[0][1])

    def test_short_objects_are_let_go_a_little_higher_to_clear_the_walls(self):
        plan = plan_tray([Item("bar", "blue bar", 10, 60, 10, 5)], TRAY, WALL_TOP, FLOOR, [], FINGERS)
        p = plan.placements[0]
        self.assertGreater(p.drop, 0.0)
        self.assertLessEqual(p.drop, 8.0)
        self.assertGreater(abs(p.y), 25.0, "right by a wall")


class InTheDemoTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim(gripper=SPEC)
        self.addCleanup(self.sim.close)
        self.sim.robot.move_to(LOOK_POSE)
        world = self.world = self.sim.world
        transform = self.sim.exact_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: self.sim.robot.arm_state()[0],
                                       world.places, world.place_areas)
        self.executor = ToolExecutor(self.sim.robot, SceneBuilder(self.sim.camera, detector, transform),
                                     look_pose=LOOK_POSE, table_z_provider=lambda: 0.0, places_provider=world.places,
                                     gripper=SPEC)
        world.switch_scenario("mixed_objects")
        self.ids = {m["label"]: i for i, m in world.object_meta.items()}

    def listed(self) -> dict:
        return {o["label"]: o for o in ast.literal_eval(self.executor.execute("list_objects", {}))["objects"]}

    def test_everything_into_the_tray_in_one_go(self):
        listed = self.listed()
        result = self.executor.execute("put_all_in", {"place_name": "tray",
                                                      "object_ids": [o["id"] for label, o in listed.items() if label != "green cube"]})
        packing = self.executor.last_record["packing"]
        self.assertEqual(packing["done"], 6, result)
        self.assertIn("Put 6 of 6 in the tray", result)
        planned = {p["object"]: p for p in packing["planned"]}
        top = {}
        for label, p in planned.items():
            x, y, z = self.world.get_object_position_mm(self.ids[label])
            height = self.world.object_meta[self.ids[label]]["size"][2]
            self.assertLess(max(abs(x - 280.0), abs(y)), 36.0, f"{label} inside the tray")
            top[label] = z + height / 2
        for label, p in planned.items():
            height = self.world.object_meta[self.ids[label]]["size"][2]
            below = top[p["on"]] if p["on"] else 4.0
            self.assertAlmostEqual(top[label] - height, below, delta=1.5,
                                   msg=f"{label} standing on {p['on'] or 'the floor'}, not on anything else")

    def test_the_packed_tray_is_seen_as_it_is(self):
        """Packed close, a cube took in the sides of the block under it (\"a black block, 39 x 47 mm\"), the block's
        ends showed as objects of their own, and neighbours 26 mm apart counted as on top of each other: the model
        was then given things that weren't there, and picking the ball would have moved a cube aside first."""
        listed = self.listed()
        self.executor.execute("put_all_in", {"place_name": "tray", "object_ids": [o["id"] for label, o in listed.items() if label != "green cube"]})
        stacked = {p["object"]: p["on"] for p in self.executor.last_record["packing"]["planned"]}
        self.executor.scene_builder.reset_tracking()          # looked at afresh, as a new prompt would
        after = self.listed()
        seen = set(after)
        truth = set(self.ids) - {"tray"}
        # nothing that isn't there: each thing seen is a real one of its colour, where it is (under a smaller one,
        # its shape can't be seen: a cylinder under a cube shows as a rim)
        for label, entry in after.items():
            near = [t for t in truth if t.split()[0] == label.split()[0] and math.dist(
                entry["xyz_mm"][:2], self.world.get_object_position_mm(self.ids[t])[:2]) <= 12.0]
            self.assertTrue(near, f"the {label} at {entry['xyz_mm']} isn't there")
        self.assertGreaterEqual(len(seen), 5, seen)
        for label, entry in after.items():
            cover = entry.get("covered_by")
            if cover is not None:            # (by colour: under a smaller one, its shape can't be seen)
                self.assertEqual(stacked.get(cover, "").split()[:1], label.split()[:1],
                                 f"{label} is only covered by what's really on it")
        self.assertNotIn("covered_by", after["orange ball"], "nothing is on the ball")

    def test_going_home_after_a_tall_tower_goes_round_it(self):
        """Straight from above the tower to the home position the arm swept down through the tower top (a real arm
        would have knocked it over), and "up, across, down" isn't possible there: so near its base the arm can't
        reach that high."""
        self.world.switch_scenario("tower_building")
        self.executor.forget_scene()
        self.executor.scene_builder.reset_tracking()
        ids = {label: o["id"] for label, o in self.listed().items()}
        order = ["red cube", "yellow cube", "green cube", "blue cube", "purple cube"]
        self.executor.execute("pick", {"object_id": ids[order[0]]})
        self.executor.execute("place_at", {"place_name": "tower spot"})
        for below, top in zip(order, order[1:]):
            self.executor.execute("pick", {"object_id": ids[top]})
            self.executor.execute("place_on", {"object_id": ids[below]})
        standing = {n: self.world.get_object_position_mm(n) for n in ("red_cube", "purple_cube")}
        self.executor.execute("home", {})
        self.executor.execute("list_objects", {})
        for name, before in standing.items():
            self.assertEqual(self.world.get_object_position_mm(name), before, f"{name} not knocked")

    def test_letting_go_right_beside_a_cube_turns_the_fingers_out_of_its_way(self):
        self.world.switch_scenario("two_blocks_and_tray")
        self.executor.forget_scene()
        self.executor.scene_builder.reset_tracking()
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["red cube"]["id"]})
        # (on the left: on the right the tray's wall is too near for the fingers, as it would be for the real ones)
        result = self.executor.execute("place_beside", {"object_id": listed["blue cube"]["id"], "side": "left",
                                                        "gap_mm": 5})
        self.assertIn("5 mm apart", result)
        red, blue = (self.world.get_object_position_mm(n) for n in ("red_cube", "blue_cube"))
        self.assertAlmostEqual(abs(red[1] - blue[1]), 25.0, delta=1.5)         # 20 mm cubes, 5 mm apart
        self.assertAlmostEqual(red[2], 10.0, delta=0.5, msg="on the table beside it")

    def test_beside_a_can_a_pen_is_turned_so_the_fingers_fit(self):
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["blue bar"]["id"]})
        result = self.executor.execute("place_beside", {"object_id": listed["grey cylinder"]["id"], "side": "left",
                                                        "gap_mm": 10})
        self.assertIn("turned a quarter turn", result)
        bar, can = (self.world.get_object_position_mm(n) for n in ("blue_bar", "grey_cylinder"))
        self.assertAlmostEqual(bar[1] - can[1], 12.0 + 10.0 + 30.0, delta=2.0, msg="lying along the way, 10 mm off")
        self.assertAlmostEqual(bar[2], 5.0, delta=0.5, msg="on the table")

    def test_a_side_with_no_room_for_the_fingers_says_which_sides_have(self):
        self.world.switch_scenario("two_blocks_and_tray")
        self.executor.forget_scene()
        self.executor.scene_builder.reset_tracking()
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["red cube"]["id"]})
        with self.assertRaisesRegex(ValueError, "tray's wall.*room on its left"):
            self.executor.execute("place_beside", {"object_id": listed["blue cube"]["id"], "side": "right",
                                                   "gap_mm": 10})
        preview = self.executor.planned_target("place_beside", {"object_id": listed["blue cube"]["id"], "side": "left",
                                                                "gap_mm": 10})
        self.executor.execute("place_beside", {"object_id": listed["blue cube"]["id"], "side": "left", "gap_mm": 10})
        red = self.world.get_object_position_mm("red_cube")
        self.assertLess(math.dist(red[:2], (preview.x, preview.y)), 1.0, "the preview showed where it went")

    def test_the_preview_of_putting_something_in_a_tray_is_the_spot_it_goes_to(self):
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["white cube"]["id"]})
        preview = self.executor.planned_target("place_at", {"place_name": "tray"})
        self.executor.execute("place_at", {"place_name": "tray"})
        white = self.world.get_object_position_mm(self.ids["white cube"])
        self.assertLess(math.dist(white[:2], (preview.x, preview.y)), 1.0)

    def test_a_place_of_unknown_size_says_to_do_it_one_at_a_time(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder) / "box.json").write_text('{"x": 250, "y": 0, "z": 40, "r": 0}', encoding="utf-8")
            self.executor.poses_dir = Path(folder)
            listed = self.listed()
            with self.assertRaisesRegex(ValueError, "one at a time with pick and place_at"):
                self.executor.execute("put_all_in", {"place_name": "box", "object_ids": [listed["white cube"]["id"]]})

    def test_the_model_uses_it_and_the_goal_is_checked(self):
        def call(name, args):
            return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args}}]}

        class Model:
            last_stats = {}
            answers = [lambda r: call("list_objects", {}),
                       lambda r: call("put_all_in", {"place_name": "tray", "object_ids": [
                           o["id"] for o in ast.literal_eval(r[0])["objects"]]}),
                       lambda r: {"role": "assistant", "content": "Five went in; the ball didn't fit."}]

            def chat(self, model, messages, tools=None, temperature=0.2):
                # (the last answer again if asked again: a "done" the app's check says isn't is sent back once)
                answer = self.answers.pop(0) if len(self.answers) > 1 else self.answers[0]
                return answer([m["content"] for m in messages if m["role"] == "tool"])
        run = Agent(Model(), self.executor, "qwen3:8b", look_first=False).run("can u put everything in the tray")
        self.assertEqual(run.trace["understood"]["task"], "put several into a place")
        goal = run.trace["end"]["goal"]
        self.assertIn("put in the tray", goal["detail"])
        from app.ui.model_tab import render
        page = render([run.trace])
        self.assertIn("biggest first", page)

    def test_a_tower_in_the_tray_is_built_not_put_all_in(self):
        """What happened: both cubes already in the tray, "make a tower in the tray" -- the model called put_all_in,
        which found them already there, and it replied that nothing needed doing. And measured from the table, the
        cubes in the tray were 24 mm, not 20."""
        self.world.switch_scenario("two_blocks_and_tray")
        self.executor.forget_scene()
        self.executor.scene_builder.reset_tracking()
        listed = self.listed()
        self.executor.execute("put_all_in", {"place_name": "tray", "object_ids": [o["id"] for o in listed.values()]})
        self.executor.scene_builder.reset_tracking()

        def call(name, args):
            return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args}}]}

        seen = {}

        class Model:
            last_stats = {}
            answers = [lambda r: call("list_objects", {}),
                       lambda r: seen.update(ast.literal_eval(r[0])) or call(
                           "put_all_in", {"place_name": "tray", "object_ids": [o["id"] for o in seen["objects"]]}),
                       lambda r: call("pick", {"object_id": next(o["id"] for o in seen["objects"]
                                                                 if o["label"] == "blue cube")}),
                       lambda r: call("place_on", {"object_id": next(o["id"] for o in seen["objects"]
                                                                     if o["label"] == "red cube")}),
                       lambda r: {"role": "assistant", "content": "The blue cube is on the red cube, in the tray."}]

            def chat(self, model, messages, tools=None, temperature=0.2):
                # (the last answer again if asked again: a "done" the app's check says isn't is sent back once)
                answer = self.answers.pop(0) if len(self.answers) > 1 else self.answers[0]
                return answer([m["content"] for m in messages if m["role"] == "tool"])
        run = Agent(Model(), self.executor, "qwen3:8b", look_first=False).run("make a tower in the tray")
        self.assertIn("TOWER", run.steps[1].result, "put_all_in was not done: the model was told how instead")
        self.assertEqual({o["label"]: o["height_mm"] for o in seen["objects"]}, {"red cube": 20, "blue cube": 20, "green cube": 20},
                         "measured from the tray's floor")
        red, blue = (self.world.get_object_position_mm(n) for n in ("red_cube", "blue_cube"))
        self.assertLess(math.dist(red[:2], blue[:2]), 2.0)
        self.assertAlmostEqual(blue[2] - red[2], 20.0, delta=1.0, msg="on it, not dropped from 4 mm up")
        self.assertIn("in the tray", run.final_message)

    def test_a_tower_is_built_in_the_order_asked_for(self):
        """What happened: "Tower: red, yellow, green, blue, purple" was built red, blue, green, yellow, purple, and
        the app's own check called it done. Now a pick out of order isn't done: the model is told the next one."""
        from app.llm.trace import tower_order
        self.world.switch_scenario("tower_building")
        self.executor.forget_scene()
        self.executor.scene_builder.reset_tracking()
        order = ["red cube", "yellow cube", "green cube", "blue cube", "purple cube"]
        seen = {}

        def call(name, args):
            return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args}}]}

        def id_of(label):
            return next(o["id"] for o in seen["objects"] if o["label"] == label)

        def following(results):
            """Like the model did: blue next -- then whatever the app says is next."""
            said = results[-1]
            if "Next: pick the " in said:
                label = said.split("Next: pick the ")[1].split(" (")[0]
                return call("pick", {"object_id": id_of(label)})
            return None
        plan = [lambda r: call("list_objects", {}),
                lambda r: seen.update(ast.literal_eval(r[0])) or call("pick", {"object_id": id_of("red cube")}),
                lambda r: call("place_at", {"place_name": "tower spot"}),
                lambda r: call("pick", {"object_id": id_of("blue cube")})]       # out of order
        built = []
        for below, top in zip(order, order[1:]):
            plan.append(lambda r, top=top: following(r) or call("pick", {"object_id": id_of(top)}))
            plan.append(lambda r, below=below: call("place_on", {"object_id": id_of(below)}))
        plan.append(lambda r: {"role": "assistant", "content": "Built it."})

        class Model:
            last_stats = {}

            def chat(self, model, messages, tools=None, temperature=0.2):
                return plan.pop(0)([m["content"] for m in messages if m["role"] == "tool"])
        run = Agent(Model(), self.executor, "qwen3:8b", max_tool_calls=20, look_first=False).run("Tower: red, yellow, green, blue, purple")
        refused = [s.result for s in run.steps if s.result.startswith("ERROR: not done. The tower")]
        self.assertTrue(refused and "Next: pick the yellow cube" in refused[0], refused)
        piles = self.executor.piles()
        self.assertEqual(max(piles, key=len), order, run.trace["end"])
        self.assertEqual(run.trace["end"]["goal"]["status"], "met", run.trace["end"]["goal"])
        self.assertEqual(tower_order("Tower: red, yellow, green, blue, purple", order), order)

    def tower_run(self, answers, prompt="Tower: red, yellow, green, blue, purple"):
        """Runs a scripted model: each answer is (tool, label or args) or a final text, with the objects' ids filled
        in from its list_objects."""
        seen = {}

        def id_of(label):
            return next(o["id"] for o in seen["objects"] if o["label"] == label)

        class Model:
            last_stats = {}

            def chat(self, model, messages, tools=None, temperature=0.2):
                results = [m["content"] for m in messages if m["role"] == "tool"]
                if results and not seen:
                    seen.update(ast.literal_eval(results[0]))
                answer = answers.pop(0) if len(answers) > 1 else answers[0]
                if isinstance(answer, str):
                    return {"role": "assistant", "content": answer}
                name, arg = answer
                args = arg if isinstance(arg, dict) else {"object_id": id_of(arg)} if arg else {}
                return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args}}]}
        return Agent(Model(), self.executor, "qwen3:8b", max_tool_calls=30, look_first=False).run(prompt)

    def tower_scene(self):
        self.world.switch_scenario("tower_building")
        self.executor.forget_scene()
        self.executor.scene_builder.reset_tracking()

    def test_the_bottom_of_a_tower_is_not_put_on_another_cube(self):
        """What happened: the model put the red cube (the bottom) on the purple one; the tower grew on the purple
        cube, and the app kept saying "just the red cube so far, next the yellow one" -- with the yellow on the red
        already -- and the model picked the yellow cube off and put it back, for five minutes."""
        self.tower_scene()
        run = self.tower_run([("list_objects", None), ("pick", "red cube"), ("place_on", "purple cube"),
                              ("place_at", {"place_name": "tower spot"}), ("pick", "yellow cube"),
                              ("place_on", "red cube"), ("pick", "green cube"), ("place_on", "yellow cube"), "Done."])
        self.assertIn("is its bottom: put it down with place_at", run.steps[2].result)
        self.assertEqual(max(self.executor.piles(), key=len), ["red cube", "yellow cube", "green cube"])

    def test_a_tower_built_wrong_is_taken_apart_from_the_top_first(self):
        self.tower_scene()
        listed = self.listed()
        for label, below in (("red cube", "purple cube"), ("yellow cube", "red cube")):   # as in the picture
            self.executor.execute("pick", {"object_id": listed[label]["id"]})
            self.executor.execute("place_on", {"object_id": listed[below]["id"]})
        run = self.tower_run([("list_objects", None), ("pick", "green cube"), ("pick", "yellow cube"),
                              ("place_free", {"where": "left"}), "Stopping here."])
        self.assertIn("the red cube (the bottom) is standing on the purple cube", run.steps[1].result)
        self.assertIn("pick the yellow cube", run.steps[1].result)
        self.assertTrue(run.steps[2].result.startswith("Picked up yellow cube"), run.steps[2].result)

    def test_a_model_going_round_in_circles_is_stopped(self):
        self.tower_scene()
        run = self.tower_run([("list_objects", None)] + [("pick", "blue cube")] * 6 + ["never reached"])
        self.assertIn("Stopped: the model kept trying", run.final_message)
        self.assertEqual(sum(s.result.startswith("ERROR: not done") for s in run.steps), 5)

    def test_a_tower_in_the_wrong_order_is_not_called_done(self):
        from app.llm.trace import PromptTrace
        trace = PromptTrace("Tower: red, yellow, green, blue, purple", "qwen3:8b", 0.2, False, 20)
        trace.data["understood"]["task"] = "build a tower"

        class Built:
            _last_scene = []

            def piles(self):
                return [["red cube", "blue cube", "green cube", "yellow cube", "purple cube"]]
        goal = trace._tower_check(Built())
        self.assertEqual(goal["status"], "not met")
        self.assertIn("asked for, bottom to top: red cube, yellow cube, green cube, blue cube, purple cube", goal["detail"])

    def test_the_model_is_told_to_use_it(self):
        from app.llm.agent import SYSTEM_PROMPT
        self.assertIn("put_all_in(place_name", SYSTEM_PROMPT)
        self.assertEqual(understand("Ball and both cubes in the tray")["task"], "put several into a place")


if __name__ == "__main__":
    unittest.main()

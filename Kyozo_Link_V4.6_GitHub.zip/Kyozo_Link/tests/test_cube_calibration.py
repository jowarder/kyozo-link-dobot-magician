"""Calibrate with a cube: the robot puts a cube it holds down at spots across the table, the wrist turned, and the
depth camera finds it there (before/after depth pictures), with no marker; the table's plane gives the tilt and
height. Then, optionally, the heights from towers of 2 or 3 cubes, and a pick test.

Run from the project root:  python -m unittest tests.test_cube_calibration
"""
from __future__ import annotations

import dataclasses
import json
import math
import os
import tempfile
import time
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest import mock

import numpy as np

import harness  # noqa: F401  (project root on the path; the tests' own config)
from app import robots
from app.calibration import cube
from app.calibration.correction import XYCorrection
from app.calibration.cube import (MIN_SPOTS, CubePair, CubeSighting, TablePlane, _Hand, find_new_object, plan_spots,
                                  put_cube_down, run_cube_calibration, run_cube_stacks, run_pick_test, solve_on_plane,
                                  to_colour_frame, tool_offset)
from app.calibration.guidance import min_radius_mm
from app.calibration.storage import (calibration_history, clear_calibration, load_calibration, restore_calibration,
                                     save_calibration)
from app.calibration.verify import PointCheck, VerifyResult
from app.hardware.gripper import GripperSpec
from app.hardware.interfaces import Intrinsics, Pose
from app.hardware.sim_camera import SimCamera
from app.hardware.sim_robot import SimRobot
from app.twin.world import TwinWorld
from app.vision.locator import LocatedObject
from app.vision.scene import SceneBuilder
from app.vision.undistort import Distorter, Undistorter


def tilted(exact: np.ndarray, degrees: float, pivot) -> np.ndarray:
    """A calibration off as the marker's often is: turned a little about a point above the table."""
    a = math.radians(degrees)
    turn = np.array([[1, 0, 0, 0], [0, math.cos(a), -math.sin(a), 0], [0, math.sin(a), math.cos(a), 0], [0, 0, 0, 1]])
    there, back = np.eye(4), np.eye(4)
    there[:3, 3], back[:3, 3] = pivot, -np.asarray(pivot, float)
    return there @ turn @ back @ exact


class Bench:
    """The demo workspace as the user leaves it to start: the table clear but for the red cube; the fingertips
    touched the table (z = 0), then the open gripper was lowered round the cube as far as it goes (1 mm above the
    table, or resting on the cube's top when the fingers are shorter than it is tall: the Dobot's) and closed."""

    def __init__(self, test: unittest.TestCase, key: str = "dobot_magician", quality: str = "Perfect"):
        self.profile = robots.set_active(key)
        test.addCleanup(robots.set_active, "dobot_magician")
        self.world = TwinWorld()
        client = self.world.start()
        test.addCleanup(self.world.stop)
        self.world.load_scenario("two_blocks_and_tray")
        self.bounds = {axis: list(v) for axis, v in self.profile.demo_bounds.items()}
        self.gripper = GripperSpec.from_config({"gripper_type": "gripper"}, self.profile.gripper_defaults())
        self.robot = SimRobot(client, self.bounds, max_speed=3000, max_reach_mm=self.profile.max_reach_mm,
                              world=self.world, gripper=self.gripper, marker_offset_mm=(9.0, -6.0))
        self.robot.connect()
        self.camera = SimCamera(client)
        self.camera.outline_bodies = self.robot.body_ids
        self.camera.connect()
        self.camera.set_faults(quality)
        self.camera._rng = np.random.default_rng(3)
        self.ox = self.profile.scene_offset_mm[0]
        self.ids = {m["label"]: object_id for object_id, m in self.world.object_meta.items()}
        for n, (label, object_id) in enumerate(self.ids.items()):
            if label != "red cube":
                self.robot._place_object(object_id, -900 - 60 * n, 900, 10)   # off the table
        self.robot._place_object(self.ids["red cube"], 200 + self.ox, 30, 10)
        self.exact = self.camera.camera_to_robot_transform()
        self.grip_z = max(1.0, 20.0 - self.gripper.finger_depth_mm)
        self.robot.move_to(Pose(200 + self.ox, 30, 60, 0))
        self.robot.move_to(Pose(200 + self.ox, 30, self.grip_z, 0))
        self.robot.close_gripper()
        test.assertEqual(self.robot._held, self.ids["red cube"])
        self.reach = self.robot.max_reach_mm

    def xy_errors(self, transform: np.ndarray, z: float, correction=None) -> list[float]:
        """How far off `transform` puts points at height z over the middle of the table, seen from above (true: the
        simulator's camera). (Its heights are left out: the simulator's rendered table reads ~0.6 mm above where
        the robot touches it, and the calibration rightly goes by the touch.)"""
        out = []
        for x in range(130, 330, 40):
            for y in range(-120, 121, 40):
                truth = np.array([x + self.ox, y, z, 1.0])
                mapped = cube.predict(transform, correction, (np.linalg.inv(self.exact) @ truth)[:3])
                out.append(float(math.hypot(*(mapped[:2] - truth[:2]))))
        return out

    def phase1(self, **kwargs):
        kwargs.setdefault("old_transform", tilted(self.exact, 1.5, (200 + self.ox, 0, 170)))
        kwargs.setdefault("mode", "quick")
        kwargs.setdefault("table_z", 0.0)
        kwargs.setdefault("frames", 3 if self.camera.faults.is_perfect else 10)   # (the app takes 20)
        return run_cube_calibration(self.robot, self.camera, self.bounds, self.reach, self.gripper, settle_s=0.0,
                                    **kwargs)

    def resume(self, progress, **kwargs):
        kwargs.setdefault("frames", 3 if self.camera.faults.is_perfect else 10)
        return run_cube_calibration(self.robot, self.camera, self.bounds, self.reach, self.gripper, resume=progress,
                                    settle_s=0.0, **kwargs)

    def take_over(self) -> None:
        """What the user does when a run pauses: jog the gripper round the cube wherever it is (turned to match it)
        and close it -- or, if it is still held, lower it onto the table."""
        robot = self.robot
        here = robot.get_pose()
        if robot._held is not None:
            robot.move_to(Pose(here.x, here.y, self.grip_z, here.r))
            return
        robot.open_gripper()
        x, y, _ = self.world.get_object_position_mm(self.ids["red cube"])
        r = cube.middle_turn(x, y)
        r += cube._wrap90(self.world.get_object_yaw_deg(self.ids["red cube"]) - r)
        robot.move_to(Pose(here.x, here.y, max(here.z, 60.0), here.r))
        robot.move_to(Pose(x, y, 60.0, r))
        robot.move_to(Pose(x, y, self.grip_z, r))
        robot.close_gripper()
        assert robot._held == self.ids["red cube"]

    def place_extra(self, count: int) -> None:
        """What the user does for the height step: 1 or 2 more cubes on the table, well apart."""
        others = [label for label in self.ids if label not in ("red cube", "tray")]
        for label, y in zip(others[:count], (-60.0, 100.0)):
            self.robot._place_object(self.ids[label], 230 + self.ox, y, 10)


# ---- finding the cube ---------------------------------------------------------------------------------------------------
class FindingTheCubeTests(unittest.TestCase):
    K = Intrinsics(fx=600.0, fy=600.0, cx=320.0, cy=240.0, width=640, height=480)

    def box(self, x0=30.0, y0=10.0, lean=0.0):
        before = np.full((480, 640), 600.0, np.float32)        # a table 600 mm from the camera, straight below
        after = before.copy()
        px = 600.0 / 580.0                                      # pixels per mm on its top (580 mm away)
        u0, v0 = 320 + x0 * px, 240 + y0 * px
        rows, cols = slice(int(round(v0 - 10 * px)), int(round(v0 + 10 * px))), \
            slice(int(round(u0 - 10 * px)), int(round(u0 + 10 * px)))
        u = np.arange(cols.start, cols.stop)
        after[rows, cols] = 580.0 - lean * (u - u0)[None, :] / px   # `lean`: mm of height per mm across
        return after, before

    def test_a_new_box_on_a_flat_table_is_found_with_its_height_size_and_the_table_round_it(self):
        after, before = self.box()
        seen = find_new_object(after, before, self.K)
        self.assertIsNotNone(seen)
        self.assertAlmostEqual(seen.height_mm, 20.0, delta=0.5)
        self.assertAlmostEqual(seen.cam_xyz[0], 30.0, delta=1.0)
        self.assertAlmostEqual(seen.cam_xyz[1], 10.0, delta=1.0)
        self.assertAlmostEqual(seen.cam_xyz[2], 580.0, delta=0.5)
        self.assertAlmostEqual(seen.footprint_mm[0], 20.0, delta=2.0)
        self.assertLess(seen.tilt_deg, 0.5)
        self.assertGreater(len(seen.table_points), 100)
        np.testing.assert_allclose(seen.table_points[:, 2], 600.0)

    def test_a_cube_that_landed_crooked_shows_its_lean(self):
        for degrees in (14, 20):
            after, before = self.box(lean=math.tan(math.radians(degrees)))
            seen = find_new_object(after, before, self.K)
            # left out by its lean, or (leaning so far that only a strip of its top is level) by its top's outline
            self.assertTrue(seen.tilt_deg > cube.TILT_MAX_DEG or not cube._whole(seen, 20.0), degrees)

    def test_a_noisy_flat_top_is_not_taken_for_a_lean(self):
        # a real camera's depth: flat cube, a few mm of noise on its top -- 6-59 degrees of "lean" at the lab
        after, before = self.box()
        rng = np.random.default_rng(5)
        noise = rng.normal(0.0, 1.5, after.shape).astype(np.float32)
        top = after < 590
        after = np.where(top, after + noise, after)
        seen = find_new_object(after, before, self.K)
        self.assertIsNotNone(seen)
        self.assertLess(seen.tilt_deg, cube.TILT_MAX_DEG)

    def test_the_cube_not_the_bigger_gripper_waiting_in_view(self):
        # at the lab: the gripper, open at its waiting place in view (closed on the cube in the empty-table picture),
        # was new too, bigger than the cube -- and was measured instead (42 mm long, "88 degrees")
        after, before = self.box(x0=30.0, y0=10.0)
        px = 600.0 / 520.0                                      # an arm part 80 mm above the table, 45 x 15 mm
        u0, v0 = 320 - 120 * px, 240 - 80 * px
        after[int(v0 - 7.5 * px):int(v0 + 7.5 * px), int(u0 - 22.5 * px):int(u0 + 22.5 * px)] = 520.0
        seen = find_new_object(after, before, self.K)
        self.assertAlmostEqual(seen.cam_xyz[0], 30.0, delta=1.0)
        self.assertAlmostEqual(seen.height_mm, 20.0, delta=0.5)
        # and where the cube should be, if a calibration says so
        hinted = find_new_object(after, before, self.K, expect_px=(320 + 30 * 600 / 580, 240 + 10 * 600 / 580))
        self.assertAlmostEqual(hinted.cam_xyz[0], 30.0, delta=1.0)

    def test_nothing_new_or_only_specks_is_nothing(self):
        before = np.full((480, 640), 600.0, np.float32)
        self.assertIsNone(find_new_object(before.copy(), before, self.K))
        speck = before.copy()
        speck[100:104, 100:104] = 560.0
        self.assertIsNone(find_new_object(speck, before, self.K))

    def test_two_new_boxes_are_both_found(self):
        after, before = self.box(x0=-60.0)
        other, _ = self.box(x0=60.0)
        after = np.minimum(after, other)
        found = cube.find_new_objects(after, before, self.K, 2)
        self.assertEqual(sorted(round(s.cam_xyz[0] / 10) for s in found), [-6, 6])


class VerifyLeanTests(unittest.TestCase):
    def result(self, offsets):
        return VerifyResult(points=[PointCheck(target=(0, 0, 0), predicted_px=(0, 0), error_mm=math.hypot(*o),
                                               offset_mm=o) for o in offsets])

    def test_misses_that_all_lean_one_way_are_reported_as_a_lean(self):
        result = self.result([(2.0, -0.4), (1.6, -0.6), (2.2, -0.2), (1.8, -0.5)])
        dx, dy = result.lean_mm
        self.assertAlmostEqual(dx, 1.9, places=6)
        self.assertAlmostEqual(dy, -0.425, places=6)
        self.assertLess(result.scatter_mm, 0.4)
        self.assertIn("1.9 mm towards +x", result.lean_text)
        self.assertIn("towards -y", result.lean_text)
        self.assertIn("Usable", result.verdict)     # typical ~1.9 mm: under 3, not under 1.5

    def test_scattered_misses_are_not_a_lean(self):
        result = self.result([(1.0, 0.0), (-1.0, 0.0), (0.0, 1.0), (0.0, -1.0)])
        self.assertEqual(result.lean_text, "")
        self.assertIn("Good", result.verdict)       # 1 mm typical


# ---- where, and how high ------------------------------------------------------------------------------------------------
class SpotPlanningTests(unittest.TestCase):
    def test_spots_spread_over_the_reachable_table_in_view_with_the_turns_dealt_out(self):
        profile = robots.active()
        bounds = {axis: list(v) for axis, v in profile.demo_bounds.items()}
        reach = profile.max_reach_mm
        angles = (-60.0, -20.0, 20.0, 60.0)
        spots = plan_spots(bounds, reach, (200.0, 30.0), 12, seen=lambda x, y: y < 120, angles=angles)
        self.assertEqual(len(spots), 12)
        for x, y, turn in spots:
            self.assertTrue(min_radius_mm() + 10 - 1e-6 <= math.hypot(x, y) <= 0.92 * reach)
            self.assertTrue(bounds["x"][0] <= x <= bounds["x"][1] and bounds["y"][0] <= y <= bounds["y"][1])
            self.assertLess(y, 120)
            self.assertIn(turn, angles)
        self.assertEqual({turn for _, _, turn in spots}, set(angles))     # each turn used, three times each
        closest = min(math.dist(a[:2], b[:2]) for i, a in enumerate(spots) for b in spots[i + 1:])
        self.assertGreaterEqual(closest, 25.0)

    def test_a_turn_the_wrist_cant_make_there_is_swapped_for_one_it_can(self):
        profile = robots.active()
        bounds = {axis: list(v) for axis, v in profile.demo_bounds.items()}
        spots = plan_spots(bounds, profile.max_reach_mm, (200.0, 30.0), 10, seen=lambda x, y: True,
                           angles=(-60.0, 60.0), fits=lambda turn, x, y: turn < 0 or y < 0)
        self.assertTrue(all(turn < 0 or y < 0 for x, y, turn in spots))

    def test_spots_are_where_the_camera_sees_the_table_not_too_slanted(self):
        profile = robots.active()
        bounds = {axis: list(v) for axis, v in profile.demo_bounds.items()}
        tilt = lambda x, y: 20.0 if y > -40.0 else 50.0                     # (seen slanted on one side)
        spots = plan_spots(bounds, profile.max_reach_mm, (200.0, 30.0), 6, seen=lambda x, y: True, tilt=tilt)
        self.assertEqual(len(spots), 6)
        self.assertTrue(all(y > -40.0 for x, y, _ in spots), spots)
        few = lambda x, y: 20.0 if math.dist((x, y), (200.0, 30.0)) < 30.0 else 40.0 + y / 10.0
        spots = plan_spots(bounds, profile.max_reach_mm, (200.0, 30.0), 6, seen=lambda x, y: True, tilt=few)
        self.assertEqual(len(spots), 6, "too few well seen: the best-seen ones instead")
        camera = np.eye(4)
        camera[:3, 3] = (473.0, -2.0, 415.0)                              # (the lab's camera, about)
        slant = cube.view_tilt_check(camera, 0.0)
        self.assertAlmostEqual(slant(473.0, -2.0), 0.0, places=3)
        self.assertGreater(slant(120.0, -150.0), cube.VIEW_TILT_MAX_DEG, "near the base, to the side: too slanted")
        self.assertIsNone(cube.view_tilt_check(None, 0.0))

    def test_without_a_calibration_the_spots_stay_near_where_the_cube_was(self):
        profile = robots.active()
        bounds = {axis: list(v) for axis, v in profile.demo_bounds.items()}
        for x, y, _ in plan_spots(bounds, profile.max_reach_mm, (200.0, 30.0), 10):
            self.assertLessEqual(math.dist((x, y), (200.0, 30.0)), cube.NEAR_START_MM)

    def test_spots_stay_where_the_table_was_touched_and_the_first_is_where_the_cube_was(self):
        # (the lab: a spot 120 mm past the touches, at the edge of the view, landed crooked and the fingers came down
        # on it; and the first put-down never went back on the paper's centre, where the cube was gripped)
        profile = robots.active()
        bounds = {axis: list(v) for axis, v in profile.demo_bounds.items()}
        heights = cube.TableHeights([(x, y, -39.0) for _name, x, y in cube.TOUCH_POINTS])
        self.assertEqual(len(cube.TOUCH_POINTS), 6)
        self.assertFalse(heights.covers(150.0, 230.0))
        self.assertTrue(heights.covers(225.0, 0.0) and heights.covers(180.0, 80.0) and heights.covers(265.0, -80.0))
        for seen in (None, lambda x, y: True):
            spots = plan_spots(bounds, profile.max_reach_mm, (225.0, 0.0), 20, seen=seen, allowed=heights.covers)
            self.assertEqual(len(spots), 20)
            self.assertEqual(spots[0][:2], (225.0, 0.0), "the first back where the cube was gripped")
            self.assertTrue(all(heights.covers(x, y) for x, y, _ in spots))
        # two touches along the arm only: nothing kept from the sides (they say nothing about them)
        two = cube.TableHeights([(225.0, 0.0, -39.0), (275.0, 0.0, -39.5)])
        self.assertTrue(two.covers(200.0, 150.0))
        # ...and with no calibration, still near where the cube was (touches that don't spread sideways limit nothing
        # sideways: spots went over the whole reach, half out of the picture)
        for x, y, _ in plan_spots(bounds, profile.max_reach_mm, (225.0, 0.0), 10, allowed=two.covers):
            self.assertLessEqual(math.dist((x, y), (225.0, 0.0)), cube.NEAR_START_MM)

    def test_the_touches_verdict(self):
        flat = [(x, y, -39.0 + 0.007 * (x - 225.0)) for _name, x, y in cube.TOUCH_POINTS]
        self.assertEqual(cube.TableHeights(flat).verdict()[0], "good")
        # the lab's, 2026-10-19: the table sloping 4.6 mm per 100 mm, T4 1.4 mm below the others
        lab = [(225, 0, -38.3), (275, 0, -40.3), (200, 110, -39.4), (200, -110, -39.1), (165, 90, -36.9),
               (165, -90, -36.1)]
        level, words = cube.TableHeights(lab).verdict()
        self.assertEqual(level, "usable")
        self.assertIn("T4 is 1.4 mm off", words)
        pressed = list(flat)
        pressed[2] = (pressed[2][0], pressed[2][1], pressed[2][2] - 4.0)     # 4 mm into the table
        level, words = cube.TableHeights(pressed).verdict()
        self.assertEqual(level, "redo")
        self.assertIn("Redo T3: it is 4", words)

    def test_touches_that_agree_on_a_sloping_plane_are_believed(self):
        # the lab, 2026-10-21: 6 touches within 0.6 mm of a plane 7 mm per 100 mm out of level, refused as "too steep"
        def plane(x, y):
            return -36.0 - 0.07 * (math.hypot(x, y) - 165.0)
        wobble = (0.3, -0.2, 0.4, -0.3, 0.1, -0.4)
        six = [(x, y, plane(x, y) + w) for (_n, x, y), w in zip(cube.TOUCH_POINTS, wobble)]
        heights = cube.TableHeights(six)
        self.assertTrue(heights.agreed)
        self.assertFalse(heights.too_steep)
        verdict, words = heights.verdict()
        self.assertEqual(verdict, "usable", words)
        two = cube.TableHeights([six[0], six[1]])
        self.assertTrue(two.too_steep, "2 touches: one bad one could make that slope")
        steep = cube.TableHeights([(x, y, -36.0 - 0.15 * (math.hypot(x, y) - 165.0)) for _n, x, y in cube.TOUCH_POINTS])
        self.assertTrue(steep.too_steep)
        self.assertIn("press Home", steep.verdict()[1])

    def test_the_odd_touch_is_told_only_with_six(self):
        # (marking the touch furthest from the fit through all of them marked the good middle one, not the bad one)
        good = [(x, y, -39.0 + 0.007 * (x - 225.0)) for _name, x, y in cube.TOUCH_POINTS]
        self.assertIsNone(cube.TableHeights(good).odd_one())
        for bad in range(6):
            touches = list(good)
            x, y, z = touches[bad]
            touches[bad] = (x, y, z - 3.0)                      # pressed 3 mm into the table
            self.assertEqual(cube.TableHeights(touches).odd_one(), bad)
            self.assertIsNone(cube.TableHeights(touches[:4] if bad < 4 else good[:4]).odd_one(), "4: can't tell")

    def test_the_table_height_from_one_touch_or_more(self):
        one = cube.TableHeights([(200.0, 0.0, -50.0)])
        self.assertEqual(one.at(120.0, -200.0), -50.0)
        self.assertIn("1 place", one.describe())
        # the lab's Dobot: stretched out it stood ~2.4 mm higher than near
        two = cube.TableHeights([(200.0, 0.0, -51.4), (280.0, 0.0, -49.0)])
        self.assertAlmostEqual(two.at(200.0, 0.0), -51.4)
        self.assertAlmostEqual(two.at(280.0, 0.0), -49.0)
        self.assertAlmostEqual(two.at(0.0, 240.0), -50.2)               # by the reach, whichever way
        self.assertAlmostEqual(two.per_100mm, 3.0)
        self.assertEqual(two.at(500.0, 0.0), two.at(320.0, 0.0))        # never past the touches (+40 mm)
        self.assertFalse(two.too_steep)
        self.assertIn("2 places", two.describe())
        three = cube.TableHeights([(200.0, 0.0, -51.0), (280.0, 0.0, -49.0), (150.0, 200.0, -50.0)])
        for x, y, z in three.touches:
            self.assertAlmostEqual(three.at(x, y), z)
        self.assertTrue(cube.TableHeights([(200.0, 0.0, -50.0), (260.0, 0.0, -40.0)]).too_steep)   # a bad touch
        near = cube.TableHeights([(200.0, 0.0, -50.0), (215.0, 0.0, -49.0)])    # too close to say how it slopes
        self.assertAlmostEqual(near.at(300.0, 0.0), -49.5)
        touches = cube.with_touch([(280.0, 0.0, -49.0)], (200.0, 0.0, -51.4))
        self.assertEqual(len(touches), 2)
        touches = cube.with_touch(touches, (210.0, 10.0, -51.0))           # near the second: replaces it
        self.assertEqual(touches, [(280.0, 0.0, -49.0), (210.0, 10.0, -51.0)])

    def test_the_arm_check_from_the_table_touches(self):
        level = [(200.0, 0.0, -51.4), (280.0, 0.0, -50.8)]
        self.assertEqual(cube.arm_check(level, last_table_z=-51.0), [])
        self.assertIn("homed", cube.arm_check(level, homed=False)[0])
        steep = [(200.0, 0.0, -51.4), (280.0, 0.0, -48.0)]                 # 4.3 mm per 100 mm
        self.assertIn("arm's own angles", " ".join(cube.arm_check(steep)))
        # the lab: -51.4 one day, 2.2 the next (switched off and on, not homed)
        self.assertIn("heights changed", " ".join(cube.arm_check([(200.0, 0.0, 2.2)], last_table_z=-51.4)))

    def test_before_the_runs_own_fit_the_calibration_in_use_says_where_the_cube_moved(self):
        transform = np.eye(4)
        transform[:3, 3] = (10.0, 0.0, 0.0)                               # (cam x + 10 = robot x)
        from types import SimpleNamespace
        progress = SimpleNamespace(old_transform=transform)
        spot = lambda cam, xy: CubePair(xy, 0.0, CubeSighting(cam_xyz=np.array(cam, float), height_mm=25.0,
                                                              footprint_mm=(25.0, 25.0), pixel=(0.0, 0.0),
                                                              depth_mm=400.0), None, 1, None)
        # its own error 0.5 mm in x at both spots so far; now the cube is 1.8 mm further on than where it was let go
        others = [spot((190.5, 0.0, 0.0), (200.0, 0.0)), spot((210.5, 20.0, 0.0), (220.0, 20.0))]
        now = others[0].sighting.__class__(cam_xyz=np.array([242.3, -10.0, 0.0]), height_mm=25.0,
                                           footprint_mm=(25.0, 25.0), pixel=(0.0, 0.0), depth_mm=400.0)
        (dx, dy), spread = cube._early_shift(progress, now, others, 250.0, -10.0)
        self.assertAlmostEqual(dx, 1.8, places=6)
        self.assertAlmostEqual(dy, 0.0, places=6)
        self.assertAlmostEqual(spread, 0.0, places=6)
        self.assertIsNone(cube._early_shift(progress, now, others[:1], 250.0, -10.0), "one spot: too few")
        progress.old_transform = np.eye(4)                                 # (no calibration in use: not said)
        self.assertIsNone(cube._early_shift(progress, now, others, 250.0, -10.0))

    def test_how_far_the_cube_turned_as_it_was_let_go(self):
        self.assertIsNone(cube.turn_estimate([10.0]))                      # the first spot: the usual one
        self.assertEqual(cube.cube_turned([10.0, 11.5]), 0.0)              # from the second, against the earlier
        self.assertAlmostEqual(cube.cube_turned([10.0, 16.0]), 6.0, delta=0.01)
        self.assertAlmostEqual(cube.cube_turned([10.0, 10.5, 4.0]), -6.25, delta=0.01)
        self.assertEqual(cube.cube_turned([10.0, 10.5, 30.0]), cube.TURN_FIX_MAX_DEG)
        self.assertEqual(cube.cube_turned([10.0, 10.5, 9.8, 10.9]), 0.0)   # the outline's own noise
        self.assertAlmostEqual(cube.cube_turned([10.0, 10.5, 9.8, 10.2, 18.0]), 8.0, delta=0.6)
        self.assertAlmostEqual(cube.cube_turned([10.0, 10.5, 9.8, 10.2, 2.0]), -8.0, delta=0.6)
        # a square looks the same turned 90 degrees: 44 and -44.5 are 1.5 degrees apart
        self.assertAlmostEqual(cube.cube_turned([44.0, -44.5, 44.8, 45.0, -38.0]), 7.4, delta=0.8)
        self.assertEqual(cube.cube_turned([10.0, 10.5, 9.8, 10.2, 40.0]), cube.TURN_FIX_MAX_DEG)   # 30: 15 at most

    def test_the_heights_the_fingertips_go_to(self):
        # the user's grip 1 mm above the table at z = 10; 20 mm cubes; fingers 15 mm deep (the Dobot's)
        hand = _Hand(table_z=10.0, first_grip=1.0, grip=1.0, cube_h=20.0, finger_mm=15.0)
        self.assertAlmostEqual(hand.release_z(), 11.5)          # the cube's foot 0.5 mm above the table
        self.assertAlmostEqual(hand.pick_z(), 12.0)             # taken back 1 mm higher than the first grip
        hand.taken()
        self.assertAlmostEqual(hand.grip, 2.0)
        self.assertAlmostEqual(hand.release_z(), 12.5)          # still let go 0.5 mm up
        self.assertAlmostEqual(hand.release_z(2), 10 + 20 + 2 + cube.STACK_GAP_MM)
        self.assertAlmostEqual(hand.pick_z(2), 10 + 20 + 6.0)   # as low as the fingers reach (3 mm wouldn't)
        hand.finger_mm = 20.0
        self.assertAlmostEqual(hand.pick_z(2), 10 + 20 + cube.STACK_REPICK_MM)


# ---- the solve ------------------------------------------------------------------------------------------------------------
def _sighting(cam):
    return CubeSighting(cam_xyz=np.asarray(cam, float), height_mm=20.0, footprint_mm=(20.0, 20.0), pixel=(0.0, 0.0),
                        depth_mm=float(cam[2]))


class SolveTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(1)
        # a camera 600 mm up, looking down at 50 degrees, turned 20 degrees: robot -> camera
        tilt, yaw = math.radians(40.0), math.radians(20.0)
        rx = np.array([[1, 0, 0], [0, math.cos(tilt), -math.sin(tilt)], [0, math.sin(tilt), math.cos(tilt)]])
        rz = np.array([[math.cos(yaw), -math.sin(yaw), 0], [math.sin(yaw), math.cos(yaw), 0], [0, 0, 1]])
        self.truth = np.eye(4)
        self.truth[:3, :3] = rz @ rx @ np.diag([1.0, -1.0, -1.0])
        self.truth[:3, 3] = (200.0, -350.0, 600.0)
        self.to_cam = np.linalg.inv(self.truth)
        self.table_z = 5.0
        self.xy = rng.uniform((140, -150), (320, 150), (16, 2))
        self.r = np.array([(-60.0, -20.0, 20.0, 60.0)[i % 4] for i in range(16)])
        table = np.c_[rng.uniform((100, -200), (350, 200), (3000, 2)), np.full(3000, self.table_z)]
        self.table_cam = (self.to_cam[:3, :3] @ table.T).T + self.to_cam[:3, 3]
        centre = self.table_cam.mean(axis=0)
        _, _, vt = np.linalg.svd(self.table_cam - centre)
        normal = vt[2] if np.dot(vt[2], -centre) > 0 else -vt[2]
        self.plane = TablePlane(normal=normal, offset=float(normal @ centre), rms_mm=0.0, points=3000)

    def cam_of(self, xy, z):
        points = np.c_[xy, np.full(len(xy), z)]
        return (self.to_cam[:3, :3] @ points.T).T + self.to_cam[:3, 3]

    def test_the_plane_and_the_spots_give_the_camera_back(self):
        transform, loo = solve_on_plane(self.cam_of(self.xy, self.table_z + 20), self.xy, self.plane, self.table_z)
        np.testing.assert_allclose(transform, self.truth, atol=1e-6)
        self.assertLess(np.abs(loo).max(), 1e-6)

    def test_more_adjustable_numbers_must_earn_their_place(self):
        # the lab, 2026-10-12 (13:32): a scale of 0.98 and the gripper's middle 6.5 mm off won by 0.04 mm, and the
        # robot then moved by that offset; the next run measured it +6.9 mm the other way
        from types import SimpleNamespace as Fit
        lab = [Fit(name="top, colour-aligned depth", typical_mm=2.11, scale=1.0, offset=None),
               Fit(name="top, colour-aligned depth, scale 1.0046", typical_mm=2.08, scale=1.0046, offset=None),
               Fit(name="top, colour-aligned depth, the gripper's middle", typical_mm=1.79, scale=1.0, offset=(-1.9, 1.0)),
               Fit(name="top, colour-aligned depth, scale 0.9795, the gripper's middle", typical_mm=1.69, scale=0.9795,
                   offset=(-6.5, 0.9)),
               Fit(name="top, the depth sensor's own picture", typical_mm=1.73, scale=1.0, offset=None)]
        self.assertEqual(cube.choose_fit(lab).name, "top, the depth sensor's own picture")
        # a real offset (the robot moving by a wrong one: 4 mm without, 1 mm with) is still kept
        real = [Fit(name="top, the depth sensor's own picture", typical_mm=3.95, scale=1.0, offset=None),
                Fit(name="top, the depth sensor's own picture, the gripper's middle", typical_mm=1.08, scale=1.0,
                    offset=(6.9, -3.5))]
        self.assertIsNotNone(cube.choose_fit(real).offset)
        # an unbelievable scale is left out however well it fits
        wild = [Fit(name="top", typical_mm=1.2, scale=1.0, offset=None),
                Fit(name="top, scale 0.9", typical_mm=0.3, scale=0.9, offset=None)]
        self.assertEqual(cube.choose_fit(wild).name, "top")

    def test_a_depth_scale_is_found_with_the_scale(self):
        cam = self.cam_of(self.xy, self.table_z + 20) * 1.005
        plane = TablePlane(self.plane.normal, self.plane.offset * 1.005, 0.0, 3000)
        plain, loo_plain = solve_on_plane(cam, self.xy, plane, self.table_z)
        scaled, loo_scaled = solve_on_plane(cam, self.xy, plane, self.table_z, with_scale=True)
        self.assertAlmostEqual(float(np.cbrt(np.linalg.det(scaled[:3, :3]))), 1 / 1.005, places=5)
        self.assertLess(np.abs(loo_scaled).max(), 1e-6)
        self.assertGreater(np.abs(loo_plain).max(), 0.1)

    def test_the_fingers_off_the_wrists_axis_are_found_from_the_turns(self):
        d = np.array([2.0, -1.5])
        turns = cube._rot(self.r)
        centres = self.xy + np.einsum("nij,j->ni", turns, d)          # where the cube really was
        rng = np.random.default_rng(2)
        cam = self.cam_of(centres, self.table_z + 20) + rng.normal(0, 0.05, (16, 3))
        found, without, with_d = tool_offset(cam, self.xy, self.r, self.plane, self.table_z)
        np.testing.assert_allclose(found, d, atol=0.2)
        self.assertLess(with_d, without)
        found, _, _ = tool_offset(self.cam_of(self.xy, self.table_z + 20), self.xy, self.r, self.plane, self.table_z)
        np.testing.assert_allclose(found, (0.0, 0.0), atol=1e-3)

    def test_the_correction_over_the_table_follows_a_bow_and_not_noise(self):
        rng = np.random.default_rng(4)
        xy = rng.uniform((140, -150), (320, 150), (20, 2))
        bow = np.c_[0.004 * (xy[:, 1] / 10) ** 2, -0.03 * (xy[:, 0] - 230) / 10]     # mm, growing to the edges
        cam = self.cam_of(xy - bow, self.table_z + 20)
        _, loo_plain = solve_on_plane(cam, xy, self.plane, self.table_z)
        correction, loo = cube.correction_for(cam, xy, self.plane, self.table_z, False)
        self.assertLess(np.median(np.hypot(*loo.T)), 0.5 * np.median(np.hypot(*loo_plain.T)))
        noise = self.cam_of(xy, self.table_z + 20) + rng.normal(0, 0.15, (20, 3))
        _, loo_plain = solve_on_plane(noise, xy, self.plane, self.table_z)
        _, loo = cube.correction_for(noise, xy, self.plane, self.table_z, False)
        self.assertGreater(np.median(np.hypot(*loo.T)), cube.CORRECTION_GAIN * np.median(np.hypot(*loo_plain.T)))

    def test_solve_cube_keeps_the_simplest_unless_another_is_better(self):
        cam = self.cam_of(self.xy, self.table_z + 20)
        pairs = []
        for (x, y), c, r in zip(self.xy, cam, self.r):
            s = _sighting(c)
            s.table_points = self.table_cam[:200]
            pairs.append(CubePair((x, y), r, s))
        best, tried, plane = cube.solve_cube(pairs, self.table_z, 20.0)
        self.assertEqual(best.name, "top, colour-aligned depth")
        self.assertEqual(len(tried), 4)          # without and with a scale, without and with the gripper's offset
        np.testing.assert_allclose(best.transform, self.truth, atol=1e-4)

    def test_a_transform_from_the_depth_sensors_own_picture_works_on_the_colour_cameras(self):
        depth_to_colour = np.eye(4)
        depth_to_colour[:3, 3] = (-32.0, 0.5, 1.0)        # the colour camera 32 mm beside the depth sensor
        colour_point = np.array([10.0, 20.0, 600.0, 1.0])
        depth_point = np.linalg.inv(depth_to_colour) @ colour_point
        from_depth = self.truth                             # as solved on the depth sensor's points
        np.testing.assert_allclose(to_colour_frame(from_depth, depth_to_colour) @ colour_point,
                                   from_depth @ depth_point)


class CorrectionAndStorageTests(unittest.TestCase):
    def test_the_correction_is_saved_with_the_calibration_and_applied_to_what_the_camera_finds(self):
        correction = XYCorrection(centre=(200.0, 0.0), cx=(0.5, 0, 0, 0, 0, 0), cy=(-0.2, 0, 0, 0, 0, 0))
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "calibration.json"
            save_calibration(path, np.eye(4), Intrinsics(600, 600, 320, 240, 640, 480), "cube (precise)", 0.2, 20,
                             extras={"xy_correction": correction.as_dict(), "tool_offset_mm": (0.1, 0.2)})
            loaded = load_calibration(path)
            self.assertEqual(loaded.extras["tool_offset_mm"], [0.1, 0.2])
            self.assertEqual(loaded.correction(), correction)
            # an older file, without extras, still loads
            data = json.loads(path.read_text())
            del data["extras"]
            path.write_text(json.dumps(data))
            self.assertIsNone(load_calibration(path).correction())
        builder = SceneBuilder(camera=None, detector=None, t_cam_to_robot=np.eye(4))
        builder.set_calibration(np.eye(4), correction)
        moved = builder._corrected([LocatedObject("cube", (300.0, 100.0, 20.0), 1.0)])[0]
        self.assertAlmostEqual(moved.xyz_robot[0], 300.5)
        self.assertAlmostEqual(moved.xyz_robot[1], 99.8)
        self.assertEqual(moved.xyz_robot[2], 20.0)
        bent = XYCorrection(centre=(200.0, 0.0), cx=(0, 0, 0, 1.0, 0, 0), cy=(0, 0, 0, 0, 0, 0))
        self.assertLessEqual(math.hypot(*bent.shift(5000.0, 0.0)), 3.0 + 1e-9)    # never runs away


class LensTests(unittest.TestCase):
    def test_a_bent_picture_is_straightened_back(self):
        k = Intrinsics(fx=690.0, fy=690.0, cx=640.0, cy=360.0, width=1280, height=720)
        coefficients = (0.08, -0.05, 0.001, -0.0005, 0.0)
        v, u = np.mgrid[0:720, 0:1280].astype(np.float32)
        depth = (500.0 + 0.1 * u + 0.05 * v).astype(np.float32)   # a smooth slope: easy to check pixel by pixel
        rgb = np.zeros((720, 1280, 3), np.uint8)
        _, bent = Distorter(k, coefficients).apply(rgb, depth)
        self.assertGreater(np.abs(bent - depth)[100:620, 100:1180].max(), 1.0)    # the corners moved (~20 px)
        _, straight = Undistorter(k, coefficients).apply(rgb, bent)
        inner = (slice(60, 660), slice(80, 1200))
        self.assertLess(np.median(np.abs(straight - depth)[inner]), 0.15)


# ---- in the demo ------------------------------------------------------------------------------------------------------------
class CubeCalibrationTests(unittest.TestCase):
    def check_phase1(self, bench: Bench, out, xy_mm: float) -> None:
        self.assertTrue(out.passed, out.reason)
        self.assertGreaterEqual(len(out.used), 7)
        self.assertLessEqual(out.typical_mm, cube.MODES[out.mode].pass_mm)
        old = bench.xy_errors(tilted(bench.exact, 1.5, (200 + bench.ox, 0, 170)), 20)
        self.assertGreater(float(np.median(old)), 3.0, "the calibration it starts from is 3-5 mm off")
        for z in (0, 20, 60):
            self.assertLess(float(np.median(bench.xy_errors(out.transform, z, out.correction))), xy_mm)
        for size in out.cube_mm:
            self.assertAlmostEqual(size, 20.0, delta=2.0)
        self.assertEqual(out.table_z, 0.0)
        self.assertEqual(out.table_from, "touched")
        self.assertLess(out.slip_mm, cube.SLIP_MM)
        self.assertLess(out.up_check_deg, 0.3)
        self.assertGreater(out.plane.points, 1000)
        self.assertTrue(out.before_mm and float(np.median(out.before_mm)) > 2.0)
        self.assertGreater(len({round(p.r) for p in out.used}), 2, "the wrist turned different ways")

    def test_the_dobot_from_a_tilted_calibration_then_towers_of_three(self):
        bench = Bench(self, "dobot_magician", "Realistic")
        said = []
        out = bench.phase1(on_progress=said.append)
        self.check_phase1(bench, out, 0.6)
        self.assertTrue(any("Spot 10 of 10" in s for s in said))
        # ready for what follows: still holding the cube, out of the way
        self.assertTrue(out.holding and bench.robot._held == bench.ids["red cube"])
        self.assertIsNotNone(out.background)
        # the heights: two more cubes, towers of three
        bench.place_extra(2)
        heights = run_cube_stacks(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper, extra=2,
                                  spots=3, settle_s=0.0, frames=10)
        self.assertFalse(heights.reason.startswith("the tower"), heights.reason)
        self.assertEqual(heights.tried, 3)
        self.assertGreaterEqual(len(heights.stacks), 4)
        self.assertEqual({p.level for p in heights.stacks}, {2, 3})
        self.assertLess(max(heights.stack_before_mm), 1.5, "2 and 3 cube-heights up, by the table calibration")
        for level, bias in heights.level_bias_mm.items():
            self.assertLess(abs(bias), 1.0, f"{level} high")
        # every cube left standing on the table, apart, and the gripper empty
        self.assertIsNone(bench.robot._held)
        positions = [bench.world.get_object_position_mm(bench.ids[c]) for c in bench.ids if c != "tray"]
        on_table = [p for p in positions if p[0] > -500]
        self.assertEqual(len(on_table), 3)
        for p in on_table:
            self.assertAlmostEqual(p[2], 10.0, delta=1.0)
        self.assertGreater(min(math.dist(a[:2], b[:2]) for i, a in enumerate(on_table) for b in on_table[i + 1:]),
                           25.0)

    def test_the_xarm_whose_gripper_also_measures_the_cube_then_the_pick_test(self):
        bench = Bench(self, "xarm6", "Perfect")
        gaps = iter([20.3, 19.8] + [20.0] * 40)
        with mock.patch.object(cube, "_gripper_gap", side_effect=lambda robot: next(gaps)):
            out = bench.phase1()
        self.check_phase1(bench, out, 0.9)       # (the demo camera's pixel centres put ~0.5 mm into this one)
        self.assertEqual(out.gripper_mm, (19.8, 20.3))
        test = run_pick_test(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                             settle_s=0.0, frames=3)
        self.assertEqual(test.rounds, 3, test.reason)
        self.assertEqual(test.held, 3)
        self.assertLess(max(test.placed_mm), 1.0)
        self.assertEqual(bench.robot._held, bench.ids["red cube"])
        # "Finish": the cube put back down, the gripper empty
        put_cube_down(bench.robot, out, bench.bounds, bench.reach, settle_s=0.0)
        self.assertIsNone(bench.robot._held)
        self.assertAlmostEqual(bench.world.get_object_position_mm(bench.ids["red cube"])[2], 10.0, delta=1.0)

    def test_fingers_off_the_wrists_axis_are_measured(self):
        bench = Bench(self, "xarm6", "Perfect")
        bench.robot.tool_offset_mm = (1.5, -1.0)
        out = bench.phase1()
        self.assertTrue(out.passed, out.reason)
        np.testing.assert_allclose(out.tool_offset_mm, (1.5, -1.0), atol=0.35)
        without, with_d = out.tool_offset_gain
        self.assertLess(with_d, without)

    def test_a_gripper_whose_middle_is_well_off_the_tool_point_like_the_labs(self):
        # at the lab the gripper's middle sat ~13 mm from the Dobot's tool point: with the wrist turned, spots
        # disagreed by ~3 mm and the cube "slipped" 2.7 mm. The wrist now stays in its middle and the offset is
        # measured with the calibration, then the robot moves by it.
        # (3, -2) mm here: further off, the first centring squeeze, turning round the tool point, puts a finger
        # onto the cube -- in the demo and on the real arm alike. Once measured, the robot turns round the middle.
        bench = Bench(self, "dobot_magician", "Perfect")
        bench.robot.tool_offset_mm = (3.0, -2.0)
        out = bench.phase1(mode="quick")
        self.assertTrue(out.passed, out.reason)
        self.assertTrue(out.offset_used)
        # (across the arm it is told apart from a turn of the camera only by the spots' different distances:
        # measured less closely, and what is left is taken up by the turn)
        np.testing.assert_allclose(out.tool_offset_mm, (3.0, -2.0), atol=1.0)
        self.assertLess(out.slip_mm, 1.0)
        self.assertEqual(bench.robot.tool_centre_mm, out.total_offset)
        self.assertLess(float(np.median(bench.xy_errors(out.transform, 20, out.correction))), 0.8)
        # picks go to the gripper's middle: the pick test holds the cube every time
        test = run_pick_test(bench.robot, bench.camera, out, bench.bounds, bench.reach, bench.gripper,
                             settle_s=0.0, frames=3)
        self.assertEqual(test.held, test.rounds, test.reason)
        self.assertLess(max(test.placed_mm), 1.5)
        # a second calibration, the robot already moving by it: only a small remainder is left to find
        put_cube_down(bench.robot, out, bench.bounds, bench.reach, settle_s=0.0)
        x, y, _ = bench.world.get_object_position_mm(bench.ids["red cube"])
        middle = math.degrees(math.atan2(y, x))
        bench.robot.move_to(Pose(x, y, 60, middle))
        bench.robot.move_to(Pose(x, y, bench.grip_z, middle))
        bench.robot.close_gripper()
        self.assertEqual(bench.robot._held, bench.ids["red cube"])
        again = bench.phase1(mode="fast", old_transform=out.transform)
        self.assertTrue(again.passed, again.reason)
        np.testing.assert_allclose(again.total_offset, (3.0, -2.0), atol=1.0)

    def test_the_wrist_stays_in_its_middle_at_every_spot(self):
        bench = Bench(self)
        turns = []
        real = bench.robot._move_to_raw

        def watch(pose, speed=None):
            turns.append((pose.x, pose.y, pose.z, pose.r))
            return real(pose, speed)
        bench.robot._move_to_raw = watch
        out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        for x, y, z, r in turns[2:]:  # J4 = r - J1: 0 once the wrist is put in its middle (the first moves)
            self.assertLessEqual(abs((r - math.degrees(math.atan2(y, x)) + 180) % 360 - 180), 1.0, (x, y, z, r))

    def test_a_bent_lens_and_long_distances_are_allowed_for(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        bench.camera.set_lens(distortion=(0.12, -0.1, 0.0, 0.0, 0.0), depth_scale=1.01)
        bench.exact = bench.exact @ np.diag([1 / 1.01, 1 / 1.01, 1 / 1.01, 1.0])   # its points come 1% too far
        out = bench.phase1(spots=12)
        self.assertTrue(out.passed, out.reason)
        self.assertIn("scale", out.fit.name)
        self.assertLess(float(np.median(bench.xy_errors(out.transform, 20))), 0.6)

    @contextmanager
    def slipping(self, mm: float, at: int = 2):
        """The cube seen `mm` from where it was the first time at the look back at the end (8 spots: the second look
        back, after the one after spot 5; `at` 1: that one). (Its place in the fingers not tracked: the tracking
        would see it landed where it should have.)"""
        real, calls = cube._moved_on_table, []

        def moved(a, b, sightings):
            calls.append(1)
            return mm if len(calls) == at else real(a, b, sightings)
        with mock.patch.object(cube, "_moved_on_table", side_effect=moved), \
                mock.patch.object(cube, "_off_landing", return_value=None):
            yield

    def test_a_cube_far_from_where_it_was_at_the_end_pauses_and_the_spots_since_are_done_again(self):
        bench = Bench(self)
        saved = []
        with self.slipping(5.0):
            out = bench.phase1(spots=8, on_save=saved.append)
        self.assertFalse(out.passed)
        self.assertTrue(out.paused and out.keep_progress)
        self.assertIn("from where it was the first time", out.reason)
        self.assertIn("Home", out.reason)
        self.assertIsNotNone(bench.robot._held, "taken back: still in the gripper")
        self.assertEqual(out.spot_log[-1]["spot"], "first again")      # kept in the run's record, with its picture
        self.assertEqual(len(out.pictures), 4)
        progress = saved[-1]
        self.assertEqual(progress.next_index, 5, "spots 6-8, after the last good check, are done again")
        self.assertEqual(len([p for p in out.pairs if not p.check]), 5)
        bench.take_over()
        out = bench.resume(progress)
        self.assertTrue(out.passed, out.reason)
        self.assertEqual(len([p for p in out.pairs if not p.check]), 8)

    def test_a_cube_that_moved_a_little_is_said_and_that_look_isnt_a_spot(self):
        # (reviewer 2, 2026-10-27: a look 1.5-3 mm off was added to the fit as one that "has to agree with the first")
        bench = Bench(self)
        with self.slipping(2.0):
            out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertIn("2.0 mm", " ".join(out.notes))
        self.assertEqual(len([p for p in out.pairs if p.check]), 1, "the look back after spot 5 only")
        self.assertEqual(len([p for p in out.pairs if not p.check]), 8)
        self.assertAlmostEqual(out.slip_worst_mm, 2.0)

    def test_the_worst_look_back_is_reported_not_only_the_last(self):
        bench = Bench(self)
        with self.slipping(2.0, at=1):                       # the look back after spot 5; the one at the end fine
            out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertLess(out.slip_mm, cube.SLIP_MM)
        self.assertAlmostEqual(out.slip_worst_mm, 2.0)

    def test_paused_while_taking_the_cube_back_and_carried_on_by_hand(self):
        bench = Bench(self)
        path = Path(tempfile.mkdtemp()) / "calibration_cube_progress.pkl"
        flag = {"pause": False}

        def on_save(progress):
            cube.save_progress(path, progress)
            pending = progress.pending or {}
            if pending.get("measured") and pending.get("index") == 2:
                flag["pause"] = True               # pressed as it went back for the cube at spot 3
        out = bench.phase1(spots=8, on_save=on_save, pause=lambda: flag["pause"])
        self.assertTrue(out.paused, out.reason)
        self.assertIn("Pause", out.reason)
        self.assertIsNone(bench.robot._held, "stopped before taking it back")
        progress = cube.load_progress(path)                  # (as after the app was closed and opened again)
        self.assertEqual(progress.pending, {"index": 2, "measured": True, "pair": True})
        self.assertIn("2 of 8", progress.describe())
        bench.take_over()
        out = bench.resume(progress, on_save=on_save, use_last=False)
        self.assertTrue(out.passed, out.reason)
        self.assertIn("spot 3: not used", " ".join(out.skipped))
        self.assertEqual(out.spots_tried, 8)
        self.assertEqual(len([p for p in out.pairs if not p.check]), 7)
        checks = [entry["why"] for entry in out.spot_log if entry["spot"] == "first again"]
        self.assertEqual(checks[0], "after taking over", "carrying on starts with a look back at the first spot")

    def test_the_gripper_offset_is_found_afresh_not_built_on_an_old_one(self):
        # (the lab: a shaky run's -8.8 mm was carried into every calibration after it)
        bench = Bench(self, "dobot_magician", "Perfect")
        bench.robot.tool_offset_mm = (3.0, -2.0)
        bench.robot.tool_centre_mm = (-8.8, 3.7)                 # what an earlier, poor calibration left
        out = bench.phase1(mode="quick")
        self.assertTrue(out.passed, out.reason)
        self.assertEqual(out.base_offset, (0.0, 0.0))
        np.testing.assert_allclose(out.total_offset, (3.0, -2.0), atol=1.0)
        self.assertEqual(bench.robot.tool_centre_mm, out.total_offset)

    def test_paused_as_it_finished_solving_the_robot_keeps_the_offset_it_had(self):
        # (a review found: Pause pressed during "Solving..." left the run passed, and the robot moving by the new
        # gripper offset -- though nothing was saved and the app said "Nothing was changed")
        bench = Bench(self, "dobot_magician", "Perfect")
        bench.robot.tool_offset_mm = (3.0, -2.0)
        before = tuple(bench.robot.tool_centre_mm)
        said, saved = [], []
        out = bench.phase1(on_progress=said.append, on_save=saved.append, pause=lambda: "Solving..." in said)
        self.assertTrue(out.paused and out.keep_progress, out.reason)
        self.assertFalse(out.passed)
        self.assertIsNone(out.transform)
        self.assertEqual(tuple(bench.robot.tool_centre_mm), before)
        # carried on: solved again, and only now the robot moves by the offset found
        bench.take_over()
        out = bench.resume(saved[-1], on_save=saved.append)
        self.assertTrue(out.passed, out.reason)
        self.assertTrue(out.offset_used)
        self.assertEqual(bench.robot.tool_centre_mm, out.total_offset)

    def test_too_few_spots_left_once_the_odd_ones_are_left_out_is_no_calibration(self):
        # (a review found: the spots were counted before the odd ones -- partly hidden, odd height, gripped
        # off-centre -- were left out, so a fit could be made from fewer than the minimum)
        bench = Bench(self, "xarm6", "Perfect")
        calls = []

        def gap(robot):         # the two centring squeezes, then spots 1, 3 and 5 gripped 4 mm wider than the rest
            calls.append(1)
            return 24.0 if len(calls) in (3, 5, 7) else 20.0
        with mock.patch.object(cube, "_gripper_gap", side_effect=gap):
            out = bench.phase1(spots=8)
        self.assertEqual(len([e for e in out.spot_log if e.get("found") and e["spot"] != "first again"]), 8,
                         "all found by the camera")
        self.assertFalse(out.passed)
        self.assertIsNone(out.transform)
        self.assertEqual(sum("gripped off-centre" in why for why in out.skipped), 3)
        left = 8 - sum(why.startswith("(") for why in out.skipped)          # (and any the camera saw only partly)
        self.assertIn(f"only {left} of the 8 spots the camera found can be used", out.reason)
        self.assertIn("at least 6 are needed", out.reason)
        self.assertIsNone(bench.robot._held, "the cube left down")

    def test_the_fingers_real_angle_is_measured_from_the_spots(self):
        # the demo's fingers close along jaw_axis_deg (90); the app is told 90, or (a gripper turned 4 degrees on the
        # wrist, as the app sees it) 86: the calibration has to find the difference, and the angle to use
        for told in (90.0, 86.0):
            with self.subTest(app_thinks=told):
                bench = Bench(self, "dobot_magician", "Perfect")
                bench.gripper = dataclasses.replace(bench.gripper, jaw_axis_deg=told)
                out = bench.phase1(spots=10)
                self.assertTrue(out.passed, out.reason)
                offset, scatter, n = out.fingers
                self.assertGreaterEqual(n, 6)
                self.assertAlmostEqual(offset, 90.0 - told, delta=1.0)
                self.assertLess(scatter, 1.5)
                self.assertAlmostEqual(out.jaw_axis_deg, 90.0, delta=1.0)

    def test_with_no_calibration_in_use_the_spots_are_near_the_cube(self):
        # the lab: the calibration was cleared, the app's stand-in (the identity) was taken as one, and no spot was
        # in its "view": 0 of 0 spots
        for old in (np.eye(4), None):
            with self.subTest(old_transform="identity" if old is not None else None):
                bench = Bench(self)
                out = bench.phase1(spots=8, old_transform=old)
                self.assertEqual(out.spots_tried, 8, out.reason)
                self.assertTrue(out.passed, out.reason)

    def test_a_first_spot_seen_only_partly_is_not_what_the_checks_go_by(self):
        # the lab: the first spot's top read 15.5 x 30.1 mm (a 25 mm cube), and the look back at it 17.7 x 24.8: a
        # "slip" of 4.3 mm that was the camera's, not the arm's
        bench = Bench(self)
        real, calls = cube.find_new_object, []

        def first_seen_partly(after, before, k, table=None, **hints):
            seen = real(after, before, k, table, **hints)
            calls.append(1)
            if seen is not None and len(calls) == 1:
                seen.footprint_mm = (14.0, 26.0)
                seen.cam_xyz = seen.cam_xyz + np.array([4.0, 0.0, 0.0])
            return seen
        with mock.patch.object(cube, "find_new_object", side_effect=first_seen_partly):
            out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        checks = [entry for entry in out.spot_log if entry["spot"] == "first again"]
        self.assertEqual(len(checks), 2)
        self.assertNotEqual(checks[0]["xy"], out.spot_log[0]["xy"], "back to the second spot, the first seen whole")
        self.assertLess(out.slip_mm, cube.SLIP_MM)

    def test_the_arm_losing_its_place_is_found_at_the_next_check_and_those_spots_done_again(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        saved = []

        def said(message):
            if "Spot 3 of" in message:
                bench.robot.tool_offset_mm = (4.0, 0.0)         # from spot 3 on, everything lands 4 mm along
        out = bench.phase1(spots=8, on_progress=said, on_save=saved.append)
        self.assertTrue(out.paused, out.reason)
        self.assertIn("from where it was the first time", out.reason)
        self.assertEqual(out.spot_log[-1]["why"], "a check after spot 5")
        self.assertEqual(saved[-1].next_index, 0, "no check had passed yet: every spot is done again")
        self.assertIn("done again", " ".join(out.skipped))
        bench.robot.tool_offset_mm = (0.0, 0.0)                 # Home: the arm knows where it is again
        bench.take_over()
        out = bench.resume(saved[-1])
        self.assertTrue(out.passed, out.reason)

    def test_a_smaller_shift_after_taking_over_stops_the_run_for_home(self):
        # the lab, 2026-10-12: the arm stopped answering at a spot, the user took over, and the cube put back at the
        # first spot was 2.7 mm off -- under the 3 mm that stops a run, so it carried on mixing spots from before and
        # after the shift and failed at 2.5 mm (and "Save it anyway" offered to keep it)
        bench = Bench(self, "dobot_magician", "Perfect")
        path = Path(tempfile.mkdtemp()) / "calibration_cube_progress.pkl"
        flag = {"pause": False}

        def on_save(progress):
            cube.save_progress(path, progress)
            pending = progress.pending or {}
            if pending.get("measured") and pending.get("index") == 2:
                flag["pause"] = True
        out = bench.phase1(spots=8, on_save=on_save, pause=lambda: flag["pause"])
        self.assertTrue(out.paused, out.reason)
        bench.robot.tool_offset_mm = (2.5, 0.0)          # it lost its place as it stopped: everything 2.5 mm along
        bench.take_over()
        saved = []
        out = bench.resume(cube.load_progress(path), on_save=saved.append, use_last=False)
        self.assertTrue(out.paused, out.reason)
        self.assertIn("from where it was the first time", out.reason)
        self.assertIn("Home", out.reason)
        self.assertEqual(out.spot_log[-1]["why"], "after taking over")
        bench.robot.tool_offset_mm = (0.0, 0.0)          # Home: the arm knows where it is again
        bench.take_over()
        out = bench.resume(saved[-1])
        self.assertTrue(out.passed, out.reason)

    def test_a_run_whose_cube_shifted_isnt_offered_to_save_anyway(self):
        out = cube.CubeOutcome()
        out.slipped = True
        self.assertFalse(out.over_limit)
        from app.ui.calibration_panel import CalibrationPanel
        out.over_limit, out.transform, out.errors_mm = False, np.eye(4), [2.4, 2.5, 2.6]
        self.assertFalse(CalibrationPanel._may_save_anyway(out))

    def test_the_gripper_coming_up_without_the_cube_looks_again_and_takes_it_once_more(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        real, calls = bench.robot.close_gripper, []

        def close():
            calls.append(1)
            if len(calls) == 4:                     # (the regrip and the centring squeeze; then spots 1 and 2)
                bench.robot._gripper_closed = True  # closed on nothing: the cube stays on the table
                return
            real()
        bench.robot.close_gripper = close
        with self.assertLogs("app.calibration.cube", "INFO") as logs:
            out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertIn("it is taken again there", " | ".join(logs.output))

    def test_the_gripper_coming_up_without_the_cube_twice_pauses_for_the_user(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        real, calls = bench.robot.close_gripper, []

        def close():
            calls.append(1)
            if len(calls) in (4, 5):                # (spot 2's take-back, and the one more try)
                bench.robot._gripper_closed = True  # closed on nothing: the cube stays on the table
                return
            real()
        bench.robot.close_gripper = close
        saved = []
        out = bench.phase1(spots=8, on_save=saved.append)
        self.assertTrue(out.paused, out.reason)
        self.assertIn("without the cube", out.reason)
        self.assertIn("tried once more", out.reason)
        bench.robot.close_gripper = real
        bench.take_over()
        out = bench.resume(saved[-1])
        self.assertTrue(out.passed, out.reason)
        self.assertEqual(len([p for p in out.pairs if not p.check]), 8, "spot 2 was measured before; it counts")

    def test_no_room_for_the_fingers_the_arm_waits_above_the_cube(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        bench.gripper = dataclasses.replace(bench.gripper, opening_mm=21.5)    # as tight as a 25 mm cube's
        real, opened = bench.robot.open_gripper, []

        def open_and_turn():
            held = bench.robot._held
            real()
            if held is not None:
                opened.append(1)
                if len(opened) == 6:                # spot 4: it turns 22 degrees, more than the wrist matches
                    x, y, z = bench.world.get_object_position_mm(bench.ids["red cube"])
                    yaw = bench.world.get_object_yaw_deg(bench.ids["red cube"])
                    bench.robot._place_object(bench.ids["red cube"], x, y, z, yaw + 22.0)
        bench.robot.open_gripper = open_and_turn
        saved = []
        out = bench.phase1(spots=8, on_save=saved.append)
        self.assertTrue(out.paused, out.reason)
        self.assertIn("isn't room", out.reason)
        here = bench.robot.get_pose()
        x, y, _ = bench.world.get_object_position_mm(bench.ids["red cube"])
        self.assertLess(math.dist((here.x, here.y), (x, y)), 2.0, "waiting over the cube")
        self.assertGreater(here.z, 30.0)
        bench.robot.open_gripper = real
        bench.take_over()
        out = bench.resume(saved[-1])
        self.assertTrue(out.passed, out.reason)

    def test_carrying_on_after_the_camera_moved_is_refused(self):
        bench = Bench(self)
        saved = []
        out = bench.phase1(spots=8, on_save=saved.append, pause=lambda: saved[-1].next_index >= 3 if saved else False)
        self.assertTrue(out.paused)
        bench.camera.bump()
        bench.take_over()
        out = bench.resume(saved[-1])
        self.assertFalse(out.passed)
        self.assertFalse(out.keep_progress)
        self.assertIn("start afresh", out.reason)       # (no progress kept: no Start over)
        self.assertIsNone(bench.robot._held, "the cube put down")

    def test_touched_far_out_too_the_cube_is_let_go_by_the_table_there(self):
        # the lab's Dobot let the cube go 2-3 mm high stretched out: touched there as well, every move near the
        # table follows the height the touches give
        bench = Bench(self, "dobot_magician", "Perfect")
        moves = []
        real = bench.robot.move_to

        def recorded(pose, *args, **kwargs):
            moves.append(pose)
            return real(pose, *args, **kwargs)
        bench.robot.move_to = recorded
        touches = [(150.0, 0.0, 0.0), (280.0, 0.0, 1.2)]
        out = bench.phase1(table_touches=touches, table_z=None, mode="fast")
        self.assertTrue(out.passed, out.reason)
        self.assertIn("2 places", out.table_from)
        heights = cube.TableHeights(touches)
        self.assertAlmostEqual(out.table_z, heights.at(200 + bench.ox, 30.0), places=3)
        lowest = {}
        for pose in moves:
            key = (round(pose.x), round(pose.y))
            lowest[key] = min(lowest.get(key, pose.z), pose.z)
        spots = [(round(p.xy[0]), round(p.xy[1])) for p in out.pairs]
        far, near = max(spots, key=lambda q: math.hypot(*q)), min(spots, key=lambda q: math.hypot(*q))
        self.assertAlmostEqual(lowest[far] - lowest[near], heights.at(*far) - heights.at(*near), delta=0.05)
        self.assertGreater(heights.at(*far) - heights.at(*near), 0.5)

    def test_a_cube_that_turned_as_it_was_let_go_is_taken_back_turned_to_match(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        real, opened = bench.robot.open_gripper, []
        label = "red cube"

        def open_and_turn():
            held = bench.robot._held
            real()
            if held is not None:
                opened.append(1)
                if len(opened) == 6:    # (first the regrip with the wrist in its middle, the centring squeeze); spot 4
                    x, y, z = bench.world.get_object_position_mm(bench.ids[label])
                    yaw = bench.world.get_object_yaw_deg(bench.ids[label])
                    bench.robot._place_object(bench.ids[label], x, y, z, yaw + 8.0)
        bench.robot.open_gripper = open_and_turn
        out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertEqual([spot for spot, _ in out.turn_fixes], [4])
        self.assertAlmostEqual(out.turn_fixes[0][1], 8.0, delta=1.5)
        self.assertIn("turned", " ".join(out.notes))

    def test_a_cube_nudged_as_it_was_let_go_early_on_is_taken_back_where_it_is_and_slowly(self):
        bench = Bench(self, "dobot_magician", "Perfect")
        real, opened, let_go = bench.robot.open_gripper, [], []
        label = "red cube"

        def open_and_nudge():
            held = bench.robot._held
            real()
            if held is not None:
                opened.append(1)
                if len(opened) == 9:    # spot 6 (after the look back after spot 5): 6 spots before it, enough for
                    #                         the camera's fit to aim the fingers (MIN_FIT_SPOTS)
                    here = bench.robot.get_pose()
                    let_go.append((here.x, here.y, here.r))
                    x, y, z = bench.world.get_object_position_mm(bench.ids[label])
                    yaw = bench.world.get_object_yaw_deg(bench.ids[label])
                    across = math.radians(bench.gripper.closing_direction(here.r))   # (1.5 mm across the fingers)
                    bench.robot._place_object(bench.ids[label], x + 1.5 * math.cos(across),
                                              y + 1.5 * math.sin(across), z, yaw)
        bench.robot.open_gripper = open_and_nudge
        real_back, backs = cube._take_back, []

        def take_back(arm, robot, x, y, *more):
            if let_go and len(backs) == 0:
                backs.append((x, y))
            return real_back(arm, robot, x, y, *more)
        real_slow, slow = cube._Arm.move_slow, []

        def move_slow(arm, *args):
            slow.append(args[-1])
            return real_slow(arm, *args)
        with mock.patch.object(cube, "_take_back", take_back), \
                mock.patch.object(cube._Arm, "move_slow", move_slow), \
                self.assertLogs("app.calibration.cube", "INFO") as logs:
            out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertIn("across the fingers from where it was let go", "\n".join(logs.output))
        (bx, by), (lx, ly, lr) = backs[0], let_go[0]
        across = math.radians(bench.gripper.closing_direction(lr))
        moved_across = (bx - lx) * math.cos(across) + (by - ly) * math.sin(across)
        moved_along = -(bx - lx) * math.sin(across) + (by - ly) * math.cos(across)
        self.assertAlmostEqual(moved_across, 1.5, delta=0.6, msg="the fingers came down across them where the cube "
                               "was, not where it was let go")
        self.assertAlmostEqual(moved_along, 0.0, places=6, msg="along them: where it was let go (see _room)")
        backs_slow = [speed for speed in slow if speed == cube.TAKE_BACK_SPEED_MM_S]
        self.assertGreaterEqual(len(backs_slow), 8, "every take-back's last mm slowly")
        self.assertTrue(all(speed in (cube.TAKE_BACK_SPEED_MM_S, cube.RELEASE_SPEED_MM_S) for speed in slow),
                        "and every let-go's first mm up (the gentle release)")

    def test_a_spot_where_the_camera_misses_the_cube_is_skipped(self):
        bench = Bench(self)
        real, calls = cube.find_new_object, []

        def blind_once(after, before, k, table=None, **hints):
            calls.append(1)
            return None if len(calls) == 3 else real(after, before, k, table, **hints)
        with mock.patch.object(cube, "find_new_object", side_effect=blind_once):
            out = bench.phase1(spots=8)
        self.assertEqual(out.spots_tried, 8)
        self.assertEqual(len([p for p in out.pairs if not p.check]), 7)
        self.assertIn("not found", " ".join(out.skipped))
        self.assertTrue(out.passed, out.reason)

    def refusing_take_backs(self, bench, refuse: set):
        """The robot refuses (no answer) the take-backs numbered in `refuse` (1 = the first, counting retries)."""
        real, count = cube._take_back, {"n": 0}

        def take_back(arm, robot, x, y, z, middle, *more):
            count["n"] += 1
            if count["n"] in refuse:
                arm.acted = False
                raise RuntimeError("The robot did not acknowledge the move command.")
            return real(arm, robot, x, y, z, middle, *more)
        return mock.patch.object(cube, "_take_back", take_back)

    def test_a_take_back_the_robot_refuses_once_is_tried_again(self):
        bench = Bench(self)
        with self.refusing_take_backs(bench, {2}):
            out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertEqual(len([p for p in out.pairs if not p.check]), 8)

    def test_a_take_back_refused_twice_pauses_it_and_says_where_the_cube_is(self):
        bench = Bench(self)
        with self.refusing_take_backs(bench, {3, 4}):
            out = bench.phase1(spots=8)
        self.assertFalse(out.passed)
        self.assertTrue(out.paused and out.keep_progress)
        self.assertIsNone(out.transform)
        self.assertIn("refused a move while taking the cube back", out.reason)
        self.assertIsNone(bench.robot._held)
        x, y = (float(v) for v in out.reason.split("back at (")[1].split(")")[0].split(", "))
        cube_xy = bench.world.get_object_position_mm(bench.ids["red cube"])[:2]
        self.assertLess(math.dist((x, y), cube_xy), 2.0)

    def test_fast_mode_six_spots_and_one_may_be_missed(self):
        bench = Bench(self)
        real, calls = cube.find_new_object, []

        def blind_once(after, before, k, table=None, **hints):
            calls.append(1)                  # (1: spot 1; 2: spot 1 again, the camera's steadiness; 3: spot 2)
            return None if len(calls) == 3 else real(after, before, k, table, **hints)
        with mock.patch.object(cube, "find_new_object", side_effect=blind_once):
            out = bench.phase1(mode="fast")
        self.assertEqual(out.spots_tried, 6)
        self.assertEqual(len([p for p in out.pairs if not p.check]), 5)
        self.assertTrue(out.passed, out.reason)
        self.assertLess(float(np.median(bench.xy_errors(out.transform, 20))), 0.8)
        self.assertGreater(len({round(p.r) for p in out.used}), 2, "each of the three turns used")

    def test_too_few_spots_is_no_calibration_and_the_cube_left_down(self):
        bench = Bench(self)
        out = bench.phase1(spots=cube.FEWEST_SPOTS - 1)
        self.assertFalse(out.passed)
        self.assertIsNone(out.transform)
        self.assertIn("at least", out.reason)
        self.assertIsNone(bench.robot._held)
        self.assertAlmostEqual(bench.world.get_object_position_mm(bench.ids["red cube"])[2], 10.0, delta=1.0)

    def test_stop_part_way_leaves_the_cube_on_the_table_and_nothing_calibrated(self):
        bench = Bench(self)
        said = []
        out = bench.phase1(on_progress=said.append, cancel=lambda: any("Spot 3" in s for s in said))
        self.assertTrue(out.cancelled)
        self.assertFalse(out.passed)
        self.assertIsNone(out.transform)
        self.assertIsNone(bench.robot._held)
        self.assertAlmostEqual(bench.world.get_object_position_mm(bench.ids["red cube"])[2], 10.0, delta=1.0)
        self.assertFalse(bench.robot._gripper_closed)

    def test_stop_just_after_taking_the_cube_back_still_puts_it_down(self):
        # (a review found: stopped as the arm lifted the cube it had just closed on, the run thought it held
        # nothing, left the gripper shut on the cube, and said "the cube was put down")
        bench = Bench(self)
        said, closes = [], []
        real_close = bench.robot.close_gripper

        def close():
            real_close()
            if any("Spot 1" in s for s in said):
                closes.append(1)
        bench.robot.close_gripper = close
        out = bench.phase1(on_progress=said.append, cancel=lambda: bool(closes))
        self.assertTrue(out.cancelled)
        self.assertFalse(out.holding)
        self.assertIsNone(bench.robot._held)
        self.assertFalse(bench.robot._gripper_closed)
        self.assertAlmostEqual(bench.world.get_object_position_mm(bench.ids["red cube"])[2], 10.0, delta=1.0)

    def test_fingertips_below_the_table_height_given_is_refused_before_moving(self):
        bench = Bench(self)
        before = bench.robot.get_pose()
        out = bench.phase1(table_z=bench.grip_z + 5.0)
        self.assertFalse(out.passed)
        self.assertIn("below the table", out.reason)
        self.assertEqual(bench.robot.get_pose(), before)


class TrackingTheCubeInTheFingersTests(unittest.TestCase):
    """The fit that follows where the cube sits along the fingers, grip by grip (solve_chain), and the runs that need
    it: the Dobot's fingers centre a cube across them only, so once knocked it is held further along from then on."""
    JAW = 90.0
    PLANE = TablePlane(normal=np.array([0.0, 0.0, 1.0]), offset=500.0, rms_mm=0.1, points=1000)

    def spots(self, n=10, noise=0.2, pushed_at=(), across=1.2):
        """n spots taken back blind where they were let go (the grip along the fingers stays as it was), the camera
        straight above, turned 25 degrees. `pushed_at`: at those spots a finger pushes the cube 2.5 mm along as it
        comes down to take it back (not seen): it is held so from then on."""
        rng = np.random.default_rng(3)
        theta, shift = math.radians(25.0), np.array([180.0, -40.0])
        turn = np.array([[math.cos(theta), -math.sin(theta)], [math.sin(theta), math.cos(theta)]])
        e_c, e_a = cube._unit(self.JAW), cube._unit(self.JAW + 90.0)
        puts = np.array([(200 + 60 * math.cos(k), 80 * math.sin(1.7 * k)) for k in range(n)])
        rs = np.degrees(np.arctan2(puts[:, 1], puts[:, 0]))
        u, cam, truth = 0.7, [], []
        for j in range(n):
            wrist = cube._rot(np.array([rs[j]]))[0]
            landed = puts[j] + wrist @ (across * e_c + u * e_a)
            truth.append(landed)
            cam.append(np.append(turn.T @ (landed + rng.normal(0, noise, 2) - shift), 500.0))
            u = float((wrist @ e_a) @ (landed - puts[j])) + (2.5 if j in pushed_at else 0.0)
        return np.array(cam), puts, rs, puts.copy(), rs.copy(), [None] + list(range(n - 1)), np.array(truth)

    def errors(self, fit, cam, truth):
        return [float(np.linalg.norm(fit.seen(c) - t)) for c, t in zip(cam, truth)]

    def test_a_changed_place_in_the_fingers_is_followed(self):
        cam, puts, rs, taken_xy, taken_r, prev, truth = self.spots(pushed_at=(3,))
        fit = cube.solve_chain(cam, puts, rs, taken_xy, taken_r, prev, self.PLANE, 0.0, self.JAW, with_offset=True)
        self.assertIsNotNone(fit)
        self.assertEqual(fit.broken, [4], "spot 5's grip, pushed unseen, is taken as unknown")
        self.assertLess(float(np.median(self.errors(fit, cam, truth))), 0.6)
        self.assertLess(max(self.errors(fit, cam, truth)), 1.2)
        self.assertLess(fit.typical_mm, 0.5)
        self.assertAlmostEqual(float(np.ptp(fit.along[5:])), 0.0, delta=0.5, msg="held the same from spot 6 on")
        self.assertAlmostEqual(float(np.median(fit.along[5:]) - np.median(fit.along[:5])), 2.5, delta=0.5)
        self.assertAlmostEqual(abs(fit.across_mm), 1.2, delta=0.5, msg="the fingers' middle, across")
        e_c, e_a = cube._unit(self.JAW), cube._unit(self.JAW + 90.0)
        self.assertAlmostEqual(float(fit.offset @ e_c), fit.across_mm, places=6)
        self.assertAlmostEqual(float(fit.offset @ e_a), float(np.median(fit.along[:4])), delta=0.3,
                               msg="along the fingers: where the hand gripped it, the grips before the push")
        _, loo, _ = cube.solve_on_plane_offset(cam, puts, self.PLANE, 0.0, False, rs)
        self.assertGreater(float(np.median(np.hypot(loo[:, 0], loo[:, 1]))), 1.0, "one place all along: off")

    def test_two_pushes_the_camera_didnt_see_break_only_those_grips(self):
        cam, puts, rs, taken_xy, taken_r, prev, truth = self.spots(pushed_at=(2, 6))
        fit = cube.solve_chain(cam, puts, rs, taken_xy, taken_r, prev, self.PLANE, 0.0, self.JAW, with_offset=True)
        self.assertEqual(sorted(fit.broken), [3, 7])
        self.assertLess(float(np.median(self.errors(fit, cam, truth))), 0.6)

    def test_too_few_spots_or_no_grips_known_isnt_tracked(self):
        cam, puts, rs, taken_xy, taken_r, prev, _ = self.spots(n=3)
        self.assertIsNone(cube.solve_chain(cam, puts, rs, taken_xy, taken_r, prev, self.PLANE, 0.0, self.JAW))
        cam, puts, rs, taken_xy, taken_r, prev, _ = self.spots()
        self.assertIsNone(cube.solve_chain(cam, puts, rs, taken_xy, taken_r, [None] * len(cam), self.PLANE, 0.0,
                                           self.JAW))

    def nudging(self, bench, at_open: int, mm: float):
        """As the gripper lets go for the `at_open`-th time with the cube (5: spot 3, after the centring at the
        start), the cube lands `mm` further along the fingers, as the camera then sees it."""
        real, opened, label = bench.robot.open_gripper, [], "red cube"

        def open_and_nudge():
            held, r = bench.robot._held, bench.robot.real_r()
            real()
            if held is not None:
                opened.append(1)
                if len(opened) == at_open:
                    x, y, z = bench.world.get_object_position_mm(bench.ids[label])
                    along = math.radians(bench.gripper.closing_direction(r) + 90.0)
                    bench.robot._place_object(bench.ids[label], x + mm * math.cos(along), y + mm * math.sin(along),
                                              z, bench.world.get_object_yaw_deg(bench.ids[label]))
        bench.robot.open_gripper = open_and_nudge

    def test_a_cube_held_further_along_after_spot_3_is_tracked_and_the_run_passes(self):
        bench = Bench(self)
        bench.robot.keeps_place_along_fingers = True
        self.nudging(bench, 5, 2.0)
        self.nudging(bench, 9, -2.0)               # (and back the other way after the look back at spot 1)
        out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertTrue(out.fit.tracked, out.fit.name)
        self.assertIn("tracked in the fingers", out.fit.name)
        self.assertLess(float(np.median(bench.xy_errors(out.transform, 20.0, out.correction))), 0.5)
        self.assertIn("the camera tracked it", " ".join(out.notes))
        self.assertEqual(len(out.grip_along_mm), len(out.pairs))
        self.assertTrue(all(p.held_at is not None for p in out.pairs), "what follows goes where each cube was")

    def test_without_the_tracking_the_same_run_is_well_off(self):
        bench = Bench(self)
        bench.robot.keeps_place_along_fingers = True
        self.nudging(bench, 5, 2.0)
        self.nudging(bench, 9, -2.0)
        with mock.patch.object(cube, "solve_chain", return_value=None):
            out = bench.phase1(spots=8)
        if out.passed:
            self.assertGreater(float(np.median(bench.xy_errors(out.transform, 20, out.correction))), 0.6)

    def test_knocked_further_than_the_look_back_allows_it_pauses(self):
        # (3.5 mm along the fingers can't be told from an arm 3.5 mm short of its reach: it pauses, saying which is
        # likelier)
        bench = Bench(self)
        bench.robot.keeps_place_along_fingers = True
        self.nudging(bench, 5, 3.5)
        out = bench.phase1(spots=8)
        self.assertTrue(out.paused, out.reason)
        self.assertIn("from where it was the first time", out.reason)

    def test_a_clean_run_keeps_the_plain_fit(self):
        bench = Bench(self)
        bench.robot.keeps_place_along_fingers = True
        out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertFalse(out.fit.tracked, out.fit.name)
        self.assertEqual(out.grip_along_mm, [])
        self.assertTrue(all(p.held_at is None for p in out.pairs))
        self.assertTrue(all(p.taken_xy is not None for p in out.pairs), "every take-back's place is kept")
        self.assertIsNone(out.pairs[0].prev, "gripped by hand: not carried from a spot")
        self.assertIs(out.pairs[1].prev, out.pairs[0])


    def test_a_tracked_calibration_keeps_the_whole_offset_of_the_fingers_middle(self):
        # (the fingers' middle off the tool point both ways: across them it is fitted, along them it is where the
        # hand gripped the cube -- dropped, every pick after would have held things that much off along them. The
        # bench's grip is made before the twin keeps places along the fingers: the cube starts in their middle)
        bench = Bench(self)
        bench.robot.tool_offset_mm = (3.0, -2.0)
        bench.robot.keeps_place_along_fingers = True
        self.nudging(bench, 5, 2.0)
        self.nudging(bench, 9, -2.0)
        out = bench.phase1(spots=8)
        self.assertTrue(out.passed, out.reason)
        self.assertTrue(out.fit.tracked, out.fit.name)
        self.assertTrue(out.offset_used)
        np.testing.assert_allclose(out.total_offset, (3.0, -2.0), atol=0.7)
        self.assertEqual(bench.robot.tool_centre_mm, out.total_offset)
        self.assertLess(float(np.median(bench.xy_errors(out.transform, 20, out.correction))), 0.8)

    def paused_at_spot_5_and_taken_over_off_centre(self, bench, along_mm: float):
        """A run paused as it went back for the cube at spot 5; the user grips it again by hand, `along_mm` off its
        middle along the fingers (the hand can't tell), and carries on."""
        path = Path(tempfile.mkdtemp()) / "calibration_cube_progress.pkl"
        flag = {"pause": False}

        def on_save(progress):
            cube.save_progress(path, progress)
            pending = progress.pending or {}
            if pending.get("measured") and pending.get("index") == 4:
                flag["pause"] = True
        out = bench.phase1(spots=8, on_save=on_save, pause=lambda: flag["pause"])
        self.assertTrue(out.paused, out.reason)
        robot, label = bench.robot, "red cube"
        here = robot.get_pose()
        x, y, _ = bench.world.get_object_position_mm(bench.ids[label])
        r = cube.middle_turn(x, y)
        along = math.radians(bench.gripper.closing_direction(r) + 90.0)
        gx, gy = x + along_mm * math.cos(along), y + along_mm * math.sin(along)
        robot.open_gripper()
        robot.move_to(Pose(here.x, here.y, max(here.z, 60.0), here.r))
        robot.move_to(Pose(gx, gy, 60.0, r))
        robot.move_to(Pose(gx, gy, bench.grip_z, r))
        robot.close_gripper()
        self.assertEqual(robot._held, bench.ids[label])
        return bench.resume(cube.load_progress(path), on_save=on_save, use_last=False)

    def test_taken_over_with_the_cube_held_elsewhere_along_the_fingers_it_carries_on(self):
        bench = Bench(self)
        bench.robot.keeps_place_along_fingers = True
        out = self.paused_at_spot_5_and_taken_over_off_centre(bench, 2.5)
        self.assertTrue(out.passed, out.reason)
        self.assertIn("after you took over", " ".join(out.notes))
        self.assertLess(float(np.median(bench.xy_errors(out.transform, 20, out.correction))), 0.8)

    def test_taken_over_off_centre_judged_the_old_way_it_paused_again(self):
        bench = Bench(self)
        bench.robot.keeps_place_along_fingers = True
        with mock.patch.object(cube, "_across_moved", return_value=None):
            out = self.paused_at_spot_5_and_taken_over_off_centre(bench, 2.5)
        self.assertTrue(out.paused, out.reason)
        self.assertIn("from where it was the first time", out.reason)

    def test_precise_with_two_knocks_is_tracked(self):
        bench = Bench(self)
        bench.robot.keeps_place_along_fingers = True
        real, opened, label = bench.robot.open_gripper, [], "red cube"

        def open_and_nudge():                    # knocked 2.5 mm one way at spot 3, and 2 mm the other at spot 9
            held, r = bench.robot._held, bench.robot.real_r()
            real()
            if held is not None:
                opened.append(1)
                mm = {5: 2.5, 12: -2.0}.get(len(opened))
                if mm:
                    x, y, z = bench.world.get_object_position_mm(bench.ids[label])
                    along = math.radians(bench.gripper.closing_direction(r) + 90.0)
                    bench.robot._place_object(bench.ids[label], x + mm * math.cos(along), y + mm * math.sin(along),
                                              z, bench.world.get_object_yaw_deg(bench.ids[label]))
        bench.robot.open_gripper = open_and_nudge
        out = bench.phase1(mode="precise")
        self.assertTrue(out.passed, out.reason)
        self.assertTrue(out.fit.tracked, out.fit.name)
        self.assertLess(float(np.median(bench.xy_errors(out.transform, 20, out.correction))), 0.6)
        self.assertIn("Cube calibration summary", cube.summary(out))


class CalibrationHistoryTests(unittest.TestCase):
    def test_earlier_calibrations_are_kept_and_can_be_gone_back_to_or_cleared(self):
        path = Path(tempfile.mkdtemp()) / "calibration.json"
        k = Intrinsics(fx=600.0, fy=600.0, cx=320.0, cy=240.0, width=640, height=480)
        for n in range(13):
            save_calibration(path, np.eye(4) * (1 + n), k, method=f"cube (quick) {n}", reprojection_error_mm=0.1 * n,
                             num_samples=10)
            os.utime(path, (1_000_000 + n * 60, 1_000_000 + n * 60))        # (saved a minute apart)
        history = calibration_history(path)
        self.assertEqual(len(history), 10)                                  # the newest 10 kept
        self.assertEqual(history[0][1].method, "cube (quick) 11")           # the one before the one in use
        restore_calibration(path, history[2][0])
        self.assertEqual(load_calibration(path).method, "cube (quick) 9")
        self.assertEqual(calibration_history(path)[0][1].method, "cube (quick) 12", "the one replaced is kept")
        clear_calibration(path)
        self.assertIsNone(load_calibration(path))
        methods = [calib.method for _, calib, _ in calibration_history(path)]     # (by when each was made)
        self.assertIn("cube (quick) 9", methods)
        self.assertEqual(len(methods), len(set(methods)), "each kept once")

    def test_going_back_is_checked_first_and_the_one_restored_is_dated_now(self):
        path = Path(tempfile.mkdtemp()) / "calibration.json"
        k = Intrinsics(fx=600.0, fy=600.0, cx=320.0, cy=240.0, width=640, height=480)
        for n in range(2):
            save_calibration(path, np.eye(4), k, method=f"cube (quick) {n}", reprojection_error_mm=0.5, num_samples=10)
            os.utime(path, (1_000_000 + n * 60, 1_000_000 + n * 60))
        earlier = calibration_history(path)[0][0]
        damaged = path.with_name("damaged.json")
        damaged.write_text('{"t_cam_to_robot": [[1, 0', encoding="utf-8")
        self.assertIsNone(restore_calibration(path, damaged))
        self.assertEqual(load_calibration(path).method, "cube (quick) 1", "the one in use kept")
        self.assertTrue(damaged.exists(), "left where it was")
        started = time.time()
        self.assertEqual(restore_calibration(path, earlier).method, "cube (quick) 0")
        self.assertGreater(path.stat().st_mtime, started - 2.0, "dated now, not when it was first made")
        self.assertEqual(load_calibration(path).method, "cube (quick) 0")



class ReviewRegressionTests(unittest.TestCase):
    """Bugs a review of the cube calibration found (2026-10-09), pinned down."""

    def test_camera_noise_alone_doesnt_turn_the_wrist(self):
        noisy = [0.5, -1.5, 2.0, -2.0, 1.8, -1.0, 5.4]          # the cube never turned; the camera reads +-2, then 5.4
        self.assertEqual(cube.cube_turned(noisy), 0.0)
        steady = [0.2, -0.3, 0.1, -0.2, 0.3, 10.0]              # a steady reading, then a real 10 degree turn
        self.assertNotEqual(cube.cube_turned(steady), 0.0)

    def test_a_noisy_camera_never_lets_a_turn_too_wide_for_the_fingers_through(self):
        # (found running the walk-through: readings scattered by +-3 degrees put the noise floor at 9, so a cube
        # really turned 7 degrees -- too wide for a 25 mm cube in fingers opening 27.5 -- wasn't matched: a miss)
        scattered = [3.0, -3.0, 2.5, -2.8, 3.2, -2.6, 7.0]
        self.assertGreater(cube.turn_noise(scattered), 7.0)
        self.assertEqual(cube.cube_turned(scattered), 0.0)                      # no limit: left alone
        fits = cube.fits_turn(25.0, 27.5)
        self.assertAlmostEqual(fits, 4.1, delta=0.2)
        self.assertNotEqual(cube.cube_turned(scattered, fits), 0.0)             # past what fits: matched
        self.assertEqual(cube.turn_threshold([0.0] * 6, fits), cube.TURN_FIX_MIN_DEG)
        self.assertEqual(cube.fits_turn(20.0, 40.0), 45.0)

    def test_the_measured_cube_side_is_the_narrow_side(self):
        sighting = mock.Mock(footprint_mm=(24.0, 20.2))
        progress = mock.Mock(cube_size_mm=None)
        progress.out.pairs = [mock.Mock(sighting=sighting) for _ in range(3)]
        self.assertAlmostEqual(cube._cube_side(progress), 20.2)

    def test_the_room_check_trusts_a_measured_cubes_height_over_its_blurred_top(self):
        # a poor camera reads a 20 mm cube's top as 23 mm (blurred edges) but its height right: in fingers opening
        # 22 mm, that is room enough -- not a pause at the first spot
        sighting = mock.Mock(footprint_mm=(23.0, 24.3), height_mm=20.0)
        progress = mock.Mock(cube_size_mm=None)
        progress.out.pairs = [mock.Mock(sighting=sighting)]
        gripper = mock.Mock(fingers=True, opening_mm=22.0)
        shift, room, why = cube._room(progress, gripper, sighting, 200.0, 0.0, 0.0, [])
        self.assertEqual(why, "")
        self.assertGreater(room, 0.0)
        progress.cube_size_mm = 23.0                            # typed in: taken as it is
        shift, room, why = cube._room(progress, gripper, sighting, 200.0, 0.0, 0.0, [])
        self.assertLess(room, 0.0)
        self.assertIn("23 mm cube", why)

    def test_the_gripper_hiding_the_cube_isnt_taken_for_a_pick_it_looks_again_from_away(self):
        # (the gripper hovering over a missed cube, seen from above, read "gone": a miss scored as a perfect pick)
        arm = mock.Mock(camera=object(), settle_s=0.0)
        sighting = mock.Mock(pixel=(10.0, 10.0), depth_mm=500.0)

        def depth(value):
            return np.full((20, 20), value, float), None
        for value, expect in ((500.0, True), (525.0, False), (470.0, None), (0.0, None)):
            with mock.patch.object(cube, "median_depth", return_value=depth(value)):
                self.assertEqual(cube._seen_at(arm, sighting), expect, value)
        robot = mock.Mock(spec=["get_pose"])                    # the Dobot: no held_object, no gap reading
        looks = iter([depth(470.0), depth(500.0)])             # hidden by the gripper; from away, still there
        with mock.patch.object(cube, "median_depth", side_effect=lambda *a: next(looks)):
            self.assertFalse(cube.holding_after(arm, robot, sighting, away="the waiting place"))
        arm.away.assert_called_once_with("the waiting place")

    def test_a_controller_that_stops_answering_pauses_at_once_saying_what_to_do(self):
        # (the lab, 2026-10-11: the lift after spot 3 got no answer, sent again and again; the run skipped three
        # spots, each the same stuck move, before it paused)
        bench = Bench(self)
        real_move, count = bench.robot.move_to, [0]

        def stuck_after_a_while(pose, *a, **k):
            count[0] += 1
            if count[0] > 40:
                raise RuntimeError("The robot did not acknowledge the move command.")
            return real_move(pose, *a, **k)
        bench.robot.move_to = stuck_after_a_while
        out = bench.phase1()
        bench.robot.move_to = real_move
        self.assertTrue(out.paused, out.reason)
        self.assertFalse([s for s in out.skipped if "acknowledge" in s], out.skipped)
        self.assertIn("switch the Dobot off", out.reason)

    def test_a_step_that_failed_after_taking_the_cube_isnt_done_again(self):
        robot = mock.Mock()
        robot.get_pose.return_value = Pose(200.0, 0.0, 10.0, 0.0)
        arm = cube._Arm(robot, None, 0.0, 1, lambda m: None, None)
        steps = []

        def step():
            steps.append(1)
            arm.acted = arm.closed = True                       # closed on the cube...
            raise RuntimeError("no answer")                     # ...then the lift wasn't answered
        with mock.patch.object(cube.time, "sleep"):
            arm.retried("Taking the cube back", step)
        self.assertEqual(len(steps), 1, "not taken a second time")

    def test_on_a_gripper_that_cant_tell_a_miss_is_seen_as_the_cube_still_there(self):
        robot = mock.Mock(spec=["get_pose"])                    # no held_object, no gap reading: the Dobot
        arm = mock.Mock(camera=object())
        sighting = mock.Mock()
        with mock.patch.object(cube, "_seen_at", return_value=True):
            self.assertFalse(cube.holding_after(arm, robot, sighting), "still on the table: a miss")
        with mock.patch.object(cube, "_seen_at", return_value=False):
            self.assertTrue(cube.holding_after(arm, robot, sighting))
        self.assertTrue(cube.holding_after(arm, robot, None), "nothing to look at: as before")

    def test_a_take_back_the_camera_cant_judge_from_above_is_looked_at_from_out_of_the_way(self):
        # (reviewer 2, 2026-10-27: "can't tell" -- the gripper over the spot -- was taken as "taken")
        arm, sighting, away = mock.Mock(camera=object()), mock.Mock(), Pose(150.0, 150.0, 120.0, 0.0)
        with mock.patch.object(cube, "_seen_at", side_effect=[None, True]):
            self.assertTrue(cube._still_there(arm, sighting, away), "seen from away: still on the table")
        arm.away.assert_called_once_with(away)
        with mock.patch.object(cube, "_seen_at", side_effect=[None, False]):
            self.assertFalse(cube._still_there(arm, sighting, away))
        with mock.patch.object(cube, "_seen_at", side_effect=[None]):
            self.assertFalse(cube._still_there(arm, sighting), "nowhere else to look from: as before")

    def test_a_group_of_spots_far_off_fails_however_good_the_typical(self):
        self.assertEqual(len(cube.too_many_far([1.0] * 6 + [4.0, 4.5, 4.2, 5.0])), 4, "4 of 10 at 4-5 mm")
        self.assertEqual(cube.too_many_far([1.0] * 9 + [3.5]), [], "one far spot: noise")
        self.assertEqual(cube.too_many_far([1.0] * 18 + [3.2, 3.4]), [], "2 of 20: under a fifth")
        self.assertEqual(len(cube.too_many_far([1.0] * 4 + [3.2, 3.4])), 2, "2 of 6 (Fast)")
        self.assertEqual(cube.too_many_far([]), [])

    def test_after_a_step_stopped_part_way_where_the_cube_is_is_what_the_step_last_did(self):
        from types import SimpleNamespace
        out = SimpleNamespace(holding=True, cube_at=None)
        cube._holding_now(out, SimpleNamespace(acted=True, closed=False, acted_at=(210.0, 15.0)))
        self.assertEqual((out.holding, out.cube_at), (False, (210.0, 15.0)), "let go of, then no answer")
        cube._holding_now(out, SimpleNamespace(acted=True, closed=True, acted_at=(210.0, 15.0)))
        self.assertEqual((out.holding, out.cube_at), (True, None), "gripped as Pause was pressed")
        cube._holding_now(out, SimpleNamespace(acted=False, closed=False, acted_at=None))
        self.assertEqual((out.holding, out.cube_at), (True, None), "nothing done yet: as it was")

    def test_progress_saved_by_an_older_version_is_started_afresh(self):
        import pickle
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "calibration_cube_progress.pkl"
            path.write_bytes(pickle.dumps((1, {"an": "old progress"})))
            self.assertIsNone(cube.load_progress(path))

    def test_adding_to_a_calibration_doesnt_fill_the_history_with_copies(self):
        from app.calibration.storage import save_calibration
        from app.hardware.interfaces import Intrinsics
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "calibration.json"
            intr = Intrinsics(fx=600, fy=600, cx=320, cy=240, width=640, height=480)
            save_calibration(path, np.eye(4), intr, "cube", 1.0, 10)
            save_calibration(path, np.eye(4), intr, "cube", 1.0, 10)              # a new calibration: archived
            before = len(calibration_history(path))
            save_calibration(path, np.eye(4), intr, "cube", 1.0, 10, extras={"wrist_model": {}}, archive=False)
            self.assertEqual(len(calibration_history(path)), before)


class ReviewerTwoRunTests(unittest.TestCase):
    """A run stopped part way, as a second review of the calibration found it (2026-10-27): carrying on after a stop
    before the spots were planned, an arm that needs a person, a knocked cube's spot, a grip on nothing."""

    def test_stopped_before_the_spots_were_planned_it_carries_on_afresh(self):
        bench = Bench(self)
        saved = []
        with mock.patch.object(cube, "_centre_in_hand", side_effect=RuntimeError("The Dobot hasn't been homed")):
            out = bench.phase1(spots=8, on_save=saved.append)
        self.assertTrue(out.paused and out.keep_progress, out.reason)
        progress = saved[-1]
        self.assertEqual((progress.route, progress.backgrounds), ([], []))
        bench.take_over()
        out = bench.resume(progress)       # (it read the empty table's first picture, which wasn't there: IndexError)
        self.assertTrue(out.passed, out.reason)
        self.assertEqual(len(progress.route), 8)
        self.assertEqual(len(progress.backgrounds), len(progress.away))

    def test_an_arm_that_needs_a_person_pauses_with_the_spots_left_to_do(self):
        from app.hardware.interfaces import Frame, RobotNeedsPerson

        class Camera:
            def get_intrinsics(self):
                return Intrinsics(width=640, height=480, fx=600, fy=600, cx=320, cy=240)

            def get_frame(self):
                return Frame(np.zeros((480, 640, 3), np.uint8), np.full((480, 640), 800, np.float32),
                             self.get_intrinsics())

        class Stuck:                         # takes 40 moves, then refuses every one (an alarm that won't clear)
            tool_centre_mm, moves, pose = (0.0, 0.0), 0, Pose(220, 0, -30, 0)

            def get_pose(self):
                return self.pose

            def move_to(self, pose, speed=None):
                self.moves += 1
                if self.moves > 40:
                    raise RobotNeedsPerson("stuck in alarm: refuses every move")
                self.pose = pose

            def open_gripper(self):
                pass

            close_gripper = open_gripper

        saved = []
        bounds = {"x": [100.0, 320.0], "y": [-250.0, 250.0], "z": [-31.6, 150.0]}
        out = run_cube_calibration(Stuck(), Camera(), bounds, 320.0, None, mode="quick", table_z=-31.0, settle_s=0,
                                   frames=1, on_save=saved.append)
        self.assertTrue(out.paused and out.keep_progress, out.reason)
        self.assertIn("stuck in alarm", out.reason)
        self.assertFalse([s for s in out.skipped if "couldn't go there" in s], "every spot left was skipped")
        self.assertLess(saved[-1].next_index, len(saved[-1].route))
        self.assertTrue(cube.needs_a_person(RuntimeError("Lost contact with the robot during a move: x")))
        self.assertFalse(cube.needs_a_person(RuntimeError("The arm can't reach (300, 0, -30)")))

    def _take_back(self, room, still_there):
        arm = mock.Mock(acted=True, closed=True, camera=object())
        progress = mock.Mock()
        progress.out.hand.pick_z.return_value = 0.0
        with mock.patch.object(cube, "_room", return_value=((4.0, 0.0), room, "it bounced or was knocked")),                 mock.patch.object(cube, "_take_back"),                 mock.patch.object(cube, "_still_there", return_value=still_there),                 mock.patch.object(cube, "_retake", return_value=None):
            with self.assertRaises(cube._Paused) as stopped:
                cube._take_back_checked(arm, mock.Mock(), progress, mock.Mock(), 200.0, 0.0, 0.0, 0.0, 0.0,
                                        mock.Mock(), [], "Spot 3")
        return arm, stopped.exception

    def test_a_knocked_cube_pauses_as_knocked_and_a_grip_on_nothing_isnt_holding(self):
        _, paused = self._take_back(cube.KNOCKED, False)
        self.assertTrue(paused.knocked)
        _, paused = self._take_back(-0.3, False)                 # no room for the fingers: its spot is good
        self.assertFalse(paused.knocked)
        arm, paused = self._take_back(None, True)                # closed on nothing, and on nothing again
        self.assertIn("without the cube", paused.why)
        self.assertFalse(arm.closed, "taken as still in the gripper")


if __name__ == "__main__":
    unittest.main()

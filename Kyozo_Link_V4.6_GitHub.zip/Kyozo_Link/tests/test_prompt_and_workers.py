"""The prompt tab's busy indicator, and background jobs that are dropped the moment they finish.

    python -m unittest discover -s tests -p test_prompt_and_workers.py -v
"""
from __future__ import annotations

import gc
import os
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from harness import ROOT  # noqa: F401,E402  (sets up sys.path and the working folder)
from PyQt6.QtWidgets import QApplication  # noqa: E402

from app.llm.agent import AgentRun  # noqa: E402
from app.ui import worker as worker_module  # noqa: E402
from app.ui.prompt_panel import PromptPanel  # noqa: E402
from app.ui.worker import CallableWorker  # noqa: E402

app = QApplication.instance() or QApplication([])


def pump_until(condition, timeout_s: float = 20.0) -> None:
    deadline = time.time() + timeout_s
    while not condition():
        if time.time() > deadline:
            raise TimeoutError("did not finish in time")
        app.processEvents()
        time.sleep(0.005)


class SlowAgent:
    def __init__(self, fail: bool = False):
        self.fail = fail

    def run(self, prompt, on_step=None):
        time.sleep(0.8)
        if self.fail:
            raise RuntimeError("Could not reach Ollama")
        return AgentRun(final_message="done")


class BusyIndicatorTests(unittest.TestCase):
    def check(self, fail: bool):
        panel = PromptPanel(SlowAgent(fail))
        panel.show()
        panel._send_text("go home")
        app.processEvents()
        self.assertTrue(panel.busy.isVisible(), "the bar shows while the model works")
        self.assertIn("can take up to a minute to process", panel.busy.label.text())
        self.assertIn("can take up to a minute to process", panel.log.toPlainText())
        self.assertNotIn("CPU-only", panel.log.toPlainText())
        self.assertFalse(panel.send_btn.isEnabled())
        pump_until(lambda: not panel.is_busy())
        self.assertFalse(panel.busy.isVisible(), "and goes away when it's done")
        self.assertTrue(panel.send_btn.isEnabled())
        return panel

    def test_shows_while_working_and_hides_afterwards(self):
        self.assertIn("done", self.check(fail=False).log.toPlainText())

    def test_hides_after_an_error_too(self):
        self.assertIn("Could not reach Ollama", self.check(fail=True).log.toPlainText())


class LogLineTests(unittest.TestCase):
    """Your prompts, the robot's steps, its reply and errors were all one colour: each now has its own, and an icon."""

    def setUp(self):
        self.panel = PromptPanel(agent=None)
        self.addCleanup(self.panel.deleteLater)

    def html_of_last_line(self) -> str:
        block = self.panel.log.document().lastBlock()
        cursor = self.panel.log.textCursor()
        cursor.setPosition(block.position())
        cursor.setPosition(block.position() + block.length() - 1, cursor.MoveMode.KeepAnchor)
        return cursor.selection().toHtml()

    def test_each_kind_of_line_has_its_colour_and_icon(self):
        from app.ui.prompt_panel import LINE_STYLES
        for kind, text in (("you", "You: green cube on the red one"), ("robot", "Robot: done"), ("error", "Error: x")):
            self.panel._append_log(text, kind)
            line = self.html_of_last_line()
            colour, name = LINE_STYLES[kind]
            self.assertIn(colour.lower(), line.lower(), kind)
            self.assertIn(f"icon://{name}/", line, kind)
        self.assertIn("You: green cube on the red one", self.panel.log.toPlainText(), "the words are as they were")

    def test_refused_steps_can_be_hidden_and_the_conversation_cleared(self):
        panel = self.panel
        panel._append_log("You: dismantle the tower", "you")
        panel._append_log("Step refused (take_apart): Call list_objects first.", "refused")
        panel._append_log("Robot: done", "robot")
        panel._append_log("Note: not everything asked for was done", "note")
        panel.refused_switch.setChecked(False)
        text = panel.log.toPlainText()
        self.assertNotIn("Step refused", text)
        self.assertIn("Note: not everything", text, "the app's own check under a reply always shows")
        panel._append_log("Step refused (pick): Already holding the red cube.", "refused")    # while hidden
        self.assertNotIn("Step refused", panel.log.toPlainText())
        panel.refused_switch.setChecked(True)
        text = panel.log.toPlainText()
        self.assertEqual(text.count("Step refused"), 2, "shown again, in their places")
        self.assertLess(text.index("take_apart"), text.index("Robot: done"))
        panel.clear_btn.click()
        self.assertEqual(panel.log.toPlainText(), "")
        panel.refused_switch.setChecked(False)
        self.assertEqual(panel.log.toPlainText(), "", "cleared stays cleared")

    def test_a_step_gets_the_icon_of_what_it_did(self):
        from app.llm.agent import AgentStep
        from app.ui.prompt_panel import step_kind
        self.assertEqual(step_kind(AgentStep("list_objects", {}, "{}")), "look")
        self.assertEqual(step_kind(AgentStep("pick", {"object_id": "obj_1"}, "Picked up red cube")), "pick")
        self.assertEqual(step_kind(AgentStep("place_on", {"object_id": "obj_1"}, "Placed")), "place")
        self.assertEqual(step_kind(AgentStep("pick", {}, "ERROR: no such object")), "refused")


class ReplyReasonTests(unittest.TestCase):
    """The robot once said "too wide for the gripper" when the tool had said the cube touched the table."""

    def test_a_reason_the_tools_never_gave_is_flagged_with_theirs(self):
        from app.llm.agent import AgentStep
        from app.ui.prompt_panel import reply_reason_mismatch
        steps = [AgentStep("pick", {"object_id": "obj_1"}, "ERROR: Stopped at (480, 10, 12): the black cube it "
                                                             "carries touched the table.")]
        made_up = "The black cube cannot be picked up because it is too wide for the gripper."
        self.assertIn("touched the table", reply_reason_mismatch(made_up, steps))
        honest = "I couldn't: the black cube touched the table while it was carried, so it stopped."
        self.assertEqual(reply_reason_mismatch(honest, steps), "")
        self.assertEqual(reply_reason_mismatch("Done.", []), "")


class WorkerLifetimeTests(unittest.TestCase):
    def test_workers_dropped_at_the_moment_they_finish_do_not_crash(self):
        results = []
        for _ in range(200):
            worker = CallableWorker(lambda: 1)
            worker.finished_ok.connect(results.append)
            worker.start()
            del worker                 # nobody holds it: the way a handler drops it when the result arrives
            if len(results) % 20 == 0:
                gc.collect()
                app.processEvents()
        pump_until(lambda: len(results) == 200)
        pump_until(lambda: not worker_module._running)
        self.assertEqual(len(results), 200)


if __name__ == "__main__":
    unittest.main()

"""The depth preset (Settings > Camera): loaded before the camera streams, changed while running (restart the streams,
else reopen the camera, else keep the old one), saved in config.yaml, locked while busy, and recorded with each
calibration.

    python -m unittest discover -s tests -p test_depth_preset.py -v

The real camera's SDK is replaced by a stand-in that behaves like the Gemini 335 (a preset only takes while the
streams are stopped), so this runs without hardware. Uses a temporary folder: nothing in the project changes.
"""
from __future__ import annotations

import os
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: E402  (sets up sys.path and the working folder)
import numpy as np  # noqa: E402
import yaml  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

from app.calibration.storage import load_calibration, save_calibration  # noqa: E402
from app.config import load_config  # noqa: E402
from app.hardware import camera as camera_module  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402

app = QApplication.instance() or QApplication([])


def pump_until(condition, timeout_s: float = 60.0) -> None:
    deadline = time.time() + timeout_s
    while not condition():
        if time.time() > deadline:
            raise TimeoutError("the UI did not finish in time")
        app.processEvents()
        time.sleep(0.01)


# ---- a stand-in for pyorbbecsdk -----------------------------------------------------------------------------------
class FakeDevice:
    def __init__(self, sdk):
        self.sdk = sdk

    def get_current_preset_name(self):
        return self.sdk.preset

    def load_preset(self, name):
        self.sdk.calls.append(("load", name, self.sdk.streaming))
        if self.sdk.streaming or name in self.sdk.refused:    # like the Gemini 335: not while streaming
            raise RuntimeError("device busy")
        if not (self.sdk.ignore_after_restart and self.sdk.starts > 0 and not self.sdk.fresh):
            self.sdk.preset = name


class FakeFrames:
    def __init__(self, w=4, h=3):
        self.w, self.h = w, h

    def get_color_frame(self):
        return SimpleNamespace(get_data=lambda: np.zeros(self.w * self.h * 3, np.uint8).tobytes(),
                               get_width=lambda: self.w, get_height=lambda: self.h)

    def get_depth_frame(self):
        return SimpleNamespace(get_data=lambda: np.full(self.w * self.h, 500, np.uint16).tobytes(),
                               get_width=lambda: self.w, get_height=lambda: self.h, get_depth_scale=lambda: 1.0)


class FakeSDK:
    def __init__(self):
        self.preset = "Default"
        self.streaming = False
        self.calls: list = []
        self.starts = 0
        self.fresh = True             # a Pipeline just made (reopened), not yet started
        self.refused: set = set()     # presets the camera never takes
        self.ignore_after_restart = False   # restarting the streams doesn't take a new preset (reopening does)
        self.fail_reopen = 0          # how many reopens fail
        self.slow_start_s = 0.0

    def install(self):
        sdk = self

        class Pipeline:
            def __init__(self):
                if sdk.fail_reopen and sdk.starts > 0:
                    sdk.fail_reopen -= 1
                    raise RuntimeError("no device")
                sdk.fresh = True

            def get_stream_profile_list(self, _sensor):
                profile = SimpleNamespace(
                    get_intrinsic=lambda: SimpleNamespace(fx=1.0, fy=1.0, cx=2.0, cy=1.5, width=4, height=3),
                    get_distortion=lambda: SimpleNamespace(k1=0, k2=0, p1=0, p2=0, k3=0, k4=0, k5=0, k6=0))
                return SimpleNamespace(get_video_stream_profile=lambda *a: profile)

            def enable_frame_sync(self):
                pass

            def get_device(self):
                return FakeDevice(sdk)

            def start(self, _config):
                time.sleep(sdk.slow_start_s)
                sdk.calls.append(("start", sdk.preset))
                sdk.streaming, sdk.fresh = True, False
                sdk.starts += 1

            def stop(self):
                sdk.calls.append(("stop",))
                sdk.streaming = False

            def wait_for_frames(self, _ms):
                return FakeFrames()

        patches = {
            "Pipeline": Pipeline,
            "Context": lambda: SimpleNamespace(query_devices=lambda: [object()]),
            "Config": lambda: SimpleNamespace(enable_stream=lambda _p: None),
            "OBSensorType": SimpleNamespace(COLOR_SENSOR=0, DEPTH_SENSOR=1),
            "OBFormat": SimpleNamespace(RGB=0, Y16=1),
            "AlignFilter": lambda align_to_stream: SimpleNamespace(process=lambda frames: frames),
            "OBStreamType": SimpleNamespace(COLOR_STREAM=0),
        }
        return [mock.patch.object(camera_module, name, value, create=True) for name, value in patches.items()]


class OrbbecPresetTests(unittest.TestCase):
    def setUp(self):
        self.sdk = FakeSDK()
        self.patches = self.sdk.install()
        for p in self.patches:
            p.start()
        self.camera = camera_module.OrbbecCamera(width=4, height=3, undistort=False, depth_preset="High Accuracy")

    def tearDown(self):
        for p in self.patches:
            p.stop()

    def test_loaded_before_the_streams_start(self):
        self.camera.connect()
        load = self.sdk.calls.index(("load", "High Accuracy", False))
        self.assertLess(load, self.sdk.calls.index(("start", "High Accuracy")))
        self.assertEqual(self.camera.depth_preset, "High Accuracy")

    def test_a_camera_that_refuses_keeps_its_own_and_still_streams(self):
        self.sdk.refused = {"High Accuracy"}
        self.camera.connect()
        self.assertEqual(self.camera.depth_preset, "Default")
        self.camera.get_frame()

    def test_switch_by_restarting_the_streams(self):
        self.camera.connect()
        message = self.camera.switch_depth_preset("Default")
        self.assertEqual(message, "Depth preset: Default.")
        self.assertEqual((self.camera.depth_preset, self.sdk.preset, self.sdk.streaming), ("Default", "Default", True))
        self.camera.get_frame()

    def test_switch_by_reopening_when_a_restart_doesnt_take_it(self):
        self.camera.connect()
        self.sdk.ignore_after_restart = True
        started = self.camera.connected_at
        message = self.camera.switch_depth_preset("Default")
        self.assertIn("reopened", message)
        self.assertEqual(self.camera.depth_preset, "Default")
        self.assertEqual(self.camera.connected_at, started)    # the camera's warm-up isn't restarted
        self.camera.get_frame()

    def test_back_to_the_old_preset_when_reopening_fails(self):
        self.camera.connect()
        self.sdk.ignore_after_restart = True
        self.sdk.fail_reopen = 1
        message = self.camera.switch_depth_preset("Default")
        self.assertIn("wouldn't take", message)
        self.assertEqual(self.camera.depth_preset, "High Accuracy")
        self.camera.get_frame()

    def test_says_so_when_the_camera_cant_be_brought_back(self):
        self.camera.connect()
        self.sdk.ignore_after_restart = True
        self.sdk.fail_reopen = 2
        with self.assertRaises(RuntimeError):
            self.camera.switch_depth_preset("Default")

    def test_feed_doesnt_freeze_while_switching_but_workers_wait(self):
        self.camera.connect()
        self.sdk.slow_start_s = 0.3
        switching = threading.Thread(target=self.camera.switch_depth_preset, args=("Default",))
        switching.start()
        time.sleep(0.1)
        with self.assertRaises(RuntimeError):          # the UI thread: no waiting
            self.camera.get_frame()
        got = []
        worker = threading.Thread(target=lambda: got.append(self.camera.get_frame()))
        worker.start()
        worker.join(5)
        switching.join(5)
        self.assertEqual(len(got), 1)                  # a worker waited for the switch, then got a picture
        self.assertEqual(self.camera.depth_preset, "Default")


# ---- the app ------------------------------------------------------------------------------------------------------
class SettingsCameraTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        shutil.copy(ROOT / "config.yaml", Path(cls.folder.name) / "config.yaml")
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
        config["display"] = {}
        config["camera"]["depth_preset"] = "Default"
        cls.window = main_window_module.MainWindow(config)
        cls.window.show()

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def setUp(self):
        self.window.camera.preset_trouble = None
        self.choose("Default")

    def saved(self, key: str = "depth_preset_demo") -> str:
        """The preset saved in config.yaml: the demo's (these tests run the demo) unless `key` says otherwise."""
        raw = yaml.safe_load((Path(self.folder.name) / "config.yaml").read_text(encoding="utf-8"))
        return raw["camera"].get(key)

    def choose(self, name: str) -> None:
        self.window._on_depth_preset(name)
        pump_until(lambda: not self.window._preset_switching())

    def test_in_every_settings_panel(self):
        self.assertEqual(len(self.window._preset_combos), len(self.window._settings_panels))
        self.assertGreaterEqual(len(self.window._preset_combos), 1)

    def test_switch_is_saved_and_shown_everywhere(self):
        self.choose("High Accuracy")
        self.assertEqual(self.window.camera.depth_preset, "High Accuracy")
        self.assertEqual(self.saved(), "High Accuracy")
        self.assertNotEqual(self.saved("depth_preset"), "High Accuracy", "the lab camera's preset isn't the demo's")
        self.assertTrue(all(c.currentText() == "High Accuracy" and c.isEnabled() for c in self.window._preset_combos))

    def test_a_camera_that_refuses_stays_and_says_so(self):
        self.window.camera.preset_trouble = "refuse"
        self.choose("High Accuracy")
        self.assertEqual(self.window.camera.depth_preset, "Default")
        self.assertEqual(self.saved(), "Default")
        self.assertTrue(all(c.currentText() == "Default" for c in self.window._preset_combos))
        self.assertIn("wouldn't take", self.window.statusBar().currentMessage())

    def test_locked_while_calibrating(self):
        panel = self.window.calibration_tab
        panel._worker = object()
        try:
            self.choose("High Accuracy")
        finally:
            panel._worker = None
        self.assertEqual(self.window.camera.depth_preset, "Default")
        self.assertIn("calibration step is running", self.window.statusBar().currentMessage())

    def test_recorded_with_the_calibration_and_a_mismatch_is_reported(self):
        panel = self.window.calibration_tab
        self.assertEqual(panel._camera_extras()["depth_preset"], "Default")
        path = self.window._calibration_path()
        save_calibration(path, np.eye(4), self.window.camera.get_intrinsics(), method="test",
                         reprojection_error_mm=1.0, num_samples=3, extras=panel._camera_extras())
        try:
            self.assertEqual(load_calibration(path).extras["depth_preset"], "Default")
            self.assertIsNone(self.window._preset_mismatch())
            self.choose("High Accuracy")
            self.assertIn("made with the Default depth preset", self.window._preset_mismatch())
            self.assertIn("recalibrate", self.window.statusBar().currentMessage())
        finally:
            path.unlink(missing_ok=True)


class LiveSettingsTests(unittest.TestCase):
    """Live mode has a Settings panel too, with just the camera; with no camera plugged in the choice is kept for
    when it connects."""

    def test_live_panel_saves_for_the_next_connect(self):
        with tempfile.TemporaryDirectory() as folder:
            original = (main_window_module.PROJECT_ROOT, main_window_module.DobotRobot, main_window_module.OrbbecCamera)
            main_window_module.PROJECT_ROOT = Path(folder)
            shutil.copy(ROOT / "config.yaml", Path(folder) / "config.yaml")

            def missing(*args, **kwargs):
                raise RuntimeError("nothing is plugged in")
            main_window_module.DobotRobot = missing
            main_window_module.OrbbecCamera = missing
            try:
                config = load_config()
                config["mode"] = "live"
                config["display"] = {}
                window = main_window_module.MainWindow(config)
                window.show()
                self.assertEqual(len(window._settings_panels), 1)
                self.assertEqual(len(window._preset_combos), 1)
                window.settings_btn.setChecked(True)
                self.assertTrue(window._settings_panels[0].isVisible())
                window._on_depth_preset("High Accuracy")
                raw = yaml.safe_load((Path(folder) / "config.yaml").read_text(encoding="utf-8"))
                self.assertEqual(raw["camera"]["depth_preset"], "High Accuracy")
                self.assertIn("when the camera connects", window.statusBar().currentMessage())
                window.close()
            finally:
                main_window_module.PROJECT_ROOT, main_window_module.DobotRobot, main_window_module.OrbbecCamera = original


if __name__ == "__main__":
    unittest.main()

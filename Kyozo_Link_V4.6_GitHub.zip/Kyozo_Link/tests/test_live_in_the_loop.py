"""The whole app in LIVE mode, against a fake Dobot that moves the simulator.

    python -m unittest discover -s tests -p test_live_in_the_loop.py -v

The real robot driver (queue, waiting for a move to finish, E-STOP, alarms) and the live-mode
parts of the app run unchanged. What is fake is only the far end of the serial cable and the
camera: the fake Dobot answers the way the protocol says, and moves the simulated arm so the
(also simulated, and slightly laggy and read-only) camera sees it. Nothing in the project changes:
calibrations and sessions go to a temporary folder.
"""
from __future__ import annotations

import math
import os
import shutil
import struct
import sys
import tempfile
import threading
import time
import traceback
import unittest
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT, Sim  # noqa: E402  (sets up sys.path and the working folder)
from PyQt6.QtWidgets import QApplication, QMessageBox, QTabWidget  # noqa: E402

from app.config import load_config  # noqa: E402
from app.hardware.dobot import DobotRobot  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from app.system_check import FAIL  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402
from scripted import StackingClient  # noqa: E402
from test_hardware_realism import RealCameraLike  # noqa: E402

app = QApplication.instance() or QApplication([])
sys.excepthook = lambda *info: traceback.print_exception(*info)   # PyQt6 quits silently on an error in a handler; show it


def pump_until(condition, timeout_s: float = 600.0) -> None:
    deadline = time.time() + timeout_s
    while not condition():
        if time.time() > deadline:
            raise TimeoutError("the UI did not finish in time")
        app.processEvents()
        time.sleep(0.01)


class SimBackedDobot:
    """Speaks the Dobot's protocol as far as the driver uses it, and moves a SimRobot."""

    MOVE_SECONDS = 0.25

    def __init__(self, sim_robot):
        self.lock = threading.Lock()
        self.robot = sim_robot
        self.queued = self.finished = 0
        self.move = None
        self.alarm = False
        self.stops = 0

    def _advance(self, now: float) -> None:
        if self.move is None:
            return
        index, t0, t1, start, target = self.move
        fraction = min(1.0, (now - t0) / (t1 - t0))
        pose = Pose(*[s + (t - s) * fraction for s, t in zip(start, target)])
        self.robot._pose = pose
        self.robot._apply_pose_to_visual()
        if fraction >= 1.0:
            self.finished, self.move = index, None

    def _send_command(self, msg, wait=False):
        with self.lock:
            now = time.monotonic()
            self._advance(now)
            message_id = getattr(msg.id, "value", msg.id)
            if message_id in (84, 31):
                here = self.robot._pose
                target = (list(struct.unpack_from("<4f", msg.params, 1)) if message_id == 84
                          else [200.0, 0.0, 50.0, 0.0])
                self.queued += 1
                self.move = (self.queued, now, now + self.MOVE_SECONDS, [here.x, here.y, here.z, here.r], target)
                return SimpleNamespace(params=struct.pack("<II", self.queued, 0))
            if message_id in (62, 63):                        # suction cup / gripper, sent outside the queue
                (self.robot.close_gripper if msg.params[1] else self.robot.open_gripper)()
                return SimpleNamespace(params=b"")
            if message_id == 246:
                return SimpleNamespace(params=struct.pack("<II", self.finished, 0))
            if message_id == 20:
                return SimpleNamespace(params=bytes([1] + [0] * 15) if self.alarm else bytes(16))
            if message_id == 241:
                self.stops += 1
                self.move = None
            return SimpleNamespace(params=bytes(8))

    def pose(self):
        with self.lock:
            self._advance(time.monotonic())
            p = self.robot._pose
            return (p.x, p.y, p.z, p.r, 0.0, 0.0, 0.0, 0.0)

    def close(self):
        pass


class FakeOrbbec(RealCameraLike):
    """The simulated camera dressed as the Orbbec: laggy, read-only pictures, and a USB 3 connection."""

    def connect(self):
        pass

    def disconnect(self):
        pass

    def describe(self):
        return {"name": "Gemini 335 (fake)", "connection": "USB3.2"}


class LiveModeInTheLoop(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        shutil.copy(ROOT / "config.yaml", Path(cls.folder.name) / "config.yaml")   # live mode rewrites its own copy
        cls.sim = Sim(marker_offset_mm=(9.0, -6.0))
        cls.device = SimBackedDobot(cls.sim.robot)
        cls.originals = (main_window_module.PROJECT_ROOT, main_window_module.DobotRobot,
                         main_window_module.OrbbecCamera, QMessageBox.question, QMessageBox.information,
                         QMessageBox.warning)
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)

        class ConnectedDobot(DobotRobot):
            def connect(inner):
                inner._device, inner._estopped = cls.device, False

        main_window_module.DobotRobot = ConnectedDobot
        main_window_module.OrbbecCamera = lambda **kwargs: FakeOrbbec(cls.sim.camera)
        QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
        QMessageBox.information = staticmethod(lambda *a, **k: None)
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        config = load_config()
        config["mode"] = "live"
        config["display"] = {}   # default settings, whatever was last picked in Settings
        config["robot"]["workspace_bounds"] = cls.sim.bounds
        config["robot"]["gripper_settle_s"] = 0.05        # the real arm waits ~0.8 s per grip; nobody is watching here
        config["vision"]["known_sizes_mm"] = {"cube": 20.0}   # the demo's cubes (set as Rafi sets it for his cubes)
        cls.window = main_window_module.MainWindow(config)
        cls.window.show()
        cls.panel = cls.window.calibration_tab

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        (main_window_module.PROJECT_ROOT, main_window_module.DobotRobot, main_window_module.OrbbecCamera,
         QMessageBox.question, QMessageBox.information, QMessageBox.warning) = cls.originals
        cls.sim.close()
        cls.folder.cleanup()

    def wait_idle(self):
        pump_until(lambda: self.panel._worker is None)

    def run_checks(self):
        window = self.window
        window._open_system_check()
        pump_until(lambda: window._system_check._worker is None)
        return {r.area: r for r in window._system_check._results}

    def test_a_whole_session_in_live_mode(self):
        window, panel, sim = self.window, self.panel, self.sim
        self.assertTrue(window.robot_connected and window.camera_connected)
        self.assertIsInstance(window.robot, DobotRobot)

        note = lambda text: print(f'  [live test] {text}', flush=True)   # progress lines, so a crash shows where
        note('checking before calibration')
        # before calibrating: the check knows, and says what to do
        checks = self.run_checks()
        self.assertEqual(checks["robot alarms"].status, "ok")
        self.assertEqual(checks["camera cable"].status, "ok")
        self.assertEqual(checks["calibration"].status, FAIL)

        # the driver: pose readable, moves complete, through the real driver code -- after Home, as the app asks once
        # connected (V4.4: a Dobot not homed since it was connected refuses every move, needs_person)
        self.assertIsNotNone(window.robot.needs_person)
        window.robot.home()
        self.assertIsNone(window.robot.needs_person)
        window.robot.move_to(Pose(200, 0, 70))
        self.assertAlmostEqual(window.robot.get_pose().z, 70.0, delta=0.5)

        note('automatic calibration')
        # calibrate automatically, touch the table, verify -- all through the driver
        panel._start_auto()
        self.wait_idle()
        self.assertIn("Automatic calibration done", panel.result_label.text())
        note('table height')
        window.robot.move_to(Pose(170, 0, 0))   # past MIN_RADIUS_MM, the closest the robot will actually go
        panel._set_table_height()
        self.wait_idle()
        self.assertTrue(panel.result_label.text().startswith("Done."), panel.result_label.text())
        note('verify')
        panel._verify()
        self.wait_idle()
        self.assertLess(panel.recorder.verification["typical_mm"], 8.0, panel.result_label.text())
        self.assertTrue((Path(self.folder.name) / "calibration.json").exists(), "live mode saves calibration.json")
        self.assertFalse((Path(self.folder.name) / "calibration_demo.json").exists())

        # afterwards the check has nothing to complain about (Ollama not running is only a warning)
        checks = self.run_checks()
        problems = [f"{r.area}: {r.message}" for r in checks.values() if r.status == FAIL]
        self.assertEqual(problems, [])
        self.assertEqual(checks["table-height step"].status, "ok")

        note('prompt')
        # a prompt drives the same driver: the red cube ends up on the blue one
        window.agent.client = StackingClient()
        window.prompt_panel._send_text("put the red cube on the blue cube")
        pump_until(lambda: not window.prompt_panel.is_busy())
        log = window.prompt_panel.log.toPlainText()
        self.assertNotIn("refused", log, log)
        red, blue = (sim.world.get_object_position_mm(n) for n in ("red_cube", "blue_cube"))
        self.assertLess(math.hypot(red[0] - blue[0], red[1] - blue[1]), 12.0, (red, blue, log))
        self.assertAlmostEqual(red[2] - blue[2], 20.0, delta=1.5, msg="sitting on top of it (20 mm cubes), not beside it")

        note('e-stop')
        # E-STOP during a calibration run: the run ends, nothing changes, and the robot can be reset
        before = window.scene_builder.t_cam_to_robot.copy()
        window.robot.move_to(Pose(200, 0, 70))
        panel._start_auto()
        pump_until(lambda: panel._worker is not None and panel.stop_btn.isEnabled())
        time.sleep(1.0)
        window._on_estop()
        self.wait_idle()
        self.assertGreaterEqual(self.device.stops, 1, "the stop reached the (fake) robot")
        self.assertRegex(panel.result_label.text(), "(?i)stopped")
        self.assertTrue((window.scene_builder.t_cam_to_robot == before).all())
        self.assertAlmostEqual(window.robot.get_pose().z, window.robot.get_pose().z)   # still readable after E-STOP
        window.robot.reset_estop()
        window.robot.move_to(Pose(200, 0, 70))


if __name__ == "__main__":
    unittest.main()

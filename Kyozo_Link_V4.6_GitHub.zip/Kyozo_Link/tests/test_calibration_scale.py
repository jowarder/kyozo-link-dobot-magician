"""The calibration measures the camera's distance scale too: the real camera's distances came out about 10% long, and
no turn and shift alone could fit that (every calibration 15-19 mm off; about 7 mm with the scale).

    python -m unittest discover -s tests -p test_calibration_scale.py -v
"""
from __future__ import annotations

import unittest

import numpy as np

from harness import ROOT  # noqa: F401  (sets up the paths)

from app.calibration.boardless import BoardlessCalibrator
from app.hardware.interfaces import Intrinsics

K = Intrinsics(fx=690.6, fy=690.8, cx=644.4, cy=364.2, width=1280, height=720)
# a camera above and in front of the arm, looking down at the table (robot -> camera)
CAMERA_AT = np.array([520.0, 40.0, 420.0])


def camera_frame():
    forward = np.array([180.0, 0.0, 0.0]) - CAMERA_AT
    forward /= np.linalg.norm(forward)
    right = np.cross(forward, [0.0, 0.0, 1.0])
    right /= np.linalg.norm(right)
    down = np.cross(forward, right)
    return np.stack([right, down, forward])          # rows: the camera's x, y, z in the robot's frame


def sightings(depth_scale: float, noise_px: float = 0.3, seed: int = 1):
    """Where the camera sees points the arm went to (the auto calibration's 3 x 3 sweep at two heights): pixel and
    depth, the depth read `depth_scale` times what it is."""
    rng = np.random.default_rng(seed)
    rot = camera_frame()
    out = []
    for i, (x, y) in enumerate([(133, -202), (200, -202), (267, -68), (200, -68), (167, -47), (267, 67), (200, 67),
                                (200, 202), (133, 202)]):
        z = 150.0 + (30.0 if i % 2 else 0.0)
        p = rot @ (np.array([x, y, z]) - CAMERA_AT)
        u = K.fx * p[0] / p[2] + K.cx + rng.normal(0, noise_px)
        v = K.fy * p[1] / p[2] + K.cy + rng.normal(0, noise_px)
        out.append(((float(x), float(y), z), (u, v), float(p[2] * depth_scale)))
    return out


def solve(depth_scale: float):
    calibrator = BoardlessCalibrator(K)
    for robot, pixel, depth in sightings(depth_scale):
        calibrator.add_sample(robot, pixel, depth)
    return calibrator.solve_detailed()


class ScaleTests(unittest.TestCase):
    def test_distances_read_10_percent_long_are_allowed_for(self):
        result = solve(1.10)
        self.assertAlmostEqual(result.scale, 1 / 1.10, delta=0.01)
        self.assertLess(result.honest_error_mm, 2.0)
        self.assertGreater(result.unscaled_error_mm, 8.0, "a turn and a shift alone can't fit it")

    def test_a_camera_that_reads_true_is_left_alone(self):
        result = solve(1.0)
        self.assertEqual(result.scale, 1.0)
        self.assertIsNone(result.unscaled_error_mm)
        self.assertLess(result.honest_error_mm, 2.0)

    def test_the_transform_carries_the_scale(self):
        result = solve(1.10)
        robot, pixel, depth = sightings(1.10)[4]
        z = depth
        point = np.array([(pixel[0] - K.cx) * z / K.fx, (pixel[1] - K.cy) * z / K.fy, z, 1.0])
        self.assertLess(np.linalg.norm((result.transform @ point)[:3] - robot), 2.0)


if __name__ == "__main__":
    unittest.main()

"""The second robot, the UFACTORY xArm 6 with the xArm Gripper: its model, its twin in the demo, its live driver
(against a stand-in for UFACTORY's SDK, no arm needed), and the app started with it.

    python -m unittest discover -s tests -p test_xarm.py -v
"""
from __future__ import annotations

import math
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: F401,E402  (sets up sys.path and the working folder)
import numpy as np  # noqa: E402

from app import robots  # noqa: E402
from app.hardware.gripper import GripperSpec, plan_grip, tool_parts  # noqa: E402
from app.hardware.interfaces import OutOfReach, Pose, RobotAlarm  # noqa: E402
from app.twin.xarm6 import model  # noqa: E402


class XArmTestCase(unittest.TestCase):
    """Runs with the xArm as the robot, and puts the Dobot back after (the other tests' robot)."""

    def setUp(self):
        self.profile = robots.set_active("xarm6")
        self.addCleanup(robots.set_active, "dobot_magician")


class ModelTests(XArmTestCase):
    def test_the_tool_points_down_where_it_was_asked(self):
        rng = np.random.default_rng(7)
        reached = 0
        for _ in range(400):
            radius, turn = rng.uniform(200, 650), rng.uniform(-math.pi, math.pi)
            x, y, z, yaw = radius * math.cos(turn), radius * math.sin(turn), rng.uniform(0, 400), rng.uniform(-180, 180)
            q = model.solve(x, y, z, yaw)
            if q is None:
                continue
            reached += 1
            frame = model.tool_frame(q)
            np.testing.assert_allclose(frame[:3, 3], (x, y, z), atol=0.05)
            np.testing.assert_allclose(frame[:3, :3], model._down(math.radians(yaw)), atol=1e-4)
            self.assertTrue(model.within_limits(q))
        self.assertGreater(reached, 360, "nearly all of its working space is reachable")

    def test_too_far_is_out_of_reach_and_drawn_stretched_toward_it(self):
        geometry = self.profile.geometry(900.0, 0.0, 50.0)
        self.assertFalse(geometry.reachable)
        self.assertGreater(geometry.tcp[0], 600.0, "stretched out toward the spot")
        self.assertFalse(self.profile.within_limits(900.0, 0.0, 50.0))
        self.assertTrue(self.profile.within_limits(350.0, 0.0, 10.0))

    def test_near_its_base_it_would_come_down_on_itself(self):
        self.assertFalse(self.profile.within_limits(170.0, 0.0, 10.0))
        self.assertTrue(self.profile.within_limits(220.0, 0.0, 10.0))

    def test_six_joints_with_their_limits(self):
        joints = self.profile.joints(self.profile.geometry(350.0, -60.0, 40.0, 30.0), 30.0)
        self.assertEqual(list(joints), ["J1", "J2", "J3", "J4", "J5", "J6"])
        self.assertAlmostEqual(joints["J1"], math.degrees(math.atan2(-60, 350)), places=3)
        for name, angle in joints.items():
            self.assertEqual(self.profile.joint_status(name, angle), "ok", name)

    def test_its_meshes_are_there_and_posed(self):
        geometry = self.profile.geometry(350.0, 0.0, 20.0)
        triangles, colours, tool, normals = self.profile.posed_mesh(geometry, 0.0, gripper_closed=False)
        self.assertEqual(normals.shape, (len(triangles), 3, 3), "each triangle's smoothed corner normals, for the light")
        normals = normals.sum(axis=1)
        normals /= np.linalg.norm(normals, axis=1)[:, None]
        flat = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
        flat /= np.maximum(np.linalg.norm(flat, axis=1), 1e-9)[:, None]
        self.assertGreater(np.median(np.einsum("ij,ij->i", normals, flat)), 0.9, "on the same side as the triangle")
        self.assertEqual(len(triangles), len(colours))
        self.assertTrue(tool.any() and not tool.all())
        fingertips = triangles[tool].reshape(-1, 3)[:, 2].min()
        self.assertAlmostEqual(fingertips, 20.0, delta=3.0, msg="opened 40 mm, the fingertips are at the tool point")
        self.assertEqual(len(self.profile.part_slices()), 14)

    def test_the_gripper_opens_as_its_model_says(self):
        from app.robots.xarm6 import drive_for_gap
        self.assertAlmostEqual(drive_for_gap(88.9), 0.0, places=3)
        self.assertAlmostEqual(drive_for_gap(1.6), 0.85, places=3)
        self.assertLess(drive_for_gap(60.0), drive_for_gap(30.0))


class GripperTests(XArmTestCase):
    def setUp(self):
        super().setUp()
        self.spec = GripperSpec.from_config({"gripper_type": "gripper"}, self.profile.gripper_defaults())

    def test_its_own_size_and_wrist(self):
        self.assertEqual(self.spec.opening_mm, 40.0)
        self.assertFalse(self.spec.wrist_relative)
        fingers = [p for p in tool_parts(self.spec, 300.0, 0.0, 10.0, 0.0) if p.name == "a finger"]
        self.assertEqual([p.size[:2] for p in fingers], [(14.0, 32.0)] * 2)
        self.assertEqual(sorted(p.centre[1] for p in fingers), [-27.0, 27.0])

    def test_a_config_opening_wins(self):
        spec = GripperSpec.from_config({"gripper_type": "gripper", "gripper": {"opening_mm": 60}},
                                       self.profile.gripper_defaults())
        self.assertEqual(spec.opening_mm, 60.0)
        self.assertEqual(spec.shape.finger_width_mm, 32.0, "the rest is still the xArm's")

    def test_the_grip_names_its_wrist_joint(self):
        plan = plan_grip(self.spec, 300.0, 50.0, 20.0, 20.0, (20.0, 20.0, 30.0))
        self.assertIn("J6", plan.note)
        self.assertEqual(plan.depth_mm, 10.0)


class DemoTests(XArmTestCase):
    """The xArm's twin through the robot tools, as a prompt drives it (no LLM)."""

    def setUp(self):
        super().setUp()
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.llm.tools import ToolExecutor
        from app.twin.world import TwinWorld
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        self.world = TwinWorld()
        client = self.world.start()
        self.addCleanup(self.world.stop)
        self.world.load_scenario("two_blocks_and_tray")
        bounds = {axis: list(v) for axis, v in self.profile.demo_bounds.items()}
        spec = GripperSpec.from_config({"gripper_type": "gripper"}, self.profile.gripper_defaults())
        self.robot = SimRobot(client, bounds, max_speed=3000, max_reach_mm=self.profile.max_reach_mm,
                              world=self.world, gripper=spec)
        self.robot.connect()
        camera = SimCamera(client)
        camera.outline_bodies = self.robot.body_ids
        camera.connect()
        look = Pose(*self.profile.demo_look_pose)
        self.robot.move_to(look)
        transform = camera.camera_to_robot_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: self.robot.arm_state()[0],
                                       self.world.places, self.world.place_areas)
        self.executor = ToolExecutor(self.robot, SceneBuilder(camera, detector, transform), look_pose=look,
                                     table_z_provider=lambda: 0.0, places_provider=self.world.places,
                                     place_areas_provider=self.world.place_areas, gripper=spec)

    def positions(self) -> dict:
        return {o["label"]: o["pos"] for o in self.world.snapshot()}

    def ids(self) -> dict:
        listed = eval(self.executor.execute("list_objects", {}))   # noqa: S307 - the tool's own repr of a dict
        return {o["label"]: o["id"] for o in listed["objects"]}

    def test_the_scene_is_set_out_where_the_xarm_reaches(self):
        self.assertAlmostEqual(self.positions()["red cube"][0], 220.0 + 120.0, delta=0.5)
        self.assertEqual(set(self.ids()), {"red cube", "blue cube", "green cube"}, "the camera sees all three")

    def test_all_three_cubes_into_the_tray(self):
        ids = self.ids()
        for label in ("green cube", "red cube", "blue cube"):
            self.executor.execute("pick", {"object_id": ids[label]})
            self.executor.execute("place_at", {"place_name": "tray"})
        tray = self.positions()["tray"]
        for label in ("green cube", "red cube", "blue cube"):
            x, y, _ = self.positions()[label]
            self.assertLess(max(abs(x - tray[0]), abs(y - tray[1])), 36.0, label)

    def test_beside_a_cube_the_closed_fingers_miss_it_on_the_way_down(self):
        ids = self.ids()
        self.executor.execute("pick", {"object_id": ids["green cube"]})
        said = self.executor.execute("place_beside", {"object_id": ids["blue cube"], "side": "left"})
        self.assertIn("left of the blue cube", said)
        blue, green = self.positions()["blue cube"], self.positions()["green cube"]
        self.assertAlmostEqual(green[1] - blue[1], 30.0, delta=2.0)
        self.assertAlmostEqual(blue[2], 10.0, delta=1.0, msg="the blue cube wasn't pushed into")

    def test_after_putting_one_down_it_looks_from_nearby_not_the_far_parking_spot(self):
        """It swung all the way to the parking spot before every look: a long trip between every two cubes."""
        ids = self.ids()
        self.executor.execute("pick", {"object_id": ids["green cube"]})
        self.executor.execute("place_at", {"place_name": "tray"})
        seen = self.ids()                                           # the next look
        here = self.robot.get_pose()
        park = self.profile.demo_look_pose
        self.assertGreater(math.dist((here.x, here.y, here.z), park), 150.0, "not off to the parking spot")
        self.assertEqual(set(seen), {"red cube", "blue cube", "green cube"}, "and the camera still sees all three")

    def test_an_arm_in_front_of_a_cube_counts_as_hiding_it(self):
        self.ids()
        red = self.positions()["red cube"]
        self.assertTrue(self.executor._hides_objects(Pose(red[0], red[1], 40.0)), "right above it")
        self.assertFalse(self.executor._hides_objects(Pose(*self.profile.demo_look_pose)), "parked")

    def test_a_stack(self):
        ids = self.ids()
        self.executor.execute("pick", {"object_id": ids["red cube"]})
        said = self.executor.execute("place_on", {"object_id": ids["blue cube"]})
        self.assertIn("blue cube, red cube", said)
        self.assertAlmostEqual(self.positions()["red cube"][2], 30.0, delta=1.5)


class TurnTests(unittest.TestCase):
    """"Turn the brown block 70 degrees": the AI had no way to ask for a turn. Both robots."""

    def run_robot(self, key: str) -> dict:
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.llm.tools import ToolExecutor
        from app.twin.world import TwinWorld
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        profile = robots.set_active(key)
        self.addCleanup(robots.set_active, "dobot_magician")
        world = TwinWorld()
        client = world.start()
        self.addCleanup(world.stop)
        world.load_scenario("mixed_objects")
        spec = GripperSpec.from_config({"gripper_type": "gripper"}, profile.gripper_defaults())
        robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                         max_reach_mm=profile.max_reach_mm, world=world, gripper=spec)
        robot.connect()
        camera = SimCamera(client)
        camera.outline_bodies = robot.body_ids
        camera.connect()
        look = Pose(*profile.demo_look_pose)
        robot.move_to(look)
        transform = camera.camera_to_robot_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: robot.arm_state()[0], world.places,
                                       world.place_areas)
        executor = ToolExecutor(robot, SceneBuilder(camera, detector, transform), look_pose=look,
                                table_z_provider=lambda: 0.0, places_provider=world.places,
                                place_areas_provider=world.place_areas, gripper=spec)
        ids = {o["label"]: o["id"] for o in eval(executor.execute("list_objects", {}))["objects"]}   # noqa: S307
        block = next(k for k, m in world.object_meta.items() if m["label"] == "brown block")
        before = world.get_object_yaw_deg(block), world.get_object_position_mm(block)
        said = executor.execute("turn_object", {"object_id": ids["brown block"], "turn_deg": 70})
        after = world.get_object_yaw_deg(block), world.get_object_position_mm(block)
        ball = executor.execute("turn_object", {"object_ids": [ids["orange ball"]], "turn_deg": 45})
        cubes = [i for label, i in ids.items() if label.endswith("cube")]
        set_at = executor.execute("turn_object", {"object_ids": cubes, "angle_deg": 45})
        angles = {m["label"]: world.get_object_yaw_deg(k) % 90.0 for k, m in world.object_meta.items()
                  if m["label"].endswith("cube")}
        # held, and turned to match another ("pick the red cube and make its angle like the brown block's")
        ids = {o["label"]: o["id"] for o in eval(executor.execute("list_objects", {}))["objects"]}   # noqa: S307
        cube_label = sorted(label for label in ids if label.endswith("cube"))[0]
        red = next(k for k, m in world.object_meta.items() if m["label"] == cube_label)
        red_at = world.get_object_position_mm(red)
        executor.execute("turn_object", {"object_ids": [ids["brown block"]], "turn_deg": 20})
        executor.execute("list_objects", {})
        executor.execute("pick", {"object_id": ids[cube_label]})
        held = executor.execute("turn_object", {"object_ids": [ids[cube_label]], "like_id": ids["brown block"]})
        like = ((world.get_object_yaw_deg(red) - world.get_object_yaw_deg(block)) % 90.0 + 45.0) % 90.0 - 45.0
        return {"said": said, "turned": (after[0] - before[0] + 90.0) % 180.0 - 90.0,
                "moved": math.dist(after[1][:2], before[1][:2]), "ball": ball, "set_at": set_at, "angles": angles,
                "held": held, "like": like, "red_moved": math.dist(world.get_object_position_mm(red)[:2], red_at[:2]),
                "holding": executor.holding}

    def test_turning_a_block_70_degrees_where_it_stands(self):
        for key in ("dobot_magician", "xarm6"):
            with self.subTest(robot=key):
                result = self.run_robot(key)
                self.assertAlmostEqual(result["turned"], 70.0, delta=2.0, msg=result["said"])
                self.assertLess(result["moved"], 3.0, "back on its own spot")
                self.assertIn("round", result["ball"], "a ball looks the same at any turn")
                for label, angle in result["angles"].items():   # "all the cubes at 45 degrees", in one call
                    self.assertAlmostEqual(angle, 45.0, delta=2.0, msg=f"{label}: {result['set_at']}")
                self.assertIn("put back where it was picked up", result["held"])
                self.assertAlmostEqual(result["like"], 0.0, delta=2.5, msg=result["held"])
                self.assertLess(result["red_moved"], 3.0)
                self.assertIsNone(result["holding"])


class TowerAndBridgeTests(unittest.TestCase):
    """"A tower inside the tray, every cube at 45 degrees" in one call; and a bar laid across a row of cubes."""

    def world_for(self, key: str, scene: str):
        from app.hardware.sim_camera import SimCamera
        from app.hardware.sim_robot import SimRobot
        from app.llm.tools import ToolExecutor
        from app.twin.world import TwinWorld
        from app.vision.depth_detector import DepthObjectDetector
        from app.vision.scene import SceneBuilder
        profile = robots.set_active(key)
        self.addCleanup(robots.set_active, "dobot_magician")
        world = TwinWorld()
        client = world.start()
        self.addCleanup(world.stop)
        world.load_scenario(scene)
        spec = GripperSpec.from_config({"gripper_type": "gripper"}, profile.gripper_defaults())
        robot = SimRobot(client, {a: list(v) for a, v in profile.demo_bounds.items()}, max_speed=3000,
                         max_reach_mm=profile.max_reach_mm, world=world, gripper=spec)
        robot.connect()
        camera = SimCamera(client)
        camera.outline_bodies = robot.body_ids
        camera.connect()
        look = Pose(*profile.demo_look_pose)
        robot.move_to(look)
        transform = camera.camera_to_robot_transform()
        detector = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: robot.arm_state()[0], world.places,
                                       world.place_areas)
        executor = ToolExecutor(robot, SceneBuilder(camera, detector, transform), look_pose=look,
                                table_z_provider=lambda: 0.0, places_provider=world.places,
                                place_areas_provider=world.place_areas, gripper=spec)
        return world, executor

    @staticmethod
    def look(executor) -> dict:
        return {o["label"]: o for o in eval(executor.execute("list_objects", {}))["objects"]}   # noqa: S307

    @staticmethod
    def where(world, label):
        oid = next(k for k, m in world.object_meta.items() if m["label"] == label)
        return world.get_object_position_mm(oid), world.get_object_yaw_deg(oid)

    def test_a_tower_in_the_tray_every_cube_at_45_degrees(self):
        for key in ("dobot_magician", "xarm6"):
            with self.subTest(robot=key):
                world, executor = self.world_for(key, "two_blocks_and_tray")
                seen = self.look(executor)
                said = executor.execute("build_tower", {"object_ids": [seen[k]["id"] for k in
                                                                       ("green cube", "blue cube", "red cube")],
                                                        "place_name": "tray", "angle_deg": 45})
                self.assertIn("bottom to top: green cube, blue cube, red cube", said)
                tray, _ = self.where(world, "tray")
                for n, label in enumerate(("green cube", "blue cube", "red cube")):
                    (x, y, z), yaw = self.where(world, label)
                    self.assertLess(max(abs(x - tray[0]), abs(y - tray[1])), 36.0, f"{label} in the tray")
                    self.assertAlmostEqual(z, 14.0 + 20.0 * n, delta=2.0, msg=f"{label} at level {n + 1}")
                    self.assertAlmostEqual(yaw % 90.0, 45.0, delta=2.0, msg=f"{label} at 45 degrees")

    def test_a_bar_laid_across_a_row_of_cubes(self):
        world, executor = self.world_for("xarm6", "mixed_objects")
        seen = self.look(executor)
        executor.execute("put_all_in", {"place_name": "tray", "object_ids": [seen[k]["id"] for k in
                                                                              ("white cube", "black cube", "green cube")]})
        seen = self.look(executor)
        executor.execute("pick", {"object_id": seen["blue bar"]["id"]})
        said = executor.execute("place_on", {"object_ids": [seen[k]["id"] for k in
                                                            ("white cube", "black cube", "green cube")]})
        self.assertIn("across the white cube, the black cube and the green cube", said)
        (_, _, z), _ = self.where(world, "blue bar")
        self.assertAlmostEqual(z, 4.0 + 20.0 + 5.5, delta=2.0, msg="resting on the cubes' tops")


class PileNameTests(unittest.TestCase):
    """A cylinder with a cube on it was renamed "grey cube" (its edge, seen from above, looked square), and the cube
    on it "black cylinder": a prompt about either lost it."""

    def test_objects_in_a_pile_keep_their_names_and_others_dont(self):
        from app.vision.locator import LocatedObject
        from app.vision.scene import SceneBuilder

        class Detector:
            looks: list = []

            def locate(self, frame, transform):
                return self.looks.pop(0)

        class Camera:
            def get_frame(self):
                return mock.Mock(depth=np.zeros((2, 2)))

        detector = Detector()
        builder = SceneBuilder(Camera(), detector, np.eye(4))
        detector.looks = [[LocatedObject("grey cylinder", (300, 0, 36), 1.0), LocatedObject("black cube", (250, 50, 24), 1.0),
                           LocatedObject("red cube", (200, -80, 24), 1.0)],
                          [LocatedObject("grey cube", (300, 0, 36), 1.0), LocatedObject("black cylinder", (301, 1, 56), 1.0),
                           LocatedObject("red ball", (200, -80, 24), 1.0)]]
        first = {o.label: o.id for o in builder.get_scene()}
        builder.note_moved(first["black cube"], (301.0, 1.0, 56.0))       # the robot put it on the cylinder
        second = {o.id: o.label for o in builder.get_scene()}
        self.assertEqual(second[first["grey cylinder"]], "grey cylinder", "under the cube: its name kept")
        self.assertEqual(second[first["black cube"]], "black cube", "on the cylinder: its name kept")
        self.assertEqual(second[first["red cube"]], "red ball", "on its own: as seen now")


class FakeArm:
    """Stands in for xarm.wrapper.XArmAPI: records what it is told."""

    def __init__(self, ip, is_radian=False, do_not_open=False):
        self.ip, self.connected, self.error_code, self.calls = ip, False, 0, []
        self.position = [300.0, 0.0, 200.0, 180.0, 0.0, 0.0]
        self.next_error = 0

    def __getattr__(self, name):
        def record(*args, **kwargs):
            self.calls.append((name, args, kwargs))
            return 0
        return record

    def connect(self):
        self.connected = True

    def get_position(self, is_radian=False):
        return 0, list(self.position)

    def get_servo_angle(self, is_radian=False):
        return 0, [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 0.0]

    def set_position(self, **kwargs):
        self.calls.append(("set_position", (), kwargs))
        if self.next_error:
            self.error_code, self.next_error = self.next_error, 0
            return 1
        self.position = [kwargs["x"], kwargs["y"], kwargs["z"], kwargs["roll"], kwargs["pitch"], kwargs["yaw"]]
        return 0

    def clean_error(self):
        self.calls.append(("clean_error", (), {}))
        self.error_code = 0
        return 0


class LiveDriverTests(unittest.TestCase):
    def make(self, **kwargs):
        from app.hardware import xarm
        self.fakes = []

        def build(*args, **kw):
            arm = FakeArm(*args, **kw)
            self.fakes.append(arm)
            return arm
        patcher = mock.patch.object(xarm, "XArmAPI", build)
        patcher.start()
        self.addCleanup(patcher.stop)
        robot = xarm.XArmRobot("192.168.1.185", {"x": [-500, 650], "y": [-550, 550], "z": [0, 550]}, **kwargs)
        robot.connect()
        return robot, self.fakes[0]

    def test_it_needs_an_address(self):
        from app.hardware import xarm
        with mock.patch.object(xarm, "XArmAPI", FakeArm):
            with self.assertRaises(ValueError):
                xarm.XArmRobot("", {"x": [0, 1], "y": [0, 1], "z": [0, 1]})

    def test_connecting_gets_it_ready_with_the_grippers_tool_point(self):
        robot, arm = self.make(collision_sensitivity=4)
        names = [c[0] for c in arm.calls]
        for step in ("clean_error", "motion_enable", "set_mode", "set_state", "set_tcp_offset",
                     "set_collision_sensitivity", "set_gripper_enable"):
            self.assertIn(step, names)
        offset = next(c for c in arm.calls if c[0] == "set_tcp_offset")[1][0]
        self.assertEqual(offset[2], 172.0)

    def test_a_pose_is_the_tool_pointing_down_turned_by_r(self):
        robot, arm = self.make()
        robot.move_to(Pose(350.0, -40.0, 30.0, 200.0), speed=1000.0)
        sent = [c for c in arm.calls if c[0] == "set_position"][-1][2]
        self.assertEqual((sent["roll"], sent["pitch"]), (180.0, 0.0))
        self.assertAlmostEqual(sent["yaw"], -160.0)
        self.assertLessEqual(sent["speed"], 250.0, "never faster than the cap")
        self.assertTrue(sent["wait"])
        self.assertEqual(robot.get_pose(), Pose(350.0, -40.0, 30.0, -160.0))
        self.assertEqual(robot.get_joints(), (1.0, 2.0, 3.0, 4.0, 5.0, 6.0))

    def test_it_is_kept_out_of_its_base_and_inside_the_box(self):
        robot, arm = self.make()
        robot.move_to(Pose(100.0, 0.0, -50.0, 0.0))
        sent = [c for c in arm.calls if c[0] == "set_position"][-1][2]
        self.assertAlmostEqual(math.hypot(sent["x"], sent["y"]), 200.0)
        self.assertEqual(sent["z"], 0.0)

    def test_out_of_reach_is_said_and_cleared(self):
        robot, arm = self.make()
        arm.next_error = 23
        with self.assertRaises(OutOfReach):
            robot.move_to(Pose(400.0, 0.0, 100.0))
        self.assertEqual(arm.error_code, 0, "cleared, so it can be sent elsewhere")

    def test_a_collision_stops_it(self):
        robot, arm = self.make()
        arm.next_error = 31
        with self.assertRaises(RobotAlarm) as raised:
            robot.move_to(Pose(400.0, 0.0, 100.0))
        self.assertIn("collision", str(raised.exception))

    def test_the_gripper_opens_to_its_setting_and_closes(self):
        robot, arm = self.make(opening_mm=43.0)
        robot.open_gripper()
        robot.close_gripper()
        positions = [c[1][0] for c in arm.calls if c[0] == "set_gripper_position"]
        self.assertAlmostEqual(positions[0], 425.0)
        self.assertEqual(positions[1], 0)

    def test_e_stop_stops_and_lets_go(self):
        from app.hardware.interfaces import RobotStopped
        robot, arm = self.make()
        robot.stop()
        self.assertIn(("set_state", (4,), {}), arm.calls)
        self.assertIn("set_gripper_position", [c[0] for c in arm.calls])
        with self.assertRaises(RobotStopped):
            robot.move_to(Pose(300.0, 0.0, 100.0))
        robot.reset_estop()
        robot.move_to(Pose(300.0, 0.0, 100.0))


class AppTests(unittest.TestCase):
    def test_the_app_starts_with_the_xarm_and_keeps_its_files_apart(self):
        from PyQt6.QtWidgets import QApplication
        from app.config import load_config
        from app.hardware.sim_robot import SimRobot
        from app.ui import main_window as main_window_module
        app = QApplication.instance() or QApplication([])   # noqa: F841
        self.addCleanup(robots.set_active, "dobot_magician")
        with tempfile.TemporaryDirectory() as folder:
            original = main_window_module.PROJECT_ROOT
            main_window_module.PROJECT_ROOT = Path(folder)
            try:
                config = load_config()
                config.update(mode="demo", robot_model="xarm6", display={})
                config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
                window = main_window_module.MainWindow(config)
                try:
                    self.assertIn("UFACTORY xArm 6", window.windowTitle())
                    self.assertTrue(window.windowTitle().startswith("Kyozo Link V"))
                    self.assertIsInstance(window.robot, SimRobot)
                    self.assertEqual(window.robot_selector.currentData(), "xarm6")
                    self.assertEqual(window._calibration_path().name, "calibration_demo_xarm6.json")
                    self.assertEqual(window._poses_dir().name, "poses_demo_xarm6")
                    self.assertEqual(window.tool_executor.gripper.wrist_name, "J6")
                    self.assertEqual(window.config["robot"]["max_reach_mm"], 650.0, "the xArm's own settings")
                    geometry = window._arm_geometry()
                    self.assertTrue(geometry.reachable)
                    self.assertEqual(len(getattr(geometry, "joints", ())), 6)
                finally:
                    window.jog_panel.stop_pose_monitor()
                    window.close()
                    window._twin_world.stop()
            finally:
                main_window_module.PROJECT_ROOT = original
        self.assertEqual(robots.set_active("dobot_magician").key, "dobot_magician")

    def test_live_without_an_address_says_so(self):
        from PyQt6.QtWidgets import QApplication
        from app.config import load_config
        from app.hardware.unavailable import UnavailableRobot
        from app.ui import main_window as main_window_module
        app = QApplication.instance() or QApplication([])   # noqa: F841
        self.addCleanup(robots.set_active, "dobot_magician")
        with tempfile.TemporaryDirectory() as folder:
            original = main_window_module.PROJECT_ROOT
            main_window_module.PROJECT_ROOT = Path(folder)
            try:
                config = load_config()
                config.update(mode="live", robot_model="xarm6", display={})
                config.pop("xarm6", None)
                with mock.patch.object(main_window_module, "OrbbecCamera", side_effect=RuntimeError("no camera")):
                    window = main_window_module.MainWindow(config)
                try:
                    self.assertIsInstance(window.robot, UnavailableRobot)
                    self.assertIn("IP address", window.robot.reason)
                finally:
                    window.jog_panel.stop_pose_monitor()
                    window.close()
            finally:
                main_window_module.PROJECT_ROOT = original


class StartupChooserTests(unittest.TestCase):
    """The window at start-up: which robot, demo or live, the last choice already picked."""

    def setUp(self):
        from PyQt6.QtWidgets import QApplication
        self.app = QApplication.instance() or QApplication([])

    def chooser(self, config, mode=None):
        from app.ui.robot_chooser import RobotChooser
        dialog = RobotChooser(config, mode=mode)
        self.addCleanup(dialog.deleteLater)
        return dialog

    def test_the_last_choice_is_already_picked(self):
        self.assertEqual(self.chooser({"robot_model": "xarm6", "mode": "live"}).choice(), ("xarm6", "live"))
        self.assertEqual(self.chooser({}).windowTitle(), "Kyozo Link")
        self.assertEqual(self.chooser({"mode": "live"}).choice(), ("dobot_magician", "live"))
        self.assertEqual(self.chooser({"mode": "live"}, mode="demo").choice(), ("dobot_magician", "demo"),
                         "the demo shortcut's --mode demo picks demo")

    def test_it_says_what_start_will_do(self):
        dialog = self.chooser({"robot_model": "xarm6", "mode": "live", "xarm6": {"ip": ""}})
        self.assertIn("No address", dialog.summary.text())
        dialog.robot_buttons["dobot_magician"].click()
        dialog.mode_buttons["demo"].click()
        self.assertEqual(dialog.choice(), ("dobot_magician", "demo"))
        self.assertIn("3D twin", dialog.summary.text())

    def test_the_choice_is_remembered_for_next_time(self):
        import yaml
        from app import main as main_module
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "config.yaml"
            path.write_text(yaml.safe_dump({"mode": "demo", "robot": {"port": "COM4"}}), encoding="utf-8")
            config = {"mode": "demo"}
            with mock.patch.object(main_module, "CONFIG_PATH", path):
                main_module.remember_choice(config, "xarm6", "live")
            saved = yaml.safe_load(path.read_text(encoding="utf-8"))
            self.assertEqual((saved["robot_model"], saved["mode"]), ("xarm6", "live"))
            self.assertEqual(saved["robot"], {"port": "COM4"}, "the Dobot's settings left as they were")
            self.assertIn("ip", saved["xarm6"])
            self.assertEqual((config["robot_model"], config["mode"]), ("xarm6", "live"))


if __name__ == "__main__":
    unittest.main()

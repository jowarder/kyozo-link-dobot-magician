"""Damaged or half-written files must never stop the app from starting or make it lose good data.

    python -m unittest discover -s tests -p test_files.py -v
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: F401,E402  (sets up sys.path and the working folder)
import numpy as np  # noqa: E402

from app import fileutil  # noqa: E402
from app.calibration.storage import load_calibration, save_calibration  # noqa: E402
from app.hardware.interfaces import Intrinsics  # noqa: E402
from app.llm.tools import ToolExecutor  # noqa: E402
from app.vision.drift import ViewReference  # noqa: E402

INTRINSICS = Intrinsics(fx=690.0, fy=690.0, cx=640.0, cy=360.0, width=1280, height=720)


class CalibrationFileTests(unittest.TestCase):
    def test_a_saved_calibration_reads_back(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "calibration.json"
            transform = np.eye(4)
            transform[:3, 3] = (10.0, 20.0, 30.0)
            save_calibration(path, transform, INTRINSICS, "marker+table", 1.5, 11)
            loaded = load_calibration(path)
            np.testing.assert_allclose(loaded.transform_matrix(), transform)
            self.assertEqual(loaded.method, "marker+table")

    def test_a_damaged_calibration_is_set_aside_and_the_app_starts_uncalibrated(self):
        damaged = {"half written": '{"t_cam_to_robot": [[1, 0, 0, ', "empty": "", "wrong keys": json.dumps({"a": 1}),
                   "not text": "\x00\x01\x02",
                   "not a transform": json.dumps({"t_cam_to_robot": [[1, 2]], "intrinsics": {}, "method": "x",
                                                  "reprojection_error_mm": 1.0, "num_samples": 3})}
        for name, text in damaged.items():
            with self.subTest(name), tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / "calibration.json"
                path.write_text(text, encoding="utf-8")
                self.assertIsNone(load_calibration(path))
                self.assertFalse(path.exists())
                self.assertTrue((Path(folder) / "calibration.json.bad").exists(), "kept for a look")

    def test_no_file_means_no_calibration(self):
        with tempfile.TemporaryDirectory() as folder:
            self.assertIsNone(load_calibration(Path(folder) / "calibration.json"))


class AtomicWriteTests(unittest.TestCase):
    def test_a_failed_save_leaves_the_old_file_untouched_and_no_debris(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "config.yaml"
            path.write_text("the good version", encoding="utf-8")
            with mock.patch.object(fileutil.os, "replace", side_effect=OSError("power cut")):
                with self.assertRaises(OSError):
                    fileutil.atomic_write_text(path, "the new version")
            self.assertEqual(path.read_text(encoding="utf-8"), "the good version")
            self.assertEqual([p.name for p in Path(folder).iterdir()], ["config.yaml"], "no temporary file left")

    def test_a_good_save_replaces_the_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "sub" / "x.json"
            fileutil.atomic_write_text(path, "one")
            fileutil.atomic_write_text(path, "two")
            self.assertEqual(path.read_text(encoding="utf-8"), "two")


class OtherFileTests(unittest.TestCase):
    def test_a_damaged_camera_reference_is_ignored(self):
        for name, blob in (("empty", b""), ("garbage", b"not an archive"), ("truncated", b"PK\x03\x04truncated")):
            with self.subTest(name), tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / "calibration.reference.npz"
                path.write_bytes(blob)
                self.assertIsNone(ViewReference.load(path))

    def test_a_reference_survives_a_round_trip(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "r.npz"
            ViewReference(np.zeros((360, 640), np.uint8), -12.5, 0.4, "now").save(path)
            loaded = ViewReference.load(path)
            self.assertEqual((loaded.table_z_mm, loaded.table_tilt_deg), (-12.5, 0.4))

    def test_one_damaged_saved_place_does_not_break_the_others(self):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder) / "tray.json").write_text('{"x": 280, "y": 0, "z"', encoding="utf-8")
            (Path(folder) / "shelf.json").write_text(json.dumps({"x": 1, "y": 2, "z": 3, "r": 0}), encoding="utf-8")
            (Path(folder) / "nonsense.json").write_text(json.dumps({"hello": 1}), encoding="utf-8")
            executor = ToolExecutor.__new__(ToolExecutor)
            executor.poses_dir = Path(folder)
            self.assertEqual(sorted(executor._saved_places()), ["shelf"])


class StartupTests(unittest.TestCase):
    def test_the_app_starts_with_a_damaged_calibration_file(self):
        from PyQt6.QtWidgets import QApplication
        from app.config import load_config
        from app.ui import main_window as main_window_module
        app = QApplication.instance() or QApplication([])   # noqa: F841
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder) / "calibration_demo.json").write_text('{"t_cam_to_robot": [[1, 0', encoding="utf-8")
            (Path(folder) / "calibration_demo.reference.npz").write_bytes(b"")
            original = main_window_module.PROJECT_ROOT
            main_window_module.PROJECT_ROOT = Path(folder)
            try:
                config = load_config()
                config["mode"] = "demo"
                config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"   # the tests' scene, not the one last picked in Settings
                config["display"] = {}   # default look and prompts (not step-by-step), whatever was last picked in Settings
                window = main_window_module.MainWindow(config)
                self.assertTrue(window._calibrated, "demo falls back to the simulator's exact calibration")
                window.jog_panel.stop_pose_monitor()
                window.close()
                window._twin_world.stop()
            finally:
                main_window_module.PROJECT_ROOT = original


if __name__ == "__main__":
    unittest.main()

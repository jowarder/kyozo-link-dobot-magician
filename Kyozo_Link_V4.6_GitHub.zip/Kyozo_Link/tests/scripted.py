"""A stand-in for Ollama that behaves like a sensible model, so prompts can be tested without one."""
from __future__ import annotations

import ast


def _call(name: str, arguments: dict) -> dict:
    return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": arguments}}]}


class StackingClient:
    """Looks at the table, picks up one object, puts it on another, then says it is done. It reads the
    object ids out of what the tools reported, as a real model would."""

    def __init__(self, pick: str = "red cube", onto: str = "blue cube"):
        self.pick, self.onto = pick, onto

    def chat(self, model, messages, tools=None, temperature=0.2):
        results = [m["content"] for m in messages if m["role"] == "tool"]
        if not results:
            return _call("list_objects", {})
        if results[-1].startswith("ERROR"):
            return {"role": "assistant", "content": f"I could not do that: {results[-1]}"}
        if len(results) == 1:
            objects = ast.literal_eval(results[0])["objects"]
            wanted = next(o for o in objects if o["label"] == self.pick)
            return _call("pick", {"object_id": wanted["id"]})
        if len(results) == 2:
            objects = ast.literal_eval(results[0])["objects"]
            target = next(o for o in objects if o["label"] == self.onto)
            return _call("place_on", {"object_id": target["id"]})
        return {"role": "assistant", "content": "Done."}


class PickThenPutFreeClient:
    """Picks up one object (whatever is on it is the tool's business), then puts it down on free table space."""

    def __init__(self, pick: str = "red cube", where: str = "near_base"):
        self.pick, self.where = pick, where

    def chat(self, model, messages, tools=None, temperature=0.2):
        results = [m["content"] for m in messages if m["role"] == "tool"]
        if not results:
            return _call("list_objects", {})
        if results[-1].startswith("ERROR"):
            return {"role": "assistant", "content": f"I could not do that: {results[-1]}"}
        if len(results) == 1:
            wanted = next(o for o in ast.literal_eval(results[0])["objects"] if o["label"] == self.pick)
            return _call("pick", {"object_id": wanted["id"]})
        if len(results) == 2:
            return _call("place_free", {"where": self.where})
        return {"role": "assistant", "content": "Done."}


class BesideClient:
    """Picks up one object and puts it beside another at a given side and gap."""

    def __init__(self, pick: str = "red cube", beside: str = "blue cube", side: str = "right", gap_mm: float = 10.0):
        self.pick, self.beside, self.side, self.gap_mm = pick, beside, side, gap_mm

    def chat(self, model, messages, tools=None, temperature=0.2):
        results = [m["content"] for m in messages if m["role"] == "tool"]
        if not results:
            return _call("list_objects", {})
        if results[-1].startswith("ERROR"):
            return {"role": "assistant", "content": f"I could not do that: {results[-1]}"}
        objects = ast.literal_eval(results[0])["objects"]
        if len(results) == 1:
            return _call("pick", {"object_id": next(o["id"] for o in objects if o["label"] == self.pick)})
        if len(results) == 2:
            target = next(o["id"] for o in objects if o["label"] == self.beside)
            return _call("place_beside", {"object_id": target, "side": self.side, "gap_mm": self.gap_mm})
        return {"role": "assistant", "content": "Done."}


class PutInPlaceClient:
    """Picks up one object and puts it at a saved place by name (the watcher study's "Put the red cube in zone A")."""

    def __init__(self, pick: str = "red cube", place: str = "zone a"):
        self.pick, self.place = pick, place

    def chat(self, model, messages, tools=None, temperature=0.2):
        results = [m["content"] for m in messages if m["role"] == "tool"]
        if not results:
            return _call("list_objects", {})
        if results[-1].startswith("ERROR"):
            return {"role": "assistant", "content": f"I could not do that: {results[-1]}"}
        if len(results) == 1:
            wanted = next(o for o in ast.literal_eval(results[0])["objects"] if o["label"] == self.pick)
            return _call("pick", {"object_id": wanted["id"]})
        if len(results) == 2:
            return _call("place_at", {"place_name": self.place})
        return {"role": "assistant", "content": "Done."}

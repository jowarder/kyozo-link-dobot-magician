"""The Detection window's settings: any object or coloured cubes only, and what is left out against phantom objects
(lower than, smaller than, not steady, outside the pick area).

    python -m unittest discover -s tests -p test_detection_settings.py -v

Demo mode only; config.yaml is not changed (the window's saving is checked on a copy).
"""
from __future__ import annotations

import os
import unittest

from harness import LOOK_POSE, Sim

from app.hardware.gripper import GripperSpec
from app.vision.depth_detector import DepthObjectDetector
from app.vision.detection_settings import FIND_ANY, FIND_CUBES, DetectionSettings, SwitchingDetector
from app.vision.detector import build_detector, with_demo_colors
from app.vision.locator import LocatedObject
from app.vision.scene import SceneBuilder

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PyQt6.QtWidgets import QApplication  # noqa: E402

APP = QApplication.instance() or QApplication([])      # one for the whole module: the window lives in it


class Setup(unittest.TestCase):
    def setUp(self):
        self.sim = Sim(gripper=GripperSpec())
        self.addCleanup(self.sim.close)
        self.sim.robot.move_to(LOOK_POSE)
        self.world = self.sim.world
        transform = self.sim.exact_transform()
        self.settings = DetectionSettings()
        depth = DepthObjectDetector(lambda: transform, lambda: 0.0, lambda: self.sim.robot.arm_state()[0],
                                    self.world.places, self.world.place_areas, settings=self.settings)
        colour = build_detector(with_demo_colors(dict(self.sim.config["vision"], detector="color_blob")))
        self.detector = SwitchingDetector(self.settings, depth, colour, lambda: transform)
        self.scene = SceneBuilder(self.sim.camera, self.detector, transform)

    def seen(self) -> list[str]:
        self.scene.reset_tracking()
        return sorted(o.label for o in self.scene.get_scene())


class FindingTests(Setup):
    def test_any_object_or_coloured_cubes_only(self):
        self.world.switch_scenario("mixed_objects")
        self.assertEqual(len(self.seen()), 7, "any object: all seven, whatever their colour")
        self.settings.update(find=FIND_CUBES)
        self.assertNotIn("white cube", self.seen(), "coloured only: the white and black cubes aren't colours")
        self.world.switch_scenario("tower_building")
        self.assertEqual(self.seen(), ["blue cube", "green cube", "purple cube", "red cube", "yellow cube"])
        self.settings.update(find=FIND_ANY)
        self.assertEqual(len(self.seen()), 5)

    def test_only_inside_the_pick_area(self):
        self.world.switch_scenario("two_blocks_and_tray")          # red at y -60, blue at y +60
        self.settings.update(pick_area={"x": [150.0, 300.0], "y": [-120.0, 0.0]})
        self.assertEqual(self.seen(), ["red cube"])
        self.settings.update(find=FIND_CUBES)
        self.assertEqual(self.seen(), ["red cube"], "for the colour detector too")
        self.settings.update(pick_area=None)
        self.assertEqual(self.seen(), ["blue cube", "green cube", "red cube"])

    def test_lower_or_smaller_than_set_is_left_out(self):
        self.world.switch_scenario("size_sorting")                 # 15 and 20 mm cubes
        self.settings.update(min_size_mm=17.0)
        self.assertEqual(self.seen(), ["blue cube", "yellow cube"], "the 15 mm ones are smaller than that")
        self.settings.update(min_size_mm=8.0, min_height_mm=17.0)
        self.assertEqual(self.seen(), ["blue cube", "yellow cube"], "and lower than that")

    def test_the_camera_feed_and_the_scene_see_the_same(self):
        self.world.switch_scenario("two_blocks_and_tray")
        self.settings.update(pick_area={"x": [150.0, 300.0], "y": [0.0, 120.0]})
        frame = self.sim.camera.get_frame()
        self.assertEqual([d.label for d in self.detector.detect(frame.rgb, frame.depth, frame.intrinsics)],
                         ["blue cube"])


class SteadyTests(unittest.TestCase):
    def test_only_what_is_seen_again_counts(self):
        class Flickering:
            """A thing there in one picture and gone in the next: depth noise."""
            settings = DetectionSettings(steady_looks=2)
            looks = [[LocatedObject("red cube", (200.0, 0.0, 20.0), 1.0, (20, 20, 0)),
                      LocatedObject("grey ball", (250.0, 50.0, 8.0), 1.0, (9, 9, 0))],
                     [LocatedObject("red cube", (201.0, 1.0, 20.0), 1.0, (20, 20, 0))]]

            def locate(self, frame, transform):
                return self.looks.pop(0)

        class Camera:
            def get_frame(self):
                return type("Frame", (), {"depth": object()})()
        scene = SceneBuilder(Camera(), Flickering(), None)
        self.assertEqual([o.label for o in scene.get_scene()], ["red cube"])


class WindowTests(unittest.TestCase):
    def test_the_window_changes_the_settings_and_they_go_into_config(self):
        from app.ui.detection_dialog import DetectionDialog
        settings = DetectionSettings()
        calls = []
        settings.changed.append(lambda: calls.append(1))
        dialog = DetectionDialog(settings)
        self.addCleanup(dialog.deleteLater)
        dialog.cubes_btn.setChecked(True)
        dialog.min_size.setValue(12.0)
        dialog.steady.setValue(2)
        dialog.area_on.setChecked(True)
        dialog.x_low.setValue(160.0)
        self.assertEqual((settings.find, settings.min_size_mm, settings.steady_looks), (FIND_CUBES, 12.0, 2))
        self.assertEqual(settings.pick_area["x"], [160.0, 300.0])
        self.assertFalse(dialog.min_height.isEnabled(), "height is for the depth camera only")
        self.assertTrue(calls)
        config = settings.to_config()
        self.assertEqual(config["detector"], "color_blob")
        again = DetectionSettings.from_config(config)
        self.assertEqual((again.find, again.min_size_mm, again.steady_looks, again.pick_area),
                         (settings.find, settings.min_size_mm, settings.steady_looks, settings.pick_area))
        dialog._defaults()
        self.assertEqual((settings.find, settings.pick_area, settings.min_size_mm), (FIND_ANY, None, 8.0))

    def _exposure_dialog(self, locked: bool = False):
        from unittest import mock
        from PyQt6.QtWidgets import QMessageBox
        from app.hardware.sim_camera import SimCamera
        from app.ui.detection_dialog import DetectionDialog, ExposureHooks
        camera = SimCamera.__new__(SimCamera)          # (only its picture settings: no simulated world needed)
        camera._controls = {"exposure_auto": True, "exposure": 140, "gain": 0, "white_balance_auto": True,
                            "white_balance": 4600, "projector_power": 4, "anti_flicker": 0}
        saved = []
        hooks = ExposureHooks(camera=camera, save=saved.append, locked=lambda: locked)
        questions = mock.patch("app.ui.detection_dialog.QMessageBox.question",
                               return_value=QMessageBox.StandardButton.Yes)
        questions.start()
        self.addCleanup(questions.stop)
        dialog = DetectionDialog(DetectionSettings(), exposure=hooks)
        self.addCleanup(dialog.deleteLater)
        return dialog, camera, saved

    def test_choosing_coloured_cubes_offers_to_fix_the_exposure(self):
        dialog, camera, saved = self._exposure_dialog()
        self.assertFalse(dialog.exposure_box.isHidden())
        self.assertTrue(dialog.exposure_auto.isChecked())
        self.assertFalse(dialog.exposure_value.isEnabled(), "the camera chooses while automatic")
        dialog.cubes_btn.setChecked(True)                  # (the question answered Yes)
        self.assertFalse(camera._controls["exposure_auto"])
        self.assertEqual(camera._controls["exposure"], 140, "fixed where it was")
        self.assertTrue(dialog.exposure_value.isEnabled())
        self.assertEqual(saved[-1]["exposure_auto"], False)
        self.assertEqual(saved[-1]["exposure"], 140)
        dialog.exposure_value.setValue(90)                 # darker: the colours stronger
        self.assertEqual(camera._controls["exposure"], 90)
        self.assertEqual(saved[-1]["exposure"], 90)
        dialog.exposure_auto.setChecked(True)              # back to automatic
        self.assertTrue(camera._controls["exposure_auto"])
        self.assertNotIn("exposure", saved[-1], "a manual value isn't kept while automatic chooses")

    def test_the_exposure_isnt_changed_while_locked_for_the_study(self):
        dialog, camera, saved = self._exposure_dialog(locked=True)
        dialog.cubes_btn.setChecked(True)
        self.assertTrue(camera._controls["exposure_auto"])
        self.assertFalse(dialog.exposure_auto.isEnabled())
        self.assertIn("Locked", dialog.exposure_note.text())
        self.assertEqual(saved, [])


if __name__ == "__main__":
    unittest.main()

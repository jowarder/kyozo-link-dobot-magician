"""The Model tab: the record of each prompt (every model turn, what the app did, every move and joint) and the page.

    python -m unittest discover -s tests -p test_model_tab.py -v

Demo mode with a scripted stand-in for the model; the real driver against the fake Dobot; nothing in the project
changes (logs go to temporary folders).
"""
from __future__ import annotations

import ast
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT, Sim  # noqa: E402
from PyQt6.QtCore import Qt  # noqa: E402
from PyQt6.QtWidgets import QApplication, QMessageBox  # noqa: E402

from app.config import load_config  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from app.llm import ollama_client as ollama_module  # noqa: E402
from app.llm.agent import Agent  # noqa: E402
from app.llm.recording import MoveRecorder  # noqa: E402
from app.llm.tools import ToolExecutor  # noqa: E402
from app.llm.trace import match_phrase, understand  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402
from app.ui.model_tab import ModelTab, problems, render  # noqa: E402
from app.vision.detector import build_detector, with_demo_colors  # noqa: E402
from app.vision.scene import SceneBuilder  # noqa: E402

app = QApplication.instance() or QApplication([])
LOOK = Pose(120.0, -160.0, 90.0)


def call(name, args):
    return {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args}}]}


class Scripted:
    """Plays back model answers; each is a function of the tool results so far (ids are read from them)."""

    def __init__(self, *answers):
        self.answers = list(answers)
        self.last_stats = {"tokens_read": 2900, "tokens_written": 20, "read_s": 2.0, "write_s": 0.8, "load_s": 0.0,
                           "total_s": 3.0, "stop_reason": "stop"}

    def chat(self, model, messages, tools=None, temperature=0.2):
        results = [m["content"] for m in messages if m["role"] == "tool"]
        # the last answer again if asked again (the app sends a "done" that isn't back once: the same reply then)
        return (self.answers.pop(0) if len(self.answers) > 1 else self.answers[0])(results)


def ids(results):
    return {o["label"]: o["id"] for o in ast.literal_eval(results[0])["objects"]}


class ReadingTests(unittest.TestCase):
    def test_how_prompts_are_read(self):
        self.assertEqual(understand("put the blue box inside the tray")["task"], "put into a place")
        self.assertEqual(understand("put the red cube on the blue cube")["task"], "stack on another object")
        self.assertEqual(understand("put the red cube to the right of the blue cube")["task"], "put beside another object")
        self.assertEqual(understand("build a tower using all these cubes")["task"], "build a tower")
        self.assertEqual(understand("Take the blue cube off the tower and put it to the left of the tower")["task"],
                         "take off a pile", "S-18: a cube taken off, no tower to build")
        self.assertEqual(understand("what do you see?")["task"], "look at the table")
        reading = understand("put the blue box inside the tray")
        self.assertEqual((reading["object"], reading["destination"]), ("blue box", "tray"))
        self.assertTrue(understand("pick the blue colored box inside the tray")["notes"], "flagged as ambiguous")

    def test_words_are_matched_to_the_table_and_guesses_are_flagged(self):
        objects = [{"id": "obj_1", "label": "red cube"}, {"id": "obj_2", "label": "blue cube"}]
        blue = match_phrase("blue box", objects, ["tray"], "object")
        self.assertEqual(blue["best"], "blue cube (obj_2)")
        self.assertTrue(blue["guess"])
        red = match_phrase("red cube", objects, ["tray"], "object")
        self.assertFalse(red["guess"])
        tray = match_phrase("tray", objects, ["tray"], "destination")
        self.assertEqual((tray["best"], tray["guess"]), ("tray", False))


class RecordTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim()
        self.sim.robot.max_speed = 3000
        self.addCleanup(self.sim.close)
        detector = build_detector(with_demo_colors(self.sim.config["vision"]))
        self.executor = ToolExecutor(self.sim.robot, SceneBuilder(self.sim.camera, detector, self.sim.exact_transform()),
                                     look_pose=LOOK, table_z_provider=lambda: 0.0, places_provider=self.sim.world.places)

    def run_agent(self, prompt, *answers, max_steps=12):
        seen = []
        # (the model's own turns, as V4.2 had them: the app's look first is tested in AppLooksFirstTests)
        run = Agent(Scripted(*answers), self.executor, "qwen3:8b", max_tool_calls=max_steps, look_first=False).run(
            prompt, on_trace=seen.append)
        return run.trace, seen

    def test_a_reply_claiming_what_was_not_done_is_caught(self):
        """The tower was built beside the tray with nothing turned, and the reply said "a tower inside the tray,
        oriented at 45 degrees"."""
        from app.ui.prompt_panel import goal_mismatch
        prompt = "make tower inside the tray using all the cubes, place all the cubes 45 degree"
        claim = "All the cubes are now in a tower inside the tray, oriented at 45 degrees as requested."
        trace, _ = self.run_agent(
            prompt,
            lambda r: call("list_objects", {}),
            lambda r: call("pick", {"object_id": ids(r)["blue cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["green cube"]}),
            lambda r: call("pick", {"object_id": ids(r)["red cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["blue cube"]}),
            lambda r: {"role": "assistant", "content": claim})
        goal = trace["end"]["goal"]
        self.assertEqual(goal["status"], "not met", goal)
        self.assertIn("not in the tray", goal["detail"])
        self.assertIn("nothing was turned", goal["detail"])
        self.assertIn("not in the tray", goal_mismatch(claim, trace))
        self.assertEqual(goal_mismatch("I could only build it beside the tray.", trace), "", "it says so itself")

    def test_the_same_tower_built_with_build_tower_is_met(self):
        trace, _ = self.run_agent(
            "make tower inside the tray using all the cubes, place all the cubes 45 degree",
            lambda r: call("list_objects", {}),
            lambda r: call("build_tower", {"object_ids": [ids(r)[k] for k in ("green cube", "blue cube", "red cube")],
                                           "place_name": "tray", "angle_deg": 45}),
            lambda r: {"role": "assistant", "content": "Built the tower in the tray, each cube at 45 degrees."})
        goal = trace["end"]["goal"]
        self.assertEqual(goal["status"], "met", goal)

    def test_a_whole_prompt_is_recorded_turn_by_turn_with_every_move_and_joint(self):
        trace, seen = self.run_agent(
            "put the blue box inside the tray",
            lambda r: call("list_objects", {}),
            lambda r: call("pick", {"object_id": ids(r)["blue cube"]}),
            lambda r: call("place_at", {"place_name": "tray"}),
            lambda r: {"role": "assistant", "content": "I put the blue cube inside the tray."})
        self.assertTrue(seen and seen[-1]["finished"], "the tab was kept up to date, turn by turn")
        json.dumps(trace)                                          # plain data: it can be saved
        turns = trace["turns"]
        self.assertEqual([t["calls"][0]["name"] if t["calls"] else "reply" for t in turns],
                         ["list_objects", "pick", "place_at", "reply"])
        pick = turns[1]["calls"][0]
        self.assertEqual(pick["fills"][0]["from"], "the app's reply in turn 1")
        self.assertTrue(pick["matches"][0]["guess"], "\"blue box\" is not \"blue cube\"")
        self.assertTrue(all(c["ok"] for c in pick["checks"]))
        app_part = pick["app"]
        self.assertIn("camera: top of the blue cube", app_part["target_from"])
        moves = [m for m in app_part["moves"] if m["kind"] == "move"]
        self.assertEqual(len(moves), 3, "above, down, lift")
        self.assertEqual(moves[0]["route"], "swings round the base")
        self.assertEqual(set(moves[0]["joints_after"]), {"J1", "J2", "J3", "J4"})
        self.assertEqual(app_part["joint_source"], "calculated from the arm model")
        self.assertIsNotNone(moves[0]["tightest_on_path"])
        self.assertEqual(turns[1]["receive"]["tokens_read"], 2900)
        end = trace["end"]
        self.assertEqual(end["goal"]["status"], "met")
        self.assertTrue(end["reply"]["ok"])
        self.assertEqual(end["refusals"], 0)
        self.assertEqual(len(end["guesses"]), 1)

    def test_a_made_up_number_in_the_reply_is_caught(self):
        trace, _ = self.run_agent(
            "put the red cube inside the tray",
            lambda r: call("list_objects", {}),
            lambda r: call("pick", {"object_id": ids(r)["red cube"]}),
            lambda r: call("place_at", {"place_name": "tray"}),
            lambda r: {"role": "assistant", "content": "Done: it is exactly 17 mm from the edge."})
        self.assertFalse(trace["end"]["reply"]["ok"])
        self.assertIn("17", trace["end"]["reply"]["detail"])

    def test_a_refusal_and_how_the_model_recovered(self):
        self.sim.world.switch_scenario("tower_building")
        trace, _ = self.run_agent(
            "build a tower using all these cubes",
            lambda r: call("list_objects", {}),
            lambda r: call("pick", {"object_id": ids(r)["yellow cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["purple cube"]}),
            lambda r: call("pick", {"object_id": ids(r)["red cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["purple cube"]}),       # the bottom: refused
            lambda r: call("place_on", {"object_id": ids(r)["yellow cube"]}),       # the hint: the top
            lambda r: {"role": "assistant", "content": "Tower of three."})
        end = trace["end"]
        self.assertEqual(end["refusals"], 1)
        self.assertEqual(end["recoveries"][0]["then"], "followed the hint")
        refused = trace["turns"][4]["calls"][0]
        self.assertTrue(refused["app"]["refused"])
        self.assertEqual(refused["app"]["moves"], [], "refused before moving")
        self.assertFalse(refused["checks"][-1]["ok"])

    def test_a_tower_left_unfinished_and_described_wrongly_is_caught(self):
        """The run from the app: red on green, yellow on red, purple on yellow, blue left out, and "the red cube is
        at the bottom". The model is now told the pile after each stack, and the tab checks the tower."""
        self.sim.world.switch_scenario("tower_building")
        # the tower's base at the scenario's tower spot: at (170, 0), its fourth cube would need the Dobot's rear arm
        # 9 degrees past upright, which the lab's controller refuses (study 2, S-06_Run1), so it is refused here too
        green = next(i for i, m in self.sim.world.object_meta.items() if m["label"] == "green cube")
        self.sim.world.set_object_position_mm(green, 230.0, 0.0, 10.0, 0.0)
        trace, _ = self.run_agent(
            "build a tower, the yellow block shoub the third block in the tower",
            lambda r: call("list_objects", {}),
            lambda r: call("pick", {"object_id": ids(r)["red cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["green cube"]}),
            lambda r: call("pick", {"object_id": ids(r)["yellow cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["red cube"]}),
            lambda r: call("pick", {"object_id": ids(r)["purple cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["yellow cube"]}),
            lambda r: {"role": "assistant", "content": "The red cube is at the bottom, followed by the yellow cube, "
                                                       "and then the purple cube on top."})
        told = trace["turns"][4]["calls"][0]["app"]["result"]
        self.assertIn("bottom to top: green cube, red cube, yellow cube", told)
        self.assertIn("Not in this pile: purple cube", told)
        end = trace["end"]
        self.assertEqual(end["goal"]["status"], "not met")
        self.assertIn("left out: blue cube", end["goal"]["detail"])
        self.assertNotIn("should be", end["goal"]["detail"], "yellow is the third block, as asked")
        self.assertFalse(end["reply"]["ok"])
        self.assertIn("says the red cube is at the bottom", end["reply"]["detail"])
        self.assertNotIn("purple", end["reply"]["detail"], "\"purple cube on top\" is right")
        self.assertEqual(len(end["guesses"]), 1, "the same guess is listed once")

    def test_saying_what_it_will_do_without_doing_it_gets_a_go_ahead(self):
        """"Sort the cubes by colour" ended at "Let me first list the objects." -- no tool called -- every time."""
        trace, _ = self.run_agent(
            "put the red cube inside the tray",
            lambda r: {"role": "assistant", "content": "Let me first list the objects on the table."},
            lambda r: call("list_objects", {}),
            lambda r: call("pick", {"object_id": ids(r)["red cube"]}),
            lambda r: call("place_at", {"place_name": "tray"}),
            lambda r: {"role": "assistant", "content": "The red cube is in the tray."})
        self.assertEqual(trace["end"]["goal"]["status"], "met")
        self.assertIn("nudged", trace["turns"][0])
        # a question is for you: not pushed on
        asked, _ = self.run_agent(
            "put the cube in the tray",
            lambda r: {"role": "assistant", "content": "Which cube do you mean? I'll move it then."})
        self.assertEqual(len(asked["turns"]), 1)
        self.assertEqual(asked["final_message"], "Which cube do you mean? I'll move it then.")

    def test_after_stop_the_models_late_answer_is_not_acted_on(self):
        agent = Agent(Scripted(lambda r: call("list_objects", {})), self.executor, "qwen3:8b", look_first=False)
        original = agent.client.chat

        def answer_after_stop(*args, **kwargs):
            agent.cancel()                    # Stop pressed while the model was still thinking
            return original(*args, **kwargs)
        agent.client.chat = answer_after_stop
        run = agent.run("what do you see?")
        self.assertEqual(run.final_message, "Stopped by you. Nothing further was done.")
        self.assertEqual(run.steps, [], "the tool it asked for was not run")

    def test_a_loop_is_noticed(self):
        self.sim.world.switch_scenario("tower_building")
        trace, _ = self.run_agent(
            "build a tower",
            lambda r: call("list_objects", {}),
            lambda r: call("pick", {"object_id": ids(r)["yellow cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["purple cube"]}),
            lambda r: call("pick", {"object_id": ids(r)["red cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["purple cube"]}),
            lambda r: call("place_on", {"object_id": ids(r)["purple cube"]}),
            lambda r: {"role": "assistant", "content": "I could not."})
        self.assertTrue(trace["end"]["loops"])
        self.assertEqual(trace["end"]["recoveries"][0]["then"], "tried exactly the same again")
        self.assertIn("looping", problems(trace))


class ClientTests(unittest.TestCase):
    def test_ollamas_figures_and_the_reasoning_are_kept(self):
        answer = {"message": {"role": "assistant", "content": "", "thinking": "The blue one is obj_2.",
                              "tool_calls": [{"function": {"name": "pick", "arguments": {"object_id": "obj_2"}}}]},
                  "prompt_eval_count": 3120, "eval_count": 24, "prompt_eval_duration": 2_100_000_000,
                  "eval_duration": 900_000_000, "load_duration": 0, "total_duration": 7_900_000_000,
                  "done_reason": "stop"}
        response = SimpleNamespace(json=lambda: answer, raise_for_status=lambda: None)
        client = ollama_module.OllamaClient()
        client.think = True
        with mock.patch.object(ollama_module.requests, "post", return_value=response) as post:
            message = client.chat("qwen3:8b", [{"role": "user", "content": "x"}])
        self.assertTrue(post.call_args.kwargs["json"]["think"], "reasoning asked for")
        self.assertEqual(message["thinking"], "The blue one is obj_2.")
        self.assertEqual(client.last_stats["tokens_read"], 3120)
        self.assertAlmostEqual(client.last_stats["read_s"], 2.1)
        self.assertEqual(client.last_stats["stop_reason"], "stop")


class RealModeJointTests(unittest.TestCase):
    def test_on_the_real_robot_the_joint_angles_come_from_the_dobot(self):
        from test_dobot_driver import FakeDobot, make_robot
        fake = FakeDobot(move_seconds=0.05)
        recorder = MoveRecorder(make_robot(fake))
        recorder.moves = []
        recorder.move_to(Pose(230, 0, 40))
        move = recorder.moves[0]
        self.assertEqual(recorder.joint_source, "reported by the Dobot")
        self.assertEqual(set(move["joints_after"]), {"J1", "J2", "J3", "J4"})
        self.assertNotIn("tightest_on_path", move, "the controller checks its own path")


class PageTests(unittest.TestCase):
    def trace(self, **end):
        base = {"goal": {"status": "met", "detail": "done"}, "reply": {"ok": True, "detail": "ok"}, "guesses": [],
                "ambiguities": [], "refusals": 0, "recoveries": [], "loops": [],
                "budget": {"steps": 1, "limit": 20, "model_s": 1.0, "robot_s": 1.0, "tokens_read": 10,
                           "tokens_written": 2}, "joints": {"moves": 0, "closest": None}}
        base.update(end)
        return {"prompt": f"prompt {len(end)}", "started": f"2026-09-25 10:00:0{len(end)}", "model": "qwen3:8b",
                "temperature": 0.2, "reasoning": False, "max_steps": 20, "setup": {"mode": "demo"}, "model_info": {},
                "understood": understand("go home"), "turns": [], "finished": True, "final_message": "done",
                "took_s": 1.0, "end": base}

    def test_filter_save_and_the_log_files(self):
        with tempfile.TemporaryDirectory() as folder:
            tab = ModelTab(Path(folder) / "logs")
            clean, troubled = self.trace(), self.trace(refusals=2)
            tab.update_trace(clean)
            tab.update_trace(troubled)
            self.assertEqual(len(list((Path(folder) / "logs").glob("*.json"))), 2, "one file per prompt")
            self.assertEqual(len(tab.visible_traces()), 2)
            tab.only_problems.setChecked(True)
            self.assertEqual(tab.visible_traces(), [troubled])
            tab.save_to(Path(folder) / "page.html")
            self.assertIn("2 refused", (Path(folder) / "page.html").read_text(encoding="utf-8"))
            self.assertIn("Nothing yet", render([]))


class InTheAppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        shutil.copy(ROOT / "config.yaml", Path(cls.folder.name) / "config.yaml")
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        cls._warning = QMessageBox.warning
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"
        config["display"] = {}
        cls.window = main_window_module.MainWindow(config)
        cls.window.show()

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        QMessageBox.warning = cls._warning
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def test_the_pick_area_is_outlined_on_the_camera_picture(self):
        window = self.window
        window.detection_settings.update(pick_area={"x": [180.0, 260.0], "y": [-100.0, 100.0]})
        try:
            corners = window._pick_area_outline()
            intrinsics = window.camera.get_intrinsics()
            self.assertEqual(len(corners), 4)
            for u, v in corners:
                self.assertTrue(0 <= u < intrinsics.width and 0 <= v < intrinsics.height, (u, v))
        finally:
            window.detection_settings.update(pick_area=None)
        self.assertIsNone(window._pick_area_outline())

    def test_an_unchecked_camera_table_height_is_not_used_for_z_min(self):
        """Live, without the calibration's table touch, the camera put the table at -179 (the tip touches it at about
        -35), and "Detect table height" set Z min there: 145 mm below the table."""
        import json
        from types import SimpleNamespace
        path = Path(self.folder.name) / "calibration_check.json"
        live = SimpleNamespace(_twin_world=None, _calibration_path=lambda: path)
        for method, checked in (("marker", False), ("marker+table", True)):
            path.write_text(json.dumps({"t_cam_to_robot": [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], "intrinsics": {"fx": 1, "fy": 1, "cx": 0,
                            "cy": 0, "width": 2, "height": 2}, "method": method, "reprojection_error_mm": 3.0,
                            "num_samples": 9}), encoding="utf-8")
            self.assertEqual(main_window_module.MainWindow._heights_checked(live), checked, method)

    def test_the_estop_lets_the_tools_know_the_gripper_let_go(self):
        """The stop releases the gripper (demo and real): the next prompt was still told it held the cube."""
        window = self.window
        window.tool_executor.holding = "red cube"
        try:
            window._on_estop()
            self.assertIsNone(window.tool_executor.holding)
        finally:
            window.robot.reset_estop()

    def test_the_tab_sits_next_to_prompt_and_the_reasoning_switch_reaches_the_model(self):
        window = self.window
        self.assertEqual([window.tabs.tabText(i) for i in range(window.tabs.count())],
                         ["Manual", "Prompt", "Model", "Calibration", "Log"])
        self.assertIs(window.calibration_tab, window.tabs.widget(3))
        self.assertFalse(window.ollama_client.think)
        window.display_settings.set("show_reasoning", True)
        self.assertTrue(window.ollama_client.think)
        window.display_settings.set("show_reasoning", False)
        self.assertEqual(window._describe_setup()["scene"], "Three cubes and a tray")

    def test_the_model_list_shows_what_is_installed_with_a_few_words_each(self):
        from unittest import mock
        from app.llm.models import ModelInfo
        window = self.window
        installed = [ModelInfo("qwen3:8b", 5.2), ModelInfo("qwen3:4b", 2.5, thinking_only=True),
                     ModelInfo("qwen3:4b-instruct-2507-q4_K_M", 2.5), ModelInfo("llava:latest", 4.7, tools=False),
                     ModelInfo("llama3.2:latest", 2.0)]
        before = window.agent.model
        self.addCleanup(setattr, window.agent, "model", before)
        with mock.patch.object(window, "_load_model") as load:
            window.agent.model = "not-installed:1b"
            window._on_model_list(installed)
        from app.ui.model_combo import PLANNING, ROLE, SPEED
        combo = window.model_selector
        names = [combo.itemData(i) for i in range(combo.count())]
        self.assertEqual(names, ["qwen3:4b-instruct-2507-q4_K_M", "llama3.2:latest", "qwen3:8b", "qwen3:4b"],
                         "every model that can use tools (V4.3), Quick first, the tested Qwen first in each; llava "
                         "can't use tools")
        self.assertEqual([combo.itemData(i, ROLE) for i in range(4)],
                         ["Quick", "Quick", "Detailed planning", "Deep reasoning"])
        self.assertEqual([(combo.itemData(i, SPEED), combo.itemData(i, PLANNING)) for i in range(4)],
                         [(3, 1), (3, 1), (1, 2), (1, 3)])
        tips = [combo.itemData(i, Qt.ItemDataRole.ToolTipRole) for i in range(4)]
        self.assertIn("the study's model (the default)", tips[0])
        self.assertIn("not tested with this app", tips[1])
        self.assertEqual(combo.closed_text(), "qwen3:4b-instruct · Quick")
        self.assertEqual(window.agent.model, "qwen3:4b-instruct-2507-q4_K_M", "a model that is there, the recommended one")
        load.assert_called_once_with("qwen3:4b-instruct-2507-q4_K_M")

    def test_the_open_list_has_a_heading_row_that_is_not_a_model(self):
        """The dots alone didn't say which was speed and which planning: Model, Good for, Speed, Planning above them."""
        from unittest import mock
        from app.llm.models import ModelInfo
        from app.ui.model_combo import HEADING_HEIGHT
        window = self.window
        before = window.agent.model
        self.addCleanup(setattr, window.agent, "model", before)
        with mock.patch.object(window, "_load_model"):
            window._on_model_list([ModelInfo("qwen3:4b-instruct-2507-q4_K_M", 2.5), ModelInfo("qwen3:8b", 5.2),
                                   ModelInfo("qwen3:4b", 2.5, thinking_only=True)])
        combo = window.model_selector
        combo.showPopup()
        self.addCleanup(combo.hidePopup)
        view = combo.view()
        self.assertTrue(combo.heading.isVisible())
        self.assertEqual(combo.heading.geometry().bottom() + 1, view.viewport().geometry().top(), "right above the rows")
        self.assertEqual(combo.heading.height(), HEADING_HEIGHT)
        self.assertGreaterEqual(view.viewport().height(), sum(view.sizeHintForRow(i) for i in range(combo.count())),
                                "no row cut off")
        self.assertEqual(combo.count(), 3, "the heading is not a row: it can't be picked")

    def test_picking_a_model_loads_it_for_this_sitting_and_warns_of_a_thinking_one(self):
        from unittest import mock
        from app.llm.models import ModelInfo
        window = self.window
        before = window.agent.model
        self.addCleanup(setattr, window.agent, "model", before)
        # (not the one in your config.yaml, which may well be qwen3:4b already)
        self.addCleanup(window.config["llm"].__setitem__, "model", window.config["llm"]["model"])
        window.agent.model = window.config["llm"]["model"] = "qwen3:4b-instruct-2507-q4_K_M"
        with mock.patch.object(window, "_load_model"):
            window._on_model_list([ModelInfo("qwen3:4b-instruct-2507-q4_K_M", 2.5),
                                   ModelInfo("qwen3:4b", 2.5, thinking_only=True)])
        combo = window.model_selector
        with mock.patch.object(window, "_load_model") as load, mock.patch.object(window, "_save_config_value") as save, \
                mock.patch.object(main_window_module.QMessageBox, "warning") as warning:
            combo.setCurrentIndex(combo.findData("qwen3:4b"))
            window._on_model_picked(combo.currentIndex())
        self.assertEqual(window.agent.model, "qwen3:4b")
        load.assert_called_once_with("qwen3:4b")
        save.assert_not_called()          # (V4.3: the default in config.yaml, the study's model, stays)
        self.assertEqual(window.config["llm"]["model"], "qwen3:4b-instruct-2507-q4_K_M")
        warning.assert_called_once()

    def test_the_model_is_chosen_in_the_prompt_tab_and_shown_in_the_status_bar(self):
        """In the toolbar it didn't fit a screen with larger text: the Model list went into the overflow strip,
        which closed again as the list opened, and the model couldn't be changed."""
        from PyQt6.QtWidgets import QToolBar
        window = self.window
        self.assertTrue(window.prompt_panel.isAncestorOf(window.model_selector))
        self.assertEqual(len(window.findChildren(QToolBar)), 1, "one toolbar row")
        window._llm_status = "Ready (x)"
        window._set_model_state("ready · 3.2 GB", "#4caf50")
        self.assertIn("ready · 3.2 GB", window.llm_status_label.text())

    def test_the_simulated_camera_tools_are_in_the_settings_panels_kept_in_step(self):
        window = self.window
        self.assertEqual(len(window._quality_combos), 2, "one in each Settings panel (Manual and Prompt tabs)")
        window._quality_combos[0].setCurrentText(window._quality_combos[0].itemText(1))
        self.assertEqual(window._quality_combos[1].currentText(), window._quality_combos[0].itemText(1))
        window._quality_combos[0].setCurrentText(window._quality_combos[0].itemText(0))

    def test_an_imperfect_demo_camera_shows_in_the_status_bar(self):
        """Left on "Poor", the demo camera saw one cube as three things, and nothing on screen said why."""
        window = self.window
        self.addCleanup(window._quality_combos[0].setCurrentText, "Perfect")
        window._quality_combos[0].setCurrentText("Poor")
        self.assertIn("picture: Poor", window.camera_status_label.text())
        window._quality_combos[1].setCurrentText("Perfect")
        self.assertNotIn("picture:", window.camera_status_label.text())

    def test_the_demo_keeps_its_own_detection_settings(self):
        """"Coloured cubes only", chosen against the real camera's phantoms, also blinded the demo to its ball."""
        import yaml
        window = self.window
        self.assertEqual(window._vision_section, "vision_demo")
        path = window._config_file
        self.assertEqual(path.parent, main_window_module.PROJECT_ROOT, "the test's own folder")
        path.write_text(yaml.safe_dump({"vision": {"detector": "color_blob", "pick_area": {"x": [1, 2], "y": [3, 4]}}}),
                        encoding="utf-8")
        self.addCleanup(path.unlink)
        before = window.detection_settings.find
        self.addCleanup(window._detection_save.stop)      # (its delayed save: not left to fire after the test)
        self.addCleanup(window.detection_settings.update, find=before)
        window.detection_settings.update(find="any")
        window._save_detection_settings()
        saved = yaml.safe_load(path.read_text(encoding="utf-8"))
        self.assertEqual(saved["vision_demo"]["detector"], "depth")
        self.assertEqual(saved["vision"], {"detector": "color_blob", "pick_area": {"x": [1, 2], "y": [3, 4]}},
                         "the real camera's left as they were")

    def test_the_model_list_is_locked_while_a_prompt_runs(self):
        window = self.window
        window.prompt_panel.busy_changed.emit(True)
        self.assertFalse(window.model_selector.isEnabled())
        window.prompt_panel.busy_changed.emit(False)
        self.assertTrue(window.model_selector.isEnabled())

    def test_the_log_tab_beside_calibration_shows_the_same_log_live(self):
        import logging
        window = self.window
        self.assertIs(window.tabs.widget(4), window.log_tab)
        logging.getLogger("test").warning("seen in the Log tab")
        QApplication.processEvents()
        self.assertIn("seen in the Log tab", window.log_tab.view.toPlainText())
        self.assertEqual(window.log_tab.view.toPlainText(), window.log_panel.text(), "the same lines in both")
        window.log_tab.copy_btn.click()
        self.assertIn("seen in the Log tab", QApplication.clipboard().text())
        window.log_tab.clear_btn.click()
        self.assertEqual((window.log_tab.view.toPlainText(), window.log_panel.text()), ("", ""), "Clear empties both")
        logging.getLogger("test").warning("after the clear")
        QApplication.processEvents()
        self.assertIn("after the clear", window.log_tab.view.toPlainText())

    def test_the_log_also_shows_in_the_system_check_window(self):
        import logging
        from unittest import mock
        from app.ui.system_check_dialog import SystemCheckDialog
        window = self.window
        logging.getLogger("test").warning("logged before the window was opened")
        with mock.patch.object(SystemCheckDialog, "run", SystemCheckDialog.show_checks):   # no real checks here
            window._open_system_check()
        dialog = window._system_check
        self.addCleanup(dialog.close)
        self.assertFalse(dialog.showing_log(), "it opens on the checks")
        self.assertEqual((dialog.log_btn.text(), dialog.clear_btn.isVisible()), ("Show log", False))
        dialog.log_btn.click()
        self.assertTrue(dialog.showing_log())
        self.assertEqual(len(window.findChildren(SystemCheckDialog)), 1, "the same window, not another one")
        self.assertEqual((dialog.windowTitle(), dialog.log_btn.text(), dialog.copy_btn.text()),
                         ("System check: log", "Back to checks", "Copy log"))
        self.assertTrue(dialog.clear_btn.isVisible())
        QApplication.processEvents()
        self.assertIn("logged before the window was opened", window.log_panel.text())
        dialog.copy_btn.click()
        self.assertIn("logged before the window was opened", QApplication.clipboard().text())
        dialog.log_btn.click()
        self.assertFalse(dialog.showing_log())
        self.assertEqual((dialog.windowTitle(), dialog.copy_btn.text()), ("System check", "Copy report"))
        dialog.log_btn.click()
        with mock.patch.object(SystemCheckDialog, "run", SystemCheckDialog.show_checks):
            window._open_system_check()
        self.assertFalse(dialog.showing_log(), "opened again, it's back on the checks")
        self.assertIsNone(SystemCheckDialog(lambda: None, window).log_btn, "no button without a log to show")


def calls(*steps):
    """One answer with several tool calls: (name, args) pairs, in order."""
    return {"role": "assistant", "content": "",
            "tool_calls": [{"function": {"name": name, "arguments": args}} for name, args in steps]}


class AppLooksFirstTests(unittest.TestCase):
    """V4.3: the app looks first, the model may give every step in one answer and end it with done(); a step that
    fails stops the rest of its answer (study 1: Qwen's 3-6 turns a run took 47-177 s on the laptop's CPU)."""

    setUp = RecordTests.setUp

    def run_v43(self, prompt, *answers):
        client = Scripted(*answers)
        asked = []
        chat = client.chat
        client.chat = lambda *a, **k: (asked.append(1), chat(*a, **k))[1]
        run = Agent(client, self.executor, "qwen3:8b", max_tool_calls=12).run(prompt)
        return run, len(asked)

    def test_the_app_looks_first_and_one_answer_does_every_step_then_done(self):
        run, asked = self.run_v43(
            "put the blue box inside the tray",
            lambda r: calls(("pick", {"object_id": ids(r)["blue cube"]}), ("place_at", {"place_name": "tray"}),
                            ("done", {})))
        self.assertEqual(asked, 1, "one model answer for the whole prompt")
        self.assertEqual([s.tool_name for s in run.steps], ["list_objects", "pick", "place_at"], "done isn't a step")
        first = run.trace["turns"][0]
        self.assertEqual((first["by"], first["decided_s"], first["calls"][0]["name"]), ("the app", 0.0, "list_objects"))
        self.assertIn("Picked up blue cube", run.final_message, "the app's reply: what the steps said")
        self.assertNotIn("{'holding'", run.final_message, "not the look")
        self.assertEqual(run.trace["end"]["goal"]["status"], "met", run.trace["end"]["goal"])

    def test_done_written_as_the_answer_is_taken_as_the_call(self):
        # the V4.3 twin chain (2026-10-25): Qwen wrote "done()" as its answer after each last step, every prompt
        run, asked = self.run_v43(
            "put the blue box inside the tray",
            lambda r: call("pick", {"object_id": ids(r)["blue cube"]}),
            lambda r: {"role": "assistant", "content": "done()"},
            lambda r: call("place_at", {"place_name": "tray"}),
            lambda r: {"role": "assistant", "content": "done()"})
        self.assertEqual(asked, 4)
        self.assertIn("still holding the blue cube", run.trace["turns"][2]["nudged"], "checked as the call is")
        self.assertNotIn("done()", run.final_message)
        self.assertIn("Picked up blue cube", run.final_message)

    def test_a_step_that_fails_stops_the_rest_of_its_answer(self):
        run, asked = self.run_v43(
            "put the blue box inside the tray",
            lambda r: calls(("pick", {"object_id": "obj_999"}), ("place_at", {"place_name": "tray"}), ("done", {})),
            lambda r: {"role": "assistant", "content": "I couldn't find that cube."})
        self.assertEqual(asked, 2, "the model is asked again after the failure")
        self.assertEqual([s.tool_name for s in run.steps], ["list_objects", "pick"], "place_at and done not run")
        answer = run.trace["turns"][1]["calls"]
        self.assertTrue(answer[0]["app"]["refused"])
        self.assertEqual([c["app"]["stopped"] for c in answer[1:]], ["not run", "not run"])
        self.assertFalse(any(c["app"]["refused"] for c in answer[1:]), "not counted as refused: never tried")
        self.assertEqual(run.final_message, "I couldn't find that cube.")

    def test_done_while_holding_or_not_finished_is_sent_back(self):
        run, asked = self.run_v43(
            "put the blue box inside the tray",
            lambda r: calls(("pick", {"object_id": ids(r)["blue cube"]}), ("done", {})),
            lambda r: calls(("place_at", {"place_name": "tray"}), ("done", {})))
        self.assertEqual(asked, 2)
        self.assertIn("still holding the blue cube", run.trace["turns"][1]["nudged"])
        self.assertEqual([s.tool_name for s in run.steps], ["list_objects", "pick", "place_at"])
        self.assertIsNone(run.trace["turns"][2].get("nudged"))
        self.assertEqual(run.trace["end"]["goal"]["status"], "met")


if __name__ == "__main__":
    unittest.main()

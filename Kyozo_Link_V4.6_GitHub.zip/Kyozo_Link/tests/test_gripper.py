"""The two-finger gripper: the camera measures each object's footprint, the tools check it fits between the fingers,
turn the fingers to its narrow sides and close partway down it; the demo gripper only holds what a real one could.

    python -m unittest discover -s tests -p test_gripper.py -v

Demo mode only (the real gripper is checked on the robot); nothing in the project changes.
"""
from __future__ import annotations

import ast
import math
import unittest

from harness import LOOK_POSE, Sim

from app.hardware.gripper import GripperSpec, across, grip_depth, plan_grip, turn_for_place
from app.hardware.interfaces import Pose
from app.llm.tools import RELEASE_GAP_MM, ToolExecutor
from app.twin import kinematics
from app.twin.shuffle import MAX_OBJECT_TURN_DEG, shuffle_turns
from app.vision.detector import build_detector, with_demo_colors
from app.vision.scene import SceneBuilder

SPEC = GripperSpec()          # the Magician's gripper kit: opens 27.5 mm
CUBE = 20.0                   # the demo's cubes


def square_turn_error(measured: float, true: float) -> float:
    """How far apart two turns of a square are (a quarter turn looks the same)."""
    return abs((measured - true + 45.0) % 90.0 - 45.0)


class Setup(unittest.TestCase):
    def setUp(self):
        self.sim = Sim(gripper=SPEC)
        self.addCleanup(self.sim.close)
        self.world = self.sim.world
        self.ids = {m["label"]: i for i, m in self.world.object_meta.items()}
        self.scene = SceneBuilder(self.sim.camera, build_detector(with_demo_colors(self.sim.config["vision"])),
                                  self.sim.exact_transform())
        self.executor = ToolExecutor(self.sim.robot, self.scene, look_pose=LOOK_POSE, table_z_provider=lambda: 0.0,
                                     places_provider=self.world.places, gripper=SPEC)

    def turn(self, label: str, yaw: float, x=None, y=None) -> None:
        object_id = self.ids[label]
        ox, oy, oz = self.world.get_object_position_mm(object_id)
        self.world.set_object_position_mm(object_id, ox if x is None else x, oy if y is None else y, oz, yaw)

    def listed(self) -> dict:
        return {o["label"]: o for o in ast.literal_eval(self.executor.execute("list_objects", {}))["objects"]}


class MeasuringTests(Setup):
    def test_the_camera_measures_each_objects_footprint_centre_and_turn(self):
        self.sim.robot.move_to(LOOK_POSE)
        for scene in ("two_blocks_and_tray", "size_sorting"):
            self.world.switch_scenario(scene)
            self.ids = {m["label"]: i for i, m in self.world.object_meta.items()}
            for yaw in (0.0, 30.0, 45.0):
                for label, object_id in self.ids.items():
                    if self.world.object_meta[object_id]["shape"] != "tray":
                        self.turn(label, yaw)
                seen = {o.label: o for o in self.scene.get_scene()}
                for label, object_id in self.ids.items():
                    meta = self.world.object_meta[object_id]
                    if meta["shape"] == "tray":
                        continue
                    self.assertIn(label, seen, f"{label} turned {yaw} degrees is still found")
                    width, length, angle = seen[label].footprint
                    size = meta["size"][0]
                    self.assertAlmostEqual(width, size, delta=1.0, msg=f"{label} at {yaw}")
                    self.assertAlmostEqual(length, size, delta=1.0, msg=f"{label} at {yaw}")
                    self.assertLess(square_turn_error(angle, yaw), 3.0, f"{label} at {yaw}: {angle}")
                    x, y, _ = self.world.get_object_position_mm(object_id)
                    self.assertLess(math.dist(seen[label].xyz_robot[:2], (x, y)), 1.0,
                                    f"{label} at {yaw}: the fingers have only 3.75 mm to spare round a 20 mm cube")

    def test_the_model_is_told_the_footprint(self):
        self.sim.robot.move_to(LOOK_POSE)
        blue = self.listed()["blue cube"]
        self.assertEqual(blue["footprint_mm"], [20, 20])
        self.assertNotIn("gripper", blue, "it fits")


class PlanningTests(unittest.TestCase):
    def test_the_fingers_close_across_the_narrow_side_with_the_least_wrist_turn(self):
        plan = plan_grip(SPEC, 200.0, 0.0, 25.0, 25.0, (20.0, 40.0, 10.0))
        closing = SPEC.closing_direction(plan.r)
        self.assertLess(abs((closing - 100.0 + 90.0) % 180.0 - 90.0), 0.01, "across the 20 mm side (at 100 degrees)")
        self.assertAlmostEqual(plan.across_mm, 20.0, places=1)
        self.assertAlmostEqual(plan.spare_mm, 7.5, places=1)
        self.assertAlmostEqual(plan.depth_mm, 12.5, places=1, msg="halfway down a 25 mm tall one")
        square = plan_grip(SPEC, 220.0, 60.0, 25.0, 25.0, (25.0, 25.0, 30.0))
        j1 = math.degrees(math.atan2(60.0, 220.0))
        self.assertLessEqual(abs(square.j4), 45.0, "a square can be taken across either pair of sides: the nearer")
        self.assertAlmostEqual(square.j4, square.r - j1, places=1)

    def test_what_cant_be_gripped_is_refused_in_words(self):
        with self.assertRaisesRegex(ValueError, r"34 mm across .* opens only 27\.5 mm"):
            plan_grip(SPEC, 200.0, 0.0, 25.0, 25.0, (34.0, 34.0, 0.0))
        with self.assertRaisesRegex(ValueError, "too flat"):
            plan_grip(SPEC, 200.0, 0.0, 5.0, 5.0, (20.0, 20.0, 0.0))
        with self.assertRaisesRegex(ValueError, "would hit the red cube"):
            plan_grip(SPEC, 200.0, 0.0, 25.0, 25.0, (20.0, 40.0, 0.0), blocked=lambda direction: "red cube")

    def test_grip_depth(self):
        self.assertEqual(grip_depth(SPEC, 25.0), 12.5)
        self.assertEqual(grip_depth(SPEC, 40.0), SPEC.finger_depth_mm, "no deeper than the fingers reach")
        self.assertEqual(grip_depth(SPEC, None), 8.0, "height unknown: shallow, clear of the table")
        self.assertEqual(grip_depth(GripperSpec(kind="suction"), 25.0), 0.0, "suction takes it by the top")

    def test_the_wrist_turn_follows_the_dobots_r(self):
        """The Dobot's r is J1 + J4: with r held the gripper keeps its direction while the base turns."""
        geometry = kinematics.arm_geometry(173.2, 100.0, 50.0)          # 30 degrees round
        joints = kinematics.dobot_joints(geometry, 0.0)
        self.assertAlmostEqual(joints["J1"], 30.0, places=1)
        self.assertAlmostEqual(joints["J4"], -30.0, places=1)
        self.assertAlmostEqual(kinematics.dobot_joints(geometry, 30.0)["J4"], 0.0, places=1)

    def test_a_held_object_keeps_its_turn_unless_the_wrist_cant(self):
        self.assertEqual(turn_for_place(SPEC, 20.0, 280.0, 0.0, square=True), 20.0, "kept")
        # picked turned -90 far to the right; over on the left the wrist would need J4 -150: a quarter turn instead
        r = turn_for_place(SPEC, -90.0, 150.0, 150.0, square=True)
        self.assertEqual(r, 0.0)
        self.assertEqual(turn_for_place(SPEC, -90.0, 150.0, 150.0, square=False), 90.0, "a half turn for a long one")

    def test_the_settings_come_from_config(self):
        spec = GripperSpec.from_config({"gripper_type": "gripper", "gripper": {"opening_mm": 30, "jaw_axis_deg": 0}})
        self.assertTrue(spec.fingers)
        self.assertEqual((spec.opening_mm, spec.jaw_axis_deg), (30.0, 0.0))
        self.assertFalse(GripperSpec.from_config({"gripper_type": "suction"}).fingers)
        self.assertAlmostEqual(across(20.0, 40.0, 0.0, 90.0), 20.0)
        self.assertAlmostEqual(across(20.0, 40.0, 0.0, 0.0), 40.0)


class DemoGripperTests(Setup):
    def test_the_fingers_hold_only_what_they_close_round(self):
        robot = self.sim.robot
        x, y, _ = self.world.get_object_position_mm(self.ids["red cube"])
        robot.open_gripper()
        robot.move_to(Pose(x, y, 30.0, 0.0))            # fingertips above the top (20): nothing between them
        robot.close_gripper()
        self.assertIsNone(robot.held_object)
        self.assertIn("above", robot.last_grip_problem)
        robot.open_gripper()
        robot.move_to(Pose(x, y, 12.5, 0.0))
        robot.close_gripper()
        self.assertEqual(robot.held_object, self.ids["red cube"])
        robot.open_gripper()
        robot.move_to(Pose(x, y, 60.0, 0.0))
        # a 40 x 20 block with its long side along the way the fingers close (r = 0): 40 mm between fingers that
        # open 27.5
        self.world.object_meta[self.ids["red cube"]]["size"] = (40.0, 20.0, CUBE)
        self.turn("red cube", SPEC.closing_direction(0.0))
        from app.hardware.sim_robot import Collision
        with self.assertRaisesRegex(Collision, "a finger touched the red cube"):
            robot.move_to(Pose(x, y, 12.5, 0.0))       # a finger comes down on its end, as a real one would
        self.assertGreaterEqual(robot.get_pose().z, CUBE - 1.0, "stopped on it, not through it")
        robot.close_gripper()
        self.assertIsNone(robot.held_object)


class LettingGoTests(Setup):
    def test_let_go_over_an_edge_it_tips_off_and_lands_beside(self):
        """It used to "rest" on a cube it overlapped by 3 mm, hanging almost wholly in the air beside it."""
        robot, world = self.sim.robot, self.world
        bx, by, _ = world.get_object_position_mm(self.ids["blue cube"])
        rx, ry, _ = world.get_object_position_mm(self.ids["red cube"])

        def carry(x, y):
            px, py, pz = world.get_object_position_mm(self.ids["blue cube"])
            robot.open_gripper()
            robot.move_to(Pose(px, py, pz + 50, 0.0))
            robot.move_to(Pose(px, py, pz, 0.0))
            robot.close_gripper()
            self.assertEqual(robot.held_object, self.ids["blue cube"], robot.last_grip_problem)
            robot.move_to(Pose(px, py, 90, 0.0))
            robot.move_to(Pose(x, y, 90, 0.0))
            robot.open_gripper()
            return world.get_object_position_mm(self.ids["blue cube"])
        x, y, z = carry(rx + CUBE - 3.0, ry)                  # 3 mm over the red cube's edge
        self.assertAlmostEqual(z, CUBE / 2, delta=0.5, msg="on the table, not hanging off the red cube")
        self.assertGreaterEqual(abs(x - rx), CUBE, "tipped clear of it")
        # (where it landed, between the red cube and the tray's wall, the fingers can't get round it either way)
        world.set_object_position_mm(self.ids["blue cube"], bx, by, CUBE / 2)
        x, y, z = carry(rx + 8.0, ry)
        self.assertAlmostEqual(z, 1.5 * CUBE, delta=0.5, msg="its middle over the red cube: it stays on it")


class PickingTests(Setup):
    def test_a_turned_cube_is_picked_with_the_fingers_turned_and_put_down_still_turned(self):
        self.turn("blue cube", 30.0)
        blue = self.listed()["blue cube"]["id"]
        self.assertEqual(self.executor.execute("pick", {"object_id": blue}), f"Picked up blue cube ({blue})")
        self.assertEqual(self.sim.robot.held_object, self.ids["blue cube"], self.sim.robot.last_grip_problem)
        grip = self.executor.last_record["grip"]
        self.assertLess(square_turn_error(SPEC.closing_direction(grip["r"]) - 90.0, 30.0), 3.0)
        moves = self.executor.last_record["moves"]
        closed = next(i for i, m in enumerate(moves) if m["kind"] == "close gripper")
        down = [m for m in moves[:closed] if m["kind"] == "move"][-1]      # (the last 15 mm slowly, after the turn)
        self.assertAlmostEqual(down["target"][2], CUBE / 2, delta=1.0, msg="fingertips halfway down")
        self.executor.execute("place_at", {"place_name": "tray"})
        self.assertLess(square_turn_error(self.world.get_object_yaw_deg(self.ids["blue cube"]), 30.0), 3.0)

    def test_an_object_too_wide_for_the_fingers_is_refused_before_the_arm_moves(self):
        object_id = self.ids["blue cube"]
        self.world.object_meta[object_id]["size"] = (34.0, 34.0, 25.0)
        body = self.world.object_ids[object_id]
        import pybullet as p
        from app.twin.world import pybullet_lock
        with pybullet_lock:     # a bigger box in the blue cube's place
            p.removeBody(body, physicsClientId=self.world.client)
        self.world._spawn_object({"id": "blue_cube", "label": "blue cube", "size_mm": 34,
                                  "position_mm": [220, 60, 12.5], "color_rgba": [0.1, 0.2, 0.8, 1]})
        blue = self.listed()["blue cube"]
        self.assertIn("too wide", blue["gripper"])
        with self.assertRaisesRegex(ValueError, r"Can't pick up the blue cube: It is 34 mm across"):
            self.executor.execute("pick", {"object_id": blue["id"]})
        self.assertEqual(self.executor.last_record["moves"], [], "refused before moving")

    def test_the_fingers_are_turned_away_from_a_close_neighbour(self):
        """A square cube can be taken across either pair of sides: the one that keeps the fingers off a
        neighbour 30 mm away is used."""
        bx, by, _ = self.world.get_object_position_mm(self.ids["blue cube"])
        listed = self.listed()
        scene = {o.label: o for o in self.executor._last_scene}
        blue = scene["blue cube"]
        plain = plan_grip(SPEC, bx, by, 25.0, 25.0, blue.footprint)
        towards = math.radians(SPEC.closing_direction(plain.r))
        self.turn("red cube", 0.0, bx + 30.0 * math.cos(towards), by + 30.0 * math.sin(towards))
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["blue cube"]["id"]})
        self.assertEqual(self.sim.robot.held_object, self.ids["blue cube"])
        used = SPEC.closing_direction(self.executor.last_record["grip"]["r"])
        self.assertAlmostEqual(abs((used - math.degrees(towards) + 90.0) % 180.0 - 90.0), 90.0, delta=1.0,
                               msg="a quarter turn from the way that meets the red cube")

    def test_stacking_with_the_fingers(self):
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["red cube"]["id"]})
        result = self.executor.execute("place_on", {"object_id": listed["blue cube"]["id"]})
        self.assertIn("bottom to top: blue cube, red cube", result)
        bx, by, _ = self.world.get_object_position_mm(self.ids["blue cube"])
        rx, ry, rz = self.world.get_object_position_mm(self.ids["red cube"])
        self.assertLess(math.dist((rx, ry), (bx, by)), 2.0)
        self.assertAlmostEqual(rz, 1.5 * CUBE, delta=1.0, msg="resting on the blue cube")
        # (the lowest move: where it was let go -- a put-down first brings the wrist to its angle from one side)
        release = min(m["target"][2] for m in self.executor.last_record["moves"] if m["kind"] == "move")
        self.assertAlmostEqual(release, CUBE + CUBE + RELEASE_GAP_MM - CUBE / 2, delta=1.5,
                               msg="let go with its bottom just above the blue cube's top")


class FoundInReviewTests(Setup):
    def test_a_tower_started_at_a_saved_place_is_stacked_on_at_the_right_height(self):
        """Put down at a place (no look after), the cube's top was remembered at the fingertips' height, 12.5 mm
        too low (25 mm cubes then): the next cube was let go 12.5 mm down into it."""
        self.world.switch_scenario("tower_building")
        self.ids = {m["label"]: i for i, m in self.world.object_meta.items()}
        self.executor.forget_scene()
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["red cube"]["id"]})
        self.executor.execute("place_at", {"place_name": "tower spot"})
        red_top = self.world.get_object_position_mm(self.ids["red cube"])[2] + CUBE / 2
        self.executor.execute("pick", {"object_id": listed["blue cube"]["id"]})
        self.executor.execute("place_on", {"object_id": listed["red cube"]["id"]})
        # (the lowest move: where it was let go -- a put-down first brings the wrist to its angle from one side)
        release = min(m["target"][2] for m in self.executor.last_record["moves"] if m["kind"] == "move")
        blue_bottom = release + CUBE / 2 - CUBE
        self.assertGreater(blue_bottom, red_top - 1.5, "let go on the red cube, not inside it")
        self.assertLess(blue_bottom, red_top + RELEASE_GAP_MM + 3.0, "let go just above it")
        bx, by, bz = self.world.get_object_position_mm(self.ids["blue cube"])
        self.assertAlmostEqual(bz, red_top + CUBE / 2, delta=1.5)

    def test_a_short_cube_on_another_is_not_refused_for_the_one_under_it(self):
        self.world.object_meta[self.ids["red cube"]]["size"] = (25.0, 25.0, 12.0)
        bx, by, _ = self.world.get_object_position_mm(self.ids["blue cube"])
        self.turn("red cube", 0.0, bx, by)
        red = self.world.object_ids[self.ids["red cube"]]
        import pybullet as p
        from app.twin.world import pybullet_lock
        with pybullet_lock:      # a flat red block lying on the blue cube
            p.removeBody(red, physicsClientId=self.world.client)
        self.world._spawn_object({"id": "red_cube", "label": "red cube", "size_mm": [25, 25, 12],
                                  "position_mm": [bx, by, 31.0], "color_rgba": [0.8, 0.1, 0.1, 1]})
        self.executor._heights["red cube"] = 12.0
        listed = self.listed()
        self.executor.execute("pick", {"object_id": listed["red cube"]["id"]})
        self.assertEqual(self.sim.robot.held_object, "red_cube", self.sim.robot.last_grip_problem)

    def test_closing_on_nothing_in_the_demo_is_said_not_passed_off_as_a_pick(self):
        listed = self.listed()
        # the cube is moved after the look: the fingers come down where it was, and it is looked for again and
        # picked where it is now (as the Dobot does after a missed grip), the miss said
        self.turn("blue cube", 0.0, 150.0, 150.0)
        said = self.executor.execute("pick", {"object_id": listed["blue cube"]["id"]})
        self.assertIn("The first grip missed the blue cube; looked again and picked it once more", said)
        self.assertEqual(self.sim.robot.held_object, "blue_cube")
        self.assertEqual(self.executor.holding, "blue cube")

    def test_a_grip_that_misses_twice_is_said_not_passed_off_as_a_pick(self):
        listed = self.listed()
        self.sim.robot._between_fingers = lambda: None      # (the fingers never close round it)
        with self.assertRaisesRegex(ValueError, r"closed on nothing .* the blue cube was not picked up.*the second try"):
            self.executor.execute("pick", {"object_id": listed["blue cube"]["id"]})
        self.assertIsNone(self.executor.holding)
        self.assertGreater(self.sim.robot.get_pose().z, 40.0, "lifted clear again")

    def test_the_arm_between_the_camera_and_the_cube_moves_out_of_the_way_before_the_picks_pictures(self):
        """This round's E3 (S-07): the gripper, just after a put-down, stood on the camera's line to the next cube; the
        part of the cube left in view put it 11 mm off, and the turn came down onto it."""
        import numpy as np
        listed = self.listed()
        blue = next(o for o in self.executor._last_scene if o.label == "blue cube")
        cube = np.array(blue.xyz_robot, float)
        camera = (np.asarray(self.executor.scene_builder.t_cam_to_robot, float) @ [0.0, 0.0, 0.0, 1.0])[:3]
        on_line = cube + (camera - cube) * ((90.0 - cube[2]) / (camera[2] - cube[2]))    # 90 mm up the line
        here = Pose(x=float(on_line[0]), y=float(on_line[1]), z=90.0, r=0.0)
        self.sim.robot.move_to(here)
        self.assertTrue(self.executor._hides_objects(self.sim.robot.get_pose(), only=[blue]), "in the way")
        self.executor.execute("pick", {"object_id": listed["blue cube"]["id"]})
        self.assertIn("view_cleared", self.executor.last_record)
        self.assertEqual(self.sim.robot.held_object, "blue_cube")
        self.assertNotIn("moved", self.executor.last_record, "read where it is, not where the arm left of it")

    def test_a_finger_on_the_cubes_edge_is_said_so_not_that_the_cube_is_too_wide(self):
        robot = self.sim.robot
        robot.open_gripper()
        robot.move_to(Pose(x=200.0, y=0.0, z=60.0, r=0.0))
        gx, gy = robot._grip_point()
        # a 20 mm cube 4.5 mm off the fingers' middle, both ways (3.75 mm spare a side): a finger lands on its edge
        self.turn("blue cube", 0.0, gx + 4.5, gy + 4.5)
        robot.move_to(Pose(x=200.0, y=0.0, z=12.0, r=0.0))
        robot.close_gripper()
        self.assertIsNone(robot.held_object)
        self.assertIn("off the blue cube's middle, onto its edge", robot.last_grip_problem)
        self.assertNotIn("across the fingers, which open", robot.last_grip_problem)

    def test_where_no_turn_that_looks_the_same_fits_the_wrist_it_turns_as_little_as_it_can(self):
        # a long object held at r 100 (J4 +100 would be needed straight out): no half turn fits either side
        r = turn_for_place(SPEC, 100.0, 280.0, 0.0, square=False)
        self.assertLessEqual(r - 0.0, SPEC.j4_limits_deg[1] - 2.0)

    def test_the_preview_shows_where_the_fingertips_go(self):
        listed = self.listed()
        target = self.executor.planned_target("pick", {"object_id": listed["blue cube"]["id"]})
        self.assertAlmostEqual(target.z, CUBE / 2, delta=1.0)


class ModelTabTests(Setup):
    def test_the_app_block_shows_the_grip(self):
        from app.llm.trace import PromptTrace
        from app.ui.model_tab import render
        self.turn("blue cube", 30.0)
        blue = self.listed()["blue cube"]["id"]
        trace = PromptTrace("pick the blue cube", "qwen3:8b", 0.2, False, 20)
        turn = trace.model_turn({"role": "assistant", "content": "", "tool_calls": [
            {"function": {"name": "pick", "arguments": {"object_id": blue}}}]}, {}, 1.0, None, "")
        result = self.executor.execute("pick", {"object_id": blue})
        trace.app_result(turn, 0, result, self.executor.last_record, "calculated from the arm model")
        page = render([trace.snapshot()])
        self.assertRegex(page, r"camera measured the blue cube 20 × 20 mm, square, turned \+(29|30|31)°")
        self.assertIn("to spare in the 27.5 mm opening", page)


class ShuffleTurnTests(unittest.TestCase):
    def test_shuffled_objects_are_turned_too_the_same_way_for_the_same_layout(self):
        turns = shuffle_turns(["red_cube", "blue_cube"], 42)
        self.assertEqual(turns, shuffle_turns(["blue_cube", "red_cube"], 42))
        self.assertNotEqual(turns, shuffle_turns(["red_cube", "blue_cube"], 43))
        self.assertTrue(all(abs(t) <= MAX_OBJECT_TURN_DEG for t in turns.values()))


if __name__ == "__main__":
    unittest.main()

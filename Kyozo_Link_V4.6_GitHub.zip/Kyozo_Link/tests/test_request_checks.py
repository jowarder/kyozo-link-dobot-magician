"""The app's checks of each step against the words of the request: every mistake the prompt test bench caught the
small model making, refused with the reason; what was asked for, let through.

    python -m unittest discover -s tests -p test_request_checks.py -v
"""
from __future__ import annotations

import unittest

from harness import ROOT  # noqa: F401  (sets up sys.path and the working folder)

from app.hardware.interfaces import Pose
from app.llm.agent import Agent
from app.llm.request_checks import angle_asked, check_step, direction_asked, wants_slow
from app.vision.scene import SceneObject


class Executor:
    """Just enough of ToolExecutor for the checks: the table as listed, the saved places, what is held."""

    def __init__(self, labels, places=("tray",), holding=None):
        self._last_scene = [SceneObject(f"obj_{i}", label, (200.0, 40.0 * i, 20.0), 1.0)
                            for i, label in enumerate(labels)]
        self.places = {name: Pose(280, 0, 0) for name in places}
        self.holding = holding

    def _saved_places(self):
        return self.places

    def _covered_by(self, obj):
        return None

    def id(self, label):
        return next(o.id for o in self._last_scene if o.label == label)


TWO = ("red cube", "blue cube", "green cube")


def check(name, args, prompt, executor, task="other"):
    return check_step(name, args, prompt, executor, task)


class WordTests(unittest.TestCase):
    def test_by_or_at_an_angle(self):
        self.assertEqual(angle_asked("Turn the brown block 45 degrees"), ("by", 45.0))
        self.assertEqual(angle_asked("rotate it by -30°"), ("by", -30.0))
        self.assertEqual(angle_asked("Put the red cube in the tray at 45 degrees"), ("at", 45.0))
        self.assertEqual(angle_asked("Set all the cubes to 30 degrees"), ("at", 30.0))
        self.assertIsNone(angle_asked("Put the cubes in a row, 3 cm apart"))

    def test_directions(self):
        self.assertEqual(direction_asked("Move the red cube 1 inch towards the robot"), "towards")
        self.assertEqual(direction_asked("move it 2 cm closer"), "towards")
        self.assertEqual(direction_asked("Move the blue cube 30 mm forward"), "away")
        self.assertEqual(direction_asked("push it back a bit"), "towards")
        self.assertEqual(direction_asked("Move the red cube 5 cm to the left"), "left")

    def test_slowly(self):
        self.assertTrue(wants_slow("Carefully stack the blue cube on the green cube"))
        self.assertTrue(wants_slow("put it in the tray, gently"))
        self.assertFalse(wants_slow("Put the red cube in the tray"))


class SideTests(unittest.TestCase):
    """The lab, 2026-10-11: asked for the right side of the green cube, the robot put the blue cube on the left."""

    def test_the_side_asked_for_isnt_swapped(self):
        ex = Executor(TWO, holding="blue cube")
        prompt = "pick the blue cube and put in on the right side of green cube 30mm gap"
        refusal = check("place_beside", {"object_id": ex.id("green cube"), "side": "left", "gap_mm": 30}, prompt, ex)
        self.assertIn("asked for it on the right", refusal)
        self.assertIn("tell the user why", refusal)
        self.assertIsNone(check("place_beside", {"object_id": ex.id("green cube"), "side": "right", "gap_mm": 30},
                                prompt, ex))
        self.assertIsNone(check("place_beside", {"object_id": ex.id("green cube"), "side": "left"},
                                "put the blue cube next to the green cube", ex), "no side named: any side")

    def test_further_and_nearer_and_several_sides(self):
        # the study's paper-free tasks (V4.1): "further from / nearer the robot than", and two sides in one request
        ex = Executor(TWO, holding="blue cube")
        green = ex.id("green cube")
        prompt = "Put the blue cube nearer the robot than the green cube, with a 20 mm gap"
        self.assertIsNone(check("place_beside", {"object_id": green, "side": "behind"}, prompt, ex))
        self.assertIn("asked for it on the behind", check("place_beside", {"object_id": green, "side": "front"},
                                                          prompt, ex))
        prompt = ("Put the blue cube further from the robot than the green cube, then put the red cube to the left "
                  "of the green cube")
        self.assertIsNone(check("place_beside", {"object_id": green, "side": "front"}, prompt, ex))
        self.assertIsNone(check("place_beside", {"object_id": green, "side": "left"}, prompt, ex))
        self.assertIn("none of them", check("place_beside", {"object_id": green, "side": "right"}, prompt, ex))


class DirectionTests(unittest.TestCase):
    def test_near_and_far_and_moves_toward_a_relative_place(self):
        # place_beside's own near / far words; and a move_object on the way to "left of the green cube" or a row
        ex = Executor(TWO, holding="blue cube")
        green, red = ex.id("green cube"), ex.id("red cube")
        prompt = "Put the blue cube nearer the robot than the green cube, with a 20 mm gap"
        self.assertIsNone(check("place_beside", {"object_id": green, "side": "near"}, prompt, ex))
        self.assertIsNotNone(check("place_beside", {"object_id": green, "side": "far"}, prompt, ex))
        for prompt in ("Put the red cube to the left of the green cube with a 40 mm gap",
                       "Line up the cubes 30 mm apart: blue, red, green from left to right"):
            self.assertIsNone(check("move_object", {"object_id": red, "direction": "forward", "distance_mm": 20},
                                    prompt, ex), prompt)

    def test_a_tower_goes_nowhere_else_unless_the_request_says_where(self):
        # S-17 in the twin (2026-10-24): built near the base, away from the green cube, though nobody said where
        ex = Executor(TWO)
        ids = [ex.id("green cube"), ex.id("red cube"), ex.id("blue cube")]
        prompt = "Build a tower with the green cube at the bottom, then the red cube, then the blue cube on top."
        self.assertIn("without where", check("build_tower", {"object_ids": ids, "where": "near_base"}, prompt, ex))
        self.assertIsNone(check("build_tower", {"object_ids": ids}, prompt, ex))
        self.assertIsNone(check("build_tower", {"object_ids": ids, "where": "left"},
                                "Build a tower of the three cubes on the left side of the table.", ex))
        self.assertIsNone(check("build_tower", {"object_ids": ids, "place_name": "tray"},
                                "Build a tower of the three cubes in the tray.", ex))
        # V4.3, S-17 in the twin (2026-10-25): the order wrong too, and Qwen gave up ("a location is required"): the
        # refusal says the call to make, in the order the request gives
        wrong = [ex.id("blue cube"), ex.id("green cube"), ex.id("red cube")]
        said = check("build_tower", {"object_ids": wrong, "where": "near_base"}, prompt, ex)
        self.assertIn("so it needs no place", said)
        self.assertIn(f"build_tower(object_ids=[{', '.join(ids)}])", said)

    def test_by_the_tower_with_no_tower_says_so(self):
        # V4.3, S-18 in the twin (2026-10-25): S-17 built no tower; "to the left of the tower" -> beside the green
        # cube, refused five times as not named, the same each time
        ex = Executor(TWO, holding="blue cube")
        ex._pile_of = lambda obj: [obj.label]                     # every cube on the table, none on another
        prompt = "Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap."
        said = check("place_beside", {"object_id": ex.id("green cube"), "side": "left", "gap_mm": 60}, prompt, ex)
        self.assertIn("there is no tower", said)
        self.assertIn("Put the blue cube down where it was (put_back)", said)
        ex._pile_of = lambda obj: ["green cube", "red cube"] if obj.label in ("green cube", "red cube") else [obj.label]
        self.assertIsNone(check("place_beside", {"object_id": ex.id("red cube"), "side": "left", "gap_mm": 60},
                                prompt, ex), "with a tower, its cubes are named by it")

    def test_each_cube_its_own_way_when_the_request_gives_each_one(self):
        # S-05 (twin and Dobot, 2026-10-23): both directions were taken as asked for both cubes -- red was sent
        # forward (asked: nearer), out of reach, and blue back (asked: further), out of the area
        ex = Executor(TWO)
        red, blue = ex.id("red cube"), ex.id("blue cube")
        prompt = "Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot."
        self.assertIn("Use direction 'back'",
                      check("move_object", {"object_id": red, "direction": "forward", "distance_mm": 40}, prompt, ex))
        self.assertIsNone(check("move_object", {"object_id": red, "direction": "back", "distance_mm": 40}, prompt, ex))
        self.assertIn("Use direction 'forward'",
                      check("move_object", {"object_id": blue, "direction": "back", "distance_mm": 40}, prompt, ex))
        self.assertIsNone(check("move_object", {"object_id": blue, "direction": "forward", "distance_mm": 40},
                                prompt, ex))
        # (a part with no colour is the last-named cube's: red's forward leg isn't refused)
        prompt = "Move the red cube 20 mm right and 30 mm forward, and the blue cube 40 mm back."
        self.assertIsNone(check("move_object", {"object_id": red, "direction": "forward", "distance_mm": 30},
                                prompt, ex))
        self.assertIsNotNone(check("move_object", {"object_id": blue, "direction": "forward", "distance_mm": 30},
                                   prompt, ex))

    def test_a_move_in_two_legs_may_go_either_way_it_names(self):
        # "30 mm to the left, then 60 mm to the right": the second leg was refused as "the user asked to move it left"
        ex = Executor(TWO)
        red = ex.id("red cube")
        prompt = "Move the red cube 30 mm to the left, then 60 mm to the right."
        for way in ("left", "right"):
            self.assertIsNone(check("move_object", {"object_id": red, "direction": way, "distance_mm": 30}, prompt, ex))
        self.assertIn("Use direction 'left' or 'right'",
                      check("move_object", {"object_id": red, "direction": "forward", "distance_mm": 30}, prompt, ex))
        prompt = "Move the red cube 30 mm to the right and 20 mm further from the robot."
        self.assertIsNone(check("move_object", {"object_id": red, "direction": "forward", "distance_mm": 20},
                                prompt, ex))
        self.assertIn("Use direction 'left'.", check("move_object", {"object_id": red, "direction": "right",
                                                                     "distance_mm": 5}, "Move it 5 cm to the left", ex))


class StepTests(unittest.TestCase):
    def test_no_yellow_cube_is_said_not_swapped_for_the_red_one(self):
        ex = Executor(TWO)
        refusal = check("pick", {"object_id": ex.id("red cube")}, "Put the yellow cube in the tray", ex)
        self.assertIn("there is no yellow one", refusal)
        self.assertIsNone(check("pick", {"object_id": ex.id("red cube")}, "Put the red cube in the tray", ex))

    def test_a_colour_misspelt_by_a_letter_is_still_that_colour(self):
        # the lab, 2026-10-21: "pick up the bllue cube ... right side of the green cube" was refused as naming only green
        from app.llm.request_checks import named_colours
        self.assertEqual(named_colours("pick up the bllue cube and put it right of the green cube"), ["blue", "green"])
        self.assertEqual(named_colours("the greem one, then the blues"), ["green", "blue"])
        self.assertEqual(named_colours("move it back, then read the red one"), ["red"], "back isn't black")
        self.assertEqual(named_colours("Put the leftmost cube in the tray"), [], "tray isn't gray")
        ex = Executor(TWO)
        self.assertIsNone(check("pick", {"object_id": ex.id("green cube")}, "pick up the gren cube", ex))

    def test_a_colour_not_named_is_refused_on_the_place_too(self):
        ex = Executor(TWO, holding="red cube")
        refusal = check("place_on", {"object_id": ex.id("green cube")}, "Put the red cube on the purple cube", ex)
        self.assertIn("no purple one", refusal)

    def test_a_teal_cube_stands_for_the_green_one_when_no_green_one_is_seen(self):
        # study 3, S-14: the green cube under the blue one was read as teal -- "there is no green one"
        ex = Executor(("blue cube", "red cube", "teal cube"))
        prompt = "Take the tower apart: put the blue cube to the left of the green cube with a 45 mm gap."
        self.assertIsNone(check("pick", {"object_id": ex.id("blue cube")}, prompt, ex))
        ex.holding = "blue cube"
        self.assertIsNone(check("place_beside", {"object_id": ex.id("teal cube")}, prompt, ex))
        # ...but not with a green cube seen too, nor for a colour it isn't near
        both = Executor(("green cube", "teal cube"))
        self.assertIn("wasn't asked for", check("pick", {"object_id": both.id("teal cube")},
                                                "Put the green cube in the tray", both))
        only = Executor(("teal cube",))
        self.assertIn("no red one", check("pick", {"object_id": only.id("teal cube")}, "Put the red cube in the tray",
                                          only))

    def test_a_held_cube_that_was_only_in_the_way_is_told_where_to_go(self):
        # S-19 in the twin, 2026-10-24: holding blue (lifted off red), place_beside it was only "wasn't asked for"
        ex = Executor(TWO, holding="blue cube")
        refusal = check("place_beside", {"object_id": ex.id("blue cube")},
                        "Put the red cube to the right of the green cube with a 50 mm gap.", ex)
        self.assertIn("only in the way", refusal)
        self.assertIn("place_free", refusal)

    def test_all_them_and_no_colours_are_not_checked(self):
        ex = Executor(TWO)
        for prompt in ("Put all the cubes in the tray", "Put the leftmost cube in the tray",
                       "Line up the cubes", "Put them in the tray, red first"):
            self.assertIsNone(check("pick", {"object_id": ex.id("green cube")}, prompt, ex), prompt)

    def test_no_bin_is_said_not_swapped_for_the_tray(self):
        ex = Executor(TWO)
        self.assertIn("there is no place called that",
                      check("place_at", {"place_name": "tray"}, "Put the red cube in the bin", ex))
        self.assertIsNone(check("place_at", {"place_name": "tray"}, "Put the red cube in the tray", ex))
        bins = Executor(TWO, places=("warm bin", "cool bin"))
        self.assertIsNone(check("place_at", {"place_name": "warm bin"}, "warm colours in the warm bin", bins))

    def test_a_tower_in_the_tray_names_the_tray(self):
        ex = Executor(TWO)
        ids = [o.id for o in ex._last_scene]
        self.assertIn("place_name='tray'", check("build_tower", {"object_ids": ids},
                                                 "Build a tower of the three cubes in the tray", ex, "build a tower"))
        self.assertIsNone(check("build_tower", {"object_ids": ids, "place_name": "tray"},
                                "Build a tower of the three cubes in the tray", ex, "build a tower"))
        self.assertIsNone(check("build_tower", {"object_ids": ids}, "Build a tower with all the cubes", ex, "build a tower"))

    def test_out_of_the_tray_is_not_back_into_it(self):
        ex = Executor(TWO, holding="red cube")
        self.assertIn("OUT of the tray", check("place_at", {"place_name": "tray"}, "Take the cube out of the tray", ex))
        self.assertIsNone(check("place_free", {"where": "next_to"}, "Take the cube out of the tray", ex))

    def test_a_tower_outside_the_tray_is_not_built_in_it(self):
        ex = Executor(TWO)
        ids = [o.id for o in ex._last_scene]
        for prompt in ("build a tower with the cube outside of the tray", "the tower should be outside of the tray",
                       "build a tower, not in the tray"):
            self.assertIn("where='outside'", check("build_tower", {"object_ids": ids, "place_name": "tray"}, prompt, ex,
                                                   "build a tower"), prompt)
        self.assertIsNone(check("build_tower", {"object_ids": ids, "where": "outside"},
                                "build a tower with the cube outside of the tray", ex, "build a tower"))

    def test_a_turn_nobody_asked_for(self):
        ex = Executor(TWO, holding="red cube")
        self.assertIn("didn't ask for any turn", check("place_free", {"where": "left", "turn_deg": 0, "angle_deg": 0},
                                                       "Take the cube out of the tray", ex))
        self.assertIsNone(check("place_at", {"place_name": "tray", "angle_deg": 0}, "Put the cube in the tray straight", ex))
        self.assertIsNone(check("place_at", {"place_name": "tray"}, "Put the red cube in the tray", ex))

    def test_nothing_is_picked_for_a_place_that_isnt_there(self):
        # refused only at the place step, the cube was already held, and the model put it down elsewhere
        ex = Executor(TWO)
        self.assertIn("Pick nothing", check("pick", {"object_id": ex.id("red cube")}, "Put the red cube in the bin", ex))
        self.assertIsNone(check("pick", {"object_id": ex.id("red cube")}, "Put the red cube in the tray", ex))
        self.assertIsNone(check("pick", {"object_id": ex.id("red cube")}, "Pick up the red box", ex))

    def test_a_row_in_the_order_named(self):
        ex = Executor(("red cube", "green cube", "purple cube"))
        wrong = [ex.id("purple cube"), ex.id("green cube"), ex.id("red cube")]
        refusal = check("line_up", {"object_ids": wrong}, "Line up red, green and purple from left to right", ex)
        self.assertIn("red, green, purple", refusal)
        right = list(reversed(wrong))
        self.assertIsNone(check("line_up", {"object_ids": right}, "Line up red, green and purple from left to right", ex))
        self.assertIsNone(check("line_up", {"object_ids": wrong}, "Line up red, green and purple from right to left", ex))

    def test_towards_the_robot_is_back(self):
        ex = Executor(TWO)
        args = {"object_id": ex.id("red cube"), "direction": "forward", "distance_mm": 25.4}
        self.assertIn("Use direction 'back'", check("move_object", args, "Move the red cube 1 inch towards the robot", ex))
        args["direction"] = "back"
        self.assertIsNone(check("move_object", args, "Move the red cube 1 inch towards the robot", ex))

    def test_by_an_angle_is_turn_deg_and_at_an_angle_is_angle_deg(self):
        ex = Executor(("brown block",))
        ids = [ex.id("brown block")]
        self.assertIn("turn_deg=45", check("turn_object", {"object_ids": ids, "angle_deg": 45},
                                           "Turn the brown block 45 degrees", ex))
        self.assertIsNone(check("turn_object", {"object_ids": ids, "turn_deg": 45}, "Turn the brown block 45 degrees", ex))
        self.assertIn("angle_deg=30", check("turn_object", {"object_ids": ids, "turn_deg": 30},
                                            "Set the brown block to 30 degrees", ex))


class AgentTests(unittest.TestCase):
    def scripted(self, *messages):
        class Client:
            def __init__(self):
                self.sent = []
                self.replies = list(messages)

            def chat(self, model, messages, tools=None, temperature=0.2):
                self.sent.append([dict(m) for m in messages])
                return self.replies.pop(0) if self.replies else {"role": "assistant", "content": "Done."}
        return Client()

    def test_carefully_slows_the_arm_down_without_the_model(self):
        class Slow(Executor):
            speed = None

            def _tool_set_speed(self, args):
                return "slow"

            def execute(self, name, args):
                self.speed = args["speed"]
                return "The arm moves slowly."
        ex = Slow(TWO)
        run = Agent(self.scripted(), ex, "m").run("Carefully stack the blue cube on the green cube")
        self.assertEqual(ex.speed, "slow")
        self.assertEqual(run.steps[0].tool_name, "set_speed")

    def test_ending_with_something_still_held_is_nudged_to_put_it_down(self):
        ex = Executor(TWO, holding="red cube")
        client = self.scripted({"role": "assistant", "content": "The red cube was taken from the tray."})
        Agent(client, ex, "m").run("Take the cube out of the tray")
        self.assertIn("You are still holding the red cube", client.sent[1][-1]["content"])

    def test_a_reply_saying_it_turned_something_when_nothing_was_turned_is_sent_back(self):
        # the lab: turn_object failed (the cube was held), it was put down unturned, and the reply said "I turned it
        # to a 45-degree angle"
        ex = Executor(TWO)
        client = self.scripted({"role": "assistant", "content": "I placed the red cube near the base. Then, I turned "
                                                                "it to a 45-degree angle."},
                               {"role": "assistant", "content": "The red cube was not turned."})
        run = Agent(client, ex, "m").run("pick the red cube and make the angle similar to the green cube")
        self.assertIn("no tool turned anything", client.sent[1][-1]["content"])
        self.assertEqual(run.final_message, "The red cube was not turned.")

    def test_a_reply_about_a_turn_that_was_done_or_owned_up_to_is_let_through(self):
        from app.llm.agent import AgentStep, claims_turn_not_done
        done = [AgentStep("turn_object", {}, "Turned 1 of 1: the red cube Set at 45° as asked (turned +12°).")]
        self.assertFalse(claims_turn_not_done("The red cube is turned to 45 degrees.", done))
        failed = [AgentStep("turn_object", {}, "ERROR: Already holding the red cube.")]
        self.assertTrue(claims_turn_not_done("I turned it to 45 degrees.", failed))
        self.assertFalse(claims_turn_not_done("I couldn't turn it: the tool said it was held.", failed))
        self.assertFalse(claims_turn_not_done("Put the red cube in the tray.", []))

    def test_a_pick_up_request_may_end_holding_it(self):
        ex = Executor(TWO, holding="red cube")
        client = self.scripted({"role": "assistant", "content": "Holding the red cube."})
        Agent(client, ex, "m").run("Pick up the red cube")
        self.assertEqual(len(client.sent), 1)

    def test_a_refused_step_sent_again_is_told_not_to_repeat_it(self):
        # V4.3, S-18 in the twin (2026-10-25): the same refused place_beside five times, 236 s of the model's time
        ex = Executor(TWO)
        wrong = {"role": "assistant", "content": "", "tool_calls": [
            {"function": {"name": "place_beside", "arguments": {"object_id": ex.id("green cube"), "side": "left"}}}]}
        client = self.scripted(wrong, wrong, {"role": "assistant", "content": "I can't do that."})
        Agent(client, ex, "m").run("Put the red cube to the left of the blue cube")
        first, second = client.sent[1][-1]["content"], client.sent[2][-1]["content"]
        self.assertTrue(first.startswith("ERROR") and "sent exactly this step before" not in first)
        self.assertIn("sent exactly this step before", second)


if __name__ == "__main__":
    unittest.main()

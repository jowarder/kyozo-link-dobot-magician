"""The watcher study's task checker (watcher/tasks.py): the one set of rules that scores a run in the twin and on the
real Dobot. Uses the training tasks only -- the test set lives outside the project and is never read here."""
from __future__ import annotations

import copy
import json
import os
import sys
import unittest
from unittest import mock
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app.vision import paper as _paper  # noqa: E402
_paper.use_paper("a4")          # the design's sheet, whatever config.yaml's study: paper says (the lab: letter)

from watcher.tasks import Cube, angle_difference, load_task_set, match, score  # noqa: E402

# the engine's tests (scoring, zones, the window's run cycle) use the earlier zone-based task file, kept as a fixture;
# the A4 sheet's engine (spots, arrangements, the paper) is tested on the earlier sheet training set, also kept as a
# fixture (SheetTaskTests, SheetWindowTests...); the study's own paper-free file (V4.1) by PaperFreeTaskTests
TRAIN = ROOT / "tests" / "zone_tasks.yaml"
SHEET_TRAIN = ROOT / "tests" / "sheet_tasks.yaml"
STUDY_TRAIN = ROOT / "study" / "tasks" / "train.yaml"
import watcher.window as _window_module  # noqa: E402
_window_module.TRAIN_FILE = TRAIN
# (the engine's tests run training sessions: the menu as it was, opening on Training; the real menu -- the unseen test
# and Simple 20 only -- is checked in test_the_four_choices_greyed_by_mode)
_REAL_MENU = (_window_module.MENU_SETS, _window_module.DEFAULT_SET)
_window_module.MENU_SETS, _window_module.DEFAULT_SET = ("train", "test", "simple"), "train"
# no test ever touches the real results folder or the test set (wherever it is): an empty folder in their place
import tempfile as _tempfile  # noqa: E402
from watcher import results as _results  # noqa: E402
_results.RESULTS_ROOT = Path(_tempfile.mkdtemp(prefix="kyozo_test_results_")) / "Kyozo_Link_Results"



def moved(cubes, label, x=None, y=None, yaw=None, dx=0.0, dy=0.0):
    """A copy of `cubes` with one cube (the first with that label) put somewhere else."""
    out = copy.deepcopy(cubes)
    c = next(c for c in out if c.label == label)
    c.x = x if x is not None else c.x + dx
    c.y = y if y is not None else c.y + dy
    c.yaw = yaw if yaw is not None else c.yaw
    return out


class TaskFileTests(unittest.TestCase):
    def test_both_cube_sets_load_with_two_tasks_per_category(self):
        for cube_set in (3, 6):
            tasks = load_task_set(TRAIN, cube_set)
            self.assertEqual(len(tasks.tasks), 16)
            for category in "ABCDEFGH":
                self.assertEqual(sum(t.category == category for t in tasks.tasks), 2, (cube_set, category))
            for t in tasks.tasks:
                self.assertTrue(t.targets and t.oracle and t.prompt, t.id)
            self.assertEqual(len(tasks.sha256), 64)

    def test_the_cube_sets_differ_only_in_the_sorting_layouts(self):
        three, six = load_task_set(TRAIN, 3), load_task_set(TRAIN, 6)
        self.assertEqual(len(six.task("TR-F1").start), 6)
        self.assertEqual(len(three.task("TR-F1").start), 3)
        self.assertEqual(three.task("TR-A1").start, six.task("TR-A1").start)

    def test_every_layout_cube_is_within_the_arms_reach(self):
        for cube_set in (3, 6):
            for t in load_task_set(TRAIN, cube_set).tasks:
                for c in t.start:
                    r = (c.x ** 2 + c.y ** 2) ** 0.5
                    self.assertTrue(160 <= r <= 300, f"{t.id} {c.label} at {r:.0f} mm")


class ScoringTests(unittest.TestCase):
    def setUp(self):
        self.tasks = load_task_set(TRAIN, 3)
        self.rule, self.zones = self.tasks.rule, self.tasks.zones

    def run_task(self, task_id, end, start=None):
        task = self.tasks.task(task_id)
        return score(task, end, self.zones, self.rule, self.tasks.cube_size_mm, start=start)

    def test_a_cube_in_its_zone_passes_and_one_just_outside_fails(self):
        start = self.tasks.task("TR-A1").start
        self.assertTrue(self.run_task("TR-A1", moved(start, "red cube", x=170, y=160)).passed)
        outside = self.run_task("TR-A1", moved(start, "red cube", x=170, y=205))   # zone A ends at y = 200
        self.assertFalse(outside.passed)
        self.assertAlmostEqual(outside.targets[0].position_error_mm, 5.0, places=1)

    def test_a_relative_move_is_judged_from_where_the_cube_started(self):
        start = self.tasks.task("TR-B1").start                     # blue 4 cm to the left: +40 in y
        self.assertTrue(self.run_task("TR-B1", moved(start, "blue cube", dy=46)).passed)
        self.assertFalse(self.run_task("TR-B1", moved(start, "blue cube", dy=52)).passed)
        self.assertFalse(self.run_task("TR-B1", moved(start, "blue cube", dy=-40)).passed, "the wrong way")

    def test_towards_the_robot_is_along_the_line_to_its_base(self):
        start = self.tasks.task("TR-B2").start                     # green at (200, -60), 30 mm towards the base
        g = next(c for c in start if c.label == "green cube")
        r = (g.x ** 2 + g.y ** 2) ** 0.5
        k = (r - 30) / r
        self.assertTrue(self.run_task("TR-B2", moved(start, "green cube", x=g.x * k, y=g.y * k)).passed)
        k_away = (r + 30) / r
        self.assertFalse(self.run_task("TR-B2", moved(start, "green cube", x=g.x * k_away, y=g.y * k_away)).passed,
                         "away from the robot instead")

    def test_beside_means_the_robots_side_and_the_face_gap(self):
        start = self.tasks.task("TR-C1").start                     # green to the RIGHT (-y) of red, 10 mm apart
        red = next(c for c in start if c.label == "red cube")
        right = moved(start, "green cube", x=red.x, y=red.y - 35)
        self.assertTrue(self.run_task("TR-C1", right).passed)
        left = moved(start, "green cube", x=red.x, y=red.y + 35)
        self.assertFalse(self.run_task("TR-C1", left).passed)

    def test_angles_count_modulo_ninety(self):
        start = self.tasks.task("TR-D1").start                     # red to 30 degrees
        self.assertTrue(self.run_task("TR-D1", moved(start, "red cube", yaw=118)).passed)   # = 28
        self.assertFalse(self.run_task("TR-D1", moved(start, "red cube", yaw=40)).passed)
        self.assertAlmostEqual(angle_difference(359, 1), 2.0)

    def test_a_row_needs_a_straight_line_and_the_asked_gaps(self):
        start = self.tasks.task("TR-E1").start                     # in a row, 3 cm apart: centres 55 mm apart
        good = [Cube("red cube", 220, 55), Cube("blue cube", 220, 0), Cube("green cube", 220, -55)]
        self.assertTrue(self.run_task("TR-E1", good, start=start).passed)
        crooked = [Cube("red cube", 220, 55), Cube("blue cube", 240, 0), Cube("green cube", 220, -55)]
        self.assertFalse(self.run_task("TR-E1", crooked, start=start).passed)
        tight = [Cube("red cube", 220, 40), Cube("blue cube", 220, 0), Cube("green cube", 220, -40)]
        self.assertFalse(self.run_task("TR-E1", tight, start=start).passed)

    def test_a_swap_puts_each_cube_where_the_other_was(self):
        start = self.tasks.task("TR-G1").start
        red, blue = (next(c for c in start if c.label == n) for n in ("red cube", "blue cube"))
        swapped = moved(moved(start, "red cube", x=blue.x, y=blue.y), "blue cube", x=red.x + 4, y=red.y)
        self.assertTrue(self.run_task("TR-G1", swapped).passed)
        self.assertFalse(self.run_task("TR-G1", start).passed)

    def test_a_cube_the_task_doesnt_act_on_must_stay_put(self):
        start = self.tasks.task("TR-A1").start
        done = moved(start, "red cube", x=170, y=160)
        knocked = moved(done, "green cube", dx=15)
        result = self.run_task("TR-A1", knocked)
        self.assertFalse(result.passed)
        self.assertEqual(len(result.collateral), 1)

    def test_a_cube_not_seen_at_the_end_fails_and_is_reported(self):
        start = self.tasks.task("TR-A1").start
        result = self.run_task("TR-A1", [c for c in start if c.label != "red cube"])
        self.assertFalse(result.passed)
        self.assertEqual(result.missing, ["red cube"])

    def test_emptying_a_zone_with_six_cubes(self):
        six = load_task_set(TRAIN, 6)
        task = six.task("TR-H2")
        emptied = moved(moved(task.start, "red cube", x=230, y=60), "blue cube", x=260, y=-20)
        self.assertTrue(score(task, emptied, six.zones, six.rule).passed)
        self.assertFalse(score(task, task.start, six.zones, six.rule).passed)

    def test_all_cubes_of_a_colour_in_a_zone(self):
        six = load_task_set(TRAIN, 6)
        task = six.task("TR-F1")                                   # all the red cubes in zone A
        end = copy.deepcopy(task.start)
        reds = [c for c in end if c.label == "red cube"]
        reds[0].x, reds[0].y = 160, 150
        self.assertFalse(score(task, end, six.zones, six.rule).passed, "only one of two")
        reds[1].x, reds[1].y = 185, 175
        self.assertTrue(score(task, end, six.zones, six.rule).passed)


class ZonePlaceTests(unittest.TestCase):
    """The study's zones are saved places with a size ("area_mm"), so several cubes go in side by side -- without
    one a place is a single spot and the second cube had nowhere to go."""

    def executor(self, folder):
        import json
        from app.llm.tools import ToolExecutor
        ex = object.__new__(ToolExecutor)              # only the place lookups are exercised
        ex.poses_dir, ex.places_provider = Path(folder), None
        ex.place_areas_provider = lambda: {"tray": (72.0, 72.0, 16.0)}
        (Path(folder) / "zone a.json").write_text(json.dumps({"x": 170, "y": 160, "z": 0, "r": 0,
                                                              "area_mm": [80, 80]}), encoding="utf-8")
        (Path(folder) / "home spot.json").write_text(json.dumps({"x": 200, "y": 0, "z": 50, "r": 0}), encoding="utf-8")
        return ex

    def test_a_sized_saved_place_is_a_flat_area_and_still_a_place(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            ex = self.executor(folder)
            places = ex._saved_places()
            self.assertEqual((places["zone a"].x, places["zone a"].y), (170.0, 160.0))
            self.assertIn("home spot", places)
            areas = ex._place_areas()
            self.assertEqual(areas["zone a"], (80.0, 80.0, 0.0))
            self.assertEqual(areas["tray"], (72.0, 72.0, 16.0), "the scene's own trays are kept")
            self.assertNotIn("home spot", areas, "a place without a size stays one spot")
            # a zone's z is the table's: things are let go just above it, whatever is held (a taught pose's z is
            # the tool's own height, as before)
            self.assertIn("zone a", ex._scene_place_names())
            self.assertNotIn("home spot", ex._scene_place_names())


class ResultsFolderTests(unittest.TestCase):
    """Where results go (the Real test switch) and how they're deleted -- in a temporary results folder."""

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)

    def test_the_switch_decides_practice_or_real_and_the_folder_says_what_it_is(self):
        from watcher import results as r
        self.assertEqual(r.kind_folder(True, "train", "twin", 1, self.root), self.root / "study_1" / "Twin_Training_Data")
        self.assertEqual(r.kind_folder(True, "train", "dobot", 2, self.root), self.root / "study_2" / "Dobot_Training_Data")
        self.assertEqual(r.kind_folder(True, "test", "twin", 3, self.root), self.root / "study_3" / "Test_Twin_with_unseen_tasks")
        self.assertEqual(r.kind_folder(True, "test", "dobot", 1, self.root), self.root / "study_1" / "Test_Real_Dobot_with_unseen_tasks")
        self.assertEqual(r.kind_folder(False, "test", "dobot", 1, self.root),
                         self.root / "Practice_Session" / "practice_study_1" / "Test_Real_Dobot_with_unseen_tasks")
        self.assertEqual(r.kind_folder(True, "simple", "twin", 2, self.root), self.root / "study_2" / "20_Tasks_for_Twin")
        self.assertEqual(r.kind_folder(False, "simple", "dobot", 1, self.root),
                         self.root / "Practice_Session" / "practice_study_1" / "20_Tasks_for_Dobot")
        self.assertEqual(r.saved_folder(r.kind_folder(True, "train", "twin", 1, self.root)).name,
                         "User_Saved_Twin_Training_Data")
        self.assertEqual(r.html_folder(r.kind_folder(False, "train", "twin", 2, self.root)).parent.name,
                         "User_Saved_Twin_Training_Data")
        self.assertEqual(r.kind_folder(True, "simple", "dobot", 10, self.root),
                         self.root / "study_10" / "20_Tasks_for_Dobot")      # up to 10 studies (Dr. Curry, 2026-10-26)
        for study in (0, 11):
            with self.assertRaises(ValueError):
                r.kind_folder(True, "train", "dobot", study, self.root)
        for private in ("study_1/Test_Twin_with_unseen_tasks/x",
                        "Practice_Session/practice_study_1/Test_Real_Dobot_with_unseen_tasks",
                        "Private_never_for_Claude/Test_Tasks/test.yaml", "Private_never_for_Claude/Study_Overview",
                        "Private_never_for_Claude", "Backup_do_not_edit/a.zip",
                        "study_1/Twin_Test_Data/x", "Test_Tasks_private/test.yaml"):      # (and the earlier names)
            self.assertTrue(r.is_test_path(self.root / private), private)
        self.assertFalse(r.is_test_path(self.root / "study_1" / "Twin_Training_Data"))
        self.assertFalse(r.is_test_path(self.root / "study_1" / "20_Tasks_for_Dobot"))

    def test_a_run_is_saved_under_its_tag_and_never_over_another(self):
        from watcher import results as r
        s = r.Session.start(True, "train", "twin", 1, "base", {}, root=self.root)
        first = s.run_folder("TR-07", 1)
        self.assertEqual(first.parent.name, "_pending")
        r.write_json(first / "run.json", {"task": "TR-07"})
        self.assertEqual(s.next_tag("TR-07"), "Run1")
        kept = s.save_run(first, "TR-07", "Run 1")
        self.assertEqual(kept, self.root / "study_1" / "Twin_Training_Data" / "_raw_data" / "TR-07_Run1")
        self.assertEqual(s.next_tag("TR-07"), "Run2")
        second = s.run_folder("TR-07", 1)
        r.write_json(second / "run.json", {"task": "TR-07"})
        with self.assertRaises(FileExistsError):
            s.save_run(second, "TR-07", "Run1")
        self.assertIn("saved", (s.folder / "index.jsonl").read_text(encoding="utf-8"))

    def test_a_session_saves_runs_an_index_that_shows_tampering_and_a_backup(self):
        from watcher import results as r
        s = r.Session.start(True, "test", "dobot", 1, "base", {"mode": "normal"}, root=self.root)
        run = s.run_folder("TE-A1", 1)
        r.write_json(run / "run.json", {"passed": True})
        s.record({"run": run.name, "passed": True})
        s.record({"run": "x", "aborted": True})
        s.finish("# summary")
        self.assertTrue(r.verify_index(s.folder))
        self.assertEqual(json.loads((s.folder / "session.json").read_text())["runs"], 1)
        self.assertEqual(len(list((self.root / r.BACKUP).glob("*.zip"))), 1)
        lines = (s.folder / "index.jsonl").read_text().splitlines()
        (s.folder / "index.jsonl").write_text(lines[1] + "\n")           # the first line removed
        self.assertFalse(r.verify_index(s.folder))
        self.assertEqual(list(s.folder.rglob("*.part")), [], "no half-written files left")

    def test_practice_deletes_freely_and_real_needs_a_logged_reason(self):
        from watcher import results as r
        trashed = []
        p = r.Session.start(False, "train", "dobot", 1, "base", {}, root=self.root)
        r.write_json(p.run_folder("TR-A1", 1) / "run.json", {})
        self.assertEqual(r.delete_results(self.root / r.PRACTICE, root=self.root, trash=trashed.append), 1)
        real = r.Session.start(True, "test", "dobot", 1, "base", {}, root=self.root)
        with self.assertRaises(ValueError):
            r.delete_results(real.kind_folder, "", root=self.root, trash=trashed.append)
        r.delete_results(self.root / "study_1", "trial before the real start", root=self.root, trash=trashed.append)
        log = (self.root / r.DELETIONS_LOG).read_text(encoding="utf-8")
        self.assertIn("trial before the real start", log)
        self.assertEqual(len(trashed), 2)
        with self.assertRaises(ValueError):
            r.delete_results(Path(self._tmp.name), "x", root=self.root, trash=trashed.append)   # outside: refused

    @unittest.skipUnless(os.name == "nt", "the Recycle Bin is Windows'")
    def test_deleting_really_goes_to_the_recycle_bin(self):
        from watcher import results as r
        folder = self.root / r.PRACTICE / "throwaway"
        folder.mkdir(parents=True)
        (folder / "run.json").write_text("{}")
        r.to_recycle_bin(folder)
        self.assertFalse(folder.exists())


class MatchingTests(unittest.TestCase):
    def test_cubes_of_one_colour_are_matched_by_least_movement(self):
        wanted = [Cube("red cube", 0, 0), Cube("red cube", 100, 0), Cube("blue cube", 50, 50)]
        seen = [Cube("red cube", 98, 3), Cube("blue cube", 51, 49), Cube("red cube", 2, -1)]
        got = match(wanted, seen)
        self.assertEqual((got[0].x, got[1].x, got[2].x), (2, 98, 51))

    def test_a_cube_missing_from_view_matches_nothing(self):
        got = match([Cube("red cube", 0, 0), Cube("red cube", 100, 0)], [Cube("red cube", 99, 0)])
        self.assertIsNone(got[0])
        self.assertEqual(got[1].x, 99)



class WatcherWindowTests(unittest.TestCase):
    """The watcher window from start to saved run, in the simulated world, with a scripted model in place of Qwen:
    start a practice session, the table check, Start run, the verdict first, the score, the files."""

    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def wait_for(self, window, state, seconds=120):
        import time
        deadline = time.monotonic() + seconds
        while window.state != state and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(0.02)
        self.assertEqual(window.state, state)

    def test_a_practice_run_is_checked_run_scored_and_saved(self):
        import importlib.util
        import tempfile
        from app import robots
        from app.llm.agent import Agent
        from watcher import observe
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-A1"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            agent = Agent(PutInPlaceClient("red cube", "zone a"), twin.executor, "scripted")
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {"seed": 42}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            window.set_box.setCurrentIndex(window.set_box.findData("train"))
            window.start_session()
            self.assertEqual(window.state, "setup")
            self.assertTrue((folder / "poses" / "zone a.json").exists(), "the zones are saved places")
            window._show_setup(window._look(looks=1))
            self.assertTrue(window.run_btn.isEnabled(), window.setup_text.toPlainText())
            window._start_run()
            self.wait_for(window, "verdict")
            self.assertFalse(window.next_btn.isEnabled())
            window._verdict("pass")
            self.assertEqual(window.state, "reveal")
            window._ask_save = lambda task_id, suggested, saved: {"tag": suggested}    # (Save asks for the number)
            window._save_and_next()
            run = next((folder / "results").rglob("run.json"))
            self.assertEqual(run.parent.name, "TR-A1_Run1", "saved under its tag")
            kind = run.parents[2]
            self.assertTrue((kind / "User_Saved_Twin_Training_Data" / "TR-A1_Run1.md").exists())
            self.assertTrue((kind / "User_Saved_Twin_Training_Data" / "HTML_version" /
                             "TR-A1_Run1.html").exists())
            for name in ("FULL_REPORT.md", "FULL_REPORT.html", "full_report.json", "results.xlsx"):
                self.assertTrue((kind / name).exists(), name)
            saved = json.loads(run.read_text(encoding="utf-8"))
            self.assertTrue(saved["passed"], saved.get("score"))
            self.assertTrue(saved["unassisted_pass"])
            self.assertGreater(saved["moves"], 0, "the robot's moves were recorded")
            self.assertGreater(saved["motion"]["travel_mm"], 0, "the motion was measured")
            for key in ("setup_effort", "since_homing", "difficulty", "plan", "time_split", "arrival"):
                self.assertIn(key, saved, key)
            self.assertEqual(saved["observer"]["confidence"], "sure")
            self.assertTrue((run.parent / "picks.csv").exists(), "the per-pick record")
            self.assertEqual(saved["picks"], 1)
            for name in ("observer.json", "moves.csv", "alarms.csv", "start.png", "end.png"):
                self.assertTrue((run.parent / name).exists(), name)
            # the whole run in one file: the task, the result, the time, every event, what happened, the conditions
            report = saved["report"]
            self.assertEqual(report["task"]["prompt"], saved["prompt"])
            self.assertTrue(report["task"]["pass_if"], "what counts as a pass")
            self.assertEqual((report["result"]["watcher"], report["result"]["observer"], report["result"]["agree"]),
                             ("PASS", "Pass", True))
            self.assertIsNotNone(report["time"]["total_s"])
            kinds = {e["kind"] for e in report["events"]}
            self.assertTrue({"step", "move", "gripper"} <= kinds, kinds)
            self.assertTrue(any(e["t"] is not None for e in report["events"]), "the events are timed")
            self.assertIn("pick", report["what_happened"])
            self.assertIn("unassisted pass", report["what_happened"])
            self.assertIn("start.png", report["files"])
            text = (run.parent / "run_report.txt").read_text(encoding="utf-8")
            for heading in ("TASK", "RESULT", "TIME", "EVENTS", "WHAT HAPPENED", "CONDITIONS"):
                self.assertIn(heading, text)
            session = run.parents[2]
            from openpyxl import load_workbook
            book = load_workbook(session / "results.xlsx")
            self.assertEqual(book.sheetnames[:3], ["Runs", "Events", "Summary"])
            runs = list(book["Runs"].iter_rows(values_only=True))
            self.assertEqual(len(runs), 2, "a header and the run")
            self.assertEqual(runs[1][2], "TR-A1")
            self.assertGreater(book["Events"].max_row, 3)
            totals = json.loads((session / "full_report.json").read_text(encoding="utf-8"))["totals"]
            self.assertEqual((totals["runs"], totals["passed"]), (1, 1))
            self.assertIn("RUN REPORT", (session / "FULL_REPORT.md").read_text(encoding="utf-8"))
            # a session saved before the reports existed gets them made from its run.json
            from watcher import report as report_module
            bare = dict(saved)
            bare.pop("report")
            run.write_text(json.dumps(bare), encoding="utf-8")
            (run.parent / "run_report.txt").unlink()
            self.assertEqual(report_module.main([str(session)]), 0)
            self.assertTrue((run.parent / "run_report.txt").exists())
            self.assertIn("report", json.loads(run.read_text(encoding="utf-8")))
            window.end_session("test over")
            self.assertTrue(results_verify(session))
            self.assertIn("Practice_Session", str(session))
            window.close()


def results_verify(folder):
    from watcher.results import verify_index
    return verify_index(folder)


class WatcherTourTests(WatcherWindowTests):
    """The walk-through, watched from the first step to the last in the simulated world."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):   # (run once, in the parent class)
        pass

    def test_watching_every_step_of_the_walk_through(self):
        import importlib.util
        import tempfile
        import time
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-A1"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=Agent(PutInPlaceClient(), twin.executor, "scripted"),
                                 config={"llm": {}}, mode="demo", estop=twin.robot.stop, poses_dir=folder / "poses",
                                 twin_world=twin.world, results_root=folder / "results")
            window = WatcherWindow(ctx)
            tour = window.tour
            window.guide_btn.click()
            self.assertTrue(tour.isVisible() or not window.isVisible())
            self.assertEqual(tour.mode.currentData(), "watch")
            for i, step in enumerate(tour.steps):
                self.assertEqual(tour.index, i)
                tour.do_step()
                deadline = time.monotonic() + 120
                while not step.done(window) and time.monotonic() < deadline:
                    self.app.processEvents()
                    if step.title.startswith("4.") and window.state == "setup":
                        tour.do_step()                # (the table check needs a look after the cubes are out)
                    time.sleep(0.05)
                self.assertTrue(step.done(window), f"{step.title}: {step.todo(window)}")
                tour.tick()
                if i < len(tour.steps) - 1:
                    self.assertTrue(tour.next_btn.isEnabled(), step.title)
                    tour.next_btn.click()
            runs = [p for p in (folder / "results").rglob("run.json") if "For_Claude" not in p.parts]
            self.assertEqual(len(runs), 1)
            package = folder / "results" / "For_Claude" / "Practice_Session" / "practice_study_1"
            self.assertTrue((package / "START_HERE.md").exists(), "the training session's package for Claude")
            tour.close_tour()
            window.close()


class GhostTests(unittest.TestCase):
    """The outlines land where the camera sees the table: a point projected and seen again agree."""

    def test_a_cubes_outline_projects_onto_the_cube_in_the_picture(self):
        import numpy as np
        from watcher.ghost import ghost_marks, square, to_pixel
        from app.hardware.interfaces import Intrinsics
        intr = Intrinsics(fx=600, fy=600, cx=640, cy=360, width=1280, height=720)
        # a camera 600 mm above the point (200, 0), looking straight down: camera x = robot -y, camera y = robot -x
        t = np.array([[0, -1, 0, 200], [-1, 0, 0, 0], [0, 0, -1, 600], [0, 0, 0, 1]], float)
        u, v = to_pixel(t, intr, 200, 0, 0)
        self.assertAlmostEqual(u, 640, places=3)
        self.assertAlmostEqual(v, 360, places=3)
        corners = square(200, 0, 25, 25, 0)
        self.assertEqual(len(corners), 4)
        tasks = load_task_set(TRAIN, 3)
        marks = ghost_marks(tasks.task("TR-A1").start, [True, False, False], tasks.zones, t, intr, 0.0, 25.0)
        self.assertEqual(len(marks), 2 + 3, "two zones and three cubes")
        self.assertEqual(marks[2]["label"], "", "a cube in place is unlabelled (green)")
        self.assertTrue(all(m["kind"] == "poly" and len(m["points"]) == 4 for m in marks))


class DemoTableTests(WatcherWindowTests):
    """In demo mode the watcher shows only the study's red, blue and green cubes, and gives the scene back after."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):   # (run once, in the parent class)
        pass

    def test_opening_the_watcher_leaves_only_red_blue_and_green_and_closing_puts_the_scene_back(self):
        import importlib.util
        import tempfile
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-A1"), tasks)
        self.addCleanup(twin.stop)
        twin.world.add_object({"id": "yellow_cube", "label": "yellow cube", "color_rgba": [0.9, 0.8, 0.1, 1],
                               "size_mm": 25, "position_mm": [230, -120, 12.5]})
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=Agent(PutInPlaceClient(), twin.executor, "s"),
                                 config={"llm": {}}, mode="demo", estop=twin.robot.stop, poses_dir=folder / "p",
                                 twin_world=twin.world, results_root=folder / "r")
            window = WatcherWindow(ctx)
            window.show()
            self.app.processEvents()
            colours = {m["label"].split()[0] for m in twin.world.object_meta.values()}
            self.assertEqual(colours, {"red", "blue", "green"})
            window.close()
            self.app.processEvents()
            self.assertIn("yellow cube", {m["label"] for m in twin.world.object_meta.values()})


class SkipCheckTests(WatcherWindowTests):
    """Starting without the table check is for practice only: hidden and ignored in a real test."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):   # (run once, in the parent class)
        pass

    def test_the_skip_option_is_practice_only(self):
        from watcher.window import WatcherContext, WatcherWindow

        class Nothing:
            def get_intrinsics(self):
                raise RuntimeError("no camera")
        ctx = WatcherContext(robot=None, camera=Nothing(), scene_builder=None, executor=None, agent=None, config={},
                             mode="live", estop=lambda: None, poses_dir=Path("."))
        window = WatcherWindow(ctx)
        window.override.setChecked(True)
        self.assertTrue(window._override_on(), "practice: allowed")
        window.real.blockSignals(True)                 # (no confirmation dialog in a test)
        window.real.setChecked(True)
        window.real.blockSignals(False)
        window._set_state("idle")
        self.assertFalse(window.override.isVisibleTo(window))
        self.assertFalse(window._override_on(), "real test: never")
        window.close()


class ClaudeInputTests(unittest.TestCase):
    """The package for the next improvement round: from training sessions only, saying where its data came from."""

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)

    def session(self, real, set_name, where):
        from watcher import results as r
        s = r.Session.start(real, set_name, where, 1, "base", {}, root=self.root)
        task = "TR-A1" if set_name == "train" else "TE-A1"
        run = s.run_folder(task, 1)
        r.write_json(run / "run.json", {"task": "TR-A1", "category": "A", "prompt": "Put the red cube in zone A.",
                                        "passed": False, "unassisted_pass": False, "failure": "limit_alarm",
                                        "alarms": [{"codes": ["0x22"], "phases": ["moving"], "joints": [1, 2, 3, 4],
                                                    "auto_cleared": True}], "moves": 10})
        s.save_run(run, task, "Run1")
        s.finish()
        return s.kind_folder

    def test_a_real_training_package_has_the_prompt_summary_and_runs(self):
        from watcher import handoff
        folder = self.session(True, "train", "dobot")
        out = handoff.build([folder], 1, "base", root=self.root)
        self.assertEqual(out, self.root / "For_Claude" / "study_1")
        start = (out / "START_HERE.md").read_text(encoding="utf-8")
        self.assertIn("the real Dobot Magician", start)
        self.assertIn("study 1", start)
        self.assertIn("**Your input:** this package", start, "it doesn't send Claude to other folders")
        summary = (out / "SUMMARY.md").read_text(encoding="utf-8")
        self.assertIn("0x22", summary)
        self.assertIn("limit_alarm", summary)
        run = json.loads(next(out.rglob("run.json")).read_text(encoding="utf-8"))
        self.assertIn("real Dobot", run["data_source"])
        self.assertTrue(out.with_suffix(".zip").exists())

    def test_demo_and_twin_practice_are_labelled_practice(self):
        from watcher import handoff
        for where, word in (("twin", "digital twin"),):
            out = handoff.build([self.session(False, "train", where)], 1, "base", root=self.root)
            self.assertEqual(out, self.root / "For_Claude" / "Practice_Session" / "practice_study_1")
            start = (out / "START_HERE.md").read_text(encoding="utf-8")
            self.assertIn(word, start)
            self.assertIn("PRACTICE PACKAGE", start)

    def test_test_sessions_are_refused(self):
        from watcher import handoff
        for real, where in ((True, "dobot"), (False, "dobot")):
            with self.assertRaises(ValueError):
                handoff.build([self.session(real, "test", where)], 1, "base", root=self.root)
        self.assertFalse((self.root / handoff.FOR_CLAUDE).exists() and
                         any((self.root / handoff.FOR_CLAUDE).iterdir()), "nothing was written")


class RefusalTests(unittest.TestCase):
    """Refused steps sorted by why: the model's wasted calls, a safety check saying no, or the robot failing."""

    def test_refusals_are_sorted_by_kind(self):
        from watcher.taxonomy import count_refusals
        out = count_refusals([
            "picked up the red cube",
            "ERROR: Nothing is being held, so there is nothing to put down.",
            "ERROR: Unknown object_id: obj_9. Call list_objects first.",
            "ERROR: Place target (300, 250, 20) is outside the robot's safe workspace.",
            "ERROR: Not putting the red cube down at (280, 240) mm: the camera can't see there",
            "ERROR: The gripper closed on nothing (12 mm): the red cube was not picked up.",
            "ERROR: something new"])
        self.assertEqual((out["total"], out["wasted"], out["guard"], out["robot"], out["other"]), (6, 2, 2, 1, 1))
        self.assertTrue(out["reasons"][0].startswith("wasted: Nothing is being held"))


class MotionTests(unittest.TestCase):
    def test_motion_is_measured_from_the_move_targets(self):
        from watcher.taxonomy import motion_efficiency
        moves = [{"target": {"x": 200, "y": 0, "z": 50, "r": 0}}, {"target": {"x": 200, "y": 0, "z": 20, "r": 30}},
                 {"target": {"x": 240, "y": 30, "z": 20, "r": 10}}]
        m = motion_efficiency(moves, 12.5)
        self.assertEqual(m["moves"], 3)
        self.assertAlmostEqual(m["travel_mm"], 30 + 50, places=1)      # 30 down, then 50 across (40, 30)
        self.assertAlmostEqual(m["wrist_turning_deg"], 30 + 20, places=1)
        self.assertEqual(m["seconds"], 12.5)


class ExtractTests(unittest.TestCase):
    """What the watcher reads out of a run's trace."""

    TRACE = {"turns": [
        {"decided_s": 3.0, "calls": [{"name": "list_objects", "app": {"seconds": 1.5}}]},
        {"decided_s": 2.0, "calls": [{"name": "pick", "args": {"object_id": "obj_1"}, "app": {
            "seconds": 6.0, "safety": [{"what": "red cube", "at": [206, 60, 76], "ok": True}],
            "grip": {"object": "red cube", "r": 0.0, "j4": -16.7, "spare_mm": 2.5, "depth_mm": 12.8},
            "moves": [{"kind": "move", "target": [206, 60, 76, 0], "to": [206, 60, 76, 0]},
                      {"kind": "move", "target": [206, 60, 13, 0], "to": [206, 63, 13, 0]}],
            "result": "picked up the red cube"}}]}]}

    def test_the_perception_offset_grip_arrival_and_time_split(self):
        from watcher import extract
        seen = [Cube("red cube", 200, 60), Cube("blue cube", 240, 0)]
        rows = extract.picks(self.TRACE, seen)
        self.assertEqual(len(rows), 1)
        self.assertAlmostEqual(rows[0]["perception_offset_mm"], 6.0, places=1)
        self.assertEqual(rows[0]["grip_j4"], -16.7)
        self.assertEqual(extract.app_estimates(self.TRACE), {"red cube": (206.0, 60.0)})
        arrival = extract.arrival(self.TRACE)
        self.assertEqual((arrival["moves"], arrival["max_short_mm"], arrival["over_2mm"]), (2, 3.0, 1))
        split = extract.time_split(self.TRACE, 20.0)
        self.assertEqual((split["model_s"], split["camera_s"], split["arm_and_tools_s"], split["other_s"]),
                         (5.0, 1.5, 6.0, 7.5))

    def test_the_plan_fingerprint_tells_the_same_plan_from_a_different_one(self):
        from watcher import extract
        a = extract.plan([{"tool": "list_objects", "args": {}}, {"tool": "pick", "args": {"object_id": "obj_1"}}])
        b = extract.plan([{"tool": "list_objects", "args": {}}, {"tool": "pick", "args": {"object_id": "obj_1"}}])
        c = extract.plan([{"tool": "list_objects", "args": {}}, {"tool": "pick", "args": {"object_id": "obj_2"}}])
        self.assertEqual(a, b)
        self.assertEqual(a["shape"], c["shape"])
        self.assertNotEqual(a["full"], c["full"])

    def test_the_perception_rule_uses_the_offsets(self):
        from watcher.taxonomy import PERCEPTION, RunFacts, classify
        tasks = load_task_set(TRAIN, 3)
        task = tasks.task("TR-A1")
        start = task.start
        end = moved(start, "red cube", x=170, y=215)              # moved, but 15 mm outside zone A
        result = score(task, end, tasks.zones, tasks.rule)
        facts = RunFacts(app_estimates={"red cube": (start[0].x + 9, start[0].y)})
        self.assertEqual(classify(task, result, facts, start, end, seen_start=start), PERCEPTION)

    def test_a_wrong_action_is_a_plan_failure_not_execution(self):
        # (found in the twin: "Swap the green and the red cube" -- pick red, swap refused "already holding", red put
        # in zone A. The cubes were touched, so it was labelled execution; the twin's grip never misses.)
        from watcher.taxonomy import EXECUTION, PLAN, RunFacts, classify
        tasks = load_task_set(TRAIN, 3)
        task = tasks.task("TR-G2")
        start = task.start
        zone_a = tasks.zones["zone_a"]
        end = moved(start, "red cube", x=zone_a.cx, y=zone_a.cy)
        result = score(task, end, tasks.zones, tasks.rule)
        self.assertFalse(result.passed)
        refused = RunFacts(tool_names=["list_objects", "pick", "swap", "place_at"],
                           tool_results=["{...}", "Picked up red cube", "ERROR: Already holding the red cube. Put it "
                                         "down first.", "Placed red cube at (170, 160, 12) mm"])
        self.assertEqual(classify(task, result, refused, start, end, zones=tasks.zones), PLAN)
        self.assertEqual(classify(task, result, RunFacts(), start, end, zones=tasks.zones), PLAN,
                         "a cube left in a zone the task never mentions")
        # the swap refused but then done: the misuse was put right -- a swap off by 15 mm is a placing error
        near = moved(moved(start, "red cube", x=start[2].x + 15, y=start[2].y),
                     "green cube", x=start[0].x, y=start[0].y)
        result = score(task, near, tasks.zones, tasks.rule)
        self.assertFalse(result.passed)
        corrected = RunFacts(tool_names=["swap", "place_free", "swap"],
                             tool_results=["ERROR: Already holding the red cube. Put it down first.", "Put down",
                                           "Swapped"])
        self.assertEqual(classify(task, result, corrected, start, near, zones=tasks.zones), EXECUTION)

    def test_a_zone_named_in_the_task_or_already_full_isnt_off_task(self):
        from watcher.taxonomy import off_task_zone
        tasks = load_task_set(TRAIN, 3)
        zone_a = tasks.zones["zone_a"]
        undo = tasks.task("TR-H1")                      # "Put the red cube in zone A" -> "Put it back"
        left_in_a = moved(undo.start, "red cube", x=zone_a.cx, y=zone_a.cy)
        self.assertFalse(off_task_zone(undo, undo.start, left_in_a, tasks.zones), "zone A is in the step before")
        empty = tasks.task("TR-H2")                     # zone A starts with two cubes in it
        self.assertFalse(off_task_zone(empty, empty.start, empty.start, tasks.zones))
        swap = tasks.task("TR-G1")
        self.assertTrue(off_task_zone(swap, swap.start, moved(swap.start, "blue cube", x=zone_a.cx, y=zone_a.cy),
                                      tasks.zones))


class ReviewRegressionTests(unittest.TestCase):
    """The bugs a review found in the watcher (2026-10-09), each pinned down so it can't come back."""

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)
        self.tasks = load_task_set(TRAIN, 3)

    def test_a_cube_knocked_off_the_table_is_collateral(self):
        task = self.tasks.task("TR-A1")
        done = moved(task.start, "red cube", x=170, y=160)
        result = score(task, [c for c in done if c.label != "green cube"], self.tasks.zones, self.tasks.rule)
        self.assertFalse(result.passed)
        self.assertTrue(any("green cube" in c for c in result.collateral))

    def test_a_target_cube_missing_from_the_start_fails_instead_of_crashing(self):
        for task_id in ("TR-B1", "TR-G1", "TR-H1"):
            task = self.tasks.task(task_id)
            start = [c for c in task.start if c.label not in task.oracle]
            result = score(task, task.start, self.tasks.zones, self.tasks.rule, start=start)
            self.assertFalse(result.passed, task_id)

    def test_the_perception_rule_looks_at_the_nearest_cube_of_that_colour(self):
        from watcher.taxonomy import PERCEPTION, RunFacts, classify
        six = load_task_set(TRAIN, 6)
        task = six.task("TR-F1")                                   # all the red cubes in zone A (two reds)
        reds = [c for c in task.start if c.label == "red cube"]
        end = moved(task.start, "red cube", x=170, y=230)         # moved, but outside zone A
        result = score(task, end, six.zones, six.rule)
        facts = RunFacts(app_estimates={"red cube": (reds[0].x + 1, reds[0].y)})   # 1 mm off the nearest red
        self.assertNotEqual(classify(task, result, facts, task.start, end, seen_start=task.start), PERCEPTION)

    def test_a_truncated_or_damaged_index_is_caught(self):
        from watcher import results as r
        s = r.Session.start(True, "test", "dobot", 1, "base", {}, root=self.root)
        s.record({"run": "01"})
        s.record({"run": "02"})
        s.finish()
        self.assertTrue(r.verify_index(s.folder))
        lines = (s.folder / "index.jsonl").read_text().splitlines()
        (s.folder / "index.jsonl").write_text("\n".join(lines[:-1]) + "\n")      # the last line removed
        self.assertFalse(r.verify_index(s.folder))
        (s.folder / "index.jsonl").write_text("not json\n")
        self.assertFalse(r.verify_index(s.folder))

    def test_deleting_a_real_backup_needs_a_reason_and_is_logged_only_once_done(self):
        from watcher import results as r
        backup = self.root / r.BACKUP
        backup.mkdir(parents=True)
        with self.assertRaises(ValueError):
            r.delete_results(backup, "", root=self.root, trash=lambda p: None)

        def failing(path):
            raise OSError("the Recycle Bin said no")
        with self.assertRaises(OSError):
            r.delete_results(backup, "tidying up", root=self.root, trash=failing)
        self.assertFalse((self.root / r.DELETIONS_LOG).exists(), "nothing logged for a deletion that didn't happen")

    def test_zone_place_files_are_put_back_after_a_session(self):
        from watcher import observe
        poses = Path(self._tmp.name) / "poses"
        poses.mkdir()
        (poses / "zone a.json").write_text('{"x": 1, "y": 2, "z": 3, "r": 0}', encoding="utf-8")
        before = observe.zone_files_before(self.tasks, poses)
        observe.save_zone_places(self.tasks, poses)
        self.assertIn("area_mm", (poses / "zone a.json").read_text(encoding="utf-8"))
        observe.restore_zone_files(before)
        self.assertEqual((poses / "zone a.json").read_text(encoding="utf-8"), '{"x": 1, "y": 2, "z": 3, "r": 0}')
        self.assertFalse((poses / "zone b.json").exists(), "a zone file that wasn't there before is removed")


class WindowReviewTests(WatcherWindowTests):
    """The window's share of the review: a fresh model context per run, a camera failure at the end counted as
    infrastructure, and no ending a session with a run waiting for its verdict."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):   # (run once, in the parent class)
        pass

    def test_each_run_starts_fresh_and_a_failed_end_look_is_infrastructure(self):
        import importlib.util
        import tempfile
        from app import robots
        from app.llm.agent import Agent
        from watcher import observe
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient

        class Recording(PutInPlaceClient):
            def __init__(self):
                super().__init__("red cube", "zone a")
                self.first_messages = []

            def chat(self, model, messages, tools=None, temperature=0.2):
                if sum(m["role"] == "tool" for m in messages) <= 1:     # (the first: only the app's own look, V4.3)
                    self.first_messages.append(json.dumps(messages))
                return super().chat(model, messages, tools, temperature)

        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-A1"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            client = Recording()
            agent = Agent(client, twin.executor, "scripted")
            agent.previous_prompt = "Stack everything in a tower."        # left over from someone typing
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            window.set_box.setCurrentIndex(window.set_box.findData("train"))
            window.start_session()
            deadline = time.monotonic() + 30                  # (Start run works once the table check says READY)
            while not window.run_btn.isEnabled() and time.monotonic() < deadline:
                self.app.processEvents()
                window._show_setup(window._look(looks=1))
                time.sleep(0.05)
            window._start_run()
            self.wait_for(window, "verdict")
            # for the verdict: the task, what counts as a pass, and the zones and start places drawn again
            self.assertFalse(window.judge.isHidden())
            self.assertIn("inside zone A", window.judge.text())
            labels = [o["label"] for o in window._outlines_3d]
            self.assertIn("zone A: red cube goes here", labels)
            self.assertIn("red start", labels)
            self.assertTrue(client.first_messages)
            self.assertNotIn("Stack everything in a tower", client.first_messages[0], "a fresh context per run")
            window.end_session("too early")
            self.assertIsNotNone(window.session, "no ending with a run waiting for its verdict")
            window._outcome["end"] = []                                     # the end look failed
            window._outcome["look_error"] = "camera unplugged"
            runs_before = len(window.plan)
            window._verdict("fail")
            saved = json.loads(next((folder / "results").rglob("run.json")).read_text(encoding="utf-8"))
            self.assertEqual(saved["failure"], "infrastructure")
            # PREREG 5.1: run again at the end of the session; this attempt kept, marked, and not counted
            self.assertEqual(len(window.plan), runs_before + 1)
            self.assertEqual(window.plan[-1][0].id, "TR-A1")
            self.assertTrue(saved["repeated"])
            self.assertIn("done again", window.reveal.text())
            window.end_session("done")
            self.assertIsNone(window.session)
            self.assertFalse((folder / "poses" / "zone a.json").exists(), "the session's zones are taken away")
            window.close()

    def test_e_stop_mid_run_ends_the_run_and_blocks_the_next_until_reset(self):
        # (found in demo: E-STOP stopped the arm, but the model's run went on, the run stayed "running", the window
        # couldn't be closed -- and the main window, closed instead, left the 3D view drawing a world that was gone)
        import importlib.util
        import tempfile
        import math
        import threading
        import time
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient

        thinking, go_on, asked = threading.Event(), threading.Event(), []

        class Slow(PutInPlaceClient):
            def chat(self, model, messages, tools=None, temperature=0.2):
                asked.append(1)
                thinking.set()
                go_on.wait(30)                        # "Qwen" is thinking when E-STOP is pressed
                return super().chat(model, messages, tools, temperature)

        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-A1"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            client = Slow("red cube", "zone a")
            agent = Agent(client, twin.executor, "scripted")
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            window.set_box.setCurrentIndex(window.set_box.findData("train"))
            window.start_session()
            deadline = time.monotonic() + 30                  # (Start run works once the table check says READY)
            while not window.run_btn.isEnabled() and time.monotonic() < deadline:
                self.app.processEvents()
                window._show_setup(window._look(looks=1))
                time.sleep(0.05)
            red_before = twin.world.get_object_position_mm(next(i for i, m in twin.world.object_meta.items()
                                                                 if m["label"] == "red cube"))
            window._start_run()
            deadline = time.monotonic() + 30
            while not thinking.is_set() and time.monotonic() < deadline:
                self.app.processEvents()
                time.sleep(0.02)
            self.assertTrue(thinking.is_set())
            window._estop()
            go_on.set()
            self.wait_for(window, "verdict", seconds=60)
            self.assertEqual(len(asked), 1, "the model isn't asked again after the E-STOP")
            # waiting for the verdict, E-STOP has no run to end, and closing says to give the verdict
            window._estop()
            self.assertIn("the arm is stopped", window.run_text.toPlainText().splitlines()[-1])
            from unittest import mock
            from PyQt6.QtWidgets import QMessageBox
            said = []
            with mock.patch.object(QMessageBox, "warning", staticmethod(lambda *a, **k: said.append(a[2]))):
                self.assertFalse(window.close())
            self.assertIn("waiting for your verdict: press Pass", said[0])
            red_after = twin.world.get_object_position_mm(next(i for i, m in twin.world.object_meta.items()
                                                                if m["label"] == "red cube"))
            self.assertLess(math.dist(red_before[:2], red_after[:2]), 2.0, "nothing moved after the E-STOP")
            window._verdict("fail")
            saved = json.loads(next((folder / "results").rglob("run.json")).read_text(encoding="utf-8"))
            self.assertIn("estop", json.dumps(saved))
            window._next()
            window._show_setup(window._look(looks=1))
            self.assertFalse(window.run_btn.isEnabled(), "no next run while E-STOP is on")
            self.assertIn("E-STOP is on", window.setup_text.toPlainText())
            twin.robot.reset_estop()
            window._show_setup(window._look(looks=1))
            self.assertNotIn("E-STOP is on", window.setup_text.toPlainText())
            window.end_session("done")
            window.close()

    def test_closing_the_main_window_closes_the_watcher_first_and_waits_for_a_run(self):
        import shutil
        import tempfile
        from unittest import mock
        from PyQt6.QtWidgets import QMessageBox
        from app.config import load_config
        from app.ui import main_window as main_window_module
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        shutil.copy(ROOT / "config.yaml", Path(folder.name) / "config.yaml")
        config = load_config()
        config["mode"], config["display"] = "demo", {}
        config["llm"]["manage_memory"] = False
        with mock.patch.object(main_window_module, "PROJECT_ROOT", Path(folder.name)), \
                mock.patch.object(QMessageBox, "warning", staticmethod(lambda *a, **k: None)), \
                mock.patch.object(QMessageBox, "question",
                                  staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)):
            window = main_window_module.MainWindow(config)
            window.show()
            window._open_watcher()
            watcher = window._watcher_window
            # demo: the 3D model is the only view, and the run's pictures are of it, not the simulated camera's
            self.assertFalse(hasattr(watcher, "view_box"))
            self.assertTrue(watcher.view3d.isVisible())
            self.assertEqual(watcher.view3d.receivers(watcher.view3d.table_clicked), 0,
                             "nobody moves the arm by clicking during a study")
            self.assertFalse(watcher.video.isVisible())
            watcher.ctx.results_root = Path(folder.name) / "results"
            watcher.start_session()
            watcher.run_folder = Path(folder.name) / "run"
            watcher.view3d.yaw += 70                                  # turned by hand: the picture isn't
            turned = watcher.view3d.yaw
            watcher._save_picture("start")
            self.assertTrue((watcher.run_folder / "start.png").exists())
            self.assertTrue((watcher.run_folder / "start_depth.npz").exists())
            self.assertEqual(watcher.view3d.yaw, turned, "the view is left as it was turned")
            from PyQt6.QtGui import QImage
            saved = QImage(str(watcher.run_folder / "start.png"))
            self.assertEqual((saved.width(), saved.height()),
                             (watcher.view3d.width(), watcher.view3d.height()), "the 3D model's picture")
            watcher.end_session("test")
            watcher.session, watcher.state = object(), "running"      # a run going
            self.assertFalse(window.close(), "the main window stays open while the watcher's run goes on")
            self.assertTrue(watcher.isVisible())
            watcher.session, watcher.state = None, "idle"
            window.jog_panel.stop_pose_monitor()
            self.assertTrue(window.close())
            self.assertFalse(watcher.isVisible(), "the watcher closes with it")
            self.assertEqual(window._twin_world.snapshot(), [])

    def test_the_3d_view_can_draw_while_the_cubes_are_set_out_on_another_thread(self):
        # (found in demo: "Set the cubes out" swaps the scene on the watcher's thread while the 3D view reads it --
        # "dictionary changed size during iteration")
        import threading
        from app.twin.world import TwinWorld
        world = TwinWorld(gui=False)
        world.start()
        self.addCleanup(world.stop)
        world.load_scenario("two_blocks_and_tray")
        scene = {"name": "study", "places": {}, "objects": [
            {"id": f"cube_{i}", "label": "red cube", "color_rgba": [0.8, 0.1, 0.1, 1], "size_mm": [25, 25, 25],
             "position_mm": [200.0, -60.0 + 30 * i, 12.5]} for i in range(5)]}
        done, errors = threading.Event(), []

        def set_out():
            try:
                for _ in range(60):
                    world.switch_scenario("study", scene)
            except Exception as exc:  # noqa: BLE001
                errors.append(exc)
            done.set()
        threading.Thread(target=set_out, daemon=True).start()
        while not done.is_set():
            try:
                world.snapshot()
            except Exception as exc:  # noqa: BLE001
                errors.append(exc)
                break
        self.assertEqual(errors, [])

    def test_the_3d_view_draws_nothing_once_the_world_is_shut_down(self):
        from app.twin.world import TwinWorld
        world = TwinWorld(gui=False)
        world.start()
        world.load_scenario("two_blocks_and_tray")
        self.assertTrue(world.snapshot())
        world.stop()
        self.assertEqual(world.snapshot(), [])


class InfraRetryTests(unittest.TestCase):
    """PREREG 5.1: an infrastructure failure (Ollama, the camera, the PC) is run again -- in the twin at once."""

    def test_the_twin_runs_an_infrastructure_failure_again_and_counts_the_last_attempt(self):
        import importlib.util
        import tempfile
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        attempts = []

        def fake_run(task, tasks, model, config):
            attempts.append(task.id)
            infra = len(attempts) == 1
            return {"task": task.id, "category": task.category, "passed": not infra, "seconds": 1.0,
                    "failure": "infrastructure" if infra else None, "error": "Ollama timed out" if infra else None}
        with tempfile.TemporaryDirectory() as folder:
            real_start = twin_test.results.Session.start.__func__
            start = classmethod(lambda cls, *a, **k: real_start(cls, *a, **{**k, "root": Path(folder)}))
            with mock.patch.object(twin_test, "run_task", fake_run),                     mock.patch.object(twin_test, "_model_digest", lambda *a: "digest"),                     mock.patch.object(twin_test.results.Session, "start", start),                     mock.patch.object(sys, "argv", ["twin_test", "--version", "base", "--set", "train",
                                                    "--only", "TR-01"]):
                twin_test.main()
            runs = sorted(Path(folder).rglob("run.json"))
            self.assertEqual(attempts, ["TR-01", "TR-01"])
            self.assertEqual(len(runs), 2, "both attempts kept")
            kept = {r.parent.name: json.loads(r.read_text(encoding="utf-8")) for r in runs}
            self.assertEqual(sorted(kept), ["TR-01_Run1", "TR-01_Run1_infra1"], "saved under their tags")
            self.assertTrue(kept["TR-01_Run1_infra1"]["repeated"])
            self.assertFalse(kept["TR-01_Run1"]["repeated"])
            saved = next(Path(folder).rglob("User_Saved_*"))
            self.assertTrue((saved / "TR-01_Run1.md").exists() and (saved / "HTML_version" / "TR-01_Run1.html").exists())
            summary = next(Path(folder).rglob("SESSION_SUMMARY.md")).read_text(encoding="utf-8")
            self.assertIn("| **all** | **1** | **1** |", summary)


class JudgeTests(unittest.TestCase):
    """What counts as a pass, in words, for the person giving the verdict: a line for every target of every task."""

    def test_every_training_task_says_what_a_pass_is(self):
        from watcher.tasks import how_to_judge
        for cube_set in (3, 6):
            tasks = load_task_set(TRAIN, cube_set)
            for task in tasks.tasks:
                lines = how_to_judge(task, tasks.rule)
                self.assertEqual(len(lines), len(task.targets) + 1, task.id)
                self.assertTrue(all(lines), task.id)
                self.assertIn("no other cube moved more than 10 mm", lines[-1])
        tasks = load_task_set(TRAIN, 3)
        self.assertIn("inside zone A", how_to_judge(tasks.task("TR-A1"), tasks.rule)[0])
        self.assertIn("40 mm to the robot's left", how_to_judge(tasks.task("TR-B1"), tasks.rule)[0])
        self.assertIn("30 mm nearer to the robot", how_to_judge(tasks.task("TR-B2"), tasks.rule)[0])

    def test_the_tasks_own_zone_is_highlighted_and_says_what_goes_there(self):
        from watcher.ghost import start_outlines, task_zones
        tasks = load_task_set(TRAIN, 3)
        self.assertEqual(task_zones(tasks.task("TR-A1").targets), {"zone_a": "zone A: red cube goes here"})
        self.assertEqual(task_zones(tasks.task("TR-H2").targets), {"zone_a": "zone A: must end empty"})
        self.assertEqual(task_zones(tasks.task("TR-B1").targets), {})
        task = tasks.task("TR-A1")
        drawn = {o["label"]: o for o in start_outlines(task.start, tasks.zones, 0.0, 25.0,
                                                       highlight=task_zones(task.targets))}
        self.assertGreater(drawn["zone A: red cube goes here"]["fill"], 0)
        self.assertEqual(drawn["zone B"]["fill"], 0)
        self.assertGreater(drawn["zone A: red cube goes here"]["width"], drawn["zone B"]["width"])

    def test_the_3d_view_redraws_when_its_outlines_change(self):
        # (found in demo: the zones drawn again after a run didn't show -- the view redrew only when something moved)
        from app.ui.twin_view import TwinView
        outlines = []
        view = mock.Mock(overlay_provider=lambda: outlines)
        before = TwinView._overlay_key(view)
        outlines.append({"points": [(0, 0, 0), (1, 0, 0), (1, 1, 0)], "colour": (255, 209, 102), "label": "zone A"})
        self.assertNotEqual(TwinView._overlay_key(view), before)


class FinderTests(unittest.TestCase):
    """The watcher's own cube finder against the simulator's exact positions -- crowded, turned, at the edge of reach,
    and three cubes packed into a zone (where the app's detector lost one as a "blue block" and a "purple bar")."""

    def test_a_cube_seen_in_one_look_of_three_is_left_out(self):
        from watcher.finder import merge_looks
        red, blue = Cube("red cube", 200.0, 0.0, 10.0), Cube("blue cube", 240.0, 30.0, 0.0)
        ghost = Cube("green cube", 180.0, -60.0, 0.0)              # a reflection, in one picture only
        merged = merge_looks([[red, blue, ghost], [red, blue], [Cube("red cube", 200.4, 0.2, 89.0), blue]])
        self.assertEqual(sorted(c.label for c in merged), ["blue cube", "red cube"])
        self.assertAlmostEqual(next(c for c in merged if c.label == "red cube").yaw, 10.0 - 0.0, delta=0.01)
        flicker = merge_looks([[red, blue], [red]])                # two looks: one sighting is enough
        self.assertEqual(len(flicker), 2)

    def test_the_finder_sees_every_cube_where_it_is(self):
        import ast
        import importlib.util
        import math
        from app import robots
        from watcher import observe
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(TRAIN, 3)
        for task_id, pack in (("TR-G2", False), ("TR-D2", False), ("TR-A2", False), ("TR-F2", True)):
            twin = twin_test.TwinRun(tasks.task(task_id), tasks)
            try:
                if pack:
                    ids = [o["id"] for o in ast.literal_eval(twin.executor.execute("list_objects", {}))["objects"]]
                    twin.executor.execute("put_all_in", {"place_name": "zone a", "object_ids": ids})
                twin.robot.move_to(twin.executor.look_pose)
                exact = [Cube(m["label"], *twin.world.get_object_position_mm(o)[:2],
                              twin.world.get_object_yaw_deg(o) % 90) for o, m in twin.world.object_meta.items()]
                seen = observe.look_cubes(twin.camera, twin.scene_builder.t_cam_to_robot, 0.0, looks=1)
                self.assertEqual(len(seen), len(exact), f"{task_id}: {seen}")
                for want, got in zip(exact, match(exact, seen)):
                    self.assertIsNotNone(got, f"{task_id}: {want.label} not found")
                    self.assertLess(math.hypot(got.x - want.x, got.y - want.y), 2.0, f"{task_id} {want.label}")
                    self.assertLess(angle_difference(got.yaw, want.yaw), 2.0, f"{task_id} {want.label}")
            finally:
                twin.stop()


import math  # noqa: E402
import numpy as np  # noqa: E402


# ---- the study on the A4 sheet ----------------------------------------------------------------------------------
def render_paper(pose, cubes=(), size=(1280, 720), seed=0):
    """A synthetic camera picture of the A4 sheet (white on a dark cloth) lying at `pose`, with cubes (x, y, rgb) on
    it, seen from in front of and above the robot: (rgb, depth, intrinsics, camera->robot transform)."""
    from types import SimpleNamespace
    from app.vision.paper import PAPER_MM
    w, h = size
    k = SimpleNamespace(fx=690.0, fy=690.0, cx=w / 2.0, cy=h / 2.0)
    eye, target = np.array([560.0, 30.0, 330.0]), np.array([225.0, 0.0, 0.0])
    fwd = (target - eye) / np.linalg.norm(target - eye)
    right = np.cross(fwd, [0.0, 0.0, 1.0])
    right /= np.linalg.norm(right)
    down = np.cross(fwd, right)
    turn = np.stack([right, down, fwd], axis=1)
    transform = np.eye(4)
    transform[:3, :3], transform[:3, 3] = turn, eye
    u, v = np.meshgrid(np.arange(w), np.arange(h))
    rays = np.stack([(u - k.cx) / k.fx, (v - k.cy) / k.fy, np.ones_like(u, float)], axis=-1) @ turn.T
    t = -eye[2] / rays[..., 2]
    px, py = eye[0] + t * rays[..., 0], eye[1] + t * rays[..., 1]
    a = math.radians(pose.turn_deg)
    dx, dy = px - pose.x, py - pose.y
    along_x, along_y = dx * math.cos(a) + dy * math.sin(a), -dx * math.sin(a) + dy * math.cos(a)
    rgb = np.full((h, w, 3), 25, np.uint8)
    rgb[(np.abs(along_x) <= PAPER_MM[1] / 2) & (np.abs(along_y) <= PAPER_MM[0] / 2)] = (235, 235, 230)
    for cx, cy, colour in cubes:
        rgb[(np.abs(px - cx) < 12.5) & (np.abs(py - cy) < 12.5)] = colour
    depth = (t + np.random.default_rng(seed).normal(0.0, 0.8, t.shape)).astype(np.float32)
    return rgb, depth, k, transform


class PaperTests(unittest.TestCase):
    """The A4 sheet: its spots, and the camera finding it."""

    def test_the_spots_are_turned_for_the_wrist_in_its_middle(self):
        from app.hardware.gripper import GripperSpec, plan_grip
        from app.vision.paper import DESIGNED, SPOTS
        for number in SPOTS:
            x, y, turn = DESIGNED.spot(number)
            self.assertAlmostEqual(turn, math.degrees(math.atan2(y, x)), places=6)
            plan = plan_grip(GripperSpec(), x, y, 25.0, 25.0, (25.0, 25.0, turn))
            self.assertAlmostEqual(plan.j4, 0.0, delta=0.5, msg=f"spot {number}: the wrist in its middle")

    def test_the_camera_finds_the_paper_where_it_lies(self):
        from app.vision.paper import PaperPose, find_paper
        truth = PaperPose(231.0, -4.0, 2.0)
        cubes = [(*truth.spot(1)[:2], (200, 30, 30)), (*truth.spot(3)[:2], (30, 40, 200))]
        rgb, depth, k, transform = render_paper(truth, cubes)
        found = find_paper(rgb, depth, k, transform)
        self.assertIsNotNone(found.pose, found.reason)
        self.assertLess(math.hypot(found.pose.x - truth.x, found.pose.y - truth.y), 1.0)
        self.assertAlmostEqual(found.pose.turn_deg, truth.turn_deg, delta=0.3)
        self.assertTrue(found.pose.well_placed())
        self.assertIn("further from the robot", found.pose.describe())

    def test_a_patch_that_isnt_a4_is_refused(self):
        from app.vision import paper
        from app.vision.paper import PaperPose, find_paper
        with mock.patch.object(paper, "PAPER_MM", (200.0, 150.0)):
            rgb, depth, k, transform = render_paper(PaperPose())        # (a smaller white card)
        found = find_paper(rgb, depth, k, transform)
        self.assertIsNone(found.pose)
        self.assertIn("not A4", found.reason)

    def test_a_paper_that_slid_is_noticed(self):
        from app.vision.paper import PaperPose
        found = PaperPose(225.0, 0.0, 0.0)
        self.assertIsNone(PaperPose(226.0, 1.0, 0.3).moved_from(found))
        self.assertIn("moved", PaperPose(229.0, 3.0, 0.0).moved_from(found))
        self.assertFalse(PaperPose(240.0, 0.0, 0.0).well_placed(), "15 mm off: place it again")

    def test_the_printable_sheet(self):
        import importlib.util
        import tempfile
        spec = importlib.util.spec_from_file_location("sheet", ROOT / "study" / "sheet.py")
        sheet = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sheet)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "A4.pdf"
            sheet.write_pdf(path, sheet.draw())
            data = path.read_bytes()
        self.assertTrue(data.startswith(b"%PDF-1.4"))
        self.assertIn(b"/MediaBox [0 0 841.89 595.28]", data, "A4 landscape, exact")
        for words in (b"SPOT 1", b"SPOT 4", b"CENTRE", b"100 mm"):
            self.assertIn(words, data)

    def test_a_us_letter_sheet(self):
        """config.yaml study: paper: letter -- the lab's printers hold US Letter: an A4 page on it measured 278 x 216."""
        from app.vision import paper
        from app.vision.paper import PaperPose, find_paper
        self.addCleanup(paper.use_paper, "a4")
        paper.use_paper("letter")
        self.assertEqual(paper.PAPER_MM, (279.4, 215.9))
        truth = PaperPose(228.0, 3.0, -1.0)
        rgb, depth, k, transform = render_paper(truth)
        found = find_paper(rgb, depth, k, transform)
        self.assertIsNotNone(found.pose, found.reason)
        self.assertLess(math.hypot(found.pose.x - truth.x, found.pose.y - truth.y), 1.0)
        for number in paper.SPOTS:               # the spots where they are on A4: on the paper, with room
            x, y, _ = paper.DESIGNED.spot(number)
            self.assertLess(abs(y) + 12.5, paper.PAPER_MM[0] / 2 - 20)
        paper.use_paper("a4")                    # an A4 page, looked for as Letter: refused, and said so
        rgb, depth, k, transform = render_paper(PaperPose())
        paper.use_paper("letter")
        self.assertIn("not US Letter", find_paper(rgb, depth, k, transform).reason)

    def test_the_printable_letter_sheet(self):
        import importlib.util
        import tempfile
        from app.vision import paper
        self.addCleanup(paper.use_paper, "a4")
        spec = importlib.util.spec_from_file_location("sheet", ROOT / "study" / "sheet.py")
        sheet = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sheet)
        sheet.use("letter")
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "Letter.pdf"
            sheet.write_pdf(path, sheet.draw())
            data = path.read_bytes()
        self.assertIn(b"/MediaBox [0 0 792.00 612.00]", data, "US Letter landscape, exact")
        self.assertIn(b"US Letter", data)


class SheetTaskTests(unittest.TestCase):
    """The study's training tasks on the A4 sheet: the file, the seeded task-safe arrangements, the new target."""

    @classmethod
    def setUpClass(cls):
        cls.tasks = load_task_set(SHEET_TRAIN, 3)

    def test_twenty_tasks_in_five_levels_each_with_arrangements(self):
        from watcher.arrange import count_arrangements
        self.assertEqual(len(self.tasks.tasks), 20)
        self.assertEqual([t.level for t in self.tasks.tasks], [n for n in (1, 2, 3, 4, 5) for _ in range(4)],
                         "four tasks a level, easy to hard")
        self.assertEqual(sum(t.category == "multi" for t in self.tasks.tasks), 7)
        self.assertEqual(sorted(z for z in self.tasks.zones), ["spot_1", "spot_2", "spot_3", "spot_4"])
        for task in self.tasks.tasks:
            self.assertGreater(count_arrangements(task, self.tasks), 0, task.id)
            self.assertLessEqual(len(task.start), 3)

    def test_the_starts_dont_depend_on_the_paper_printed_on(self):
        # (on US Letter's narrower sheet, TR-07 and TR-09 lost a third of their starts and others changed: the starts
        # are the study's design, the same whatever paper the lab has)
        from watcher.arrange import arrange, count_arrangements
        self.addCleanup(_paper.use_paper, "a4")
        on_a4 = {t.id: (count_arrangements(t, self.tasks), arrange(t, self.tasks, "train", 3)[0])
                 for t in self.tasks.tasks}
        _paper.use_paper("letter")
        for task in self.tasks.tasks:
            count, start = on_a4[task.id]
            self.assertEqual(count_arrangements(task, self.tasks), count, task.id)
            self.assertEqual(arrange(task, self.tasks, "train", 3)[0], start, task.id)

    def test_arrangements_are_seeded_and_obey_the_rule(self):
        from watcher.arrange import arrange
        for task in self.tasks.tasks:
            first, info = arrange(task, self.tasks, "train", 1)
            again, _ = arrange(task, self.tasks, "train", 1)
            self.assertEqual([c.__dict__ for c in first], [c.__dict__ for c in again], "the same seed, the same start")
            rule = task.start_rule
            for colour, spot in (rule.get("pin") or {}).items():
                self.assertEqual(info["spots"][colour], int(spot.split("_")[1]), task.id)
            for spot in rule.get("free") or []:
                self.assertNotIn(int(spot.split("_")[1]), info["spots"].values(), task.id)
            for cube in first:                      # on its spot, turned as the spot is printed
                zone = self.tasks.zones[f"spot_{info['spots'][cube.color]}"]
                self.assertAlmostEqual(cube.yaw, zone.yaw)

    def test_each_task_passes_when_done_and_fails_when_not(self):
        from watcher.arrange import arrange, predicted_end
        for task in self.tasks.tasks:
            if task.category == "row":
                continue                              # (where a row goes is the robot's own choice)
            start, _ = arrange(task, self.tasks, "train", 1)
            _, end, _, problem = predicted_end(task, self.tasks, start)
            self.assertIsNone(problem, task.id)
            result = score(task, list(end.values()), self.tasks.zones, self.tasks.rule, self.tasks.cube_size_mm,
                           start=start)
            self.assertTrue(result.passed, f"{task.id}: {result.as_dict()}")
            nothing = score(task, start, self.tasks.zones, self.tasks.rule, self.tasks.cube_size_mm, start=start)
            self.assertFalse(nothing.passed, f"{task.id}: passes without doing anything")

    def test_a_multi_step_task_needs_every_step(self):
        from watcher.arrange import arrange, predicted_end
        task = self.tasks.task("TR-16")              # green 60 mm left of spot 3, then blue 30 mm away from the robot
        start, _ = arrange(task, self.tasks, "train", 1)
        _, end, _, _ = predicted_end(task, self.tasks, start)
        half = moved(list(end.values()), "green cube", dy=-25.0)      # (green 25 mm off its place)
        result = score(task, half, self.tasks.zones, self.tasks.rule, self.tasks.cube_size_mm, start=start)
        self.assertFalse(result.passed)
        self.assertEqual([t.ok for t in result.targets], [False, True])

    def test_from_a_spot_means_the_robots_left_right_and_towards(self):
        from watcher.tasks import from_spot_point
        spot = self.tasks.zones["spot_2"]                 # (265, 80)
        self.assertEqual(from_spot_point(spot, "right", 50.0), (spot.cx, spot.cy - 50.0))
        self.assertEqual(from_spot_point(spot, "left", 50.0), (spot.cx, spot.cy + 50.0))
        self.assertEqual(from_spot_point(spot, "towards", 30.0), (spot.cx - 30.0, spot.cy))   # (along the arrow)

    def test_the_spots_follow_the_paper_as_found(self):
        from app.vision.paper import PaperPose
        from watcher.tasks import how_to_judge
        moved_set = self.tasks.on_paper(PaperPose(230.0, 5.0, 2.0, "camera"))
        spot = moved_set.zones["spot_1"]
        expected = PaperPose(230.0, 5.0, 2.0).spot(1)
        self.assertAlmostEqual(spot.cx, expected[0])
        self.assertAlmostEqual(spot.yaw, expected[2])
        self.assertIn("spot 3", " ".join(how_to_judge(moved_set.task("TR-01"), moved_set.rule)))

    def test_spots_are_saved_as_places_with_room_for_one_turned_cube(self):
        import tempfile
        from watcher import observe
        with tempfile.TemporaryDirectory() as folder:
            names = observe.save_zone_places(self.tasks, Path(folder))
            self.assertEqual(sorted(names), ["spot 1", "spot 2", "spot 3", "spot 4"])
            data = json.loads((Path(folder) / "spot 1.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(data["area_mm"][0], 25.0 * math.sqrt(2), "a cube turned any way fits")
        self.assertLess(data["area_mm"][0], 25.0 * 2 + 5.0, "but never two")


class SheetWindowTests(WatcherWindowTests):
    """The watcher on the A4 sheet, in the twin: the paper drawn, the cubes put on their spots by the run's
    arrangement, a spot task done and scored."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):      # (run once, in the parent class)
        pass

    def test_a_sheet_task_in_the_twin(self):
        import importlib.util
        import tempfile
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(SHEET_TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-01"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN):
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            agent = Agent(PutInPlaceClient("blue cube", "spot 3"), twin.executor, "scripted")
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {"seed": 42}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            window.set_box.setCurrentIndex(window.set_box.findData("train"))
            window.start_session()
            task = window.plan[0][0]
            self.assertEqual(task.id, "TR-01")
            self.assertTrue((folder / "poses" / "spot 3.json").exists(), "the spots are saved places")
            window._show_setup(window._look(looks=1))
            self.assertIn("Put: blue on spot", window.setup_text.toPlainText())
            self.assertTrue(any(o.get("fill") for o in window._outlines_3d), "the paper is drawn")
            self.assertTrue(window.run_btn.isEnabled(), window.setup_text.toPlainText())
            window._start_run()
            self.wait_for(window, "verdict")
            window._verdict("pass")
            run = next((folder / "results").rglob("run.json"))
            saved = json.loads(run.read_text(encoding="utf-8"))
            self.assertTrue(saved["passed"], saved.get("score"))
            self.assertEqual(saved["arrangement"]["seed"], "train|TR-01|1")
            self.assertIn("spot 3", saved["report"]["what_happened"])
            # everything the Model tab shows, in one file per run
            log = (run.parent / "model_log.txt").read_text(encoding="utf-8")
            self.assertIn("TR-01", log)
            self.assertIn("Put the blue cube on spot 3.", log)
            self.assertIn("place", log.lower(), "the tool calls are in it")
            self.assertTrue((run.parent / "model_log.html").read_text(encoding="utf-8").startswith("<html>"))
            window.end_session("test over")
            window.close()


class SpotPickTests(unittest.TestCase):
    """A cube on each corner spot of the A4 sheet, turned as printed, is picked in the twin with the wrist in its
    middle (J4 = 0) and held: the sheet's whole point."""

    def test_each_spot_is_picked_with_the_wrist_in_its_middle(self):
        import ast
        import importlib.util
        from dataclasses import replace
        from app import robots
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(SHEET_TRAIN, 3)
        for number in (1, 2, 3, 4):
            zone = tasks.zones[f"spot_{number}"]
            task = replace(tasks.task("TR-01"), start=[Cube("blue cube", zone.cx, zone.cy, zone.yaw)])
            twin = twin_test.TwinRun(task, tasks)
            try:
                listed = {o["label"]: o for o in
                          ast.literal_eval(twin.executor.execute("list_objects", {}))["objects"]}
                answer = twin.executor.execute("pick", {"object_id": listed["blue cube"]["id"]})
                self.assertTrue(answer.startswith("Picked up blue cube"), f"spot {number}: {answer}")
                self.assertIsNotNone(twin.robot.held_object, f"spot {number}: {twin.robot.last_grip_problem}")
                grip = twin.executor.last_record["grip"]
                self.assertLess(abs(grip["j4"]), 1.0, f"spot {number}: the wrist turned {grip['j4']:.2f} deg")
            finally:
                twin.stop()


import re  # noqa: E402
import time  # noqa: E402


# ---- the study's three rounds: the session menu, the twin as a study place, Save / Discard, Claude's paired input --
class SessionMenuTests(unittest.TestCase):
    """One menu, four kinds of session; the twin's in Demo mode, the Dobot's in Live mode; how many runs each has."""

    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def window(self, mode, twin_world=None):
        from watcher.window import WatcherContext, WatcherWindow

        class Nothing:
            def get_frame(self):
                raise RuntimeError("no camera")

            def get_intrinsics(self):
                raise RuntimeError("no camera")
        ctx = WatcherContext(robot=None, camera=Nothing(), scene_builder=None, executor=None, agent=None, config={},
                             mode=mode, estop=lambda: None, poses_dir=Path("."), twin_world=twin_world)
        window = WatcherWindow(ctx)
        self.addCleanup(window.close)
        return window

    def test_the_four_choices_greyed_by_mode(self):
        for mode, here in (("demo", "twin"), ("live", "dobot")):
            with mock.patch.object(_window_module, "MENU_SETS", _REAL_MENU[0]), \
                    mock.patch.object(_window_module, "DEFAULT_SET", _REAL_MENU[1]):
                window = self.window(mode)
            box = window.session_box
            self.assertEqual([box.itemText(i) for i in range(box.count())],
                             ["Test Twin with unseen tasks", "Test Real Dobot with unseen tasks",
                              "20 Tasks for Twin (by itself)", "20 Tasks for Dobot (by itself)"])
            enabled = {box.itemData(i): box.model().item(i).isEnabled() for i in range(box.count())}
            self.assertEqual({k for k, on in enabled.items() if on}, {f"test_{here}", f"simple_{here}"}, mode)
            self.assertEqual(box.currentData(), f"simple_{here}", "Simple 20 first")
            self.assertEqual(window.set_box.currentData(), "simple")
            box.setCurrentIndex(box.findData(f"test_{here}"))
            self.assertEqual(window.set_box.currentData(), "test", "the set follows the menu")
            window.set_box.setCurrentIndex(window.set_box.findData("simple"))
            self.assertEqual(box.currentData(), f"simple_{here}", "and the menu the set")
            self.assertEqual([window.round_box.itemData(i) for i in range(window.round_box.count())], list(range(1, 11)))
            self.assertEqual(window.round_box.itemText(9), "Study 10 · after update 9 (v9)")
            self.assertTrue(window.verdict_btns["skipped"].isVisibleTo(window), "Simple 20 runs without a verdict")
            box.setCurrentIndex(box.findData(f"test_{here}"))
            self.assertEqual(window.verdict_btns["skipped"].isVisibleTo(window), here == "twin",
                             "the test: only the twin may skip the verdict")

    def test_how_many_runs_each_session_has(self):
        from watcher.window import plan_runs
        tasks = load_task_set(SHEET_TRAIN, 3)
        self.assertEqual([r for _, r in plan_runs(tasks, "train", "dobot")], [1] * 20)
        self.assertEqual([r for _, r in plan_runs(tasks, "train", "twin")], [1] * 20)
        self.assertEqual([r for _, r in plan_runs(tasks, "test", "twin")], [1] * 20)
        dobot = plan_runs(tasks, "test", "dobot")
        self.assertEqual([r for _, r in dobot], [1] * 20 + [2] * 20, "twice on the Dobot: all of repeat 1 first")
        self.assertEqual([t.id for t, _ in dobot[:20]], [t.id for t, _ in dobot[20:]])
        self.assertNotEqual(dobot[0][0].arrangement["seed"], dobot[20][0].arrangement["seed"],
                            "each repeat its own seeded start")


class TwinStudySessionTests(WatcherWindowTests):
    """A real twin training session: scored from the twin's exact positions, the verdict skipped, a run discarded
    and run again, then saved; the files in 4_TRAIN_twin_Claude_reads hold the saved run only."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):      # (run once, in the parent class)
        pass

    def test_a_real_twin_training_session_with_skip_discard_and_save(self):
        import importlib.util
        import tempfile
        from app import robots
        from app.llm.agent import Agent
        from watcher import results as r
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(SHEET_TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-01"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN), \
                mock.patch("watcher.window.QInputDialog.getText", return_value=("the cube was knocked", True)):
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            agent = Agent(PutInPlaceClient("blue cube", "spot 3"), twin.executor, "scripted")
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {"seed": 42}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            window.real.blockSignals(True)                 # (no confirmation dialog in a test)
            window.real.setChecked(True)
            window.real.blockSignals(False)
            window.session_box.setCurrentIndex(window.session_box.findData("train_twin"))
            window.start_session()
            session = window.session.folder                   # (this sitting's record: session.json, its index)
            kind = window.session.kind_folder
            self.assertEqual(kind, folder / "results" / "study_1" / "Twin_Training_Data")
            self.assertEqual(session.parent, kind / "_sessions_log")
            self.assertEqual(window.session.info["where"], "twin")
            self.assertIn("exact", window.session.info["scoring"])
            window._ask_save = lambda task_id, suggested, saved: {"tag": suggested}    # (Save asks for the number)

            def one_run():
                self.wait_for(window, "setup")
                deadline = time.time() + 30
                while not window.run_btn.isEnabled() and time.time() < deadline:
                    self.app.processEvents()
                    window._show_setup(window._look(looks=1))
                self.assertTrue(window.run_btn.isEnabled(), window.setup_text.toPlainText())
                self.assertEqual(window.status.kind, "waiting", "by hand: the status strip says it is your turn")
                self.assertIn("press Start run", window.status.sub.text())
                window._start_run()
                deadline = time.time() + 30            # (a table check still looking: it starts a moment later)
                while window.state == "setup" and time.time() < deadline:
                    self.app.processEvents()
                    time.sleep(0.02)
                self.assertEqual(window.status.kind, "running")
                self.assertRegex(window.status.head.text(), r"^Running task \d+ of \d+ · TR-01$")
                self.assertIn("last activity", window.status.sub.text())
                self.assertRegex(window.windowTitle(), r"^Kyozo Watcher · running \d+/\d+$")
                self.wait_for(window, "verdict")
                self.assertEqual(window.status.kind, "waiting")
                self.assertIn("Give your verdict", window.status.sub.text())
                window._verdict("skipped")
                self.assertEqual(window.state, "reveal")
                self.assertIn("the twin scored itself", window.reveal.text())
                self.assertIn("Save ▶ next", window.status.sub.text())
                return window.run_folder

            first = one_run()
            self.assertEqual(first.parent, kind / "_raw_data" / "_pending", "scored, waiting for Save or Discard")
            self.assertTrue((first / "run_report.txt").exists() and (first / "model_log.txt").exists())
            window._discard_and_again()
            self.assertFalse(first.exists(), "the discarded run is gone")
            binned = list((folder / "results" / "Recycle_Bin" / "study_1" / "Twin_Training_Data").glob(
                f"{first.name}__discarded_*"))
            self.assertEqual(len(binned), 1, "kept, whole, in the results' Recycle_Bin")
            self.assertTrue((binned[0] / "run.json").exists())
            self.assertIn("the cube was knocked", (binned[0] / "why.txt").read_text(encoding="utf-8"))
            self.assertEqual(window.plan[window.index][0].id, "TR-01", "the same task again")
            log = (folder / "results" / r.DELETIONS_LOG).read_text(encoding="utf-8")
            self.assertIn("the cube was knocked", log)
            one_run()
            window._save_and_next()
            second = kind / "_raw_data" / "TR-01_Run1"
            saved = json.loads((second / "run.json").read_text(encoding="utf-8"))
            self.assertTrue(saved["saved"])
            self.assertEqual(saved["tag"], "Run1")
            self.assertIn("report", saved, "saving keeps the run's report in run.json")
            self.assertTrue(saved["passed"], saved.get("score"))
            self.assertEqual(saved["observer"]["verdict"], "skipped")
            self.assertEqual(saved["cube_size_mm"], 25.0, "each run records its cubes' size")
            self.assertEqual(window.session.info["cube_size_mm"], 25.0, "and so does the session")
            self.assertEqual(saved["arrangement"]["seed"], "train|TR-01|1", "the rerun from the same start")
            md = kind / "User_Saved_Twin_Training_Data" / "TR-01_Run1.md"
            page = kind / "User_Saved_Twin_Training_Data" / "HTML_version" / "TR-01_Run1.html"
            self.assertTrue(md.exists() and page.exists(), "the run's own file, and its web page")
            self.assertIn("data:image/png;base64,", page.read_text(encoding="utf-8"), "its pictures built in")
            run_md = md.read_text(encoding="utf-8")
            self.assertIn("Put the blue cube on spot 3.", run_md)
            for words in ("Wanted (x, y) mm", "Ended (x, y) mm", "(265.0, -80.0)",       # where it had to go
                          "### Where the cubes were", "Seen at the start", "Seen at the end",
                          "### What the app saw", "| blue cube |"):
                self.assertIn(words, run_md)
            window.end_session("test over")
            self.assertEqual(window.status.kind, "ended", "ended before its last task: red, and why")
            self.assertTrue(window.status.head.text().startswith("Ended early after 1 of "), window.status.head.text())
            self.assertIn("Why: test over · 1 run saved in study_1 / Twin_Training_Data", window.status.sub.text())
            self.assertEqual(window.windowTitle(), "Kyozo Watcher · ended early")
            index = [json.loads(line) for line in (session / "index.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual([e.get("discarded") for e in index if e.get("discarded")], [first.name])
            self.assertEqual([e.get("saved") for e in index if e.get("saved")], ["TR-01_Run1"])
            self.assertTrue(r.verify_index(session), "the chain stays whole through the discard")
            runs = [p for p in (kind / "_raw_data").glob("*/run.json")]
            self.assertEqual(len(runs), 1, "only the saved run")
            full = (kind / "FULL_REPORT.md").read_text(encoding="utf-8")
            self.assertIn("`TR-01_Run1`", full)
            self.assertIn(f"| {first.name} | the cube was knocked |", full, "the discarded run listed, with why")
            self.assertIn("App · turn 1", full, "the app's own look first (V4.3)")
            self.assertIn("Model · turn 2", full, "every step the model took")
            for words in ("### Motion (speed, distance, joints)", "Every move:", "Speed mm/s", "Gripper:",
                          "### The model's turns", "Tokens read", "Which way", "seed `train|TR-01|1`",
                          "## Where the cubes ended (bias)", "Plan (tools in order):", "the gripper settles"):
                self.assertIn(words, full)
            html = (kind / "FULL_REPORT.html").read_text(encoding="utf-8")
            self.assertIn("User_Saved_Twin_Training_Data/HTML_version/TR-01_Run1.html", html, "each run linked")
            data = json.loads((kind / "full_report.json").read_text(encoding="utf-8"))
            self.assertEqual(data["totals"]["runs"], 1, "the saved run only")
            run_data = data["runs"][0]
            moves = run_data["motion_detail"]["moves"]
            self.assertTrue(moves and all(m["distance_mm"] is not None and m["seconds"] is not None for m in moves))
            self.assertTrue(any(m["speed_mm_s"] for m in moves), "each move's speed")
            self.assertTrue(any(m["speed_set_mm_s"] for m in moves), "and the speed asked for")
            self.assertGreater(run_data["motion_detail"]["totals"]["distance_mm"], 100.0, "the run's whole distance")
            self.assertTrue(run_data["motion_detail"]["gripper"], "every gripper action, timed")
            self.assertTrue(run_data["model_turns"]["turns"], "every model turn")
            self.assertEqual(run_data["app_views"][0]["label"], "blue cube", "what the app saw, as data")
            self.assertEqual(run_data["watcher_views"][0]["cube"], "blue cube")
            target = run_data["run"]["score"]["targets"][0]
            self.assertEqual(target["cube"], "blue cube")
            self.assertIsNotNone(target["dx_mm"], "which way it was off")
            self.assertTrue((kind / run_data["trace_file"]).exists(), "the model's whole record, by its file")
            self.assertTrue((second / "end_marked.png").exists(), "the end picture with the target drawn")
            self.assertTrue((second / "gripper.csv").exists())
            self.assertIn("speed_mm_s", (second / "moves.csv").read_text(encoding="utf-8").splitlines()[0])
            for name in ("runs", "moves", "gripper", "picks", "alarms", "model_turns"):
                self.assertTrue((kind / f"results_{name}.csv").exists(), name)
            from openpyxl import load_workbook
            sheets = load_workbook(kind / "results.xlsx").sheetnames
            for name in ("Runs", "Measurements", "Moves", "Gripper", "Model turns"):
                self.assertIn(name, sheets)
            self.assertIn("arm_speed_now_mm_s", json.dumps(data["settings"].get("settings")))
            statuses = [window._plan_status[i] for i in range(2)]               # the plan saw it all
            self.assertEqual(statuses, ["Discarded", "Pass · 100 Full · saved Run1"])
            self.assertTrue(list((folder / "results" / "Backup_do_not_edit").glob("*.zip")), "a real kind's backup")
            window.close()


class PairedInputTests(unittest.TestCase):
    """Claude's input pairs the round's twin and Dobot training task by task; test results never go in."""

    def setUp(self):
        import tempfile
        from unittest import mock
        from watcher import handoff
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)
        notes = mock.patch.object(handoff, "NOTES", Path(self._tmp.name) / "no_notes")   # (not the project's own)
        notes.start()
        self.addCleanup(notes.stop)

    def session(self, where, passes, round_no=1, version="base", set_name="train"):
        from watcher import results as r
        s = r.Session.start(True, set_name, where, round_no, version, {}, root=self.root)
        for task, ok in passes.items():
            run = s.run_folder(task, 1)
            r.write_json(run / "run.json", {"task": task, "category": "spot", "prompt": "Put it on spot 3.",
                                            "passed": ok, "unassisted_pass": ok, "failure": None if ok else "wrong_place",
                                            "moves": 4})
            s.save_run(run, task, "Run1")
        s.finish()
        return s.kind_folder

    def test_twin_and_dobot_paired_task_by_task(self):
        from watcher import handoff
        self.session("twin", {"TR-01": True, "TR-02": True, "TR-03": False, "TR-04": False})
        self.session("dobot", {"TR-01": True, "TR-02": False, "TR-03": False, "TR-04": True})
        self.session("dobot", {"TR-05": False}, set_name="test")          # (a test session: never picked up)
        sessions = handoff.study_sessions(1, True, root=self.root)
        self.assertEqual([handoff._side(s) for s in sessions], ["twin", "dobot"])
        out = handoff.build(sessions, 1, "base", root=self.root)
        summary = (out / "SUMMARY.md").read_text(encoding="utf-8")
        self.assertIn("Twin vs Dobot, task by task", summary)
        for task, kind in (("TR-01", "fine"), ("TR-02", "**hardware**"), ("TR-03", "**software or plan**"),
                           ("TR-04", "noise")):
            self.assertRegex(summary, rf"\| {task} \| [01]/1 \| [01]/1 \| {re.escape(kind)}")
        self.assertNotIn("TR-05", summary, "the test session isn't in it")
        kinds = sorted(p.name for p in out.iterdir() if p.is_dir())
        self.assertEqual(kinds, ["Dobot_Training_Data", "Twin_Training_Data"], "named as their folders in study_1")
        runs = sorted(out.glob("*/runs/*/run.json"))
        self.assertEqual(len(runs), 8)
        sources = {json.loads(p.read_text(encoding="utf-8"))["data_source"] for p in runs}
        self.assertEqual(len(sources), 2, "each run says where it came from")
        self.assertIn("`Twin_Training_Data\\`", (out / "START_HERE.md").read_text(encoding="utf-8"))
        for kind in kinds:                                # each session's whole story, in one file
            self.assertIn("# Full report", (out / kind / "FULL_REPORT.md").read_text(encoding="utf-8"))
            self.assertTrue((out / kind / "full_report.json").exists())

    def test_the_20_tasks_go_in_named_as_the_menu_and_the_unseen_test_never(self):
        from watcher import handoff
        self.session("twin", {"S-01": True, "S-02": False}, set_name="simple")
        self.session("dobot", {"S-01": False, "S-02": False}, set_name="simple")
        self.session("dobot", {"T-01": True}, set_name="test")             # (the unseen test: never picked up)
        out = handoff.build(handoff.study_sessions(1, True, root=self.root), 1, "base", root=self.root)
        self.assertEqual(out, self.root / "For_Claude" / "study_1")
        self.assertEqual(sorted(p.name for p in out.iterdir() if p.is_dir()),
                         ["20_Tasks_for_Dobot", "20_Tasks_for_Twin"])
        self.assertTrue((out / "20_Tasks_for_Dobot" / "runs" / "S-01_Run1" / "run.json").exists())
        summary = (out / "SUMMARY.md").read_text(encoding="utf-8")
        self.assertRegex(summary, r"\| S-01 \| 1/1 \| 0/1 \| \*\*hardware\*\*")
        self.assertNotIn("T-01", summary)
        self.assertTrue((self.root / "For_Claude" / "study_1.zip").exists())

    def test_skips_logged_before_v42_and_the_engineers_notes_go_in(self):
        import tempfile
        from unittest import mock
        from watcher import handoff, results as r
        s = r.Session.start(True, "simple", "twin", 1, "base", {}, root=self.root)
        run = s.run_folder("S-05", 1)
        r.write_json(run / "run.json", {"task": "S-05", "category": "move", "prompt": "Move it.", "passed": False,
                                        "failure": "limit_alarm", "sitting": s.folder.name,
                                        "end_seen": [{"label": "blue cube", "x": 150.0, "y": -70.0}]})
        s.save_run(run, "S-05", "Run1")
        for task in ("S-06", "S-07"):                     # (before V4.2: a skip was only a line in the index)
            s.record({"skipped": task, "repeat": 1, "why": "Move the blue cube further from the robot.",
                      "seen": [{"label": "blue cube", "x": 150.0, "y": -70.0}]})
        s.finish()
        with tempfile.TemporaryDirectory() as notes:
            (Path(notes) / "study_1").mkdir()
            (Path(notes) / "study_1" / "why_S06_on_were_skipped.md").write_text("# The blue cube was out", "utf-8")
            with mock.patch.object(handoff, "NOTES", Path(notes)):
                out = handoff.build(handoff.study_sessions(1, True, root=self.root), 1, "base", root=self.root)
        summary = (out / "SUMMARY.md").read_text(encoding="utf-8")
        self.assertIn("## Skipped before V4.2 (from the sessions' logs)", summary)
        self.assertIn("skipped before V4.2 (logged only): 2", summary)
        self.assertRegex(summary, r"\*\*S-06\*\* · Move the blue cube further from the robot\. · the camera saw: "
                                  r"blue cube \(150\.0, -70\.0\).* · the run saved last before it: `S-05_Run1`, FAIL "
                                  r"\(limit_alarm\)")
        logged = json.loads((out / "skipped_before_v4.2.json").read_text(encoding="utf-8"))
        self.assertEqual([x["task"] for x in logged], ["S-06", "S-07"])
        self.assertTrue((out / "notes" / "why_S06_on_were_skipped.md").exists(), "the engineer's report, as written")
        start = (out / "START_HERE.md").read_text(encoding="utf-8")
        self.assertIn("notes\\", start)
        self.assertIn("isn't yours to change", start)

    def test_round_two_gets_the_previous_rounds_summary(self):
        from watcher import handoff
        handoff.build([self.session("dobot", {"TR-01": False})], 1, "base", root=self.root)
        out = handoff.build([self.session("dobot", {"TR-01": True}, round_no=2, version="v1")], 2, "v1",
                            root=self.root)
        self.assertIn("Study 1 summary", (out / "PREVIOUS_SUMMARY.md").read_text(encoding="utf-8"))
        self.assertIn("PREVIOUS_SUMMARY.md", (out / "START_HERE.md").read_text(encoding="utf-8"))

    def test_a_test_session_among_them_is_refused(self):
        from watcher import handoff
        twin = self.session("twin", {"TR-01": True})
        test = self.session("dobot", {"TE-01": True}, set_name="test")
        with self.assertRaises(ValueError):
            handoff.build([twin, test], 1, "base", root=self.root)


class CheckTasksTests(unittest.TestCase):
    """study/check_tasks.py: the private test set checked without its tasks ever being printed."""

    def setUp(self):
        import importlib.util
        import tempfile
        spec = importlib.util.spec_from_file_location("check_tasks", ROOT / "study" / "check_tasks.py")
        self.ct = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.ct)
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.folder = Path(self._tmp.name)

    def test_a_good_set_passes(self):
        # (the training set stands in for a test set here: compared with an empty "training" set, it is new)
        empty = self.folder / "empty.yaml"
        empty.write_text("pass_rule: {position_mm: 10, angle_deg: 8, collateral_mm: 10}\ntasks: []\n", encoding="utf-8")
        with mock.patch.object(self.ct, "TRAIN_FILE", empty), mock.patch.object(self.ct, "TEMPLATE_FILE", empty):
            problems, counts = self.ct.check(SHEET_TRAIN)
        self.assertEqual(problems, [])
        self.assertEqual(counts["multi"], 7)

    def test_a_radial_move_is_refused(self):
        # towards/away from the robot is dx along the sheet's arrow; a test task written with radial is caught
        import yaml
        data = yaml.safe_load(SHEET_TRAIN.read_text(encoding="utf-8"))
        data["tasks"][5]["targets"] = [{"moved": {"cube": "blue cube", "radial": -30}}]
        changed = self.folder / "radial.yaml"
        changed.write_text(yaml.safe_dump(data), encoding="utf-8")
        empty = self.folder / "empty.yaml"
        empty.write_text("pass_rule: {position_mm: 10, angle_deg: 8, collateral_mm: 10}\ntasks: []\n", encoding="utf-8")
        with mock.patch.object(self.ct, "TRAIN_FILE", empty), mock.patch.object(self.ct, "TEMPLATE_FILE", empty):
            problems, _ = self.ct.check(changed)
        self.assertTrue(any("uses radial" in p for p in problems), problems)

    def test_problems_are_named_without_the_tasks_content(self):
        import contextlib
        import io
        bad = self.folder / "test.yaml"
        bad.write_text("""
set: test
cube_size_mm: 25
cube_sets: [3]
sheet: a4
pass_rule: {position_mm: 10, angle_deg: 8, collateral_mm: 10}
tasks:
  - id: TE-01
    category: spot
    start: {cubes: [blue]}
    prompt: "Secret wording about the purple elephant 137 mm away."
    targets: [{in_zone: {cube: red cube, zone: spot_7}}]
  - id: TE-01
    category: dance
    start: {cubes: [red, blue, green]}
    prompt: "Another secret, 211 mm."
    targets: [{teleport: {cube: red cube}}]
  - id: TE-03
    category: move
    start: {cubes: [red, blue, green]}
    prompt: "Move the red cube 40 mm to the left."
    targets: [{moved: {cube: blue cube}}]
""", encoding="utf-8")
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            code = self.ct.main([str(bad)])
        text = out.getvalue()
        self.assertEqual(code, 1)
        for words in ("names a cube the start doesn't have", "names a spot that doesn't exist", "used twice",
                      "unknown category", "unknown target kind", "misses dx or dy",
                      "same prompt as a training task", "3 tasks (the study has 20)"):
            self.assertIn(words, text)
        for secret in ("elephant", "137", "211", "teleport", "spot_7", "Secret"):
            self.assertNotIn(secret, text, "nothing of the tasks themselves is printed")


class ModelLogAndDeleteTests(unittest.TestCase):
    """The per-run model log, and deleting real results without ever taking the test tasks."""

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.folder = Path(self._tmp.name)

    def test_a_run_that_stopped_part_way_still_gets_its_steps(self):
        from watcher import model_log
        self.assertIsNone(model_log.write_model_log(self.folder, [], header="TR-02 · run 2 of 16",
                                                    steps=[{"tool": "pick", "args": {"object_id": "obj_1"},
                                                            "result": "Picked up blue cube"}]))
        text = (self.folder / "model_log.txt").read_text(encoding="utf-8")
        for words in ("TR-02 · run 2 of 16", "stopped part-way", "pick", "Picked up blue cube"):
            self.assertIn(words, text)

    def test_deleting_all_real_results_keeps_the_test_tasks(self):
        import shutil
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        self.app = QApplication.instance() or QApplication([])
        from watcher import results as r
        from watcher.window import DeleteDialog
        root = self.folder / "Kyozo_Link_Results"
        session = r.Session.start(True, "train", "dobot", 1, "base", {}, root=root)
        r.write_json(session.run_folder("TR-01", 1) / "run.json", {"task": "TR-01"})
        tasks = root / r.TEST_TASKS / "test.yaml"
        tasks.parent.mkdir(parents=True)
        tasks.write_text("tasks: []\n", encoding="utf-8")
        dialog = DeleteDialog(root=root)
        self.addCleanup(dialog.close)
        dialog._trash = shutil.rmtree
        answers = iter([("DELETE", True), ("starting the study again", True)])
        with mock.patch("watcher.window.QInputDialog.getText", side_effect=lambda *a, **k: next(answers)), \
                mock.patch("watcher.window.QMessageBox.information"):
            dialog._all_real()
        self.assertFalse((root / "study_1").exists(), "the study's results are gone")
        self.assertTrue(tasks.exists(), "the test tasks stay")
        self.assertIn("starting the study again", (root / r.DELETIONS_LOG).read_text(encoding="utf-8"))
        with mock.patch("watcher.window.QFileDialog.getExistingDirectory", return_value=str(root / r.TEST_TASKS)), \
                mock.patch("watcher.window.QMessageBox.warning") as warned:
            dialog._pick()
        warned.assert_called_once()
        self.assertTrue(tasks.exists(), "picking the folder that holds them is refused")


class ReviewTwoFixesTests(unittest.TestCase):
    """Fixes from the second review of the watcher (2026-10-12)."""

    @classmethod
    def setUpClass(cls):
        cls.tasks = load_task_set(SHEET_TRAIN, 3)

    def test_a_cube_only_to_be_turned_must_stay_where_it_was(self):
        from watcher.arrange import arrange, predicted_end
        task = self.tasks.task("TR-15")                 # blue to spot 4, then turn the red cube to 0 degrees
        start, _ = arrange(task, self.tasks, "train", 1)
        _, end, _, _ = predicted_end(task, self.tasks, start)
        good = score(task, list(end.values()), self.tasks.zones, self.tasks.rule, 25.0, start=start)
        self.assertTrue(good.passed, good.as_dict())
        red = end["red cube"]
        dropped = [c if c.label != "red cube" else Cube("red cube", 225.0, 0.0, red.yaw) for c in end.values()]
        bad = score(task, dropped, self.tasks.zones, self.tasks.rule, 25.0, start=start)
        self.assertFalse(bad.passed, "turned, but put down 90 mm away")
        self.assertIn("only to be turned", " ".join(bad.collateral))

    def test_the_start_doesnt_depend_on_where_the_paper_was_found(self):
        from app.vision.paper import PaperPose
        from watcher.arrange import arrange
        for pose in (PaperPose(221.0, 0.0, 0.0), PaperPose(222.0, 2.0, 0.5), PaperPose(221.0, 4.0, 0.0),
                     PaperPose(229.0, -4.0, -2.0)):
            found = self.tasks.on_paper(pose)
            for task in self.tasks.tasks:
                for repeat in (1, 2):
                    _, designed = arrange(task, self.tasks, "test", repeat)
                    _, here = arrange(found.task(task.id), found, "test", repeat)
                    self.assertEqual(designed["spots"], here["spots"], f"{task.id} r{repeat} at {pose}")

    def test_two_targets_saying_where_one_cube_ends_are_refused(self):
        from dataclasses import replace
        from watcher.arrange import count_arrangements
        task = replace(self.tasks.task("TR-01"), targets=[{"in_zone": {"cube": "blue cube", "zone": "spot_3"}},
                                                          {"moved": {"cube": "blue cube", "radial": -30}}])
        self.assertEqual(count_arrangements(task, self.tasks), 0)

    def test_towards_and_away_from_the_robot_are_along_the_sheets_arrow(self):
        from watcher.tasks import from_spot_point
        spot = self.tasks.zones["spot_1"]
        self.assertEqual(from_spot_point(spot, "away", 30), (spot.cx + 30, spot.cy))
        self.assertEqual(from_spot_point(spot, "towards", 30), (spot.cx - 30, spot.cy))
        # TR-17's second step from spot 1 (turned 24 degrees): the app's straight 30 mm along x now passes
        task = self.tasks.task("TR-17")
        self.assertIn({"moved": {"cube": "red cube", "dx": 30}}, task.targets)
        moved = next(t for t in self.tasks.task("TR-06").targets if "moved" in t)["moved"]
        self.assertEqual((moved.get("dx"), "radial" in moved), (-30, False))

    def test_a_spot_error_is_the_distance_from_its_middle(self):
        from watcher.arrange import arrange
        task = self.tasks.task("TR-01")
        start, _ = arrange(task, self.tasks, "train", 1)
        spot = self.tasks.zones["spot_3"]
        result = score(task, [Cube("blue cube", spot.cx + 6.0, spot.cy, spot.yaw)], self.tasks.zones,
                       self.tasks.rule, 25.0, start=start)
        self.assertTrue(result.passed)
        self.assertAlmostEqual(result.targets[0].position_error_mm, 6.0, places=1)
        self.assertEqual(result.targets[0].dx_mm, 6.0)

    def test_the_printed_spots_are_places_but_never_obstacles(self):
        import tempfile
        from app.llm.tools import ToolExecutor
        from watcher import observe
        with tempfile.TemporaryDirectory() as folder:
            poses = Path(folder)
            observe.save_zone_places(self.tasks, poses)
            (poses / "tray.json").write_text('{"x": 150, "y": 150, "z": 30, "r": 0}', encoding="utf-8")
            executor = ToolExecutor.__new__(ToolExecutor)          # (only the saved places are needed here)
            executor.poses_dir = poses
            self.assertEqual(sorted(executor._saved_places()), ["spot 1", "spot 2", "spot 3", "spot 4", "tray"],
                             "place_at can use every spot")
            self.assertEqual(sorted(executor._markings()), ["spot 1", "spot 2", "spot 3", "spot 4"])
            self.assertEqual(sorted(executor._obstacle_places()), ["tray"], "a tray is kept clear of, a spot isn't")


class SessionPlanTests(unittest.TestCase):
    """The Session plan tab: every run grouped by difficulty level, with its status; prompts hidden in a test."""

    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def window(self):
        from watcher.window import WatcherContext, WatcherWindow
        ctx = WatcherContext(robot=None, camera=None, scene_builder=None, executor=None, agent=None, config={},
                             mode="demo", estop=lambda: None, poses_dir=Path("."))
        window = WatcherWindow(ctx)
        self.addCleanup(window.close)
        return window

    def test_a_long_prompt_is_shown_whole_wrapped_not_cut_short(self):
        # study 2's lab notes: "the text in the prompt window was truncated in the watcher"
        from dataclasses import replace
        from PyQt6.QtWidgets import QStyleOptionViewItem
        tasks = load_task_set(SHEET_TRAIN, 3)
        long = ("put the red cube on the blue cube, then put the green cube beside them on the left with a 10 mm "
                "gap, and finally put the yellow cube in the tray, turned so that its sides line up with the tray's")
        window = self.window()
        window.plan = [(replace(tasks.tasks[0], level=1, prompt=long), 1), (replace(tasks.tasks[1], level=1), 1)]
        window._plan_status = ["Now", "Waiting"]
        window.resize(700, 600)
        window.show()
        window._refresh_plan()
        tree = window.plan_tree
        row = tree.topLevelItem(0).child(0)
        self.assertEqual(row.text(1), long, "the whole prompt")
        self.assertEqual(row.toolTip(1), long, "and in full on hover")
        index = tree.indexFromItem(row, 1)
        delegate = tree.itemDelegateForColumn(1)
        option = QStyleOptionViewItem()
        delegate.initStyleOption(option, index)
        self.assertTrue(option.features & QStyleOptionViewItem.ViewItemFeature.WrapText)
        one_line = tree.fontMetrics().height()
        from PyQt6.QtWidgets import QHeaderView
        tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)   # (to try it at two widths)
        heights = []
        for width in (700, 300):
            tree.header().resizeSection(1, width)
            self.app.processEvents()
            tall = delegate.sizeHint(option, index).height()
            heights.append(tall)
            lines = tree.fontMetrics().horizontalAdvance(long) / (width - 10)
            self.assertGreaterEqual(tall, int(lines) * one_line, f"every line of it at {width} px")
        self.assertGreater(heights[1], heights[0], "narrower: taller")
        short = tree.indexFromItem(tree.topLevelItem(0).child(1), 1)
        self.assertLess(delegate.sizeHint(option, short).height(), 4 * one_line, "a short one stays short")

    def test_runs_grouped_by_level_with_their_status(self):
        from dataclasses import replace
        tasks = load_task_set(SHEET_TRAIN, 3)
        window = self.window()
        window.plan = [(replace(tasks.tasks[0], level=1), 1), (replace(tasks.tasks[1], level=1), 1),
                       (replace(tasks.tasks[2], level=3), 1), (replace(tasks.tasks[3], level=None), 1)]
        window._plan_status = ["Pass · saved Run1", "Fail", "Now", "Waiting"]
        window._refresh_plan()
        tree = window.plan_tree
        groups = [tree.topLevelItem(i) for i in range(tree.topLevelItemCount())]
        self.assertEqual([g.text(0) for g in groups], ["Level 1", "Level 3", "No level"])
        self.assertEqual(groups[0].text(2), "1 of 2 passed")
        self.assertEqual(groups[0].child(0).text(1), tasks.tasks[0].prompt)
        self.assertEqual(groups[1].child(0).text(2), "Now")
        self.assertTrue(window.level_chips[2].isHidden(), "only the levels this session have chips")
        self.assertFalse(window.level_chips[3].isHidden())
        window.level_chips[3].click()                          # only level 3
        self.assertEqual([g.isHidden() for g in groups], [True, False, True])
        window.level_chips["all"].click()
        self.assertEqual([g.isHidden() for g in groups], [False, False, False])

    def test_a_test_session_hides_the_prompts(self):
        from types import SimpleNamespace
        tasks = load_task_set(SHEET_TRAIN, 3)
        window = self.window()
        window.plan = [(tasks.tasks[0], 1), (tasks.tasks[0], 2)]
        window._plan_status = ["Now", "Waiting"]
        window.session = SimpleNamespace(info={"set": "test"}, real=False)
        window._refresh_plan()
        rows = [window.plan_tree.topLevelItem(0).child(i) for i in range(2)]
        self.assertEqual({r.text(1) for r in rows}, {"(unseen test prompt: hidden)"})
        self.assertEqual(rows[1].text(0), f"{tasks.tasks[0].id} · repeat 2")
        self.assertTrue(window.show_prompts.isVisibleTo(window), "a test: the switch is there")
        self.assertFalse(window.prompts_warning.isVisibleTo(window))
        window.show_prompts.setChecked(True)                      # shown, for you, with a warning
        rows = [window.plan_tree.topLevelItem(0).child(i) for i in range(2)]
        self.assertEqual({r.text(1) for r in rows}, {tasks.tasks[0].prompt})
        self.assertTrue(window.prompts_warning.isVisibleTo(window))
        window.session = None
        window.close()
        self.assertFalse(window.show_prompts.isChecked(), "off again when the window closes")
        window.session_box.setCurrentIndex(window.session_box.findData("train_twin"))
        self.assertFalse(window.show_prompts.isVisibleTo(window), "training: nothing to hide, no switch")

    def test_the_plan_is_previewed_before_the_session_starts(self):
        with mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN):
            window = self.window()                              # (Demo: Task for Twin, Study 1, chosen)
            tree = window.plan_tree
            self.assertEqual([tree.topLevelItem(i).text(0) for i in range(tree.topLevelItemCount())],
                             ["Level 1", "Level 2", "Level 3", "Level 4", "Level 5"])
            self.assertEqual(sum(tree.topLevelItem(i).childCount() for i in range(5)), 20)
            self.assertIn("20 of 20 tasks ticked × 1 = <b>20 runs</b>, as planned", window.plan_summary.text())
            self.assertEqual(window.left_tabs.currentIndex(), 1, "the plan's tab in front")
            self.assertEqual(window.level_chips[1].text(), "Level 1")
            self.assertIn("one cube, one step", window.level_chips[1].toolTip())
            window.session_box.setCurrentIndex(window.session_box.findData("test_twin"))
            self.assertEqual(tree.topLevelItemCount(), 0, "no test set here: nothing to tick")
            self.assertIn("make_test_tasks.py", window.plan_summary.text(), "says how to make it")
            window.show_prompts.setChecked(True)
            self.assertFalse(window.prompts_warning.isVisibleTo(window), "no prompts on screen: no warning")


class FlexibleRunsTests(unittest.TestCase):
    """V3.9: pick any tasks, run them any number of times, in rounds or back to back, from the same or a new start;
    save a run under any number, replacing one already saved; discarded and replaced runs kept in Recycle_Bin."""

    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)

    def test_plan_runs_picks_times_order_and_start(self):
        from watcher.window import plan_runs
        tasks = load_task_set(SHEET_TRAIN, 3)
        self.assertEqual(len(plan_runs(tasks, "train", "dobot")), 20, "nothing chosen: as planned")
        rounds = plan_runs(tasks, "train", "dobot", ["TR-05", "TR-01"], 2)
        self.assertEqual([(t.id, r) for t, r in rounds], [("TR-01", 1), ("TR-05", 1), ("TR-01", 2), ("TR-05", 2)],
                         "the file's order, all once, then again")
        together = plan_runs(tasks, "train", "dobot", ["TR-05", "TR-01"], 2, order="together")
        self.assertEqual([(t.id, r) for t, r in together], [("TR-01", 1), ("TR-01", 2), ("TR-05", 1), ("TR-05", 2)])
        self.assertNotEqual(together[0][0].arrangement["seed"], together[1][0].arrangement["seed"], "new start")
        same = plan_runs(tasks, "train", "dobot", ["TR-01"], 3, start="same")
        self.assertEqual({t.arrangement["seed"] for t, _ in same}, {"train|TR-01|1"}, "every repeat as the first")
        self.assertEqual([r for _, r in same], [1, 2, 3])

    def session(self, real, set_name="train"):
        from watcher import results as r
        return r.Session.start(real, set_name, "dobot", 1, "base", {}, root=self.root)

    def saved(self, s, task_id, tag, passed=True):
        from watcher import results as r
        run = s.run_folder(task_id, 1)
        r.write_json(run / "run.json", {"task": task_id, "passed": passed, "tag": tag})
        final = s.save_run(run, task_id, tag)
        (r.saved_folder(s.kind_folder) / f"{final.name}.md").write_text("# run", encoding="utf-8")
        r.html_folder(s.kind_folder).mkdir(parents=True, exist_ok=True)
        (r.html_folder(s.kind_folder) / f"{final.name}.html").write_text("<p>run</p>", encoding="utf-8")
        return final

    def test_a_saved_run_is_replaced_only_when_asked_and_kept_in_the_recycle_bin(self):
        from watcher import results as r
        s = self.session(real=True)
        self.saved(s, "TR-07", "Run1", passed=False)
        self.saved(s, "TR-07", "Run2")
        self.saved(s, "TR-07", "Run10")
        self.saved(s, "TR-070", "Run1")                     # (another task, its id starting the same)
        self.assertEqual([x["tag"] for x in s.saved_runs("TR-07")], ["Run1", "Run2", "Run10"])
        self.assertEqual(s.saved_runs("TR-07")[0]["passed"], False)
        new = s.run_folder("TR-07", 2)
        r.write_json(new / "run.json", {"task": "TR-07", "passed": True, "tag": "Run1"})
        with self.assertRaises(FileExistsError):
            s.save_run(new, "TR-07", "Run1")
        with self.assertRaises(ValueError):                  # real: only with a reason
            s.save_run(new, "TR-07", "Run1", replace=True)
        final = s.save_run(new, "TR-07", "Run1", replace=True, reason="the camera was bumped")
        self.assertTrue(json.loads((final / "run.json").read_text())["passed"], "the new run under the old name")
        bin_kind = self.root / "Recycle_Bin" / "study_1" / "Dobot_Training_Data"
        old = list(bin_kind.glob("TR-07_Run1__replaced_*"))
        self.assertEqual(len(old), 1)
        self.assertFalse(json.loads((old[0] / "run.json").read_text())["passed"], "the earlier run, whole")
        self.assertTrue((old[0] / "saved_md" / "TR-07_Run1.md").exists(), "its own page moved with it")
        self.assertTrue((old[0] / "saved_html" / "TR-07_Run1.html").exists())
        self.assertFalse((r.saved_folder(s.kind_folder) / "TR-07_Run1.md").exists(), "(the new one writes its own)")
        why = (old[0] / "why.txt").read_text(encoding="utf-8")
        self.assertIn("the camera was bumped", why)
        self.assertIn("Replaced by", why)
        log = (self.root / r.DELETIONS_LOG).read_text(encoding="utf-8")
        self.assertIn("replaced: the camera was bumped", log)
        self.assertIn("Recycle_Bin", log)
        index = [json.loads(line) for line in (s.folder / "index.jsonl").read_text().splitlines()]
        self.assertEqual((index[-2]["replaced"], index[-1]["saved"]), ("TR-07_Run1", "TR-07_Run1"),
                         "the earlier one's move noted first, then the new one saved")
        self.assertTrue(r.verify_index(s.folder))
        from watcher import report
        self.assertIn("replaced by a new run: the camera was bumped",
                      json.dumps(report._discarded_of(s.kind_folder)))
        self.assertTrue(r.is_real_path(old[0], self.root), "deleting it from the Recycle_Bin needs a reason too")

    def test_practice_replaces_without_a_reason_and_test_runs_stay_private(self):
        from watcher import results as r
        p = self.session(real=False)
        self.saved(p, "TR-01", "Run1")
        new = p.run_folder("TR-01", 2)
        r.write_json(new / "run.json", {"task": "TR-01"})
        p.save_run(new, "TR-01", "Run1", replace=True)
        self.assertEqual(len(list((self.root / "Recycle_Bin" / "Practice_Session").rglob("why.txt"))), 1)
        self.assertFalse((self.root / r.DELETIONS_LOG).exists(), "practice: no deletions log line")
        t = self.session(real=True, set_name="test")
        pending = t.run_folder("T-03", 1)
        r.write_json(pending / "run.json", {"task": "T-03"})
        where = t.discard_run(pending, "a cube was knocked")
        self.assertEqual(where.parent, self.root / "Private_never_for_Claude" / "Recycle_Bin_test" / "study_1" /
                         "Test_Real_Dobot_with_unseen_tasks")
        self.assertTrue(r.is_test_path(where), "never Claude's to read")
        self.assertTrue((where / "run.json").exists())
        self.assertTrue(r.is_test_path(self.root / "Private_never_for_Claude" / "Recycle_Bin_test"))
        self.assertFalse(r.is_test_path(self.root / "Recycle_Bin" / "study_1" / "Dobot_Training_Data"))

    def test_the_save_dialog_suggests_the_next_number_and_asks_before_replacing(self):
        from PyQt6.QtWidgets import QDialogButtonBox
        from watcher.window import SaveRunDialog
        saved = [{"name": "TR-07_Run1", "tag": "Run1", "passed": True, "saved_at": "2026-10-14 15:32:00"}]
        taken = {"TR-07_Run1"}.__contains__
        dialog = SaveRunDialog(None, "TR-07", "Run2", saved, taken, real=True)
        self.addCleanup(dialog.close)
        save = dialog.buttons.button(QDialogButtonBox.StandardButton.Save)
        self.assertEqual(dialog.answer(), {"tag": "Run2", "replace": False, "reason": ""})
        self.assertEqual(save.text(), "Save")
        dialog.number.setValue(1)
        self.assertEqual(save.text(), "Replace Run1")
        self.assertIn("already saved (Pass", dialog.warning.text())
        self.assertFalse(save.isEnabled(), "a real run: replaced only with a reason")
        dialog.reason.setText("redo after the fix")
        self.assertTrue(save.isEnabled())
        self.assertEqual(dialog.answer(), {"tag": "Run1", "replace": True, "reason": "redo after the fix"})
        dialog.custom.setText("Run3_newcam")
        self.assertFalse(dialog.number.isEnabled())
        self.assertEqual(dialog.answer()["tag"], "Run3_newcam")
        self.assertEqual(save.text(), "Save")
        practice = SaveRunDialog(None, "TR-07", "Run1", saved, taken, real=False)
        self.addCleanup(practice.close)
        self.assertTrue(practice.buttons.button(QDialogButtonBox.StandardButton.Save).isEnabled(),
                        "practice: no reason needed")

    def test_ticking_tasks_and_levels_before_the_session(self):
        from PyQt6.QtCore import Qt
        from watcher.window import WatcherContext, WatcherWindow
        with mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN):
            ctx = WatcherContext(robot=None, camera=None, scene_builder=None, executor=None, agent=None, config={},
                                 mode="demo", estop=lambda: None, poses_dir=Path("."), results_root=self.root)
            window = WatcherWindow(ctx)
            self.addCleanup(window.close)
            tree = window.plan_tree
            level1 = tree.topLevelItem(0)
            level1.setCheckState(0, Qt.CheckState.Unchecked)       # a whole level out
            self.assertEqual(window._unticked["train"], {level1.child(i).text(0) for i in range(level1.childCount())})
            self.assertIn("16 of 20 tasks ticked", window.plan_summary.text())
            level1.child(0).setCheckState(0, Qt.CheckState.Checked)  # one of it back in
            self.assertEqual(level1.checkState(0), Qt.CheckState.PartiallyChecked)
            window.times_box.setValue(3)
            window.order_box.setCurrentIndex(window.order_box.findData("together"))
            self.assertIn("17 of 20 tasks ticked × 3 = <b>51 runs</b>", window.plan_summary.text())
            self.assertIn("back to back", window.plan_summary.text())
            level1 = tree.topLevelItem(0)                             # (the list is made again: the ticks stay)
            self.assertEqual(level1.checkState(0), Qt.CheckState.PartiallyChecked)
            self.assertEqual(level1.child(1).text(2), "not ticked")
            self.assertEqual(level1.child(0).text(2), "× 3")
            tasks = load_task_set(SHEET_TRAIN, 3)
            self.assertEqual(len(window._picked(tasks, "train")), 17)
            window._tick_all(False)
            self.assertIn("0 of 20 tasks ticked", window.plan_summary.text())
            window._tick_all(True)
            self.assertIsNone(window._picked(tasks, "train"), "all ticked: as planned")
            window.cubes_box.setCurrentIndex(1)                      # (the list made again: the choices stay)
            self.assertEqual(window.times_box.value(), 3, "the choices stay until the kind of session changes")


class FlexibleSessionTests(WatcherWindowTests):
    """A twin session of one picked task: run again from the same start, then saved over the first run (replaced)."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):      # (run once, in the parent class)
        pass

    def test_pick_one_task_run_it_again_and_replace_the_first_run(self):
        import importlib.util
        import tempfile
        import time
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(SHEET_TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-01"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN):
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            agent = Agent(PutInPlaceClient("blue cube", "spot 3"), twin.executor, "scripted")
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {"seed": 42}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            window._unticked["train"] = {t.id for t in tasks.tasks} - {"TR-01"}
            window.start_box.setCurrentIndex(window.start_box.findData("same"))
            window.start_session()
            self.assertEqual([(t.id, r) for t, r in window.plan], [("TR-01", 1)])
            choice = window.session.info["plan_choice"]
            self.assertEqual((choice["tasks"], len(choice["left_out"]), choice["as_planned"]), (["TR-01"], 19, False))
            kind = window.session.kind_folder

            def one_run():
                self.wait_for(window, "setup")
                deadline = time.time() + 30
                while not window.run_btn.isEnabled() and time.time() < deadline:
                    self.app.processEvents()
                    window._show_setup(window._look(looks=1))
                window._start_run()
                self.wait_for(window, "verdict")
                window._verdict("skipped")
                self.assertEqual(window.state, "reveal")

            one_run()
            self.assertTrue(window.again_btn.isEnabled())
            window.again_btn.click()                                  # another run of it, next
            self.assertEqual([(t.id, r) for t, r in window.plan], [("TR-01", 1), ("TR-01", 2)])
            self.assertEqual(window.plan[1][0].arrangement, window.plan[0][0].arrangement, "the same start")
            window._ask_save = lambda task_id, suggested, saved: {"tag": suggested}
            window._save_and_next()
            self.assertTrue((kind / "_raw_data" / "TR-01_Run1").exists())
            one_run()
            asked = []

            def replace_first(task_id, suggested, saved):
                asked.append((suggested, [x["tag"] for x in saved]))
                return {"tag": "Run1", "replace": True, "reason": ""}
            window._ask_save = replace_first
            window._save_and_next()                                   # (no more runs: the session ends)
            self.assertEqual(asked, [("Run2", ["Run1"])], "the next free number, and what is saved")
            self.assertEqual(window.state, "idle")
            self.assertEqual(len(list((kind / "_raw_data").glob("*/run.json"))), 1, "one Run1: the new one")
            binned = list((folder / "results" / "Recycle_Bin").rglob("TR-01_Run1__replaced_*"))
            self.assertEqual(len(binned), 1)
            self.assertTrue((binned[0] / "saved_md" / "TR-01_Run1.md").exists())
            self.assertTrue((kind / "User_Saved_Twin_Training_Data" / "TR-01_Run1.md").exists(),
                            "the new run's own page")
            full = (kind / "FULL_REPORT.md").read_text(encoding="utf-8")
            self.assertIn("TR-01_Run1 (the earlier one)", full)
            summary = next((kind / "_sessions_log").glob("*/SESSION_SUMMARY.md")).read_text(encoding="utf-8")
            self.assertIn("Planned: 1 of 20 tasks × 1 = 1 runs, in rounds, same start each repeat", summary)
            self.assertIn("Saved runs of: TR-01", summary)
            index = next((kind / "_sessions_log").glob("*/index.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"added_run": "TR-01"', index)
            window.close()

    def test_run_by_itself_runs_scores_and_saves_every_run_in_the_twin(self):
        import importlib.util
        import tempfile
        import time
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import AUTO_NOTE, WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(SHEET_TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-01"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN):
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            agent = Agent(PutInPlaceClient("blue cube", "spot 3"), twin.executor, "scripted")
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {"seed": 42}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            self.assertTrue(window.auto_run.isVisibleTo(window), "shown in Demo mode (the twin)")
            window._unticked["train"] = {t.id for t in tasks.tasks} - {"TR-01"}
            window.times_box.setValue(2)
            window.auto_run.setChecked(True)
            window._ask_save = lambda *a: self.fail("running by itself never asks")
            window.start_session()
            kind = window.session.kind_folder
            deadline = time.monotonic() + 180
            while window.session is not None and time.monotonic() < deadline:
                self.app.processEvents()
                if window.state == "setup" and not window._busy:      # (the table check, as the timer would)
                    window._show_setup(window._look(looks=1))
                time.sleep(0.02)
            self.assertIsNone(window.session, "both runs done, the session ended, nobody clicking")
            runs = sorted((kind / "_raw_data").glob("*/run.json"))
            self.assertEqual([p.parent.name for p in runs], ["TR-01_Run1", "TR-01_Run2"])
            for path in runs:
                run = json.loads(path.read_text(encoding="utf-8"))
                self.assertTrue(run["unattended"])
                self.assertEqual((run["observer"]["verdict"], run["observer"]["note"]), ("skipped", AUTO_NOTE))
            summary = next((kind / "_sessions_log").glob("*/SESSION_SUMMARY.md")).read_text(encoding="utf-8")
            self.assertIn("Ran by itself (no person watching): 2 of 2 runs", summary)
            cross = folder / "results" / "Private_never_for_Claude" / "Study_Overview_practice" / "CROSS_STUDY_REPORT.md"
            self.assertTrue(cross.exists(), "the cross-study report, remade as the runs were saved")
            self.assertIn("| Twin · training | 2/2 (100%) | - | - |", cross.read_text(encoding="utf-8"))
            window.close()

    def test_double_click_a_task_and_run_it_now(self):
        import importlib.util
        import tempfile
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        tasks = load_task_set(SHEET_TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-05"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN):
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=Agent(PutInPlaceClient("red cube", "spot 2"),
                                                                     twin.executor, "scripted"),
                                 config={"llm": {"seed": 42}}, mode="demo", estop=twin.robot.stop,
                                 poses_dir=folder / "poses", twin_world=twin.world, results_root=folder / "results")
            window = WatcherWindow(ctx)
            self.assertFalse(window.loaded_bar.isVisibleTo(window), "nothing loaded yet")
            row = next(r for r in window._picker_rows() if r.text(0) == "TR-05")
            window.plan_tree.itemDoubleClicked.emit(row, 0)        # double-click TR-05 in the plan
            self.assertTrue(window.loaded_bar.isVisibleTo(window))
            self.assertEqual(window.loaded_prompt.text(), tasks.task("TR-05").prompt)
            self.assertIn("starts a session of just this task", window.loaded_where.text())
            window.plan_tree.itemDoubleClicked.emit(window.plan_tree.topLevelItem(0), 0)   # (a level's line)
            self.assertEqual(window._loaded, "TR-05", "a level's line loads nothing")
            window.run_now_btn.click()
            self.assertIsNotNone(window.session, "a session of just that task")
            self.assertEqual([(t.id, r) for t, r in window.plan], [("TR-05", 1)])
            self.assertEqual(window.session.info["plan_choice"]["run_now"], "TR-05")
            self.assertFalse(window.loaded_bar.isVisibleTo(window), "cleared once it runs")
            self.assertEqual(window._unticked.get("train", set()), set(), "your ticks are left as they were")
            run_row = window.plan_tree.topLevelItem(0).child(0)    # (the session's run of TR-05)
            window.plan_tree.itemDoubleClicked.emit(run_row, 0)
            self.assertIn("runs next", window.loaded_where.text())
            window.run_now_btn.click()                              # a session is running: it runs next
            self.assertEqual([(t.id, r) for t, r in window.plan], [("TR-05", 1), ("TR-05", 2)])
            self.wait_for(window, "setup")
            window.end_session("test over")
            summary = next((folder / "results").rglob("SESSION_SUMMARY.md")).read_text(encoding="utf-8")
            self.assertIn("TR-05 only, once (Run this task now)", summary)
            window.close()

    def test_run_by_itself_is_the_twins_only_and_pauses_when_a_run_is_broken(self):
        from types import SimpleNamespace
        from watcher.window import WatcherContext, WatcherWindow

        class Nothing:
            def get_frame(self):
                raise RuntimeError("no camera")

            def get_intrinsics(self):
                raise RuntimeError("no camera")
        live = WatcherWindow(WatcherContext(robot=None, camera=Nothing(), scene_builder=None, executor=None,
                                            agent=None, config={}, mode="live", estop=lambda: None,
                                            poses_dir=Path(".")))
        self.addCleanup(live.close)
        self.assertFalse(live.auto_run.isVisibleTo(live), "never on the real Dobot")
        live.auto_run.setChecked(True)
        live.session = SimpleNamespace(real=False, info={})
        self.assertFalse(live._auto_on(), "and ignored there even if ticked")
        live.session = None
        demo = WatcherWindow(WatcherContext(robot=None, camera=Nothing(), scene_builder=None, executor=None,
                                            agent=None, config={}, mode="demo", estop=lambda: None,
                                            poses_dir=Path(".")))
        self.addCleanup(demo.close)
        demo.auto_run.setChecked(True)
        demo.session = SimpleNamespace(real=False, info={})
        demo.state, demo._broken = "reveal", True
        demo._auto_step()
        self.assertFalse(demo.auto_run.isChecked(), "a broken run: it stops for you")
        self.assertIn("Run by itself paused", demo.run_text.toPlainText())
        demo.session = None


class CrossStudyReportTests(unittest.TestCase):
    """Private_never_for_Claude\\Study_Overview: study 1 vs 2 vs 3, every kind side by side, from made-up saved runs."""

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)

    def runs(self, real, set_name, where, study, rows):
        """Saved runs in a kind's folder: rows of (task, level, passed, unassisted, extra)."""
        from watcher import results as r
        kind = r.kind_folder(real, set_name, where, study, self.root)
        for i, (task, level, passed, unassisted, extra) in enumerate(rows, start=1):
            r.write_json(kind / "_raw_data" / f"{task}_Run{i}" / "run.json",
                         dict({"task": task, "level": level, "passed": passed, "unassisted_pass": unassisted,
                               "failure": None if passed else "placement", "prompt": "SECRET PROMPT"}, **extra))
        r.write_json(kind / "_sessions_log" / "2026-10-14_100000" / "session.json",
                     {"version": "base" if study == 1 else f"v{study - 1}", "real": real})

    def test_the_main_claim_every_kind_the_gap_and_each_task(self):
        from watcher import overview, results as r
        self.runs(True, "test", "dobot", 1, [("T-01", 1, True, True, {}), ("T-01", 1, False, False, {}),
                                             ("T-02", 2, False, False, {}), ("T-02", 2, True, True, {"repeated": True})])
        self.runs(True, "test", "dobot", 3, [("T-01", 1, True, True, {}), ("T-01", 1, True, True, {}),
                                             ("T-02", 2, True, False, {}), ("T-02", 2, False, False, {})])
        self.runs(True, "test", "twin", 1, [("T-01", 1, True, True, {"unattended": True}),
                                            ("T-02", 2, True, True, {"unattended": True})])
        self.runs(True, "train", "twin", 2, [("TR-01", 1, True, True, {})])
        self.runs(False, "train", "twin", 1, [("TR-09", 3, True, True, {})])          # practice: not in the real one
        folder = overview.write_overview(True, self.root)
        self.assertEqual(folder, self.root / "Private_never_for_Claude" / "Study_Overview")
        self.assertTrue(r.is_test_path(folder), "private: never Claude's to read")
        md = (folder / "CROSS_STUDY_REPORT.md").read_text(encoding="utf-8")
        self.assertIn("| Study 1 | base | 3 | 1 | 1 | 33% | - |", md, "the repeated run isn't counted")
        self.assertIn("| Study 3 | v2 | 4 | 3 | 2 | 50% | +17 pp |", md, "unassisted, not just passed")
        self.assertIn("| T-01 | 1 | 1/2 (50%) | - | 2/2 (100%) | +50 pp |", md)
        self.assertIn("**1 better, 1 the same, 0 worse**", md)
        self.assertIn("| Dobot · unseen test | 1/3 (33%) | - | 2/4 (50%) |", md)
        self.assertIn("| Twin · training | - | 1/1 (100%) | - |", md)
        self.assertIn("| Unseen test | +67 pp | - | - |", md, "twin 100% - Dobot 33%")
        self.assertNotIn("TR-09", md, "practice stays out of the real report")
        self.assertNotIn("SECRET PROMPT", md, "the test's prompts never appear")
        self.assertIn("| Twin · unseen test | 1 | base | 1 | 2 | 0 | 0 | 2 |", md, "ran by itself, counted")
        data = json.loads((folder / "cross_study.json").read_text(encoding="utf-8"))
        self.assertEqual(data["kinds"]["test_dobot"]["studies"]["3"]["unassisted"], 2)
        self.assertTrue((folder / "CROSS_STUDY_REPORT.html").exists())
        from openpyxl import load_workbook
        self.assertEqual(load_workbook(folder / "cross_study.xlsx").sheetnames,
                         ["Overview", "By level", "By task", "Failures"])
        practice = overview.write_overview(False, self.root)
        self.assertEqual(practice, self.root / "Private_never_for_Claude" / "Study_Overview_practice")
        self.assertIn("| Twin · training | 1/1 (100%) | - | - |",
                      (practice / "CROSS_STUDY_REPORT.md").read_text(encoding="utf-8"))

    def test_studies_past_3_are_shown_up_to_the_last_one_run(self):
        from watcher import overview
        self.runs(True, "test", "dobot", 1, [("T-01", 1, True, True, {})])
        self.runs(True, "test", "dobot", 5, [("T-01", 1, True, True, {}), ("T-01", 1, False, False, {})])
        md = (overview.write_overview(True, self.root) / "CROSS_STUDY_REPORT.md").read_text(encoding="utf-8")
        self.assertIn("study 1 vs 2 vs 3 vs 4 vs 5", md)
        self.assertIn("| Study 5 | v4 | 2 | 1 | 1 | 50% | -50 pp |", md)
        self.assertIn("| Dobot · unseen test | 1/1 (100%) | - | - | - | 1/2 (50%) |", md)
        self.assertNotIn("Study 6", md, "studies not run yet: no empty columns")

    def test_an_empty_results_folder_still_makes_a_report(self):
        from watcher import overview
        folder = overview.write_overview(True, self.root)
        md = (folder / "CROSS_STUDY_REPORT.md").read_text(encoding="utf-8")
        self.assertIn("| Dobot · unseen test | - | - | - |", md)
        self.assertIn("No failures recorded yet.", md)


def _make_test_tasks_module():
    import importlib.util
    spec = importlib.util.spec_from_file_location("make_test_tasks", ROOT / "study" / "make_test_tasks.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["make_test_tasks"] = module            # (its dataclasses look themselves up there)
    spec.loader.exec_module(module)
    return module


class TestSetGeneratorTests(unittest.TestCase):
    """study/make_test_tasks.py, with made-up seeds in a temporary folder (never the engineer's set): 20 tasks
    made from the training set, paper-free and doable, checked; the old set retired; locked once real tests exist."""

    @classmethod
    def setUpClass(cls):
        cls.gen = _make_test_tasks_module()
        cls.data = cls.gen.make("unit-test-seed", twin=False, say=lambda line: None)

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)

    def test_twenty_tasks_mirror_the_training_levels_and_kinds(self):
        import yaml
        train = yaml.safe_load(STUDY_TRAIN.read_text(encoding="utf-8"))["tasks"]
        tasks = self.data["tasks"]
        self.assertEqual([t["id"] for t in tasks], [f"T-{n:02d}" for n in range(1, 21)])
        self.assertEqual([(t["level"], t["category"]) for t in tasks], [(t["level"], t["category"]) for t in train])
        self.assertEqual([[next(iter(x)) for x in t["targets"]] for t in tasks],
                         [[next(iter(x)) for x in t["targets"]] for t in train], "the same target kinds, in order")
        self.assertEqual([len(t["start"]["cubes"]) for t in tasks], [len(t["start"]["cubes"]) for t in train])
        self.assertEqual([sorted(k for x in t["targets"] for k in x.get("moved", {}) if k != "cube") for t in tasks],
                         [sorted(k for x in t["targets"] for k in x.get("moved", {}) if k != "cube") for t in train],
                         "each move along the same lines as its training task's (and in two legs where it was)")
        self.assertEqual([[bool(x.get("row", {}).get("order")) for x in t["targets"]] for t in tasks],
                         [[bool(x.get("row", {}).get("order")) for x in t["targets"]] for t in train])
        self.assertTrue(all(set(t["start"]) == {"cubes"} for t in tasks), "no spots: just the cubes")
        self.assertIn("area", self.data)
        self.assertNotIn("sheet", self.data)
        self.assertFalse({t["prompt"] for t in tasks} & {t["prompt"] for t in train}, "no training prompt")
        self.assertEqual(len({t["prompt"] for t in tasks}), 20, "each its own")
        self.assertEqual(self.gen.make("unit-test-seed", twin=False, say=lambda line: None)["tasks"], tasks,
                         "the same seed makes the same set")
        self.assertNotEqual(self.gen.make("another-seed", twin=False, say=lambda line: None)["tasks"], tasks)

    def test_it_follows_the_training_file(self):
        # change the training tasks and the shapes follow, with no code change; a target needing paper is refused
        import tempfile
        import yaml
        data = yaml.safe_load(STUDY_TRAIN.read_text(encoding="utf-8"))
        data["tasks"] = data["tasks"][:2]
        data["tasks"][1]["targets"] = [{"swapped": {"a": "blue cube", "b": "red cube"}}]
        data["tasks"][1]["start"] = {"cubes": ["blue", "red"]}
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "train.yaml"
            path.write_text(yaml.safe_dump(data), encoding="utf-8")
            shapes = self.gen.shapes_from(path)
            self.assertEqual([(s.mirrors, s.cubes, [k[0] for k in s.steps]) for s in shapes],
                             [("TR-01", 1, ["move"]), ("TR-02", 2, ["swap"])])
            data["tasks"][0]["targets"] = [{"in_zone": {"cube": "red cube", "zone": "spot_1"}}]
            path.write_text(yaml.safe_dump(data), encoding="utf-8")
            with self.assertRaises(ValueError):
                self.gen.shapes_from(path)

    def test_steps_become_targets_and_a_tool_recipe(self):
        steps = [{"do": "move_via", "cube": "red cube", "dir": "left", "d": 30, "dir2": "right", "d2": 60},
                 {"do": "turn", "cube": "red cube", "deg": -45},
                 {"do": "beside", "cube": "blue cube", "of": "red cube", "side": "nearer", "gap": 20},
                 {"do": "row_order", "cube": None, "cubes": ["green cube", "red cube", "blue cube"], "gap": 30}]
        self.assertEqual(self.gen.targets_of(steps),
                         [{"moved": {"cube": "red cube", "dy": -30, "via": {"dy": 30}}},
                          {"turned": {"cube": "red cube", "deg": -45}},
                          {"beside": {"cube": "blue cube", "of": "red cube", "side": "nearer", "gap": 20}},
                          {"row": {"cubes": ["green cube", "red cube", "blue cube"], "gap": 30,
                                   "order": ["green cube", "red cube", "blue cube"]}}])
        calls = self.gen.recipe(steps)
        self.assertEqual([name for name, _ in calls],
                         ["move_object", "move_object", "turn_object", "pick", "place_beside", "line_up"])
        self.assertEqual((calls[0][1]["direction"], calls[1][1]["direction"]), ("left", "right"))
        self.assertEqual(calls[2][1]["turn_deg"], -45, "turned BY, clockwise negative")
        self.assertEqual(calls[4][1]["side"], "behind", "nearer the robot: place_beside's behind")
        self.assertEqual(calls[5][1]["along"], "left_to_right")
        import random
        words = self.gen.prompt_of(steps, random.Random(1))
        self.assertIn("30 mm to the left", words)
        self.assertIn("60 mm to the right", words)
        self.assertIn("it 45 degrees clockwise", words)
        self.assertIn("nearer the robot than the red cube", words)
        self.assertIn("green, red", words)

    def test_written_checked_readable_retired_and_locked(self):
        from watcher import report, results as r
        old = self.root / "2_REAL_TEST_counts_for_paper" / "test_set" / "test.yaml"
        old.parent.mkdir(parents=True)
        old.write_text("tasks: []", encoding="utf-8")
        with self.assertRaises(FileNotFoundError):
            r.test_set_file(self.root)                                 # the old place is never read
        path = self.gen.write(self.data, self.root)
        self.assertEqual(path, self.root / "Private_never_for_Claude" / "Test_Tasks" / "test.yaml")
        self.assertEqual(r.test_set_file(self.root), path)
        self.assertTrue((path.parent / "test_tasks.html").exists() and (path.parent / "test_tasks.md").exists())
        self.assertEqual(self.gen.retire_old(self.root), 1)
        self.assertFalse(old.exists())
        self.assertEqual(len(list(old.parent.glob("test_RETIRED_*.yaml"))), 1)
        loaded = load_task_set(path, 3)
        self.assertEqual(len(loaded.tasks), 20)
        with self.assertRaises(FileExistsError):
            self.gen.write(self.data, self.root)                       # not over a set without asking
        self.gen.write(self.data, self.root, replace=True)
        self.assertEqual(len(list(path.parent.glob("test_OLD_*.yaml"))), 1, "the earlier set kept")
        s = r.Session.start(True, "test", "dobot", 1, "base", {}, root=self.root)
        pending = s.run_folder("T-01", 1)
        r.write_json(pending / "run.json", {"task": "T-01", "passed": True})
        s.save_run(pending, "T-01", "Run1")
        self.assertEqual(len(report._run_folders(s.kind_folder)), 1)
        with self.assertRaises(RuntimeError):
            self.gen.write(self.data, self.root, replace=True)         # a real test run saved: locked

    def test_every_kind_of_step_is_done_by_its_recipe_in_the_twin(self):
        from app import robots
        from watcher.arrange import arranged, count_arrangements
        robots.set_active("dobot_magician")
        import random
        rng = random.Random(7)
        # out and back, beside further, beside + turn, a row in order, swap then beside
        picked = {"TR-10", "TR-13", "TR-15", "TR-18", "TR-20"}
        import tempfile
        for shape in [s for s in self.gen.shapes_from() if s.mirrors in picked]:
            with tempfile.TemporaryDirectory() as folder:
                for _ in range(200):
                    task, steps = self.gen.draw_task(shape, 1, rng)
                    scratch = Path(folder) / "one.yaml"
                    scratch.write_text(self.gen._yaml(dict(self.gen.header("x"), tasks=[task])), encoding="utf-8")
                    one = load_task_set(scratch, 3)
                    if count_arrangements(one.tasks[0], one) >= 50:
                        break
                self.assertTrue(self.gen.twin_check(arranged(one.tasks[0], one, "test", 1), one, steps),
                                f"{shape.mirrors}'s kind, done by its recipe in the twin")


class TestSeedDialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def test_the_seed_is_hidden_and_typed_twice(self):
        from PyQt6.QtWidgets import QDialogButtonBox, QLineEdit
        from watcher.window import TestSeedDialog
        dialog = TestSeedDialog()
        self.addCleanup(dialog.close)
        ok = dialog.buttons.button(QDialogButtonBox.StandardButton.Ok)
        self.assertEqual(dialog.first.echoMode(), QLineEdit.EchoMode.Password)
        self.assertFalse(ok.isEnabled())
        dialog.first.setText("my secret")
        dialog.second.setText("my secrte")
        self.assertFalse(ok.isEnabled(), "a typo: not made")
        self.assertIn("don't match", dialog.why.text(), "and it says why")
        dialog.show_seed.setChecked(True)
        self.assertEqual(dialog.first.echoMode(), QLineEdit.EchoMode.Normal, "shown, to check it")
        dialog.show_seed.setChecked(False)
        self.assertEqual(dialog.second.echoMode(), QLineEdit.EchoMode.Password)
        dialog.second.setText("my secret")
        self.assertTrue(ok.isEnabled())
        self.assertEqual(dialog.why.text(), "")
        self.assertEqual(dialog.seed(), "my secret")
        self.assertTrue(dialog.twin.isChecked(), "the twin check on by default")

    def test_made_in_the_session_plan_tab_then_listed_with_their_prompts(self):
        import tempfile
        import time
        from types import SimpleNamespace
        from PyQt6.QtWidgets import QDialog
        from watcher.window import WatcherContext, WatcherWindow
        with tempfile.TemporaryDirectory() as folder, \
                mock.patch.object(_window_module, "TestSeedDialog", lambda parent=None: SimpleNamespace(
                    exec=lambda: QDialog.DialogCode.Accepted, seed=lambda: "ui-test-seed",
                    twin=SimpleNamespace(isChecked=lambda: False))), \
                mock.patch("watcher.window.QMessageBox.information"):
            ctx = WatcherContext(robot=None, camera=None, scene_builder=None, executor=None, agent=None, config={},
                                 mode="demo", estop=lambda: None, poses_dir=Path("."),
                                 results_root=Path(folder) / "Kyozo_Link_Results")
            window = WatcherWindow(ctx)
            self.addCleanup(window.close)
            window.session_box.setCurrentIndex(window.session_box.findData("test_twin"))
            self.assertTrue(window.make_tests_here.isVisibleTo(window), "made from the Session plan tab")
            self.assertEqual(window.make_tests_here.text(), "Make test tasks…")
            window.make_tests_here.click()
            self.assertFalse(window.make_tests_here.isEnabled(), "greyed out while it runs")
            self.assertTrue(window.testgen_panel.isVisibleTo(window), "the progress bar, while it works")
            self.assertEqual(window.left_tabs.currentIndex(), 1, "on the Session plan tab")
            self.assertIn("listed here when they're ready", window.plan_tree.topLevelItem(0).text(1))
            self.assertFalse(window.start_btn.isEnabled(), "no session starts while the test set is made")
            deadline = time.monotonic() + 240
            while window._testgen is not None and time.monotonic() < deadline:
                self.app.processEvents()
                time.sleep(0.05)
            self.assertIsNone(window._testgen, window.run_text.toPlainText())
            self.assertIn("20 test tasks made", window.run_text.toPlainText())
            self.assertFalse(window.testgen_panel.isVisibleTo(window), "gone when done")
            self.assertEqual(window.testgen_bar.value(), 40, "the bar full")
            rows = window._picker_rows()
            self.assertEqual(len(rows), 20, "the 20 test tasks, listed")
            self.assertEqual(rows[0].text(1), "(unseen test prompt: hidden)")
            window.show_prompts.setChecked(True)
            rows = window._picker_rows()
            self.assertNotIn("hidden", rows[0].text(1), "shown, with the switch on")
            self.assertTrue(window.prompts_warning.isVisibleTo(window))
            self.assertEqual(window.make_tests_here.text(), "Make new test tasks…")
            window.close()

    def test_the_bar_says_which_task_the_twin_checks_and_stop_changes_nothing(self):
        import tempfile
        import time
        from types import SimpleNamespace
        from PyQt6.QtWidgets import QDialog
        from watcher.window import WatcherContext, WatcherWindow
        with tempfile.TemporaryDirectory() as folder, \
                mock.patch.object(_window_module, "TestSeedDialog", lambda parent=None: SimpleNamespace(
                    exec=lambda: QDialog.DialogCode.Accepted, seed=lambda: "ui-stop-seed",
                    twin=SimpleNamespace(isChecked=lambda: True))), \
                mock.patch("watcher.window.QMessageBox.information") as told:
            root = Path(folder) / "Kyozo_Link_Results"
            ctx = WatcherContext(robot=None, camera=None, scene_builder=None, executor=None, agent=None, config={},
                                 mode="demo", estop=lambda: None, poses_dir=Path("."), results_root=root)
            window = WatcherWindow(ctx)
            self.addCleanup(window.close)
            window.session_box.setCurrentIndex(window.session_box.findData("test_twin"))
            window.make_tests_here.click()
            deadline = time.monotonic() + 180
            while "checking in the twin" not in window.run_text.toPlainText() and time.monotonic() < deadline:
                self.app.processEvents()
                time.sleep(0.05)
            self.assertEqual(window.testgen_now.text(), "Checking T-01 (group A) in the twin")
            self.assertEqual(window.testgen_count.text(), "0 of 20 ready")
            window.testgen_stop.click()
            while window._testgen is not None and time.monotonic() < deadline:
                self.app.processEvents()
                time.sleep(0.05)
            self.assertIsNone(window._testgen)
            self.assertFalse(window.testgen_panel.isVisibleTo(window))
            self.assertFalse((root / "Private_never_for_Claude" / "Test_Tasks" / "test.yaml").exists(), "stopped: nothing written")
            self.assertIn("Stopped", told.call_args[0][2])
            self.assertTrue(window.make_tests_here.isEnabled(), "free to make them again")
            window.close()


class ReviewThreeFixesTests(unittest.TestCase):
    """Fixes from the third review (2026-10-13): swap failures, the Recycle_Bin's deletion, the generator vs the
    template, the start checks, E-STOP and Run by itself, the level filter, the loaded bar."""

    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        import tempfile
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name) / "Kyozo_Link_Results"
        self.addCleanup(self._tmp.cleanup)

    def window(self, mode="demo", **extra):
        from watcher.window import WatcherContext, WatcherWindow
        fields = dict(robot=None, camera=None, scene_builder=None, executor=None, agent=None, config={}, mode=mode,
                      estop=lambda: None, poses_dir=Path("."), results_root=self.root)
        window = WatcherWindow(WatcherContext(**dict(fields, **extra)))
        self.addCleanup(window.close)
        return window

    def test_a_near_miss_swap_is_an_execution_failure_not_a_plan_one(self):
        from watcher.arrange import arranged
        from watcher.taxonomy import RunFacts, classify
        from watcher.tasks import Cube
        tasks = load_task_set(SHEET_TRAIN, 3)
        task = arranged(tasks.task("TR-11"), tasks, "train", 1)
        (_, spec), = task.targets[0].items()
        a = next(c for c in task.start if c.label == spec["a"])
        b = next(c for c in task.start if c.label == spec["b"])
        end = [Cube(c.label, b.x + 1, b.y, b.yaw) if c.label == spec["a"] else
               Cube(c.label, a.x + 14, a.y, a.yaw) if c.label == spec["b"] else c for c in task.start]
        result = score(task, end, tasks.zones, tasks.rule, tasks.cube_size_mm)
        self.assertFalse(result.passed)
        self.assertEqual(classify(task, result, RunFacts(), task.start, end, seen_start=task.start,
                                  zones=tasks.zones), "execution", "a cube on the other's spot is the swap, done")

    def test_deleting_the_recycle_bin_needs_a_reason_once_it_holds_real_runs(self):
        from watcher import results as r
        s = r.Session.start(True, "train", "twin", 1, "base", {}, root=self.root)
        pending = s.run_folder("TR-01", 1)
        r.write_json(pending / "run.json", {"task": "TR-01"})
        s.discard_run(pending, "bumped")
        for folder in (self.root / "Recycle_Bin", self.root / "Recycle_Bin" / "study_1"):
            self.assertTrue(r.is_real_path(folder, self.root), folder)
        with self.assertRaises(ValueError):
            r.delete_results(self.root / "Recycle_Bin", "", root=self.root, trash=lambda p: None)
        self.assertFalse(r.is_real_path(self.root / "Practice_Session", self.root))

    def test_the_generator_never_draws_the_templates_example(self):
        gen = _make_test_tasks_module()
        data = gen.make("sim-seed-108", twin=False, say=lambda line: None)    # (it drew the example before)
        self.assertEqual(gen.write(data, self.root), self.root / "Private_never_for_Claude" / "Test_Tasks" / "test.yaml")

    def test_a_refused_start_leaves_the_tick_boxes_working_and_none_while_tests_are_made(self):
        from types import SimpleNamespace
        with mock.patch.object(_window_module, "TRAIN_FILE", SHEET_TRAIN), \
                mock.patch("watcher.window.QMessageBox.warning") as warned, \
                mock.patch("watcher.window.QMessageBox.information") as told:
            window = self.window(mode="live", executor=SimpleNamespace(table_z_provider=lambda: None))
            window.start_session()                              # (the table's height isn't known: refused)
            self.assertIn("table's height", warned.call_args[0][2])
            self.assertEqual(window.plan, [], "no plan left behind")
            row = window._picker_rows()[0]
            from PyQt6.QtCore import Qt
            row.setCheckState(0, Qt.CheckState.Unchecked)
            self.assertIn(row.text(0), window._unticked["train"], "the tick boxes still work")
            window._testgen = object()                          # (the test tasks being made)
            window.start_session()
            self.assertIn("being made", told.call_args[0][2])
            self.assertIsNone(window.session)
            window._testgen = None

    def test_e_stop_from_the_main_window_pauses_run_by_itself(self):
        from types import SimpleNamespace
        window = self.window()
        window.auto_run.setChecked(True)
        window.session = SimpleNamespace(real=False, info={})
        window._on_robot_event({"kind": "estop"})              # (the main window's E-STOP, from the robot)
        self.app.processEvents()
        self.assertFalse(window.auto_run.isChecked())
        self.assertIn("E-STOP", window.run_text.toPlainText())
        window.session = None

    def test_a_hidden_level_filter_falls_back_to_all_and_the_loaded_bar_knows_the_plan(self):
        from dataclasses import replace
        from types import SimpleNamespace
        tasks = load_task_set(SHEET_TRAIN, 3)
        window = self.window()
        window.plan = [(replace(tasks.tasks[0], level=1), 1)]
        window._plan_status = ["Waiting"]
        window.level_chips[3].setChecked(True)                  # (a level the plan doesn't have)
        window._refresh_plan()
        self.assertTrue(window.level_chips["all"].isChecked(), "back to All levels")
        self.assertFalse(window.plan_tree.topLevelItem(0).isHidden(), "never a blank plan")
        window.session = SimpleNamespace(real=False, info={"set": "train"})
        window._loaded = "TR-05"                                 # (loaded, but not in this session)
        window._show_loaded()
        self.assertFalse(window.run_now_btn.isEnabled())
        self.assertIn("isn't in this session's plan", window.loaded_where.text())
        window.session = None


class TestSessionSecrecyTests(WatcherWindowTests):
    """A test session with Show test prompts off: no prompt, pass rule or target in the task line, the judge box, the
    score or the run log; nothing of the last run left on screen when the session ends."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):      # (run once, in the parent class)
        pass

    def test_the_test_prompt_stays_hidden_and_nothing_is_left_at_the_end(self):
        import importlib.util
        import tempfile
        import time
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import HIDDEN_DETAILS, WatcherContext, WatcherWindow
        from scripted import PutInPlaceClient
        robots.set_active("dobot_magician")
        gen = _make_test_tasks_module()
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        with tempfile.TemporaryDirectory() as folder, mock.patch("watcher.window.QMessageBox.information"):
            folder = Path(folder)
            path = gen.write(gen.make("secrecy-seed", twin=False, say=lambda line: None), folder / "results")
            tasks = load_task_set(path, 3)
            prompt = tasks.task("T-01").prompt
            (_, goal), = tasks.task("T-01").targets[0].items()      # (T-01: one cube moved, along x or y)
            axis, by = next((k, goal[k]) for k in ("dx", "dy") if goal.get(k))
            way = {("dx", 1): "forward", ("dx", -1): "back", ("dy", 1): "left", ("dy", -1): "right"}[(axis, 1 if by > 0
                                                                                                     else -1)]
            recipe = [("move_object", {"object_id": goal["cube"], "direction": way, "distance_mm": abs(by)})]
            twin = twin_test.TwinRun(tasks.task("T-01"), tasks)
            self.addCleanup(twin.stop)
            twin.executor.poses_dir = folder / "poses"
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor,
                                 agent=Agent(gen.RecipeClient(recipe), twin.executor, "scripted"),
                                 config={"llm": {"seed": 42}}, mode="demo", estop=twin.robot.stop,
                                 poses_dir=folder / "poses", twin_world=twin.world, results_root=folder / "results")
            window = WatcherWindow(ctx)
            window.session_box.setCurrentIndex(window.session_box.findData("test_twin"))
            window._loaded = "T-01"
            window._run_loaded()                               # (a session of just T-01)
            self.assertIsNotNone(window.session)
            self.wait_for(window, "setup")
            self.assertNotIn(prompt, window.task_label.text())
            self.assertIn("test prompt hidden", window.task_label.text())
            window.show_prompts.setChecked(True)
            self.assertIn(prompt, window.task_label.text(), "shown when you turn it on")
            window.show_prompts.setChecked(False)
            deadline = time.time() + 30
            while not window.run_btn.isEnabled() and time.time() < deadline:
                self.app.processEvents()
                window._show_setup(window._look(looks=1))
            window._start_run()
            self.wait_for(window, "verdict")
            self.assertNotIn(prompt, window.judge.text())
            self.assertIn("hidden", window.judge.text())
            log = window.run_text.toPlainText()
            self.assertNotIn("place_name", log, "the run log: tool names only")
            window._verdict("skipped")
            self.assertIn(HIDDEN_DETAILS, window.reveal.text())
            window._ask_save = lambda *a: {"tag": "Run1"}
            window._save_and_next()                            # (the only run: the session ends)
            self.assertIsNone(window.session)
            self.assertFalse(window.judge.isVisibleTo(window), "nothing of the last run left on screen")
            self.assertEqual(window.judge.text(), "")
            self.assertEqual(window.reveal.text(), "")
            window.close()


class PaperFreeTaskTests(unittest.TestCase):
    """The study's own training set (V4.1): no paper -- the cubes anywhere in the area by hand, every target relative
    to the cubes, measured from where they were seen to start; READY from the camera's look (check_start)."""

    @classmethod
    def setUpClass(cls):
        cls.tasks = load_task_set(STUDY_TRAIN, 3)

    def start(self, task_id):
        from watcher.arrange import arrange
        return arrange(self.tasks.task(task_id), self.tasks, "train", 1)[0]

    def judge(self, task_id, start, end):
        t = self.tasks.task(task_id)
        return score(t, end, self.tasks.zones, self.tasks.rule, self.tasks.cube_size_mm, start=start)

    def test_the_set_loads_without_paper(self):
        self.assertIsNone(self.tasks.sheet)
        self.assertEqual(self.tasks.area, {"x": [170.0, 290.0], "y": [-110.0, 110.0]})
        self.assertEqual([t.id for t in self.tasks.tasks], [f"TR-{n:02d}" for n in range(1, 21)])
        self.assertEqual([t.level for t in self.tasks.tasks], [1] * 5 + [2] * 5 + [3] * 5 + [4] * 5)
        self.assertEqual([len(t.start) for t in self.tasks.tasks], [1] * 10 + [2] * 5 + [3] * 5)
        self.assertTrue(all(t.layout == "random" for t in self.tasks.tasks))
        self.assertFalse(any(name.startswith("spot_") for name in self.tasks.zones), "no spots")

    def test_random_starts_are_seeded_apart_in_reach_and_doable(self):
        import math
        from watcher.arrange import START_GAP_MM, arrange, check_arrangement, count_arrangements
        for t in self.tasks.tasks:
            cubes, info = arrange(t, self.tasks, "train", 1)
            self.assertEqual(arrange(t, self.tasks, "train", 1)[0], cubes, "the same run starts the same way")
            self.assertEqual(info["seed"], f"train|{t.id}|1")
            self.assertEqual(set(info["xy"]), {c.label.replace(" cube", "") for c in cubes})
            self.assertIsNone(check_arrangement(t, self.tasks, cubes))
            for i, a in enumerate(cubes):
                self.assertTrue(160 <= math.hypot(a.x, a.y) <= 290)
                for b in cubes[i + 1:]:
                    self.assertGreaterEqual(math.hypot(a.x - b.x, a.y - b.y), 25 + START_GAP_MM - 1e-6)
            self.assertGreaterEqual(count_arrangements(t, self.tasks), 50, f"{t.id}: most hand starts will do")
        t = self.tasks.task("TR-14")
        self.assertNotEqual(arrange(t, self.tasks, "train", 1)[0], arrange(t, self.tasks, "train", 2)[0])

    def test_turned_is_measured_from_the_cubes_own_start(self):
        start = [Cube("blue cube", 230.0, 20.0, 12.0)]
        self.assertTrue(self.judge("TR-05", start, [Cube("blue cube", 231.0, 20.0, 42.0)]).passed)
        self.assertTrue(self.judge("TR-05", start, [Cube("blue cube", 231.0, 20.0, 42.0 - 90.0)]).passed,
                        "a cube looks the same every 90 degrees")
        self.assertFalse(self.judge("TR-05", start, [Cube("blue cube", 230.0, 20.0, -18.0)]).passed, "clockwise")
        self.assertFalse(self.judge("TR-05", start, [Cube("blue cube", 230.0, 20.0, 30.0)]).passed,
                         "30 degrees absolute isn't turned by 30")
        self.assertFalse(self.judge("TR-05", start, [Cube("blue cube", 250.0, 20.0, 42.0)]).passed,
                         "it may not wander off while it turns")

    def test_beside_further_and_nearer(self):
        start = [Cube("green cube", 200.0, 40.0, 0.0), Cube("red cube", 210.0, -40.0, 0.0)]
        good = [Cube("green cube", 210.0 + 55.0, -40.0, 0.0), Cube("red cube", 210.0, -40.0, 0.0)]
        self.assertTrue(self.judge("TR-13", start, good).passed, "further: +x, 25 + 30 mm centre to centre")
        wrong = [Cube("green cube", 210.0 - 55.0, -40.0, 0.0), Cube("red cube", 210.0, -40.0, 0.0)]
        self.assertFalse(self.judge("TR-13", start, wrong).passed, "nearer isn't further")
        start = [Cube("blue cube", 200.0, 60.0, 0.0), Cube("green cube", 260.0, -20.0, 0.0)]
        good = [Cube("blue cube", 260.0 - 45.0, -20.0, 45.0), Cube("green cube", 260.0, -20.0, 0.0)]
        self.assertTrue(self.judge("TR-15", start, good).passed, "nearer by 20 mm, then turned 45")

    def test_a_row_in_order_from_left_to_right(self):
        start = [Cube("red cube", 200.0, 60.0, 0.0), Cube("green cube", 250.0, 0.0, 0.0),
                 Cube("blue cube", 200.0, -60.0, 0.0)]

        def row(labels, along_x=False, step=55.0):
            return [Cube(lbl, 210.0 + (step * i if along_x else 0.0), 0.0 if along_x else step - step * i, 0.0)
                    for i, lbl in enumerate(labels)]
        self.assertTrue(self.judge("TR-18", start, row(["blue cube", "red cube", "green cube"])).passed)
        wrong = self.judge("TR-18", start, row(["red cube", "blue cube", "green cube"]))
        self.assertFalse(wrong.passed)
        self.assertIn("wanted blue cube, red cube, green cube", wrong.targets[0].detail)
        self.assertFalse(self.judge("TR-18", start, row(["blue cube", "red cube", "green cube"], along_x=True)).passed,
                         "a row away from the robot has no left to right")
        self.assertTrue(self.judge("TR-17", start, row(["green cube", "red cube", "blue cube"], True, 45.0)).passed,
                        "without an order, any line will do")

    def test_a_move_in_two_legs_is_scored_where_it_ends(self):
        start = [Cube("red cube", 230.0, 0.0, 5.0)]
        self.assertTrue(self.judge("TR-10", start, [Cube("red cube", 230.0, -30.0, 5.0)]).passed)
        self.assertFalse(self.judge("TR-10", start, [Cube("red cube", 230.0, 30.0, 5.0)]).passed)
        self.assertTrue(self.judge("TR-06", [Cube("green cube", 220.0, 0.0, 0.0)],
                                   [Cube("green cube", 240.0, -30.0, 0.0)]).passed)

    def test_the_pass_rule_in_words(self):
        from watcher.tasks import how_to_judge
        words = " ".join(how_to_judge(self.tasks.task("TR-08"), self.tasks.rule))
        self.assertIn("turned 30 degrees clockwise (seen from above) from how it started", words)
        words = " ".join(how_to_judge(self.tasks.task("TR-13"), self.tasks.rule))
        self.assertIn("further from the robot than the red cube", words)
        words = " ".join(how_to_judge(self.tasks.task("TR-18"), self.tasks.rule))
        self.assertIn("blue cube, red cube, green cube from the robot's left to its right", words)

    def test_ready_only_when_the_hands_start_will_do(self):
        from watcher.arrange import check_start
        t = self.tasks.task("TR-14")
        good = [Cube("red cube", 230.0, 50.0, 10.0), Cube("blue cube", 230.0, -50.0, -20.0)]
        self.assertIsNone(check_start(t, self.tasks, good))
        cases = [
            ([good[0]], "Put the blue cube"),
            (good + [Cube("green cube", 260.0, 0.0, 0.0)], "Take the green cube off"),
            ([good[0], Cube("blue cube", 230.0, 20.0, 0.0)], "further apart"),
            ([good[0], Cube("blue cube", 300.0, -50.0, 0.0)], "nearer the robot"),
            ([good[0], Cube("blue cube", 140.0, -50.0, 0.0)], "further from the robot"),
            ([good[0], Cube("blue cube", 200.0, -120.0, 0.0)], "too far to the robot's right"),
        ]
        for seen, words in cases:
            self.assertIn(words, check_start(t, self.tasks, seen) or "READY", seen)
        # in reach and apart, but the task can't be done from there: the red cube would end out of reach
        t = self.tasks.task("TR-12")
        far = [Cube("red cube", 230.0, -60.0, 0.0), Cube("blue cube", 180.0, 105.0, 0.0)]
        self.assertIn("can't be done from here", check_start(t, self.tasks, far))

    def test_room_between_and_a_first_leg_in_reach(self):
        from watcher.arrange import check_start
        t = self.tasks.task("TR-16")
        blue = Cube("blue cube", 180.0, -60.0, 0.0)
        tight = [Cube("red cube", 240.0, 35.0, 0.0), Cube("green cube", 240.0, -35.0, 0.0), blue]   # 70 apart
        self.assertIn("too close for a cube between them", check_start(t, self.tasks, tight))
        roomy = [Cube("red cube", 240.0, 45.0, 0.0), Cube("green cube", 240.0, -45.0, 0.0), blue]  # 90 apart
        self.assertIsNone(check_start(t, self.tasks, roomy))
        # TR-09: 50 mm further, then 30 mm left -- from here the first leg would end 291 mm out, past the arm's reach
        out = [Cube("green cube", 230.0, -80.0, 0.0)]
        self.assertIn("first leg", check_start(self.tasks.task("TR-09"), self.tasks, out))

    def test_the_checker_passes_it(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("check_tasks", ROOT / "study" / "check_tasks.py")
        ct = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(ct)
        problems, counts = ct.check(STUDY_TRAIN)
        self.assertEqual(problems, [])
        self.assertEqual(sum(counts.values()), 20)


class PaperFreeWindowTests(WatcherWindowTests):
    """The watcher with the paper-free set, in the twin: no outlines, READY from the camera's look, a run done by the
    tools' recipe, scored from where the cubes were seen to start."""

    def test_a_practice_run_is_checked_run_scored_and_saved(self):      # (run once, in the parent class)
        pass

    def test_a_paper_free_task_in_the_twin(self):
        import importlib.util
        import tempfile
        from app import robots
        from app.llm.agent import Agent
        from watcher.window import WatcherContext, WatcherWindow
        robots.set_active("dobot_magician")
        spec = importlib.util.spec_from_file_location("twin_test", ROOT / "study" / "twin_test.py")
        twin_test = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(twin_test)
        gen = _make_test_tasks_module()
        tasks = load_task_set(STUDY_TRAIN, 3)
        twin = twin_test.TwinRun(tasks.task("TR-01"), tasks)
        self.addCleanup(twin.stop)
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(_window_module, "TRAIN_FILE", STUDY_TRAIN):
            folder = Path(folder)
            twin.executor.poses_dir = folder / "poses"
            recipe = [("move_object", {"object_id": "red cube", "direction": "left", "distance_mm": 40})]
            agent = Agent(gen.RecipeClient(recipe), twin.executor, "scripted")
            ctx = WatcherContext(robot=twin.robot, camera=twin.camera, scene_builder=twin.scene_builder,
                                 executor=twin.executor, agent=agent, config={"llm": {"seed": 42}}, mode="demo",
                                 estop=twin.robot.stop, poses_dir=folder / "poses", twin_world=twin.world,
                                 results_root=folder / "results")
            window = WatcherWindow(ctx)
            window.set_box.setCurrentIndex(window.set_box.findData("train"))
            window.start_session()
            task = window.plan[0][0]
            self.assertEqual(task.id, "TR-01")
            self._wait_placed(window)
            window._show_setup(window._look(looks=1))
            text = window.setup_text.toPlainText()
            self.assertIn("Put the red cube anywhere on the grey sheet", text)
            self.assertIn("READY", text)
            self.assertNotIn("spot", text)
            self.assertEqual(window._outlines_3d, [], "no outlines to put them on")
            self.assertTrue(window.run_btn.isEnabled(), text)
            window._start_run()
            self.wait_for(window, "verdict")
            window._verdict("pass")
            run = next((folder / "results").rglob("run.json"))
            saved = json.loads(run.read_text(encoding="utf-8"))
            self.assertTrue(saved["passed"], saved.get("score"))
            self.assertEqual(saved["arrangement"]["seed"], "train|TR-01|1")
            self.assertTrue(saved["start_seen"], "scored from where the cubes were seen to start")
            window.end_session("test over")
            window.close()

    def _wait_placed(self, window, seconds=60):
        import time
        deadline = time.monotonic() + seconds
        while getattr(window, "_busy", False) and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(0.02)

class PersonAndCubeSizeTests(unittest.TestCase):
    """Study 2 (Dr. Curry approved, 2026-10-26): the cube size the session goes by at the top of the watcher, before a
    session starts; and when the arm needs a person (a held alarm, its homing or USB link lost), nothing starts by
    itself -- "Waiting for you" -- and how a run is scored doesn't change."""

    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def window(self, robot=None, executor=None, cube=25.0):
        from watcher.window import WatcherContext, WatcherWindow
        ctx = WatcherContext(robot=robot, camera=None, scene_builder=None, executor=executor, agent=None,
                             config={"vision": {"known_sizes_mm": {"cube": cube}}}, mode="live",
                             estop=lambda: None, poses_dir=Path("."))
        window = WatcherWindow(ctx)
        self.addCleanup(window.close)
        return window

    def test_the_cube_size_is_at_the_top_before_a_session(self):
        class Executor:
            cube_mismatch = None
        executor = Executor()
        window = self.window(executor=executor, cube=20.0)
        window._refresh_status()
        self.assertIn("Cubes: <b>20 mm</b>", window.status.right.text())
        self.assertNotIn("measure", window.status.right.text())
        executor.cube_mismatch = (24.8, 20.0, 25.0)            # (the app found the cubes 25 mm)
        window._refresh_status()
        self.assertIn("The cubes measure about 25 mm", window.status.right.text())

    def test_nothing_starts_on_an_arm_that_needs_a_person(self):
        class Robot:
            needs_person = "The Dobot was reconnected but not homed. Press Home on the Manual tab."
        robot = Robot()
        window = self.window(robot=robot)
        tasks = load_task_set(SHEET_TRAIN, 3)
        window.tasks = tasks
        window.session = type("Session", (), {"real": True, "record": lambda self, entry: None})()
        window.plan, window._plan_status = [(tasks.tasks[0], 1)], ["Now"]
        window.index, window.state = 0, "setup"
        window.run_btn.setEnabled(True)
        window.auto_run.setChecked(True)
        lines = []
        window._log = lines.append
        from watcher.status_strip import clock
        kind, head, sub, _, _ = window._status_now(clock)
        self.assertEqual(kind, "waiting")
        self.assertIn("the arm needs a person", head)
        self.assertIn("not homed", sub)
        window._start_run()
        self.assertEqual(window.state, "setup", "not started")
        self.assertTrue(any(line.startswith("Not started: the arm needs a person") for line in lines), lines)
        self.assertFalse(window.auto_run.isChecked(), "Run by itself paused")
        robot.needs_person = None                              # (Home pressed)
        self.assertIsNone(window._arm_needs_person())
        window.session = None


if __name__ == "__main__":
    unittest.main()

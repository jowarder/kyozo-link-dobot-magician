"""Drives the Calibration tab the way a person would, in demo mode, without a screen.

    python -m unittest discover -s tests -p test_ui.py -v

Uses a temporary folder for calibrations and saved sessions, so nothing in the project changes.
"""
from __future__ import annotations

import os
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")

from harness import ROOT  # noqa: F401,E402  (sets up sys.path and the working folder)
import numpy as np  # noqa: E402
from PyQt6.QtWidgets import QApplication, QMessageBox, QTabWidget  # noqa: E402

from app.calibration.replay import resolve  # noqa: E402
from app.config import load_config  # noqa: E402
from app.hardware.interfaces import Pose  # noqa: E402
from app.system_check import FAIL  # noqa: E402
from app.ui import main_window as main_window_module  # noqa: E402
from scripted import BesideClient, PickThenPutFreeClient, StackingClient  # noqa: E402

app = QApplication.instance() or QApplication([])


def pump_until(condition, timeout_s: float = 600.0) -> None:
    deadline = time.time() + timeout_s
    while not condition():
        if time.time() > deadline:
            raise TimeoutError("the UI did not finish in time")
        app.processEvents()
        time.sleep(0.02)


class CalibrationTabTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        cls._original_root = main_window_module.PROJECT_ROOT
        main_window_module.PROJECT_ROOT = Path(cls.folder.name)
        cls._original = (QMessageBox.question, QMessageBox.information, QMessageBox.warning)
        QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
        QMessageBox.information = staticmethod(lambda *a, **k: None)
        QMessageBox.warning = staticmethod(lambda *a, **k: None)
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"   # the tests' scene, not the one last picked in Settings
        config["display"] = {}   # default look and prompts (not step-by-step), whatever was last picked in Settings
        cls.window = main_window_module.MainWindow(config)
        cls.window.robot.max_speed = 3000   # fast: nobody is watching
        cls.window.show()
        cls.panel = cls.window.calibration_tab

    @classmethod
    def tearDownClass(cls):
        cls.window.jog_panel.stop_pose_monitor()
        cls.window.close()
        cls.window._twin_world.stop()
        QMessageBox.question, QMessageBox.information, QMessageBox.warning = cls._original
        main_window_module.PROJECT_ROOT = cls._original_root
        cls.folder.cleanup()

    def wait_idle(self):
        pump_until(lambda: self.panel._worker is None)

    def test_whole_workflow(self):
        window, panel = self.window, self.panel
        # 1. automatic calibration from a tip parked above the table
        window.robot.move_to(Pose(200, 0, 70))
        panel._start_auto()
        self.wait_idle()
        self.assertIn("Automatic calibration done", panel.result_label.text())
        self.assertIn("NOT FINISHED", panel.result_label.text())
        self.assertIsNotNone(panel._transform)
        self.assertTrue(panel.table_btn.isEnabled())

        # 2. touch the table (170: past MIN_RADIUS_MM, now the closest the robot will actually go)
        window.robot.move_to(Pose(170, 0, 0))
        panel._set_table_height()
        self.wait_idle()
        self.assertTrue(panel.result_label.text().startswith("Done."), panel.result_label.text())
        # just above the touched table (not the calibration error's margin above it: that kept the fingers off cubes)
        self.assertAlmostEqual(window.jog_panel._bound_fields["z_min"].value(), 1.0, delta=1.5)

        # 3. verify
        panel._verify()
        self.wait_idle()
        session = panel.recorder
        self.assertLess(session.verification["typical_mm"], 8.0, panel.result_label.text())

        # 4. the session was saved, and can be replayed
        self.assertTrue((session.folder / "session.json").exists())
        replayed = resolve(session.folder)
        self.assertGreaterEqual(len(replayed["points"]), 8)
        self.assertGreater(replayed["height_correction_mm"], 50.0)   # the marker sits ~94 mm above the tip

        # 5. the system check finds nothing wrong
        window._open_system_check()
        pump_until(lambda: window._system_check._worker is None)
        problems = [r for r in window._system_check._results if r.status == FAIL]
        self.assertEqual(problems, [], [f"{r.area}: {r.message}" for r in problems])

        # 6. a knocked camera is noticed
        window.drift.capture()
        pump_until(lambda: not window.drift._capturing)
        self.assertEqual(window.drift.check_now().status, "ok")
        window.camera.bump()
        self.assertEqual(window.drift.check_now().status, "moved")
        window.camera.unbump()

    def test_a_refused_move_is_reported_and_the_panel_recovers(self):
        window, panel = self.window, self.panel
        window.robot.move_to(Pose(200, 0, 70))
        real_move, calls = window.robot.move_to, {"n": 0}

        def refusing(pose, speed=None):
            calls["n"] += 1
            if calls["n"] == 3:
                raise RuntimeError("Robot is E-stopped.")
            return real_move(pose, speed)
        window.robot.move_to = refusing
        try:
            panel._start_auto()
            self.wait_idle()
        finally:
            window.robot.move_to = real_move
        self.assertIn("stopped", panel.result_label.text().lower())
        self.assertTrue(panel.auto_btn.isEnabled() and not panel.stop_btn.isEnabled())

    def test_stop_button_cancels_without_changing_anything(self):
        window, panel = self.window, self.panel
        window.robot.move_to(Pose(200, 0, 70))
        before = window.scene_builder.t_cam_to_robot.copy()
        panel._start_auto()
        panel._stop()
        self.wait_idle()
        self.assertIn("Stopped", panel.result_label.text())
        np.testing.assert_array_equal(window.scene_builder.t_cam_to_robot, before)

    def test_estop_button_stops_a_calibration_run_in_progress(self):
        window, panel = self.window, self.panel
        window.robot.move_to(Pose(200, 0, 70))
        before = window.scene_builder.t_cam_to_robot.copy()
        panel._start_auto()
        pump_until(lambda: panel._worker is not None and panel.stop_btn.isEnabled())
        time.sleep(1.0)                      # let it get under way
        try:
            window._on_estop()
            self.wait_idle()
        finally:
            window.robot.reset_estop()
        self.assertTrue(panel.auto_btn.isEnabled())
        self.assertRegex(panel.result_label.text(), "(?i)stopped")
        np.testing.assert_array_equal(window.scene_builder.t_cam_to_robot, before)

    def test_calibrate_with_a_cube_then_the_pick_test_and_one_more_cube(self):
        window, panel, world, robot = self.window, self.panel, self.window._twin_world, self.window.robot
        if panel.gripper is None or not panel.gripper.fingers:
            self.skipTest("config.yaml's gripper has no fingers")
        robot._held = robot._held_grip = None
        robot.open_gripper()
        world.switch_scenario("calibration_cubes")
        self.addCleanup(window._restore_builtin_calibration)
        self.addCleanup(world.switch_scenario, "two_blocks_and_tray")
        self.addCleanup(robot.open_gripper)
        self.addCleanup(panel._forget_touches)
        for button in (panel.pick_test_btn, panel.add_one_btn, panel.add_two_btn, panel.finish_cube_btn):
            self.assertTrue(button.isHidden())
        # the user: the fingertips touched to the table beside the cube ("Fingertips on the table": up 1 mm), then the
        # open gripper lowered round the cube as far as it goes, and closed
        x, y, _ = world.get_object_position_mm("red_cube")
        robot.move_to(Pose(x, y + 45, 60))
        robot.move_to(Pose(x, y + 45, 0))
        panel._touch_table()
        self.wait_idle()
        self.assertAlmostEqual(robot.get_pose().z, 1.0)
        self.assertIn("z = 0.0", panel.touch_label.text())
        self.assertIn("T1: x", panel.touches_list.text())                 # listed, and marked on the picture
        self.assertIn("once more", panel.touches_list.text())
        self.assertEqual([m["label"] for m in panel._touch_marks()], ["T1"])
        robot.move_to(Pose(x, y + 45, 60))
        robot.move_to(Pose(x, y, 60))
        robot.move_to(Pose(x, y, max(1.0, 20 - panel.gripper.finger_depth_mm)))
        robot.close_gripper()
        panel.cube_mode.setCurrentIndex(panel.cube_mode.findData("quick"))
        panel.cube_spots.setValue(8)
        panel._start_cube()
        self.wait_idle()
        text = panel.result_label.text()
        self.assertIn("Calibrated with the cube (quick)", text)
        self.assertIn("Cube measured", text)
        self.assertIn("Table: z = 0.0 mm (touched)", text)
        self.assertTrue(any(mark["kind"] == "arrow" for mark in panel._verify_marks))
        for button in (panel.pick_test_btn, panel.add_one_btn, panel.add_two_btn, panel.finish_cube_btn):
            self.assertFalse(button.isHidden())
        self.assertFalse(panel.cube_btn.isEnabled())
        saved = panel.calibration_path.read_text(encoding="utf-8")
        self.assertIn('"cube (quick)"', saved)
        self.assertIn('"tool_offset_mm"', saved)
        exact = self.window.camera.camera_to_robot_transform()
        np.testing.assert_allclose(window.scene_builder.t_cam_to_robot[:3, 3], exact[:3, 3], atol=3.0)
        self.assertAlmostEqual(window.jog_panel._bound_fields["z_min"].value(), 1.0, delta=2.5)
        # the session can be replayed
        replayed = resolve(panel.recorder.folder)
        self.assertGreaterEqual(len(replayed["points"]), 7)
        # the pick test
        panel._pick_test()
        self.wait_idle()
        self.assertIn("Pick test", panel.result_label.text())
        self.assertIn("3 of 3 held", panel.result_label.text())
        # the heights: the demo brings one more cube
        panel._add_cubes(1)
        self.wait_idle()
        self.assertTrue(any(object_id.startswith("blue_extra_cube") for object_id in world.object_ids))
        self.assertRegex(panel.result_label.text(), "Heights added|table calibration is kept")
        self.assertTrue(panel.add_one_btn.isHidden())
        self.assertTrue(panel.cube_btn.isEnabled())
        self.assertIsNone(robot._held)

    def test_one_calibration_style_is_shown_at_a_time(self):
        panel = self.panel
        self.addCleanup(panel.style_box.setCurrentIndex, panel.style_box.findData("cube"))
        self.assertEqual(panel.style_box.currentData(), "cube")              # the most accurate, first
        self.assertFalse(panel.cube_box.isHidden())
        self.assertTrue(panel.auto_box.isHidden() and panel.hand_box.isHidden())
        self.assertTrue(panel.table_btn.isHidden(), "the cube touches the table itself")
        self.assertFalse(panel.verify_btn.isHidden())
        panel.style_box.setCurrentIndex(panel.style_box.findData("auto"))     # (demo: no calibrating by hand)
        self.assertFalse(panel.auto_box.isHidden())
        self.assertTrue(panel.cube_box.isHidden() and panel.hand_box.isHidden())
        self.assertFalse(panel.table_btn.isHidden())
        self.assertIn("marker", panel.overview.text())
        panel.style_box.setCurrentIndex(-1)                                 # nothing chosen: no crash, as it was
        self.assertFalse(panel.auto_box.isHidden())

    def test_continuous_is_a_style_of_its_own(self):
        panel = self.panel
        self.addCleanup(panel.style_box.setCurrentIndex, panel.style_box.findData("cube"))
        panel.style_box.setCurrentIndex(panel.style_box.findData("continuous"))
        self.assertFalse(panel.continuous_box.isHidden())
        self.assertTrue(panel.cube_box.isHidden() and panel.auto_box.isHidden())
        self.assertTrue(panel.table_btn.isHidden())
        self.assertIn("kept right", panel.overview.text())
        self.assertTrue(panel.continuous_start_btn.isEnabled())
        self.assertFalse(panel.continuous_stop_btn.isEnabled())

    def test_continuous_calibration_follows_a_bumped_camera(self):
        from app.calibration import continuous as cc
        from app.vision.paper import DESIGNED
        window, monitor = self.window, self.window.continuous
        self.addCleanup(window._restore_builtin_calibration)
        self.addCleanup(window.camera.unbump)
        self.addCleanup(monitor.stop)
        monitor.start()
        pump_until(lambda: monitor.on)
        robot = np.array([[x, y, 0.0] for x, y in DESIGNED.corners()])

        def off_mm():
            cam = cc.apply(np.linalg.inv(window.camera.camera_to_robot_transform()), robot)
            return float(np.linalg.norm(cc.apply(window.scene_builder.t_cam_to_robot, cam) - robot, axis=1).mean())
        window.camera.bump(shift_mm=(3.0, 2.0, 0.0), yaw_deg=0.3, pitch_deg=0.2)
        self.assertGreater(off_mm(), 2.0)
        for _ in range(20):
            monitor.check_now()
            pump_until(lambda: not monitor.busy)
        self.assertLess(off_mm(), cc.NOISE_MM)
        self.assertGreaterEqual(monitor.summary()["corrections"], 1)
        # a calibration made some other way ends it (its reference was the old one's)
        window._restore_builtin_calibration()
        self.assertFalse(monitor.on)

    def test_cube_back_in_the_gripper_lets_the_angle_check_run_again(self):
        from types import SimpleNamespace
        panel = self.panel
        before = panel._cube_phase1
        self.addCleanup(panel._refresh_buttons)
        self.addCleanup(setattr, panel, "_cube_phase1", before)
        panel._cube_phase1 = SimpleNamespace(holding=False, cube_at=(200.0, 0.0))   # a step lost the cube
        panel._refresh_buttons()
        self.assertFalse(panel.regrip_btn.isHidden())
        self.assertFalse(panel.fingers_btn.isEnabled())
        self.assertIn("Grip it again", panel.fingers_btn.toolTip())
        panel._cube_regripped()                                  # (the question answered Yes)
        self.assertTrue(panel._cube_phase1.holding)
        self.assertTrue(panel.regrip_btn.isHidden())
        self.assertTrue(panel.fingers_btn.isEnabled())
        self.assertNotIn("Grip it again", panel.fingers_btn.toolTip())
        self.assertIn("held again", panel.cube_said.text())       # said by the buttons, not only far below

    def test_the_four_touch_points_and_taking_one_touch_away(self):
        import math
        from app.calibration.cube import TOUCH_POINTS
        window, panel = self.window, self.panel
        self.addCleanup(panel._forget_touches)
        self.assertEqual(panel.touch_point_box.count(), 6)
        panel.touch_point_box.setCurrentIndex(1)                         # stretched out
        panel._go_touch_point()
        self.wait_idle()
        here = window.robot.get_pose()
        _name, x, y = TOUCH_POINTS[1]
        self.assertLess(math.hypot(here.x - x, here.y - y), 2.0, panel.result_label.text())
        # four touches, one pressed 3 mm into the table: with 4, which one can't be told (each moves the fit alike --
        # marking the one furthest from it marked the good middle one), only that they disagree
        panel._touches = [(225.0, 0.0, 0.0), (275.0, 0.0, 0.2), (200.0, 110.0, -0.1), (200.0, -110.0, -3.0)]
        panel._show_touches()
        self.assertEqual(len(panel.touch_remove_btns), 4)
        self.assertNotIn("check this one", panel.touches_list.text())
        self.assertIn("Touch all 6 points", panel.touches_list.text())
        # all six: the odd one is told, and only that one
        panel._touches += [(165.0, 90.0, 0.1), (165.0, -90.0, -0.1)]
        panel._show_touches()
        marked = [line for line in panel.touches_list.text().splitlines() if "check this one" in line]
        self.assertEqual(len(marked), 1)
        self.assertTrue(marked[0].startswith("T4:"), marked[0])
        self.assertFalse(panel.touch_verdict.isHidden())                 # all 6: the verdict line
        self.assertIn("Redo T4: it is 3.0 mm off", panel.touch_verdict.text())     # (3 mm in: redo)
        panel._remove_touch(3)                                           # just that one
        self.assertEqual(len(panel._touches), 5)
        self.assertEqual(len(panel.touch_remove_btns), 5)
        self.assertNotIn("check this one", panel.touches_list.text())
        self.assertIn("not touched yet: 4", panel.touches_list.text())
        self.assertTrue(panel.touch_verdict.isHidden(), "not all 6: no verdict yet")
        self.assertIn("5 kept", panel.result_label.text())

    def test_earlier_calibrations_can_be_deleted(self):
        from unittest import mock
        from PyQt6.QtCore import QTimer
        from PyQt6.QtWidgets import QPushButton
        from app.calibration.storage import calibration_history, history_dir
        panel = self.panel
        folder = history_dir(panel.calibration_path)
        folder.mkdir(parents=True, exist_ok=True)
        stem = panel.calibration_path.stem
        template = ('{"t_cam_to_robot": [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]], "intrinsics": {}, '
                    '"method": "cube (fast)", "reprojection_error_mm": 1.0, "num_samples": 7, "extras": {}}')
        for n in range(3):
            (folder / f"{stem}_2026101{n}_120000.json").write_text(template, encoding="utf-8")
        self.addCleanup(lambda: [f.unlink() for f in folder.glob(f"{stem}_2026101*_120000.json")])
        before = len(calibration_history(panel.calibration_path))

        def press(*texts):
            def act():
                dialog = QApplication.activeModalWidget()
                for text in texts:
                    next(b for b in dialog.findChildren(QPushButton) if b.text() == text).click()
                dialog.reject()
            QTimer.singleShot(50, act)
        with mock.patch("watcher.results.to_recycle_bin", side_effect=lambda p: Path(p).unlink()):
            press("Delete the one chosen")
            panel._earlier_calibrations()
            self.assertEqual(len(calibration_history(panel.calibration_path)), before - 1)
            press("Delete all earlier ones")
            panel._earlier_calibrations()
        self.assertEqual(calibration_history(panel.calibration_path), [])
        self.assertIn("deleted", panel.result_label.text())

    def test_the_fingers_angle_check_can_be_quick(self):
        from types import SimpleNamespace
        from unittest import mock
        from app.calibration.wrist_check import FingersCheckOutcome
        from app.ui import calibration_panel as panel_module
        panel = self.panel
        before = panel._cube_phase1
        self.addCleanup(panel._refresh_buttons)
        self.addCleanup(setattr, panel, "_cube_phase1", before)
        self.addCleanup(panel.fingers_size.setCurrentIndex, 0)
        panel._cube_phase1 = SimpleNamespace(holding=True, cube_at=None)
        panel._refresh_buttons()
        self.assertFalse(panel.fingers_size.isHidden())
        self.assertEqual(panel.fingers_size.currentData(), 2)              # Full (20), as before
        panel.fingers_size.setCurrentIndex(panel.fingers_size.findData(1))
        with mock.patch.object(panel_module, "run_fingers_check",
                               return_value=FingersCheckOutcome(cancelled=True)) as run:
            panel._fingers_check()
            self.wait_idle()
        self.assertEqual(run.call_args.kwargs["spots"], 1)

    def test_cube_calibration_with_paper(self):
        import json
        from app.calibration.cube import middle_turn
        from app.vision.paper import paper_path
        window, panel, world, robot = self.window, self.panel, self.window._twin_world, self.window.robot
        if panel.gripper is None or not panel.gripper.fingers:
            self.skipTest("config.yaml's gripper has no fingers")
        robot._held = robot._held_grip = None
        robot.open_gripper()
        world.switch_scenario("calibration_cubes")
        self.addCleanup(window._restore_builtin_calibration)
        self.addCleanup(world.switch_scenario, "two_blocks_and_tray")
        self.addCleanup(robot.open_gripper)
        self.addCleanup(panel._forget_touches)
        self.addCleanup(panel.style_box.setCurrentIndex, panel.style_box.findData("cube"))
        self.addCleanup(window.jog_panel.set_z_min, window.jog_panel._bound_fields["z_min"].value())   # (it sets it)
        panel.style_box.setCurrentIndex(panel.style_box.findData("paper"))
        self.assertEqual(panel.style_box.currentText(), "Cube calibration with paper")
        self.assertFalse(panel.cube_box.isHidden())
        self.assertFalse(panel.paper_btn.isHidden())
        self.assertEqual(panel.cube_btn.text(), "Calibrate with a cube and paper")
        self.assertIn("Go to the paper's centre", panel.cube_guide.toPlainText())
        # the table touched, then the open gripper over where the sheet's centre belongs, the wrist in its middle
        robot.move_to(Pose(225, 45, 60))
        robot.move_to(Pose(225, 45, 0))
        panel._touch_table()
        self.wait_idle()
        panel._go_paper_centre()
        self.wait_idle()
        here = robot.get_pose()
        self.assertAlmostEqual(here.x, 225.0, delta=0.5)
        self.assertAlmostEqual(here.y, 0.0, delta=0.5)
        self.assertAlmostEqual(here.z, 20.0, delta=1.5)
        self.assertAlmostEqual(here.r, middle_turn(225.0, 0.0), delta=0.5)
        self.assertFalse(panel.lift_paper_btn.isHidden() or panel.down_paper_btn.isHidden())
        # the cube put under it, the gripper lowered round it and closed
        world.set_object_position_mm("red_cube", 225.0, 0.0, 10.0)
        grip_z = max(1.0, 20 - panel.gripper.finger_depth_mm)
        robot.move_to(Pose(225, 0, grip_z, here.r))
        robot.close_gripper()
        # lifted for the paper: 5 mm straight up, nothing else moved
        panel._lift_for_paper()
        self.wait_idle()
        lifted = robot.get_pose()
        self.assertAlmostEqual(lifted.z, grip_z + 5.0, delta=0.2)
        self.assertAlmostEqual(lifted.x, 225.0, delta=0.2)
        self.assertAlmostEqual(lifted.y, 0.0, delta=0.2)
        self.assertAlmostEqual(lifted.r, here.r, delta=0.2)
        self.assertGreater(world.get_object_position_mm("red_cube")[2], 12.0, "the cube went up with the gripper")
        panel.cube_mode.setCurrentIndex(panel.cube_mode.findData("quick"))
        panel.cube_spots.setValue(8)
        panel._start_cube()                                       # still lifted: refused
        self.wait_idle()
        self.assertIn("Put it back down", panel.result_label.text())
        self.assertAlmostEqual(robot.get_pose().z, grip_z + 5.0, delta=0.2, msg="nothing ran")
        # the paper lined up under the held cube and taped; the cube put back on it
        panel._down_onto_paper()
        self.wait_idle()
        self.assertAlmostEqual(robot.get_pose().z, grip_z, delta=0.2)
        self.assertIsNone(panel._paper_lift)
        panel._start_cube()
        self.wait_idle()
        text = panel.result_label.text()
        self.assertIn("Calibrated with the cube (quick)", text)
        self.assertIn("Paper: the twin's sheet", text)
        saved = json.loads(panel.calibration_path.read_text(encoding="utf-8"))
        self.assertEqual(saved["method"], "cube with paper (quick)")
        self.assertEqual(saved["extras"]["paper"]["found"], "twin")
        self.assertEqual(paper_path(panel.calibration_path).name, panel.calibration_path.stem + "_paper.json")
        paper = json.loads(paper_path(panel.calibration_path).read_text(encoding="utf-8"))
        self.assertAlmostEqual(paper["x"], 225.0)
        self.assertAlmostEqual(paper["turn_deg"], 0.0)
        panel._finish_cube()
        self.wait_idle()
        # the plain cube calibration is as it was
        panel.style_box.setCurrentIndex(panel.style_box.findData("cube"))
        self.assertTrue(panel.paper_btn.isHidden())
        self.assertEqual(panel.cube_btn.text(), "Calibrate with a cube")

    def test_the_paper_steps_only_when_they_make_sense(self):
        from types import SimpleNamespace
        window, panel, robot = self.window, self.panel, self.window.robot
        self.addCleanup(panel.style_box.setCurrentIndex, panel.style_box.findData("cube"))
        panel.style_box.setCurrentIndex(panel.style_box.findData("paper"))
        robot.move_to(Pose(225, 0, 40))
        self.assertTrue(panel.paper_btn.isEnabled() and panel.lift_paper_btn.isEnabled())
        self.assertFalse(panel.down_paper_btn.isEnabled(), "nothing lifted yet")
        panel._lift_for_paper()
        self.assertFalse(panel.paper_btn.isEnabled() or panel.lift_paper_btn.isEnabled(), "not while it runs")
        self.wait_idle()
        self.assertTrue(panel.down_paper_btn.isEnabled())
        self.assertFalse(panel.lift_paper_btn.isEnabled())
        # moved since (jogged): 'Put it back down' doesn't go straight from here to the old place
        robot.move_to(Pose(240, 20, 60))
        panel._down_onto_paper()
        self.assertIsNone(panel._worker, "nothing moved")
        self.assertIn("has moved since the cube was lifted", panel.result_label.text())
        self.assertIsNone(panel._paper_lift)
        self.assertFalse(panel.down_paper_btn.isEnabled())
        self.assertAlmostEqual(robot.get_pose().z, 60.0, delta=0.5)
        # a finished run still holds the cube at its waiting place: going to the paper's centre (gripper opened
        # first) isn't offered, nor done
        panel._cube_phase1 = SimpleNamespace(holding=True)
        self.addCleanup(setattr, panel, "_cube_phase1", None)
        panel._refresh_buttons()
        self.assertFalse(panel.paper_btn.isEnabled() or panel.lift_paper_btn.isEnabled())
        panel._go_paper_centre()
        self.assertIsNone(panel._worker)
        panel._cube_phase1 = None
        panel._refresh_buttons()

    def test_finish_is_offered_again_if_the_cube_couldnt_be_put_down(self):
        from types import SimpleNamespace
        from unittest import mock
        from app.ui import calibration_panel as panel_module
        panel = self.panel
        self.addCleanup(setattr, panel, "_cube_phase1", None)
        panel._cube_phase1 = SimpleNamespace(holding=True)
        panel._refresh_buttons()

        def refused(*_args):
            raise RuntimeError("the robot refused a move")
        with mock.patch.object(panel_module, "put_cube_down", refused):
            panel._finish_cube()
            self.wait_idle()
        self.assertIn("press Finish again", panel.result_label.text())
        self.assertIsNotNone(panel._cube_phase1, "still holding the cube: Finish is there to try again")
        self.assertFalse(panel.finish_cube_btn.isHidden())
        with mock.patch.object(panel_module, "put_cube_down", lambda *_args: None):
            panel._finish_cube()
            self.wait_idle()
        self.assertIsNone(panel._cube_phase1)
        self.assertTrue(panel.finish_cube_btn.isHidden())

    def test_one_thing_at_a_time_moves_the_arm(self):
        from unittest import mock
        window, panel, robot = self.window, self.panel, self.window.robot
        robot.move_to(Pose(200, 0, 60))
        # a calibration step running: the Manual tab, click-to-move, a prompt and the watcher's Start wait for it,
        # and Camera setup can't be opened (it changes the camera)
        panel._wrist_to_middle()
        self.assertIsNotNone(panel._worker)
        self.assertFalse(panel.camera_setup_btn.isEnabled())
        window.jog_panel._jog(0.0, 0.0, 10.0)
        self.assertIn("a calibration step is running", window.jog_panel.error_label.text())
        window._start_click_move(Pose(200, 40, 60))
        self.assertIn("a calibration step is running", window.statusBar().currentMessage())
        window.prompt_panel.prompt_input.setText("What do you see?")
        window.prompt_panel._send()
        self.assertFalse(window.prompt_panel.is_busy())
        self.assertIn("Not sent: a calibration step is running", window.prompt_panel.log.toPlainText())
        self.assertEqual(window.prompt_panel.prompt_input.text(), "What do you see?", "kept, to send later")
        window.prompt_panel.prompt_input.clear()
        self.assertIn("a calibration step is running", window._watcher_held())
        self.wait_idle()
        self.assertTrue(panel.camera_setup_btn.isEnabled())
        self.assertIsNone(window.arm_busy("manual"))
        # and the other way round: something else has the arm, the calibration's steps wait
        touches = list(panel._touches)
        with mock.patch.object(window.prompt_panel, "is_busy", lambda: True):
            panel._touch_table()
        self.assertIn("Not now: a prompt", panel.result_label.text())
        self.assertEqual(panel._touches, touches, "not even recorded")
        window._watcher_active = True
        try:
            panel._start_cube()
            self.assertIn("the watcher's session is open", panel.result_label.text())
        finally:
            window._watcher_active = False
        window._camera_setup_busy = "Camera setup is testing"
        try:
            panel._wrist_to_middle()
            self.assertIn("Camera setup is testing", panel.result_label.text())
        finally:
            window._camera_setup_busy = None
        self.assertIsNone(panel._worker)

    def test_the_window_doesnt_close_under_camera_setup_or_a_calibration_step(self):
        from unittest import mock
        window, panel, robot = self.window, self.panel, self.window.robot
        window._camera_setup_busy = "Camera setup is testing"
        try:
            self.assertFalse(window._may_close())
        finally:
            window._camera_setup_busy = None
        robot.move_to(Pose(200, 0, 60))
        panel._wrist_to_middle()
        with mock.patch.object(window, "close") as close:
            self.assertFalse(window._may_close(), "asked (Yes, here): the step stopped, closed once it has")
            self.assertTrue(panel._cancel.is_set())
            pump_until(lambda: close.called, 30)
        self.assertIsNone(panel._worker)
        self.assertFalse(window._close_when_calibration_stops)
        self.assertTrue(window._may_close())

    def test_remember_this_view_says_when_it_couldnt_be_saved(self):
        from unittest import mock
        window, drift = self.window, self.window.drift
        said = []
        with mock.patch.object(drift, "capture", lambda: drift._capture_failed("no picture")):
            window._remember_view(lambda text, tone="": said.append(text))
        self.assertIn("couldn't be saved: no picture", said[-1])
        drift.reference_saved.emit()          # (a later capture, for anything else: no stale "Saved." here)
        self.assertNotIn("Saved.", said[-1])

    def test_answering_no_keeps_the_save_it_anyway_result(self):
        from types import SimpleNamespace
        from unittest import mock
        panel = self.panel
        self.addCleanup(panel._refresh_buttons)
        self.addCleanup(setattr, panel, "_unsaved_cube", None)
        unsaved = SimpleNamespace(typical_mm=2.2)
        panel._unsaved_cube = unsaved          # (as a run over its limit leaves it)
        panel._refresh_buttons()
        with mock.patch.object(QMessageBox, "question", staticmethod(lambda *a, **k: QMessageBox.StandardButton.No)):
            panel._start_cube()
        self.assertIsNone(panel._worker)
        self.assertIs(panel._unsaved_cube, unsaved)
        self.assertFalse(panel.save_anyway_btn.isHidden())
        self.assertIn("2.20 mm", panel.save_anyway_btn.text())

    def test_a_paper_run_carried_on_after_a_restart_is_still_one(self):
        from PyQt6.QtWidgets import QWidget
        from app.calibration.cube import CubeOutcome, CubeProgress
        from app.ui.calibration_panel import CalibrationPanel
        folder = Path(self.folder.name) / "paper_restart"
        folder.mkdir()
        path = folder / "calibration.json"

        def make():
            panel = CalibrationPanel(self.window.robot, self.window.camera, path, lambda *a: None, feed_widget=QWidget())
            self.addCleanup(panel.deleteLater)
            return panel
        before = make()
        before._paper_run = True                 # (as a paper run saves after every spot)
        before._save_progress(CubeProgress(out=CubeOutcome(mode="quick"), route=[(200.0, 0.0, 0.0)], backgrounds=[],
                                           away=[], mode="quick", cube_size_mm=None, old_transform=None,
                                           base_offset=(0.0, 0.0)))
        after = make()                           # (the app opened again)
        self.addCleanup(after._discard_progress)
        self.assertIsNotNone(after._progress)
        self.assertTrue(after._paper_run)
        self.assertEqual(after.style_box.currentData(), "paper")
        self.assertFalse(after.style_box.isEnabled(), "kept while the run is there to carry on")
        self.assertEqual(after.cube_btn.text(), "Calibrate with a cube and paper")

    def test_a_cube_calibration_paused_and_carried_on_by_hand(self):
        window, panel, world, robot = self.window, self.panel, self.window._twin_world, self.window.robot
        if panel.gripper is None or not panel.gripper.fingers:
            self.skipTest("config.yaml's gripper has no fingers")
        robot._held = robot._held_grip = None
        robot.open_gripper()
        world.switch_scenario("calibration_cubes")
        self.addCleanup(window._restore_builtin_calibration)
        self.addCleanup(world.switch_scenario, "two_blocks_and_tray")
        self.addCleanup(robot.open_gripper)
        self.addCleanup(panel._discard_progress)
        self.addCleanup(panel._forget_touches)
        self.addCleanup(window.jog_panel.set_z_min, window.jog_panel._bound_fields["z_min"].value())   # (it sets it)
        self.assertTrue(panel.continue_btn.isHidden())
        x, y, _ = world.get_object_position_mm("red_cube")
        grip_z = max(1.0, 20 - panel.gripper.finger_depth_mm)
        robot.move_to(Pose(x, y + 45, 60))
        robot.move_to(Pose(x, y + 45, 0))
        panel._touch_table()
        self.wait_idle()
        robot.move_to(Pose(x, y + 45, 60))
        robot.move_to(Pose(x, y, 60))
        robot.move_to(Pose(x, y, grip_z))
        robot.close_gripper()
        panel.cube_mode.setCurrentIndex(panel.cube_mode.findData("quick"))
        panel.cube_spots.setValue(8)

        def pause_at_spot_3(text):
            if "Spot 3 of" in text:
                panel._pause_cube()
        armed = {"on": True}

        def pause_once(text):
            if armed["on"]:
                pause_at_spot_3(text)
        panel.progress.connect(pause_once)
        self.addCleanup(armed.update, on=False)
        panel._start_cube()
        self.wait_idle()
        self.assertIn("Paused: you pressed Pause", panel.result_label.text())
        self.assertFalse(panel.continue_btn.isHidden())
        self.assertFalse(panel.start_over_btn.isHidden())
        self.assertTrue(panel._progress_file.exists())
        self.assertIn("2 of 8 spots done", panel.progress_label.text())
        # the user takes over: the gripper round the cube where it is, closed
        here = robot.get_pose()
        if robot._held is None:
            cx, cy, _ = world.get_object_position_mm("red_cube")
            robot.move_to(Pose(here.x, here.y, 60, here.r))
            robot.move_to(Pose(cx, cy, 60, here.r))
            robot.move_to(Pose(cx, cy, grip_z, here.r))
            robot.close_gripper()
        else:
            robot.move_to(Pose(here.x, here.y, grip_z, here.r))
        armed["on"] = False
        panel._continue_cube()
        self.wait_idle()
        self.assertIn("Calibrated with the cube (quick)", panel.result_label.text())
        self.assertFalse(panel._progress_file.exists())
        self.assertTrue(panel.continue_btn.isHidden())
        panel._finish_cube()
        self.wait_idle()

    def test_the_demo_calibration_tab_shows_the_3d_model_and_no_clicking_by_hand(self):
        from app.ui.twin_view import TwinView
        panel = self.panel
        self.assertIsInstance(panel.video_widget, TwinView)
        styles = [panel.style_box.itemData(i) for i in range(panel.style_box.count())]
        self.assertEqual(styles, ["cube", "paper", "continuous", "auto"], "no clicking points on a picture there isn't")
        view = panel.video_widget
        self.assertGreater(view.receivers(view.table_clicked), 0, "a click on the table moves the arm, as elsewhere")
        from unittest import mock
        with mock.patch.object(self.window, "_calibration_busy", return_value=True),                 mock.patch.object(self.window, "_on_table_clicked") as moved:
            view.table_clicked.emit(200.0, 0.0)
        moved.assert_not_called()
        self.assertIn("off while a calibration", self.window.statusBar().currentMessage())

    def test_a_cube_calibration_over_its_limit_may_be_saved_anyway(self):
        # (the lab, 2026-10-12: Fast, 6 spots, 1.73 mm against the 1.5 limit -- everything else went through)
        import json
        import numpy as np
        from app.calibration.cube import CubeOutcome
        from app.ui.calibration_panel import CalibrationPanel
        window = self.window
        path = Path(self.folder.name) / "over_limit.json"
        calibrated = []
        panel = CalibrationPanel(window.robot, window.camera, path, lambda *a, **k: calibrated.append(a),
                                 **window._panel_extras())
        self.addCleanup(panel.deleteLater)

        def outcome(typical):
            return CubeOutcome(mode="fast", transform=np.eye(4), errors_mm=[typical - 0.1, typical, typical + 0.1],
                               table_z=-32.4, tool_offset_mm=(0.0, 0.0), over_limit=True, pass_mm=1.5,
                               reason=f"the spots typically disagree by {typical:.2f} mm (it should be under 1.5).")
        panel._cube_done(outcome(4.0))
        self.assertTrue(panel.save_anyway_btn.isHidden(), "far over: not offered")
        panel._cube_done(outcome(1.73))
        self.assertFalse(panel.save_anyway_btn.isHidden())
        self.assertIn("1.73", panel.save_anyway_btn.text())
        self.assertFalse(path.exists(), "nothing saved until asked")
        panel._save_cube_anyway()
        saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertIn("over the limit", saved["method"])
        self.assertTrue(saved["extras"]["over_limit"])
        self.assertEqual(saved["extras"]["pass_mm"], 1.5)
        self.assertEqual(len(calibrated), 1, "the app uses it")
        self.assertTrue(panel.save_anyway_btn.isHidden())

    def test_selecting_a_point_shows_where_it_was_clicked(self):
        # (calibrating by hand: a real camera's picture, as live -- the demo's tab shows the 3D model instead)
        from app.ui.calibration_panel import CalibrationPanel
        window = self.window
        panel = CalibrationPanel(window.robot, window.camera, Path(self.folder.name) / "by_hand.json",
                                 lambda *a, **k: None, **window._panel_extras())
        self.addCleanup(panel.deleteLater)
        self.assertIn("hand", [panel.style_box.itemData(i) for i in range(panel.style_box.count())])
        panel._reset()
        for x, y, z, u, v in ((200, 0, 50, 690, 426), (148, -72, 30, 555, 474), (250, 90, 60, 828, 381)):
            window.robot.move_to(Pose(x, y, z))
            panel._arm()
            panel._on_pixel_clicked(u, v)
        marks = panel.video_widget._marks
        self.assertEqual([m["kind"] for m in marks].count("sample"), 3, "every clicked point is shown")
        panel.sample_list.setCurrentRow(1)
        marks = panel.video_widget._marks
        selected = [m for m in marks if m["kind"] == "selected"]
        self.assertEqual(len(selected), 1)
        self.assertEqual((selected[0]["u"], selected[0]["v"], selected[0]["label"]), (555, 474, "#2"))
        self.assertEqual([m["label"] for m in marks if m["kind"] == "sample"], ["1", "3"])
        panel._reset()
        self.assertEqual(panel.video_widget._marks, [], "nothing left after a reset")

    def test_a_prompt_puts_the_red_cube_on_the_blue_cube_in_demo_mode(self):
        window = self.window
        world, robot = window._twin_world, window.robot
        robot._place_object("red_cube", 220, -60, 10.0)        # back where the scenario starts
        robot._place_object("blue_cube", 220, 60, 10.0)
        window.agent.client = StackingClient()
        window.prompt_panel._send_text("put the red cube on the blue cube")
        pump_until(lambda: not window.prompt_panel.is_busy())
        log = window.prompt_panel.log.toPlainText()
        self.assertNotIn("refused", log, log)
        red, blue = (world.get_object_position_mm(n) for n in ("red_cube", "blue_cube"))
        self.assertLess(((red[0] - blue[0]) ** 2 + (red[1] - blue[1]) ** 2) ** 0.5, 12.0, (red, blue, log))
        self.assertAlmostEqual(red[2] - blue[2], 20.0, delta=1.5)   # on it (20 mm cubes)
        robot._place_object("red_cube", 220, -60, 10.0)        # leave the scene as it was
        robot._place_object("blue_cube", 220, 60, 10.0)

    def test_a_cube_under_another_cube_can_be_picked_and_put_near_the_base(self):
        window = self.window
        world, robot = window._twin_world, window.robot
        robot._place_object("red_cube", 280, 0, 14.0)          # the red cube in the tray, the blue one on top of it
        robot._place_object("blue_cube", 280, 0, 14.0 + 20)
        try:
            window.agent.client = PickThenPutFreeClient("red cube", "near_base")
            window.prompt_panel._send_text("pick the red cube and put it close to the robot base")
            pump_until(lambda: not window.prompt_panel.is_busy())
            log = window.prompt_panel.log.toPlainText()
            red, blue = (world.get_object_position_mm(n) for n in ("red_cube", "blue_cube"))
            self.assertNotIn("refused", log, log)
            self.assertLess((red[0] ** 2 + red[1] ** 2) ** 0.5, 200.0, (red, log))            # near the base
            self.assertGreater(((red[0] - blue[0]) ** 2 + (red[1] - blue[1]) ** 2) ** 0.5, 50.0, (red, blue, log))
            self.assertGreater(((blue[0] - 280) ** 2 + blue[1] ** 2) ** 0.5, 40.0, "the top cube was moved aside")
            self.assertIsNone(window.tool_executor.holding)
        finally:
            robot._place_object("red_cube", 220, -60, 10.0)
            robot._place_object("blue_cube", 220, 60, 10.0)

    def test_the_speed_drop_down_changes_how_fast_the_demo_arm_moves(self):
        window = self.window
        panel = window.jog_panel
        original, shown = window.robot.max_speed, panel.speed_combo.currentIndex()
        config_speed = window.config["robot"]["max_speed"]
        try:
            self.assertFalse(panel.gripper_combo.isEnabled(), "the simulated gripper is instant")
            index = 0 if shown != 0 else 1        # a different choice from the one config.yaml starts on
            wanted = float(panel.speed_combo.itemData(index))
            panel.speed_combo.setCurrentIndex(index)
            pump_until(lambda: window.config["robot"]["max_speed"] == wanted, 10)
            self.assertEqual(window.robot.max_speed, wanted)
        finally:
            window.robot.max_speed = original
            window.config["robot"]["max_speed"] = config_speed
            panel.speed_combo.blockSignals(True)
            panel.speed_combo.setCurrentIndex(shown)
            panel.speed_combo.blockSignals(False)

    def test_the_drop_downs_reach_a_real_robot_and_go_back_if_it_refuses(self):
        from test_dobot_driver import FakeDobot, make_robot
        from app.ui.jog_panel import JogPanel
        fake = FakeDobot()
        robot = make_robot(fake, max_speed=100)
        saved = []
        with tempfile.TemporaryDirectory() as folder:
            panel = JogPanel(robot, Path(folder), {"x": [0, 1], "y": [0, 1], "z": [0, 1]}, lambda b: None,
                             on_setting_changed=lambda key, value: saved.append((key, value)))
            try:
                self.assertEqual(panel.speed_combo.currentData(), 100.0)
                panel.speed_combo.setCurrentIndex(panel.speed_combo.findData(150.0))     # Fast
                pump_until(lambda: saved, 10)
                self.assertEqual(fake.speed[0], 150.0)
                self.assertEqual(saved[-1], ("max_speed", 150.0))
                panel.gripper_combo.setCurrentIndex(panel.gripper_combo.findData(1.5))   # Careful
                pump_until(lambda: len(saved) == 2, 10)
                self.assertEqual(robot.gripper_settle_s, 1.5)
                self.assertEqual(saved[-1], ("gripper_settle_s", 1.5))

                fake._set_ptp_coordinate_params = None                  # the arm won't take the next speed
                panel.speed_combo.setCurrentIndex(panel.speed_combo.findData(20.0))
                pump_until(lambda: "Could not change the speed" in panel.error_label.text(), 10)
                self.assertEqual(panel.speed_combo.currentData(), 150.0, "the drop-down shows what the arm is really doing")
                self.assertEqual(robot.max_speed, 150.0)
            finally:
                panel.stop_pose_monitor()

    def test_a_jog_stopped_by_z_min_says_so(self):
        """Z min had been left 39 mm above the table: jogging down, the arm just stopped there, without a word."""
        from test_dobot_driver import FakeDobot, make_robot
        from app.ui.jog_panel import JogPanel
        robot = make_robot(FakeDobot(), max_speed=100)
        robot.bounds["z"][0] = 0.6
        with tempfile.TemporaryDirectory() as folder:
            panel = JogPanel(robot, Path(folder), robot.bounds, lambda b: None)
            try:
                panel._on_pose_updated(Pose(200.0, 0.0, 3.0, 0.0))
                panel.step_spinbox.setValue(10.0)
                panel._jog(0.0, 0.0, -10.0)
                self.assertIn("Z min (0.6 mm) stops it here", panel.error_label.text())
                panel.error_label.setText("")
                panel._on_pose_updated(Pose(200.0, 0.0, 50.0, 0.0))
                panel._jog(0.0, 0.0, -10.0)
                self.assertEqual(panel.error_label.text(), "", "nothing in the way: nothing said")
            finally:
                panel.stop_pose_monitor()

    def test_a_prompt_puts_the_red_cube_beside_the_blue_cube_not_on_top(self):
        window = self.window
        world, robot = window._twin_world, window.robot
        robot._place_object("red_cube", 220, -60, 10.0)
        # (away from the tray: at (220, 60) its right side is so near the tray's wall that the fingers don't fit)
        robot._place_object("blue_cube", 220, 100, 10.0)
        try:
            window.agent.client = BesideClient("red cube", "blue cube", "right", 10.0)
            window.prompt_panel._send_text("put the red cube on the right side of the blue cube, 10 mm apart")
            pump_until(lambda: not window.prompt_panel.is_busy())
            log = window.prompt_panel.log.toPlainText()
            red, blue = (world.get_object_position_mm(n) for n in ("red_cube", "blue_cube"))
            self.assertNotIn("refused", log, log)
            self.assertAlmostEqual(red[2], blue[2], delta=1.0, msg="on the table beside it, not stacked on top")
            self.assertLess(red[1], blue[1], "the robot's right is -y")
            self.assertAlmostEqual(blue[1] - red[1] - 20.0, 10.0, delta=2.0, msg=(red, blue, log))   # 20 mm cubes
            self.assertLess(abs(red[0] - blue[0]), 5.0)
        finally:
            robot._place_object("red_cube", 220, -60, 10.0)
            robot._place_object("blue_cube", 220, 60, 10.0)

    def test_opening_the_system_check_again_reuses_the_same_window(self):
        from app.ui.system_check_dialog import SystemCheckDialog
        window = self.window
        for _ in range(3):
            window._open_system_check()
            pump_until(lambda: window._system_check._worker is None)
        self.assertEqual(len(window.findChildren(SystemCheckDialog)), 1, "one window, not one per click")

    def test_the_memory_warning_does_not_close_or_block_anything(self):
        from unittest import mock
        from PyQt6.QtWidgets import QPushButton
        window = self.window
        window._memory_warned = False
        with mock.patch.object(main_window_module, "app_memory_mb", return_value=4500.0):
            window._log_memory()
            window._log_memory()                                   # a second minute: no second warning
        notices = [b for b in window.findChildren(QMessageBox) if b.isVisible()]
        self.assertEqual(len(notices), 1, "warned once")
        self.assertIsNone(QApplication.activeModalWidget(), "nothing is modal, so the window still works")
        self.assertTrue(window.isVisible(), "and the app was not closed")
        estop = next(b for b in window.findChildren(QPushButton) if b.text() == "E-STOP")
        estop.click()                                              # E-STOP works while the warning is showing
        self.assertTrue(window.robot._estopped)
        window.robot.reset_estop()
        notices[0].close()

    def test_refuses_to_start_too_near_the_base(self):
        window, panel = self.window, self.panel
        # The robot itself now refuses to be commanded this close to the base (see
        # test_hardware_realism.py), so move_to can no longer put it there -- set the pose directly,
        # the way it would end up if someone jogged a real arm there by hand.
        window.robot._pose = Pose(120, 0, 70)   # closer than the arm can reach down to the table
        panel._start_auto()
        self.assertIsNone(panel._worker)
        self.assertIn("middle of the workspace", panel.result_label.text())


class FeedOverlayTests(unittest.TestCase):
    def test_no_boxes_on_the_feed_until_the_camera_is_calibrated(self):
        # (the lab, 2026-10-21: uncalibrated, the detector boxed the arm, the paper's edges and the sheet)
        import numpy as np
        from types import SimpleNamespace
        from app.ui.video_widget import VideoWidget
        calls, calibrated = [], {"yes": False}
        detector = SimpleNamespace(needs_depth=False, overlay_every=1,
                                   detect=lambda rgb: calls.append(1) or [SimpleNamespace(bbox=(10, 10, 20, 20),
                                                                                          label="white block")])
        camera = SimpleNamespace(get_frame=lambda: None)
        widget = VideoWidget(camera, detector=detector, detections_when=lambda: calibrated["yes"])
        widget._timer.stop()                       # (no feed to poll here)
        image = np.zeros((120, 160, 3), np.uint8)
        widget._with_overlay(image)
        self.assertEqual(calls, [], "nothing looked for")
        calibrated["yes"] = True
        shown = widget._with_overlay(image)
        self.assertEqual(len(calls), 1)
        self.assertTrue(shown[8:32, 8:32].any(), "the box is drawn once calibrated")


class ParkingSpotTests(unittest.TestCase):
    def test_the_real_dobot_parks_out_of_the_cameras_view_without_a_look_pose_set(self):
        # (the lab, 2026-10-22: none set, the arm stayed above the cube it had just put down; the next look missed it)
        from types import SimpleNamespace
        from app import robots
        bounds = {"x": [-320.0, 320.0], "y": [-300.0, 300.0], "z": [-43.3, 292.0]}
        holder = SimpleNamespace(config={"mode": "live", "robot": {"workspace_bounds": bounds, "max_reach_mm": 300.0}},
                                 robot_profile=robots.profile("dobot_magician"))
        spot = main_window_module.MainWindow._look_pose(holder)
        self.assertIsNotNone(spot)
        self.assertEqual((round(spot.x), round(spot.y)), (110, 225), "where the cube calibration waits")
        holder.config["robot"]["look_pose"] = [150.0, -200.0, 90.0]
        self.assertEqual(main_window_module.MainWindow._look_pose(holder).y, -200.0, "one set is kept")


class PaperFileTests(unittest.TestCase):
    def test_each_calibration_keeps_its_own_paper_and_an_old_shared_one_is_ignored(self):
        # (a review found: one paper.json for every calibration file -- the demo's twin sheet, "found" exactly, was
        # then trusted by a live session, which skips its paper-moved check for it)
        from app.vision.paper import PaperPose, load_paper, paper_path, save_paper
        folder = Path(tempfile.mkdtemp())
        names = ("calibration.json", "calibration_demo.json", "calibration_xarm6.json", "calibration_demo_xarm6.json")
        self.assertEqual(len({paper_path(folder / name) for name in names}), 4)
        self.assertEqual(paper_path(folder / "calibration.json"), folder / "calibration_paper.json")
        save_paper(folder / "paper.json", PaperPose(found="twin"))          # (an old shared one: whose isn't known)
        self.assertIsNone(load_paper(paper_path(folder / "calibration.json")))
        save_paper(paper_path(folder / "calibration_demo.json"), PaperPose(found="twin"))
        self.assertIsNone(load_paper(paper_path(folder / "calibration.json")), "the demo's sheet isn't the lab's")
        self.assertEqual(load_paper(paper_path(folder / "calibration_demo.json")).found, "twin")


class DemoFloorTests(unittest.TestCase):
    """A real calibration's z_min (config.yaml, this machine's own live setup) must not leak into
    the demo, whose table is always a fixed prop at z = 0."""

    def setUp(self):
        self._originals = (QMessageBox.question, QMessageBox.information, QMessageBox.warning)
        QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
        QMessageBox.information = staticmethod(lambda *a, **k: None)
        QMessageBox.warning = staticmethod(lambda *a, **k: None)

    def tearDown(self):
        QMessageBox.question, QMessageBox.information, QMessageBox.warning = self._originals

    def test_demo_mode_does_not_inherit_a_live_z_min_below_the_table(self):
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"   # the tests' scene, not the one last picked in Settings
        config["display"] = {}   # default look and prompts (not step-by-step), whatever was last picked in Settings
        # a real arm's limits in config.yaml (its own frame: the table 58 mm below its zero; an X max for its mount)
        config["robot"]["workspace_bounds"] = {"x": [-300.0, 268.0], "y": [-300.0, 300.0], "z": [-58.6, 300.0]}
        with tempfile.TemporaryDirectory() as folder:
            original_root = main_window_module.PROJECT_ROOT
            main_window_module.PROJECT_ROOT = Path(folder)
            try:
                window = main_window_module.MainWindow(config)
                try:
                    self.assertGreaterEqual(window.robot.bounds["z"][0], 0.0)
                    self.assertGreater(window.robot.bounds["x"][1], 300.0, "the demo's tray at x = 280 within reach")
                    window.robot.move_to(Pose(x=200, y=0, z=-40))
                    self.assertGreaterEqual(window.robot.get_pose().z, -0.5,
                                            "the tip must not be sent through the demo's own table")
                    self.assertGreaterEqual(window.jog_panel._bound_fields["z_min"].value(), 0.0,
                                            "the Manual tab must show the corrected floor, not config.yaml's")
                finally:
                    window.jog_panel.stop_pose_monitor()
                    window.close()
                    window._twin_world.stop()
            finally:
                main_window_module.PROJECT_ROOT = original_root

    def test_typing_a_lower_z_min_in_the_bounds_editor_is_also_corrected(self):
        """The startup fix alone isn't enough: 'Apply & Save' in the bounds editor sets
        robot.bounds directly, bypassing it, unless the callback also catches this path."""
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"   # the tests' scene, not the one last picked in Settings
        config["display"] = {}   # default look and prompts (not step-by-step), whatever was last picked in Settings
        with tempfile.TemporaryDirectory() as folder:
            original_root = main_window_module.PROJECT_ROOT
            main_window_module.PROJECT_ROOT = Path(folder)
            try:
                window = main_window_module.MainWindow(config)
                try:
                    panel = window.jog_panel
                    panel._bound_fields["z_min"].setValue(-40.0)
                    panel._apply_bounds()
                    self.assertGreaterEqual(window.robot.bounds["z"][0], 0.0)
                    self.assertGreaterEqual(panel._bound_fields["z_min"].value(), 0.0,
                                            "the spinbox must show the corrected value, not -40")
                finally:
                    window.jog_panel.stop_pose_monitor()
                    window.close()
                    window._twin_world.stop()
            finally:
                main_window_module.PROJECT_ROOT = original_root

    def test_a_carried_object_is_also_protected(self):
        config = load_config()
        config["mode"] = "demo"
        config.setdefault("twin", {})["scenario"] = "two_blocks_and_tray"   # the tests' scene, not the one last picked in Settings
        config["display"] = {}   # default look and prompts (not step-by-step), whatever was last picked in Settings
        with tempfile.TemporaryDirectory() as folder:
            original_root = main_window_module.PROJECT_ROOT
            main_window_module.PROJECT_ROOT = Path(folder)
            try:
                window = main_window_module.MainWindow(config)
                try:
                    from app.hardware.sim_robot import Collision
                    window.robot._held = "red_cube"
                    with self.assertRaisesRegex(Collision, "the red cube it carries touched the table"):
                        window.robot.move_to(Pose(x=200, y=-100, z=-40))   # stopped where it meets the table
                    z = window._twin_world.get_object_position_mm("red_cube")[2]
                    self.assertGreaterEqual(z, 9.5, "the cube (20 mm) must rest on the table, not sink into it")
                finally:
                    window.jog_panel.stop_pose_monitor()
                    window.close()
                    window._twin_world.stop()
            finally:
                main_window_module.PROJECT_ROOT = original_root


class LiveModeWithoutHardwareTests(unittest.TestCase):
    """Starting in live mode with nothing plugged in must not crash: the stand-ins report the problems."""

    def test_starts_and_reports_what_is_missing(self):
        with tempfile.TemporaryDirectory() as folder:
            original = (main_window_module.PROJECT_ROOT, main_window_module.DobotRobot, main_window_module.OrbbecCamera)
            main_window_module.PROJECT_ROOT = Path(folder)

            def missing(*args, **kwargs):
                raise RuntimeError("nothing is plugged in")
            main_window_module.DobotRobot = missing
            main_window_module.OrbbecCamera = missing
            try:
                config = load_config()
                config["mode"] = "live"
                config["display"] = {}   # default settings, whatever was last picked in Settings
                window = main_window_module.MainWindow(config)
                window.show()
                pump_until(lambda: True)
                self.assertNotIn("simulated", window.camera_status.lower())
                window.drift.check()                     # nothing to compare with; must not raise
                pump_until(lambda: window.drift._workers == [])
                window._open_system_check()
                pump_until(lambda: window._system_check._worker is None)
                areas = {r.area: r.status for r in window._system_check._results}
                self.assertEqual(areas.get("robot"), FAIL)
                self.assertEqual(areas.get("camera"), FAIL)
                window.close()
            finally:
                main_window_module.PROJECT_ROOT, main_window_module.DobotRobot, main_window_module.OrbbecCamera = original


if __name__ == "__main__":
    unittest.main()

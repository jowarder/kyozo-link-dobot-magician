"""Draws Kyozo Link's flowcharts: one data file in, every format out.

    python docs/flowcharts/make_flowcharts.py

Writes, next to this file:
  kyozo_link.drawio                 the 5 charts as pages of one diagrams.net file (open and edit at app.diagrams.net)
  <n>_<chart>.svg / <n>_<chart>_bw.svg   each chart, in colour and in black and white
  kyozo_link_flowcharts.pdf / _bw.pdf    all 5 charts, one per page
  kyozo_link_flowcharts.html        the 5 charts as one page: switch charts, zoom, click a step for its details

The charts follow ISO 5807 shapes (terminator, process, decision, input/output, predefined process, manual operation,
data store, on-page connector), with swimlanes for who does each step. They describe what the code does (the
`src` of each step); when the code changes, change the CHARTS below and run this again.
"""
from __future__ import annotations

import html
import json
import math
import os
import sys
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Optional

HERE = Path(__file__).resolve().parent
VERSION = "V4.6"
DATE = date.today().isoformat()

# ---- the charts ------------------------------------------------------------------------------------------------------
# A step: (id, lane, row, shape, title, subtitle, src, details). Shapes: term, proc, dec, io, pre, manual, store, err.
# An edge: (from, to, label, kind, route). Kinds: flow, error, data, optional, jump:<letter>:<side the jump leaves>.
# Routes: auto, vh (down, then across into the side), hv (across, then down into the top).

CHARTS = [
    {
        "key": "overview", "number": "S0", "title": "Overview", "prefix": "O",
        "subtitle": "From starting the app to the last request",
        "lanes": ["You", "App", "AI agent", "Robot and camera", "Files"],
        "steps": [
            ("O1", 1, 0, "term", "Start", "Run Kyozo Link.bat", "Run Kyozo Link.bat, app/main.py",
             "The launcher starts the app with the project's Python environment."),
            ("O2", 0, 1, "io", "Choose robot and mode", "start-up window", "app/ui/robot_chooser.py",
             "Dobot Magician or xArm 6; demo (no hardware) or live. The choice is remembered in config.yaml."),
            ("O3", 1, 2, "proc", "Build the main window", "tabs, detector, AI client", "app/ui/main_window.py",
             "Reads config.yaml, sets the active robot profile, builds the tabs, the object finder, the scene, the "
             "Ollama client and the tools."),
            ("O18", 2, 2, "proc", "Load the AI model", "Qwen3 into Ollama", "app/llm/ollama_client.py",
             "The model chosen on the Prompt tab is loaded into Ollama on this PC and kept there while the app is open "
             "(30 minutes after the last use); nothing goes to the internet."),
            ("F1", 4, 1, "store", "config.yaml", "robot, mode, settings", "config.yaml",
             "Settings: robot and mode, camera, AI model, display, the robots' own sections."),
            ("O4", 1, 3, "dec", "Live mode?", "", "MainWindow._build_backends", "Demo mode builds the twin instead "
             "of connecting hardware."),
            ("O5", 3, 3, "proc", "Build the demo twin", "simulated arm and camera", "app/twin/world.py, "
             "app/hardware/sim_robot.py, sim_camera.py",
             "A PyBullet table with the demo scene; the simulated arm obeys the same gripper and reach rules."),
            ("O6", 1, 4, "proc", "Connect robot and camera", "USB, Ethernet, USB 3", "app/hardware/dobot.py, xarm.py, "
             "camera.py", "Dobot over USB serial, xArm over Ethernet (its IP), the Gemini 335 over USB 3; the "
             "camera's lens bend is read and pictures are straightened."),
            ("O7", 1, 5, "dec", "Both connected?", "", "MainWindow._mark_robot_connected",
             "The status bar shows each connection."),
            ("O8", 3, 5, "err", "Go on without it", "System check says why", "app/system_check.py",
             "The app opens anyway; moves and looks are refused until the hardware is back."),
            ("O9", 1, 6, "proc", "Load the calibration", "transform, table correction", "app/calibration/storage.py",
             "calibration*.json for this robot: the camera-to-robot transform and, from a cube calibration, the "
             "correction over the table. The demo has its own exact one."),
            ("F2", 4, 6, "store", "calibration*.json", "one per robot", "calibration.json, calibration_xarm6.json",
             "Written by every calibration; read at start."),
            ("O10", 1, 7, "dec", "Calibrated?", "", "MainWindow._load_or_identity_transform",
             "Without a calibration, nothing the camera finds can be used to move the robot."),
            ("O11", 3, 7, "pre", "Cube calibration", "chart S1", "app/calibration/cube.py",
             "See chart S1."),
            ("O12", 1, 8, "pre", "Watch the table", "chart S3", "app/vision/scene.py", "See chart S3."),
            ("O13", 0, 9, "io", "Type a request", "Prompt tab", "app/ui/prompt_panel.py",
             "Anything in plain words: put the red cube in the tray, build a tower, undo that."),
            ("O14", 2, 10, "pre", "The AI agent handles it", "Qwen3 + 23 tools: S2, S4", "app/llm/agent.py, tools.py",
             "Qwen3 runs on this PC in Ollama and chooses each step; the app checks every step against the request, "
             "plans and makes the moves, and checks the reply before you see it. Chart S2 follows a request; chart S4 "
             "shows the agent in detail: what Qwen3 reads, the 23 tools, every check."),
            ("F3", 4, 10, "store", "prompt_logs/, app.log", "every step recorded", "prompt_logs/, app.log",
             "The Model tab's record of each request, and the log."),
            ("O15", 0, 11, "io", "Read the reply", "Prompt tab", "app/ui/prompt_panel.py",
             "What was done, or why not."),
            ("O16", 0, 12, "dec", "Another request?", "", "", ""),
            ("O17", 0, 13, "term", "End", "close the app", "", "Closing stops any calibration and the camera."),
            ("E1", 3, 11, "err", "E-STOP", "stops any move, any time", "MainWindow._on_estop",
             "The toolbar button stops the arm at once, from any chart; a request or calibration under way ends."),
        ],
        "edges": [
            ("O1", "O2", "", "flow", "hv"), ("O2", "O3", "", "flow", "vh"), ("F1", "O3", "", "data", "hv"),
            ("O3", "O4", "", "flow", "auto"), ("O3", "O18", "", "optional", "auto"), ("O4", "O5", "No", "flow", "auto"), ("O4", "O6", "Yes", "flow", "auto"),
            ("O6", "O7", "", "flow", "auto"), ("O7", "O8", "No", "error", "hv"), ("O7", "O9", "Yes", "flow", "auto"),
            ("O8", "O9", "", "flow", "jump:A:right"), ("O5", "O9", "", "flow", "jump:A:right"),
            ("F2", "O9", "", "data", "auto"), ("O9", "O10", "", "flow", "auto"), ("O10", "O11", "No", "flow", "auto"),
            ("O10", "O12", "Yes", "flow", "auto"), ("O11", "O12", "", "flow", "vh"),
            ("O12", "O13", "", "flow", "vh"), ("O13", "O14", "", "flow", "vh"), ("O14", "F3", "", "data", "auto"),
            ("O14", "O15", "", "flow", "vh"), ("O15", "O16", "", "flow", "auto"),
            ("O16", "O13", "Yes", "flow", "jump:B:right"), ("O16", "O17", "No", "flow", "auto"),
        ],
    },
    {
        "key": "cube_calibration", "number": "S1", "title": "Cube calibration", "prefix": "C",
        "subtitle": "Calibration tab, style 'with a cube': the camera found against a cube the robot puts down",
        "lanes": ["You", "App", "Robot", "Camera", "Files"],
        "steps": [
            ("C1", 0, 0, "term", "Start", "Calibration tab, section C", "app/ui/calibration_panel.py", ""),
            ("C2", 0, 1, "manual", "Clear the table", "one cube; camera on 15 min", "",
             "One cube that fits the open gripper, 15-30 mm, square and matte. The camera's distances drift while it "
             "warms up."),
            ("C3", 0, 2, "manual", "Touch the table", "far out, then by the cube", "Manual tab",
             "Stretched out first (there the Dobot stands 2-3 mm higher or lower), then beside the cube (round it if "
             "the fingers are longer than the cube is tall). A third touch to one side allows for a sideways slope."),
            ("C4", 1, 3, "proc", "Record the table height", "each touch; the arm rises 1 mm",
             "CalibrationPanel._touch_table", "'Fingertips on the table': the robot's z there is the table there. "
             "From two touches or more, TableHeights gives the table's height anywhere."),
            ("C5", 0, 4, "manual", "Grip the cube", "as low as it fits, close", "Manual tab",
             "The table height comes from the touch, so the grip height doesn't need to be exact."),
            ("C6", 0, 5, "io", "Calibrate with a cube", "Precise, Quick or Fast; size", "CalibrationPanel._start_cube",
             "Precise: 20 spots, about 12 minutes; Quick: 10; Fast: 6. The size, if typed, is only used while calibrating. "
             "Warns if the camera was switched on less than 15 minutes ago."),
            ("C7", 1, 6, "dec", "Fingertips above the table?", "", "run_cube_calibration", ""),
            ("C8", 2, 6, "err", "Refuse", "touch the table again", "run_cube_calibration",
             "Nothing moves; the reason is shown (also if the table touches disagree)."),
            ("C9", 2, 7, "proc", "Centre the cube", "wrist to its middle; squeeze", "run_cube_calibration",
             "The wrist to its middle (re-gripped there if it wasn't), then open and close in place: the fingers "
             "centre the cube across them. The wrist stays in its middle for the whole run."),
            ("C10", 3, 8, "proc", "Look at the empty table", "from both waiting places", "_Arm.look",
             "The arm holds the cube out of the way; 20 depth frames, their median, per look."),
            ("C11", 1, 9, "proc", "Plan the spots", "spread out, inside the picture", "plan_spots",
             "Over the table the camera sees (80 px clear of the picture's edges) and the arm reaches; each next "
             "spot as far from the others as it can be."),
            ("C12", 2, 10, "proc", "Put the cube down", "at the spot, wrist in its middle", "_Arm.down_and",
             "Let go 0.5 mm above the table there (its height from the touches)."),
            ("C13", 2, 11, "proc", "Go to a waiting place", "the one farther away", "away_poses_for",
             "High, at the side: out of the camera's way."),
            ("C14", 3, 12, "proc", "Look", "wait 0.6 s; 20 frames", "_Arm.look",
             "The pause lets the arm and the table stop shaking."),
            ("C15", 1, 13, "proc", "Find the cube", "new against the empty table", "find_new_object",
             "Its top's middle, height, size, lean and the table round it, with no calibration needed."),
            ("C16", 2, 14, "proc", "Take the cube back", "own coordinates, turned to match", "_take_back",
             "Where the robot put it, so it can't lose it however wrong a calibration is. If the camera saw the cube "
             "turn or move as it was let go, the wrist turns and the arm moves to match; with no room for the fingers "
             "it waits above the cube and pauses for the user. After lifting, the camera checks the cube came up."),
            ("C17", 1, 15, "dec", "Seen whole and flat?", "", "_whole, TILT_MAX_DEG", ""),
            ("C18", 2, 15, "err", "Leave the spot out", "listed in the result", "run_cube_calibration",
             "Not found, leaning over 30 degrees, taller or shorter than the others, partly hidden, or (xArm) "
             "gripped off-centre."),
            ("C19", 1, 16, "dec", "More spots?", "", "", ""),
            ("C20", 2, 17, "proc", "Back to spot 1", "slip check", "run_cube_calibration",
             "Every 5 spots and at the end. Over 3 mm from the first time: the arm lost its place (or the cube "
             "moved in the fingers, or the camera moved); the run pauses and the spots since the last good check are "
             "done again. 1.5-3 mm is noted; the look counts as a spot. Pausing (the user, or the robot needing a "
             "hand) keeps the progress: the user grips the cube by hand and carries on."),
            ("C21", 1, 18, "proc", "Solve", "table plane + spots, best try", "solve_cube",
             "The table's plane (thousands of depth points) gives tilt and height; the spots give the rest. Tried: "
             "with a scale, the gripper's offset, the depth sensor's own picture, a correction over the table; kept "
             "only if each spot, predicted from the others, comes out better. A spot that disagrees with the rest "
             "is left out (two from 10 spots up)."),
            ("C22", 1, 19, "dec", "Passed?", "enough spots; error; slip", "run_cube_calibration",
             "Precise: typical under 1.0 mm; Quick and Fast: under 1.5 mm. Slip check under 3 mm."),
            ("C23", 2, 19, "err", "Keep nothing", "cube put down; reasons", "CalibrationPanel._cube_done",
             "The calibration in use stays as it was."),
            ("C24", 1, 20, "proc", "Save and use", "table height, safety floor", "CalibrationPanel._cube_done",
             "The new transform goes straight into use; the safety floor is set from the table."),
            ("F1", 4, 20, "store", "calibration.json", "transform, correction", "app/calibration/storage.py", ""),
            ("F2", 4, 21, "store", "sessions/", "every spot, replayable", "app/calibration/session.py", ""),
            ("C25", 0, 21, "io", "Read the result", "checks; arrows on the picture", "CalibrationPanel._cube_report",
             "Each spot's miss, the table's flatness, slip, the fingers' offset from the wrist, what was left out."),
            ("C26", 0, 22, "dec", "Pick test or towers?", "", "", ""),
            ("C27", 1, 22, "pre", "Pick test, towers, wrist", "3 new spots; 2-3 high; -40..+40°",
             "run_pick_test, run_cube_stacks, run_fingers_check, run_rotation_test",
             "Pick test: the cube found and picked where the camera says. Towers with 1 or 2 more cubes: each level "
             "checked before the next; kept only if better up high. Fingers angle check: the cube put down with the "
             "wrist at -40..+40°, from below and above: offset, gain, backlash, scatter, saved with the calibration "
             "and used on every pick. Rotation pick test: the fingers' error picking a turned cube, correction on/off."),
            ("C28", 0, 23, "term", "End", "Finish: cube put down", "put_cube_down", ""),
        ],
        "edges": [
            ("C1", "C2", "", "flow", "auto"), ("C2", "C3", "", "flow", "auto"), ("C3", "C4", "", "flow", "vh"),
            ("C4", "C5", "", "flow", "vh"), ("C5", "C6", "", "flow", "auto"), ("C6", "C7", "", "flow", "vh"),
            ("C7", "C8", "No", "error", "auto"), ("C8", "C3", "", "error", "jump:A:right"),
            ("C7", "C9", "Yes", "flow", "vh"), ("C9", "C10", "", "flow", "hv"), ("C10", "C11", "", "flow", "hv"),
            ("C11", "C12", "", "flow", "hv"), ("C12", "C13", "", "flow", "auto"), ("C13", "C14", "", "flow", "hv"),
            ("C14", "C15", "", "flow", "hv"), ("C15", "C16", "", "flow", "hv"), ("C16", "C17", "", "flow", "hv"),
            ("C17", "C18", "No", "error", "auto"), ("C17", "C19", "Yes", "flow", "auto"),
            ("C18", "C19", "", "flow", "vh"), ("C19", "C12", "Yes", "flow", "jump:B:left"),
            ("C19", "C20", "No", "flow", "vh"), ("C20", "C21", "", "flow", "vh"), ("C21", "C22", "", "flow", "auto"),
            ("C22", "C23", "No", "error", "auto"), ("C23", "C3", "", "error", "jump:A:right"),
            ("C22", "C24", "Yes", "flow", "auto"), ("C24", "F1", "", "data", "auto"), ("C24", "F2", "", "data", "vh-r"),
            ("C24", "C25", "", "flow", "vh"), ("C25", "C26", "", "flow", "auto"),
            ("C26", "C27", "Yes", "optional", "auto"), ("C26", "C28", "No", "flow", "auto"),
            ("C27", "C28", "", "optional", "vh"),
        ],
    },
    {
        "key": "request", "number": "S2", "title": "Handling a request", "prefix": "R",
        "subtitle": "Prompt tab: from what you type to the reply, one step at a time",
        "lanes": ["You", "App", "AI (Qwen3 in Ollama)", "Robot", "Camera"],
        "steps": [
            ("R1", 0, 0, "term", "Start", "a request typed", "app/ui/prompt_panel.py",
             "Runs in the background: the window stays usable, and Stop or E-STOP work at any time."),
            ("R2", 1, 1, "proc", "Prepare the request", "held object, last request", "Agent.run",
             "The model is told what the gripper holds and what the previous request was ('do it again'). Towers "
             "asked for by place are worked out first (tower_plan)."),
            ("R3", 1, 2, "dec", "Asked to go slowly?", "", "request_checks.wants_slow",
             "'slowly', 'carefully'."),
            ("R4", 3, 2, "proc", "Slow the arm", "40% for this request", "ToolExecutor set_speed",
             "Back to normal speed when the request ends."),
            ("R5", 2, 3, "proc", "Choose the next step", "with the tools list", "OllamaClient.chat",
             "Qwen3 runs on this PC in Ollama: the instructions, the request and every result so far go in; a tool "
             "call or a reply comes out."),
            ("R6", 2, 4, "dec", "A tool to run?", "", "Agent.run", ""),
            ("R7", 1, 4, "proc", "Check the reply", "done? a question?", "PromptTrace.goal_now",
             "The app's own check of what was asked: a tower still standing, the tray not empty..."),
            ("R8", 1, 5, "dec", "Done, or asks you?", "", "Agent.run",
             "A reply that admits what couldn't be done, or asks which object, counts."),
            ("R9", 1, 6, "proc", "Tell Qwen3 not yet", "what the check found", "Agent.run (nudges)",
             "'Not done yet: ...', 'go ahead', 'you are still holding ...', or 'your reply says something was "
             "turned, but nothing was'; twice at most. Chart S4 has every check."),
            ("R10", 0, 6, "io", "Read the reply", "Prompt tab", "app/ui/prompt_panel.py", ""),
            ("R11", 1, 7, "dec", "Step-by-step: go?", "", "Agent.run approve",
             "Only in step-by-step mode: Go, All, or Stop before each move."),
            ("R12", 0, 7, "term", "End", "stopped by you", "", ""),
            ("R13", 1, 8, "dec", "Step makes sense?", "", "Agent._guard, request_checks.check_step",
             "Checked against the request: a tower built in the wrong order, a cube taken off for nothing."),
            ("R14", 2, 8, "err", "Refuse, say why", "too many: stop", "Agent._guard",
             "The reason goes back to Qwen3; after several refusals the request ends."),
            ("R15", 1, 9, "proc", "Run the tool", "pick, place, build_tower...", "app/llm/tools.py",
             "23 tools (chart S4); each one plans its own moves. Needs a calibration."),
            ("R16", 4, 10, "pre", "Look at the table", "chart S3; arm out of view", "ToolExecutor._tool_list_objects",
             "The arm moves only as far as needed to clear the camera's view; objects come back in robot mm."),
            ("R17", 1, 11, "proc", "Plan the moves", "reach, grip, turn, path", "app/llm/tools.py, gripper.py",
             "Fits between the fingers? Turned which way? A path round what stands in the way?"),
            ("R18", 1, 12, "dec", "Safe and in view?", "", "_require_reachable, _in_view, collision checks",
             "Inside the safe box and the arm's reach, above the safety floor, clear of other objects, and where "
             "the camera can see."),
            ("R19", 2, 12, "err", "Error to Qwen3", "what was in the way", "ToolExecutor.execute", ""),
            ("R20", 3, 13, "proc", "Move, grip, release", "Dobot, xArm or demo", "app/hardware",
             "The driver sends the moves; the gripper waits for the air (Dobot) or reports its opening (xArm)."),
            ("R21", 3, 14, "dec", "E-STOP pressed?", "", "RobotStopped", ""),
            ("R22", 4, 14, "term", "End", "stopped, nothing more", "Agent.run", ""),
            ("R23", 1, 15, "proc", "Send the result", "what really happened", "Agent.run",
             "The tool's own words: done, or refused and why."),
            ("F1", 0, 15, "store", "Model tab, prompt_logs/", "every turn recorded", "app/llm/trace.py", ""),
            ("R24", 1, 16, "dec", "Under 20 steps?", "", "llm.max_tool_calls", "Set in config.yaml."),
            ("R25", 2, 16, "term", "End", "step limit reached", "Agent.run", ""),
        ],
        "edges": [
            ("R1", "R2", "", "flow", "hv"), ("R2", "R3", "", "flow", "auto"), ("R3", "R4", "Yes", "flow", "auto"),
            ("R3", "R5", "No", "flow", "vh"), ("R4", "R5", "", "flow", "vh"), ("R5", "R6", "", "flow", "auto"),
            ("R6", "R7", "No", "flow", "auto"), ("R7", "R8", "", "flow", "auto"), ("R8", "R10", "Yes", "flow", "hv"),
            ("R8", "R9", "No", "flow", "auto"), ("R9", "R5", "", "flow", "jump:A:right:top"),
            ("R6", "R11", "Yes", "flow", "vh"), ("R11", "R12", "Stop", "flow", "auto"),
            ("R11", "R13", "Go", "flow", "auto"), ("R13", "R14", "No", "error", "auto"),
            ("R14", "R5", "", "error", "jump:A:right:top"), ("R13", "R15", "Yes", "flow", "auto"),
            ("R15", "R16", "", "flow", "hv"), ("R16", "R17", "", "flow", "vh"), ("R17", "R18", "", "flow", "auto"),
            ("R18", "R19", "No", "error", "auto"), ("R19", "R5", "", "error", "jump:A:right:top"),
            ("R18", "R20", "Yes", "flow", "vh"), ("R20", "R21", "", "flow", "auto"),
            ("R21", "R22", "Yes", "error", "auto"), ("R21", "R23", "No", "flow", "vh"),
            ("R23", "F1", "", "data", "auto"), ("R23", "R24", "", "flow", "auto"),
            ("R24", "R5", "Yes", "flow", "jump:A:left:top"), ("R24", "R25", "No", "flow", "auto"),
        ],
    },
    {
        "key": "seeing", "number": "S3", "title": "Seeing the table", "prefix": "V",
        "subtitle": "From camera frames to objects in robot millimetres",
        "lanes": ["Camera", "App", "Files"],
        "steps": [
            ("V1", 0, 0, "term", "Start", "camera running", "app/hardware/camera.py", "30 frames a second."),
            ("V2", 0, 1, "proc", "Take a frame", "colour and depth", "OrbbecCamera.get_frame",
             "Depth lined up with the colour picture; the demo renders its own."),
            ("V3", 0, 2, "proc", "Straighten for the lens", "with the bend it reports", "app/vision/undistort.py",
             "camera.undistort in config.yaml; on by default."),
            ("V4", 1, 3, "proc", "Show the picture", "Manual, Calibration, 3D view", "app/ui/video_widget.py", ""),
            ("V5", 1, 4, "dec", "Look asked for?", "", "SceneBuilder.get_scene",
             "By a tool (list_objects), a click, the 3D view's 'what the camera sees'."),
            ("V6", 1, 5, "proc", "Find the objects", "what stands above the table", "app/vision/depth_detector.py",
             "Depth finds anything, of any colour; or by colour (detector.py)."),
            ("V7", 1, 6, "proc", "Pixels to robot mm", "calibration, then correction", "app/vision/locator.py, "
             "SceneBuilder._corrected", "Each object's top: its middle, size and turn, in the robot's frame."),
            ("F1", 2, 6, "store", "calibration*.json", "transform, correction", "", ""),
            ("V8", 1, 7, "dec", "Seen in the next look?", "", "SceneBuilder.get_scene (steady_looks)",
             "Against noise: kept only if seen again within 10 mm."),
            ("V9", 2, 7, "err", "Drop it", "a phantom of noise", "", ""),
            ("V10", 1, 8, "proc", "Keep the same names", "matched within 30 mm", "SceneBuilder",
             "So 'obj_3' still means the same cube after it moves."),
            ("V11", 1, 9, "io", "Objects in robot mm", "to the tools, chart S2", "", ""),
            ("V12", 1, 10, "term", "End", "of this look", "", ""),
        ],
        "edges": [
            ("V1", "V2", "", "flow", "auto"), ("V2", "V3", "", "flow", "auto"), ("V3", "V4", "", "flow", "vh"),
            ("V4", "V5", "", "flow", "auto"), ("V5", "V2", "No", "flow", "jump:A:right"),
            ("V5", "V6", "Yes", "flow", "auto"), ("V6", "V7", "", "flow", "auto"), ("F1", "V7", "", "data", "auto"),
            ("V7", "V8", "", "flow", "auto"), ("V8", "V9", "No", "error", "auto"), ("V8", "V10", "Yes", "flow", "auto"),
            ("V9", "V10", "", "flow", "vh"), ("V10", "V11", "", "flow", "auto"), ("V11", "V12", "", "flow", "auto"),
        ],
    },
    {
        "key": "agent", "number": "S4", "title": "The agent in detail", "prefix": "G",
        "subtitle": "What Qwen3 reads, what it may do, and every check the app makes on it",
        "lanes": ["App (the agent)", "Qwen3 (Ollama, this PC)", "Checks", "Tools and robot", "Files"],
        "steps": [
            ("G1", 0, 0, "term", "Start", "a request (chart S2)", "Agent.run",
             "The request as typed; 'slowly' has already slowed the arm (chart S2)."),
            ("G2", 0, 1, "proc", "Build what Qwen3 reads", "rules, tools, state", "Agent.run",
             "The instructions (about 1,900 tokens), the 23 tools' descriptions (about 3,300), the request, what "
             "the gripper holds, the previous request ('do it again', 'now the blue one') and every step and result "
             "so far: up to 8,192 tokens at once."),
            ("F1", 4, 1, "store", "The instructions", "rules for Qwen3", "app/llm/agent.py",
             "Look at the table first. Use only ids list_objects gave; match the colour and kind named. A tower, a row "
             "or a turn of several objects is ONE call. Turn BY (turn_deg) or AT (angle_deg) as asked; like_id for "
             "'the same angle as'. An object or place not listed: say so, use nothing else. An ERROR: report it in "
             "the tool's words, never another reason. Never claim a position or distance the tools didn't give."),
            ("F2", 4, 2, "store", "The 23 tools", "what each one does", "app/llm/tools.py, app/llm/arrange.py",
             "Look: list_objects. Pick and place: pick, place, place_at, place_on, place_beside, place_free, "
             "place_between, put_all_in. Arrange: line_up, build_tower, take_apart, empty_place, swap, move_object, "
             "turn_object, put_back. Move: move_above, move_to, home. Gripper: open_gripper, close_gripper. Speed: "
             "set_speed."),
            ("G3", 1, 2, "proc", "Decide the next step", "a tool call, or a reply", "OllamaClient.chat",
             "Qwen3 (qwen3:4b-instruct, or the one chosen on the Prompt tab; qwen3:8b as the fallback), temperature "
             "0.2, kept loaded 30 minutes, 120 s to answer. Thinking aloud is off unless switched on in Settings."),
            ("G4", 1, 3, "dec", "A tool call?", "", "Agent.run", ""),
            ("G5", 2, 4, "dec", "Says it, doesn't do it?", "'Let me ...'", "agent.announces_action",
             "A reply that only says what it is about to do, and calls nothing, is sent back: 'go ahead, call the "
             "tool'. Not one that asks you something."),
            ("G6", 2, 5, "dec", "Still holding something?", "", "Agent.run (STILL_HOLDING)",
             "Ending with an object in the gripper ('take the cube out of the tray', and it just lifted it): put it "
             "down where asked. Not when the request was to pick it up."),
            ("G7", 2, 6, "dec", "Claims a turn not done?", "", "agent.claims_turn_not_done",
             "The reply says something was turned or 'at 45 degrees', and no tool turned anything (the lab: "
             "turn_object had failed, the reply said it was done)."),
            ("G8", 2, 7, "dec", "Goal met?", "the app's own check", "PromptTrace.goal_now",
             "The app looks for itself: the tower still standing, the tray not empty, an angle asked for and "
             "nothing turned... A reply that admits it, or asks you which one, counts as an answer."),
            ("G9", 1, 4, "proc", "Back: do it now", "'go ahead, call the tool'", "Agent.run (GO_AHEAD)",
             "Sent back to Qwen3, which then usually does it. Two send-backs at most per request; after that the "
             "reply stands."),
            ("G20", 1, 5, "proc", "Back: put it down", "where the user asked", "Agent.run (STILL_HOLDING)", ""),
            ("G21", 1, 6, "proc", "Back: nothing turned", "turn it, or say so", "Agent.run (NOT_TURNED)",
             "With turn_object's error, if it gave one."),
            ("G22", 1, 7, "proc", "Back: not done yet", "what the check found", "Agent.run (NOT_DONE)", ""),
            ("G10", 0, 8, "io", "The reply", "Prompt tab", "app/ui/prompt_panel.py",
             "Shown with notes on what was refused or sent back (the amber lines)."),
            ("G11", 2, 9, "dec", "Fits the request?", "", "request_checks.check_step, Agent._guard",
             "The object named (its colour and kind), the place named and not left out, not put back where it came "
             "from, the row's order and direction, a turn only if asked, BY or AT as asked; a tower in one "
             "build_tower call (never put_all_in), in the order asked."),
            ("G12", 1, 9, "err", "Refused: why", "4 at most, then stop", "Agent._guard",
             "The reason and what to do instead go back to Qwen3; after four refusals the request ends (it was going "
             "round in circles)."),
            ("G13", 3, 10, "pre", "Run the tool", "look, plan, move (S2)", "ToolExecutor.execute",
             "Each tool looks at the table if it needs to (chart S3), plans its own moves, checks reach, safety and "
             "the camera's view, and moves the arm (chart S2)."),
            ("G14", 3, 11, "proc", "Sizes and angles", "25 mm cubes; the fingers' angle", "SceneBuilder._known, "
             "app/hardware/gripper.py",
             "A cube measured near its known size (config.yaml: cube 25 mm) is taken to be that size; the fingers "
             "turn to its sides, by the fingers' real angle the cube calibration measured; too wide for the gripper "
             "is refused; a held object can be turned (put back where it was picked up)."),
            ("G15", 3, 12, "dec", "Done?", "", "ToolExecutor.execute", ""),
            ("G16", 1, 12, "err", "Error to Qwen3", "in the tool's words", "Agent.run",
             "Out of reach, nothing held, no such place, in the way... Qwen3 must report it as given."),
            ("G17", 0, 13, "proc", "Result back", "what really happened", "Agent.run",
             "The tool's own words, with its numbers; Qwen3 may only repeat what the results say."),
            ("F3", 4, 10, "store", "Model tab, prompt_logs/", "every turn recorded", "app/llm/trace.py",
             "What Qwen3 read and wrote, which checks ran and why, every move and joint, the time each took."),
            ("G18", 0, 14, "dec", "Under 20 steps?", "", "llm.max_tool_calls", "Set in config.yaml."),
            ("G19", 0, 15, "term", "End", "step limit reached", "Agent.run", ""),
        ],
        "edges": [
            ("G1", "G2", "", "flow", "auto"), ("F1", "G2", "", "data", "auto"), ("G2", "G3", "", "flow", "vh"),
            ("F2", "G3", "", "data", "auto"), ("G3", "G4", "", "flow", "auto"),
            ("G4", "G5", "No", "flow", "hv"), ("G5", "G9", "Yes", "flow", "auto"), ("G5", "G6", "No", "flow", "auto"),
            ("G6", "G20", "Yes", "flow", "auto"), ("G6", "G7", "No", "flow", "auto"),
            ("G7", "G21", "Yes", "flow", "auto"), ("G7", "G8", "No", "flow", "auto"),
            ("G8", "G22", "No", "flow", "auto"), ("G8", "G10", "Yes", "flow", "vh"),
            ("G9", "G3", "", "flow", "jump:A:left:top"), ("G20", "G3", "", "flow", "jump:A:left:top"),
            ("G21", "G3", "", "flow", "jump:A:left:top"), ("G22", "G3", "", "flow", "jump:A:left:top"),
            ("G4", "G11", "Yes", "flow", "jump:B:left:top"), ("G11", "G12", "No", "error", "auto"),
            ("G12", "G3", "", "error", "jump:A:left:top"), ("G11", "G13", "Yes", "flow", "hv"),
            ("G13", "G14", "", "flow", "auto"), ("G14", "G15", "", "flow", "auto"),
            ("G15", "G16", "No", "error", "auto"), ("G16", "G3", "", "error", "jump:A:left:top"),
            ("G15", "G17", "Yes", "flow", "vh"), ("G13", "F3", "", "data", "auto"), ("G17", "G18", "", "flow", "auto"),
            ("G18", "G3", "Yes", "flow", "jump:A:left:top"), ("G18", "G19", "No", "flow", "auto"),
        ],
    },
]

# ---- geometry --------------------------------------------------------------------------------------------------------
LANE_W, ROW_H = 216, 84
NODE_W, NODE_H, DEC_H = 172, 50, 62
MARGIN, HEAD_H, LANE_HEAD, FOOT_H = 36, 92, 34, 128
FONT = "Segoe UI, Helvetica Neue, Arial, sans-serif"

COLOUR = {
    "ink": "#22303C", "muted": "#5B6875", "lane_a": "#F4F6F8", "lane_b": "#FFFFFF", "lane_head": "#E3E8ED",
    "sheet": "#FFFFFF", "rule": "#C9D1D9",
    "term": ("#22303C", "#22303C", "#FFFFFF"), "proc": ("#FFFFFF", "#22303C", "#22303C"),
    "dec": ("#FFF3D1", "#8A6416", "#3D2B04"), "io": ("#E6F0FA", "#2B5F8C", "#163A57"),
    "pre": ("#FFFFFF", "#22303C", "#22303C"), "manual": ("#E9F4EA", "#3B6D3F", "#1F3D22"),
    "store": ("#F1F0EC", "#5F5E5A", "#2C2C2A"), "err": ("#FCEBEA", "#B42318", "#6B1209"),
    "edge": "#22303C", "error": "#B42318", "data": "#7A8794", "optional": "#22303C",
}
BW = {
    "ink": "#000000", "muted": "#444444", "lane_a": "#F2F2F2", "lane_b": "#FFFFFF", "lane_head": "#E0E0E0",
    "sheet": "#FFFFFF", "rule": "#BBBBBB",
    "term": ("#DDDDDD", "#000000", "#000000"), "proc": ("#FFFFFF", "#000000", "#000000"),
    "dec": ("#FFFFFF", "#000000", "#000000"), "io": ("#FFFFFF", "#000000", "#000000"),
    "pre": ("#FFFFFF", "#000000", "#000000"), "manual": ("#FFFFFF", "#000000", "#000000"),
    "store": ("#EEEEEE", "#000000", "#000000"), "err": ("#FFFFFF", "#000000", "#000000"),
    "edge": "#000000", "error": "#000000", "data": "#555555", "optional": "#000000",
    "dash": {"flow": None, "error": "8 3 2 3", "data": "2 3", "optional": "6 4"},   # error: dash-dot, without red
}
DASH = {"flow": None, "error": "6 4", "data": "2 3", "optional": "6 4"}


@dataclass
class Step:
    id: str
    lane: int
    row: int
    shape: str
    title: str
    sub: str
    src: str
    info: str
    cx: float = 0.0
    cy: float = 0.0

    @property
    def w(self) -> float:
        return NODE_W

    @property
    def h(self) -> float:
        return DEC_H if self.shape == "dec" else NODE_H

    def port(self, side: str) -> tuple[float, float]:
        return {"top": (self.cx, self.cy - self.h / 2), "bottom": (self.cx, self.cy + self.h / 2),
                "left": (self.cx - self.w / 2, self.cy), "right": (self.cx + self.w / 2, self.cy)}[side]

    def box(self) -> tuple[float, float, float, float]:
        return self.cx - self.w / 2, self.cy - self.h / 2, self.cx + self.w / 2, self.cy + self.h / 2


@dataclass
class Edge:
    src: str
    dst: str
    label: str
    kind: str
    route: str
    points: list = field(default_factory=list)     # the polyline, start to end
    jump: Optional[tuple] = None                    # (letter, out circle centre, in circle centre)
    exit_side: str = ""
    entry_side: str = ""


def layout(chart: dict):
    lanes = chart["lanes"]
    steps = {s[0]: Step(*s) for s in chart["steps"]}
    rows = max(s.row for s in steps.values()) + 1
    width = 2 * MARGIN + LANE_W * len(lanes)
    top = MARGIN + HEAD_H + LANE_HEAD
    height = top + rows * ROW_H + 16 + FOOT_H + MARGIN
    for s in steps.values():
        s.cx = MARGIN + LANE_W * (s.lane + 0.5)
        s.cy = top + ROW_H * (s.row + 0.5)
    edges = []
    for src, dst, label, kind, route in chart["edges"]:
        a, b = steps[src], steps[dst]
        e = Edge(src, dst, label, kind.split(":")[0] if kind.startswith("jump") else kind, route)
        if route.startswith("jump"):
            _, letter, side, *rest = route.split(":")
            into = rest[0] if rest else "left"
            e.kind = kind
            out_side = side
            sx, sy = a.port(out_side)
            reach = 52 if label else 34
            ox = sx + (reach if out_side == "right" else -reach)
            ix, iy = b.port(into)
            e.jump = (letter, (ox, sy), (ix - 34, iy) if into == "left" else (ix, iy - 34), into)
            e.exit_side, e.entry_side = out_side, into
            e.points = [(sx, sy), (ox - (11 if out_side == "right" else -11), sy)]
            edges.append(e)
            continue
        e.points, e.exit_side, e.entry_side = _route(a, b, route)
        edges.append(e)
    return steps, edges, width, height, top, rows


def _route(a: Step, b: Step, route: str):
    if a.lane == b.lane:
        if b.row > a.row:
            return [a.port("bottom"), b.port("top")], "bottom", "top"
        side = "left"
        return [a.port(side), (a.cx - a.w / 2 - 20, a.cy), (b.cx - b.w / 2 - 20, b.cy), b.port(side)], side, side
    toward = "right" if b.lane > a.lane else "left"
    away = "left" if toward == "right" else "right"
    if a.row == b.row:
        return [a.port(toward), b.port(away)], toward, away
    if route == "hv2":           # across from the side, then down the far side into the target's side
        sx, sy = a.port(toward)
        return [(sx, sy), (b.cx, sy), b.port("top")], toward, "top"
    if route == "hv" or (route == "auto" and a.shape == "dec"):
        sx, sy = a.port(toward)
        return [(sx, sy), (b.cx, sy), b.port("top")], toward, "top"
    sx, sy = a.port("bottom")
    if route == "vh-r":          # from the right part of the bottom, beside a line leaving its middle
        sx += a.w * 0.3
    tx, ty = b.port(away)
    return [(sx, sy), (sx, ty), (tx, ty)], "bottom", away


def check(chart, steps, edges) -> list[str]:
    """Lines that run through a step they don't start or end at: the layout needs fixing."""
    problems = []
    for e in edges:
        for (x1, y1), (x2, y2) in zip(e.points, e.points[1:]):
            for s in steps.values():
                if s.id in (e.src, e.dst):
                    continue
                l, t, r, btm = s.box()
                if max(x1, x2) > l + 1 and min(x1, x2) < r - 1 and max(y1, y2) > t + 1 and min(y1, y2) < btm - 1:
                    problems.append(f"{chart['key']}: {e.src}->{e.dst} crosses {s.id}")
    used: dict = {}
    for e in edges:
        if e.kind == "data" or e.route == "vh-r":
            continue
        used.setdefault((e.src, e.exit_side), []).append("out")
        if not e.jump:
            used.setdefault((e.dst, e.entry_side), []).append("in")
        elif "jump-in " + e.jump[0] not in used.get((e.dst, e.entry_side), []):
            used.setdefault((e.dst, e.entry_side), []).append("jump-in " + e.jump[0])
    for (sid, side), uses in used.items():
        kinds = set("in" if u.startswith("jump-in") else u for u in uses)
        ins = sum(1 for u in uses if u != "out")
        if len(kinds) > 1 or uses.count("out") > 1 or ins > 1:
            problems.append(f"{chart['key']}: {sid} {side} side used by {uses}")
    return problems


# ---- SVG ------------------------------------------------------------------------------------------------------------
def wrap(text: str, limit: int) -> list[str]:
    words, lines, line = text.split(), [], ""
    for word in words:
        if line and len(line) + 1 + len(word) > limit:
            lines.append(line)
            line = word
        else:
            line = f"{line} {word}".strip()
    if line:
        lines.append(line)
    return lines


def esc(text: str) -> str:
    return html.escape(text, quote=True)


def shape_svg(s: Step, c: dict) -> str:
    fill, stroke, text = c[s.shape]
    l, t, r, b = s.box()
    w, h = s.w, s.h
    sw = 1.4
    parts = []
    if s.shape == "term":
        parts.append(f'<rect x="{l}" y="{t}" width="{w}" height="{h}" rx="{h / 2}" fill="{fill}" stroke="{stroke}" '
                     f'stroke-width="{sw}"/>')
    elif s.shape in ("proc", "err"):
        dash = ' stroke-dasharray="5 3"' if s.shape == "err" else ""
        parts.append(f'<rect x="{l}" y="{t}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" '
                     f'stroke-width="{sw}"{dash}/>')
    elif s.shape == "pre":
        parts.append(f'<rect x="{l}" y="{t}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" '
                     f'stroke-width="{sw}"/>')
        for x in (l + 10, r - 10):
            parts.append(f'<line x1="{x}" y1="{t}" x2="{x}" y2="{b}" stroke="{stroke}" stroke-width="{sw}"/>')
    elif s.shape == "dec":
        parts.append(f'<polygon points="{s.cx},{t} {r},{s.cy} {s.cx},{b} {l},{s.cy}" fill="{fill}" '
                     f'stroke="{stroke}" stroke-width="{sw}"/>')
    elif s.shape == "io":
        k = 14
        parts.append(f'<polygon points="{l + k},{t} {r},{t} {r - k},{b} {l},{b}" fill="{fill}" stroke="{stroke}" '
                     f'stroke-width="{sw}"/>')
    elif s.shape == "manual":
        k = 12
        parts.append(f'<polygon points="{l},{t} {r},{t} {r - k},{b} {l + k},{b}" fill="{fill}" stroke="{stroke}" '
                     f'stroke-width="{sw}"/>')
    elif s.shape == "store":
        ry = 6
        parts.append(f'<path d="M{l} {t + ry} A{w / 2} {ry} 0 0 1 {r} {t + ry} V{b - ry} A{w / 2} {ry} 0 0 1 {l} '
                     f'{b - ry} Z" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
        parts.append(f'<path d="M{l} {t + ry} A{w / 2} {ry} 0 0 0 {r} {t + ry}" fill="none" stroke="{stroke}" '
                     f'stroke-width="{sw}"/>')
    # the words
    if s.shape == "dec":
        lines = wrap(s.title, 17)
        y0 = s.cy - (len(lines) - 1) * 7 + 4
        for i, line in enumerate(lines):
            parts.append(f'<text x="{s.cx}" y="{y0 + i * 14}" text-anchor="middle" font-size="11.5" '
                         f'font-weight="600" fill="{text}">{esc(line)}</text>')
    else:
        dy = 4 if s.shape == "store" else 0
        if s.sub:
            parts.append(f'<text x="{s.cx}" y="{s.cy - 3 + dy}" text-anchor="middle" font-size="12" '
                         f'font-weight="600" fill="{text}">{esc(s.title)}</text>')
            parts.append(f'<text x="{s.cx}" y="{s.cy + 13 + dy}" text-anchor="middle" font-size="10.5" '
                         f'fill="{text}" fill-opacity="0.85">{esc(s.sub)}</text>')
        else:
            parts.append(f'<text x="{s.cx}" y="{s.cy + 4 + dy}" text-anchor="middle" font-size="12" '
                         f'font-weight="600" fill="{text}">{esc(s.title)}</text>')
    # its number
    if s.shape not in ("store",):
        parts.append(f'<text x="{l}" y="{t - 5}" font-size="9.5" fill="{c["muted"]}" '
                     f'font-family="Consolas, monospace">{s.id}</text>')
    return (f'<g data-step="{s.id}" class="step" style="cursor:pointer">'
            + f'<title>{esc(s.id + " " + s.title)}</title>' + "".join(parts) + "</g>")


def edge_svg(e: Edge, c: dict, drawn_in: set) -> str:
    colour = c["error"] if e.kind == "error" else c["data"] if e.kind == "data" else c["edge"]
    dash = c.get("dash", DASH).get(e.kind)
    dash_attr = f' stroke-dasharray="{dash}"' if dash else ""
    marker = "ae" if e.kind == "error" else "ad" if e.kind == "data" else "a"
    pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in e.points)
    out = [f'<polyline points="{pts}" fill="none" stroke="{colour}" stroke-width="1.3"{dash_attr} '
           f'marker-end="url(#{marker})"/>']
    if e.jump:
        letter, (ox, oy), (ix, iy), into = e.jump
        out.append(_connector(ox, oy, letter, c))
        key = (e.dst, letter)
        if key not in drawn_in:
            drawn_in.add(key)
            out.append(_connector(ix, iy, letter, c))
            if into == "left":
                out.append(f'<line x1="{ix + 11}" y1="{iy}" x2="{ix + 33}" y2="{iy}" stroke="{c["edge"]}" '
                           f'stroke-width="1.3" marker-end="url(#a)"/>')
            else:
                out.append(f'<line x1="{ix}" y1="{iy + 11}" x2="{ix}" y2="{iy + 33}" stroke="{c["edge"]}" '
                           f'stroke-width="1.3" marker-end="url(#a)"/>')
    if e.label:
        (x1, y1), (x2, y2) = e.points[0], e.points[1]
        if abs(y2 - y1) < 1:      # leaves sideways: above the line
            x = x1 + (8 if x2 > x1 else -8)
            anchor = "start" if x2 > x1 else "end"
            out.append(f'<text x="{x}" y="{y1 - 5}" font-size="10.5" font-weight="600" fill="{colour}" '
                       f'text-anchor="{anchor}">{esc(e.label)}</text>')
        else:                     # leaves downwards: beside the line
            out.append(f'<text x="{x1 + 6}" y="{y1 + 14}" font-size="10.5" font-weight="600" fill="{colour}">'
                       f'{esc(e.label)}</text>')
    return "".join(out)


def _connector(x: float, y: float, letter: str, c: dict) -> str:
    return (f'<circle cx="{x}" cy="{y}" r="11" fill="#FFFFFF" stroke="{c["edge"]}" stroke-width="1.3"/>'
            f'<text x="{x}" y="{y + 4}" text-anchor="middle" font-size="11" font-weight="700" fill="{c["edge"]}">'
            f'{letter}</text>')


def legend_svg(x: float, y: float, c: dict, avail: float) -> tuple[str, float]:
    """The key: every shape and line, in as many columns as fit `avail` (px); (svg, its height)."""
    shapes = [("term", "Start / end"), ("proc", "Step"), ("dec", "Decision"), ("io", "You read or enter"),
              ("pre", "Has its own chart"), ("manual", "Done by hand"), ("store", "File on disk"),
              ("err", "Refused / error")]
    lines = [("flow", "Flow"), ("error", "Refused / error path"), ("optional", "Optional"),
             ("data", "Reads or writes a file"), ("jump", "Continues at the same letter")]
    col_w = 160
    cols = max(2, int(avail // col_w))
    out = [f'<text x="{x}" y="{y}" font-size="11" font-weight="700" fill="{c["ink"]}">Key</text>']
    items = [("shape", k, w) for k, w in shapes] + [("line", k, w) for k, w in lines]
    for i, (what, kind, words) in enumerate(items):
        sx, sy = x + (i % cols) * col_w, y + 12 + (i // cols) * 26
        if what == "shape":
            s = Step("", 0, 0, kind, "", "", "", "")
            s.cx, s.cy = 0, 0
            out.append(f'<g transform="translate({sx + 20} {sy + 10}) scale(0.22)">{shape_svg(s, c)}</g>')
        elif kind == "jump":
            out.append(_connector(sx + 20, sy + 10, "A", c))
        else:
            colour = c["error"] if kind == "error" else c["data"] if kind == "data" else c["edge"]
            dash = c.get("dash", DASH).get(kind)
            dash_attr = f' stroke-dasharray="{dash}"' if dash else ""
            out.append(f'<line x1="{sx + 2}" y1="{sy + 10}" x2="{sx + 38}" y2="{sy + 10}" stroke="{colour}" '
                       f'stroke-width="1.3"{dash_attr}/>')
        out.append(f'<text x="{sx + 46}" y="{sy + 14}" font-size="10.5" fill="{c["ink"]}">{esc(words)}</text>')
    rows = math.ceil(len(items) / cols)
    return "".join(out), 12 + rows * 26


def chart_svg(chart: dict, c: dict, page: int, pages: int) -> tuple[str, int, int]:
    steps, edges, width, height, top, rows = layout(chart)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="{width}" '
           f'height="{height}" font-family="{FONT}">',
           '<defs>'
           f'<marker id="a" viewBox="0 0 10 10" refX="9.5" refY="5" markerWidth="8" markerHeight="8" '
           f'orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="{c["edge"]}"/></marker>'
           f'<marker id="ae" viewBox="0 0 10 10" refX="9.5" refY="5" markerWidth="8" markerHeight="8" '
           f'orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="{c["error"]}"/></marker>'
           f'<marker id="ad" viewBox="0 0 10 10" refX="9.5" refY="5" markerWidth="8" markerHeight="8" '
           f'orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="{c["data"]}"/></marker></defs>',
           f'<rect width="{width}" height="{height}" fill="{c["sheet"]}"/>',
           f'<rect x="{MARGIN / 2}" y="{MARGIN / 2}" width="{width - MARGIN}" height="{height - MARGIN}" '
           f'fill="none" stroke="{c["ink"]}" stroke-width="1"/>']
    # heading
    out.append(f'<text x="{MARGIN}" y="{MARGIN + 30}" font-size="22" font-weight="700" fill="{c["ink"]}">'
               f'{chart["number"]} · {esc(chart["title"])}</text>')
    out.append(f'<text x="{MARGIN}" y="{MARGIN + 54}" font-size="12.5" fill="{c["muted"]}">'
               f'{esc(chart["subtitle"])}</text>')
    out.append(f'<text x="{width - MARGIN}" y="{MARGIN + 30}" font-size="12" text-anchor="end" fill="{c["muted"]}">'
               f'Kyozo Link {VERSION}</text>')
    # lanes
    lane_top, lane_bottom = MARGIN + HEAD_H, top + rows * ROW_H + 8
    for i, name in enumerate(chart["lanes"]):
        x = MARGIN + i * LANE_W
        out.append(f'<rect x="{x}" y="{lane_top}" width="{LANE_W}" height="{lane_bottom - lane_top}" '
                   f'fill="{c["lane_a"] if i % 2 == 0 else c["lane_b"]}" stroke="{c["rule"]}" stroke-width="0.8"/>')
        out.append(f'<rect x="{x}" y="{lane_top}" width="{LANE_W}" height="{LANE_HEAD}" fill="{c["lane_head"]}" '
                   f'stroke="{c["rule"]}" stroke-width="0.8"/>')
        out.append(f'<text x="{x + LANE_W / 2}" y="{lane_top + 22}" text-anchor="middle" font-size="12.5" '
                   f'font-weight="700" fill="{c["ink"]}">{esc(name)}</text>')
    drawn_in: set = set()
    for e in edges:
        out.append(edge_svg(e, c, drawn_in))
    for s in steps.values():
        out.append(shape_svg(s, c))
    # foot: key and title block
    fy = lane_bottom + 22
    bw, bh = 300, 96
    avail = width - 2 * MARGIN
    wide = avail >= 4 * 160 + 24 + bw           # the key beside the title block, or above it
    key_svg, key_h = legend_svg(MARGIN, fy + 4, c, avail - bw - 24 if wide else avail)
    out.append(key_svg)
    bx, by = (width - MARGIN - bw, fy - 2) if wide else (MARGIN, fy + key_h + 16)
    rows_tb = [("Drawing", f'{chart["number"]} {chart["title"]}'), ("Product", f"Kyozo Link {VERSION}"),
               ("Sheet", f"{page} of {pages}"), ("Date", DATE)]
    out.append(f'<rect x="{bx}" y="{by}" width="{bw}" height="{bh}" fill="none" stroke="{c["ink"]}" '
               f'stroke-width="1"/>')
    for i, (k, v) in enumerate(rows_tb):
        ry = by + i * bh / 4
        if i:
            out.append(f'<line x1="{bx}" y1="{ry}" x2="{bx + bw}" y2="{ry}" stroke="{c["ink"]}" stroke-width="0.6"/>')
        out.append(f'<text x="{bx + 8}" y="{ry + 16}" font-size="10" fill="{c["muted"]}">{k}</text>')
        out.append(f'<text x="{bx + 74}" y="{ry + 16}" font-size="11.5" font-weight="600" fill="{c["ink"]}">'
                   f'{esc(v)}</text>')
    out.append(f'<line x1="{bx + 66}" y1="{by}" x2="{bx + 66}" y2="{by + bh}" stroke="{c["ink"]}" '
               f'stroke-width="0.6"/>')
    out.append("</svg>")
    total_h = max(height, int(by + bh + MARGIN))
    svg = "".join(out)
    if total_h != height:
        svg = svg.replace(f'viewBox="0 0 {width} {height}" width="{width}" height="{height}"',
                          f'viewBox="0 0 {width} {total_h}" width="{width}" height="{total_h}"', 1)
        svg = svg.replace(f'<rect width="{width}" height="{height}"', f'<rect width="{width}" height="{total_h}"', 1)
        svg = svg.replace(f'height="{height - MARGIN}" fill="none"', f'height="{total_h - MARGIN}" fill="none"', 1)
    return svg, width, total_h


# ---- draw.io --------------------------------------------------------------------------------------------------------
DRAWIO_STYLE = {
    "term": "rounded=1;arcSize=50;whiteSpace=wrap;html=1;fillColor=#22303C;strokeColor=#22303C;fontColor=#FFFFFF;",
    "proc": "rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#22303C;fontColor=#22303C;",
    "err": "rounded=0;whiteSpace=wrap;html=1;fillColor=#FCEBEA;strokeColor=#B42318;fontColor=#6B1209;dashed=1;",
    "dec": "rhombus;whiteSpace=wrap;html=1;fillColor=#FFF3D1;strokeColor=#8A6416;fontColor=#3D2B04;",
    "io": "shape=parallelogram;perimeter=parallelogramPerimeter;fixedSize=1;size=14;whiteSpace=wrap;html=1;"
          "fillColor=#E6F0FA;strokeColor=#2B5F8C;fontColor=#163A57;",
    "pre": "shape=process;size=0.06;backgroundOutline=1;whiteSpace=wrap;html=1;fillColor=#FFFFFF;"
           "strokeColor=#22303C;fontColor=#22303C;",
    "manual": "shape=trapezoid;perimeter=trapezoidPerimeter;flipV=1;fixedSize=1;size=12;whiteSpace=wrap;html=1;"
              "fillColor=#E9F4EA;strokeColor=#3B6D3F;fontColor=#1F3D22;",
    "store": "shape=cylinder3;boundedLbl=1;backgroundOutline=1;size=6;whiteSpace=wrap;html=1;fillColor=#F1F0EC;"
             "strokeColor=#5F5E5A;fontColor=#2C2C2A;",
}
PORT = {"top": (0.5, 0), "bottom": (0.5, 1), "left": (0, 0.5), "right": (1, 0.5)}


def chart_drawio(chart: dict, page: int, pages: int) -> str:
    steps, edges, width, height, top, rows = layout(chart)
    cells = ['<mxCell id="0"/>', '<mxCell id="1" parent="0"/>']
    n = [0]

    def nid(prefix="c"):
        n[0] += 1
        return f"{prefix}{n[0]}"

    def vertex(value, style, x, y, w, h, cid=None):
        cid = cid or nid()
        cells.append(f'<mxCell id="{cid}" value="{esc(value)}" style="{style}" vertex="1" parent="1">'
                     f'<mxGeometry x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" as="geometry"/></mxCell>')
        return cid
    text_style = "text;html=1;align=left;verticalAlign=middle;strokeColor=none;fillColor=none;"
    vertex(f'<b style="font-size:20px">{chart["number"]} · {esc(chart["title"])}</b><br>'
           f'<span style="font-size:12px;color:#5B6875">{esc(chart["subtitle"])}</span>',
           text_style, MARGIN, MARGIN + 6, 800, 56)
    lane_top, lane_bottom = MARGIN + HEAD_H, top + rows * ROW_H + 8
    for i, name in enumerate(chart["lanes"]):
        x = MARGIN + i * LANE_W
        vertex(f"<b>{esc(name)}</b>", "swimlane;html=1;startSize=34;fillColor=#E3E8ED;swimlaneFillColor="
               f"{'#F4F6F8' if i % 2 == 0 else '#FFFFFF'};strokeColor=#C9D1D9;fontColor=#22303C;movable=0;"
               "resizable=0;deletable=0;", x, lane_top, LANE_W, lane_bottom - lane_top)
    for s in steps.values():
        l, t, r, b = s.box()
        value = f"<b>{esc(s.title)}</b>" + (f"<br><font style=\"font-size:10px\">{esc(s.sub)}</font>" if s.sub else "")
        vertex(value, DRAWIO_STYLE[s.shape] + "fontSize=12;", l, t, s.w, s.h, cid=s.id)
        if s.shape != "store":
            vertex(s.id, "text;html=1;fontSize=9;fontColor=#5B6875;fontFamily=Consolas;align=left;", l - 2, t - 16,
                   60, 14)
    jump_in = {}
    for e in edges:
        colour = "#B42318" if e.kind == "error" else "#7A8794" if e.kind == "data" else "#22303C"
        dash = "dashed=1;dashPattern=6 4;" if e.kind in ("error", "optional") else \
            "dashed=1;dashPattern=2 3;" if e.kind == "data" else ""
        style = (f"edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;endArrow=block;endFill=1;strokeColor={colour};"
                 f"fontColor={colour};fontStyle=1;labelBackgroundColor=#FFFFFF;{dash}")
        if e.jump:
            letter, (ox, oy), (ix, iy), into = e.jump
            out_id = vertex(f"<b>{letter}</b>", "ellipse;aspect=fixed;html=1;fillColor=#FFFFFF;strokeColor=#22303C;",
                            ox - 11, oy - 11, 22, 22)
            ex, ey = PORT[e.exit_side]
            cells.append(f'<mxCell id="{nid("e")}" value="{esc(e.label)}" style="{style}exitX={ex};exitY={ey};" '
                         f'edge="1" parent="1" source="{e.src}" target="{out_id}"><mxGeometry relative="1" '
                         f'as="geometry"/></mxCell>')
            key = (e.dst, letter)
            if key not in jump_in:
                in_id = vertex(f"<b>{letter}</b>", "ellipse;aspect=fixed;html=1;fillColor=#FFFFFF;"
                               "strokeColor=#22303C;", ix - 11, iy - 11, 22, 22)
                jump_in[key] = in_id
                entry = "entryX=0;entryY=0.5;" if into == "left" else "entryX=0.5;entryY=0;"
                cells.append(f'<mxCell id="{nid("e")}" value="" style="{style}{entry}" edge="1" '
                             f'parent="1" source="{in_id}" target="{e.dst}"><mxGeometry relative="1" as="geometry"/>'
                             f'</mxCell>')
            continue
        ex, ey = PORT[e.exit_side]
        nx, ny = PORT[e.entry_side]
        waypoints = "".join(f'<mxPoint x="{x:.1f}" y="{y:.1f}"/>' for x, y in e.points[1:-1])
        cells.append(f'<mxCell id="{nid("e")}" value="{esc(e.label)}" style="{style}exitX={ex};exitY={ey};'
                     f'entryX={nx};entryY={ny};" edge="1" parent="1" source="{e.src}" target="{e.dst}">'
                     f'<mxGeometry relative="1" as="geometry">'
                     + (f'<Array as="points">{waypoints}</Array>' if waypoints else "")
                     + '</mxGeometry></mxCell>')
    # title block
    vertex(f"<b>Drawing</b> {chart['number']} {esc(chart['title'])}<br><b>Product</b> Kyozo Link {VERSION}<br>"
           f"<b>Sheet</b> {page} of {pages}<br><b>Date</b> {DATE}",
           "rounded=0;whiteSpace=wrap;html=1;align=left;spacingLeft=8;fillColor=#FFFFFF;strokeColor=#22303C;"
           "fontSize=11;", width - MARGIN - 300, lane_bottom + 20, 300, 90)
    return (f'<diagram id="{chart["key"]}" name="{chart["number"]} {esc(chart["title"])}"><mxGraphModel dx="1200" '
            f'dy="800" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" '
            f'pageScale="1" pageWidth="{width}" pageHeight="{height}" math="0" shadow="0"><root>'
            + "".join(cells) + "</root></mxGraphModel></diagram>")


# ---- PDF (through Qt's SVG renderer) -----------------------------------------------------------------------------------
def write_pdf(svgs: list[tuple[str, int, int]], path: Path) -> bool:
    try:
        if os.name != "nt":          # (on Windows the offscreen platform draws no text: it finds no fonts)
            os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtCore import QByteArray, QMarginsF, QRectF, QSizeF
        from PyQt6.QtGui import QGuiApplication, QPageLayout, QPageSize, QPainter, QPdfWriter
        from PyQt6.QtSvg import QSvgRenderer
    except ImportError as exc:
        print(f"PDF skipped ({exc})")
        return False
    app = QGuiApplication.instance() or QGuiApplication(sys.argv[:1])   # noqa: F841 - fonts need it
    writer = QPdfWriter(str(path))
    writer.setResolution(96)
    writer.setTitle("Kyozo Link flowcharts")
    painter = None
    for i, (svg, w, h) in enumerate(svgs):
        size = QPageSize(QSizeF(w * 25.4 / 96, h * 25.4 / 96), QPageSize.Unit.Millimeter)
        writer.setPageLayout(QPageLayout(size, QPageLayout.Orientation.Portrait, QMarginsF(0, 0, 0, 0)))
        if i == 0:
            painter = QPainter(writer)
        else:
            writer.newPage()
        QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(painter, QRectF(0, 0, w, h))
    painter.end()
    return True


# ---- the page ---------------------------------------------------------------------------------------------------------
def write_page(svgs: list[tuple[str, int, int]], path: Path) -> None:
    details = {}
    for chart in CHARTS:
        for s in chart["steps"]:
            sid, lane, row, shape, title, sub, src, info = s
            details[f'{chart["key"]}:{sid}'] = {"id": sid, "title": title, "sub": sub, "src": src, "info": info,
                                               "lane": chart["lanes"][lane], "shape": shape}
    tabs = "".join(f'<button type="button" class="tab" id="tab-{c["key"]}" data-key="{c["key"]}" role="tab">'
                   f'<span class="num">{c["number"]}</span> {esc(c["title"])}</button>' for c in CHARTS)
    sheets = "".join(f'<div class="sheet" id="sheet-{c["key"]}" data-key="{c["key"]}" data-w="{w}" data-h="{h}" '
                     f'hidden>{svg}</div>' for c, (svg, w, h) in zip(CHARTS, svgs))
    template = (HERE / "page_template.html").read_text(encoding="utf-8")
    page = (template.replace("{{TABS}}", tabs).replace("{{SHEETS}}", sheets)
            .replace("{{DETAILS}}", json.dumps(details)).replace("{{VERSION}}", VERSION).replace("{{DATE}}", DATE))
    path.write_text(page, encoding="utf-8")


def main() -> int:
    problems = []
    colour, bw = [], []
    for page, chart in enumerate(CHARTS, start=1):
        steps, edges, *_ = layout(chart)
        problems += check(chart, steps, edges)
        colour.append(chart_svg(chart, COLOUR, page, len(CHARTS)))
        bw.append(chart_svg(chart, BW, page, len(CHARTS)))
    for chart, (svg, _, _), (svg_bw, _, _) in zip(CHARTS, colour, bw):
        stem = f'{chart["number"]}_{chart["key"]}'
        (HERE / f"{stem}.svg").write_text(svg, encoding="utf-8")
        (HERE / f"{stem}_bw.svg").write_text(svg_bw, encoding="utf-8")
    drawio = ('<mxfile host="Kyozo Link" type="device">'
              + "".join(chart_drawio(c, i, len(CHARTS)) for i, c in enumerate(CHARTS, start=1)) + "</mxfile>")
    (HERE / "kyozo_link.drawio").write_text(drawio, encoding="utf-8")
    write_pdf(colour, HERE / "kyozo_link_flowcharts.pdf")
    write_pdf(bw, HERE / "kyozo_link_flowcharts_bw.pdf")
    if (HERE / "page_template.html").exists():
        write_page(colour, HERE / "kyozo_link_flowcharts.html")
    for p in problems:
        print("LAYOUT:", p)
    print(f"Written to {HERE} ({len(problems)} layout problems)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())

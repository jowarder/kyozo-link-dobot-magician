# Kyozo Link: natural-language control of a vision-guided robot arm

**Project summary, version 3.6 (in development)**
Prepared by: (your name) · 7 October 2026

---

## Summary

Kyozo Link is a desktop application that lets a person control a robot arm by typing requests in plain language,
such as *"put the red cube in the tray"*, *"build a tower with the purple cube at the bottom"* or *"undo that"*.
A depth camera (Orbbec Gemini 335) finds the objects on the table. A language model running locally on the PC
(Qwen3, through Ollama) decides which actions are needed. The application itself works out every position and
checks every move for safety before the arm moves.

It supports two robots: the Dobot Magician and the UFACTORY xArm 6, both with two-finger grippers. It also has a
full simulator (a digital twin), so all of it can be developed and tested without hardware.

The current work (V3.6) is a new camera calibration method that uses only a cube and the robot itself, with no
printed marker. In simulation it reduces the calibration error from 2–4 mm to about 0.2–0.5 mm.

---

## Hardware and software

| | |
|---|---|
| **Robots** | Dobot Magician (USB), UFACTORY xArm 6 (Ethernet); two-finger grippers |
| **Camera** | Orbbec Gemini 335 stereo RGB-D camera (colour and depth, 30 frames/s, USB 3) |
| **AI model** | Qwen3 4B (instruct, 4-bit), run locally by Ollama; no internet connection or cloud service needed |
| **Software** | Python 3.12, PyQt6 (interface), OpenCV and NumPy (vision, geometry), PyBullet (simulator) |
| **Size** | About 22,000 lines of application code; 26 test modules with 407 automated tests |

---

## What it does

- **Plain-language requests.** 23 robot actions the AI can use: pick and place, put into a tray, build and take
  apart towers, line objects up, sort, swap two objects, turn an object, move it by a distance, put things back
  (undo), and work slowly when asked.
- **Finding objects.** From the depth image the app finds anything standing on the table, of any colour, and
  names it by colour and shape ("blue cylinder", "brown block"). It also finds objects stacked on each other.
- **Manual control.** Jogging, gripper control, saved positions, and click-to-move on the camera picture.
- **Three ways to calibrate the camera:**
  - an automatic one with a printed marker;
  - one by hand (clicking the tool in the picture);
  - the new cube method (see below).
- **Transparency.** A *Model* tab records every decision the AI made for each request (what it understood, which
  object, which action and why), and every check and arm movement the app carried out. Each request is also saved
  to a file.
- **Simulator (demo mode).** A 3D digital twin of each robot, the table and the camera, with ready-made scenes and
  adjustable camera noise. The simulated gripper follows the same rules as the real one: an object is held only if
  the real gripper could hold it.
- **System check.** One button checks the robot, camera, depth quality, calibration and AI connection, and says
  what to fix.

---

## Architecture

The software is organised in layers. Each layer talks only to the one below it through a fixed interface. That
is why the same code drives the real robots and the simulator.

| Layer | Responsibility |
|---|---|
| User interface | Tabs for requests, manual control, calibration, 3D view, AI log, settings |
| AI agent | Sends the request to Qwen3, runs the chosen actions, checks each step and the final result |
| Vision | Turns camera pictures into objects with positions in the robot's millimetres |
| Calibration | Works out where the camera is relative to the robot |
| Hardware interface | One common interface for robots and cameras |
| Drivers / simulator | Dobot, xArm and Gemini 335 drivers, or the PyBullet digital twin |

**A key design decision:** the language model only *names* actions and objects ("pick obj_3"). It never gives
coordinates. All geometry, motion planning and safety checks are done by ordinary, tested code. This keeps a small
local model reliable and makes every move checkable.

Detailed flowcharts (ISO 5807, with swimlanes) are in `docs/flowcharts/`: an overview, the cube calibration,
handling a request, and the vision pipeline. They come as a PDF and as an editable diagrams.net file.

---

## How a request is carried out

1. **Prepare.** The request is given to the AI together with what the gripper holds and the previous request.
   Requests for slow movement, and towers with required positions ("red at the bottom"), are worked out by the app
   first.
2. **Choose.** Qwen3 chooses the next action from the list of 23.
3. **Check the step.** The app checks the step makes sense for the request, for example that it doesn't build a
   tower in the wrong order. If not, it is refused and the reason goes back to the AI.
4. **Plan.** The app looks at the table again, then plans the movement:
   - Is the target within the arm's reach and above the safety floor?
   - Does the object fit between the fingers?
   - Which way must the gripper turn?
   - Is there a clear path past other objects?
   - Can the camera see the place?
5. **Move.** The arm moves; E-STOP ends the request immediately.
6. **Report.** The result goes back to the AI, and steps 2–5 repeat, up to 20 steps.
7. **Goal check.** When the AI says it has finished, the app checks this itself, for example that the tray really
   is empty. If not, the AI is told what is still missing. Only then is the reply shown.

---

## Camera calibration: the V3.6 work

**Problem.** For picking, the app must know exactly where the camera is relative to the robot. With the earlier
marker method the marker sits about 150 mm above the fingertips. A small tilt in the result (1° ≈ 2.6 mm) then
becomes a sideways error at the table, where objects are picked. Picks were 2–3 mm off, with a gripper that has
only about 3 mm to spare on each side of a 20 mm cube.

**Method (calibration with a cube).** The calibration is measured where objects are picked, with the real
gripper:

1. The user touches the table with the fingertips, once with the arm stretched out and once near the cube. This
   gives the table height directly, and how it changes with the arm's reach (the Dobot's height drifts by 2–3 mm
   when stretched out). They then grip a cube.
2. The robot centres the cube in its gripper (a squeeze in place, the wrist in the middle of its range).
3. It puts the cube down at 6–20 spots spread over the table, letting go 0.5 mm above the table at each one. At each
   spot the arm moves away and the camera finds the cube by comparing the depth image with the empty table. No
   earlier calibration is needed for that. If the cube turned as it was let go, the camera sees it and the wrist
   turns to match before taking it back.
4. The cube is put back at the first spot to check it hasn't moved in the gripper (over 3 mm: no result).
5. The solve uses the table surface (thousands of depth points) for the camera's tilt and height, and the cube
   positions for the rest. Alternatives are tried: a depth-scale correction, the sensor's raw depth, and a smooth
   correction across the table. Each is kept only if it predicts every spot better when that spot is left out of
   the fit (leave-one-out cross-validation).
6. Optional checks:
   - a **pick test** at spots the calibration never saw;
   - **towers of 2–3 cubes** to check and improve the height accuracy.

The real camera's lens distortion is now also corrected using the parameters the camera reports.

**Results in the simulator** (starting from a calibration tilted by 1.5°, about 4 mm off):

| | Dobot Magician | xArm 6 |
|---|---|---|
| Error after calibration, sideways | 0.2–0.35 mm | about 0.5–0.6 mm* |
| Each spot predicted from the others | 0.1–0.2 mm | 0.1–0.15 mm |
| Pick test at new spots | within 0.1 mm, 3 of 3 picks held | within 0.3 mm, 3 of 3 picks held |
| Heights at 2 and 3 cubes up | within 0.25 mm | within 0.3 mm |

\* About half of this comes from how the simulated camera samples pixels, not from the method.

**Important:** these are simulation results. The method has not yet been tried on the real robot and camera; that
is the next lab session. With real hardware I expect roughly 0.3–0.6 mm, limited mainly by the robot's own
repeatability and the camera mount.

---

## Safety

- E-STOP button always visible; it stops any movement at once and ends the request or calibration under way.
- Every move is checked against the workspace limits, the arm's reach and a safety floor above the table.
- Collision checks against other objects and the gripper's own shape; nothing is put down where the camera can't
  see.
- Optional step-by-step mode: the user approves each move before it happens.

---

## Testing and quality

- **407 automated tests**, many of them running the full application against the simulator, including noisy
  camera settings ("Realistic", "Poor") that imitate real depth noise.
- **Version control** (git) with tagged releases from V1.8 to V3.5. Each version is documented in a changelog
  with what changed and what was measured.
- **Replayable records.** Every calibration run is saved with its images and can be replayed and analysed later.
  Every AI request is saved as a log file.

---

## Development history

| Version | Date (2026) | Main content |
|---|---|---|
| V1.8 | 23 Sep | First version working on the real Dobot |
| V2.0–V2.5 | 24 Sep – 2 Oct | Settings, 3D view and demo scenes; Model tab; two-finger gripper; objects of any colour by depth; collision-free planning |
| V3.2 | 3 Oct | UFACTORY xArm 6 as a second robot; model picker; turning objects |
| V3.3–V3.5 | 3 Oct | Many more request types; every step checked against the request; about 30× faster AI answers on CPU; detection robust to camera noise |
| V3.6 | in progress | Cube calibration, lens correction, flowcharts |

---

## Status and next steps

1. **Lab validation of the cube calibration on the Dobot.** Mount the camera rigidly, calibrate, run the pick test
   and record the real accuracy.
2. **Bring the xArm 6 online.** It needs the control box's network address and a camera position.
3. **Confirm the camera extras on the real Gemini 335.** The lens correction and the raw depth image have only
   been tested in simulation.
4. **Use the measured gripper offset in picks.** The calibration already measures how far the gripper's centre is
   from the wrist axis, but picks don't yet correct for it.
5. **Possible extensions:** one-press recalibration (the robot finds and grips the cube itself), and refining the
   calibration from normal pick-and-place work.

---

## More detail

- `README.md`: installation, use and calibration instructions.
- `CHANGELOG.md`: every version, with measurements.
- `docs/flowcharts/`: flowcharts as PDF (colour and black and white), SVG and an editable diagrams.net file.

# Kyozo Link

A desktop app that lets a local language model (Qwen3, run with Ollama) drive a Dobot Magician robot arm from a depth
camera (Orbbec Gemini 335): you type an instruction such as "Swap the red and blue cubes, then turn the blue cube 30
degrees anticlockwise", and the app looks at the table, plans the picks and places, and checks the result. A digital
twin (PyBullet) runs the same tasks in simulation. A separate watcher program scores every run with its own camera.

This is version **4.6** (git tag `v4.6`, 2026-10-29).

## People

**Rafiul Azim Jowarder**, Doctoral Student, Victor A. Zaloom Department of Industrial and Systems Engineering,
Lamar University.

Supervisor: **Dr. James Curry**, Department Chair and Professor, Department of Industrial and Systems Engineering,
Lamar University.

With help from **Dr. Wenhao Yang**, Assistant Professor, Lamar University.

## What is here

| Folder | What |
|---|---|
| [`Kyozo_Link/`](Kyozo_Link/) | The app's source code, tests, the watcher and the study plan (`study/PREREG.md`). Setup: [`Kyozo_Link/README.md`](Kyozo_Link/README.md). Every version's changes: [`Kyozo_Link/CHANGELOG.md`](Kyozo_Link/CHANGELOG.md) |
| [`study_reports/`](study_reports/) | Results of studies 1 to 4 on the real Dobot (and studies 1 and 2 in the twin): one Markdown report and one Excel workbook per study, and all four side by side in [`study_reports/README.md`](study_reports/README.md) |

In the study reports a task the watcher skipped (never started) counts as a FAIL.

Not included: calibration photos, run pictures, depth files and logs (too large, and the study's raw data), and the
unseen test set and its results (kept private).

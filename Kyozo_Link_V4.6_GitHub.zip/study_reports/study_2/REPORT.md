# Study 2

- **Rafiul Azim Jowarder**, Doctoral Student, Victor A. Zaloom Department of Industrial and Systems Engineering,
  Lamar University
- Supervisor: **Dr. James Curry**, Department Chair and Professor, Department of Industrial and Systems Engineering,
  Lamar University
- With help from **Dr. Wenhao Yang**, Assistant Professor, Lamar University

## Real Dobot Magician

| Setting | Value |
|---|---|
| Dates | 2026-10-26 |
| Session | 20 Tasks for Dobot (by itself) |
| Software | Kyozo Link, git commit `f07c20e` (v4.2-2-gf07c20e) |
| Model | qwen3:4b-instruct-2507-q4_K_M, temperature 0.2, seed 42 |
| Cubes | 25 mm, set of 3 |
| Scoring | the watcher's camera look |
| Tasks | Simple 20 (`Kyozo_Link/study/tasks/simple.yaml`), chained: each starts where the last left the cubes |

### Results

| Measure | Value |
|---|---|
| Attempts | 32 (29 ran, 3 skipped) |
| PASS | 8 |
| SOME PARTS (counted as FAIL) | 0 |
| FAIL | 21 |
| Skipped (counted as FAIL) | 3 |
| **Pass rate** | **8/32 (25%)** |
| Mean score (0-100, skipped = 0) | 30.1 |
| Tasks passed at least once | 5/20 |
| Catastrophic attempts | 9 |
| Median position error (mm, runs that ran) | 40.1 |

| Group | Pass rate |
|---|---|
| A: moves | 8/10 (80%) |
| B: swaps with a turn | 0/10 (0%) |
| C: towers of two | 0/7 (0%) |
| D: tower of three, drops | 0/5 (0%) |

Failures by type (SOME PARTS and skipped included): plan 11, execution 8, skipped 3, preparation 2


### Task by task

| Task | Group | Instruction | Attempts, in order | Passed |
|---|---|---|---|---|
| S-01 | A | Move the red cube 40 mm further from the robot. | FAIL, PASS | 1/2 |
| S-02 | A | Move the blue cube 40 mm nearer the robot. | PASS, PASS | 2/2 |
| S-03 | A | Move the green cube 50 mm further from the robot. | PASS, FAIL | 1/2 |
| S-04 | A | Move the green cube 50 mm nearer the robot. | PASS, PASS | 2/2 |
| S-05 | A | Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot. | PASS, PASS | 2/2 |
| S-06 | B | Swap the red and green cubes, then turn the red cube 45 degrees anticlockwise. | FAIL, FAIL | 0/2 |
| S-07 | B | Swap the red and blue cubes, then turn the blue cube 30 degrees anticlockwise. | FAIL, FAIL | 0/2 |
| S-08 | B | Swap the green and blue cubes, then turn the green cube 45 degrees clockwise. | FAIL, FAIL | 0/2 |
| S-09 | B | Swap the blue and red cubes, then turn the red cube 30 degrees clockwise. | FAIL, FAIL | 0/2 |
| S-10 | B | Swap the red and blue cubes, then turn both of them 30 degrees clockwise. | SKIPPED, FAIL | 0/2 |
| S-11 | C | Put the red cube on the green cube. | SKIPPED, FAIL | 0/2 |
| S-12 | C | Take the red cube off the green cube and put it to the right of the green cube with a 50 mm gap. | SKIPPED, FAIL | 0/2 |
| S-13 | C | Put the blue cube on the green cube. | FAIL | 0/1 |
| S-14 | C | Take the tower apart: put the blue cube to the left of the green cube with a 45 mm gap. | FAIL | 0/1 |
| S-15 | C | Put the green cube on the blue cube. | FAIL | 0/1 |
| S-16 | D | Take the green cube off the blue cube and put it to the right of the blue cube with a 40 mm gap. | FAIL | 0/1 |
| S-17 | D | Build a tower with the green cube at the bottom, then the red cube, then the blue cube on top. | FAIL | 0/1 |
| S-18 | D | Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap. | FAIL | 0/1 |
| S-19 | D | Take the red cube off the green cube, lift it 50 mm above the table to the right of the green cube with a 50 mm gap, and let it drop. | FAIL | 0/1 |
| S-20 | D | Pick up the blue cube, lift it 40 mm above the table, move it 40 mm nearer the robot, and let it drop. | FAIL | 0/1 |

### Failed and skipped attempts

- **S-01** S-01_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 86.7 mm
- **S-06** S-06_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 163.0 mm · **catastrophic:** the arm couldn't park: The robot's controller is stuck in alarm (0x12: 'a joint would go past its limit') and refuses every move, even to where it already is. Clearing it doesn't help. Switch the Dobot off, wait 5 seconds, switch it on, then press Home here with the area clear. If it comes back straight after homing, check the arm isn't pushed against something. Joint angles now: J1 64.7, J2 21.7, J3 18.6, J4 -64.7 degrees.
- **S-07** S-07_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 88.4 mm · **catastrophic:** the arm couldn't park: The robot's controller is stuck in alarm (0x12: 'a joint would go past its limit') and refuses every move, even to where it already is. Clearing it doesn't help. Switch the Dobot off, wait 5 seconds, switch it on, then press Home here with the area clear. If it comes back straight after homing, check the arm isn't pushed against something. Joint angles now: J1 64.7, J2 21.7, J3 18.6, J4 -64.7 degrees.
- **S-08** S-08_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 465.9 mm · **catastrophic:** the red cube can't be seen at the end (knocked off the table?); the green cube ended outside the tray, at (203, -401); the blue cube ended outside the tray, at (284, -387); the arm lost its homing
- **S-09** S-09_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · **catastrophic:** the green cube can't be seen at the end (knocked off the table?); the blue cube can't be seen at the end (knocked off the table?); the arm couldn't park: ClearCommError failed (PermissionError(13, 'Access is denied.', None, 5))
- **S-10** S-10_Run1 · SKIPPED · skipped, never started: no cube can be seen (looked 6 time(s) from 2 arm position(s))
- **S-11** S-11_Run1 · SKIPPED · skipped, never started: no cube can be seen (looked 6 time(s) from 2 arm position(s))
- **S-12** S-12_Run1 · SKIPPED · skipped, never started: no cube can be seen (looked 6 time(s) from 2 arm position(s))
- **S-03** S-03_Run2 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 16.5 mm
- **S-06** S-06_Run2 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 116.8 mm
- **S-07** S-07_Run2 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 180.5 mm · **catastrophic:** the blue cube ended outside the tray, at (129, 111)
- **S-08** S-08_Run2 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 120.7 mm
- **S-09** S-09_Run2 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 203.6 mm · **catastrophic:** the green cube, not part of the task, moved 106 mm; the green cube ended outside the tray, at (100, 159); the blue cube ended outside the tray, at (124, 151)
- **S-10** S-10_Run2 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 85.1 mm
- **S-11** S-11_Run2 · FAIL · plan: Qwen chose the wrong cube, action or direction · **catastrophic:** the red cube can't be seen at the end (knocked off the table?)
- **S-12** S-12_Run2 · FAIL · preparation: moving a cube out of the way (a tower taken down, a cube put aside) failed · **catastrophic:** the red cube can't be seen at the end (knocked off the table?)
- **S-13** S-13_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 25.9 mm
- **S-14** S-14_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 81.3 mm
- **S-15** S-15_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 26.7 mm
- **S-16** S-16_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 77.8 mm
- **S-17** S-17_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 26.2 mm
- **S-18** S-18_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 96.3 mm
- **S-19** S-19_Run1 · FAIL · preparation: moving a cube out of the way (a tower taken down, a cube put aside) failed · **catastrophic:** the red cube can't be seen at the end (knocked off the table?)
- **S-20** S-20_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 40.1 mm

## Digital twin (simulation)

| Setting | Value |
|---|---|
| Dates | 2026-10-25 |
| Session | 20 Tasks for Twin (by itself) |
| Software | Kyozo Link, git commit `f07c20e` (v4.2-2-gf07c20e) |
| Model | qwen3:4b-instruct-2507-q4_K_M, temperature 0.2, seed 42 |
| Cubes | 25 mm, set of 3 |
| Scoring | the twin's exact positions |
| Tasks | Simple 20 (`Kyozo_Link/study/tasks/simple.yaml`), chained: each starts where the last left the cubes |

### Results

| Measure | Value |
|---|---|
| Attempts | 20 (20 ran, 0 skipped) |
| PASS | 19 |
| SOME PARTS (counted as FAIL) | 0 |
| FAIL | 1 |
| Skipped (counted as FAIL) | 0 |
| **Pass rate** | **19/20 (95%)** |
| Mean score (0-100, skipped = 0) | 95.0 |
| Tasks passed at least once | 19/20 |
| Catastrophic attempts | 0 |
| Median position error (mm, runs that ran) | 0.1 |

| Group | Pass rate |
|---|---|
| A: moves | 5/5 (100%) |
| B: swaps with a turn | 5/5 (100%) |
| C: towers of two | 5/5 (100%) |
| D: tower of three, drops | 4/5 (80%) |

Failures by type (SOME PARTS and skipped included): execution 1


### Task by task

| Task | Group | Instruction | Attempts, in order | Passed |
|---|---|---|---|---|
| S-01 | A | Move the red cube 40 mm further from the robot. | PASS | 1/1 |
| S-02 | A | Move the blue cube 40 mm nearer the robot. | PASS | 1/1 |
| S-03 | A | Move the green cube 50 mm further from the robot. | PASS | 1/1 |
| S-04 | A | Move the green cube 50 mm nearer the robot. | PASS | 1/1 |
| S-05 | A | Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot. | PASS | 1/1 |
| S-06 | B | Swap the red and green cubes, then turn the red cube 45 degrees anticlockwise. | PASS | 1/1 |
| S-07 | B | Swap the red and blue cubes, then turn the blue cube 30 degrees anticlockwise. | PASS | 1/1 |
| S-08 | B | Swap the green and blue cubes, then turn the green cube 45 degrees clockwise. | PASS | 1/1 |
| S-09 | B | Swap the blue and red cubes, then turn the red cube 30 degrees clockwise. | PASS | 1/1 |
| S-10 | B | Swap the red and blue cubes, then turn both of them 30 degrees clockwise. | PASS | 1/1 |
| S-11 | C | Put the red cube on the green cube. | PASS | 1/1 |
| S-12 | C | Take the red cube off the green cube and put it to the right of the green cube with a 50 mm gap. | PASS | 1/1 |
| S-13 | C | Put the blue cube on the green cube. | PASS | 1/1 |
| S-14 | C | Take the tower apart: put the blue cube to the left of the green cube with a 45 mm gap. | PASS | 1/1 |
| S-15 | C | Put the green cube on the blue cube. | PASS | 1/1 |
| S-16 | D | Take the green cube off the blue cube and put it to the right of the blue cube with a 40 mm gap. | PASS | 1/1 |
| S-17 | D | Build a tower with the green cube at the bottom, then the red cube, then the blue cube on top. | PASS | 1/1 |
| S-18 | D | Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap. | PASS | 1/1 |
| S-19 | D | Take the red cube off the green cube, lift it 50 mm above the table to the right of the green cube with a 50 mm gap, and let it drop. | PASS | 1/1 |
| S-20 | D | Pick up the blue cube, lift it 40 mm above the table, move it 40 mm nearer the robot, and let it drop. | FAIL | 0/1 |

### Failed and skipped attempts

- **S-20** S-20_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 72.2 mm

## What changed after study 2

Narration v2: the update after study 2 (V4.4, extending V4.3). Full account: `Kyozo_Link/study/NARRATION_v2.md`; every change: `Kyozo_Link/study/CHANGES_v2.csv` (and the Changes sheet of `study_2.xlsx`).

| Change | Kind | Aimed at | What it does |
|---|---|---|---|
| v2-01 | hardware compensation | catastrophic | The Dobot refuses every move until Home after a connect (a power cycle) or a lost USB link (RobotNeedsPerson); an alarm it can't clear holds it too, with the controller's state logged. |
| v2-02 | hardware compensation | limit_alarm | Every target is checked against the controller's own arm (J2/J3, fitted to 323 real moves) before it is sent, and refused with words if the controller would refuse it; picks and places near the base come down from lower… |
| v2-03 | hardware compensation | perception | A flat top of two clear colours, each at least a fifth of it and mostly in one piece, is split into two tops (each pixel to the colour nearest it) before each object grows its sides: two cubes touching are two cubes |
| v2-04 | software fix | preparation | The cubes' narrow sides as measured (before the known size is put on them) are kept; when their middle is within 2 mm of another size offered and 3.5 mm or more from the one set, nothing that grips or puts down a cube r… |
| v2-05 | software fix | preparation | A cube size list beside the prompt box (Cubes: 25 mm / 20 mm), the same setting as Settings > Cubes and kept in step with it; every cube size list is locked while a prompt runs |
| v2-06 | software fix | other | Watcher (approved by Dr. |
| v2-07 | software fix | preparation | Watcher (approved): the cube size the session goes by is at the top of the window (the status strip), before and during a session, and what the cubes measure if the app found them another size |
| v2-08 | hardware compensation | catastrophic | Watcher (approved): when the arm needs a person (DobotRobot.needs_person: not homed, its USB link lost, an alarm it can't clear) nothing starts, the strip says "Waiting for you · the arm needs a person", Run by itself p… |
| v2-09 | software fix | refusal | An object id from an earlier look (since the table was set out) means the one cube of its colour seen now; a swap finds the cube it just put down by its colour and where it put it, and, stopped part-way, says where both… |
| v2-10 | software fix | plan | After a whole move (move_object, swap), a put-down with nothing held is told that move is done and not to pick the cube up again (with the pick call, if it is meant to go on); move_object's description and result say it… |
| v2-11 | software fix | other | unittest.main() moved to the end of six test files: the test classes written after it now run when a file is run by itself (unittest discover ran them already) |
| v2-12 | software fix | refusal | In the twin, a grip that closed on nothing is looked at again and tried once more by the app, as the Dobot's missed grip already was (idea 17); a finger that came down on the cube's edge is said so ("the fingers came do… |
| v2-13 | software fix | refusal | After a missed grip, the cube is looked for again by its name, or else by its colour within 30 mm of where it was: the camera may name its shape another way from one look to the next |
| v2-14 | software fix | perception | Before a pick's fresh pictures of a cube (its turn, where it is now), the arm is taken out from between the camera and that cube if it stands there, as list_objects already does for all of them |
| v2-15 | software fix | plan | swap's result names each cube with its id ("the red cube (obj_35) is now at ..."), as pick's already does |

## How it is counted

- **One attempt = one row.** Every time a task was started, or was due to start, is one attempt: the runs that ran,
  repeats included, and the tasks the watcher **skipped** (it never started them because the camera didn't see the
  table READY for them).
- **A skipped task counts as a FAIL.** Its score is 0. (The app's own SUMMARY.md files leave skipped tasks out of the
  counts; these reports don't.)
- **SOME PARTS counts as a FAIL** in the pass rate: a pass needs every target within 10 mm and 8 degrees, and no other
  cube moved more than 10 mm (PREREG). Its 0-100 score is kept beside it.
- **Pass rate** = PASS attempts / all attempts. **Mean score** = mean 0-100 score over all attempts (skipped = 0).
  **Tasks passed** = how many of the 20 tasks passed at least once; a task never tried counts as not passed.
- **Catastrophic** is a flag beside the result (a cube off the table, the arm in a stuck alarm), not a separate result.

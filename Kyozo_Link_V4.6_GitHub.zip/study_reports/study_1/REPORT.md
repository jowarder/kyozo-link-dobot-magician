# Study 1

- **Rafiul Azim Jowarder**, Doctoral Student, Victor A. Zaloom Department of Industrial and Systems Engineering,
  Lamar University
- Supervisor: **Dr. James Curry**, Department Chair and Professor, Department of Industrial and Systems Engineering,
  Lamar University
- With help from **Dr. Wenhao Yang**, Assistant Professor, Lamar University

## Real Dobot Magician

| Setting | Value |
|---|---|
| Dates | 2026-10-23 |
| Session | 20 Tasks for Dobot (by itself) |
| Software | Kyozo Link, git commit `2f0030b` (v4.0-8-g2f0030b) |
| Model | qwen3:4b-instruct-2507-q4_K_M, temperature 0.2, seed 42 |
| Cubes | 25 mm, set of 3 |
| Scoring | the watcher's camera look |
| Tasks | Simple 20 (`Kyozo_Link/study/tasks/simple.yaml`), chained: each starts where the last left the cubes |

### Results

| Measure | Value |
|---|---|
| Attempts | 31 (18 ran, 13 skipped) |
| PASS | 13 |
| SOME PARTS (counted as FAIL) | 0 |
| FAIL | 5 |
| Skipped (counted as FAIL) | 13 |
| **Pass rate** | **13/31 (42%)** |
| Mean score (0-100, skipped = 0) | 45.2 |
| Tasks passed at least once | 10/20 |
| Catastrophic attempts | 0 |
| Median position error (mm, runs that ran) | 3.3 |

| Group | Pass rate |
|---|---|
| A: moves | 4/5 (80%) |
| B: swaps with a turn | 1/10 (10%) |
| C: towers of two | 8/11 (73%) |
| D: tower of three, drops | 0/5 (0%) |

Failures by type (SOME PARTS and skipped included): skipped 13, execution 4, limit_alarm 1


### Task by task

| Task | Group | Instruction | Attempts, in order | Passed |
|---|---|---|---|---|
| S-01 | A | Move the red cube 40 mm further from the robot. | PASS | 1/1 |
| S-02 | A | Move the blue cube 40 mm nearer the robot. | PASS | 1/1 |
| S-03 | A | Move the green cube 50 mm further from the robot. | PASS | 1/1 |
| S-04 | A | Move the green cube 50 mm nearer the robot. | PASS | 1/1 |
| S-05 | A | Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot. | FAIL | 0/1 |
| S-06 | B | Swap the red and green cubes, then turn the red cube 45 degrees anticlockwise. | SKIPPED, FAIL | 0/2 |
| S-07 | B | Swap the red and blue cubes, then turn the blue cube 30 degrees anticlockwise. | SKIPPED, FAIL | 0/2 |
| S-08 | B | Swap the green and blue cubes, then turn the green cube 45 degrees clockwise. | SKIPPED, FAIL | 0/2 |
| S-09 | B | Swap the blue and red cubes, then turn the red cube 30 degrees clockwise. | SKIPPED, FAIL | 0/2 |
| S-10 | B | Swap the red and blue cubes, then turn both of them 30 degrees clockwise. | SKIPPED, PASS | 1/2 |
| S-11 | C | Put the red cube on the green cube. | SKIPPED, PASS, PASS | 2/3 |
| S-12 | C | Take the red cube off the green cube and put it to the right of the green cube with a 50 mm gap. | SKIPPED, PASS, PASS | 2/3 |
| S-13 | C | Put the blue cube on the green cube. | SKIPPED, PASS, PASS | 2/3 |
| S-14 | C | Take the tower apart: put the blue cube to the left of the green cube with a 45 mm gap. | PASS | 1/1 |
| S-15 | C | Put the green cube on the blue cube. | PASS | 1/1 |
| S-16 | D | Take the green cube off the blue cube and put it to the right of the blue cube with a 40 mm gap. | SKIPPED | 0/1 |
| S-17 | D | Build a tower with the green cube at the bottom, then the red cube, then the blue cube on top. | SKIPPED | 0/1 |
| S-18 | D | Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap. | SKIPPED | 0/1 |
| S-19 | D | Take the red cube off the green cube, lift it 50 mm above the table to the right of the green cube with a 50 mm gap, and let it drop. | SKIPPED | 0/1 |
| S-20 | D | Pick up the blue cube, lift it 40 mm above the table, move it 40 mm nearer the robot, and let it drop. | SKIPPED | 0/1 |

### Failed and skipped attempts

- **S-05** S-05_Run1 · FAIL · limit alarm: the arm couldn't reach the pose · position error 60.4 mm
- **S-06** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-07** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-08** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-09** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-10** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-11** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-12** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: green cube, then red cube on top (bottom first). The camera doesn't see it like that)
- **S-13** (session 2026-10-23_115448, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-06** S-06_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 70.3 mm
- **S-07** S-07_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 1.0 mm
- **S-08** S-08_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 2.8 mm
- **S-09** S-09_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 114.4 mm
- **S-16** (session 2026-10-23_124708, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: blue cube, then green cube on top (bottom first). The camera doesn't see it like that)
- **S-17** (session 2026-10-23_124708, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Put the blue cube and the green cube on the grey sheet)
- **S-18** (session 2026-10-23_124708, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: green cube, then red cube, then blue cube on top (bottom first). The camera doesn't see it like that)
- **S-19** (session 2026-10-23_124708, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: green cube, then red cube on top (bottom first). The camera doesn't see it like that)
- **S-20** (session 2026-10-23_124708, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Put the blue cube and the green cube on the grey sheet)

## Digital twin (simulation)

| Setting | Value |
|---|---|
| Dates | 2026-10-23 |
| Session | 20 Tasks for Twin (by itself) |
| Software | Kyozo Link, git commit `69df47c` (v4.0-9-g69df47c) |
| Model | qwen3:4b-instruct-2507-q4_K_M, temperature 0.2, seed 42 |
| Cubes | 25 mm, set of 3 |
| Scoring | the twin's exact positions |
| Tasks | Simple 20 (`Kyozo_Link/study/tasks/simple.yaml`), chained: each starts where the last left the cubes |

### Results

| Measure | Value |
|---|---|
| Attempts | 20 (5 ran, 15 skipped) |
| PASS | 4 |
| SOME PARTS (counted as FAIL) | 0 |
| FAIL | 1 |
| Skipped (counted as FAIL) | 15 |
| **Pass rate** | **4/20 (20%)** |
| Mean score (0-100, skipped = 0) | 20.0 |
| Tasks passed at least once | 4/20 |
| Catastrophic attempts | 0 |
| Median position error (mm, runs that ran) | 0.1 |

| Group | Pass rate |
|---|---|
| A: moves | 4/5 (80%) |
| B: swaps with a turn | 0/5 (0%) |
| C: towers of two | 0/5 (0%) |
| D: tower of three, drops | 0/5 (0%) |

Failures by type (SOME PARTS and skipped included): skipped 15, limit_alarm 1


### Task by task

| Task | Group | Instruction | Attempts, in order | Passed |
|---|---|---|---|---|
| S-01 | A | Move the red cube 40 mm further from the robot. | PASS | 1/1 |
| S-02 | A | Move the blue cube 40 mm nearer the robot. | PASS | 1/1 |
| S-03 | A | Move the green cube 50 mm further from the robot. | PASS | 1/1 |
| S-04 | A | Move the green cube 50 mm nearer the robot. | PASS | 1/1 |
| S-05 | A | Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot. | FAIL | 0/1 |
| S-06 | B | Swap the red and green cubes, then turn the red cube 45 degrees anticlockwise. | SKIPPED | 0/1 |
| S-07 | B | Swap the red and blue cubes, then turn the blue cube 30 degrees anticlockwise. | SKIPPED | 0/1 |
| S-08 | B | Swap the green and blue cubes, then turn the green cube 45 degrees clockwise. | SKIPPED | 0/1 |
| S-09 | B | Swap the blue and red cubes, then turn the red cube 30 degrees clockwise. | SKIPPED | 0/1 |
| S-10 | B | Swap the red and blue cubes, then turn both of them 30 degrees clockwise. | SKIPPED | 0/1 |
| S-11 | C | Put the red cube on the green cube. | SKIPPED | 0/1 |
| S-12 | C | Take the red cube off the green cube and put it to the right of the green cube with a 50 mm gap. | SKIPPED | 0/1 |
| S-13 | C | Put the blue cube on the green cube. | SKIPPED | 0/1 |
| S-14 | C | Take the tower apart: put the blue cube to the left of the green cube with a 45 mm gap. | SKIPPED | 0/1 |
| S-15 | C | Put the green cube on the blue cube. | SKIPPED | 0/1 |
| S-16 | D | Take the green cube off the blue cube and put it to the right of the blue cube with a 40 mm gap. | SKIPPED | 0/1 |
| S-17 | D | Build a tower with the green cube at the bottom, then the red cube, then the blue cube on top. | SKIPPED | 0/1 |
| S-18 | D | Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap. | SKIPPED | 0/1 |
| S-19 | D | Take the red cube off the green cube, lift it 50 mm above the table to the right of the green cube with a 50 mm gap, and let it drop. | SKIPPED | 0/1 |
| S-20 | D | Pick up the blue cube, lift it 40 mm above the table, move it 40 mm nearer the robot, and let it drop. | SKIPPED | 0/1 |

### Failed and skipped attempts

- **S-05** S-05_Run1 · FAIL · limit alarm: the arm couldn't reach the pose · position error 60.0 mm
- **S-06** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-07** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-08** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-09** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-10** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-11** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-12** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: green cube, then red cube on top (bottom first). The camera doesn't see it like that)
- **S-13** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-14** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: green cube, then blue cube on top (bottom first). The camera doesn't see it like that)
- **S-15** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-16** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: blue cube, then green cube on top (bottom first). The camera doesn't see it like that)
- **S-17** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)
- **S-18** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: green cube, then red cube, then blue cube on top (bottom first). The camera doesn't see it like that)
- **S-19** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: This task starts from a tower: green cube, then red cube on top (bottom first). The camera doesn't see it like that)
- **S-20** (session 2026-10-23_154754, not saved as a run) · SKIPPED · skipped, never started: the camera didn't see the table READY for it (the watcher's note: Move the blue cube further from the robot)

## The engineer's notes on this study

Why tasks were skipped or went wrong, as the engineer wrote them at the time (in the study's package, `notes/`). The skipped tasks still count as FAIL here.

- Group D (S-16 to S-20) on 2026-10-23: why every task was skipped
- Twin, all 20 tasks on 2026-10-23: why S-06 to S-20 were skipped

## What changed after study 1

Narration v1: the update after study 1 (V4.3, round 1). Full account: `Kyozo_Link/study/NARRATION_v1.md`; every change: `Kyozo_Link/study/CHANGES_v1.csv` (and the Changes sheet of `study_1.xlsx`).

| Change | Kind | Aimed at | What it does |
|---|---|---|---|
| v1-01 | software fix | latency | The app looks at the table itself (list_objects) before the model's first answer and gives it to the model as its own call and result: the model starts from what is on the table, one turn fewer per request |
| v1-02 | software fix | latency | The model may give every step it knows in one answer; a step that fails stops the rest of that answer (NOT RUN, not counted as a refusal), so nothing runs on a table it no longer matches |
| v1-03 | software fix | latency | A done() tool after the last step: the app checks the goal (nothing held, the goal check) and writes the reply from the steps' results; done written as text counts the same. |
| v1-04 | hardware compensation | latency | The wrist's approach from one side is folded into the travel: the travel ends short of the angle and the last move turns the rest of the way (the same side, so the same backlash take-up): one move fewer per pick and per… |
| v1-05 | hardware compensation | latency | The reading taken by each move's arrival check (no alarm, arrived) stands for 2 s while nothing moves, clears or stops the arm: the next move's leftover-alarm check and the move record's before/after readings use it ins… |
| v1-06 | software fix | latency | Any installed model that can call tools is offered in the Model list (laptop size, "not tested" notes, too big for a laptop flagged slow); a pick lasts for the sitting, the Qwen default in config.yaml stays |
| v1-07 | software fix | refusal | A build_tower refused for a place it doesn't need now says the exact call to make, bottom to top |
| v1-08 | software fix | refusal | A step refused before and sent again exactly is told not to send it again (and what to do instead); "by the tower" with no tower on the table says so instead of using another cube |
| v1-09 | software fix | plan | "nearer" and "farther" are directions (towards / away from the robot), and the move_object description says "40 mm nearer the robot" = back |
| v1-10 | software fix | latency | One answer at most 256 tokens (was 512): the longest real answer in two 20-task chains was 129 tokens; one that runs on is cut off sooner and told to answer with its tool calls only |
| v1-11 | software fix | refusal | A put-down with nothing held says the calls to make: pick(object_id=...) of the object last moved, then the step again, in one answer; place_beside also says its object_id is the one to put it beside |
| v1-12 | software fix | plan | place_beside or place_on naming the held object itself as where it goes is refused, with the other objects and their ids to choose from |

## How it is counted

- **One attempt = one row.** Every time a task was started, or was due to start, is one attempt: the runs that ran,
  repeats included, and the tasks the watcher **skipped** (it never started them because the camera didn't see the
  table READY for them).
- **A skipped task counts as a FAIL.** Its score is 0. (The app's own SUMMARY.md files leave skipped tasks out of the
  counts; these reports don't.)
- **SOME PARTS counts as a FAIL** in the pass rate: a pass needs every target within 10 mm and 8 degrees, and no other
  cube moved more than 10 mm (PREREG). Its 0-100 score is kept beside it.
- **Pass rate** = PASS attempts / all attempts. **Mean score** = mean 0-100 score over all attempts (skipped = 0).
  **Tasks passed** = how many of the 20 tasks passed at least once; a task never tried counts as not passed.
- **Catastrophic** is a flag beside the result (a cube off the table, the arm in a stuck alarm), not a separate result.

# Kyozo Link: study reports (studies 1-4)

Results of the Simple 20 tasks (three 25 mm cubes, 20 chained tasks in four groups) run by Kyozo Link: a local language model (Qwen) driving a Dobot Magician from a depth camera, scored by the watcher's own camera. Studies 1 and 2 also ran in the digital twin (a simulation with ideal hardware). After each study the software was improved from that study's results, and the next study ran on the improved version.

- **Rafiul Azim Jowarder**, Doctoral Student, Victor A. Zaloom Department of Industrial and Systems Engineering,
  Lamar University
- Supervisor: **Dr. James Curry**, Department Chair and Professor, Department of Industrial and Systems Engineering,
  Lamar University
- With help from **Dr. Wenhao Yang**, Assistant Professor, Lamar University

## All studies

| Study | Data | Dates | Attempts | Skipped (= FAIL) | PASS | SOME PARTS | FAIL | **Pass rate** | Mean score | Tasks passed | Catastrophic |
|---|---|---|---|---|---|---|---|---|---|---|---|
| [1](study_1/REPORT.md) | Real Dobot Magician | 2026-10-23 | 31 | 13 | 13 | 0 | 5 | **42%** | 45.2 | 10/20 | 0 |
| [1](study_1/REPORT.md) | Digital twin (simulation) | 2026-10-23 | 20 | 15 | 4 | 0 | 1 | **20%** | 20.0 | 4/20 | 0 |
| [2](study_2/REPORT.md) | Real Dobot Magician | 2026-10-26 | 32 | 3 | 8 | 0 | 21 | **25%** | 30.1 | 5/20 | 9 |
| [2](study_2/REPORT.md) | Digital twin (simulation) | 2026-10-25 | 20 | 0 | 19 | 0 | 1 | **95%** | 95.0 | 19/20 | 0 |
| [3](study_3/REPORT.md) | Real Dobot Magician | 2026-10-28 | 20 | 0 | 12 | 3 | 5 | **60%** | 70.7 | 12/20 | 1 |
| [4](study_4/REPORT.md) | Real Dobot Magician | 2026-10-28 | 20 | 0 | 13 | 3 | 4 | **65%** | 83.3 | 13/20 | 2 |

Pass rate on the real Dobot, by group:

| Study | A: moves | B: swaps with a turn | C: towers of two | D: tower of three, drops |
|---|---|---|---|---|
| 1 | 4/5 (80%) | 1/10 (10%) | 8/11 (73%) | 0/5 (0%) |
| 2 | 8/10 (80%) | 0/10 (0%) | 0/7 (0%) | 0/5 (0%) |
| 3 | 5/5 (100%) | 0/5 (0%) | 3/5 (60%) | 4/5 (80%) |
| 4 | 5/5 (100%) | 2/5 (40%) | 4/5 (80%) | 2/5 (40%) |

## How it is counted

- **One attempt = one row.** Every time a task was started, or was due to start, is one attempt: the runs that ran,
  repeats included, and the tasks the watcher **skipped** (it never started them because the camera didn't see the
  table READY for them).
- **A skipped task counts as a FAIL.** Its score is 0. (The app's own SUMMARY.md files leave skipped tasks out of the
  counts; these reports don't.)
- **SOME PARTS counts as a FAIL** in the pass rate: a pass needs every target within 10 mm and 8 degrees, and no other
  cube moved more than 10 mm (PREREG). Its 0-100 score is kept beside it.
- **Pass rate** = PASS attempts / all attempts. **Mean score** = mean 0-100 score over all attempts (skipped = 0).
  **Tasks passed** = how many of the 20 tasks passed at least once; a task never tried counts as not passed.
- **Catastrophic** is a flag beside the result (a cube off the table, the arm in a stuck alarm), not a separate result.

## What is here

| File | What |
|---|---|
| `README.md` | This page: all four studies side by side |
| `all_studies.xlsx` | The same overview, and every attempt of every study in one sheet |
| `study_N/REPORT.md` | One study: setup, results, task by task, every failed or skipped attempt, what changed after it |
| `study_N/study_N.xlsx` | The same as sheets: summary, attempts, tasks, changes made after the study |

## Sources

- The watcher's packages `Kyozo_Link_Results/For_Claude/study_1` to `study_4` (`full_report.json`; study 1's tasks skipped before V4.2 from `skipped_before_v4.2.json`).
- The tasks: `Kyozo_Link/study/tasks/simple.yaml`. The changes after each study: `Kyozo_Link/study/CHANGES_vN.csv` and `NARRATION_vN.md`. The study plan: `Kyozo_Link/study/PREREG.md`.
- Left out: pictures, depth files and raw run folders (too large for GitHub, and the study's raw data), practice sessions (not counted), and the unseen test set and its results (kept private).

# Study 3

- **Rafiul Azim Jowarder**, Doctoral Student, Victor A. Zaloom Department of Industrial and Systems Engineering,
  Lamar University
- Supervisor: **Dr. James Curry**, Department Chair and Professor, Department of Industrial and Systems Engineering,
  Lamar University
- With help from **Dr. Wenhao Yang**, Assistant Professor, Lamar University

## Real Dobot Magician

| Setting | Value |
|---|---|
| Dates | 2026-10-28 |
| Session | 20 Tasks for Dobot (by itself) |
| Software | Kyozo Link, git commit `175dfed` (v4.3-14-g175dfed) |
| Model | qwen3:4b-instruct-2507-q4_K_M, temperature 0.2, seed 42 |
| Cubes | 25.0 mm, set of 3 |
| Scoring | the watcher's camera look |
| Tasks | Simple 20 (`Kyozo_Link/study/tasks/simple.yaml`), chained: each starts where the last left the cubes |

### Results

| Measure | Value |
|---|---|
| Attempts | 20 (20 ran, 0 skipped) |
| PASS | 12 |
| SOME PARTS (counted as FAIL) | 3 |
| FAIL | 5 |
| Skipped (counted as FAIL) | 0 |
| **Pass rate** | **12/20 (60%)** |
| Mean score (0-100, skipped = 0) | 70.7 |
| Tasks passed at least once | 12/20 |
| Catastrophic attempts | 1 |
| Median position error (mm, runs that ran) | 3.4 |

| Group | Pass rate |
|---|---|
| A: moves | 5/5 (100%) |
| B: swaps with a turn | 0/5 (0%) |
| C: towers of two | 3/5 (60%) |
| D: tower of three, drops | 4/5 (80%) |

Failures by type (SOME PARTS and skipped included): execution 5, plan 3


### Task by task

| Task | Group | Instruction | Attempts, in order | Passed |
|---|---|---|---|---|
| S-01 | A | Move the red cube 40 mm further from the robot. | PASS | 1/1 |
| S-02 | A | Move the blue cube 40 mm nearer the robot. | PASS | 1/1 |
| S-03 | A | Move the green cube 50 mm further from the robot. | PASS | 1/1 |
| S-04 | A | Move the green cube 50 mm nearer the robot. | PASS | 1/1 |
| S-05 | A | Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot. | PASS | 1/1 |
| S-06 | B | Swap the red and green cubes, then turn the red cube 45 degrees anticlockwise. | SOME PARTS | 0/1 |
| S-07 | B | Swap the red and blue cubes, then turn the blue cube 30 degrees anticlockwise. | FAIL | 0/1 |
| S-08 | B | Swap the green and blue cubes, then turn the green cube 45 degrees clockwise. | SOME PARTS | 0/1 |
| S-09 | B | Swap the blue and red cubes, then turn the red cube 30 degrees clockwise. | SOME PARTS | 0/1 |
| S-10 | B | Swap the red and blue cubes, then turn both of them 30 degrees clockwise. | FAIL | 0/1 |
| S-11 | C | Put the red cube on the green cube. | PASS | 1/1 |
| S-12 | C | Take the red cube off the green cube and put it to the right of the green cube with a 50 mm gap. | PASS | 1/1 |
| S-13 | C | Put the blue cube on the green cube. | PASS | 1/1 |
| S-14 | C | Take the tower apart: put the blue cube to the left of the green cube with a 45 mm gap. | FAIL | 0/1 |
| S-15 | C | Put the green cube on the blue cube. | FAIL | 0/1 |
| S-16 | D | Take the green cube off the blue cube and put it to the right of the blue cube with a 40 mm gap. | PASS | 1/1 |
| S-17 | D | Build a tower with the green cube at the bottom, then the red cube, then the blue cube on top. | PASS | 1/1 |
| S-18 | D | Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap. | PASS | 1/1 |
| S-19 | D | Take the red cube off the green cube, lift it 50 mm above the table to the right of the green cube with a 50 mm gap, and let it drop. | PASS | 1/1 |
| S-20 | D | Pick up the blue cube, lift it 40 mm above the table, move it 40 mm nearer the robot, and let it drop. | FAIL | 0/1 |

### Failed and skipped attempts

- **S-06** S-06_Run1 · SOME PARTS · execution: a missed grip, slip, drop, or a placement or angle error · position error 3.9 mm
- **S-07** S-07_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 122.7 mm
- **S-08** S-08_Run1 · SOME PARTS · execution: a missed grip, slip, drop, or a placement or angle error · position error 3.1 mm
- **S-09** S-09_Run1 · SOME PARTS · execution: a missed grip, slip, drop, or a placement or angle error · position error 5.9 mm
- **S-10** S-10_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 189.8 mm
- **S-14** S-14_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 70.0 mm
- **S-15** S-15_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 50.7 mm
- **S-20** S-20_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · **catastrophic:** the blue cube can't be seen at the end (knocked off the table?)

## What changed after study 3

Narration v3: the update after study 3 (V4.5, extending V4.4). Full account: `Kyozo_Link/study/NARRATION_v3.md`; every change: `Kyozo_Link/study/CHANGES_v3.csv` (and the Changes sheet of `study_3.xlsx`).

| Change | Kind | Aimed at | What it does |
|---|---|---|---|
| v3-01 | hardware compensation | execution | The fingers angle check's offset is used up to 30 degrees (was 15) when the check is otherwise steady (gain, backlash and scatter limits unchanged); an offset over 15 is used with a note in the log and the Model tab: th… |
| v3-02 | software fix | execution | A turn counts from how the cube lay when the request began: each cube's angle is noted at the prompt's first look, and a relative turn of a cube moved earlier in the same prompt aims at that angle plus the turn (said so… |
| v3-03 | hardware compensation | refusal | A cube the app itself just put down, still within 6 mm of where it was let go, whose readings wander but whose mean is within 10 degrees of the angle it was put down at, is picked at that angle instead of being refused … |
| v3-04 | software fix | plan | A new robot tool, drop: lift the held (or named) cube, carry it to a spot (direction + distance, or where it is), and let go height_mm above the table (40 by default, at most 100), or beside another object (beside_id, s… |
| v3-05 | hardware compensation | perception | The cube under another, seen only by its sides, is named from the colour groups with the top's own group left out (teal settled by the green or blue group's majority); and a request for green or blue accepts the teal ob… |
| v3-06 | software fix | plan | "X on Y" where Y stands on X: after Y is lifted off X and X is gripped, X is put down beside, Y is carried back to where it stood and at its angle, and X is put on it, so the pair stays where the pile was. |
| v3-07 | software fix | plan | A swap whose first carry fails with nothing held says "Not swapped, nothing moved: (why). |
| v3-08 | software fix | other | Each grip and each release inside one tool call (swap, the pair put back, drop) is kept in the step's record (grips: object, place, angle seen, r, J4; releases), so a swap's second pick no longer hides its first |
| v3-09 | software fix | other | Twin: what the fingers touch is judged where they really point (the wrist's faults, as the grip already used), not at the told r. |

## How it is counted

- **One attempt = one row.** Every time a task was started, or was due to start, is one attempt: the runs that ran,
  repeats included, and the tasks the watcher **skipped** (it never started them because the camera didn't see the
  table READY for them).
- **A skipped task counts as a FAIL.** Its score is 0. (The app's own SUMMARY.md files leave skipped tasks out of the
  counts; these reports don't.)
- **SOME PARTS counts as a FAIL** in the pass rate: a pass needs every target within 10 mm and 8 degrees, and no other
  cube moved more than 10 mm (PREREG). Its 0-100 score is kept beside it.
- **Pass rate** = PASS attempts / all attempts. **Mean score** = mean 0-100 score over all attempts (skipped = 0).
  **Tasks passed** = how many of the 20 tasks passed at least once; a task never tried counts as not passed.
- **Catastrophic** is a flag beside the result (a cube off the table, the arm in a stuck alarm), not a separate result.

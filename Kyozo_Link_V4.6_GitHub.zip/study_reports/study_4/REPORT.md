# Study 4

- **Rafiul Azim Jowarder**, Doctoral Student, Victor A. Zaloom Department of Industrial and Systems Engineering,
  Lamar University
- Supervisor: **Dr. James Curry**, Department Chair and Professor, Department of Industrial and Systems Engineering,
  Lamar University
- With help from **Dr. Wenhao Yang**, Assistant Professor, Lamar University

## Real Dobot Magician

| Setting | Value |
|---|---|
| Dates | 2026-10-28 |
| Session | 20 Tasks for Dobot (by itself) |
| Software | Kyozo Link, git commit `26ea23e` (v4.5-1-g26ea23e) |
| Model | qwen3:4b-instruct-2507-q4_K_M, temperature 0.2, seed 42 |
| Cubes | 25.0 mm, set of 3 |
| Scoring | the watcher's camera look |
| Tasks | Simple 20 (`Kyozo_Link/study/tasks/simple.yaml`), chained: each starts where the last left the cubes |

### Results

| Measure | Value |
|---|---|
| Attempts | 20 (20 ran, 0 skipped) |
| PASS | 13 |
| SOME PARTS (counted as FAIL) | 3 |
| FAIL | 4 |
| Skipped (counted as FAIL) | 0 |
| **Pass rate** | **13/20 (65%)** |
| Mean score (0-100, skipped = 0) | 83.3 |
| Tasks passed at least once | 13/20 |
| Catastrophic attempts | 2 |
| Median position error (mm, runs that ran) | 3.5 |

| Group | Pass rate |
|---|---|
| A: moves | 5/5 (100%) |
| B: swaps with a turn | 2/5 (40%) |
| C: towers of two | 4/5 (80%) |
| D: tower of three, drops | 2/5 (40%) |

Failures by type (SOME PARTS and skipped included): execution 5, plan 1, limit_alarm 1


### Task by task

| Task | Group | Instruction | Attempts, in order | Passed |
|---|---|---|---|---|
| S-01 | A | Move the red cube 40 mm further from the robot. | PASS | 1/1 |
| S-02 | A | Move the blue cube 40 mm nearer the robot. | PASS | 1/1 |
| S-03 | A | Move the green cube 50 mm further from the robot. | PASS | 1/1 |
| S-04 | A | Move the green cube 50 mm nearer the robot. | PASS | 1/1 |
| S-05 | A | Move the red cube 40 mm nearer the robot and the blue cube 40 mm further from the robot. | PASS | 1/1 |
| S-06 | B | Swap the red and green cubes, then turn the red cube 45 degrees anticlockwise. | PASS | 1/1 |
| S-07 | B | Swap the red and blue cubes, then turn the blue cube 30 degrees anticlockwise. | SOME PARTS | 0/1 |
| S-08 | B | Swap the green and blue cubes, then turn the green cube 45 degrees clockwise. | SOME PARTS | 0/1 |
| S-09 | B | Swap the blue and red cubes, then turn the red cube 30 degrees clockwise. | PASS | 1/1 |
| S-10 | B | Swap the red and blue cubes, then turn both of them 30 degrees clockwise. | SOME PARTS | 0/1 |
| S-11 | C | Put the red cube on the green cube. | PASS | 1/1 |
| S-12 | C | Take the red cube off the green cube and put it to the right of the green cube with a 50 mm gap. | PASS | 1/1 |
| S-13 | C | Put the blue cube on the green cube. | PASS | 1/1 |
| S-14 | C | Take the tower apart: put the blue cube to the left of the green cube with a 45 mm gap. | FAIL | 0/1 |
| S-15 | C | Put the green cube on the blue cube. | PASS | 1/1 |
| S-16 | D | Take the green cube off the blue cube and put it to the right of the blue cube with a 40 mm gap. | FAIL | 0/1 |
| S-17 | D | Build a tower with the green cube at the bottom, then the red cube, then the blue cube on top. | PASS | 1/1 |
| S-18 | D | Take the blue cube off the tower and put it to the left of the tower with a 60 mm gap. | PASS | 1/1 |
| S-19 | D | Take the red cube off the green cube, lift it 50 mm above the table to the right of the green cube with a 50 mm gap, and let it drop. | FAIL | 0/1 |
| S-20 | D | Pick up the blue cube, lift it 40 mm above the table, move it 40 mm nearer the robot, and let it drop. | FAIL | 0/1 |

### Failed and skipped attempts

- **S-07** S-07_Run1 · SOME PARTS · execution: a missed grip, slip, drop, or a placement or angle error · position error 3.5 mm
- **S-08** S-08_Run1 · SOME PARTS · execution: a missed grip, slip, drop, or a placement or angle error · position error 4.4 mm
- **S-10** S-10_Run1 · SOME PARTS · execution: a missed grip, slip, drop, or a placement or angle error · position error 7.0 mm
- **S-14** S-14_Run1 · FAIL · plan: Qwen chose the wrong cube, action or direction · position error 89.8 mm · **catastrophic:** the blue cube ended outside the tray, at (116, 137)
- **S-16** S-16_Run1 · FAIL · limit alarm: the arm couldn't reach the pose · **catastrophic:** the red cube, not part of the task, moved 50 mm; the green cube can't be seen at the end (knocked off the table?)
- **S-19** S-19_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 25.1 mm
- **S-20** S-20_Run1 · FAIL · execution: a missed grip, slip, drop, or a placement or angle error · position error 23.4 mm

## What changed after study 4

Narration v4: the update after study 4 (V4.6, extending V4.5). Full account: `Kyozo_Link/study/NARRATION_v4.md`; every change: `Kyozo_Link/study/CHANGES_v4.csv` (and the Changes sheet of `study_4.xlsx`).

| Change | Kind | Aimed at | What it does |
|---|---|---|---|
| v4-01 | hardware compensation | execution | With only cubes on the table (config.yaml vision: cubes_only, the lab's setting), each cube's turn is read from its top face by colour: the object's pixels in its own colour group within 4 mm of its flat top's height (t… |
| v4-02 | hardware compensation | execution | On a robot that can't feel its grip (the Dobot), the object last let go of must be seen somewhere on the table in the next look, and a pick that follows a release in the same request looks first. |
| v4-03 | software fix | plan | A swap keeps each cube's level: what each stands on is noted first (an object seen under it, its top at least 12 mm lower), and each is put down where the other was at that level -- on the cube the other stood on (squar… |

## How it is counted

- **One attempt = one row.** Every time a task was started, or was due to start, is one attempt: the runs that ran,
  repeats included, and the tasks the watcher **skipped** (it never started them because the camera didn't see the
  table READY for them).
- **A skipped task counts as a FAIL.** Its score is 0. (The app's own SUMMARY.md files leave skipped tasks out of the
  counts; these reports don't.)
- **SOME PARTS counts as a FAIL** in the pass rate: a pass needs every target within 10 mm and 8 degrees, and no other
  cube moved more than 10 mm (PREREG). Its 0-100 score is kept beside it.
- **Pass rate** = PASS attempts / all attempts. **Mean score** = mean 0-100 score over all attempts (skipped = 0).
  **Tasks passed** = how many of the 20 tasks passed at least once; a task never tried counts as not passed.
- **Catastrophic** is a flag beside the result (a cube off the table, the arm in a stuck alarm), not a separate result.
